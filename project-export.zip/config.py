
import os
import psycopg2.pool

def get_db_pool():
    return psycopg2.pool.SimpleConnectionPool(1, 10, os.environ['DATABASE_URL'])
