
# Data Processing Flask App

This project is a Flask application that allows users to upload data files and processes them dynamically.

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Set your `DATABASE_URL` environment variable.

3. Run the application:
   ```
   python app.py
   ```

4. Open `http://localhost:5000` in your browser to upload files.
