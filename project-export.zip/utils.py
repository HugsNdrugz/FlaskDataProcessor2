
import pandas as pd
from config import get_db_pool

pool = get_db_pool()

def execute_query(query, params=None):
    conn = pool.getconn()
    try:
        with conn.cursor() as cur:
            cur.execute(query, params)
        conn.commit()
    finally:
        pool.putconn(conn)

def detect_file_type(file_path):
    data = pd.read_csv(file_path).columns.str.lower()

    if 'call type' in data:
        return 'calls'
    elif 'name' in data and 'phone number' in data:
        return 'contacts'
    elif 'sms type' in data:
        return 'sms'
    elif 'application name' in data:
        return 'applications'
    elif 'application' in data and 'text' in data:
        return 'keylogs'
    else:
        return None

def insert_data(table, data):
    insert_queries = {
        'calls': "INSERT INTO calls (contact_id, call_type, call_time, duration, location) VALUES (%s, %s, %s, %s, %s)",
        'contacts': "INSERT INTO contacts (contact_name, phone_number, email) VALUES (%s, %s, %s)",
        'sms': "INSERT INTO sms (sender_id, receiver_id, message_type, message_time, message_text, location) VALUES (%s, %s, %s, %s, %s, %s)",
        'applications': "INSERT INTO applications (application_name, package_name, installed_date) VALUES (%s, %s, %s)",
        'keylogs': "INSERT INTO keylogs (application_id, log_time, keylog_text) VALUES (%s, %s, %s)"
    }

    for _, row in data.iterrows():
        execute_query(insert_queries[table], tuple(row))

def process_and_insert_data(file_path):
    file_type = detect_file_type(file_path)
    if not file_type:
        print(f"Unknown file type for {file_path}")
        return

    data = pd.read_csv(file_path)
    insert_data(file_type, data)
