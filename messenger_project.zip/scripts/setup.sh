
#!/bin/bash
pip install -r backend/requirements.txt
npm install --prefix frontend
