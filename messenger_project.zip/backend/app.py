
from flask import Flask, jsonify
import psycopg2

app = Flask(__name__)

# PostgreSQL connection setup
conn = psycopg2.connect(
    host="ep-fragrant-scene-a507b740.us-east-2.aws.neon.tech",
    database="neondb",
    user="neondb_owner",
    password="4piPg2YGLuRy",
)

@app.route('/api/messages', methods=['GET'])
def get_messages():
    cursor = conn.cursor()
    cursor.execute("SELECT sender, text, timestamp FROM ChatMessenger ORDER BY timestamp ASC;")
    messages = cursor.fetchall()
    cursor.close()
    return jsonify([{"sender": msg[0], "text": msg[1], "timestamp": msg[2]} for msg in messages])

if __name__ == '__main__':
    app.run(debug=True)
