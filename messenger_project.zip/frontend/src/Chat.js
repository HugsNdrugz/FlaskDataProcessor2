
import React, { useEffect, useState } from 'react';
import './Chat.css';

const Chat = () => {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    fetch('/api/messages')
      .then((response) => response.json())
      .then((data) => setMessages(data))
      .catch((error) => console.error('Error fetching messages:', error));
  }, []);

  return (
    <div className="chat-container">
      {messages.map((msg, index) => (
        <div key={index} className={`chat-bubble ${msg.sender === 'me' ? 'outgoing' : 'incoming'}`}>
          <p className="sender-name">{msg.sender}</p>
          <p className="message-text">{msg.text}</p>
          <span className="timestamp">{new Date(msg.timestamp).toLocaleTimeString()}</span>
        </div>
      ))}
    </div>
  );
};

export default Chat;
