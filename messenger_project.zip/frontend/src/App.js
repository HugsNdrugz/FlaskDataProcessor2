
import Chat from './Chat';
function App() {
  return <Chat />;
}
export default App;
