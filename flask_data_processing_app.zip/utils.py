
import pandas as pd
import chardet
import psycopg2
from datetime import datetime
import os

def detect_encoding(file_path):
    with open(file_path, 'rb') as f:
        result = chardet.detect(f.read())
    return result.get('encoding', 'utf-8')

def convert_to_utc_safe(time_str, format_str="%b %d, %I:%M %p"):
    try:
        dt = datetime.strptime(time_str, format_str)
        dt = dt.replace(year=datetime.now().year)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return datetime(datetime.now().year, 2, 28, 23, 59).strftime("%Y-%m-%d %H:%M:%S")

def detect_file_type(df):
    columns = df.columns.str.lower()
    if 'call type' in columns:
        return 'calls'
    elif 'name' in columns and 'phone number' in columns:
        return 'contacts'
    elif 'sms type' in columns:
        return 'sms'
    elif 'application name' in columns:
        return 'applications'
    elif 'application' in columns and 'text' in columns:
        return 'keylogs'
    elif 'messenger' in columns:
        return 'chats'
    return None

def insert_data(table, data):
    DATABASE_URL = os.getenv('DATABASE_URL')

    query_map = {
        'calls': "INSERT INTO calls (contact_id, call_type, call_time, duration, location) VALUES (%s, %s, %s, %s, %s)",
        'contacts': "INSERT INTO contacts (contact_name, phone_number, email) VALUES (%s, %s, %s)",
        'sms': "INSERT INTO sms (sender_id, receiver_id, message_type, message_time, message_text, location) VALUES (%s, %s, %s, %s, %s, %s)",
        'applications': "INSERT INTO applications (application_name, package_name, installed_date) VALUES (%s, %s, %s)",
        'keylogs': "INSERT INTO keylogs (application_id, log_time, keylog_text) VALUES (%s, %s, %s)",
        'chats': "INSERT INTO chats (messenger, time, sender, text) VALUES (%s, %s, %s, %s)"
    }

    query = query_map.get(table)
    if not query:
        print(f"No query available for table: {table}")
        return

    try:
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()

        for _, row in data.iterrows():
            cur.execute(query, tuple(row))

        conn.commit()
        print(f"Data inserted successfully into {table}.")
    except Exception as e:
        print(f"Error inserting into {table}: {e}")
    finally:
        cur.close()
        conn.close()

def process_data(data):
    columns = set(data.columns.str.lower())

    if 'sms type' in columns:
        print("Processing as SMS...")
        data['Time'] = data['Time'].apply(lambda x: convert_to_utc_safe(x) if pd.notna(x) else None)
        data['From/To'] = data['From/To'].str.strip()
        data['Text'] = data['Text'].str.strip()
        data.fillna("Unknown", inplace=True)

    elif 'call type' in columns:
        print("Processing as Calls...")
        data['Time'] = data['Time'].apply(lambda x: convert_to_utc_safe(x) if pd.notna(x) else None)
        data['Duration (Sec)'] = pd.to_numeric(data['Duration (Sec)'].str.replace(' Sec', ''), errors='coerce').fillna(0).astype(int)
        data['From/To'].fillna("Private", inplace=True)

    return data

def process_and_insert_data(file_path):
    try:
        if file_path.endswith('.csv'):
            encoding = detect_encoding(file_path)
            df = pd.read_csv(file_path, encoding=encoding, on_bad_lines='skip')
        elif file_path.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file_path)
        else:
            return

        table = detect_file_type(df)
        if table:
            df_cleaned = process_data(df)
            insert_data(table, df_cleaned)
    except Exception as e:
        print(f"Error processing {os.path.basename(file_path)}: {e}")
