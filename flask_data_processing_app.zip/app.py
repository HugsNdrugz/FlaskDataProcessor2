from flask import Flask, render_template, request
import os
from utils import process_and_insert_data

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def upload_page():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file part', 400

    file = request.files['file']
    if file.filename == '':
        return 'No selected file', 400

    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    process_and_insert_data(file_path)

    return 'File processed and data inserted successfully!'

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
