{
    "translations": {
        "1VqMgLPpraa": "Previous item",
        "7zajSsSIBFZ": "Next item"
    },
    "virtual_modules": ["CometCompositeFocusIndicator.react$fbt_virtual"]
}