{
    "translations": {
        "9pTPm1txftc": "Unsupported file format",
        "3MspJ4rRDaT": "Download to play",
        "-Hi1PFpXdXk": "Couldn't play video",
        "x5Yq4cFsR_G": "Couldn't play audio",
        "BGxC_0TtXwE": "Retry",
        "jCbL2nmLvOs": "Couldn't download",
        "2xRftcH2vsr": "{previous items}; {following items}",
        "A8Te3iyJoQY": "{previous items} \u2022 {following items}",
        "ymp6OXT1HEX": "{previous items}, {following items}",
        "qQ-J1F_2ppK": "{list of items} and {last item}",
        "pqsshngVpqN": "{list of items} or {last item}",
        "KtjanthXGG0": "{previous items}; {last item}",
        "pWqMqQJ5cvg": "{list of items} \u2022 {last item}",
        "QEekv2-b_Os": "{list of items}, {last item}"
    },
    "virtual_modules": ["MAWVideoAudioPlaybackErrorHandlerUtils$fbt_virtual", "intlList$fbt_virtual"]
}