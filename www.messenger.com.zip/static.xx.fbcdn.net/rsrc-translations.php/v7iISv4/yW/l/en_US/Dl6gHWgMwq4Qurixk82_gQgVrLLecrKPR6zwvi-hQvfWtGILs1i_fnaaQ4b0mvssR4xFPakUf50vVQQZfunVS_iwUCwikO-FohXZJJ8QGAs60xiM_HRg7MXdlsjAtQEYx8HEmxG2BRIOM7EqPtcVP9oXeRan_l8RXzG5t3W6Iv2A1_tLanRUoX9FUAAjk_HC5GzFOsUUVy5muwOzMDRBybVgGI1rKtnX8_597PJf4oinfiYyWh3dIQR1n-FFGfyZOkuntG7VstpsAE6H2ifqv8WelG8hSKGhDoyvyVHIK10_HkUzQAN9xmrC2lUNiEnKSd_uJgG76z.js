{
    "translations": {
        "uQTwTbCP0iW": "{Inviter Name} invited you to join",
        "1VqMgLPpraa": "Previous item",
        "7zajSsSIBFZ": "Next item",
        "KJ9BpmLEozf": "Active now",
        "_H_8HkZmS8j": "Active {time} ago",
        "6lD-XyRyuHe": "Loading...",
        "32piJ10frlX": "Audio renderer error: Please restart your computer.",
        "6MAWOMXczk1": "This video is DRM-protected, but your device certificate appears to be revoked. Please make sure your browser is up to date, and try again.",
        "EuR8fzpxUQU": "This video cannot be played in the browser, operating system, or hardware you're using.",
        "NrJkVWZ6st1": "This video content isn't available right now.",
        "n-kQyB08R28": "No suggested searches.",
        "71Zs7ul5B_o": {
            "*": "{number} suggested searches",
            "_1": "1 suggested search"
        },
        "UnoAJjMNsJN": "You can now pin messages"
    },
    "virtual_modules": ["MAWUpdateLSThreadCapabilities$fbt_virtual", "CometCompositeFocusIndicator.react$fbt_virtual", "fbs$fbt_virtual", "useTriggerAccessibilityAlert$fbt_virtual", "usePresenceUnifiedStatusText$fbt_virtual", "FDSPopoverLoadingState.react$fbt_virtual", "getVideoPlayerUserFacingErrorMessageFromError$fbt_virtual", "useCometTypeaheadViewLabel$fbt_virtual", "MWPinnedMessageRowFooterNUX.react$fbt_virtual"]
}