{
    "translations": {
        "sqvt0agiqDI": "Verifying your PIN",
        "jo46UlZ-CxV": "Code sent.",
        "X0e88liSOaT": "Facebook",
        "f4zXRCPfA02": "Messenger",
        "x7Td_cS4dOE": "Last seen {last_seen}",
        "kJ5r2sR46Qc": "Unable to show your devices. {try_again}",
        "03dyiSnSf15": "Refresh"
    },
    "virtual_modules": ["MWChatEBPinCodeVerifyIndicator.react$fbt_virtual", "MWEncryptedBackupsOTCShowNotificationSentToast$fbt_virtual", "MWEncryptedBackupsDeviceListCell.react$fbt_virtual", "MWEncryptedBackupsOTCEligibleDevicesList.react$fbt_virtual"]
}