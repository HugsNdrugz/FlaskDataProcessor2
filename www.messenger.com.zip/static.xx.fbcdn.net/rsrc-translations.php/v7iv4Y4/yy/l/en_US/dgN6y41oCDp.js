{
    "translations": {
        "0qfdnRKA9Ag": "Attendance-update",
        "EBurxV5oTK7": "Canceled",
        "AlGwHch7pkD": "Declined",
        "FBK2-m7QkC9": "No-show",
        "fZa0Y0vJA5c": "Appointment request",
        "shi97YE6--k": "Scheduled",
        "Yqgf6F7YPxj": "This attachment has been marked as malicious.",
        "8Hq3iHE6VuY": "Workplace user",
        "u21fesk-4Br": "Facebook user",
        "wQqRyMlOKFy": "Workplace user",
        "6YiFugiNOIw": "Workrooms User",
        "yosnsm5UZCw": "Facebook user"
    },
    "virtual_modules": ["MessengerStoryAttachmentTransformer.bs$fbt_virtual", "MessengerAttachmentTransformer.bs$fbt_virtual", "MessengerServerPayloadTransformer.bs$fbt_virtual", "MessengerParticipants.bs$fbt_virtual"]
}