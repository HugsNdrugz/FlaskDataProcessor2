{
    "translations": {
        "GWeGP0j1NWF": "Learn more",
        "dzG08k88Xfs": "Sorry, we're having trouble playing this video.",
        "pymzrO9zrya": "Play video",
        "neZzFA-dHLC": "Pause",
        "HFCl7btmLVQ": "Replay",
        "Pdft-1wnTrL": "Play",
        "3cUloDtyzSK": "Play from beginning",
        "jTksR1FMT97": "Skip to end",
        "69czi8qDKMx": "Change Position",
        "Fazg7jyI-AJ": "Fast forward 10 seconds",
        "Hz44qTuOc36": "Fast forward 5 seconds",
        "fXj-dMG-OtJ": "Rewind 10 seconds",
        "KzLU7zLc4h8": "Rewind 5 seconds",
        "2eve7xHkp9w": "Unmute",
        "5xFv4FPvBT3": "Mute",
        "2--dERDMJls": "Increase volume",
        "rnGEAKbNBgc": "Decrease volume",
        "qjrL7gM7Ew1": "Change volume"
    },
    "virtual_modules": ["VideoPlayerFallbackLearnMoreLink.react$fbt_virtual", "VideoPlayerFallbackCover.react$fbt_virtual", "VideoPlayerPlayButton.react$fbt_virtual", "VideoPlayerPlaybackControlBase.react$fbt_virtual", "VideoPlayerScrubberBase.react$fbt_virtual", "VideoPlayerScrubber.react$fbt_virtual", "VideoPlayerSmallPlayButton.react$fbt_virtual", "VideoPlayerVolumeControlBase.react$fbt_virtual", "VideoPlayerVolumeSliderBase.react$fbt_virtual"]
}