{
    "translations": {
        "jdA38No1bHZ": "Dismiss {card name} card",
        "PfdWOKkgwGk": "Dismiss card",
        "7PesNdiLm6N": "A reminder about unsent messages",
        "jjSY-Fh1rGw": "Unsending messages gives people more control over the messages they've sent. They can still be included in reports.",
        "W_KwwnBzw9K": "Learn more",
        "CqytfJoYvSJ": "OK",
        "2M6kSClZEXW": "Something went wrong when submitting feedback. Please try again later.",
        "HrskqaLxsoO": "Bad response",
        "UiU1vrQt_qf": "Good response",
        "BGxC_0TtXwE": "Retry",
        "aP8gCQjcFIz": "Download"
    },
    "virtual_modules": ["CometContextualMessage.react$fbt_virtual", "MWChatUnsendNUXReceiverBanner.react$fbt_virtual", "useUGCAgentsSubmitFeedbackMutation$fbt_virtual", "useGenAiNegativeFeedback$fbt_virtual", "useGenAiPositiveFeedback$fbt_virtual", "MWV2AttachmentRetriableErrorPlaceholderWithBlurImage.react$fbt_virtual", "MWV2AttachmentDownloadablePlaceholderWithBlurImage.react$fbt_virtual"]
}