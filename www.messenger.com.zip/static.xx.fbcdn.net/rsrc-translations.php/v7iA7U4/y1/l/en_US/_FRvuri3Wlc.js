{
    "translations": {
        "mrw3CpFXi7r": "Open photo",
        "7iXxkHlQ-F-": "If you can't find the media you're looking for, try using the Messenger mobile app.",
        "PpijmwC5Lut": {
            "Photos and videos": "Photos and videos shared in this channel will appear here.",
            "Files": "Files shared in this channel will appear here.",
            "Links": "Links shared in this channel will appear here."
        },
        "6OltF4lnito": {
            "Photos and videos": "Photos and videos that you exchange with {name} will appear here.",
            "Files": "Files that you exchange with {name} will appear here.",
            "Links": "Links that you exchange with {name} will appear here."
        },
        "0YQmVoWIu6A": {
            "Photos and videos": "Photos and videos that you exchange with this group will appear here.",
            "Files": "Files that you exchange with this group will appear here.",
            "Links": "Links that you exchange with this group will appear here."
        },
        "F8WROxnU5px": {
            "media": "No media",
            "files": "No files",
            "links": "No links"
        },
        "LlHcIvsh5It": "{restoredPercentage}\u0025 of chats loaded...",
        "EPxp6BXcf-B": "All chats loaded.",
        "BcL_Hf5UaRM": "Currently migrating database",
        "UJ0S4v9Hktq": "Migration completed",
        "BGxC_0TtXwE": "Retry",
        "uiTAWyhPCWI": "File",
        "W_KwwnBzw9K": "Learn more",
        "PnVpnKg9Gg_": "Refresh",
        "P1CnLTqi4fK": "Add people",
        "K0E4NNoKNtJ": "Added to chat",
        "sbctGC-UNw4": "Not added to chat",
        "JFJx3iugODR": "Community Bot Settings",
        "c2UIg9XVAm2": "Copy link",
        "iEaTUwEK-KE": "Invite community members to join this chat",
        "AyF1PV5UJkW": "Events",
        "t79c9SrYA8D": {
            "*": "{Number of upcoming events} upcoming events",
            "_1": "{Number of upcoming events} upcoming event"
        },
        "XLqB3kIUlsv": "Go to {facebook group name}",
        "5FWHZ8StuMQ": {
            "*": "Message {name}"
        },
        "gvt-u-jxLjT": {
            "*": "Message {name}"
        },
        "3WTOYPxVm2l": "Admin",
        "J1b76x4xKfs": "Moderator",
        "d3jtAkHct5c": "Host",
        "YJ7dDY2F-1_": "Pending",
        "XW-fqo6HqSP": "Invited by you",
        "iywW1hlnypb": "Blocked",
        "I91w8MVMuJd": "Member options",
        "-R08aUV4n3s": {
            "*": "Member settings for {name}"
        },
        "M-jFobtfz3M": "Hosts lead conversations and help moderate the chat. They'll appear here once they're added.",
        "7DQH5InZyqq": "No chat hosts",
        "BN54OIlz3MA": "See all",
        "4FAWQwvEk9h": "Member requests",
        "B36kC69TSuv": "Sidechats {subthread_count}",
        "cO3zYIieEQ4": "Show channel in inbox",
        "nO-_JTOnN3T": "You can message as {page_name} while logged into {acting_account_name} on Messenger.",
        "wSyF3E_Fmrl": "Back",
        "iMHo6cQn9S_": "Message from main profile",
        "NOWur2M4WPy": ["Channel admin", "91d783db2fb886ee4801ae5e0a86e04c", 1],
        "iMEghxYa-Iu": "Message from main profile",
        "sqTeJmgA5ut": "Back",
        "Ah2RnxbIZcr": "{Event start day} at {Event start time}",
        "v5PrQVy1sl6": {
            "*": "{number} went",
            "_1": "1 went"
        },
        "XSB3PsCrhNb": {
            "*": "{number} going",
            "_1": "1 going"
        },
        "fXxTlY6mdIj": {
            "*": "{number} interested",
            "_1": "1 interested"
        },
        "BtbmbekLHtu": "Dropdown menu for an event linked to a chat",
        "X0KyQ0oU0tZ": "Go to Facebook event",
        "1bPihBJj8iC": "Events",
        "jhw66QHG4uX": "Create new event",
        "xaWBg6G3BFD": "View pinned messages",
        "__m4bWP_4pT": "You've reached the maximum number of members. To add another, please remove someone from the group.",
        "Vlach4Yw5My": "Media",
        "FHoGsrpePI0": "Files",
        "HIyYRXboLqA": "Links",
        "IJaUCbo68p8": "Media, files and links",
        "4EGmvHMttO2": "Media and files"
    },
    "virtual_modules": ["MWInboxInfoPhotoGalleryItem.react$fbt_virtual", "MWSharedContentCommonFbt$fbt_virtual", "MWInboxInfoSharedContentEmptyTab.react$fbt_virtual", "MAWLoadingStateSpinner.react$fbt_virtual", "MAWMigrationStateSpinner.react$fbt_virtual", "MWInboxInfoSharedContentFilePreview.react$fbt_virtual", "MWInboxInfoSharedContentFile.react$fbt_virtual", "MAWUserVisibleErrorsNuxWrapper.react$fbt_virtual", "MWAddMemberToGroupListCell.react$fbt_virtual", "MWCMBotStrings$fbt_virtual", "MWCMBotDetailsEntrypoint.react$fbt_virtual", "MWCMInboxInfoGroupCopyLinkButton.react$fbt_virtual", "MWCMInboxInfoGroupEventsButton.react$fbt_virtual", "MWCMInboxInfoGroupLink.react$fbt_virtual", "MWLSGroupMembershipMemberCellProfilePhoto.react$fbt_virtual", "MWLSGroupMembershipMemberCell.react$fbt_virtual", "MWLSGroupMembershipMemberList.react$fbt_virtual", "MWCMInboxInfoMemberList.react$fbt_virtual", "MWCMInboxInfoMemberRequests.react$fbt_virtual", "MWCMSubthreadlistMenuItem.react$fbt_virtual", "MWChannelsPersonalInboxOptInPage.react$fbt_virtual", "MWInboxInfoChannelCreatorProfileLink.react$fbt_virtual", "MWInboxInfoChannelPersonalInboxOptIn.react$fbt_virtual", "MWInboxInfoSubPageHeader.react$fbt_virtual", "MWInboxInfoEventsListSection.react$fbt_virtual", "MWInboxInfoViewPinnedMessages.react$fbt_virtual", "MWInboxInfoMemberList.react$fbt_virtual", "MWInboxInfoSharedContent.react$fbt_virtual"]
}