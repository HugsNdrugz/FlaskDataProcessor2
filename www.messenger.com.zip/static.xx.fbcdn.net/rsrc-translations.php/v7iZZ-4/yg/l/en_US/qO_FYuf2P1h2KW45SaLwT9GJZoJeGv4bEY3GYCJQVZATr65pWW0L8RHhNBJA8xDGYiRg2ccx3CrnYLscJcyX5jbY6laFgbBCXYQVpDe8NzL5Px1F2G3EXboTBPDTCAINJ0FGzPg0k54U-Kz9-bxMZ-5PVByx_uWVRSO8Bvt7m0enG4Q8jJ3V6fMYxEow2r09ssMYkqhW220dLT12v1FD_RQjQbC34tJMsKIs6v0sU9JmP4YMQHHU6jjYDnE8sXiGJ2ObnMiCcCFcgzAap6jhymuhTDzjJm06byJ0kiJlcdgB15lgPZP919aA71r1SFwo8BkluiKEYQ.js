{
    "translations": {
        "9XeRgIrgALB": "+{number more}",
        "kVm3XG6kEyt": "See everyone",
        "d2rQbelcbvx": {
            "*": "+ {number} more profiles",
            "_1": "+ 1 more profile"
        },
        "AVRl6ij3kje": "Disabled",
        "AOlGHVa_PET": "Enabled",
        "sqTeJmgA5ut": "Back",
        "DOoRvZWfN9Q": "Refresh",
        "iQVounN-Hch": "Refresh the page to reload them.",
        "vJj0Hk9D_-R": {
            "*": "Couldn\u2019t load chats",
            "_1": "Couldn\u2019t load chat"
        },
        "U5NUnUf9KdD": {
            "*": "Unable to retrieve chats",
            "_1": "Unable to retrieve chat"
        },
        "ee6MA3uWv7t": "Some end-to-end encrypted messages on this device may be missing. If you've set up secure storage, try refreshing this page to restore them.",
        "plrZEdqhq2n": {
            "*": "Your chats are out of date.",
            "_1": "Your chat is out of date."
        },
        "0a79Vl-Ytg3": {
            "*": "Refresh your chats",
            "_1": "Refresh your chat"
        },
        "LiLFo9P7Z2y": "Reload",
        "Hg8XBFMDRr1": {
            "*": "Reload this page to see your chats.",
            "_1": "Reload this page to see your chat."
        },
        "OHGlQkJYzQl": "Messages are missing. Restore your chat history to search more messages.",
        "LQMCgf275AT": "Restore now",
        "dV9Vz_8TRow": "Confirm",
        "vfZ0qXC5Zmr": "Cancel",
        "36BYGlpQtWb": "How did you learn about this channel?",
        "V-weVECiTjR": "What should I use this channel for?",
        "RhK4ghDrdIN": "What song are you listening to?",
        "g1ZdnaGJN5X": "Make me laugh \ud83d\udc80",
        "E_415VXITzl": "Favorite thing right now \ud83d\udc98",
        "eHLXzP2TSOZ": "Favorite travel destination \u2708\ufe0f",
        "aL9VVWwvNE9": "Your happy place \u2763\ufe0f",
        "TOM4ZEHVssE": "Best part of 2024 so far?",
        "AzAym9J7EWA": "Something you're proud of \ud83d\udc9f",
        "uXjDaOT32-5": "Ten years ago, I was...",
        "QxscZ4lxunq": "What are you grateful for today? \ud83e\udef6",
        "qy8iamPbReV": "What would your dream job be if money didn't matter?",
        "TXxbFpKeb22": "What's inspiring you right now? \ud83c\udf1f",
        "6gV4NChieWE": "What's something unique about yourself?",
        "JLk6BM4UvkT": "A movie you enjoyed recently \ud83c\udfa5",
        "mwik205YEPp": "Health is wealth \ud83d\udcaa\ud83e\udd57",
        "8sIVGHbOcnd": "The last concert you went to \ud83d\udc69\u200d\ud83c\udfa4",
        "X5O2vx4mHSM": "Today I learned...",
        "FPtMuola2gP": "What are you doing tonight?",
        "_58Ig9CWslh": "Could not create prompt",
        "racSmevYoYZ": "Send",
        "ddF1YsNwDg4": "Cancel",
        "ALK-qDDamkT": "New prompt",
        "5IH2ZuZJVHE": "Members can respond with text for 24 hours.",
        "tnRfHlva-bL": "Close",
        "XzprMQh2D7n": "Close",
        "GHJU3Bu9b8k": "Profile photo",
        "ieqv99SUA1F": "{alt}, view story",
        "BZVPmyBiLsa": "Profile story",
        "AEU9lK-0d2O": "Profile Photo",
        "f9gCYTnWqPh": "Install Chrome",
        "s0GPCxVDhdM": "Get Chrome to join",
        "3WXTq_usDO0": "This feature isn't supported by your browser. Install {link to install chrome} to use all of Workplace's audio calling and video chat features.",
        "agcfNH3Ijps": "This feature isn't supported by your browser. Install {link to install chrome} to use all of Messenger's audio calling and video chat features.",
        "RxRErEZcnki": "Not now",
        "MIDsNkwRENR": "Incoming {Unsupported feature name}",
        "qvGfLDDj2uv": "Chrome"
    },
    "virtual_modules": ["MDSFacepilePhoto.react$fbt_virtual", "getListCellAddOn.react$fbt_virtual", "FDSMenuHeaderListCell.react$fbt_virtual", "getMWErrorDefinition$fbt_virtual", "MWMessageSearchEBRestoreUpsell.react$fbt_virtual", "CometTwoButtonDialog.react$fbt_virtual", "useMWChatPromptSuggestions$fbt_virtual", "MWChatPromptDialog.react$fbt_virtual", "FDSDialogStartAlignedTextHeader.react$fbt_virtual", "CometAlertDialogImpl.react$fbt_virtual", "MDSProfilePhoto.react$fbt_virtual", "MDSToast.react$fbt_virtual", "FDSProfilePhotoForActor.react$fbt_virtual", "RTWebUnsupportedDialog.react$fbt_virtual"]
}