; /*FB_PKG_DELIM*/

__d("ACTSanitizerApiTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        Valid: 0,
        UrlFailure: 1,
        MessageTextFailure: 2,
        CtaFailure: 3
    });
    f.ACTSanitizerValidationResult = a
}), 66);
__d("LSIsMobileClient", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return c[0] = !1, b.resolve(c)
    }
    a.__sproc_name__ = "LSEncryptedBackupsIsMobileClientStoredProcedure";
    e.exports = a
}), null);
__d("MebClientLogsFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("3226");
    b = d("FalcoLoggerInternal").create("meb_client_logs", a);
    e = b;
    g["default"] = e
}), 98);
__d("LSLogMebClientEvent.nop", ["I64", "LSVec", "MebClientLogsFalcoEvent", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    a = function(a, e, f, g, j, k) {
        c("MebClientLogsFalcoEvent").log(function() {
            return {
                calling_class: f,
                device_family_id: void 0,
                device_registration_id: void 0,
                log_level: (i || (i = d("I64"))).to_string(k),
                msg: g,
                trace_ids: c("LSVec").toArray(j)
            }
        });
        return (h || (h = b("Promise"))).resolve()
    };
    g["default"] = a
}), 98);
__d("WAProtoConst", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        REPEATED: 1 << 6,
        PACKED: 1 << 7,
        REQUIRED: 1 << 8
    };
    b = 31;
    c = {
        INT32: 1,
        INT64: 2,
        UINT32: 3,
        UINT64: 4,
        SINT32: 5,
        SINT64: 6,
        BOOL: 7,
        ENUM: 8,
        FIXED64: 9,
        SFIXED64: 10,
        DOUBLE: 11,
        STRING: 12,
        BYTES: 13,
        MESSAGE: 14,
        FIXED32: 15,
        SFIXED32: 16,
        FLOAT: 17,
        MAP: 18
    };
    d = {
        VARINT: 0,
        BIT64: 1,
        BINARY: 2,
        BIT32: 5
    };
    e = {
        ONEOF: "__oneofs__",
        RESERVED: "__reserved__",
        RESERVED_TAGS: "tags",
        RESERVED_FIELDS: "fields"
    };
    f.FLAGS = a;
    f.TYPE_MASK = b;
    f.TYPES = c;
    f.ENC = d;
    f.KEYS = e
}), 66);
__d("WACommon.pb", ["WAProtoConst"], (function(a, b, c, d, e, f, g) {
    a = {
        EVERYONE: 1,
        SILENT: 2,
        AI: 3,
        AI_IMAGINE: 4
    };
    b = {
        PLACEHOLDER: 0,
        NO_PLACEHOLDER: 1,
        IGNORE: 2
    };
    c = {};
    e = {};
    f = {};
    var h = {};
    c.internalSpec = {
        remoteJid: [1, (d = d("WAProtoConst")).TYPES.STRING],
        fromMe: [2, d.TYPES.BOOL],
        id: [3, d.TYPES.STRING],
        participant: [4, d.TYPES.STRING]
    };
    e.internalSpec = {
        commandType: [1, d.TYPES.ENUM, a],
        offset: [2, d.TYPES.UINT32],
        length: [3, d.TYPES.UINT32],
        validationToken: [4, d.TYPES.STRING]
    };
    f.internalSpec = {
        text: [1, d.TYPES.STRING],
        mentionedJid: [2, d.FLAGS.REPEATED | d.TYPES.STRING],
        commands: [3, d.FLAGS.REPEATED | d.TYPES.MESSAGE, e]
    };
    h.internalSpec = {
        payload: [1, d.TYPES.BYTES],
        version: [2, d.TYPES.INT32]
    };
    g.COMMAND_COMMAND_TYPE = a;
    g.FUTURE_PROOF_BEHAVIOR = b;
    g.MessageKeySpec = c;
    g.CommandSpec = e;
    g.MessageTextSpec = f;
    g.SubProtocolSpec = h
}), 98);
__d("WAArmadilloXMA.pb", ["WACommon.pb", "WAProtoConst"], (function(a, b, c, d, e, f, g) {
    var h;
    a = {
        INFO: 0,
        EYE_OFF: 1,
        NEWS_OFF: 2,
        WARNING: 3,
        PRIVATE: 4,
        NONE: 5,
        MEDIA_LABEL: 6,
        POST_COVER: 7,
        POST_LABEL: 8,
        WARNING_SCREENS: 9
    };
    b = {
        OPEN_NATIVE: 11
    };
    c = {
        SINGLE: 0,
        HSCROLL: 1,
        PORTRAIT: 3,
        STANDARD_DXMA: 12,
        LIST_DXMA: 15,
        GRID: 16
    };
    e = {
        UNSUPPORTED: -1,
        IG_STORY_PHOTO_MENTION: 4,
        IG_SINGLE_IMAGE_POST_SHARE: 9,
        IG_MULTIPOST_SHARE: 10,
        IG_SINGLE_VIDEO_POST_SHARE: 11,
        IG_STORY_PHOTO_SHARE: 12,
        IG_STORY_VIDEO_SHARE: 13,
        IG_CLIPS_SHARE: 14,
        IG_IGTV_SHARE: 15,
        IG_SHOP_SHARE: 16,
        IG_PROFILE_SHARE: 19,
        IG_STORY_PHOTO_HIGHLIGHT_SHARE: 20,
        IG_STORY_VIDEO_HIGHLIGHT_SHARE: 21,
        IG_STORY_REPLY: 22,
        IG_STORY_REACTION: 23,
        IG_STORY_VIDEO_MENTION: 24,
        IG_STORY_HIGHLIGHT_REPLY: 25,
        IG_STORY_HIGHLIGHT_REACTION: 26,
        IG_EXTERNAL_LINK: 27,
        IG_RECEIVER_FETCH: 28,
        FB_FEED_SHARE: 1e3,
        FB_STORY_REPLY: 1001,
        FB_STORY_SHARE: 1002,
        FB_STORY_MENTION: 1003,
        FB_FEED_VIDEO_SHARE: 1004,
        FB_GAMING_CUSTOM_UPDATE: 1005,
        FB_PRODUCER_STORY_REPLY: 1006,
        FB_EVENT: 1007,
        FB_FEED_POST_PRIVATE_REPLY: 1008,
        FB_SHORT: 1009,
        FB_COMMENT_MENTION_SHARE: 1010,
        MSG_EXTERNAL_LINK_SHARE: 2e3,
        MSG_P2P_PAYMENT: 2001,
        MSG_LOCATION_SHARING: 2002,
        MSG_LOCATION_SHARING_V2: 2003,
        MSG_HIGHLIGHTS_TAB_FRIEND_UPDATES_REPLY: 2004,
        MSG_HIGHLIGHTS_TAB_LOCAL_EVENT_REPLY: 2005,
        MSG_RECEIVER_FETCH: 2006,
        MSG_IG_MEDIA_SHARE: 2007,
        MSG_GEN_AI_SEARCH_PLUGIN_RESPONSE: 2008,
        MSG_REELS_LIST: 2009,
        MSG_CONTACT: 2010,
        MSG_THREADS_POST_SHARE: 2011,
        MSG_FILE: 2012,
        MSG_AVATAR_DETAILS: 2013,
        MSG_AI_CONTACT: 2014,
        MSG_MEMORIES_SHARE: 2015,
        MSG_SHARED_ALBUM_REPLY: 2016,
        MSG_SHARED_ALBUM: 2017,
        MSG_OCCAMADILLO_XMA: 2018,
        MSG_GEN_AI_SUBSCRIPTION: 2021,
        MSG_GEN_AI_REMINDER: 2022,
        MSG_GEN_AI_MEMU_ONBOARDING_RESPONSE: 2023,
        MSG_NOTE_REPLY: 2024,
        MSG_NOTE_MENTION: 2025,
        RTC_AUDIO_CALL: 3e3,
        RTC_VIDEO_CALL: 3001,
        RTC_MISSED_AUDIO_CALL: 3002,
        RTC_MISSED_VIDEO_CALL: 3003,
        RTC_GROUP_AUDIO_CALL: 3004,
        RTC_GROUP_VIDEO_CALL: 3005,
        RTC_MISSED_GROUP_AUDIO_CALL: 3006,
        RTC_MISSED_GROUP_VIDEO_CALL: 3007,
        DATACLASS_SENDER_COPY: 4e3
    };
    f = {};
    var i = {};
    f.internalSpec = {
        associatedMessage: [1, (h = d("WAProtoConst")).TYPES.MESSAGE, (d = d("WACommon.pb")).SubProtocolSpec],
        targetType: [2, h.TYPES.ENUM, e],
        targetUsername: [3, h.TYPES.STRING],
        targetId: [4, h.TYPES.STRING],
        targetExpiringAtSec: [5, h.TYPES.INT64],
        xmaLayoutType: [6, h.TYPES.ENUM, c],
        ctas: [7, h.FLAGS.REPEATED | h.TYPES.MESSAGE, i],
        previews: [8, h.FLAGS.REPEATED | h.TYPES.MESSAGE, d.SubProtocolSpec],
        titleText: [9, h.TYPES.STRING],
        subtitleText: [10, h.TYPES.STRING],
        maxTitleNumOfLines: [11, h.TYPES.UINT32],
        maxSubtitleNumOfLines: [12, h.TYPES.UINT32],
        favicon: [13, h.TYPES.MESSAGE, d.SubProtocolSpec],
        headerImage: [14, h.TYPES.MESSAGE, d.SubProtocolSpec],
        headerTitle: [15, h.TYPES.STRING],
        overlayIconGlyph: [16, h.TYPES.ENUM, a],
        overlayTitle: [17, h.TYPES.STRING],
        overlayDescription: [18, h.TYPES.STRING],
        sentWithMessageId: [19, h.TYPES.STRING],
        messageText: [20, h.TYPES.STRING],
        headerSubtitle: [21, h.TYPES.STRING],
        xmaDataclass: [22, h.TYPES.STRING],
        contentRef: [23, h.TYPES.STRING],
        mentionedJid: [24, h.FLAGS.REPEATED | h.TYPES.STRING],
        commands: [25, h.FLAGS.REPEATED | h.TYPES.MESSAGE, d.CommandSpec]
    };
    i.internalSpec = {
        buttonType: [1, h.TYPES.ENUM, b],
        title: [2, h.TYPES.STRING],
        actionUrl: [3, h.TYPES.STRING],
        nativeUrl: [4, h.TYPES.STRING],
        ctaType: [5, h.TYPES.STRING],
        actionContentBlob: [6, h.TYPES.STRING]
    };
    g.EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH = a;
    g.EXTENDED_CONTENT_MESSAGE_CTA_BUTTON_TYPE = b;
    g.EXTENDED_CONTENT_MESSAGE_XMA_LAYOUT_TYPE = c;
    g.EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE = e;
    g.ExtendedContentMessageSpec = f;
    g.ExtendedContentMessage$CTASpec = i
}), 98);
__d("WABinary", ["WAHex", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 65533,
        i = 10,
        j = new Uint8Array(i),
        k = new Uint8Array(0);
    a = function() {
        function a(b, c) {
            var d = this;
            b === void 0 && (b = k);
            c === void 0 && (c = !1);
            this.$1 = new Uint8Array(0);
            this.$2 = 0;
            this.$4 = 0;
            this.write = function() {
                for (var b = 0; b < arguments.length; b++) {
                    var c = b < 0 || arguments.length <= b ? void 0 : arguments[b];
                    typeof c === "string" ? d.writeString(c) : typeof c === "number" ? d.writeUint8(c) : c instanceof a ? d.writeBinary(c) : c instanceof ArrayBuffer ? d.writeBuffer(c) : c instanceof Uint8Array && d.writeByteArray(c)
                }
            };
            b instanceof ArrayBuffer ? (this.$1 = new Uint8Array(b), this.$2 = this.$4 = b.byteLength) : b instanceof Uint8Array && (this.$1 = b, this.$2 = this.$4 = b.length);
            this.$5 = 0;
            this.$6 = this.$3 = 0;
            this.$7 = null;
            this.$8 = c;
            this.$9 = 0;
            this.$10 = 0
        }
        var b = a.prototype;
        b.size = function() {
            return this.$2 - this.$3
        };
        b.peek = function(a, b) {
            this.$9++;
            var c = this.$3,
                d = this.$5;
            try {
                return a(this, b)
            } finally {
                this.$9--, this.$3 = c - (this.$5 - d)
            }
        };
        b.advance = function(a) {
            this.$11(a)
        };
        b.readWithViewParser = function(a, b, c, d) {
            return b(this.$12(), this.$11(a), a, c, d)
        };
        b.readWithBytesParser = function(a, b, c, d) {
            return b(this.$1, this.$11(a), a, c, d)
        };
        b.readUint8 = function() {
            return p(this, 1, r, !1)
        };
        b.readInt8 = function() {
            return p(this, 1, r, !0)
        };
        b.readUint16 = function(a) {
            a === void 0 && (a = this.$8);
            return p(this, 2, s, a)
        };
        b.readInt32 = function(a) {
            a === void 0 && (a = this.$8);
            return p(this, 4, t, a)
        };
        b.readUint32 = function(a) {
            a === void 0 && (a = this.$8);
            return p(this, 4, u, a)
        };
        b.readInt64 = function(a) {
            a === void 0 && (a = this.$8);
            return p(this, 8, v, U, a)
        };
        b.readUint64 = function(a) {
            a === void 0 && (a = this.$8);
            return p(this, 8, v, V, a)
        };
        b.readLong = function(a, b) {
            b === void 0 && (b = this.$8);
            return p(this, 8, v, a, b)
        };
        b.readFloat32 = function(a) {
            a === void 0 && (a = this.$8);
            return p(this, 4, w, a)
        };
        b.readFloat64 = function(a) {
            a === void 0 && (a = this.$8);
            return p(this, 8, x, a)
        };
        b.readVarInt = function(a) {
            var b = this.size();
            b = q(this, 0, y, b);
            return q(this, b, z, a)
        };
        b.readBuffer = function(a) {
            a === void 0 && (a = this.size());
            return a === 0 ? new ArrayBuffer(0) : q(this, a, A)
        };
        b.readByteArray = function(a) {
            a === void 0 && (a = this.size());
            return a === 0 ? new Uint8Array(0) : q(this, a, B)
        };
        b.readBinary = function(b, c) {
            b === void 0 && (b = this.size());
            c === void 0 && (c = this.$8);
            if (b === 0) return new a(void 0, c);
            b = q(this, b, B);
            return new a(b, c)
        };
        b.indexOf = function(a) {
            if (a.length === 0) return 0;
            var b = this.$1,
                c = this.$2,
                d = this.$3,
                e = 0,
                f = d;
            for (var g = d; g < c; g++)
                if (b[g] === a[e]) {
                    e === 0 && (f = g);
                    e++;
                    if (e === a.byteLength) return g - d - a.byteLength + 1
                } else e > 0 && (e = 0, g = f);
            return -1
        };
        b.readString = function(a) {
            return q(this, a, C)
        };
        b.ensureCapacity = function(a) {
            this.$13(this.$3 + a)
        };
        b.ensureAdditionalCapacity = function(a) {
            this.$13(this.$4 + a)
        };
        b.writeToView = function(a, b, c, d) {
            var e = this.$14(a);
            return b(this.$12(), e, a, c, d)
        };
        b.writeToBytes = function(a, b, c, d) {
            var e = this.$14(a);
            return b(this.$1, e, a, c, d)
        };
        b.writeUint8 = function(a) {
            S(a, 0, 256, "uint8"), E(this, 1, F, a, !1)
        };
        b.writeInt8 = function(a) {
            S(a, -128, 128, "signed int8"), E(this, 1, F, a, !0)
        };
        b.writeUint16 = function(a, b) {
            b === void 0 && (b = this.$8), S(a, 0, 65536, "uint16"), D(this, 2, G, a, b)
        };
        b.writeInt16 = function(a, b) {
            b === void 0 && (b = this.$8), S(a, -32768, 32768, "signed int16"), D(this, 2, H, a, b)
        };
        b.writeUint32 = function(a, b) {
            b === void 0 && (b = this.$8), S(a, 0, 4294967296, "uint32"), D(this, 4, I, a, b)
        };
        b.writeInt32 = function(a, b) {
            b === void 0 && (b = this.$8), S(a, -2147483648, 2147483648, "signed int32"), D(this, 4, J, a, b)
        };
        b.writeUint64 = function(a, b) {
            b === void 0 && (b = this.$8), S(a, 0, 18446744073709552e3, "uint64"), D(this, 8, K, a, b)
        };
        b.writeInt64 = function(a, b) {
            b === void 0 && (b = this.$8), S(a, -9223372036854776e3, 9223372036854776e3, "signed int64"), D(this, 8, K, a, b)
        };
        b.writeFloat32 = function(a, b) {
            b === void 0 && (b = this.$8), D(this, 4, L, a, b)
        };
        b.writeFloat64 = function(a, b) {
            b === void 0 && (b = this.$8), D(this, 8, M, a, b)
        };
        b.writeVarInt = function(a) {
            S(a, -9223372036854776e3, 9223372036854776e3, "varint (signed int64)");
            var b = a < 0;
            a = b ? -a : a;
            var c = Math.floor(a / 4294967296);
            a = a - c * 4294967296;
            b && (c = ~c, a === 0 ? c++ : a = -a);
            b = R(c, a);
            E(this, b, N, c, a)
        };
        b.writeVarIntFromHexLong = function(a) {
            var b = d("WAHex").hexLongIsNegative(a);
            a = b ? d("WAHex").negateHexLong(a) : a;
            a = d("WAHex").hexLongToHex(a);
            var c = 0,
                e = 0;
            for (var f = 0; f < d("WAHex").NUM_HEX_IN_LONG; f++) c = c << 4 | e >>> 28, e = e << 4 | d("WAHex").hexAt(a, f);
            b && (c = ~c, e === 0 ? c++ : e = -e);
            a = R(c, e);
            E(this, a, N, c, e)
        };
        b.writeBinary = function(a) {
            a = a.peek(function(a) {
                return a.readByteArray()
            });
            if (a.length) {
                var b = this.$14(a.length);
                this.$1.set(a, b)
            }
        };
        b.writeBuffer = function(a) {
            this.writeByteArray(new Uint8Array(a))
        };
        b.writeByteArray = function(a) {
            var b = this.$14(a.length);
            this.$1.set(a, b)
        };
        b.writeBufferView = function(a) {
            this.writeByteArray(new Uint8Array(a.buffer, a.byteOffset, a.byteLength))
        };
        b.writeString = function(a) {
            E(this, n(a), O, a)
        };
        b.writeHexLong = function(a, b) {
            b === void 0 && (b = this.$8), D(this, 8, P, a, b)
        };
        b.writeBytes = function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            for (var d = 0; d < b.length; d++) S(b[d], 0, 256, "byte");
            E(this, b.length, Q, b)
        };
        b.writeAtomically = function(a, b) {
            this.$10++;
            var c = this.$4,
                d = this.$5;
            try {
                a = a(this, b);
                c = this.$4;
                d = this.$5;
                return a
            } finally {
                this.$10--, this.$4 = c - (this.$5 - d)
            }
        };
        b.writeWithVarIntLength = function(a, b) {
            var c = this.$4;
            a = this.writeAtomically(a, b);
            b = this.$4;
            this.writeVarInt(b - c);
            var d = this.$4 - b,
                e = this.$1;
            for (var f = 0; f < d; f++) j[f] = e[b + f];
            for (f = b - 1; f >= c; f--) e[f + d] = e[f];
            for (b = 0; b < d; b++) e[c + b] = j[b];
            return a
        };
        a.build = function() {
            for (var b = arguments.length, c = new Array(b), d = 0; d < b; d++) c[d] = arguments[d];
            var e = 0;
            for (var f = 0; f < c.length; f++) {
                var g = c[f];
                typeof g === "string" ? e += n(g) : typeof g === "number" ? e++ : g instanceof a ? e += g.size() : g instanceof ArrayBuffer ? e += g.byteLength : g instanceof Uint8Array && (e += g.length)
            }
            var h = new a();
            h.ensureCapacity(e);
            h.write.apply(h, arguments);
            return h
        };
        b.$12 = function() {
            return this.$7 || (this.$7 = new DataView(this.$1.buffer, this.$1.byteOffset))
        };
        b.$11 = function(a) {
            if (a < 0) throw c("err")("ReadError: given negative number of bytes to read");
            var b = this.$3;
            a = b + a;
            if (a > this.$2) throw c("err")(b === this.$2 ? "ReadError: tried to read from depleted binary" : "ReadError: tried to read beyond end of binary");
            this.$3 = a;
            this.$9 || (this.$6 = a);
            return b
        };
        b.$13 = function(a) {
            var b = this.$1;
            if (a <= b.length) return a;
            else {
                var c = this.$6;
                a = a - c;
                var d = Math.max(a, 2 * (b.length - c), 64);
                d = new Uint8Array(d);
                c ? (d.set(b.subarray(c)), this.$5 += c, this.$3 -= c, this.$2 -= c, this.$4 -= c, this.$6 = 0) : d.set(b);
                this.$1 = d;
                this.$7 = null;
                return a
            }
        };
        b.$14 = function(a) {
            a = this.$13(this.$4 + a);
            var b = this.$4;
            this.$4 = a;
            this.$10 || (this.$2 = a);
            return b
        };
        return a
    }();
    var l = "",
        m = 0;

    function n(a) {
        if (a === l) return m;
        var b = a.length,
            c = 0;
        for (var d = 0; d < b; d++) {
            var e = a.charCodeAt(d);
            if (e < 128) c++;
            else if (e < 2048) c += 2;
            else if (e < 55296 || 57344 <= e && e <= 65535) c += 3;
            else if (55296 <= e && e < 56320 && d + 1 !== b) {
                e = a.charCodeAt(d + 1);
                56320 <= e && e < 57344 ? (d++, c += 4) : c += 3
            } else c += 3
        }
        l = a;
        return m = c
    }

    function o(a, b, c) {
        var d = b >> 21;
        if (!a) return d === 0;
        else {
            a = b & 2097151;
            b = Boolean(a || c);
            return d === 0 || d === -1 && b
        }
    }

    function p(a, b, c, d, e) {
        return a.readWithViewParser(b, c, d, e)
    }

    function q(a, b, c, d, e) {
        return a.readWithBytesParser(b, c, d, e)
    }

    function r(a, b, c, d) {
        return d ? a.getInt8(b) : a.getUint8(b)
    }

    function s(a, b, c, d) {
        return a.getUint16(b, d)
    }

    function t(a, b, c, d) {
        return a.getInt32(b, d)
    }

    function u(a, b, c, d) {
        return a.getUint32(b, d)
    }

    function v(a, b, c, d, e) {
        c = a.getInt32(e ? b + 4 : b, e);
        a = a.getInt32(e ? b : b + 4, e);
        return d(c, a)
    }

    function w(a, b, c, d) {
        return a.getFloat32(b, d)
    }

    function x(a, b, c, d) {
        return a.getFloat64(b, d)
    }

    function y(a, b, d, e) {
        d = Math.min(e, i);
        e = 0;
        var f = 128;
        while (e < d && f & 128) f = a[b + e++];
        if (e === i && f > 1) throw c("err")("ParseError: varint exceeds 64 bits");
        else if (f & 128) return e + 1;
        return e
    }

    function z(b, c, d, a) {
        var e = 0,
            f = 0,
            g = d;
        d === i && (g--, f = b[c + g] & 1);
        for (d = g - 1; d >= 0; d--) e = e << 7 | f >>> 25, f = f << 7 | b[c + d] & 127;
        return a(e, f)
    }

    function A(a, b, c) {
        b = b + a.byteOffset;
        a = a.buffer;
        return b === 0 && c === a.byteLength ? a : a.slice(b, b + c)
    }

    function B(a, b, c) {
        return a.subarray(b, b + c)
    }

    function C(a, b, c) {
        c = b + c;
        var d = [],
            e = null;
        for (b = b; b < c; b++) {
            d.length > 5e3 && (e || (e = []), e.push(String.fromCharCode.apply(String, d)), d = []);
            var f = a[b] | 0;
            if ((f & 128) === 0) d.push(f);
            else if ((f & 224) === 192) {
                var g = W(a, b + 1, c);
                if (g) {
                    b++;
                    g = (f & 31) << 6 | g & 63;
                    g >= 128 ? d.push(g) : d.push(h)
                } else d.push(h)
            } else if ((f & 240) === 224) {
                g = W(a, b + 1, c);
                var i = W(a, b + 2, c);
                if (g && i) {
                    b += 2;
                    i = (f & 15) << 12 | (g & 63) << 6 | i & 63;
                    i >= 2048 && !(55296 <= i && i < 57344) ? d.push(i) : d.push(h)
                } else g ? (b++, d.push(h)) : d.push(h)
            } else if ((f & 248) === 240) {
                i = W(a, b + 1, c);
                g = W(a, b + 2, c);
                var j = W(a, b + 3, c);
                if (i && g && j) {
                    b += 3;
                    f = (f & 7) << 18 | (i & 63) << 12 | (g & 63) << 6 | j & 63;
                    if (f >= 65536 && f <= 1114111) {
                        j = f - 65536;
                        d.push(55296 | j >> 10, 56320 | j & 1023)
                    } else d.push(h)
                } else i && g ? (b += 2, d.push(h)) : i ? (b++, d.push(h)) : d.push(h)
            } else d.push(h)
        }
        f = String.fromCharCode.apply(String, d);
        if (e) {
            e.push(f);
            return e.join("")
        } else return f
    }

    function D(a, b, c, d, e) {
        return a.writeToView(b, c, d, e)
    }

    function E(a, b, c, d, e) {
        return a.writeToBytes(b, c, d, e)
    }

    function F(a, b, c, d) {
        a[b] = d
    }

    function G(a, b, c, d, e) {
        a.setUint16(b, d, e)
    }

    function H(a, b, c, d, e) {
        a.setInt16(b, d, e)
    }

    function I(a, b, c, d, e) {
        a.setUint32(b, d, e)
    }

    function J(a, b, c, d, e) {
        a.setInt32(b, d, e)
    }

    function K(a, b, c, d, e) {
        c = d < 0;
        d = c ? -d : d;
        var f = Math.floor(d / 4294967296);
        d = d - f * 4294967296;
        c && (f = ~f, d === 0 ? f++ : d = -d);
        a.setUint32(e ? b + 4 : b, f, e);
        a.setUint32(e ? b : b + 4, d, e)
    }

    function L(a, b, c, d, e) {
        a.setFloat32(b, d, e)
    }

    function M(a, b, c, d, e) {
        a.setFloat64(b, d, e)
    }

    function N(a, b, c, d, e) {
        d = d;
        e = e;
        c = b + c - 1;
        for (b = b; b < c; b++) a[b] = 128 | e & 127, e = d << 25 | e >>> 7, d >>>= 7;
        a[c] = e
    }

    function O(a, b, c, d) {
        c = b;
        b = d.length;
        for (var e = 0; e < b; e++) {
            var f = d.charCodeAt(e);
            if (f < 128) a[c++] = f;
            else if (f < 2048) a[c++] = 192 | f >> 6, a[c++] = 128 | f & 63;
            else if (f < 55296 || 57344 <= f) a[c++] = 224 | f >> 12, a[c++] = 128 | f >> 6 & 63, a[c++] = 128 | f & 63;
            else if (55296 <= f && f < 56320 && e + 1 !== b) {
                var g = d.charCodeAt(e + 1);
                if (56320 <= g && g < 57344) {
                    e++;
                    f = 65536 + ((f & 1023) << 10 | g & 1023);
                    a[c++] = 240 | f >> 18;
                    a[c++] = 128 | f >> 12 & 63;
                    a[c++] = 128 | f >> 6 & 63;
                    a[c++] = 128 | f & 63
                } else a[c++] = 239, a[c++] = 191, a[c++] = 189
            } else a[c++] = 239, a[c++] = 191, a[c++] = 189
        }
    }

    function P(a, b, c, e, f) {
        c = d("WAHex").hexLongIsNegative(e);
        e = d("WAHex").hexLongToHex(e);
        var g = 0,
            h = 0;
        for (var i = 0; i < 16; i++) g = g << 4 | h >>> 28, h = h << 4 | d("WAHex").hexAt(e, i);
        c && (g = ~g, h === 0 ? g++ : h = -h);
        a.setUint32(f ? b + 4 : b, g, f);
        a.setUint32(f ? b : b + 4, h, f)
    }

    function Q(a, b, c, d) {
        for (var e = 0; e < c; e++) a[b + e] = d[e]
    }

    function R(a, b) {
        var c;
        a ? (c = 5, a = a >>> 3) : (c = 1, a = b >>> 7);
        while (a) c++, a >>>= 7;
        return c
    }

    function S(a, b, d, e) {
        if (typeof a !== "number" || a !== a || Math.floor(a) !== a || a < b || a >= d) throw c("err")(typeof a === "string" ? 'TyperError WriteError: string "' + a + '" is not a valid ' + e : "TypeError WriteError: " + String(a) + " is not a valid " + e)
    }

    function T(a, b, d) {
        var e = o(a, b, d),
            f;
        b >= 0 ? f = b : f = a ? b : 4294967296 + b;
        a = d >= 0 ? d : 4294967296 + d;
        b = f * 4294967296 + a;
        if (!e) throw c("err")("ReadError: integer exceeded 53 bits (" + b + ")");
        return b
    }

    function U(a, b) {
        return T(!0, a, b)
    }

    function V(a, b) {
        return T(!1, a, b)
    }

    function W(a, b, c) {
        if (b >= c) return 0;
        c = a[b] | 0;
        return (c & 192) === 128 ? c : 0
    }
    g.Binary = a;
    g.numUtf8Bytes = n;
    g.longFitsInDouble = o;
    g.parseInt64OrThrow = U;
    g.parseUint64OrThrow = V
}), 98);
__d("WAHasProperty", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
    f["default"] = a
}), 66);
__d("WALongInt", ["WAHex", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is over 64 bits']);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is not a valid decimal string']);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " is not a safe integer"]);
        j = function() {
            return a
        };
        return a
    }

    function k(a) {
        if (typeof a !== "number") {
            d("WALogger").LOG(j(), a).color("red");
            throw new Error("numberOrThrowIfTooLarge is given a non-safe integer")
        }
        return a
    }
    f = function(a) {
        return a == null ? a : k(a)
    };

    function a(a) {
        return a == null || typeof a !== "number" ? null : a
    }

    function b(a, b) {
        if (typeof a === "number" && typeof b === "number") return a > b;
        a = typeof a === "number" ? d("WAHex").hexLongFromNumber(a) : a;
        b = typeof b === "number" ? d("WAHex").hexLongFromNumber(b) : b;
        return d("WAHex").isBiggerHexLong(a, b)
    }

    function c(a) {
        if (typeof a === "number") return a.toString(10);
        var b = d("WAHex").hexLongToHex(a),
            c = [0],
            e = 0;
        for (var f = 0; f < b.length; f++) {
            e = d("WAHex").hexAt(b, f);
            for (var g = 0; g < c.length; g++) c[g] = c[g] * 16 + e, e = c[g] / 10 | 0, c[g] %= 10;
            while (e > 0) c.push(e % 10), e = e / 10 | 0
        }
        g = c.reverse().join("");
        return d("WAHex").hexLongIsNegative(a) ? "-" + g : g
    }

    function e(a) {
        if (!/^-?\d+$/.test(a)) {
            d("WALogger").LOG(i(), a).color("red");
            throw new Error("decimalStringToLongInt is given an invalid decimal string")
        }
        var b = a[0] === "-",
            c = a.replace(/^-?0*/, ""),
            e = c.length;
        if (e < 16 || e === 16 && c <= "9007199254740991") return b ? -Number(c) : Number(c);
        if (e > 20 || e === 20 && c > "18446744073709551615" || b && (e > 19 || e === 19 && c > "9223372036854775807")) {
            d("WALogger").LOG(h(), a).color("red");
            throw new Error("decimalStringToHexLong is given value over 64 bits")
        }
        a = 0;
        var f = 0;
        for (var g = 0; g < e; g++) a = a * 10 + Number(c[g]), f = f * 10 + Math.floor(a / 4294967296), a = a % 4294967296;
        return d("WAHex").createHexLongFrom32Bits(f, a, b)
    }
    g.numberOrThrowIfTooLarge = k;
    g.maybeNumberOrThrowIfTooLarge = f;
    g.maybeNumber = a;
    g.isBiggerLongInt = b;
    g.longIntToDecimalString = c;
    g.decimalStringToLongInt = e
}), 98);
__d("WAPromiseCallSync", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a, c) {
        try {
            for (var d = arguments.length, e = new Array(d > 2 ? d - 2 : 0), f = 2; f < d; f++) e[f - 2] = arguments[f];
            return (g || (g = b("Promise"))).resolve(a.apply(c, e))
        } catch (a) {
            return (g || (g = b("Promise"))).reject(a)
        }
    }
    f.promiseCallSync = a
}), 66);
__d("WAPromiseManagement", ["WAPromiseCallSync"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = null,
            c = function() {
                b || (b = d("WAPromiseCallSync").promiseCallSync(a)["finally"](function() {
                    b = null
                }));
                return b
            };
        c.isPending = function() {
            return !!b
        };
        return c
    }

    function b(a, b) {
        var c = new Map();
        return function(d) {
            var e = a(d),
                f = c.get(e);
            if (f) return f;
            try {
                f = Promise.resolve(b(d))
            } catch (a) {
                f = Promise.reject(a)
            }
            d = f["finally"](function() {
                return void c["delete"](e)
            });
            c.set(e, d);
            return d
        }
    }
    var h = new Set();

    function c(a) {
        h.add(a), a["finally"](function() {
            h["delete"](a)
        })
    }
    g.nullaryCacheWhilePending = a;
    g.cacheWhilePending = b;
    g.preventGarbageCollection = c
}), 98);
__d("WAProtoCompile", ["WAProtoConst"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a, b, c, d, e, f, g, h, i) {
        this.names = a, this.fields = b, this.types = c, this.defaults = d, this.meta = e, this.oneofToFields = f, this.fieldToOneof = g, this.reservedTags = h ? h.reduce(function(a, b) {
            a[b] = !0;
            return a
        }, {}) : {}, this.reservedFields = i ? i.reduce(function(a, b) {
            a[b] = !0;
            return a
        }, {}) : {}
    };

    function a(a) {
        if (a.internalCompiledSpec) return a.internalCompiledSpec;
        var b = a.internalSpec;
        if (!b) throw new Error("Message Class " + String(a) + " does not have internalSpec");
        var c = a.internalDefaults || {},
            e = Object.keys(b).filter(function(a) {
                return a !== d("WAProtoConst").KEYS.ONEOF
            }),
            f = new Array(e.length),
            g = [],
            j = [],
            k = new Array(e.length),
            l = b[d("WAProtoConst").KEYS.ONEOF] || {};
        e.sort(function(a, c) {
            a = i(b, a);
            c = i(b, c);
            return a[0] - c[0]
        });
        for (var m = 0; m < e.length; m++) {
            var n = e[m],
                o = i(b, n);
            k[m] = c[n];
            var p = o[1],
                q = o[0];
            g.push(q);
            j.push(p);
            if ((p & d("WAProtoConst").TYPE_MASK) === d("WAProtoConst").TYPES.MESSAGE) f[m] = o[2];
            else if ((p & d("WAProtoConst").TYPE_MASK) === d("WAProtoConst").TYPES.ENUM) {
                q = o[2];
                if (typeof q.cast === "function") f[m] = q;
                else {
                    var r = !0,
                        s = 0;
                    for (var t in q) r && t !== s++ && (r = !1);
                    t = void 0;
                    if (r) {
                        t = [];
                        for (r = 0; r < s; r++) t.push(!0)
                    } else {
                        t = {};
                        for (r in q) t[q[r]] = !0
                    }
                    f[m] = t
                }
            } else if ((p & d("WAProtoConst").TYPE_MASK) === d("WAProtoConst").TYPES.MAP) {
                if (o.length !== 3) throw new Error("Map field " + n + " should have exactly three elements in its internalSpec");
                f[m] = o[2]
            } else f[m] = null
        }
        var u = {};
        s = function(a) {
            l[a].forEach(function(b) {
                u[b] || (u[b] = []), u[b].push(a)
            })
        };
        for (r in l) s(r);
        q = b[d("WAProtoConst").KEYS.RESERVED] && b[d("WAProtoConst").KEYS.RESERVED][d("WAProtoConst").KEYS.RESERVED_TAGS];
        t = b[d("WAProtoConst").KEYS.RESERVED] && b[d("WAProtoConst").KEYS.RESERVED][d("WAProtoConst").KEYS.RESERVED_FIELDS];
        p = new h(e, g, j, k, f, l, u, q, t);
        a.internalCompiledSpec = p;
        return p
    }

    function i(a, b) {
        a = a[b];
        if (a == null) throw new Error("fieldData of " + b + " is missing");
        return a
    }
    g.Spec = h;
    g.compileSpec = a
}), 98);
__d("WAProtoUtils", ["WAProtoConst"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a & d("WAProtoConst").FLAGS.PACKED) return d("WAProtoConst").ENC.BINARY;
        a = a & d("WAProtoConst").TYPE_MASK;
        if (a <= d("WAProtoConst").TYPES.ENUM) return d("WAProtoConst").ENC.VARINT;
        else if (a <= d("WAProtoConst").TYPES.DOUBLE) return d("WAProtoConst").ENC.BIT64;
        else if (a <= d("WAProtoConst").TYPES.MESSAGE) return d("WAProtoConst").ENC.BINARY;
        else if (a === d("WAProtoConst").TYPES.MAP) return d("WAProtoConst").ENC.BINARY;
        else return d("WAProtoConst").ENC.BIT32
    }
    g.typeToEncType = a
}), 98);
__d("WAProtoValidate", ["WAHasProperty", "WALogger", "WAProtoCompile", "WAProtoConst"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is not an array']);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is not ', ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is out of range']);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is not a valid int']);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is not a valid long']);
        l = function() {
            return a
        };
        return a
    }
    var m = Number.MAX_SAFE_INTEGER;

    function n(a, b) {
        a = o(a, b);
        if (a) {
            a.reverse();
            throw new TypeError("Message missing required value " + a.join("."))
        }
    }

    function a(a, b) {
        n(a, b);
        b = u(b, a);
        if (b) {
            b.path.reverse();
            throw new TypeError("Invalid value at " + b.path.join(".") + ": " + b.error)
        }
    }

    function o(a, b) {
        a = d("WAProtoCompile").compileSpec(a);
        var e = a.names,
            f = a.types;
        a = a.meta;
        var g = void 0;
        for (var h = 0; h < f.length && !g; h++) {
            var i = f[h],
                j = e[h],
                k = c("WAHasProperty")(b, j) ? b[j] : void 0;
            if (i & d("WAProtoConst").FLAGS.REQUIRED && k == null) g = [j];
            else if ((i & d("WAProtoConst").TYPE_MASK) === d("WAProtoConst").TYPES.MESSAGE && i & d("WAProtoConst").FLAGS.REPEATED && k != null) {
                var l = a[h],
                    m = void 0;
                for (m = 0; m < k.length && !g; m++) g = o(l, k[m]);
                g && g.push(j + "[" + m + "]")
            } else(i & d("WAProtoConst").TYPE_MASK) === d("WAProtoConst").TYPES.MESSAGE && k != null && (g = o(a[h], k), g && g.push(j))
        }
        return g
    }

    function p(a, b, c) {
        if (typeof a === "string")
            if (/^-?0x[0-9a-f]{16}$/i.test(a)) return !1;
            else {
                d("WALogger").LOG(l(), s(a)).color("red");
                return {
                    path: [],
                    error: "value must be a hex string of the form '0x123...' or '-0x123...' where the tail is always 16 characters long"
                }
            }
        else return q(a, b, c)
    }

    function q(a, b, c) {
        if (typeof a !== "number" || a !== a || Math.floor(a) !== a) {
            d("WALogger").LOG(k(), s(a)).color("red");
            return {
                path: [],
                error: "value must be an int"
            }
        } else if (a < b || a >= c) {
            d("WALogger").LOG(j(), s(a)).color("red");
            return {
                path: [],
                error: "value is out of range"
            }
        } else return !1
    }

    function r(a, b, c) {
        if (a) return void 0;
        else {
            d("WALogger").LOG(i(), s(c), b).color("red");
            return {
                path: [],
                error: "value is invalid"
            }
        }
    }

    function s(a) {
        if (typeof a === "string") return '"' + a + '"';
        else if (Array.isArray(a)) return "[" + a.join(", ") + "]";
        else return "" + a
    }
    var t = [void 0, function(a) {
        return q(a, -2147483648, 2147483648)
    }, function(a) {
        return p(a, -m, m + 1)
    }, function(a) {
        return q(a, 0, 4294967296)
    }, function(a) {
        return p(a, 0, m + 1)
    }, function(a) {
        return q(a, -2147483648, 2147483648)
    }, function(a) {
        return p(a, -m, m + 1)
    }, function(a) {
        return r(typeof a === "boolean", "boolean", a)
    }, function(a, b) {
        return r(typeof a === "number" && (b[a] || b.cast(a) !== void 0), "in enum", a)
    }, function(a) {
        return p(a, 0, m + 1)
    }, function(a) {
        return p(a, -m, m + 1)
    }, function(a) {
        return r(typeof a === "number", "number", a)
    }, function(a) {
        return r(typeof a === "string", "string", a)
    }, function(a) {
        return r(a instanceof ArrayBuffer || a instanceof Uint8Array, "ArrayBuffer or Uint8Array", a)
    }, u, function(a) {
        return q(a, 0, 4294967296)
    }, function(a) {
        return q(a, -2147483648, 2147483648)
    }, function(a) {
        return r(typeof a === "number", "number", a)
    }];

    function u(a, b) {
        b = d("WAProtoCompile").compileSpec(b);
        var c = b.names,
            e = b.fields,
            f = b.types,
            g = b.meta,
            i = b.oneofToFields,
            j = b.fieldToOneof,
            k = b.reservedTags,
            l = b.reservedFields,
            m = void 0;
        b = function(b) {
            var n = c[b],
                o = f[b],
                p = a[n],
                q = o & d("WAProtoConst").TYPE_MASK,
                r = t[q],
                u = (o & d("WAProtoConst").TYPE_MASK) === d("WAProtoConst").TYPES.MAP;
            if (r === void 0 && !u) throw new Error("Can not find the validator for type " + q);
            if (o & (d("WAProtoConst").FLAGS.PACKED | d("WAProtoConst").FLAGS.REPEATED) && p != null)
                if (!Array.isArray(p)) d("WALogger").LOG(h(), s(p)).color("red"), m = {
                    path: [n],
                    error: "repeated field must be array"
                };
                else {
                    q = g[b];
                    for (o = 0; o < p.length && !m; o++) m = r(p[o], q), m && m.path.push(n + "[" + o + "]")
                }
            else if (u && p != null) {
                o = g[b];
                q = o[0];
                u = o[1];
                o = typeof u === "object" ? d("WAProtoConst").TYPES.MESSAGE : u;
                var v = t[q],
                    w = t[o];
                if (v === void 0 || w === void 0) throw new Error("Can not find the validator for Map with key type " + q + ", value type " + o);
                for (var o = p, x = Array.isArray(o), y = 0, o = x ? o : o[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var z;
                    if (x) {
                        if (y >= o.length) break;
                        z = o[y++]
                    } else {
                        y = o.next();
                        if (y.done) break;
                        z = y.value
                    }
                    z = z;
                    var A = z[0];
                    z = z[1];
                    m = v(A, q);
                    if (m) {
                        m.path.push(n + "'s key [" + A + "]");
                        return {
                            v: m
                        }
                    }
                    m = w(z, u);
                    if (m) {
                        m.path.push(n + "[" + A + "]'s value");
                        return {
                            v: m
                        }
                    }
                }
            } else if (p != null) {
                m = r(p, g[b]);
                m && m.path.push(n);
                z = j[n];
                z && z.forEach(function(b) {
                    var c = i[b].filter(function(a) {
                        return a !== n
                    });
                    c.forEach(function(c) {
                        typeof a[c] !== "undefined" && (m = {
                            path: [b],
                            error: "oneof '" + b + "' has fields '" + n + "' and '" + c + "' set"
                        })
                    })
                });
                k[e[b]] && (m = {
                    path: [n],
                    error: "tag " + e[b] + " is reserved"
                });
                l[n] && (m = {
                    path: [n],
                    error: "field " + n + " is reserved"
                })
            }
        };
        for (var n = 0; n < c.length && !m; n++) {
            var o = b(n);
            if (typeof o === "object") return o.v
        }
        return m
    }
    g.checkRequirements = n;
    g.checkValid = a
}), 98);
__d("WAStanzaUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f.toStanzaId = a
}), 66);
__d("WAWasmModuleCache", ["WAPromiseManagement", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = a.fetch,
        i = new Map();
    c = d("WAPromiseManagement").cacheWhilePending(function(a) {
        return a
    }, function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = i.get(a);
            if (b != null) return b;
            b = (yield j(a));
            i.set(a, b);
            return b
        });
        return function(b) {
            return a.apply(this, arguments)
        }
    }());

    function j(a) {
        return k.apply(this, arguments)
    }

    function k() {
        k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            a = h(a);
            if (typeof WebAssembly.compileStreaming === "function") return WebAssembly.compileStreaming(a);
            a = (yield a);
            return WebAssembly.compile(yield a.arrayBuffer())
        });
        return k.apply(this, arguments)
    }
    g.loadWasmModule = c
}), 98);
__d("encodeProtobuf", ["WABinary", "WAHex", "WAProtoCompile", "WAProtoConst", "WAProtoUtils", "WAProtoValidate"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = void 0,
        i = 128;

    function a(a, b, c) {
        c === void 0 && (c = new(d("WABinary").Binary)());
        d("WAProtoValidate").checkValid(a, b);
        o(c, b, a);
        h = void 0;
        return c
    }

    function b() {
        return h !== void 0 ? "Last encoded value for " + h : "No information known"
    }

    function c(a, b) {
        a.writeVarInt(b)
    }

    function e(a, b) {
        if (typeof b === "number" && b < 4503599627370496 && b >= -4503599627370496) a.writeVarInt(b >= 0 ? 2 * b : 2 * -b - 1);
        else {
            var c = new(d("WABinary").Binary)(),
                e;
            typeof b === "number" ? (e = b < 0, c.writeVarInt(e ? -b : b)) : (e = d("WAHex").hexLongIsNegative(b), c.writeVarIntFromHexLong(e ? d("WAHex").negateHexLong(b) : b));
            b = c.peek(function() {
                return c.readByteArray()
            });
            var f = b.byteLength;
            if (e) {
                var g = 0,
                    h;
                do h = b[g], b[g] = h & i | (h & 127) - 1 & 127, g++; while (b[g - 1] === 255)
            }
            h = e ? 1 : 0;
            for (g = 0; g < f; g++) {
                e = b[g];
                var j = e & i | (e & 63) << 1 | h;
                h = (e & 64) >> 6;
                b[g] = j
            }
            h === 1 && (b[f - 1] |= i, c.writeInt8(1));
            a.writeBinary(c)
        }
    }

    function f(a, b) {
        typeof b === "number" ? a.writeVarInt(b) : a.writeVarIntFromHexLong(b)
    }

    function j(a, b) {
        a.writeVarInt(d("WABinary").numUtf8Bytes(b)), a.writeString(b)
    }

    function k(a, b) {
        a.writeVarInt(b.byteLength), a.writeBuffer(b)
    }

    function l(a, b, c) {
        a.writeWithVarIntLength(function(a, b) {
            return o(a, b, c)
        }, b)
    }
    var m = [void 0, c, f, c, f, e, e, function(a, b) {
        a.writeVarInt(b ? 1 : 0)
    }, c, function(a, b) {
        typeof b === "number" ? a.writeUint64(b, !0) : a.writeHexLong(b, !0)
    }, function(a, b) {
        typeof b === "number" ? a.writeInt64(b, !0) : a.writeHexLong(b, !0)
    }, function(a, b) {
        a.writeFloat64(b, !0)
    }, j, k, l, function(a, b) {
        a.writeUint32(b, !0)
    }, function(a, b) {
        a.writeInt32(b, !0)
    }, function(a, b) {
        a.writeFloat32(b, !0)
    }];
    f = function(a) {
        if (a == null) return void 0;
        var b = a;

        function c(a, c) {
            for (var d = 0; d < c.length; d++) b(a, c[d])
        }
        return function(a, b) {
            a.writeWithVarIntLength(c, b)
        }
    };
    var n = m.map(f);

    function o(a, b, c) {
        var e = d("WAProtoCompile").compileSpec(c),
            f = e.names,
            g = e.fields,
            i = e.types;
        e = e.meta;
        c = c.internalDefaults;
        for (var j = 0; j < f.length; j++) {
            var k = f[j],
                l = b[k];
            l == null && c && (l = c[k]);
            if (l != null) {
                h = k;
                k = g[j];
                var o = i[j],
                    p = o & d("WAProtoConst").TYPE_MASK,
                    q = e[j];
                k = k * 8 | d("WAProtoUtils").typeToEncType(o);
                if (o & d("WAProtoConst").FLAGS.PACKED) {
                    if (l.length > 0) {
                        a.writeVarInt(k);
                        var r = n[p];
                        r(a, l, q)
                    }
                } else if (o & d("WAProtoConst").FLAGS.REPEATED)
                    for (r = 0; r < l.length; r++) {
                        a.writeVarInt(k);
                        o = m[p];
                        o(a, l[r], q)
                    } else if (p === d("WAProtoConst").TYPES.MAP)
                        for (var o = l, r = Array.isArray(o), s = 0, o = r ? o : o[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                            var t;
                            if (r) {
                                if (s >= o.length) break;
                                t = o[s++]
                            } else {
                                s = o.next();
                                if (s.done) break;
                                t = s.value
                            }
                            t = t;
                            var u = t[0];
                            t = t[1];
                            a.writeVarInt(k);
                            var v = q[0],
                                w = q[1],
                                x = typeof w === "object" ? d("WAProtoConst").TYPES.MESSAGE : w,
                                y = m[v],
                                z = m[x];
                            if (y == null || z == null) throw new Error("Invalid encoder for map key/value");
                            var A = new(d("WABinary").Binary)(),
                                B = 1 * 8 | d("WAProtoUtils").typeToEncType(v);
                            A.writeVarInt(B);
                            y(A, u, v);
                            B = 2 * 8 | d("WAProtoUtils").typeToEncType(x);
                            A.writeVarInt(B);
                            z(A, t, w);
                            a.writeVarInt(A.size());
                            a.writeBinary(A)
                        } else {
                            a.writeVarInt(k);
                            y = m[p];
                            y(a, l, q)
                        }
            }
        }
    }
    g.encodeProtobuf = a;
    g.encodeErrorInfo = b
}), 98); /*FB_PKG_DELIM*/
__d("MAWDbGroupInviteTxns", ["MAWDexieTable", "MAWMsgType"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return a.groupInvites.put(b).then(function() {
            return b
        })
    }

    function b(a, b, c) {
        return a.groupInvites.where(["threadJid", "inviteeJid"]).anyOf([
            [b, c]
        ])["delete"]()
    }

    function h(a, b, c) {
        return a.groupInvites.where(["threadJid", "inviteeJid"]).equals([b, c]).first()
    }

    function c(a, b, c) {
        return a.groupInvites.where(["threadJid", "inviteeJid"]).anyOf([
            [b, c]
        ]).toArray()
    }

    function e(a, b) {
        return b.type === d("MAWMsgType").MSG_TYPE.GROUP_INVITE ? b.invitedParticipantUserJid == null ? d("MAWDexieTable").dexieResolve() : h(a, b.threadJid, b.invitedParticipantUserJid) : d("MAWDexieTable").dexieResolve()
    }
    g.putGroupInvite = a;
    g.deleteGroupInvitesByThreadAndInvitedParticipant = b;
    g.maybeGetGroupInvite = h;
    g.getGroupInvitesByThreadAndInvitedParticipant = c;
    g.getAndCheckGroupInviteFromMsg = e
}), 98);
__d("MAWDebugMsg", ["MAWBridgeMsg", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbThreadTxns", "MAWDexieTable", "MAWIndexedDb", "MAWLocalizationType", "MAWLocalizationUtils", "MAWMsgType", "MAWTransactionMode", "MAWTransactor", "WATimeUtils", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("MAWTransactor").makeMsgrTransactor({
        chunk: (a = d("MAWTransactionMode")).READONLY,
        groupInfo: a.READONLY,
        media: a.READONLY,
        messages: a.READWRITE,
        participants: a.READONLY,
        threads: a.READWRITE
    }, "writeDebugMsg", function(a) {
        return function(b, e, f) {
            return !c("gkx")("23958") ? d("MAWDexieTable").dexieResolve() : d("MAWDbThreadTxns").getThread(a, b).then(function(b) {
                if (!b.success) return;
                var c = b.value;
                return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").getThreadNewestMessageBySortOrder(a, c.jid), d("MAWDbMsgTxns").getThreadNewestMessageTs(a, c), (f == null ? void 0 : f.decryptionError) === "errDuplicateMsg" ? d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, f.protocolMsgId).then(function(a) {
                    if (a == null) return ", no existing message";
                    return a.type === d("MAWMsgType").MSG_TYPE.CIPHERTEXT ? ", existing ciphertext message" : ",  existing message"
                }) : d("MAWDexieTable").dexieResolve(""), d("MAWDbMsgTxns").getNextMsgIdNumberForThread(a, c)]).then(function(a) {
                    var b = a[0],
                        f = a[1],
                        g = a[2];
                    a = a[3];
                    a = d("MAWDbMsg").craftDebugMsgId(c.chatId, a - 1);
                    f = d("WATimeUtils").castToMillisTime(((b = (b = b == null ? void 0 : b.sortOrderMs) != null ? b : f) != null ? b : 0) + 1);
                    b = d("MAWLocalizationUtils").buildUnstoredDbAdminMsg({
                        adminMsgContent: ["[fb-only][DEBUG]: " + (e + g)],
                        adminType: d("MAWLocalizationType").LOCALIZATION_TYPE.DEBUG_MSG,
                        version: 0
                    }, c.jid);
                    d("MAWIndexedDb").afterTransaction({
                        tag: "NewMsg",
                        value: d("MAWBridgeMsg").createBridgeMsg(babelHelpers["extends"]({}, b, {
                            msgId: a,
                            sortOrderMs: f
                        }))
                    })
                })
            })
        }
    });
    g.writeDebugMsg = b
}), 98);
__d("MAWGetEditMsgForSending", ["MAWAckLevel", "MAWAsMessageApplication", "MAWDbEditMsgHistoryTxns", "MAWDbMsgTxns", "MAWDbThreadTxns", "MAWDexieTable", "MAWIndexedDb", "MAWJidUtils", "MAWTransactionMode", "WAJids", "WALogger", "WAResultOrError", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[SendEditMsg] Failed to get originalMsg"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[SendEditMsg] Failed to get thread (success:", ")"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[SendEditMsg] Failed to get originalMsgProtocolMsgId"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[SendEditMsg] Failed to get edit history"]);
        k = function() {
            return a
        };
        return a
    }
    b = d("MAWIndexedDb").makeMsgrTransactor({
        editMsgHistory: (a = d("MAWTransactionMode")).READONLY,
        messages: a.READONLY,
        participants: a.READONLY,
        reactions: a.READONLY,
        threads: a.READONLY
    }, "getEditMsgForSending", function(a) {
        return function(b, e) {
            return l(a, b, e).then(function(a) {
                if (!a.success) return {
                    type: a.error
                };
                a = a.value.msg;
                var e = d("MAWAsMessageApplication").asEditMessageApplication(a);
                if (d("WAJids").isAuthorSystem(a.author)) throw c("err")("This cannot happen because there are no system edit");
                return {
                    dbMsg: a,
                    editOriginalExternalId: a.originalMsgExternalId,
                    messageApplication: e,
                    messageType: {
                        isRevoked: !1,
                        type: "text"
                    },
                    protocolMsgId: b,
                    type: "unsent"
                }
            })
        }
    });

    function l(a, b, c) {
        return d("MAWDbEditMsgHistoryTxns").getEditHistoryMsgByEditedProtocolMsgId(a, b, c).then(function(b) {
            if (b == null) {
                d("WALogger").ERROR(k());
                return d("WAResultOrError").makeError("missing_history")
            } else if (b.sendStatus != null && b.sendStatus > d("MAWAckLevel").ACK.clock) return d("WAResultOrError").makeError("sent");
            var c = d("MAWJidUtils").maybeToProtocolMsgId(b.author, b.threadJid, b.originalMsgExternalId);
            if (c == null) {
                d("WALogger").ERROR(j());
                return d("WAResultOrError").makeError("missing_msg")
            }
            return d("MAWDexieTable").dexieAll([d("MAWDbThreadTxns").getThread(a, b.threadJid), d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, c)]).then(function(a) {
                var c = a[0];
                a = a[1];
                if (!c.success) {
                    d("WALogger").ERROR(i(), c.success);
                    return d("WAResultOrError").makeError("missing_thread")
                }
                if (a == null) {
                    d("WALogger").ERROR(h());
                    return d("WAResultOrError").makeError("missing_msg")
                }
                return a.ack > d("MAWAckLevel").ACK.clock ? d("WAResultOrError").makeError("sent") : d("WAResultOrError").makeResult({
                    msg: b,
                    thread: c.value
                })
            })
        })
    }
    g.getEditMsgForSending = b
}), 98);
__d("MAWMediaType", ["WAServerMediaType"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a) {
            case "XMA":
                return "xma-image";
            case "EphemeralScreenshotAction":
            case "Raven":
            case "RavenAction":
            case "EditAction":
            case "BumpExistingMessage":
                return null;
            default:
                return d("WAServerMediaType").getMediaType(a)
        }
    }
    g.getMediaType = a
}), 98);
__d("MAWSendMsgUtil", ["MAWMediaType", "WAMsgType"], (function(a, b, c, d, e, f, g) {
    "use strict";
    ({});

    function h(a) {
        var b = d("MAWMediaType").getMediaType(a),
            c = a === d("WAMsgType").MSG_TYPE.REVOKED;
        if (b != null) return {
            mediaType: b,
            type: "media"
        };
        else if (a === d("WAMsgType").MSG_TYPE.SK_DISTRIBUTION) return {
            isInvisible: !0,
            isRevoked: !1,
            type: "text"
        };
        else return {
            isRevoked: c,
            type: "text"
        }
    }

    function a(a) {
        var b = d("MAWMediaType").getMediaType(a);
        if (b != null) return {
            mediaType: b,
            type: "media"
        };
        switch (a) {
            case "XMA":
            case "Raven":
            case "RavenAction":
            case "EphemeralScreenshotAction":
            case "EditAction":
            case "BumpExistingMessage":
                return {
                    isRevoked: !1,
                    type: "text"
                };
            default:
                return h(a)
        }
    }
    g.waGetMessageTypeFromMsg = h;
    g.getMessageTypeFromMsg = a
}), 98);
__d("MAWGetMsgForSendingApi", ["MAWAckLevel", "MAWAsMessageApplication", "MAWDbGroupInviteTxns", "MAWDbMediaTxns", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbParticipantTxns", "MAWDbUnrenderedMsgTxns", "MAWDbXMATxns", "MAWDexieTable", "MAWIndexedDb", "MAWMsgType", "MAWSendMsgUtil", "MAWTransactionMode", "MAWXMAUtils", "WAJids", "WALogger", "WAResultOrError", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[SendMsg] Failed to get XMA: isXma: ", ", type: ", " "]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[SendMsg] Failed to get message"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg ", " -- MAWGetMsgForSendingAPI -- Done"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg ", " -- MAWGetMsgForSendingAPI -- Unrecognized type ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg ", " -- MAWGetMsgForSendingAPI -- Error: ", ""]);
        l = function() {
            return a
        };
        return a
    }
    b = d("MAWIndexedDb").makeMsgrTransactor({
        groupInvites: (a = d("MAWTransactionMode")).READONLY,
        media: a.READONLY,
        messages: a.READONLY,
        participants: a.READONLY,
        reactions: a.READONLY,
        threads: a.READONLY,
        unrenderedMessages: a.READONLY,
        xma: a.READONLY
    }, "getMsgForSending", function(a) {
        return function(b) {
            return m(a, b).then(function(a) {
                if (!a.success) {
                    d("WALogger").LOG(l(), b, a.error);
                    return {
                        type: a.error
                    }
                }
                a = a.value;
                var e = a.contactsInThread,
                    f = a.groupInvite,
                    g = a.isReplyMsg,
                    h = a.media,
                    i = a.msg;
                a = a.xmaPayload;
                if (!d("MAWDbMsg").NO_CONTENT_MESSAGE_TYPES_ALLOWLIST.includes(i.type) && !d("MAWDbMsg").isContentMsg(i)) {
                    d("WALogger").LOG(k(), b, i.type);
                    throw c("err")("We do not support message sending with " + i.type + " type")
                }
                var m = d("MAWAsMessageApplication").asMessageApplication(i, h, f, a),
                    n = null;
                i.type === d("MAWMsgType").MSG_TYPE.GROUP_INVITE && f ? n = {
                    invitedParticipantUserJid: f.inviteeJid,
                    isRevoked: !1,
                    type: "text"
                } : n = d("MAWSendMsgUtil").getMessageTypeFromMsg(i.type);
                if (d("WAJids").isAuthorSystem(i.author)) throw c("err")("A system message cannot be sent");
                d("WALogger").LOG(j(), b);
                return {
                    contactsInThread: e,
                    dbMsg: i,
                    isReplyMsg: g,
                    isXMAMsg: a != null,
                    media: h,
                    messageApplication: m,
                    messageType: n,
                    protocolMsgId: {
                        author: i.author,
                        chat: i.threadJid,
                        externalId: a != null && a.associatedMessage != null ? a.associatedMessage.externalId : i.externalId
                    },
                    type: "unsent",
                    xmaPayload: a
                }
            })
        }
    });

    function m(a, b) {
        return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, b), d("MAWDbUnrenderedMsgTxns").maybeGetUnrenderedMsgByProtocolMsgId(a, b)]).then(function(c) {
            var e = c[0];
            c = c[1];
            var f = c.value,
                g = e || f;
            if (g == null) {
                d("WALogger").ERROR(i());
                return d("WAResultOrError").makeError("missing_msg")
            } else if (g.ack > d("MAWAckLevel").ACK.clock) return d("WAResultOrError").makeError("sent");
            var j = d("MAWXMAUtils").maybeXMAMessage(e),
                k = g.quote != null;
            return d("MAWDexieTable").dexieAll([e ? d("MAWDbMediaTxns").getAndCheckMediaFromMsg(a, e) : d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeResult()), c.success ? d("MAWDbGroupInviteTxns").getAndCheckGroupInviteFromMsg(a, c.value) : d("MAWDexieTable").dexieResolve(), j ? d("MAWDbXMATxns").maybeGetXMAPayloadFromProtocolMsgId(a, b) : null, d("MAWDbParticipantTxns").getParticipantsInThread(a, g.threadJid).then(function(a) {
                return a.map(function(a) {
                    return a.userJid
                })
            })]).then(function(a) {
                var b = a[0],
                    c = a[1],
                    e = a[2];
                a = a[3];
                if (!b.success) return b;
                if (e != null && !e.success) {
                    d("WALogger").ERROR(h(), j, g.type);
                    return d("WAResultOrError").makeError("missing_xma")
                }
                b = b.value;
                return d("WAResultOrError").makeResult({
                    contactsInThread: a,
                    groupInvite: c,
                    isReplyMsg: k,
                    media: b,
                    msg: g,
                    xmaPayload: e != null ? e.value : null
                })
            })
        })
    }
    g.getMsgForSending = b
}), 98);
__d("MAWGetReactionForSending", ["MAWAckLevel", "MAWAsMessageApplication", "MAWDbReactionsTxns", "MAWDbThreadTxns", "MAWIndexedDb", "MAWTransactionMode", "WAJids", "WAResultOrError", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        return d("MAWDbReactionsTxns").getReaction(a, b).then(function(b) {
            if (b == null) return d("WAResultOrError").makeError("missing");
            else if (b.ack > d("MAWAckLevel").ACK.clock) return d("WAResultOrError").makeError("sent");
            return d("MAWDbThreadTxns").getThread(a, b.threadJid).then(function(a) {
                return !a.success ? d("WAResultOrError").makeError(a.error) : d("WAResultOrError").makeResult({
                    msg: b
                })
            })
        })
    }
    a = d("MAWIndexedDb").makeMsgrTransactor({
        reactions: d("MAWTransactionMode").READONLY,
        threads: d("MAWTransactionMode").READONLY
    }, "getReactionForSending", function(a) {
        return function(b) {
            return h(a, b).then(function(a) {
                if (!a.success) return {
                    type: a.error
                };
                a = a.value.msg;
                var b = d("MAWAsMessageApplication").asReactionMessageApplication(a);
                if (d("WAJids").isAuthorSystem(a.author)) throw c("err")("This cannot happen because there are no system reactions");
                return {
                    chat: a.threadJid,
                    dbMsg: a,
                    externalId: a.externalId,
                    messageApplication: b,
                    messageType: {
                        isInvisible: !0,
                        type: "reaction"
                    },
                    protocolMsgId: {
                        author: a.author,
                        chat: a.threadJid,
                        externalId: a.externalId
                    },
                    type: "unsent"
                }
            })
        }
    });
    g.getReactionForSending = a
}), 98);
__d("MAWLoadThreadParticipantsApi", ["MAWDbParticipantTxns", "MAWIndexedDb", "MAWTransactionMode", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["MAWLoadThreadParticipantsApi -- loadThreadParticipants -- there is no thread in db"]);
        h = function() {
            return a
        };
        return a
    }
    a = d("MAWIndexedDb").makeMsgrTransactor({
        participants: d("MAWTransactionMode").READONLY,
        threads: d("MAWTransactionMode").READONLY
    }, "loadThreadParticipants", function(a) {
        return function(b) {
            return a.threads.get({
                jid: b
            }).then(function(b) {
                if (b == null) {
                    d("WALogger").ERROR(h());
                    return []
                }
                return d("MAWDbParticipantTxns").getParticipantsInThread(a, b.jid).then(function(a) {
                    return a.map(function(a) {
                        return a.userJid
                    })
                })
            })
        }
    });
    g.loadThreadParticipants = a
}), 98);
__d("MAWMarkEditMsgDroppedApi", ["FBLogger", "MAWAckLevel", "MAWBridgeMsg", "MAWBridgeTypesCreators", "MAWDbEditMsgHistoryTxns", "MAWDbMsgTxns", "MAWDexieTable", "MAWIndexedDb", "MAWJidUtils", "MAWThreadSnippetForTextMsg", "MAWThreadUpdateMiddlewareGKUtil", "MAWTransactionMode", "WAGlobals", "WAJids", "WALogger", "WAMsgType", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] editMsgHistory updated"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] originalMsg is not a text message"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] thread is null"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] newestEditedMsg is not the newest edit"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] previousEditedMsg is null"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] newestEditedMsg is null"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] originalMsg is null"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgDropped] originalProtocolMsgId is null"]);
        o = function() {
            return a
        };
        return a
    }
    a = d("MAWIndexedDb").makeMsgrTransactor({
        editMsgHistory: d("MAWTransactionMode").READWRITE,
        messages: d("MAWTransactionMode").READWRITE,
        threads: d("MAWTransactionMode").READWRITE
    }, "markEditMsgDropped", function(a) {
        return function(b, e) {
            var f = d("MAWJidUtils").maybeToProtocolMsgId(b.author, b.chat, e);
            if (f == null) {
                d("WALogger").ERROR(o());
                return d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeError("missing_original_protocol_msg_id"))
            }
            return d("MAWDexieTable").dexieAll([a.threads.get({
                jid: b.chat
            }), d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, f), d("MAWDbEditMsgHistoryTxns").maybeGetEditMsgHistoryFromProtocolMsgId(a, f)]).then(function(f) {
                var g = f[0],
                    o = f[1],
                    p = f[2];
                f = p.sort(function(a, b) {
                    return b.editTs - a.editTs
                });
                var q = p.find(function(a) {
                        return a.editExternalId === b.externalId
                    }),
                    r = f[1];
                if (o == null) {
                    d("WALogger").ERROR(n());
                    return d("WAResultOrError").makeError("missing_original_msg")
                }
                if (q == null) {
                    d("WALogger").ERROR(m());
                    return d("WAResultOrError").makeError("missing_newest_edited_msg")
                }
                if (r == null) {
                    d("WALogger").ERROR(l());
                    return d("WAResultOrError").makeError("missing_previous_edited_msg")
                }
                if (q.editExternalId !== f[0].editExternalId) {
                    d("WALogger").ERROR(k());
                    return d("WAResultOrError").makeError("invalid_newest_edited_msg")
                }
                if (g == null) {
                    d("WALogger").ERROR(j());
                    return d("WAResultOrError").makeError("missing_thread")
                }
                if (o.type !== d("WAMsgType").MSG_TYPE.TEXT) {
                    d("WALogger").ERROR(i());
                    return d("WAResultOrError").makeError("invalid_original_msg")
                }
                return d("MAWDexieTable").dexieAll([a.messages.where("quoteExternalId").equals(e).toArray(), d("MAWDbMsgTxns").getThreadNewestMessageId(a, g.jid)]).then(function(e) {
                    var f = e[0],
                        i = e[1],
                        j = babelHelpers["extends"]({}, o, {
                            ack: d("MAWAckLevel").ACK.sent,
                            editCount: ((e = o.editCount) != null ? e : 0) - 1,
                            msgContent: r.msgContent
                        }),
                        k = d("WAGlobals").getMyUserJid(),
                        l = [];
                    e = f.find(function(a) {
                        var c;
                        return (((c = a.quote) == null ? void 0 : c.content.author) === d("WAJids").AUTHOR_ME || ((c = a.quote) == null ? void 0 : c.content.author) === k) && a.threadJid === b.chat
                    });
                    if (e != null) {
                        f = e.quote;
                        var m = e.quoteExternalId;
                        if (f == null) c("FBLogger")("messenger_e2ee_web").warn("[markEditMsgDropped] Failed to get the quoted content for a msg that has been quoted.", m);
                        else {
                            m = babelHelpers["extends"]({}, e, {
                                quote: babelHelpers["extends"]({}, f, {
                                    content: babelHelpers["extends"]({}, f.content, {
                                        msgContent: babelHelpers["extends"]({}, j.msgContent)
                                    })
                                })
                            });
                            l.push(m)
                        }
                    }
                    e = [];
                    o.editCount === 1 && p.length === 2 && e.push(r.editMsgHistoryId);
                    e.push(q.editMsgHistoryId);
                    return d("MAWDexieTable").dexieAll([a.messages.put(j), a.editMsgHistory.bulkDelete(e)]).then(function() {
                        d("WALogger").LOG(h());
                        d("MAWIndexedDb").afterTransaction({
                            tag: "MsgUpdated",
                            value: d("MAWBridgeMsg").createBridgeMsg(j)
                        });
                        l.forEach(function(a) {
                            d("MAWIndexedDb").afterTransaction({
                                tag: "MsgUpdated",
                                value: d("MAWBridgeMsg").createBridgeMsg(a)
                            })
                        });
                        if (i === o.msgId && !d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(j.type)) {
                            var a = d("WAJids").userIdFromJid(d("WAGlobals").getMyUserJid()),
                                b = c("MAWThreadSnippetForTextMsg")(j, a, d("WAJids").interpretAsGroupJid(g.jid) != null),
                                e = b.snippetParams;
                            b = b.snippetType;
                            d("MAWIndexedDb").afterTransaction({
                                tag: "ThreadUpdated",
                                value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                                    snippetParams: e,
                                    snippetSenderContactId: a,
                                    snippetType: b,
                                    threadJid: g.jid
                                })
                            })
                        }
                        return d("WAResultOrError").makeResult()
                    })
                })
            })
        }
    });
    g.markEditMsgDropped = a
}), 98);
__d("MAWMarkEditMsgSentApi", ["ArmadilloDataTraceType", "MAWAckLevel", "MAWBridgeMsg", "MAWBridgeTrace", "MAWBridgeTraceEvent", "MAWDbEditMsgHistory", "MAWDbEditMsgHistoryTxns", "MAWDbMsgTxns", "MAWDexieTable", "MAWFTSTxns", "MAWIndexedDb", "MAWJidUtils", "MAWLoadReplyMediaTxns", "MAWTransactionMode", "WAJids", "WALogger", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgSent] editMsgHistory updated"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgSent] on incoming message"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgSent] editMsgHistory has already been sent"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgSent] editedMsg?.editExternalId is null"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgSent] originalMsgHistory is null"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgSent] originalMsg is null"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[markEditMsgSent] originalProtocolMsgId is null"]);
        n = function() {
            return a
        };
        return a
    }
    b = d("MAWIndexedDb").makeMsgrTransactor({
        chunk: (a = d("MAWTransactionMode")).READONLY,
        editMsgHistory: a.READWRITE,
        ftsBackloggedMessages: a.READWRITE,
        media: a.READONLY,
        messages: a.READWRITE,
        receiverFetchInfo: a.READONLY,
        xma: a.READONLY
    }, "markMsgSent", function(a) {
        return function(b, e, f, g) {
            var o = d("MAWJidUtils").maybeToProtocolMsgId(b.author, b.chat, e);
            if (o == null) {
                d("WALogger").ERROR(n());
                return d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeError("missing_original_protocol_msg_id"))
            }
            return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, o), d("MAWDbEditMsgHistoryTxns").maybeGetEditMsgHistoryFromProtocolMsgId(a, o), d("MAWFTSTxns").maybePutMessageToBacklog(a, e)]).then(function(n) {
                var o = n[0];
                n = n[1];
                var p = n.find(function(a) {
                        return a.editExternalId === e
                    }),
                    q = n.find(function(a) {
                        return a.editExternalId === b.externalId
                    });
                if (o == null) {
                    d("WALogger").ERROR(m());
                    return d("WAResultOrError").makeError("missing_original_msg")
                }
                if (p == null) {
                    d("WALogger").ERROR(l());
                    return d("WAResultOrError").makeError("missing_original_msg_edit_history")
                }
                if ((q == null ? void 0 : q.editExternalId) == null) {
                    d("WALogger").ERROR(k());
                    return d("WAResultOrError").makeError("missing_edit_external_id")
                }
                if (q.sendStatus != null && q.sendStatus > d("MAWAckLevel").ACK.clock && o.ack > d("MAWAckLevel").ACK.clock) {
                    d("WALogger").LOG(j());
                    return d("WAResultOrError").makeError("already_sent")
                }
                if (q.author !== d("WAJids").AUTHOR_ME) {
                    d("WALogger").ERROR(i());
                    return d("WAResultOrError").makeError("not_author")
                }
                d("MAWIndexedDb").afterTransaction({
                    tag: "UpdateTrace",
                    value: d("MAWBridgeTrace").createBridgeUpdateTraceData([q.editExternalId], c("MAWBridgeTraceEvent").ReceivedSent, d("ArmadilloDataTraceType").armadilloMessageSend)
                });
                var r = [];
                if (n.length === 2 && o.editCount === 1) {
                    n = babelHelpers["extends"]({}, p, {
                        sendStatus: d("MAWAckLevel").ACK.sent
                    });
                    r.push(n)
                }
                p = babelHelpers["extends"]({}, q, {
                    editTs: f,
                    sendStatus: d("MAWAckLevel").ACK.sent
                });
                r.push(p);
                var s = r.map(function(a) {
                        return babelHelpers["extends"]({}, a, {
                            editMsgHistoryId: d("MAWDbEditMsgHistory").convertToEditMsgHistoryId64(a.editMsgHistoryId),
                            originalMsgId: o.msgId
                        })
                    }),
                    t = babelHelpers["extends"]({}, o, {
                        ack: d("MAWAckLevel").ACK.sent
                    });
                g != null && (t.reportingMeta = g);
                return d("MAWDexieTable").dexieAll([a.editMsgHistory.bulkPut(r), a.messages.put(t), d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, t)]).then(function(a) {
                    a[0];
                    a = a[2];
                    d("WALogger").LOG(h());
                    d("MAWIndexedDb").afterTransaction({
                        tag: "MsgUpdated",
                        value: d("MAWBridgeMsg").createBridgeMsg(t, void 0, a)
                    });
                    d("MAWIndexedDb").afterTransaction({
                        tag: "EditMsgHistoryAdded",
                        value: s
                    });
                    return d("WAResultOrError").makeResult()
                })
            })
        }
    });
    g.markEditMsgSent = b
}), 98);
__d("MAWMarkMsgDroppedApi", ["MAWAckLevel", "MAWDbMsgTxns", "MAWDbReactionsTxns", "MAWDexieTable", "MAWIndexedDb", "MAWTransactionMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("MAWIndexedDb").makeMsgrTransactor({
        chunk: (a = d("MAWTransactionMode")).READONLY,
        media: a.READONLY,
        messages: a.READWRITE,
        reactions: a.READWRITE,
        receiverFetchInfo: a.READONLY,
        threads: a.READWRITE,
        xma: a.READONLY
    }, "markMsgDropped", function(a) {
        return function(b, c) {
            c === void 0 && (c = !1);
            return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, b), d("MAWDbReactionsTxns").maybeGetReactionByProtocolMsgId(a, b)]).then(function(b) {
                var e = b[0];
                b = b[1];
                if (e != null) {
                    var f = c ? d("MAWAckLevel").ACK.failedRetryable : d("MAWAckLevel").ACK.expired;
                    return d("MAWDbMsgTxns").updateSystemAck(a, e.msgId, f).then(function(a) {
                        return a == null ? "missing" : a.ack <= d("MAWAckLevel").ACK.clock ? "dropped" : "sent"
                    })
                }
                return b != null ? d("MAWDbReactionsTxns").deleteReaction(a, b).then(function() {
                    return "dropped"
                }) : "missing"
            })
        }
    });
    g.markMsgDropped = b
}), 98);
__d("MAWMarkMsgSentApi", ["ArmadilloDataTraceType", "I64", "MAWAckLevel", "MAWBridgeTrace", "MAWBridgeTraceEvent", "MAWBridgeTypesCreators", "MAWCalculateBumpTimestampMs", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbThread", "MAWDbThreadTxns", "MAWDbUnrenderedMsgTxns", "MAWDexieTable", "MAWEphemeralMsgTxns", "MAWEphemeralSettingsTxns", "MAWFolderTypes", "MAWIndexedDb", "MAWMsgType", "MAWThreadNewestMsgOrReactionUtils", "MAWThreadSnippetBuildTxns", "MAWThreadUpdateMiddlewareGKUtil", "MAWTransactionMode", "MAWUpdateThreadBumpTimestamp", "WALogger", "WATimeUtils", "emptyFunction", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Thread missing from DB"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Found both regular and unrendered message with the same protocol msg ID"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Msg missing from DB"]);
        k = function() {
            return a
        };
        return a
    }
    b = d("MAWIndexedDb").makeMsgrTransactor({
        chunk: (a = d("MAWTransactionMode")).READONLY,
        ephemeralSettings: a.READWRITE,
        groupInfo: a.READONLY,
        media: a.READONLY,
        messages: a.READWRITE,
        reactions: a.READONLY,
        receiverFetchInfo: a.READONLY,
        threads: a.READWRITE,
        unrenderedMessages: a.READWRITE,
        xma: a.READONLY
    }, "markMsgSent", function(a) {
        return function(b, e, f, g) {
            return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, b), d("MAWDbUnrenderedMsgTxns").maybeGetUnrenderedMsgByProtocolMsgId(a, b)]).then(function(m) {
                var n = m[0];
                m = m[1];
                if (n == null && !m.success) {
                    d("WALogger").LOG(k());
                    return
                } else if (n != null) {
                    d("MAWIndexedDb").afterTransaction({
                        tag: "UpdateTrace",
                        value: d("MAWBridgeTrace").createBridgeUpdateTraceData([n.externalId], c("MAWBridgeTraceEvent").ReceivedSent, d("ArmadilloDataTraceType").armadilloMessageSend)
                    });
                    m.success && d("WALogger").ERROR(j());
                    var o = n.ack < d("MAWAckLevel").ACK.sent;
                    return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").updateSystemAck(a, n.msgId, d("MAWAckLevel").ACK.sent, e, f, g), d("MAWDbThreadTxns").getThread(a, n.threadJid)]).then(function(b) {
                        var c = b[0];
                        b = b[1];
                        if (!b.success) {
                            d("WALogger").ERROR(i());
                            return
                        }
                        var f = b.value,
                            g = d("WATimeUtils").castUnixTimeToMillisTime(e);
                        b = babelHelpers["extends"]({}, f, {
                            lastReadMsgTs: g,
                            newestMsgTs: g,
                            threadOrder: d("MAWDbThread").craftThreadOrder(g, f.jid)
                        });
                        b = o ? d("MAWDbThreadTxns").updateThread(a, b) : d("MAWDexieTable").dexieResolve();
                        return d("MAWDexieTable").dexieAll([l(a, f), d("MAWEphemeralMsgTxns").markEphemeralMessageAsSent(a, c), b]).then(function() {
                            if (n.altIndex !== d("MAWDbMsg").SPAM_ALT_INDEX && n.altIndex !== d("MAWDbMsg").FUTUREPROOF_SPAM_ALT_INDEX && !d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(n.type) && o) return d("MAWThreadSnippetBuildTxns").buildThreadSnippet(a, n).then(function(a) {
                                var b = a.snippetParams,
                                    c = a.snippetSenderContactId;
                                a = a.snippetType;
                                if (n.type === d("MAWMsgType").MSG_TYPE.REVOKED) d("MAWIndexedDb").afterTransaction({
                                    tag: "ThreadUpdated",
                                    value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                                        snippetParams: b,
                                        snippetSenderContactId: c,
                                        snippetType: a,
                                        threadJid: f.jid
                                    })
                                });
                                else if (!d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(n.type)) {
                                    var e = n.externalId !== void 0 ? (h || (h = d("I64"))).of_string_opt(n.externalId) : void 0;
                                    e = d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMs(g, e);
                                    d("MAWIndexedDb").afterTransaction({
                                        tag: "ThreadBumpedV2",
                                        value: d("MAWBridgeTypesCreators").createBridgeBumpedThreadV2({
                                            bumpTimestampMs: e,
                                            description: "markMsgSent",
                                            isMessageAuthorMe: !0,
                                            snippetData: {
                                                params: b,
                                                senderContactId: c,
                                                type: a
                                            },
                                            threadJid: f.jid
                                        })
                                    })
                                }
                            })
                        })
                    })
                } else if (m.success) {
                    var p = m.value;
                    return d("MAWDbUnrenderedMsgTxns").updateSystemAckForUnrenderedMsg(a, p.msgId, d("MAWAckLevel").ACK.sent).then(function() {
                        if (p.type === d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE) return d("MAWEphemeralSettingsTxns").updateContactWhenEphemeralSettingChangeMarkedSent(a, b.chat, e)
                    })
                }
            }).then(c("emptyFunction"))
        }
    });

    function l(a, b) {
        return !c("gkx")("7818") ? d("MAWDexieTable").dexieResolve() : d("MAWThreadNewestMsgOrReactionUtils").getNewestMsgOrReactionForBump(a, b.jid).then(function(a) {
            d("MAWIndexedDb").afterTransaction({
                tag: "CreateE2EEMetadataThread",
                value: {
                    bumpTimestampMs: d("MAWUpdateThreadBumpTimestamp").getBumpTimestampMs(a),
                    creationSource: "outgoing_message",
                    folderId: (a = b.folder) != null ? a : d("MAWFolderTypes").INBOX,
                    jid: b.jid,
                    mawThreadKeys: {
                        authoritative: b.authoritativeThreadKey,
                        optimistic: b.optimisticThreadKey
                    }
                }
            })
        })
    }
    g.markMsgSent = b
}), 98);
__d("MAWMessageSendScheduler", ["WorkerScheduler"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        h == null && (h = d("WorkerScheduler").makeScheduler("message-send", {
            concurrency: 5,
            maxConcurrency: 5,
            maxThrottleMs: 500
        }));
        return h
    }
    g.messageSendScheduler = a
}), 98);
__d("MAWMessageSendsCommon", ["MAWMarkMsgDroppedApi", "MAWMessageSendScheduler", "MAWQplProxy", "Promise", "WAGetSafeQPLError", "WAPersistedJobManager", "WAResultOrError", "WATagsLogger", "WATimeUtils", "WAWaitForComms", "WorkerScheduler", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Guard: should not happen, result is null"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Message send fails: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Guard: Non constanct backoff detected: ", ""]);
        k = function() {
            return a
        };
        return a
    }
    var l = d("WATagsLogger").TAGS(["MessageSend"]),
        m = 1e3;

    function n(a, b, c, d, e) {
        return o.apply(this, arguments)
    }

    function o() {
        o = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c, e, f, g) {
            d("MAWQplProxy").sendQplPointThroughBridge(a, "backend_reached", {
                annotations: {
                    bool: {
                        backendSetupReadyFromWorker: !d("WAWaitForComms").isStillWaitingForComms()
                    }
                },
                instanceKey: c
            });
            var o;
            try {
                d("MAWQplProxy").sendQplPointThroughBridge(a, "wait_for_comms_start", {
                    annotations: {},
                    instanceKey: c
                }), yield d("WAWaitForComms").waitForComms(), d("MAWQplProxy").sendQplPointThroughBridge(a, "wait_for_comms_end", {
                    annotations: {},
                    instanceKey: c
                }), d("MAWQplProxy").sendQplPointThroughBridge(a, "message_send_start", {
                    annotations: {},
                    instanceKey: c
                }), o = (yield d("MAWMessageSendScheduler").messageSendScheduler().runTask({
                    customFlags: {
                        runtimeReliability: !0
                    },
                    fn: function() {
                        return e(d("WATimeUtils").unixTime())
                    },
                    name: f,
                    priority: d("WorkerScheduler").BLOCKING_PRIORITY
                })), o.success === !0 ? d("MAWQplProxy").sendQplPointThroughBridge(a, "message_send_end", {
                    annotations: {},
                    instanceKey: c
                }) : d("MAWQplProxy").sendQplPointThroughBridge(a, "message_send_fail", {
                    annotations: {
                        string: {
                            errorType: o.error.type
                        }
                    },
                    instanceKey: c
                })
            } catch (b) {
                if (b instanceof d("WAPersistedJobManager").RetryOnBackoff) {
                    var p;
                    b.backoffOptions.algo.type !== "constant" && l.ERROR(k(), b.backoffOptions.algo.type);
                    o = d("WAResultOrError").makeError({
                        backoff: (p = b.backoffOptions.algo.delay) != null ? p : m,
                        type: "retryable-error"
                    });
                    d("MAWQplProxy").sendQplPointThroughBridge(a, "message_send_fail", {
                        annotations: {
                            string: {
                                errorType: "retryable-error"
                            }
                        },
                        instanceKey: c
                    })
                } else {
                    l.ERROR(j(), b);
                    d("MAWQplProxy").sendQplPointThroughBridge(a, "message_send_fail", {
                        annotations: {
                            string: {
                                errorType: "runtime-error",
                                jsError: d("WAGetSafeQPLError").getSafeQPLErrorMessage(b)
                            }
                        },
                        instanceKey: c
                    });
                    g != null && (yield d("MAWMarkMsgDroppedApi").markMsgDropped(g));
                    throw b
                }
            }
            if (!o) {
                l.ERROR(i());
                return d("WAResultOrError").makeError({
                    type: "unknown-error"
                })
            }
            if (o.success === !0) return o;
            o.success;
            if (g != null) {
                p = o.error.type === "retryable-error";
                yield d("MAWMarkMsgDroppedApi").markMsgDropped(g, p)
            }
            if (o.error.type === "retryable-error") {
                var q = o.error.backoff;
                yield new(h || (h = b("Promise")))(function(a) {
                    var b;
                    setTimeout(function() {
                        a()
                    }, (b = q) != null ? b : m)
                });
                return n(a, c, e, f, g)
            } else return o
        });
        return o.apply(this, arguments)
    }
    g.messageSendLogger = l;
    g.messageSendObserver = n
}), 98);
__d("WAQPLProxy", ["WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAQPLProxy: Proxy implementation is not provided for ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAQPLProxy: Proxy implementation is not provided for ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function a(a, b, e, f, g) {
        g === void 0 && (g = !0);
        if (j == null) {
            d("WALogger").ERROR(i(), a);
            throw c("err")("WAQPLProxy: Proxy implementation is not provided")
        }
        return j.start(a, b, e, f, g)
    }

    function b(a, b) {
        if (j == null) {
            d("WALogger").ERROR(h(), a);
            throw c("err")("WAQPLProxy: Proxy implementation is not provided")
        }
        return j.resume(a, b)
    }
    var j = null;

    function e(a) {
        j = a
    }
    g.waQPLProxyStart = a;
    g.waQPLProxyStartResume = b;
    g.provideProxyImplementationForWAQPLProxy = e
}), 98);
__d("MAWSendWrittenMsg", ["EBAPI", "FBLogger", "I64", "MAWBridge", "MAWDebugMsg", "MAWGetEditMsgForSending", "MAWGetMsgForSendingApi", "MAWGetReactionForSending", "MAWJobManager", "MAWLoadThreadParticipantsApi", "MAWMarkEditMsgDroppedApi", "MAWMarkEditMsgSentApi", "MAWMarkMsgDroppedApi", "MAWMarkMsgSentApi", "MAWMessageSendsCommon", "WAAPI", "WAAsMessageApplication", "WAFrankingTypes", "WAGlobals", "WAJids", "WAMsgApplication.pb", "WAPREList", "WAPREMetrics", "WAPersistedJobManager", "WAQPLProxy", "WAResultOrError", "asyncToGeneratorRuntime", "encodeProtobuf", "err", "gkx", "promiseDone", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg END ", " : ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg not sending message: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg(", "): drop result: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg(", "): too old, dropping"]);
        m = function() {
            return a
        };
        return a
    }
    a = 24 * 60 * 60;

    function n(a, b, c) {
        return o.apply(this, arguments)
    }

    function o() {
        o = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e) {
            var f;
            d("MAWMessageSendsCommon").messageSendLogger.LOG(k(), a.protocolMsgId);
            var g = null;
            b == null ? void 0 : b.addPoint("get_msg_for_sending_start", {
                string: {
                    type: a.type
                }
            });
            e == null ? void 0 : e.addPoint("get_msg_for_sending", {
                string: {
                    type: a.type
                }
            });
            if (a.type === "message" || a.type === "revoke") g = (yield d("MAWGetMsgForSendingApi").getMsgForSending(a.protocolMsgId));
            else if (a.type === "reaction") g = (yield d("MAWGetReactionForSending").getReactionForSending(a.protocolMsgId));
            else if (a.type === "edit") g = (yield d("MAWGetEditMsgForSending").getEditMsgForSending(a.protocolMsgId, a.referencedOriginalExternalId));
            else {
                a.type;
                throw c("err")("This cannot happen because type has `message` as default argument but flow does not know that")
            }
            if (g.type !== "unsent") {
                d("MAWMessageSendsCommon").messageSendLogger.LOG(j(), g.type);
                e == null ? void 0 : e.endFail(g.type);
                return d("WAResultOrError").makeError({
                    type: "unknown-error"
                })
            }
            a = g;
            g = a.dbMsg;
            var l = a.editOriginalExternalId,
                m = a.isReplyMsg,
                n = a.isXMAMsg,
                o = a.media,
                p = a.messageApplication,
                q = a.messageType,
                r = a.protocolMsgId;
            a = a.xmaPayload;
            b == null ? void 0 : b.addPoint("get_msg_for_sending_end", {
                bool: {
                    isEditMsg: l != null,
                    isReplyMsg: m,
                    isXMAMsg: n
                },
                string: {
                    msgType: q.type
                }
            });
            e == null ? void 0 : e.addPoint("message-fetched-from-db", {
                bool: {
                    isEditMsg: l != null,
                    isReplyMsg: m,
                    isXMAMsg: n
                },
                string: {
                    msgType: q.type
                }
            });
            m = {
                bytes: d("WAAsMessageApplication").castToMessageApplicationBytes(d("encodeProtobuf").encodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, p).readByteArray()),
                version: "v3"
            };
            b == null ? void 0 : b.addPoint("wa_send_msg_start");
            q = (yield c("WAAPI").sendChatMessage({
                loadThreadParticipants: d("MAWLoadThreadParticipantsApi").loadThreadParticipants,
                messagePayload: {
                    frankingKey: ((f = p.metadata) == null ? void 0 : f.frankingKey) ? d("WAFrankingTypes").castToFrankingKey(new Uint8Array((f = p.metadata) == null ? void 0 : f.frankingKey)) : null,
                    frankingVersion: (f = p.metadata) == null ? void 0 : f.frankingVersion,
                    messageBytes: m,
                    messageType: q,
                    protocolMsgId: r
                }
            }, (f = b) != null ? f : e));
            if (q.success === !1) {
                b == null ? void 0 : b.addPoint("wa_send_msg_fail", {
                    string: {
                        errorType: q.error.type,
                        msgType: g.type
                    }
                });
                e == null ? void 0 : e.addPoint("send-msg-v2-failed", {
                    string: {
                        errorType: q.error.type,
                        msgType: g.type
                    }
                });
                e == null ? void 0 : e.endFail(q.error.type);
                if (l != null) yield d("MAWMarkEditMsgDroppedApi").markEditMsgDropped(r, l);
                else {
                    f = q.error.type === "retryable-error";
                    yield d("MAWMarkMsgDroppedApi").markMsgDropped(r, f)
                }
                d("MAWMessageSendsCommon").messageSendLogger.ERROR(i(), q.error.type, (f = q.payload) != null ? f : "");
                switch (q.error.type) {
                    case "non-retryable-error":
                        f = c("gkx")("794");
                        if (f && q.error.applicationErrorCode != null && q.error.applicationErrorCode === 10009) try {
                            d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
                                events: [{
                                    tag: "RefreshContact",
                                    value: (h || (h = d("I64"))).of_string(d("WAJids").threadIdForChatJid(g.threadJid))
                                }]
                            })
                        } catch (a) {
                            c("FBLogger")("labyrinth_web").catching(a).mustfix("Failed to call bridge handler RefreshContact for JID %s and mediaType %s", g.threadJid, g.type)
                        }
                        throw new(d("WAPersistedJobManager").NonRetryableError)();
                    case "retryable-error":
                        if (q.error.backoff != null) throw new(d("WAPersistedJobManager").RetryOnBackoff)({
                            algo: {
                                delay: q.error.backoff,
                                type: "constant"
                            }
                        });
                        throw c("err")("sendWrittenMsg error");
                    default:
                        throw c("err")("sendWrittenMsg error")
                }
            }
            q.success;
            b == null ? void 0 : b.addPoint("wa_send_msg_end");
            ((f = q.value.meta) == null ? void 0 : f.pOrDhashMismatch) && (b == null ? void 0 : b.addPoint("dhash_phash_mismatch"), c("promiseDone")(d("MAWDebugMsg").writeDebugMsg(r.chat, "Outgoing msg " + r.externalId + " got a phash mismatch")));
            b == null ? void 0 : b.addPoint("mark_edit_msg_sent_start");
            l != null ? yield d("MAWMarkEditMsgSentApi").markEditMsgSent(r, l, q.value.serverTs, q.value.reportingMeta).then(function() {
                e == null ? void 0 : e.addPoint("mark_edit_msg_sent")
            }): yield d("MAWMarkMsgSentApi").markMsgSent(r, q.value.serverTs, q.value.reportingMeta, e).then(function() {
                e == null ? void 0 : e.addPoint("mark_msg_sent")
            });
            b == null ? void 0 : b.addPoint("mark_edit_msg_sent_end");
            b == null ? void 0 : b.addPoint("eb_upload_scheduling_start");
            yield c("EBAPI").uploadSentMessage({
                dbMsg: g,
                instanceKey: r.externalId,
                isXMAMsg: n,
                media: o,
                messageApplication: p,
                messageApplicationBytes: m.bytes,
                protocolMsgId: r,
                serverTs: q.value.serverTs,
                xmaPayload: a
            });
            b == null ? void 0 : b.addPoint("eb_upload_scheduling_end");
            return q
        });
        return o.apply(this, arguments)
    }

    function p(a, b, c) {
        return q.apply(this, arguments)
    }

    function q() {
        q = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e) {
            var f = b.qplEventType;
            b = b.qplInstanceKey;
            var g, h;
            c("gkx")("7854") && b != null ? (g = d("WAQPLProxy").waQPLProxyStartResume(f, b), g.addAnnotations({
                bool: {
                    is_secure: !0
                },
                string: {
                    description: e,
                    jid: a.protocolMsgId.chat
                }
            })) : (h = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.SEND_MESSAGE, {
                bool: {
                    isSenderKeyPredistriubtionEnabled: d("WAGlobals").getConfig().isSenderKeyPredistributionEnabled()
                },
                string: {
                    jid: a.protocolMsgId.chat
                }
            }, b), h.addAnnotations({
                bool: {
                    is_secure: !0
                },
                string: {
                    description: e
                }
            }));
            return n(a, g, h)
        });
        return q.apply(this, arguments)
    }
    e = d("MAWJobManager").getPersistedJobsApi().definePersistedJob().finalStep("encryptAndSend", {
        code: function(a) {
            var b = a.s2sInstanceKey;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["s2sInstanceKey"]);
            return p(a, {
                qplEventType: c("qpl")._(25313175, "1551"),
                qplInstanceKey: b
            }, "sendWrittenMsg")
        },
        stopRetryIf: {
            onStopRetry: function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    a = a.protocolMsgId;
                    d("MAWMessageSendsCommon").messageSendLogger.LOG(m(), a);
                    var b = (yield d("MAWMarkMsgDroppedApi").markMsgDropped(a));
                    d("MAWMessageSendsCommon").messageSendLogger.LOG(l(), a, b);
                    return d("WAResultOrError").makeError({
                        type: "too-many-retries"
                    })
                });

                function c(b) {
                    return a.apply(this, arguments)
                }
                return c
            }(),
            timePassedSeconds: a
        }
    }).end();
    g.sendWrittenMsgExternal = p;
    g.sendWrittenMsg = e
}), 98);
__d("MAWSendReactionMsg", ["MAWBridge", "MAWIndexedDb", "MAWJobDefinitions", "MAWJobManager", "MAWMessageSendScheduler", "MAWMessageSendsCommon", "MAWSendWrittenMsg", "MAWTransactionMode", "MAWWriteReactionMsgApi", "WAAPI", "WAJids", "WALongInt", "WAResultOrError", "WATimeUtils", "WorkerScheduler", "asyncToGeneratorRuntime", "gkx", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendReactionMsg cannot react to a non-existent message"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendReactionMsg cannot send to a non-existent thread"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendReactionMsg already sent message"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendReactionMsg: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l(a) {
        return a === "\u2764\ufe0f" ? "\u2764" : a
    }

    function m(a, b, c, d) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e, f) {
            var g = a.args,
                m = a.chatJid;
            a = a.externalId;
            d("MAWMessageSendsCommon").messageSendLogger.DEV(k(), m);
            var n = g.reaction,
                q = g.reactToProtocolMsgId;
            n = l(n);
            var r = d("WAJids").toMsgrUserJid(g.reactToAuthor),
                s = (yield p(q.externalId));
            s = (yield o(s));
            yield c("WAAPI").getDevicesBeforeSend({
                chatJid: m,
                reason: "sendReactionMsg"
            });
            n = (yield d("MAWWriteReactionMsgApi").writeReactionMsg(a, m, {
                groupingKey: n,
                reaction: n,
                reactToAuthor: r,
                reactToExternalId: q.externalId,
                senderTimestampMs: s
            }, b));
            if (n.type === "already_sent") {
                d("MAWMessageSendsCommon").messageSendLogger.LOG(j());
                return d("WAResultOrError").makeError({
                    type: "already-sent"
                })
            } else if (n.type === "missing_thread") {
                d("MAWMessageSendsCommon").messageSendLogger.LOG(i());
                return d("WAResultOrError").makeError({
                    type: "missing-thread"
                })
            } else if (n.type === "missing_msg") {
                d("MAWMessageSendsCommon").messageSendLogger.LOG(h());
                return d("WAResultOrError").makeError({
                    type: "missing-referenced-msg"
                })
            }
            if (c("gkx")("1861")) {
                r = (yield d("MAWSendWrittenMsg").sendWrittenMsgExternal({
                    protocolMsgId: n.protocolMsgId,
                    type: "reaction"
                }, {
                    qplEventType: e,
                    qplInstanceKey: f
                }, "MAWSendReactionMsg"));
                if (r.success === !1)
                    if (c("gkx")("7854")) return d("WAResultOrError").makeError(r.error);
                    else {
                        d("MAWBridge").getBridge().fireAndForget("event", "handleMessageSendResult", {
                            success: !1
                        }, !0);
                        return d("WAResultOrError").makeError(r.error)
                    }
                else {
                    q = {
                        chatJid: m,
                        externalId: a,
                        messageType: "reactionMsg",
                        reaction: g.reaction,
                        source: g.source
                    };
                    if (c("gkx")("7854")) return d("WAResultOrError").makeResult(q);
                    else {
                        d("MAWBridge").getBridge().fireAndForget("event", "handleMessageSendResult", {
                            report: q,
                            success: !0
                        }, !0);
                        return d("WAResultOrError").makeResult(q)
                    }
                }
            } else {
                yield d("MAWJobManager").getJobManager().waitUntilPersisted(d("MAWJobDefinitions").createStartJobInfo("sendWrittenMsg", {
                    protocolMsgId: n.protocolMsgId,
                    s2sInstanceKey: f,
                    type: "reaction"
                }));
                return d("WAResultOrError").makeResult()
            }
        });
        return n.apply(this, arguments)
    }

    function a(a) {
        var b = a.args,
            c = a.chatJid,
            e = a.externalId,
            f = a.qplEventType,
            g = a.qplInstanceKey;
        return d("MAWMessageSendsCommon").messageSendObserver(f, g, function(a) {
            return m({
                args: b,
                chatJid: c,
                externalId: e
            }, a, f, g)
        }, "reaction", {
            author: d("WAJids").AUTHOR_ME,
            chat: c,
            externalId: e
        })
    }
    e = d("MAWJobManager").getPersistedJobsApi().definePersistedJob().finalStep("saveAndPassOff", function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f) {
            if (c("gkx")("5801")) yield d("MAWMessageSendScheduler").messageSendScheduler().runTask({
                customFlags: {
                    runtimeReliability: !0
                },
                fn: function() {
                    var d = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                        var e = a.args,
                            b = babelHelpers.objectWithoutPropertiesLoose(a, ["args"]),
                            d = e.s2sInstanceKey;
                        e = babelHelpers.objectWithoutPropertiesLoose(e, ["s2sInstanceKey"]);
                        yield m(babelHelpers["extends"]({
                            args: e
                        }, b), f.jobStartTime, c("qpl")._(25313175, "1551"), d)
                    });

                    function e() {
                        return d.apply(this, arguments)
                    }
                    return e
                }(),
                name: "reaction",
                priority: d("WorkerScheduler").BLOCKING_PRIORITY
            });
            else {
                e = a.args;
                var g = babelHelpers.objectWithoutPropertiesLoose(a, ["args"]),
                    h = e.s2sInstanceKey;
                e = babelHelpers.objectWithoutPropertiesLoose(e, ["s2sInstanceKey"]);
                yield m(babelHelpers["extends"]({
                    args: e
                }, g), f.jobStartTime, c("qpl")._(25313175, "1551"), h)
            }
        });
        return function(b, c, d) {
            return a.apply(this, arguments)
        }
    }()).end();

    function o(a) {
        a = a.map(function(a) {
            return d("WALongInt").maybeNumberOrThrowIfTooLarge(a.senderTimestampMs)
        }).filter(Boolean).reduce(function(a, b) {
            return Math.max(a, b)
        }, 0);
        return Math.max(((a = a) != null ? a : 0) + 1, d("WATimeUtils").unixTimeMs())
    }
    var p = d("MAWIndexedDb").makeMsgrTransactor({
        reactions: d("MAWTransactionMode").READONLY
    }, "findMatchingReactionBeforeSendReactionMsg", function(a) {
        return function(b) {
            return a.reactions.where("reactToExternalId").equals(b).toArray()
        }
    });
    g.sanitizeReaction = l;
    g.sendReactionMsgFn = a;
    g.sendReactionMsg = e;
    g.calculateSenderTimestampMs = o
}), 98); /*FB_PKG_DELIM*/
__d("BDHeaderConfig", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = "129477";
    f.ASBD_ID = a
}), 66);
__d("OdsWebBatchFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1838142");
    b = d("FalcoLoggerInternal").create("ods_web_batch", a);
    e = b;
    g["default"] = e
}), 98);
__d("FalcoConsentChecker", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, b, c, d) {
        var e;
        switch (typeof d) {
            case "string":
                e = a[String(d)];
                return !e ? !1 : e <= b;
            case "number":
                return g(a, b, c, c[Number(d)]);
            default:
                e = !1;
                if (Array.isArray(d)) {
                    var f = d[0];
                    for (var h = 1; h < d.length; h++) {
                        e = g(a, b, c, d[h]);
                        if (e) {
                            if (f === "or") return !0
                        } else if (f === "and") return !1
                    }
                }
                return e
        }
    }
    f["default"] = g
}), 66);
__d("pageID", ["WebSession"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WebSession").getPageId_DO_NOT_USE();
    g["default"] = a
}), 98);
__d("WebStorageMutex", ["WebStorage", "clearTimeout", "pageID", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = null,
        j = !1,
        k = c("pageID");

    function l() {
        j || (j = !0, i = (h || (h = c("WebStorage"))).getLocalStorage());
        return i
    }
    a = function() {
        function a(a) {
            this.name = a
        }
        a.testSetPageID = function(a) {
            k = a
        };
        var b = a.prototype;
        b.$2 = function() {
            var a, b = l();
            if (!b) return k;
            b = b.getItem("mutex_" + this.name);
            b = ((a = b) != null ? a : "").split(":");
            return b && parseInt(b[1], 10) >= Date.now() ? b[0] : null
        };
        b.$3 = function(a) {
            var b = l();
            if (!b) return;
            a = a == null ? 1e3 : a;
            a = Date.now() + a;
            (h || (h = c("WebStorage"))).setItemGuarded(b, "mutex_" + this.name, k + ":" + a)
        };
        b.hasLock = function() {
            return this.$2() === k
        };
        b.lock = function(a, b, d) {
            var e = this;
            this.$1 && c("clearTimeout")(this.$1);
            k === (this.$2() || k) && this.$3(d);
            this.$1 = c("setTimeout")(function() {
                e.$1 = null;
                var c = e.hasLock() ? a : b;
                c && c(e)
            }, 0)
        };
        b.unlock = function() {
            this.$1 && c("clearTimeout")(this.$1);
            var a = l();
            a && this.hasLock() && a.removeItem("mutex_" + this.name)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("guid", [], (function(a, b, c, d, e, f) {
    function a() {
        if (typeof crypto === "object" && typeof crypto.getRandomValues === "function" && typeof String.prototype.padStart === "function") {
            var a = crypto.getRandomValues(new Uint32Array(2));
            return "f" + a[0].toString(16).padStart(8, "0") + a[1].toString(16).padStart(8, "0")
        }
        return "f" + (Math.random() * (1 << 30)).toString(16).replace(".", "")
    }
    f["default"] = a
}), 66);
__d("PersistedQueue", ["AnalyticsCoreData", "BaseEventEmitter", "ExecutionEnvironment", "Run", "WebStorage", "WebStorageMutex", "cr:8958", "err", "guid", "nullthrows", "performanceAbsoluteNow", "requestAnimationFrame"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = 24 * 60 * 60 * 1e3,
        m = 30 * 1e3,
        n = new(c("BaseEventEmitter"))(),
        o;

    function p(a) {
        a === void 0 && (a = !1);
        if (o === void 0) {
            var b;
            if (((b = (h || (h = c("AnalyticsCoreData"))).queue_activation_experiment) != null ? b : !1) && a) try {
                return (i || (i = c("WebStorage"))).getLocalStorageForRead()
            } catch (a) {
                return null
            }
            b = "check_quota";
            try {
                a = (i || (i = c("WebStorage"))).getLocalStorage();
                a ? (a.setItem(b, b), a.removeItem(b), o = a) : o = null
            } catch (a) {
                o = null
            }
        }
        return o
    }

    function q(a) {
        var b = a.prev,
            c = a.next;
        c && (c.prev = b);
        b && (b.next = c);
        a.next = null;
        a.prev = null
    }

    function r(a) {
        return {
            item: a,
            next: null,
            prev: null
        }
    }

    function s(a, b) {
        return a + "^$" + ((a = b == null ? void 0 : b.queueNameSuffix) != null ? a : "")
    }
    var t = {},
        u = {},
        v = {},
        w = !1;
    a = function() {
        function a(a, b) {
            var d, e = this;
            this.$7 = 0;
            this.$3 = a;
            this.$5 = (d = b == null ? void 0 : b.queueNameSuffix) != null ? d : "";
            this.$15 = b == null ? void 0 : b.application;
            this.$4 = s(a, b);
            this.$11 = this.$4 + "^$" + c("guid")();
            this.$14 = !1;
            if (b) {
                this.$8 = (d = b.max_age_in_ms) != null ? d : l;
                this.$12 = b.migrate;
                this.$13 = b.onLoad
            } else this.$8 = l;
            this.$9 = [n.addListener("active", function() {
                (e.$10 != null || !e.$14) && (e.$14 = !0, e.$10 = null, e.$16())
            }), n.addListener("inactive", function() {
                e.$10 == null && (e.$10 = Date.now(), e.$17())
            })];
            ((j || (j = c("ExecutionEnvironment"))).canUseDOM || (j || (j = c("ExecutionEnvironment"))).isInWorker) && c("requestAnimationFrame")(function() {
                return e.$16()
            })
        }
        var d = a.prototype;
        d.isActive = function() {
            var a = this.$10;
            if (a == null) return !0;
            if (Date.now() - a > m) {
                this.$10 = null;
                n.emit("active", null);
                return !0
            }
            return !1
        };
        d.$16 = function() {
            this.$18(), this.$19()
        };
        d.$17 = function() {
            this.$20()
        };
        d.getFullName = function() {
            return this.$4
        };
        d.getQueueNameSuffix = function() {
            return this.$5
        };
        a.isQueueActivateExperiment = function() {
            return w
        };
        a.setOnQueueActivateExperiment = function() {
            w = !0
        };
        a.create = function(b, d) {
            var e = s(b, d);
            if (e in t) throw c("err")("Duplicate queue created: " + b);
            d = new a(b, d);
            t[e] = d;
            v[b] ? v[b].push(d) : v[b] = [d];
            e = u[b];
            e && d.setHandler(e);
            return d
        };
        a.setHandler = function(a, b) {
            if (v[a]) {
                var c = v[a];
                for (var c = c, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= c.length) break;
                        f = c[e++]
                    } else {
                        e = c.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    f.setHandler(b)
                }
            }
            u[a] = b
        };
        d.destroy = function() {
            this.$9.forEach(function(a) {
                return a.remove()
            })
        };
        a.destroy = function(a, b) {
            a = s(a, b);
            t[a].destroy();
            delete t[a]
        };
        d.setHandler = function(a) {
            this.$6 = a;
            this.$19();
            return this
        };
        d.$19 = function() {
            this.$7 > 0 && this.$6 && this.$6(this)
        };
        d.length = function() {
            return this.$7
        };
        d.enumeratedLength = function() {
            return this.$21().length
        };
        a.isPersistenceAllowed = function() {
            var a = p();
            return !a ? !1 : !0
        };
        a.getSuffixesForKey = function(a) {
            var b = [];
            try {
                var c = p(!0);
                if (!c) return b;
                a = a + "^$";
                for (var d = 0; d < c.length; d++) {
                    var e = c.key(d);
                    if (typeof e === "string" && e.startsWith("mutex_falco_")) c.removeItem(e);
                    else if (typeof e === "string" && e.startsWith(a)) {
                        e = e.split("^$");
                        if (e.length > 2) {
                            e = e[1];
                            b.push(e)
                        } else b.push("")
                    }
                }
            } catch (a) {}
            return b
        };
        d.$18 = function() {
            var d, e = this,
                a = p(!0);
            if (!a) return;
            var f = this.$4 + "^$";
            d = new(c("WebStorageMutex"))((d = this.$15) != null ? d : f);
            var g = this.$12,
                h = this.$13;
            d.lock(function(d) {
                var i = Date.now() - e.$8;
                try {
                    for (var j = 0; j < a.length; j++) {
                        var k = a.key(j);
                        if (typeof k === "string" && k.startsWith(f)) {
                            var l = a.getItem(k);
                            a.removeItem(k);
                            if (l != null && l.startsWith("{")) {
                                k = b("cr:8958").parse(c("nullthrows")(l));
                                if (k.ts > i) try {
                                    for (var l = k.items, k = Array.isArray(l), m = 0, l = k ? l : l[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                        var n;
                                        if (k) {
                                            if (m >= l.length) break;
                                            n = l[m++]
                                        } else {
                                            m = l.next();
                                            if (m.done) break;
                                            n = m.value
                                        }
                                        n = n;
                                        g != null ? g(n) : n;
                                        n = h != null ? h(n) : n;
                                        e.$22(n)
                                    }
                                } catch (a) {}
                            }
                        }
                    }
                } catch (a) {}
                d.unlock();
                e.$19()
            })
        };
        d.$20 = function() {
            var a = p();
            if (!a) return;
            var d = this.$21();
            if (d.length === 0) {
                a.getItem(this.$11) != null && a.removeItem(this.$11);
                return
            }(i || (i = c("WebStorage"))).setItemGuarded(a, this.$11, b("cr:8958").stringify({
                items: d.map(function(a) {
                    return a
                }),
                ts: (k || (k = c("performanceAbsoluteNow")))()
            }))
        };
        d.$21 = function() {
            var a = this.$1,
                b = [];
            if (!a) return b;
            do b.push(a.item); while (a = a.prev);
            return b.reverse()
        };
        d.markItemAsCompleted = function(a) {
            var b = a.prev;
            q(a);
            this.$1 === a && (this.$1 = b);
            this.$7--;
            this.isActive() || this.$20()
        };
        d.markItemAsFailed = function(a) {
            q(a);
            var b = this.$2;
            if (b) {
                var c = b.prev;
                c && (c.next = a, a.prev = c);
                a.next = b;
                b.prev = a
            }
            this.$2 = a;
            this.isActive() && this.$19()
        };
        d.markItem = function(a, b) {
            b ? this.markItemAsCompleted(a) : this.markItemAsFailed(a)
        };
        d.$22 = function(a) {
            a = r(a);
            var b = this.$1;
            b && (b.next = a, a.prev = b);
            this.$1 = a;
            this.$2 || (this.$2 = a);
            this.$7++
        };
        d.wrapAndEnqueueItem = function(a) {
            this.$22(a), this.isActive() ? this.$19() : this.$20()
        };
        d.dequeueItem = function() {
            if (this.$10 != null) return null;
            var a = this.$2;
            if (!a) return null;
            this.$2 = a.next;
            return a
        };
        return a
    }();
    a.eventEmitter = n;
    if ((j || (j = c("ExecutionEnvironment"))).canUseDOM) {
        var x = d("Run").maybeOnBeforeUnload(function() {
            n.emit("inactive", null), x == null ? void 0 : x.remove()
        }, !1);
        if (!x) var y = d("Run").onUnload(function() {
            n.emit("inactive", null), y.remove()
        })
    }
    g["default"] = a
}), 98);
__d("ServerTime", ["ServerTimeData"], (function(a, b, c, d, e, f, g) {
    var h, i = 0;
    f = 0;
    var j = null;
    h = (h = (typeof window !== "undefined" ? window : self).performance) == null ? void 0 : h.timing;
    if (h) {
        var k = h.requestStart;
        h = h.domLoading;
        if (k && h) {
            var l = c("ServerTimeData").timeOfResponseStart - c("ServerTimeData").timeOfRequestStart;
            k = h - k - l;
            f = k / 2;
            l = h - c("ServerTimeData").timeOfResponseStart - f;
            h = Math.max(50, k * .8);
            Math.abs(l) > h && (i = l, j = Date.now())
        }
    } else d(c("ServerTimeData").serverTime);

    function a() {
        return Date.now() - i
    }

    function b() {
        return i
    }

    function d(a) {
        a = Date.now() - a;
        Math.abs(i - a) > 6e4 && (i = a, j = Date.now())
    }

    function e() {
        return j === null ? null : Date.now() - j
    }
    f = a;
    k = b;
    g.getMillis = a;
    g.getOffsetMillis = b;
    g.update = d;
    g.getMillisSinceLastUpdate = e;
    g.get = f;
    g.getSkew = k
}), 98);
__d("FalcoLoggerInternal", ["AnalyticsCoreData", "BaseEventEmitter", "FBLogger", "FalcoConsentChecker", "FalcoUtils", "PersistedQueue", "Promise", "Random", "ServerTime", "WebSession", "nullthrows", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = (f = d("FalcoUtils")).getTaggedBitmap(33),
        l = f.getTaggedBitmap(0),
        m = f.getTaggedBitmap(37),
        n = 500 * 1024 * .6,
        o = new Map();

    function p(a) {
        var b;
        a.tags = d("FalcoUtils").xorBitmap((b = a.tags) != null ? b : [0, 0], k);
        return a
    }

    function a(a, b) {
        var d;
        d = (d = c("PersistedQueue").getSuffixesForKey(a)) != null ? d : [];
        d.push(b);
        for (var d = d, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g, h;
            if (e) {
                if (f >= d.length) break;
                h = d[f++]
            } else {
                f = d.next();
                if (f.done) break;
                h = f.value
            }
            h = h;
            var j = a + "^$" + h;
            if (o.has(j)) continue;
            g = ((g = (i || (i = c("AnalyticsCoreData"))).use_falco_as_mutex_key) != null ? g : !1) ? c("PersistedQueue").create(a, {
                onLoad: p,
                queueNameSuffix: h,
                application: "falco"
            }) : c("PersistedQueue").create(a, {
                onLoad: p,
                queueNameSuffix: h
            });
            o.set(j, g)
        }
        return c("nullthrows")(o.get(a + "^$" + b))
    }
    f = f.identityToString((i || (i = c("AnalyticsCoreData"))).identity);
    var q = a("falco_queue_log", f),
        r = a("falco_queue_immediately", f),
        s = a("falco_queue_critical", f),
        t = new(c("BaseEventEmitter"))(),
        u = {};

    function v(a, b, e) {
        var f = c("Random").coinflip(b.r);
        if (!f) {
            d("FalcoUtils").bumpODSMetrics(e, "event.filters.sampling", 1);
            return !1
        }
        f = b.c;
        if (f != null && (i || (i = c("AnalyticsCoreData"))).consents != null) {
            b = w(f, (i || (i = c("AnalyticsCoreData"))).consents, a);
            if (!b) {
                d("FalcoUtils").bumpODSMetrics(e, "event.filters.consent", 1);
                return !1
            }
        }
        return !0
    }

    function w(a, b, d) {
        var e = u[a];
        e == null && (e = u[a] = JSON.parse(a));
        return c("FalcoConsentChecker")(b, d, e, e[0])
    }

    function x() {
        return (j || (j = c("performanceAbsoluteNow")))() - d("ServerTime").getOffsetMillis()
    }

    function y(a, b, d, e, f, g) {
        if ((i || (i = c("AnalyticsCoreData"))).enable_observer) {
            a = babelHelpers["extends"]({
                name: a,
                time: b,
                sampled: d,
                getData: f,
                policy: e
            }, g && {
                getPrivacyContext: g
            });
            t.emit("event", a)
        }
    }

    function z(a, b, e, f, g, h) {
        var j;
        g = JSON.stringify(g);
        if (g.length > n) {
            d("FalcoUtils").bumpODSMetrics(a, "event.filters.exceeded_size", 1);
            c("FBLogger")("falco", "oversized_message:" + a).warn('Dropping event "%s" due to exceeding the max size %s at %s', a, n, g.length);
            return
        }
        var k = d("FalcoUtils").xorBitmap([0, 0], l);
        k = d("FalcoUtils").xorBitmap(k, m);
        ((j = (i || (i = c("AnalyticsCoreData"))).enable_session_id_bug_fix) != null ? j : !1) ? h.wrapAndEnqueueItem({
            name: a,
            policy: b,
            time: e,
            extra: g,
            privacyContext: f,
            tags: k,
            sessionId: d("WebSession").getId(),
            deviceId: (i || (i = c("AnalyticsCoreData"))).device_id
        }): (h.wrapAndEnqueueItem({
            name: a,
            policy: b,
            time: e,
            extra: g,
            privacyContext: f,
            tags: k
        }), d("FalcoUtils").bumpODSMetrics(a, "event.captured", 1))
    }

    function A(a, b, c, e, f) {
        try {
            var g = x();
            d("FalcoUtils").bumpODSMetrics(a, "event.logged", 1);
            var h = v(g, b, a);
            if (h) {
                var i = e(),
                    j = c && c();
                z(a, b, g, j, i, f)
            }
            y(a, g, h, b, e, c)
        } catch (a) {
            C(a)
        }
    }

    function B(a, c, e, f, g) {
        try {
            var i = x();
            d("FalcoUtils").bumpODSMetrics(a, "event.logged", 1);
            var j = v(i, c, a);
            if (j) {
                var k = f(),
                    l = (h || (h = b("Promise"))).resolve(e && e());
                return h.all([k, l]).then(function(b) {
                    var d = b[0],
                        e = b[1];
                    z(a, c, i, e, d, g);
                    y(a, i, j, c, function() {
                        return d
                    }, e && function() {
                        return e
                    })
                })
            } else {
                y(a, i, j, c, f, e);
                return (h || (h = b("Promise"))).resolve()
            }
        } catch (a) {
            return (h || (h = b("Promise"))).reject(a)
        }
    }

    function C(a) {
        var b = c("FBLogger")("falco");
        a instanceof Error ? b.catching(a).warn("Error while attempting to log to Falco") : b.warn("Caught non-error while attempting to log to Falco: %s", JSON.stringify(a))
    }

    function e(a, b) {
        return {
            log: function(c, d) {
                A(a, b, d, c, q)
            },
            logAsync: function(c, d) {
                B(a, b, d, c, q)["catch"](C)
            },
            logImmediately: function(c, d) {
                A(a, b, d, c, r)
            },
            logCritical: function(c, d) {
                A(a, b, d, c, s)
            },
            logRealtimeEvent: function(c, d) {
                A(a, b, d, c, s)
            }
        }
    }
    g.observable = t;
    g.create = e
}), 98);
__d("FalcoUtils", ["AnalyticsCoreData", "ODS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = "ods_web_batch";

    function a(a) {
        if (a) {
            var b = a.fbIdentity,
                c = a.appScopedIdentity;
            a = a.claim;
            var d = "";
            if (b) {
                var e = b.accountId;
                b = b.actorId;
                d = e + "^#" + b + "^#"
            } else c !== void 0 && (d = "^#^#" + c);
            return d + "^#" + a
        }
        return ""
    }

    function b(a) {
        return a > 30 ? [0, 1 << a - 30] : [1 << a, 0]
    }

    function e(a, b) {
        return [a[0] | b[0], a[1] | b[1]]
    }

    function f(a, b, e) {
        if (a === j) return;
        (i || (i = d("ODS"))).bumpEntityKey(7173, "entities.ff_js_web." + a + "." + (h || (h = c("AnalyticsCoreData"))).app_id + "." + ((a = (h || (h = c("AnalyticsCoreData"))).app_version) != null ? a : "0").split(".")[0] + "." + h.push_phase, b, e)
    }
    g.identityToString = a;
    g.getTaggedBitmap = b;
    g.xorBitmap = e;
    g.bumpODSMetrics = f
}), 98);
__d("ODS", ["ExecutionEnvironment", "OdsWebBatchFalcoEvent", "Random", "Run", "clearTimeout", "gkx", "setTimeout", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    var h, i, j = (h || (h = c("ExecutionEnvironment"))).canUseDOM || (h || c("ExecutionEnvironment")).isInWorker,
        k = {};

    function l(a, b, c, d, e) {
        var f;
        d === void 0 && (d = 1);
        e === void 0 && (e = 1);
        var g = (f = k[b]) != null ? f : null;
        if (g != null && g <= 0) return;
        i = i || {};
        var h = i[a] || (i[a] = {}),
            j = h[b] || (h[b] = {}),
            l = j[c] || (j[c] = {
                n: 0,
                d: null
            }),
            m = Number(d),
            o = Number(e);
        g > 0 && (m /= g, o /= g);
        if (!isFinite(m) || !isFinite(o)) return;
        l.n += m;
        if (arguments.length >= 5) {
            var p = l.d;
            p == null && (p = 0);
            l.d = p + o
        }
        n()
    }
    var m;

    function n() {
        if (m != null) return;
        m = c("setTimeout")(function() {
            o()
        }, c("gkx")("20935") ? 13e3 / 2 : 5e3)
    }

    function a(a, b) {
        if (!j) return;
        k[a] = d("Random").random() < b ? b : 0
    }

    function b(a, b, c, d) {
        d === void 0 && (d = 1);
        if (!j) return;
        l(a, b, c, d)
    }

    function e(a, b, c, d, e) {
        d === void 0 && (d = 1);
        e === void 0 && (e = 1);
        if (!j) return;
        l(a, b, c, d, e)
    }

    function o(a) {
        a === void 0 && (a = "normal");
        if (!j) return;
        c("clearTimeout")(m);
        m = null;
        if (i == null) return;
        var b = i;
        i = null;

        function d() {
            return {
                batch: b
            }
        }
        a === "critical" ? c("OdsWebBatchFalcoEvent").logCritical(d) : c("OdsWebBatchFalcoEvent").log(d)
    }
    j && d("Run").onUnload(function() {
        o("critical")
    });
    g.setEntitySample = a;
    g.bumpEntityKey = b;
    g.bumpFraction = e;
    g.flush = o
}), 98);
__d("CometSuspenseFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1828945");
    b = d("FalcoLoggerInternal").create("comet_suspense", a);
    e = b;
    g["default"] = e
}), 98);
__d("FBJSON", [], (function(a, b, c, d, e, f) {
    a = JSON.parse;
    b = JSON.stringify;
    f.parse = a;
    f.stringify = b
}), 66);
__d("FbtLogging", ["cr:1094907", "cr:8828"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = b("cr:1094907") == null ? void 0 : b("cr:1094907").logImpression;
    c = b("cr:8828") == null ? void 0 : b("cr:8828").logImpressionV2;
    g.logImpression = a;
    g.logImpressionV2 = c
}), 98);
__d("IntlQtEventFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1848815");
    b = d("FalcoLoggerInternal").create("intl_qt_event", a);
    e = b;
    g["default"] = e
}), 98);
__d("LSIntEnum", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new Map();

    function a(a) {
        var b = i.get(a);
        if (b != null) return b;
        b = (h || (h = d("I64"))).of_float(a);
        i.set(a, b);
        return b
    }

    function j(a) {
        return (h || (h = d("I64"))).to_float(a)
    }

    function b(a) {
        return (h || (h = d("I64"))).to_float(a)
    }

    function c(a, b) {
        return a == null ? !1 : j(a) === b
    }
    g.ofNumber = a;
    g.toNumber = j;
    g.unwrapIntEnum = b;
    g.equal = c
}), 98);
__d("Log", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = -1;
    b = {
        DEBUG: 3,
        INFO: 2,
        WARNING: 1,
        ERROR: 0
    };
    c = function(a, b, c) {
        for (var d = arguments.length, e = new Array(d > 3 ? d - 3 : 0), f = 3; f < d; f++) e[f - 3] = arguments[f];
        var h = 0,
            i = c.replace(/%s/g, function() {
                return String(e[h++])
            }),
            j = window.console;
        j && g >= b && j[a in j ? a : "log"](i)
    };

    function a(a) {
        g = a
    }
    d = c.bind(null, "debug", b.DEBUG);
    e = c.bind(null, "info", b.INFO);
    var h = c.bind(null, "warn", b.WARNING),
        i = c.bind(null, "error", b.ERROR);
    f.Level = b;
    f.log = c;
    f.setLevel = a;
    f.debug = d;
    f.info = e;
    f.warn = h;
    f.error = i
}), 66);
__d("RDRequireDeferredReference", ["RequireDeferredReference"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        b.disableForSSR_DO_NOT_USE = function() {
            this.$RDRequireDeferredReference1 = !1
        };
        var c = b.prototype;
        c.isAvailableInSSR_DO_NOT_USE = function() {
            return this.constructor.$RDRequireDeferredReference1
        };
        return b
    }(c("RequireDeferredReference"));
    a.$RDRequireDeferredReference1 = !0;
    g["default"] = a
}), 98);
__d("XHRHttpError", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "HTTP_CLIENT_ERROR",
        h = "HTTP_PROXY_ERROR",
        i = "HTTP_SERVER_ERROR",
        j = "HTTP_TRANSPORT_ERROR",
        k = "HTTP_UNKNOWN_ERROR";

    function a(a, b) {
        if (b === 0) {
            a = a.getProtocol();
            return a === "file" || a === "ftp" ? null : j
        } else if (b >= 100 && b < 200) return h;
        else if (b >= 200 && b < 300) return null;
        else if (b >= 400 && b < 500) return g;
        else if (b >= 500 && b < 600) return i;
        else if (b >= 12001 && b < 12156) return j;
        else return k
    }
    f.HTTP_CLIENT_ERROR = g;
    f.HTTP_PROXY_ERROR = h;
    f.HTTP_SERVER_ERROR = i;
    f.HTTP_TRANSPORT_ERROR = j;
    f.HTTP_UNKNOWN_ERROR = k;
    f.getErrorCode = a
}), 66);
__d("getCrossOriginTransport", ["invariant", "ExecutionEnvironment", "err"], (function(a, b, c, d, e, f, g) {
    var h;

    function i() {
        if (!(h || (h = b("ExecutionEnvironment"))).isInBrowser) throw b("err")("getCrossOriginTransport: %s", "Cross origin transport unavailable in the server environment.");
        try {
            var a = new XMLHttpRequest();
            !("withCredentials" in a) && typeof XDomainRequest !== "undefined" && (a = new XDomainRequest());
            return a
        } catch (a) {
            throw b("err")("getCrossOriginTransport: %s", a.message)
        }
    }
    i.withCredentials = function() {
        var a = i();
        "withCredentials" in a || g(0, 5150);
        var b = a.open;
        a.open = function() {
            b.apply(this, arguments), this.withCredentials = !0
        };
        return a
    };
    e.exports = i
}), null);
__d("ZeroRewrites", ["URI", "ZeroRewriteRules", "getCrossOriginTransport", "getSameOriginTransport", "isFacebookURI"], (function(a, b, c, d, e, f) {
    var g, h = {
        rewriteURI: function(a) {
            if (!b("isFacebookURI")(a) || h._isWhitelisted(a)) return a;
            var c = h._getRewrittenSubdomain(a);
            c !== null && c !== void 0 && (a = a.setSubdomain(c));
            return a
        },
        getTransportBuilderForURI: function(a) {
            return h.isRewritten(a) ? b("getCrossOriginTransport").withCredentials : b("getSameOriginTransport")
        },
        isRewriteSafe: function(a) {
            if (Object.keys(b("ZeroRewriteRules").rewrite_rules).length === 0 || !b("isFacebookURI")(a)) return !1;
            var c = h._getCurrentURI().getDomain(),
                d = new(g || (g = b("URI")))(a).qualify().getDomain();
            return c === d || h.isRewritten(a)
        },
        isRewritten: function(a) {
            a = a.getQualifiedURI();
            if (Object.keys(b("ZeroRewriteRules").rewrite_rules).length === 0 || !b("isFacebookURI")(a) || h._isWhitelisted(a)) return !1;
            var c = a.getSubdomain(),
                d = h._getCurrentURI(),
                e = h._getRewrittenSubdomain(d);
            return a.getDomain() !== d.getDomain() && c === e
        },
        _isWhitelisted: function(a) {
            a = a.getPath();
            a.endsWith("/") || (a += "/");
            return b("ZeroRewriteRules").whitelist && b("ZeroRewriteRules").whitelist[a] === 1
        },
        _getRewrittenSubdomain: function(a) {
            a = a.getQualifiedURI().getSubdomain();
            return b("ZeroRewriteRules").rewrite_rules[a]
        },
        _getCurrentURI: function() {
            return new(g || (g = b("URI")))("/").qualify()
        }
    };
    e.exports = h
}), null);
__d("getAsyncHeaders", ["BDHeaderConfig", "LSD", "ZeroCategoryHeader", "isFacebookURI", "requireWeak"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = {},
            d = c("isFacebookURI")(a);
        d && c("ZeroCategoryHeader").value && (b[c("ZeroCategoryHeader").header] = c("ZeroCategoryHeader").value);
        d = h(a);
        d && (b["X-FB-LSD"] = d);
        d = i(a);
        d && (b["X-ASBD-ID"] = d);
        c("requireWeak")("MessengerPWAVersionForUserAgent", function(c) {
            c = c();
            c != null && !j(a) && (b["X-FB-PWA"] = "" + c)
        });
        return b
    }

    function h(a) {
        return j(a) ? null : c("LSD").token
    }

    function i(a) {
        return j(a) ? null : d("BDHeaderConfig").ASBD_ID
    }

    function j(a) {
        var b;
        b = (b = (b = k()) == null ? void 0 : (b = b.location) == null ? void 0 : b.origin) != null ? b : (b = window) == null ? void 0 : (b = b.location) == null ? void 0 : b.origin;
        return b == null ? !0 : !a.toString().startsWith("/") && a.getOrigin() !== b
    }

    function k() {
        if (typeof document !== "undefined") return document;
        else return null
    }
    g["default"] = a
}), 98);
__d("xhrSimpleDataSerializer", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = [];
        for (var c in a) b.push(encodeURIComponent(c) + "=" + encodeURIComponent(a[c]));
        return b.join("&")
    }
    f["default"] = a
}), 66);
__d("XHRRequest", ["invariant", "DTSGUtils", "Env", "ErrorGuard", "FBLogger", "LSD", "Log", "NetworkStatus", "ResourceTimingsStore", "ResourceTypes", "SprinkleConfig", "TimeSlice", "URI", "XHRHttpError", "ZeroRewrites", "cr:8959", "cr:8960", "fb-error", "getAsyncHeaders", "xhrSimpleDataSerializer"], (function(a, b, c, d, e, f, g) {
    var h, i, j, k = b("fb-error").ErrorXFBDebug,
        l = !1,
        m = {
            loadedBytes: 0,
            totalBytes: 0
        };

    function n(a) {
        return b("ZeroRewrites").rewriteURI(new(h || (h = b("URI")))(a))
    }
    a = function() {
        "use strict";

        function a(a) {
            this.$3 = function() {
                return null
            }, this.$19 = n(a), this.$7 = "POST", this.$6 = {}, this.setResponseType(null), this.setTransportBuilder(b("ZeroRewrites").getTransportBuilderForURI(this.getURI())), this.setDataSerializer(b("xhrSimpleDataSerializer")), this.$11 = b("ResourceTimingsStore").getUID(b("ResourceTypes").XHR, a != null ? a.toString() : "")
        }
        var c = a.prototype;
        c.setURI = function(a) {
            this.$19 = n(a);
            return this
        };
        c.getURI = function() {
            return this.$19
        };
        c.setResponseType = function(a) {
            this.$13 = a;
            return this
        };
        c.setMethod = function(a) {
            this.$7 = a;
            return this
        };
        c.getMethod = function() {
            return this.$7
        };
        c.setData = function(a) {
            this.$2 = a;
            return this
        };
        c.getData = function() {
            return this.$2
        };
        c.setRawData = function(a) {
            this.$10 = a;
            return this
        };
        c.setRequestHeader = function(a, b) {
            this.$6[a] = b;
            return this
        };
        c.setTimeout = function(a) {
            this.$14 = a;
            return this
        };
        c.getTimeout = function() {
            return this.$14
        };
        c.setResponseHandler = function(a) {
            this.$12 = a;
            return this
        };
        c.getResponseHandler = function() {
            return this.$12
        };
        c.setErrorHandler = function(a) {
            this.$5 = a;
            return this
        };
        c.getErrorHandler = function() {
            return this.$5
        };
        c.setNetworkFailureHandler = function(a) {
            this.$8 = a;
            return this
        };
        c.getNetworkFailureHandler = function() {
            return this.$8
        };
        c.getResponseHeader = function(a) {
            var b = this.$9;
            return b ? b.getResponseHeader(a) : null
        };
        c.setAbortHandler = function(a) {
            this.$1 = a;
            return this
        };
        c.getAbortHandler = function() {
            return this.$1
        };
        c.setTimeoutHandler = function(a) {
            this.$15 = a;
            return this
        };
        c.getTimeoutHandler = function() {
            return this.$15
        };
        c.setUploadProgressHandler = function(a) {
            this.$18 = a;
            return this
        };
        c.setDownloadProgressHandler = function(a) {
            this.$4 = a;
            return this
        };
        c.setTransportBuilder = function(a) {
            !this.$17 || !b("ZeroRewrites").isRewritten(this.$19) ? this.$17 = a : b("FBLogger")("iorg-FOS").blameToPreviousFile().mustfix("can not set new TransportBuilder for the request %s", String(this.getURI()));
            return this
        };
        c.setDataSerializer = function(a) {
            this.$3 = a;
            return this
        };
        c.setWithCredentials = function(a) {
            this.$20 = a;
            return this
        };
        c.send = function() {
            var a = this.$14,
                c = this.$17;
            if (!c) return;
            var d = c();
            c = this.getURI();
            if (c.toString().includes("/../") || c.toString().includes("/..\\") || c.toString().includes("\\../") || c.toString().includes("\\..\\")) {
                b("Log").error("XHRRequest.send(): path traversal is not allowed.");
                return !1
            }
            if (l === !0) return;
            var e = new(h || (h = b("URI")))(c).getQualifiedURI().toString(),
                f = this.$11;
            b("ResourceTimingsStore").updateURI(b("ResourceTypes").XHR, f, e);
            b("ResourceTimingsStore").measureRequestSent(b("ResourceTypes").XHR, f);
            this.$9 = d;
            this.$7 === "POST" || !this.$10 || g(0, 2346, this.$10, c);
            e = (i || (i = b("Env"))).force_param;
            e && (this.$2 = babelHelpers["extends"]({}, this.getData() || {}, e));
            if (this.$7 === "GET" && b("DTSGUtils").shouldAppendToken(c)) {
                e = b("cr:8960").getCachedToken ? b("cr:8960").getCachedToken() : b("cr:8960").getToken();
                e && (this.$2 ? this.$2.fb_dtsg_ag = e : this.$2 = {
                    fb_dtsg_ag: e
                }, b("SprinkleConfig").param_name && (this.$2[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(e)))
            }
            if (this.$7 === "POST" && b("DTSGUtils").shouldAppendToken(c)) {
                e = b("cr:8959").getCachedToken ? b("cr:8959").getCachedToken() : b("cr:8959").getToken();
                e && (this.$2 ? this.$2.fb_dtsg = e : this.$2 = {
                    fb_dtsg: e
                }, b("SprinkleConfig").param_name && (this.$2[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(e)));
                b("LSD").token && (this.$2 ? this.$2.lsd = b("LSD").token : this.$2 = {
                    lsd: b("LSD").token
                }, b("SprinkleConfig").param_name && !e && (this.$2[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(b("LSD").token)))
            }
            this.$7 === "GET" || this.$10 ? (c.addQueryData(this.$2), e = this.$10) : e = this.$3(this.$2);

            function j(a) {
                b("ResourceTimingsStore").measureResponseReceived(b("ResourceTypes").XHR, f);
                for (var c = arguments.length, d = new Array(c > 1 ? c - 1 : 0), e = 1; e < c; e++) d[e - 1] = arguments[e];
                a.apply(this, d)
            }
            j = b("TimeSlice").guard(j, "XHRRequest response received", {
                propagationType: b("TimeSlice").PropagationType.CONTINUATION
            });
            d.onreadystatechange = this.$21(j);
            d.onerror = this.$22(j);
            d.upload && this.$18 && (d.upload.onprogress = this.$23.bind(this));
            this.$4 && (d.onprogress = this.$24.bind(this));
            a && (this.$16 = setTimeout(this.$25.bind(this), a));
            this.$20 != null && (d.withCredentials = this.$20);
            d.open(this.$7, c.toString(), !0);
            j = !1;
            if (this.$6)
                for (a in this.$6) a.toLowerCase() === "content-type" && (j = !0), d.setRequestHeader(a, this.$6[a]);
            this.$7 == "POST" && !this.$10 && !j && d.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            var k = b("getAsyncHeaders")(c);
            Object.keys(k).forEach(function(a) {
                d.setRequestHeader(a, k[a])
            });
            this.$13 === "arraybuffer" && ("responseType" in d ? d.responseType = "arraybuffer" : "overrideMimeType" in d ? d.overrideMimeType("text/plain; charset=x-user-defined") : "setRequestHeader" in d && d.setRequestHeader("Accept-Charset", "x-user-defined"));
            this.$13 === "blob" && (d.responseType = this.$13);
            d.send(e)
        };
        c.abort = function(a) {
            this.$26(), this.$1 && (j || (j = b("ErrorGuard"))).applyWithGuard(this.$1, null, [a], {
                name: "XHRRequest:_abortHandler"
            })
        };
        c.$26 = function() {
            var a = this.$9;
            a && (a.onreadystatechange = null, a.abort());
            this.$27()
        };
        c.$25 = function() {
            this.$26(), this.$15 && (j || (j = b("ErrorGuard"))).applyWithGuard(this.$15, null, [], {
                name: "XHRRequest:_abortHandler"
            })
        };
        c.$28 = function(a) {
            if (this.$13)
                if ("response" in a) return a.response;
                else if (this.$13 === "arraybuffer" && window.VBArray) return window.VBArray(a.responseBody).toArray();
            return a.responseText
        };
        c.$22 = function(a) {
            var c = this,
                d = this.$9;
            return function() {
                var e;
                e = {
                    errorCode: b("XHRHttpError").HTTP_TRANSPORT_ERROR,
                    errorMsg: "Network Failure.",
                    errorType: "Network",
                    errorRawResponseHeaders: null,
                    errorRawTransport: d == null ? void 0 : (e = d.constructor) == null ? void 0 : e.name,
                    errorRawTransportStatus: 0
                };
                c.$8 ? (j || (j = b("ErrorGuard"))).applyWithGuard(a.bind(void 0, c.$8), null, [e], {
                    name: "XHRRequest:_networkFailureHandler"
                }) : a(function() {});
                b("NetworkStatus").reportError()
            }
        };
        c.$21 = function(a) {
            var c = this,
                d = b("TimeSlice").guard(function(a) {
                    for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
                    return a.apply(this, c)
                }, "XHRRequest onreadystatechange", {
                    propagationType: b("TimeSlice").PropagationType.EXECUTION
                });
            return function() {
                var e = c.$9;
                if (e == null) return;
                var f = e.readyState;
                if (f >= 2) {
                    var g = f === 4;
                    g && k.addFromXHR(e);
                    var h = c.getURI();
                    h = b("XHRHttpError").getErrorCode(h, e.status);
                    var i = c.$12;
                    if (h != null) {
                        if (g) {
                            var l = {
                                errorCode: h,
                                errorMsg: c.$28(e),
                                errorRawTransport: e.constructor.name,
                                errorRawTransportStatus: e.status,
                                errorRawResponseHeaders: i && i.includeHeaders ? e.getAllResponseHeaders() : null,
                                errorType: e.status ? "HTTP " + e.status : "HTTP"
                            };
                            c.$5 ? (j || (j = b("ErrorGuard"))).applyWithGuard(a.bind(void 0, c.$5), null, [l], {
                                name: "XHRRequest:_errorHandler"
                            }) : a(function() {})
                        }
                    } else if (i) {
                        if (g || i.parseStreaming && f === 3) {
                            l = g ? a : d;
                            f = (i == null ? void 0 : i.includeHeaders) ? e.getAllResponseHeaders() : null;
                            (j || (j = b("ErrorGuard"))).applyWithGuard(l.bind(void 0, i), null, [c.$28(e), f, g], {
                                name: "XHRRequest:handler"
                            })
                        }
                    } else g && a(function() {});
                    g && (h != "HTTP_TRANSPORT_ERROR" && b("NetworkStatus").reportSuccess(), c.$27())
                }
            }
        };
        c.$23 = function(a) {
            m.loadedBytes = a.loaded, m.totalBytes = a.total, this.$18 && (j || (j = b("ErrorGuard"))).applyWithGuard(this.$18, null, [m], {
                name: "XHRRequest:_uploadProgressHandler"
            })
        };
        c.$24 = function(a) {
            a = {
                loadedBytes: a.loaded,
                totalBytes: a.total
            };
            this.$4 && (j || (j = b("ErrorGuard"))).applyWithGuard(this.$4, null, [a], {
                name: "XHRRequest:_downloadProgressHandler"
            })
        };
        c.$27 = function() {
            clearTimeout(this.$16), delete this.$9
        };
        a.disable = function() {
            l = !0
        };
        return a
    }();
    e.exports = a
}), null);
__d("isInIframe", [], (function(a, b, c, d, e, f) {
    var g = typeof window !== "undefined" && window.top != null && window != window.top;

    function a() {
        return g
    }
    f["default"] = a
}), 66);
__d("isPromise", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a) {
        return a instanceof(g || (g = b("Promise"))) || typeof(a == null ? void 0 : a.then) === "function"
    }
    f["default"] = a
}), 66);
__d("requireDeferred", ["RDRequireDeferredReference"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {};

    function i(a, b) {
        h[a] = b
    }

    function j(a) {
        return h[a]
    }

    function a(a) {
        var b = j(a);
        if (b) return b;
        b = new(c("RDRequireDeferredReference"))(a);
        i(a, b);
        return b
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("bs_caml", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        if (a < b) return -1;
        else if (a === b) return 0;
        else return 1
    }

    function b(a, b) {
        if (a)
            if (b) return 0;
            else return 1;
        else if (b) return -1;
        else return 0
    }

    function c(a, b) {
        if (a === b) return 0;
        else if (a < b) return -1;
        else if (a > b || a === a) return 1;
        else if (b === b) return -1;
        else return 0
    }

    function d(a, b) {
        if (a === b) return 0;
        else if (a < b) return -1;
        else return 1
    }

    function e(a, b) {
        if (a) return b;
        else return a
    }

    function g(a, b) {
        if (a < b) return a;
        else return b
    }

    function h(a, b) {
        if (a < b) return a;
        else return b
    }

    function i(a, b) {
        if (a < b) return a;
        else return b
    }

    function j(a, b) {
        if (a < b) return a;
        else return b
    }

    function k(a, b) {
        if (a) return a;
        else return b
    }

    function l(a, b) {
        if (a > b) return a;
        else return b
    }

    function m(a, b) {
        if (a > b) return a;
        else return b
    }

    function n(a, b) {
        if (a > b) return a;
        else return b
    }

    function o(a, b) {
        if (a > b) return a;
        else return b
    }

    function p(a, b) {
        if (a[1] === b[1]) return a[0] === b[0];
        else return !1
    }

    function q(a, b) {
        var c = b[0],
            d = a[0];
        if (d > c) return !0;
        else if (d < c) return !1;
        else return a[1] >= b[1]
    }

    function r(a, b) {
        return !p(a, b)
    }

    function s(a, b) {
        return !q(a, b)
    }

    function t(a, b) {
        if (a[0] > b[0]) return !0;
        else if (a[0] < b[0]) return !1;
        else return a[1] > b[1]
    }

    function u(a, b) {
        return !t(a, b)
    }

    function v(a, b) {
        if (q(a, b)) return b;
        else return a
    }

    function w(a, b) {
        if (t(a, b)) return a;
        else return b
    }
    f.caml_int_compare = a;
    f.caml_bool_compare = b;
    f.caml_float_compare = c;
    f.caml_string_compare = d;
    f.caml_bool_min = e;
    f.caml_int_min = g;
    f.caml_float_min = h;
    f.caml_string_min = i;
    f.caml_int32_min = j;
    f.caml_bool_max = k;
    f.caml_int_max = l;
    f.caml_float_max = m;
    f.caml_string_max = n;
    f.caml_int32_max = o;
    f.i64_eq = p;
    f.i64_neq = r;
    f.i64_lt = s;
    f.i64_gt = t;
    f.i64_le = u;
    f.i64_ge = q;
    f.i64_min = v;
    f.i64_max = w
}), null);
__d("bs_caml_int64", ["bs_caml"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a, b) {
        return [b, a >>> 0]
    }
    var h = [-2147483648, 0],
        i = [2147483647, 4294967295],
        j = [0, 1],
        k = [0, 0],
        l = [-1, 4294967295];

    function m(a) {
        return (a & -2147483648) !== 0
    }

    function n(a) {
        return (a & -2147483648) === 0
    }

    function c(a) {
        var b = a[1];
        a = a[0];
        b = b + 1 | 0;
        return [a + (b === 0 ? 1 : 0) | 0, b >>> 0]
    }

    function o(a) {
        var b = (a[1] ^ -1) + 1 | 0;
        return [(a[0] ^ -1) + (b === 0 ? 1 : 0) | 0, b >>> 0]
    }

    function p(a, b, c) {
        var d = a[1],
            e = d + b | 0;
        d = m(d) && (m(b) || n(e)) || m(b) && n(e) ? 1 : 0;
        return [a[0] + c + d | 0, e >>> 0]
    }

    function q(a, b) {
        return p(a, b[1], b[0])
    }

    function d(a, c) {
        if (c !== null) return (g || (g = b("bs_caml"))).i64_eq(a, c);
        else return !1
    }

    function e(a, c) {
        if (c !== void 0) return (g || (g = b("bs_caml"))).i64_eq(a, c);
        else return !1
    }

    function r(a, c) {
        if (c == null) return !1;
        else return (g || (g = b("bs_caml"))).i64_eq(a, c)
    }

    function s(a, b, c) {
        b = (b ^ -1) + 1 >>> 0;
        c = (c ^ -1) + (b === 0 ? 1 : 0) | 0;
        return p(a, b, c)
    }

    function t(a, b) {
        return s(a, b[1], b[0])
    }

    function u(a, b) {
        if (b === 0) return a;
        var c = a[1];
        if (b >= 32) return [c << (b - 32 | 0), 0];
        else return [c >>> (32 - b | 0) | a[0] << b, c << b >>> 0]
    }

    function v(a, b) {
        if (b === 0) return a;
        var c = a[0],
            d = b - 32 | 0;
        if (d === 0) return [0, c >>> 0];
        else if (d > 0) return [0, c >>> d];
        else return [c >>> b, (c << (-d | 0) | a[1] >>> b) >>> 0]
    }

    function w(a, b) {
        if (b === 0) return a;
        var c = a[0];
        if (b < 32) return [c >> b, (c << (32 - b | 0) | a[1] >>> b) >>> 0];
        else return [c >= 0 ? 0 : -1, c >> (b - 32 | 0) >>> 0]
    }

    function x(a) {
        if (a[0] !== 0) return !1;
        else return a[1] === 0
    }

    function y(a, b) {
        while (!0) {
            var c = b,
                d = a,
                e, f = d[0],
                g = 0,
                i = 0,
                j;
            if (f !== 0) j = 4;
            else {
                if (d[1] === 0) return k;
                j = 4
            }
            if (j === 4)
                if (c[0] !== 0) i = 3;
                else {
                    if (c[1] === 0) return k;
                    i = 3
                }
            i === 3 && (f !== -2147483648 || d[1] !== 0 ? g = 2 : e = c[1]);
            if (g === 2) {
                j = c[0];
                i = d[1];
                g = 0;
                j !== -2147483648 || c[1] !== 0 ? g = 3 : e = i;
                if (g === 3) {
                    g = c[1];
                    if (f < 0) {
                        if (j >= 0) return o(y(o(d), c));
                        b = o(c);
                        a = o(d);
                        continue
                    }
                    if (j < 0) return o(y(d, o(c)));
                    d = f >>> 16;
                    c = f & 65535;
                    f = i >>> 16;
                    i = i & 65535;
                    var l = j >>> 16;
                    j = j & 65535;
                    var m = g >>> 16;
                    g = g & 65535;
                    var n, p, q, r = i * g;
                    q = (r >>> 16) + f * g;
                    p = q >>> 16;
                    q = (q & 65535) + i * m;
                    p = p + (q >>> 16) + c * g;
                    n = p >>> 16;
                    p = (p & 65535) + f * m;
                    n = n + (p >>> 16);
                    p = (p & 65535) + i * j;
                    n = n + (p >>> 16);
                    p = p & 65535;
                    n = n + (d * g + c * m + f * j + i * l) & 65535;
                    return [p | n << 16, (r & 65535 | (q & 65535) << 16) >>> 0]
                }
            }
            if ((e & 1) === 0) return k;
            else return h
        }
    }

    function z(a, b) {
        return [a[0] ^ b[0], (a[1] ^ b[1]) >>> 0]
    }

    function A(a, b) {
        return [a[0] | b[0], (a[1] | b[1]) >>> 0]
    }

    function B(a, b) {
        return [a[0] & b[0], (a[1] & b[1]) >>> 0]
    }

    function C(a) {
        return a[0] * 4294967296 + a[1]
    }

    function D(a) {
        if (isNaN(a) || !isFinite(a)) return k;
        if (a <= -9223372036854776e3) return h;
        if (a + 1 >= 9223372036854776e3) return i;
        if (a < 0) return o(D(-a));
        var b = a / 4294967296 | 0;
        a = a % 4294967296 | 0;
        return [b, a >>> 0]
    }

    function E(a) {
        var b = a[0],
            c = b >> 21;
        if (c === 0) return !0;
        else if (c === -1) return !(a[1] === 0 && b === -2097152);
        else return !1
    }

    function F(a) {
        if (E(a)) return String(C(a));
        if (a[0] < 0)
            if ((g || (g = b("bs_caml"))).i64_eq(a, h)) return "-9223372036854775808";
            else return "-" + F(o(a));
        var c = D(Math.floor(C(a) / 10)),
            d = c[1],
            e = c[0];
        a = s(s(a, d << 3, d >>> 29 | e << 3), d << 1, d >>> 31 | e << 1);
        d = a[1];
        e = a[0];
        if (d === 0 && e === 0) return F(c) + "0";
        if (e < 0) {
            a = (d ^ -1) + 1 >>> 0;
            e = Math.ceil(a / 10);
            a = 10 * e - a;
            return F(s(c, e | 0, 0)) + String(a | 0)
        }
        e = Math.floor(d / 10);
        a = d - 10 * e;
        return F(p(c, e | 0, 0)) + String(a | 0)
    }

    function G(a, c) {
        while (!0) {
            var d = c,
                e = a,
                f = e[0],
                i = 0,
                m;
            if (d[0] !== 0 || d[1] !== 0) m = 2;
            else throw {
                RE_EXN_ID: "Division_by_zero",
                Error: new Error()
            };
            if (m === 2)
                if (f !== -2147483648)
                    if (f !== 0) i = 1;
                    else {
                        if (e[1] === 0) return k;
                        i = 1
                    }
            else if (e[1] !== 0) i = 1;
            else {
                if ((g || (g = b("bs_caml"))).i64_eq(d, j) || (g || (g = b("bs_caml"))).i64_eq(d, l)) return e;
                if ((g || (g = b("bs_caml"))).i64_eq(d, h)) return j;
                m = w(e, 1);
                m = u(G(m, d), 1);
                var n;
                if (m[0] !== 0) n = 3;
                else {
                    if (m[1] === 0)
                        if (d[0] < 0) return j;
                        else return o(j);
                    n = 3
                }
                if (n === 3) {
                    n = t(e, y(d, m));
                    return q(m, G(n, d))
                }
            }
            if (i === 1) {
                m = d[0];
                if (m !== -2147483648) n = 2;
                else {
                    if (d[1] === 0) return k;
                    n = 2
                }
                if (n === 2) {
                    if (f < 0) {
                        if (m >= 0) return o(G(o(e), d));
                        c = o(d);
                        a = o(e);
                        continue
                    }
                    if (m < 0) return o(G(e, o(d)));
                    i = k;
                    n = e;
                    while ((g || (g = b("bs_caml"))).i64_ge(n, d)) {
                        f = Math.floor(C(n) / C(d));
                        m = 1 > f ? 1 : f;
                        e = Math.ceil(Math.log(m) / Math.LN2);
                        f = e <= 48 ? 1 : Math.pow(2, e - 48);
                        e = D(m);
                        var p = y(e, d);
                        while (p[0] < 0 || (g || (g = b("bs_caml"))).i64_gt(p, n)) m = m - f, e = D(m), p = y(e, d);
                        x(e) && (e = j);
                        i = q(i, e);
                        n = t(n, p)
                    }
                    return i
                }
            }
        }
    }

    function H(a, b) {
        return t(a, y(G(a, b), b))
    }

    function I(a, b) {
        var c = G(a, b);
        return [c, t(a, y(c, b))]
    }

    function J(a, b) {
        var c = b[0],
            d = a[0];
        d = d < c ? -1 : d === c ? 0 : 1;
        if (d !== 0) return d;
        c = b[1];
        d = a[1];
        if (d < c) return -1;
        else if (d === c) return 0;
        else return 1
    }

    function K(a) {
        return [a < 0 ? -1 : 0, a >>> 0]
    }

    function L(a) {
        return a[1] | 0
    }

    function M(a) {
        var b = a[1];
        a = a[0];
        var c = function(a) {
            return (a >>> 0).toString(16)
        };
        if (a === 0 && b === 0) return "0";
        if (b === 0) return c(a) + "00000000";
        if (a === 0) return c(b);
        b = c(b);
        var d = 8 - b.length | 0;
        if (d <= 0) return c(a) + b;
        else return c(a) + ("0".repeat(d) + b)
    }

    function N(a) {
        return [2147483647 & a[0], a[1]]
    }

    function O(a) {
        return function(a, b) {
            return new Float64Array(new Int32Array([a, b]).buffer)[0]
        }(a[1], a[0])
    }

    function P(a) {
        a = function(a) {
            return new Int32Array(new Float64Array([a]).buffer)
        }(a);
        return [a[1], a[0] >>> 0]
    }
    f.mk = a;
    f.succ = c;
    f.min_int = h;
    f.max_int = i;
    f.one = j;
    f.zero = k;
    f.neg_one = l;
    f.of_int32 = K;
    f.to_int32 = L;
    f.add = q;
    f.neg = o;
    f.sub = t;
    f.lsl_ = u;
    f.lsr_ = v;
    f.asr_ = w;
    f.is_zero = x;
    f.mul = y;
    f.xor = z;
    f.or_ = A;
    f.and_ = B;
    f.equal_null = d;
    f.equal_undefined = e;
    f.equal_nullable = r;
    f.to_float = C;
    f.of_float = D;
    f.div = G;
    f.mod_ = H;
    f.compare = J;
    f.float_of_bits = O;
    f.bits_of_float = P;
    f.div_mod = I;
    f.to_hex = M;
    f.discard_sign = N;
    f.to_string = F
}), null);
__d("bs_caml_format", ["bs_caml", "bs_caml_int64"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h;

    function i(a) {
        if (a >= 65)
            if (a >= 97)
                if (a >= 123) return -1;
                else return a - 87 | 0;
        else if (a >= 91) return -1;
        else return a - 55 | 0;
        else if (a > 57 || a < 48) return -1;
        else return a - 48 | 0
    }

    function j(a) {
        switch (a) {
            case 0:
                return 8;
            case 1:
                return 16;
            case 2:
                return 10;
            case 3:
                return 2
        }
    }

    function k(a) {
        var b = 1,
            c = 2,
            d = 0,
            e = a.charCodeAt(d);
        switch (e) {
            case 43:
                d = d + 1 | 0;
                break;
            case 44:
                break;
            case 45:
                b = -1;
                d = d + 1 | 0;
                break;
            default:
        }
        if (a[d] === "0") {
            e = a.charCodeAt(d + 1 | 0);
            if (e >= 89)
                if (e >= 111) {
                    if (e < 121) switch (e) {
                        case 111:
                            c = 0;
                            d = d + 2 | 0;
                            break;
                        case 117:
                            d = d + 2 | 0;
                            break;
                        case 112:
                        case 113:
                        case 114:
                        case 115:
                        case 116:
                        case 118:
                        case 119:
                            break;
                        case 120:
                            c = 1;
                            d = d + 2 | 0;
                            break
                    }
                } else e === 98 && (c = 3, d = d + 2 | 0);
            else if (e !== 66) {
                if (e >= 79) switch (e) {
                    case 79:
                        c = 0;
                        d = d + 2 | 0;
                        break;
                    case 85:
                        d = d + 2 | 0;
                        break;
                    case 80:
                    case 81:
                    case 82:
                    case 83:
                    case 84:
                    case 86:
                    case 87:
                        break;
                    case 88:
                        c = 1;
                        d = d + 2 | 0;
                        break
                }
            } else c = 3, d = d + 2 | 0
        }
        return [d, b, c]
    }

    function a(a) {
        var b = k(a),
            c = b[0],
            d = j(b[2]),
            e = 4294967295,
            f = a.length,
            g = c < f ? a.charCodeAt(c) : 0;
        g = i(g);
        if (g < 0 || g >= d) throw {
            RE_EXN_ID: "Failure",
            _1: "int_of_string",
            Error: new Error()
        };
        var h = function(b, c) {
            while (!0) {
                var g = c,
                    h = b;
                if (g === f) return h;
                var j = a.charCodeAt(g);
                if (j === 95) {
                    c = g + 1 | 0;
                    continue
                }
                j = i(j);
                if (j < 0 || j >= d) throw {
                    RE_EXN_ID: "Failure",
                    _1: "int_of_string",
                    Error: new Error()
                };
                h = d * h + j;
                if (h > e) throw {
                    RE_EXN_ID: "Failure",
                    _1: "int_of_string",
                    Error: new Error()
                };
                c = g + 1 | 0;
                b = h;
                continue
            }
        };
        b = b[1] * h(g, c + 1 | 0);
        h = b | 0;
        if (d === 10 && b !== h) throw {
            RE_EXN_ID: "Failure",
            _1: "int_of_string",
            Error: new Error()
        };
        return h
    }

    function c(a) {
        var c = k(a),
            d = c[2],
            e = c[0],
            f = (g || (g = b("bs_caml_int64"))).of_int32(j(d));
        c = g.of_int32(c[1]);
        var l;
        switch (d) {
            case 0:
                l = [536870911, 4294967295];
                break;
            case 1:
                l = [268435455, 4294967295];
                break;
            case 2:
                l = [429496729, 2576980377];
                break;
            case 3:
                l = (g || (g = b("bs_caml_int64"))).max_int;
                break
        }
        var m = a.length;
        d = e < m ? a.charCodeAt(e) : 0;
        d = g.of_int32(i(d));
        if ((h || (h = b("bs_caml"))).i64_lt(d, (g || (g = b("bs_caml_int64"))).zero) || (h || (h = b("bs_caml"))).i64_ge(d, f)) throw {
            RE_EXN_ID: "Failure",
            _1: "int64_of_string",
            Error: new Error()
        };
        var n = function(c, d) {
            while (!0) {
                var e = d,
                    j = c;
                if (e === m) return j;
                var k = a.charCodeAt(e);
                if (k === 95) {
                    d = e + 1 | 0;
                    continue
                }
                k = (g || (g = b("bs_caml_int64"))).of_int32(i(k));
                if ((h || (h = b("bs_caml"))).i64_lt(k, (g || (g = b("bs_caml_int64"))).zero) || (h || (h = b("bs_caml"))).i64_ge(k, f) || (h || (h = b("bs_caml"))).i64_gt(j, l)) throw {
                    RE_EXN_ID: "Failure",
                    _1: "int64_of_string",
                    Error: new Error()
                };
                j = g.add(g.mul(f, j), k);
                d = e + 1 | 0;
                c = j;
                continue
            }
        };
        c = g.mul(c, n(d, e + 1 | 0));
        n = g.or_(c, g.zero);
        if ((h || (h = b("bs_caml"))).i64_eq(f, [0, 10]) && (h || (h = b("bs_caml"))).i64_neq(c, n)) throw {
            RE_EXN_ID: "Failure",
            _1: "int64_of_string",
            Error: new Error()
        };
        return n
    }

    function l(a) {
        switch (a) {
            case 0:
                return 8;
            case 1:
                return 16;
            case 2:
                return 10
        }
    }

    function m(a) {
        if (a >= 65 && a <= 90 || a >= 192 && a <= 214 || a >= 216 && a <= 222) return a + 32 | 0;
        else return a
    }

    function n(a) {
        var b = a.length;
        if (b > 31) throw {
            RE_EXN_ID: "Invalid_argument",
            _1: "format_int: format too long",
            Error: new Error()
        };
        var c = {
                justify: "+",
                signstyle: "-",
                filter: " ",
                alternate: !1,
                base: 2,
                signedconv: !1,
                width: 0,
                uppercase: !1,
                sign: 1,
                prec: -1,
                conv: "f"
            },
            d = 0;
        while (!0) {
            var e = d;
            if (e >= b) return c;
            var f = a.charCodeAt(e),
                g = 0;
            if (f >= 69)
                if (f >= 88)
                    if (f >= 121) g = 1;
                    else switch (f) {
                            case 88:
                                c.base = 1;
                                c.uppercase = !0;
                                d = e + 1 | 0;
                                continue;
                            case 101:
                            case 102:
                            case 103:
                                g = 5;
                                break;
                            case 100:
                            case 105:
                                g = 4;
                                break;
                            case 111:
                                c.base = 0;
                                d = e + 1 | 0;
                                continue;
                            case 117:
                                c.base = 2;
                                d = e + 1 | 0;
                                continue;
                            case 89:
                            case 90:
                            case 91:
                            case 92:
                            case 93:
                            case 94:
                            case 95:
                            case 96:
                            case 97:
                            case 98:
                            case 99:
                            case 104:
                            case 106:
                            case 107:
                            case 108:
                            case 109:
                            case 110:
                            case 112:
                            case 113:
                            case 114:
                            case 115:
                            case 116:
                            case 118:
                            case 119:
                                g = 1;
                                break;
                            case 120:
                                c.base = 1;
                                d = e + 1 | 0;
                                continue
                        } else if (f >= 72) g = 1;
                        else {
                            c.signedconv = !0;
                            c.uppercase = !0;
                            c.conv = String.fromCharCode(m(f));
                            d = e + 1 | 0;
                            continue
                        }
            else switch (f) {
                case 35:
                    c.alternate = !0;
                    d = e + 1 | 0;
                    continue;
                case 32:
                case 43:
                    g = 2;
                    break;
                case 45:
                    c.justify = "-";
                    d = e + 1 | 0;
                    continue;
                case 46:
                    c.prec = 0;
                    var h = e + 1 | 0;
                    while (function(b) {
                            return function() {
                                var c = a.charCodeAt(b) - 48 | 0;
                                return c >= 0 && c <= 9
                            }
                        }(h)()) c.prec = (Math.imul(c.prec, 10) + a.charCodeAt(h) | 0) - 48 | 0, h = h + 1 | 0;
                    d = h;
                    continue;
                case 33:
                case 34:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 44:
                case 47:
                    g = 1;
                    break;
                case 48:
                    c.filter = "0";
                    d = e + 1 | 0;
                    continue;
                case 49:
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                    g = 3;
                    break;
                default:
                    g = 1
            }
            switch (g) {
                case 1:
                    d = e + 1 | 0;
                    continue;
                case 2:
                    c.signstyle = String.fromCharCode(f);
                    d = e + 1 | 0;
                    continue;
                case 3:
                    c.width = 0;
                    h = e;
                    while (function(b) {
                            return function() {
                                var c = a.charCodeAt(b) - 48 | 0;
                                return c >= 0 && c <= 9
                            }
                        }(h)()) c.width = (Math.imul(c.width, 10) + a.charCodeAt(h) | 0) - 48 | 0, h = h + 1 | 0;
                    d = h;
                    continue;
                case 4:
                    c.signedconv = !0;
                    c.base = 2;
                    d = e + 1 | 0;
                    continue;
                case 5:
                    c.signedconv = !0;
                    c.conv = String.fromCharCode(f);
                    d = e + 1 | 0;
                    continue
            }
        }
    }

    function o(a, b) {
        var c = a.justify,
            d = a.signstyle,
            e = a.filter,
            f = a.alternate,
            g = a.base,
            h = a.signedconv,
            i = a.width,
            j = a.uppercase;
        a = a.sign;
        var k = b.length;
        h && (a < 0 || d !== "-") && (k = k + 1 | 0);
        f && (g === 0 ? k = k + 1 | 0 : g === 1 && (k = k + 2 | 0));
        var l = "";
        if (c === "+" && e === " ")
            for (var m = k; m < i; ++m) l = l + e;
        h && (a < 0 ? l = l + "-" : d !== "-" && (l = l + d));
        f && g === 0 && (l = l + "0");
        f && g === 1 && (l = l + "0x");
        if (c === "+" && e === "0")
            for (m = k; m < i; ++m) l = l + e;
        l = j ? l + b.toUpperCase() : l + b;
        if (c === "-")
            for (h = k; h < i; ++h) l = l + " ";
        return l
    }

    function d(a, b) {
        if (a === "%d") return String(b);
        a = n(a);
        b = b < 0 ? a.signedconv ? (a.sign = -1, -b >>> 0) : b >>> 0 : b;
        b = b.toString(l(a.base));
        if (a.prec >= 0) {
            a.filter = " ";
            var c = a.prec - b.length | 0;
            c > 0 && (b = "0".repeat(c) + b)
        }
        return o(a, b)
    }

    function p(a) {
        if (!(h || (h = b("bs_caml"))).i64_lt(a, (g || (g = b("bs_caml_int64"))).zero)) return (g || (g = b("bs_caml_int64"))).to_string(a);
        var c = [0, 10];
        a = (g || (g = b("bs_caml_int64"))).discard_sign(a);
        a = g.div_mod(a, c);
        c = g.div_mod(g.add([0, 8], a[1]), c);
        a = g.add(g.add([214748364, 3435973836], a[0]), c[0]);
        return g.to_string(a) + "0123456789" [g.to_int32(c[1])]
    }

    function q(a) {
        var c = "",
            d = [0, 8],
            e = "01234567";
        if ((h || (h = b("bs_caml"))).i64_lt(a, (g || (g = b("bs_caml_int64"))).zero)) {
            var f = (g || (g = b("bs_caml_int64"))).discard_sign(a);
            f = g.div_mod(f, d);
            var i = g.add([268435456, 0], f[0]);
            f = f[1];
            c = e[g.to_int32(f)] + c;
            while ((h || (h = b("bs_caml"))).i64_neq(i, (g || (g = b("bs_caml_int64"))).zero)) {
                var j = (g || (g = b("bs_caml_int64"))).div_mod(i, d);
                i = j[0];
                f = j[1];
                c = e[g.to_int32(f)] + c
            }
        } else {
            j = (g || (g = b("bs_caml_int64"))).div_mod(a, d);
            f = j[0];
            i = j[1];
            c = e[g.to_int32(i)] + c;
            while ((h || (h = b("bs_caml"))).i64_neq(f, (g || (g = b("bs_caml_int64"))).zero)) {
                a = (g || (g = b("bs_caml_int64"))).div_mod(f, d);
                f = a[0];
                i = a[1];
                c = e[g.to_int32(i)] + c
            }
        }
        return c
    }

    function e(a, c) {
        if (a === "%d") return (g || (g = b("bs_caml_int64"))).to_string(c);
        a = n(a);
        c = a.signedconv && (h || (h = b("bs_caml"))).i64_lt(c, (g || (g = b("bs_caml_int64"))).zero) ? (a.sign = -1, (g || (g = b("bs_caml_int64"))).neg(c)) : c;
        var d = a.base,
            e;
        switch (d) {
            case 0:
                e = q(c);
                break;
            case 1:
                e = (g || (g = b("bs_caml_int64"))).to_hex(c);
                break;
            case 2:
                e = p(c);
                break
        }
        if (a.prec >= 0) {
            a.filter = " ";
            d = a.prec - e.length | 0;
            c = d > 0 ? "0".repeat(d) + e : e
        } else c = e;
        return o(a, c)
    }

    function r(a, b) {
        a = n(a);
        var c = a.prec < 0 ? 6 : a.prec,
            d = b < 0 ? (a.sign = -1, -b) : b;
        b = "";
        if (isNaN(d)) b = "nan", a.filter = " ";
        else if (isFinite(d)) {
            var e = a.conv;
            switch (e) {
                case "e":
                    b = d.toExponential(c);
                    e = b.length;
                    b[e - 3 | 0] === "e" && (b = b.slice(0, e - 1 | 0) + ("0" + b.slice(e - 1 | 0)));
                    break;
                case "f":
                    b = d.toFixed(c);
                    break;
                case "g":
                    var f = c !== 0 ? c : 1;
                    b = d.toExponential(f - 1 | 0);
                    e = b.indexOf("e");
                    c = Number(b.slice(e + 1 | 0)) | 0;
                    if (c < -4 || d >= 1e21 || d.toFixed().length > f) {
                        var g = e - 1 | 0;
                        while (b[g] === "0") g = g - 1 | 0;
                        b[g] === "." && (g = g - 1 | 0);
                        b = b.slice(0, g + 1 | 0) + b.slice(e);
                        g = b.length;
                        b[g - 3 | 0] === "e" && (b = b.slice(0, g - 1 | 0) + ("0" + b.slice(g - 1 | 0)))
                    } else {
                        var h = f;
                        if (c < 0) h = h - (c + 1 | 0) | 0, b = d.toFixed(h);
                        else
                            while (function() {
                                    b = d.toFixed(h);
                                    return b.length > (f + 1 | 0)
                                }()) h = h - 1 | 0;
                        if (h !== 0) {
                            e = b.length - 1 | 0;
                            while (b[e] === "0") e = e - 1 | 0;
                            b[e] === "." && (e = e - 1 | 0);
                            b = b.slice(0, e + 1 | 0)
                        }
                    }
                    break;
                default:
            }
        } else b = "inf", a.filter = " ";
        return o(a, b)
    }
    var s = function(a, b, c) {
            if (!isFinite(a)) return isNaN(a) ? "nan" : a > 0 ? "infinity" : "-infinity";
            var d = a == 0 && 1 / a == -Infinity ? 1 : a >= 0 ? 0 : 1;
            d && (a = -a);
            var e = 0;
            if (!(a == 0))
                if (a < 1)
                    while (a < 1 && e > -1022) a *= 2, e--;
                else
                    while (a >= 2) a /= 2, e++;
            var f = e < 0 ? "" : "+",
                g = "";
            if (d) g = "-";
            else switch (c) {
                case 43:
                    g = "+";
                    break;
                case 32:
                    g = " ";
                    break;
                default:
                    break
            }
            if (b >= 0 && b < 13) {
                d = Math.pow(2, b * 4);
                a = Math.round(a * d) / d
            }
            c = a.toString(16);
            if (b >= 0) {
                d = c.indexOf(".");
                if (d < 0) c += "." + "0".repeat(b);
                else {
                    a = d + 1 + b;
                    c.length < a ? c += "0".repeat(a - c.length) : c = c.substr(0, a)
                }
            }
            return g + "0x" + c + "p" + f + e.toString(10)
        },
        t = function(a, b) {
            var c = +a;
            if (a.length > 0 && c === c) return c;
            a = a.replace(/_/g, "");
            c = +a;
            if (a.length > 0 && c === c || /^[+-]?nan$/i.test(a)) return c;
            var d = /^ *([+-]?)0x([0-9a-f]+)\.?([0-9a-f]*)p([+-]?[0-9]+)/i.exec(a);
            if (d) {
                var e = d[3].replace(/0+$/, ""),
                    f = parseInt(d[1] + d[2] + e, 16);
                d = (d[4] | 0) - 4 * e.length;
                c = f * Math.pow(2, d);
                return c
            }
            if (/^\+?inf(inity)?$/i.test(a)) return Infinity;
            if (/^-inf(inity)?$/i.test(a)) return -Infinity;
            throw b
        };

    function u(a) {
        return t(a, {
            RE_EXN_ID: "Failure",
            _1: "float_of_string"
        })
    }
    var v = d,
        w = d,
        x = a,
        y = a;
    f.caml_format_float = r;
    f.caml_hexstring_of_float = s;
    f.caml_format_int = d;
    f.caml_nativeint_format = v;
    f.caml_int32_format = w;
    f.caml_float_of_string = u;
    f.caml_int64_format = e;
    f.caml_int_of_string = a;
    f.caml_int32_of_string = x;
    f.caml_int64_of_string = c;
    f.caml_nativeint_of_string = y
}), null);
__d("bs_caml_exceptions", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {
        contents: 0
    };

    function a(a) {
        g.contents = g.contents + 1 | 0;
        return a + ("/" + g.contents)
    }

    function b(a) {
        if (a == null) return !1;
        else return typeof a.RE_EXN_ID === "string"
    }

    function c(a) {
        return a.RE_EXN_ID
    }
    f.id = g;
    f.create = a;
    f.caml_is_extension = b;
    f.caml_exn_slot_name = c
}), null);
__d("bs_caml_option", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.BS_PRIVATE_NESTED_SOME_NONE !== void 0
    }

    function g(a) {
        if (a === void 0) return {
            BS_PRIVATE_NESTED_SOME_NONE: 0
        };
        else if (a !== null && a.BS_PRIVATE_NESTED_SOME_NONE !== void 0) return {
            BS_PRIVATE_NESTED_SOME_NONE: a.BS_PRIVATE_NESTED_SOME_NONE + 1 | 0
        };
        else return a
    }

    function b(a) {
        if (a == null) return;
        else return g(a)
    }

    function c(a) {
        if (a === void 0) return;
        else return g(a)
    }

    function d(a) {
        if (a === null) return;
        else return g(a)
    }

    function h(a) {
        if (!(a !== null && a.BS_PRIVATE_NESTED_SOME_NONE !== void 0)) return a;
        a = a.BS_PRIVATE_NESTED_SOME_NONE;
        if (a === 0) return;
        else return {
            BS_PRIVATE_NESTED_SOME_NONE: a - 1 | 0
        }
    }

    function e(a) {
        if (a === void 0) return;
        else return h(a)
    }

    function i(a) {
        if (a !== void 0) return a.VAL;
        else return a
    }
    f.nullable_to_opt = b;
    f.undefined_to_opt = c;
    f.null_to_opt = d;
    f.valFromOption = h;
    f.some = g;
    f.isNested = a;
    f.option_get = e;
    f.option_unwrap = i
}), null);
__d("bs_caml_js_exceptions", ["bs_caml_exceptions", "bs_caml_option"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("bs_caml_exceptions").create("Caml_js_exceptions.Error");

    function a(a) {
        if (b("bs_caml_exceptions").caml_is_extension(a)) return a;
        else return {
            RE_EXN_ID: g,
            _1: a
        }
    }

    function c(a) {
        if (a.RE_EXN_ID === g) return b("bs_caml_option").some(a._1)
    }
    f.$$Error = g;
    f.internalToOCamlException = a;
    f.caml_as_js_exn = c
}), null);
__d("bs_int64", ["bs_caml", "bs_caml_format", "bs_caml_int64", "bs_caml_js_exceptions"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h;

    function a(a) {
        return (g || (g = b("bs_caml_int64"))).sub(a, g.one)
    }

    function c(a) {
        if ((h || (h = b("bs_caml"))).i64_ge(a, (g || (g = b("bs_caml_int64"))).zero)) return a;
        else return (g || (g = b("bs_caml_int64"))).neg(a)
    }

    function d(a) {
        return (g || (g = b("bs_caml_int64"))).xor(a, g.neg_one)
    }

    function e(a) {
        try {
            return b("bs_caml_format").caml_int64_of_string(a)
        } catch (c) {
            a = b("bs_caml_js_exceptions").internalToOCamlException(c);
            if (a.RE_EXN_ID === "Failure") return;
            throw a
        }
    }
    var i = (g || (g = b("bs_caml_int64"))).compare;

    function j(a, c) {
        return (g || (g = b("bs_caml_int64"))).compare(a, c) === 0
    }
    var k = g.zero,
        l = g.one,
        m = g.neg_one,
        n = g.succ,
        o = g.max_int,
        p = g.min_int,
        q = g.to_string;
    f.zero = k;
    f.one = l;
    f.minus_one = m;
    f.succ = n;
    f.pred = a;
    f.abs = c;
    f.max_int = o;
    f.min_int = p;
    f.lognot = d;
    f.of_string_opt = e;
    f.to_string = q;
    f.compare = i;
    f.equal = j
}), null);
__d("I64", ["bs_caml", "bs_caml_format", "bs_caml_int64", "bs_int64", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a) {
        return function() {
            var b = a.apply(void 0, arguments);
            b._tag || (b._tag = "i64");
            return b
        }
    }

    function b(a) {
        return function() {
            var b = a.apply(void 0, arguments);
            b != null && !b._tag && (b._tag = "i64");
            return b
        }
    }
    f = a((h || (h = c("bs_caml_int64"))).mk);
    var j = a(h.succ),
        k = a(function() {
            return (h || (h = c("bs_caml_int64"))).min_int
        })(),
        l = a(function() {
            return (h || (h = c("bs_caml_int64"))).max_int
        })(),
        m = a(function() {
            return (h || (h = c("bs_caml_int64"))).one
        })(),
        n = a(function() {
            return (h || (h = c("bs_caml_int64"))).zero
        })(),
        o = a(function() {
            return (h || (h = c("bs_caml_int64"))).neg_one
        })(),
        p = a(h.of_int32),
        q = a(h.add),
        r = a(h.neg),
        s = a(h.sub),
        t = a(h.lsl_),
        u = a(h.lsr_),
        v = a(h.asr_),
        w = a(h.mul),
        x = a(h.xor),
        y = a(h.or_),
        z = a(h.and_),
        A = a(h.of_float),
        B = a(h.div),
        C = a(h.mod_),
        D = a(function() {
            return c("bs_int64").minus_one
        })(),
        E = a(c("bs_int64").abs),
        F = a(c("bs_int64").lognot);
    b = b(c("bs_int64").of_string_opt);
    var G, H;
    if (typeof BigInt === "function") {
        var I = BigInt(32),
            J = BigInt(4294967295);
        G = function(a) {
            return BigInt.asIntN(64, (BigInt(a[0]) << I) + BigInt(a[1])).toString()
        };
        H = function(a) {
            a = BigInt.asIntN(64, BigInt(a));
            a = [Number(a >> I), Number(a & J)];
            a._tag = "i64";
            return a
        }
    } else G = (h || (h = c("bs_caml_int64"))).to_string, H = a(c("bs_caml_format").caml_int64_of_string);
    G = G;
    H = H;
    var K = a((i || (i = c("bs_caml"))).i64_max);
    a = a(i.i64_min);

    function L(a) {
        if (Array.isArray(a) && a.length === 2) {
            var b = a[0];
            a = a[1];
            if (typeof b === "number" && Number.isInteger(b) && typeof a === "number" && Number.isInteger(a)) {
                b = [b, a];
                b._tag = "i64";
                return b
            }
        }
        return void 0
    }

    function d(a) {
        return c("nullthrows")(L(a))
    }

    function e(a) {
        return (a == null ? void 0 : a._tag) === "i64"
    }
    g.mk = f;
    g.succ = j;
    g.min_int = k;
    g.max_int = l;
    g.one = m;
    g.zero = n;
    g.neg_one = o;
    g.of_int32 = p;
    g.to_int32 = h.to_int32;
    g.add = q;
    g.neg = r;
    g.sub = s;
    g.lsl_ = t;
    g.lsr_ = u;
    g.asr_ = v;
    g.is_zero = h.is_zero;
    g.mul = w;
    g.xor = x;
    g.or_ = y;
    g.and_ = z;
    g.to_float = h.to_float;
    g.of_float = A;
    g.div = B;
    g.mod_ = C;
    g.compare = h.compare;
    g.minus_one = D;
    g.abs = E;
    g.lognot = F;
    g.of_string_opt = b;
    g.equal = c("bs_int64").equal;
    g.to_string = G;
    g.of_string = H;
    g.gt = i.i64_gt;
    g.ge = i.i64_ge;
    g.lt = i.i64_lt;
    g.le = i.i64_le;
    g.max = K;
    g.min = a;
    g.cast = L;
    g.castExn = d;
    g.isI64 = e
}), 98);
__d("LSAppendDataTraceAddon", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return c[0] = b.i64.of_float(Date.now()), b.db.table(154).add({
                addonId: void 0,
                traceId: a[0],
                timestampMs: c[0],
                checkPointId: a[1],
                syncChannel: a[2],
                errorMessage: a[3],
                tags: a[4]
            })
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSDataTraceAppendDataTraceAddonStoredProcedure";
    e.exports = a
}), null);
__d("LSArrayGetObjectAt", ["I64", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a, c, e, f) {
        return (i || (i = b("Promise"))).resolve([e[(h || (h = d("I64"))).to_int32(f)], e])
    }
    g.call = a
}), 98);
__d("LSVec", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {
        tag: {
            value: "ls-array"
        }
    };

    function h(a) {
        return Object.defineProperties([].concat(a), g)
    }

    function a(a) {
        return h(a)
    }

    function b(a) {
        return Array.from(a)
    }
    c = {
        from: h,
        ofArray: a,
        toArray: b
    };
    f["default"] = c
}), 66);
__d("LSDict", ["I64", "LSVec", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a) {
        if (a == null) return void 0;
        var b = (h || (h = d("I64"))).cast(a);
        return b != null ? JSON.stringify([(h || (h = d("I64"))).to_string(b)]) : JSON.stringify(a)
    }

    function j(a) {
        if (a == null) return void 0;
        a = JSON.parse(a);
        return Array.isArray(a) ? (h || (h = d("I64"))).of_string(a[0]) : a
    }
    a = function() {
        function a(a) {
            this.size = 0;
            var b = new Map(Array.from(a || []).map(function(a) {
                var b = a[0];
                a = a[1];
                return b == null ? null : [i(b), a]
            }).filter(Boolean));
            this.$1 = b;
            Object.defineProperties(this, {
                size: {
                    get: function() {
                        return b.size
                    }
                }
            })
        }
        var b = a.prototype;
        b.get = function(a) {
            return a == null ? void 0 : this.$1.get(i(a))
        };
        b.set = function(a, b) {
            if (a == null) return this;
            this.$1.set(i(a), b);
            return this
        };
        b["delete"] = function(a) {
            return a == null ? !1 : this.$1["delete"](i(a))
        };
        b.clear = function() {
            return this.$1.clear()
        };
        b.forEach = function(a) {
            var b = this;
            this.$1.forEach(function(c, d) {
                return a(c, j(d), b)
            })
        };
        b.has = function(a) {
            return a == null ? !1 : this.$1.has(i(a))
        };
        b.entries = function*() {
            for (var a of this.$1.entries()) {
                var b = a[0],
                    c = a[1];
                yield [j(b), c]
            }
        };
        b.keys = function() {
            return c("LSVec").from(Array.from(this.$1.keys()).map(function(a) {
                return j(a)
            }))
        };
        b.values = function() {
            return this.$1.values()
        };
        a.fromObject = function(b) {
            return new a(Object.entries(b))
        };
        a.shapeToRecord = function(a) {
            return Array.from(a.entries()).reduce(function(a, b) {
                var d = b[0];
                b = b[1];
                if (typeof d !== "string") throw c("unrecoverableViolation")("Cannot convert dicts with mixed keys to records", "messenger_web_product");
                return babelHelpers["extends"]({}, a, (a = {}, a[d] = b, a))
            }, {})
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("LSFlushSyncTrace", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(153).fetch(), function(c) {
                return b.i64.eq(c.traceType, b.i64.cast([0, 2])) && c.contextOne === a[1] && c.contextThree === a[0]
            }), function(a) {
                var b = a.update;
                a.item;
                return b({
                    shouldFlush: !0
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSDataTraceFlushSyncTraceStoredProcedure";
    e.exports = a
}), null);
__d("LSExecuteFinallyBlockForSyncTransaction", ["LSFlushSyncTrace"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.sequence([function(c) {
                return b.forEach(b.filter(b.db.table(3).fetch([
                    [
                        ["", a[1]]
                    ]
                ]), function(c) {
                    return c.taskQueueName === "" && b.i64.eq(c.syncDatabaseId, a[1]) && b.i64.eq(c.epochId, a[2])
                }), function(c) {
                    var d = c.update;
                    c = c.item;
                    return d({
                        epochId: !a[0] && b.i64.eq(c.failureCount, b.i64.cast([-1, 4294967295])) ? c.epochId : void 0,
                        failureCount: b.i64.eq(c.failureCount, b.i64.cast([-1, 4294967295])) ? b.i64.cast([0, 0]) : b.i64.add(c.failureCount, b.i64.cast([0, 1]))
                    })
                })
            }, function(a) {
                return b.resolve()
            }])
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSCoreExecuteFinallyBlockForSyncTransactionStoredProcedure";
    e.exports = a
}), null);
__d("LSLogEventAnnotate.nop", ["FBLogger", "I64", "LSDict", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    a = function(a, e, f, g, j, k) {
        a = k.has("error_msg");
        a && c("FBLogger")("ls_web_init").warn("LS log event for logCategory %s, logEventId %s, logEventInstanceId %s, annotations %s", (i || (i = d("I64"))).to_string(f), i.to_string(g), i.to_string(j), JSON.stringify(c("LSDict").shapeToRecord(k)));
        return (h || (h = b("Promise"))).resolve()
    };
    g["default"] = a
}), 98);
__d("LSExecuteFirstBlockForSyncTransaction", ["LSAppendDataTraceAddon", "LSArrayGetObjectAt", "LSLogEventAnnotate.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(f) {
            return c.sequence([function(a) {
                return c.resolve()
            }, function(e) {
                return c.filter(c.db.table(3).fetch([
                    [
                        ["", a[0]]
                    ]
                ]), function(b) {
                    return b.taskQueueName === "" && c.i64.eq(b.syncDatabaseId, a[0]) && c.i64.eq(b.epochId, a[1])
                }).next().then(function(e, f) {
                    f = e.done;
                    e = e.value;
                    return f ? c.sequence([function(e) {
                        return d[2] = ",",
                            function(a) {
                                c.logger(a).mustfix(a)
                            }(["epoch mismatch", d[2], " db_type=", d[2], c.i64.to_string(a[0]), d[2], " previous_cursor=", d[2], a[2] == null ? "null" : a[2], d[2], " next_cursor=", d[2], a[3]].join("")), d[3] = new c.Map(), d[3].set("database_id", a[0]), d[3].set("epoch_id", a[1]), d[3].set("sync_status", a[4]), d[3].set("next_cursor", a[3]), d[3].set("error_msg", "epoch mismatch"), a[9] ? d[4] = !1 : d[4] = !0, d[4] ? c.resolve() : (d[6] = a[9].keys(), d[7] = c.i64.of_int32(d[6].length), c.i64.gt(d[7], c.i64.cast([0, 0])) ? c.loopAsync(d[7], function(e) {
                                return d[8] = e, c.sequence([function(a) {
                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[6], d[8]).then(function(a) {
                                        return a = a, d[9] = a[0], d[10] = a[1], a
                                    })
                                }, function(b) {
                                    return d[11] = a[9].get(d[9]), a[9], d[3].set(d[9], d[11])
                                }])
                            }) : c.resolve())
                    }, function(a) {
                        return c.nativeOperation(b("LSLogEventAnnotate.nop"), c.i64.cast([0, 16]), c.i64.cast([0, 35]), c.i64.cast([0, 0]), d[3])
                    }, function(a) {
                        return d[5] = !1, d[0] = d[5]
                    }]) : (e.item, c.sequence([function(e) {
                        return c.filter(c.db.table(1).fetch([
                            [
                                [a[0]]
                            ]
                        ]), function(b) {
                            return c.i64.eq(b.groupId, a[0]) && b.currentCursor === a[2]
                        }).next().then(function(e, f) {
                            f = e.done;
                            e = e.value;
                            return f ? c.sequence([function(e) {
                                return d[4] = ",",
                                    function(a) {
                                        c.logger(a).mustfix(a)
                                    }(["cursor mismatch", d[4], " db_type=", d[4], c.i64.to_string(a[0]), d[4], " previous_cursor=", d[4], a[2] == null ? "null" : a[2], d[4], " next_cursor=", d[4], a[3]].join("")), d[5] = new c.Map(), d[5].set("database_id", a[0]), d[5].set("epoch_id", a[1]), d[5].set("sync_status", a[4]), d[5].set("next_cursor", a[3]), d[5].set("error_msg", "cursor mismatch"), a[9] ? d[6] = !1 : d[6] = !0, d[6] ? c.resolve() : (d[8] = a[9].keys(), d[9] = c.i64.of_int32(d[8].length), c.i64.gt(d[9], c.i64.cast([0, 0])) ? c.loopAsync(d[9], function(e) {
                                        return d[10] = e, c.sequence([function(a) {
                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[8], d[10]).then(function(a) {
                                                return a = a, d[11] = a[0], d[12] = a[1], a
                                            })
                                        }, function(b) {
                                            return d[13] = a[9].get(d[11]), a[9], d[5].set(d[11], d[13])
                                        }])
                                    }) : c.resolve())
                            }, function(a) {
                                return c.nativeOperation(b("LSLogEventAnnotate.nop"), c.i64.cast([0, 16]), c.i64.cast([0, 35]), c.i64.cast([0, 0]), d[5])
                            }, function(a) {
                                return d[7] = !1, d[2] = d[7]
                            }]) : (e.item, c.sequence([function(b) {
                                return d[4] = c.i64.of_float(Date.now()), d[5] = c.i64.of_float(Date.now()), c.forEach(c.db.table(1).fetch([
                                    [
                                        [a[0]]
                                    ]
                                ]), function(b) {
                                    var e = b.update;
                                    b.item;
                                    return e({
                                        currentCursor: a[3],
                                        syncStatus: a[4],
                                        sendSyncParams: a[5],
                                        minTimeToSyncTimestampMs: c.i64.eq(a[6], c.i64.cast([0, 0])) ? c.i64.cast([0, 0]) : c.i64.add(d[4], a[6]),
                                        canIgnoreTimestamp: a[7],
                                        syncChannel: a[8],
                                        lastSyncCompletedTimestampMs: d[5]
                                    })
                                })
                            }, function(b) {
                                return c.forEach(c.db.table(3).fetch([
                                    [
                                        ["", a[0]]
                                    ]
                                ]), function(a) {
                                    var b = a.update;
                                    a.item;
                                    return b({
                                        failureCount: c.i64.cast([-1, 4294967295])
                                    })
                                })
                            }, function(e) {
                                return d[6] = new c.Map(), d[6].set("database_id", a[0]), d[6].set("epoch_id", a[1]), d[6].set("sync_status", a[4]), d[6].set("next_cursor", a[3]), a[9] ? d[7] = !1 : d[7] = !0, d[7] ? c.resolve() : (d[9] = a[9].keys(), d[10] = c.i64.of_int32(d[9].length), c.i64.gt(d[10], c.i64.cast([0, 0])) ? c.loopAsync(d[10], function(e) {
                                    return d[11] = e, c.sequence([function(a) {
                                        return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[9], d[11]).then(function(a) {
                                            return a = a, d[12] = a[0], d[13] = a[1], a
                                        })
                                    }, function(b) {
                                        return d[14] = a[9].get(d[12]), a[9], d[6].set(d[12], d[14])
                                    }])
                                }) : c.resolve())
                            }, function(a) {
                                return c.nativeOperation(b("LSLogEventAnnotate.nop"), c.i64.cast([0, 16]), c.i64.cast([0, 35]), c.i64.cast([0, 0]), d[6])
                            }, function(a) {
                                return d[8] = !0, d[2] = d[8]
                            }]))
                        })
                    }, function(a) {
                        return d[0] = d[2]
                    }]))
                })
            }, function(a) {
                return e[0] = d[0]
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSCoreExecuteFirstBlockForSyncTransactionStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("CometTextTypography", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            apple: {
                MozOsxFontSmoothing: "xlh3980",
                WebkitFontSmoothing: "xvmahel",
                fontFamily: "x1n0sxbx",
                $$css: !0
            },
            "default": {
                fontFamily: "x10flsy6",
                $$css: !0
            },
            segoe: {
                fontFamily: "x1xmvt09",
                $$css: !0
            }
        },
        i = {
            body1: {
                fontFamily: h["default"],
                fontSize: 20,
                fontWeight: "normal",
                lineHeight: 24,
                offsets: [4, 5]
            },
            body2: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [3, 5]
            },
            body3: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [4, 5]
            },
            body4: {
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "normal",
                lineHeight: 16,
                offsets: [3, 4]
            },
            bodyLink1: {
                fontFamily: h["default"],
                fontSize: 20,
                fontWeight: "semibold",
                lineHeight: 24,
                offsets: [4, 5]
            },
            bodyLink2: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [3, 5]
            },
            bodyLink3: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            bodyLink4: {
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "semibold",
                lineHeight: 16,
                offsets: [3, 4]
            },
            button1: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [3, 5]
            },
            button2: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            entityHeaderHeadline1: {
                fontFamily: h["default"],
                fontSize: 32,
                fontWeight: "bold",
                lineHeight: 38,
                offsets: [7, 8]
            },
            entityHeaderHeadline2: {
                fontFamily: h["default"],
                fontSize: 28,
                fontWeight: "bold",
                lineHeight: 32,
                offsets: [5, 7]
            },
            entityHeaderMeta1: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "bold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            entityHeaderMeta2: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "bold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            headline3: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "medium",
                lineHeight: 20,
                offsets: [3, 5]
            },
            headline4: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "medium",
                lineHeight: 20,
                offsets: [4, 5]
            },
            headlineDeemphasized3: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [3, 5]
            },
            headlineDeemphasized4: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [4, 5]
            },
            headlineEmphasized1: {
                fontFamily: h["default"],
                fontSize: 24,
                fontWeight: "bold",
                lineHeight: 28,
                offsets: [5, 6]
            },
            headlineEmphasized2: {
                fontFamily: h["default"],
                fontSize: 20,
                fontWeight: "bold",
                lineHeight: 24,
                offsets: [4, 5]
            },
            headlineEmphasized3: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [3, 4]
            },
            headlineEmphasized4: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            meta1: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "semibold",
                lineHeight: 16,
                offsets: [3, 4]
            },
            meta2: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "semibold",
                lineHeight: 16,
                offsets: [3, 4]
            },
            meta3: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "normal",
                lineHeight: 16,
                offsets: [3, 4]
            },
            meta4: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 12,
                fontWeight: "normal",
                lineHeight: 16,
                offsets: [3, 4]
            }
        },
        j = [
            ["body1", [5, 5]],
            ["body2", [4, 4]],
            ["body3", [4, 4]],
            ["body4", [4, 3]],
            ["bodyLink1", [5, 5]],
            ["bodyLink2", [4, 4]],
            ["bodyLink3", [4, 4]],
            ["bodyLink4", [4, 3]],
            ["button1", [4, 4]],
            ["button2", [4, 4]],
            ["entityHeaderHeadline1", [8, 7]],
            ["entityHeaderHeadline2", [6, 6]],
            ["entityHeaderMeta1", [4, 4]],
            ["entityHeaderMeta2", [4, 4]],
            ["headline3", [4, 4]],
            ["headline4", [4, 4]],
            ["headlineDeemphasized3", [4, 4]],
            ["headlineDeemphasized4", [4, 4]],
            ["headlineEmphasized1", [6, 5]],
            ["headlineEmphasized2", [5, 5]],
            ["headlineEmphasized3", [4, 4]],
            ["headlineEmphasized4", [4, 4]],
            ["meta1", [4, 3]],
            ["meta2", [4, 3]],
            ["meta3", [4, 3]],
            ["meta4", [3, 3]]
        ],
        k = [
            ["body1", [5, 5]],
            ["body2", [4, 4]],
            ["body3", [5, 4]],
            ["body4", [4, 3]],
            ["bodyLink1", [6, 4]],
            ["bodyLink2", [4, 3]],
            ["bodyLink3", [5, 4]],
            ["bodyLink4", [4, 3]],
            ["button1", [4, 3]],
            ["button2", [5, 4]],
            ["entityHeaderHeadline1", [8, 7]],
            ["entityHeaderHeadline2", [7, 5]],
            ["entityHeaderMeta1", [5, 4]],
            ["entityHeaderMeta2", [5, 4]],
            ["headline3", [5, 3]],
            ["headline4", [5, 4]],
            ["headlineDeemphasized3", [5, 3]],
            ["headlineDeemphasized4", [5, 4]],
            ["headlineEmphasized1", [6, 5]],
            ["headlineEmphasized2", [6, 4]],
            ["headlineEmphasized3", [4, 3]],
            ["headlineEmphasized4", [5, 4]],
            ["meta1", [4, 3]],
            ["meta2", [4, 3]],
            ["meta3", [4, 3]],
            ["meta4", [4, 3]]
        ],
        l = [
            ["body1", [6, 4, 1]],
            ["body2", [5, 3, 1]],
            ["body3", [5, 4]],
            ["body4", [4, 3, 1]],
            ["bodyLink1", [6, 4, 1]],
            ["bodyLink2", [5, 3, 1]],
            ["bodyLink3", [5, 4]],
            ["bodyLink4", [4, 3, 1]],
            ["button1", [5, 3, 1]],
            ["button2", [5, 4]],
            ["entityHeaderHeadline1", [10, 6, 2]],
            ["entityHeaderHeadline2", [8, 5, 3]],
            ["entityHeaderMeta1", [5, 4, 1]],
            ["entityHeaderMeta2", [5, 4, 1]],
            ["headline3", [5, 3, 1]],
            ["headline4", [5, 4]],
            ["headlineDeemphasized3", [5, 3, 1]],
            ["headlineDeemphasized4", [5, 4]],
            ["headlineEmphasized1", [7, 4, 2]],
            ["headlineEmphasized2", [6, 4, 2]],
            ["headlineEmphasized3", [5, 3, 1]],
            ["headlineEmphasized4", [5, 4]],
            ["meta1", [4, 3, 1]],
            ["meta2", [4, 3, 1]],
            ["meta3", [4, 3, 1]],
            ["meta4", [4, 3]]
        ];

    function m() {
        if (c("UserAgent").isPlatform("Windows >= 6")) return {
            fontFamily: h.segoe,
            offsets: l
        };
        return c("UserAgent").isPlatform("Mac OS X >= 10.11") && !c("UserAgent").isBrowser("Firefox < 55") || c("UserAgent").isPlatform("iOS >= 9") ? {
            fontFamily: h.apple,
            offsets: c("UserAgent").isEngine("Gecko") ? k : j
        } : null
    }

    function a() {
        var a = babelHelpers["extends"]({}, i),
            b = m();
        if (b != null) {
            var c = b.fontFamily;
            b = b.offsets;
            b = new Map(b);
            b.forEach(function(b, d) {
                a[d] = babelHelpers["extends"]({}, a[d], {
                    fontFamily: c,
                    offsets: b
                })
            })
        }
        return a
    }
    b = a();
    g["default"] = b
}), 98);
__d("FDSTextContext", ["CometTextTypography", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    e = h;
    var j = e.useContext,
        k = e.useMemo,
        l = i.createContext(null);

    function a() {
        return j(l)
    }
    var m = {
        disabled: "disabledButton",
        highlight: "primaryDeemphasizedButton",
        secondary: "secondaryButton",
        white: "primaryButton"
    };

    function n(a, b) {
        return b ? (b = m[a]) != null ? b : a : a
    }

    function b(a) {
        var b = a.children,
            c = a.color;
        a = a.type;
        if (a == null) return i.jsx(l.Provider, {
            value: null,
            children: typeof b === "function" ? b(null) : b
        });
        else return i.jsx(o, {
            children: b,
            color: c,
            type: a
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";

    function o(a) {
        var b = a.children,
            d = a.color,
            e = a.type;
        a = c("CometTextTypography")[e].defaultColor;
        a = a === void 0 ? "primary" : a;
        var f = n((d = d) != null ? d : a, e === "button1" || e === "button2");
        d = k(function() {
            return {
                color: f,
                type: e
            }
        }, [f, e]);
        return i.jsx(l.Provider, {
            value: d,
            children: typeof b === "function" ? b(d) : b
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";
    g.useFDSTextContext = a;
    g.FDSTextContextProvider = b;
    g.FDSTextContextProviderNonNull = o
}), 98);
__d("BaseTextContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    c = h;
    var j = c.useContext,
        k = c.useMemo,
        l = i.createContext(null);

    function a(a) {
        var b = a.children,
            c = a.nested;
        a = k(function() {
            return {
                nested: c
            }
        }, [c]);
        return i.jsx(l.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return j(l)
    }
    g.BaseTextContextProvider = a;
    g.useBaseTextContext = b
}), 98);
__d("XPlatReactUserAgent", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("UserAgent")
}), 98);
__d("BaseHeading.react", ["BaseHeadingContext", "BaseTextContext", "XPlatReactUserAgent", "gkx", "react", "react-strict-dom", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useContext,
        k = b.useMemo,
        l = c("XPlatReactUserAgent").isBrowser("Chrome < 83") || c("XPlatReactUserAgent").isBrowser("Safari < 14.1") || c("XPlatReactUserAgent").isBrowser("Firefox < 69"),
        m = {
            oldBrowsers: {
                boxShadow: "x59fq91 x1gnnqk1",
                $$css: !0
            },
            root: {
                color: "x1heor9g",
                fontSize: "x1qlqyl8",
                fontWeight: "x1pd3egz",
                outline: "x1a2a7pz",
                $$css: !0
            },
            rootGated: {
                boxShadow: "xpx8ijz xq7l91r x1gnnqk1",
                $$css: !0
            }
        },
        n = {
            1: d("react-strict-dom").html.h1,
            2: d("react-strict-dom").html.h2,
            3: d("react-strict-dom").html.h3,
            4: d("react-strict-dom").html.h4,
            5: d("react-strict-dom").html.h5,
            6: d("react-strict-dom").html.h6
        };
    e = i.forwardRef(a);

    function a(a, b) {
        var e = a.children,
            f = a.id,
            g = a.isPrimaryHeading,
            h = g === void 0 ? !1 : g;
        g = a.suppressHydrationWarning;
        var o = a.testid;
        o = a.xstyle;
        var p = j(c("BaseHeadingContext"));
        a = k(function() {
            if (h) return d("react-strict-dom").html.h1;
            var a = Math.max(Math.min(p, 6), 2);
            return n["" + a]
        }, [h, p]);
        if (a == null) throw c("unrecoverableViolation")("Failed to retrieve a heading tag, this should not be possible", "comet_ui");
        var q = d("BaseTextContext").useBaseTextContext();
        q = (q == null ? void 0 : q.nested) === !0;
        var r = c("gkx")("8029") ? [m.rootGated, l && m.oldBrowsers] : [];
        return i.jsx(a, {
            "data-testid": void 0,
            dir: q ? void 0 : "auto",
            id: f,
            ref: b,
            style: [m.root].concat(r, [
                [o]
            ]),
            suppressHydrationWarning: g,
            children: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = e;
    g["default"] = b
}), 98);
__d("stylex-compat", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a.$$css = !0;
        return a
    }
    f.makeNamespace = a
}), 66);
__d("BaseStyledButton.react", ["BaseRow.react", "BaseRowItem.react", "CometPressable.react", "react", "stylex", "stylex-compat"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useRef,
        l = .96,
        m = 10,
        n = {
            button: {
                boxSizing: "x9f619",
                display: "x3nfvp2",
                flexDirection: "xdt5ytf",
                justifyContent: "xl56j7k",
                position: "x1n2onr6",
                width: "xh8yej3",
                $$css: !0
            },
            content: {
                borderTopStartRadius: "xi112ho",
                borderTopEndRadius: "x17zwfj4",
                borderBottomEndRadius: "x585lrc",
                borderBottomStartRadius: "x1403ito",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxSizing: "x9f619",
                paddingEnd: "xn6708d",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            disabled: {
                backgroundColor: "xwcfey6",
                $$css: !0
            },
            item: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexShrink: "x2lah0s",
                marginEnd: "x1fbi1t2",
                marginStart: "xl8fo4v",
                $$css: !0
            },
            offset: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginEnd: "x1608yet",
                marginStart: "xljgi0e",
                width: "x1e0frkt",
                $$css: !0
            },
            paddingWide: {
                paddingEnd: "xbxaen2",
                paddingStart: "x1u72gb5",
                $$css: !0
            },
            sizeLargeItem: {
                marginEnd: "x185m5pd",
                marginStart: "xmly5ks",
                $$css: !0
            },
            sizeLargeOffset: {
                marginEnd: "x3fpzix",
                marginStart: "xxdpisx",
                $$css: !0
            }
        };
    b = j.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = a.addOnAbsolute,
            e = a.addOnEnd,
            f = a.addOnStart,
            g = a.content,
            i = a.contentXstyle,
            o = a.disabled,
            q = o === void 0 ? !1 : o;
        o = a.display;
        o = o === void 0 ? "inline" : o;
        var r = a.focusable,
            s = a.icon,
            t = a.id,
            u = a.linkProps,
            v = a.onFocusIn,
            w = a.onFocusOut,
            x = a.onHoverIn,
            y = a.onHoverOut,
            z = a.onPress,
            A = a.onPressIn,
            B = a.onPressOut,
            C = a.overlayHoveredStyle,
            D = a.overlayPressedStyle,
            E = a.padding,
            F = E === void 0 ? "normal" : E;
        E = a.size;
        var G = E === void 0 ? "medium" : E;
        E = a.suppressHydrationWarning;
        E = E === void 0 ? !1 : E;
        var H = a.testid;
        H = a.testOnly_pressed;
        H = H === void 0 ? !1 : H;
        var I = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnAbsolute", "addOnEnd", "addOnStart", "content", "contentXstyle", "disabled", "display", "focusable", "icon", "id", "linkProps", "onFocusIn", "onFocusOut", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "onPressOut", "overlayHoveredStyle", "overlayPressedStyle", "padding", "size", "suppressHydrationWarning", "testid", "testOnly_pressed", "xstyle"]);
        var J = k(null),
            K = function(a) {
                if (J.current != null) {
                    var b = J.current;
                    b instanceof HTMLDivElement && (b.style.transform = "scale(" + Math.max(l, (b.offsetWidth - m) / b.offsetWidth) + ")")
                }
                typeof A === "function" && A(a)
            },
            L = function(a) {
                if (J.current != null) {
                    var b = J.current;
                    b instanceof HTMLDivElement && (b.style.transform = "none")
                }
                typeof B === "function" && B(a)
            };
        I = p(I);
        var M = I[0],
            N = I[1],
            O = [n.item, G === "large" && n.sizeLargeItem];
        I = function(a) {
            a = a.overlay;
            return j.jsxs(c("BaseRow.react"), {
                align: "center",
                ref: J,
                role: "none",
                verticalAlign: "center",
                xstyle: [n.content, F === "wide" && n.paddingWide, q && n.disabled, N, i],
                children: [j.jsxs("div", {
                    className: (h || (h = c("stylex")))([n.offset, G === "large" && n.sizeLargeOffset]),
                    children: [f != null ? j.jsx(c("BaseRowItem.react"), {
                        role: "none",
                        useDeprecatedStyles: !0,
                        xstyle: O,
                        children: f
                    }) : s != null ? j.jsx(c("BaseRowItem.react"), {
                        role: "none",
                        useDeprecatedStyles: !0,
                        xstyle: O,
                        children: s
                    }) : null, g != null ? j.jsx(c("BaseRowItem.react"), {
                        role: "none",
                        useDeprecatedStyles: !0,
                        xstyle: O,
                        children: g
                    }) : null, e != null ? j.jsx(c("BaseRowItem.react"), {
                        role: "none",
                        useDeprecatedStyles: !0,
                        xstyle: O,
                        children: e
                    }) : null]
                }), a, d != null ? d : null]
            })
        };
        return j.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, a, {
            disabled: q,
            display: o,
            focusable: r,
            id: t,
            linkProps: u,
            onFocusIn: v,
            onFocusOut: w,
            onHoverIn: x,
            onHoverOut: y,
            onPress: z,
            onPressIn: K,
            onPressOut: L,
            overlayHoveredStyle: C,
            overlayPressedStyle: D,
            ref: b,
            suppressHydrationWarning: E,
            testOnly_pressed: H,
            testid: void 0,
            xstyle: [n.button, M],
            children: I
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    var o = new WeakMap();

    function p(a) {
        if (!a) return [{}, {}];
        var b = o.get(a);
        if (b != null) return b;
        b = (h || (h = c("stylex"))).compose(a);
        var e = b.alignSelf,
            f = b.cursor,
            g = b.flexBasis,
            i = b.flexGrow,
            j = b.flexShrink,
            k = b.height,
            l = b.justifySelf,
            m = b.margin,
            n = b.marginBottom,
            p = b.marginEnd,
            q = b.marginStart,
            r = b.marginTop,
            s = b.maxHeight,
            t = b.maxWidth,
            u = b.minHeight,
            v = b.minWidth,
            w = b.position,
            x = b.width;
        b = babelHelpers.objectWithoutPropertiesLoose(b, ["alignSelf", "cursor", "flexBasis", "flexGrow", "flexShrink", "height", "justifySelf", "margin", "marginBottom", "marginEnd", "marginStart", "marginTop", "maxHeight", "maxWidth", "minHeight", "minWidth", "position", "width"]);
        e = {
            alignSelf: e,
            cursor: f,
            flexBasis: g,
            flexGrow: i,
            flexShrink: j,
            height: k,
            justifySelf: l,
            margin: m,
            marginBottom: n,
            marginEnd: p,
            marginStart: q,
            marginTop: r,
            maxHeight: s,
            maxWidth: t,
            minHeight: u,
            minWidth: v,
            position: w,
            width: x
        };
        f = {};
        for (g in e) e[g] !== void 0 && (f[g] = e[g]);
        i = [d("stylex-compat").makeNamespace(f), d("stylex-compat").makeNamespace(b)];
        o.set(a, i);
        return i
    }
    g["default"] = e
}), 98);
__d("CSSUserAgentSupports", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        webkitLineClamp: function() {
            return !(c("UserAgent").isBrowser("IE") || c("UserAgent").isBrowser("Edge < 17") || c("UserAgent").isBrowser("Firefox < 68"))
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("CometDensityModeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = !1;
    c = a.createContext([b, function() {}]);
    e = c;
    g["default"] = e
}), 98);
__d("CometHeroInteractionContext", ["hero-tracing-placeholder"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("hero-tracing-placeholder").HeroInteractionContext
}), 98);
__d("CometLineClamp.react", ["CSSUserAgentSupports", "CometPlaceholder.react", "CometTextTypography", "FDSTextContext", "JSResourceForInteraction", "cr:2099", "lazyLoadComponent", "react", "stylex", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i,
        l = k.useCallback,
        m = k.useRef,
        n = k.useState;

    function a() {}
    b = (k = b("cr:2099")) != null ? k : {
        useTranslationKeyForTextParent: a
    };
    var o = b.useTranslationKeyForTextParent,
        p = c("JSResourceForInteraction")("CometTooltip_DEPRECATED.react").__setRef("CometLineClamp.react"),
        q = c("lazyLoadComponent")(p),
        r = c("CSSUserAgentSupports").webkitLineClamp(),
        s = {
            oneLine: {
                textOverflow: "xlyipyv",
                whiteSpace: "xuxw1ft",
                $$css: !0
            },
            root: {
                display: "x1lliihq",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x1n2onr6",
                $$css: !0
            }
        };
    k = j.forwardRef(e);

    function e(a, b) {
        var e = a.children,
            f = a.id,
            g = a.lines,
            i = a.testid,
            k = a.truncationTooltip;
        i = a.useAutomaticTextDirection;
        i = i === void 0 ? !1 : i;
        a = a.xstyle;
        var u = d("FDSTextContext").useFDSTextContext(),
            v = o(),
            w = n(!1),
            x = w[0],
            y = w[1],
            z = m(null);
        w = e;
        var A;
        if (g > 1)
            if (r) A = {
                WebkitBoxOrient: "vertical",
                WebkitLineClamp: g,
                display: "-webkit-box"
            };
            else {
                e = t(u == null ? void 0 : u.type);
                A = {
                    maxHeight: e * g + .1
                };
                u = {
                    maxHeight: "calc((100% - " + e * g + "px) * 999)",
                    top: e * (g - 1)
                };
                w = j.jsxs(j.Fragment, {
                    children: [w, j.jsx("span", {
                        "aria-hidden": !0,
                        className: "xds687c x6ikm8r x10wlt62 x10l6tqk",
                        style: u,
                        children: "\u2026"
                    })]
                })
            }
        e = function() {
            var a = z.current;
            if (a == null || g < 1) return;
            y(a.offsetWidth < a.scrollWidth || a.offsetHeight < a.scrollHeight)
        };
        u = l(function(a) {
            if (a == null || k == null) return;
            p.preload()
        }, [k]);
        b = c("useMergeRefs")(b, z, u);
        u = j.jsx("span", {
            className: (h || (h = c("stylex")))(s.root, g === 1 && s.oneLine, a),
            "data-testid": void 0,
            dir: i ? "auto" : void 0,
            id: f,
            onMouseEnter: k != null ? e : void 0,
            ref: b,
            style: A,
            children: w
        }, v);
        return x ? j.jsx(c("CometPlaceholder.react"), {
            fallback: u,
            children: j.jsx(q, {
                tooltip: k,
                children: u
            })
        }) : u
    }
    e.displayName = e.name + " [from " + f.id + "]";
    a = k;

    function t(a) {
        return a != null && a in c("CometTextTypography") ? c("CometTextTypography")[a].lineHeight : 16
    }
    g["default"] = a
}), 98);
__d("CometLinkTrackingUtils.facebook", ["ConstUriUtils", "isFacebookURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e) {
        if (a != null && a !== "#" && (e.length || b.length)) {
            var f = d("ConstUriUtils").getUri(a);
            if (f != null) {
                if (!c("isFacebookURI")(f)) return a;
                e.length && (f = f.addQueryParam("__cft__", e));
                b.length && f != null && (f = f.addQueryParam("__tn__", b.join("")));
                return f != null ? f.toString() : a
            }
        }
        return a
    }
    g.decorateHrefWithTrackingInfo = a
}), 98);
__d("FDSProgressRingUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c, d) {
        function e(a, b) {
            return 1 - 3 * b + 3 * a
        }

        function f(a, b) {
            return 3 * b - 6 * a
        }

        function g(a) {
            return 3 * a
        }

        function h(a, b, c) {
            return ((e(b, c) * a + f(b, c)) * a + g(b)) * a
        }

        function i(a, b, c) {
            return 3 * e(b, c) * a * a + 2 * f(b, c) * a + g(b)
        }

        function j(b) {
            var d = b;
            for (var e = 0; e < 4; ++e) {
                var f = i(d, a, c);
                if (f === 0) return d;
                var g = h(d, a, c) - b;
                d -= g / f
            }
            return d
        }
        return function(e) {
            return a === b && c === d ? e : h(j(e), b, d)
        }
    }

    function b(a) {
        switch (a) {
            case "dark":
                return {
                    backgroundColor: "var(--progress-ring-neutral-background)",
                    foregroundColor: "var(--progress-ring-neutral-foreground)"
                };
            case "light":
                return {
                    backgroundColor: "var(--progress-ring-on-media-background)",
                    foregroundColor: "var(--progress-ring-on-media-foreground)"
                };
            case "blue":
                return {
                    backgroundColor: "var(--progress-ring-blue-background)",
                    foregroundColor: "var(--progress-ring-blue-foreground)"
                };
            case "disabled_DEPRECATED":
            case "disabled":
                return {
                    backgroundColor: "var(--progress-ring-disabled-background)",
                    foregroundColor: "var(--progress-ring-disabled-foreground)"
                }
        }
    }
    f.getCubicBezierPercentageFunc = a;
    f.getRingColor = b
}), 66);
__d("CometProgressRingIndeterminate.react", ["ix", "BaseLoadingStateElement.react", "CometImageFromIXValue.react", "FDSProgressRingUtils", "gkx", "react", "stylex", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || d("react"),
        l = {
            foregroundCircle: {
                animationDuration: "x1c74tu6",
                animationFillMode: "x1u6ievf",
                animationIterationCount: "xa4qsjk",
                animationTimingFunction: "xuxiujg",
                transformOrigin: "x1bndym7",
                $$css: !0
            },
            foregroundCircle12: {
                animationName: "x1iqdq0d",
                $$css: !0
            },
            foregroundCircle16: {
                animationName: "x1koaglw",
                $$css: !0
            },
            foregroundCircle20: {
                animationName: "x16tkgvi",
                $$css: !0
            },
            foregroundCircle24: {
                animationName: "xiepp7r",
                $$css: !0
            },
            foregroundCircle32: {
                animationName: "x1pb3rhs",
                $$css: !0
            },
            foregroundCircle48: {
                animationName: "x1w90wak",
                $$css: !0
            },
            foregroundCircle60: {
                animationName: "x1jrcm85",
                $$css: !0
            },
            foregroundCircle72: {
                animationName: "xnw30k",
                $$css: !0
            },
            root: {
                display: "x78zum5",
                $$css: !0
            }
        },
        m = 2,
        n = "always-enable-animations";

    function a(a) {
        var b = a.color,
            e = a.isDecorative;
        e = e === void 0 ? !1 : e;
        var f = a.size,
            g = a.testid;
        g = a.xstyle;
        var h = a["aria-label"];
        a = a["aria-labelledby"];
        var j = d("FDSProgressRingUtils").getRingColor(b);
        j = j.foregroundColor;
        var p = (f - m) * Math.PI,
            q = c("useCurrentDisplayMode")();
        q = q === "dark";
        q = o(b, f, q ? "dark" : "light");
        return k.jsx(c("BaseLoadingStateElement.react"), {
            "aria-label": h,
            "aria-labelledby": a,
            isDecorative: e,
            testid: void 0,
            xstyle: [l.root, g],
            children: b === "dark" && !c("gkx")("6275") ? k.jsx("svg", {
                className: [n, "x1c74tu6 xa4qsjk x1kfoseq x1bndym7 x1u6ievf x1wnkzza"].join(" "),
                height: f,
                viewBox: "0 0 " + f + " " + f,
                width: f,
                children: k.jsx("circle", {
                    className: [n, (i || (i = c("stylex")))([l.foregroundCircle, f === 12 && l.foregroundCircle12, f === 16 && l.foregroundCircle16, f === 20 && l.foregroundCircle20, f === 24 && l.foregroundCircle24, f === 32 && l.foregroundCircle32, f === 48 && l.foregroundCircle48, f === 60 && l.foregroundCircle60, f === 72 && l.foregroundCircle72])].join(" "),
                    cx: f / 2,
                    cy: f / 2,
                    fill: "none",
                    r: (f - m) / 2,
                    stroke: j,
                    strokeDasharray: p,
                    strokeWidth: m
                })
            }) : k.jsx("div", {
                style: {
                    height: f,
                    width: f
                },
                children: k.jsx(c("CometImageFromIXValue.react"), {
                    source: q,
                    testid: void 0
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function o(a, b, c) {
        switch (b) {
            case 12:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876411");
                            case "disabled_DEPRECATED":
                                return h("1876443");
                            case "dark":
                                return h("1876427");
                            case "light":
                                return h("1876427");
                            default:
                                return h("1876427")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876419");
                            case "disabled_DEPRECATED":
                                return h("1876451");
                            case "dark":
                                return h("1876435");
                            case "light":
                                return h("1876427");
                            default:
                                return h("1876435")
                        }
                    default:
                        return h("1876435")
                }
            case 16:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876412");
                            case "disabled_DEPRECATED":
                                return h("1876444");
                            case "dark":
                                return h("1876428");
                            case "light":
                                return h("1876428");
                            default:
                                return h("1876428")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876420");
                            case "disabled_DEPRECATED":
                                return h("1876452");
                            case "dark":
                                return h("1876436");
                            case "light":
                                return h("1876428");
                            default:
                                return h("1876436")
                        }
                    default:
                        return h("1876436")
                }
            case 20:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876413");
                            case "disabled_DEPRECATED":
                                return h("1876445");
                            case "dark":
                                return h("1876429");
                            case "light":
                                return h("1876429");
                            default:
                                return h("1876429")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876421");
                            case "disabled_DEPRECATED":
                                return h("1876453");
                            case "dark":
                                return h("1876437");
                            case "light":
                                return h("1876429");
                            default:
                                return h("1876437")
                        }
                    default:
                        return h("1876437")
                }
            case 24:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876414");
                            case "disabled_DEPRECATED":
                                return h("1876446");
                            case "dark":
                                return h("1876430");
                            case "light":
                                return h("1876430");
                            default:
                                return h("1876430")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876422");
                            case "disabled_DEPRECATED":
                                return h("1876454");
                            case "dark":
                                return h("1876438");
                            case "light":
                                return h("1876430");
                            default:
                                return h("1876438")
                        }
                    default:
                        return h("1876438")
                }
            case 32:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876415");
                            case "disabled_DEPRECATED":
                                return h("1876447");
                            case "dark":
                                return h("1876431");
                            case "light":
                                return h("1876431");
                            default:
                                return h("1876431")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876423");
                            case "disabled_DEPRECATED":
                                return h("1876455");
                            case "dark":
                                return h("1876439");
                            case "light":
                                return h("1876431");
                            default:
                                return h("1876439")
                        }
                    default:
                        return h("1876439")
                }
            case 48:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876416");
                            case "disabled_DEPRECATED":
                                return h("1876448");
                            case "dark":
                                return h("1876432");
                            case "light":
                                return h("1876432");
                            default:
                                return h("1876432")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876424");
                            case "disabled_DEPRECATED":
                                return h("1876456");
                            case "dark":
                                return h("1876440");
                            case "light":
                                return h("1876432");
                            default:
                                return h("1876440")
                        }
                    default:
                        return h("1876440")
                }
            case 60:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1940508");
                            case "disabled_DEPRECATED":
                                return h("1940512");
                            case "dark":
                                return h("1940510");
                            case "light":
                                return h("1940510");
                            default:
                                return h("1940510")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1940509");
                            case "disabled_DEPRECATED":
                                return h("1940513");
                            case "dark":
                                return h("1940511");
                            case "light":
                                return h("1940510");
                            default:
                                return h("1940511")
                        }
                    default:
                        return h("1940511")
                }
            case 72:
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876418");
                            case "disabled_DEPRECATED":
                                return h("1876450");
                            case "dark":
                                return h("1876434");
                            case "light":
                                return h("1876434");
                            default:
                                return h("1876434")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876426");
                            case "disabled_DEPRECATED":
                                return h("1876458");
                            case "dark":
                                return h("1876442");
                            case "light":
                                return h("1876434");
                            default:
                                return h("1876442")
                        }
                    default:
                        return h("1876442")
                }
            default:
                return h("1876439")
        }
    }
    g["default"] = a
}), 98);
__d("CometTextLangContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(void 0);
    g["default"] = b
}), 98);
__d("EventListener", ["cr:5695"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:5695")
}), 98);
__d("EventListenerWWW", ["cr:1353359"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1353359")
}), 98);
__d("FDSTextImpl.react", ["BaseHeading.react", "BaseTextContext", "CometDensityModeContext", "CometLineClamp.react", "CometTextLangContext", "CometTextTypography", "FDSTextContext", "MetaConfig", "cr:2099", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useContext;

    function a() {
        return {}
    }
    b = (b = b("cr:2099")) != null ? b : {
        useTranslationKeyForTextParent: a
    };
    var l = b.useTranslationKeyForTextParent,
        m = {
            base: {
                maxWidth: "x193iq5w",
                minWidth: "xeuugli",
                wordBreak: "x13faqbe",
                wordWrap: "x1vvkbs",
                $$css: !0
            },
            block: {
                display: "x1lliihq",
                "::after_content": "x1s928wv",
                "::after_display": "xhkezso",
                "::after_height": "x1gmr53x",
                "::before_content": "x1cpjm7i",
                "::before_display": "x1fgarty",
                "::before_height": "x1943h6x",
                $$css: !0
            },
            heading: {
                maxWidth: "x193iq5w",
                minWidth: "xeuugli",
                $$css: !0
            },
            preserveNewLines: {
                whiteSpace: "x1fj9vlw",
                $$css: !0
            }
        },
        n = {
            center: {
                textAlign: "x2b8uid",
                $$css: !0
            },
            end: {
                textAlign: "xp4054r",
                $$css: !0
            },
            start: {
                textAlign: "x1yc453h",
                $$css: !0
            }
        },
        o = {
            blueLink: {
                color: "x1fey0fg",
                $$css: !0
            },
            disabled: {
                color: "x1dntmbh",
                $$css: !0
            },
            disabledButton: {
                color: "x1x80s81",
                $$css: !0
            },
            highlight: {
                color: "x1qq9wsj",
                $$css: !0
            },
            negative: {
                color: "x1a1m0xk",
                $$css: !0
            },
            placeholder: {
                color: "x12scifz",
                $$css: !0
            },
            positive: {
                color: "x6u5lvz",
                $$css: !0
            },
            primary: {
                color: "xzsf02u",
                $$css: !0
            },
            primaryButton: {
                color: "xtk6v10",
                $$css: !0
            },
            primaryDeemphasizedButton: {
                color: "x1mvi0mv",
                $$css: !0
            },
            primaryOnColor: {
                color: "x1ko2xvj",
                $$css: !0
            },
            primaryOnMedia: {
                color: "x17z8epw",
                $$css: !0
            },
            secondary: {
                color: "xi81zsa",
                $$css: !0
            },
            secondaryButton: {
                color: "x1dem4cn",
                $$css: !0
            },
            secondaryOnColor: {
                color: "xj0d7sl",
                $$css: !0
            },
            secondaryOnMedia: {
                color: "xkxfvhb",
                $$css: !0
            },
            selectedOption: {
                color: "x1qoxp87",
                $$css: !0
            },
            tertiary: {
                color: "x12scifz",
                $$css: !0
            },
            tooltip: {
                color: "xzsf02u",
                $$css: !0
            },
            white: {
                color: "x14ctfv",
                $$css: !0
            }
        },
        p = {
            12: {
                fontSize: "x1pg5gke",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            13: {
                fontSize: "x1nxh6w3",
                lineHeight: "x1sibtaa",
                $$css: !0
            },
            14: {
                fontSize: "x1f6kntn",
                lineHeight: "x1ruc54x",
                $$css: !0
            },
            15: {
                fontSize: "x6prxxf",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            16: {
                fontSize: "x1jchvi3",
                lineHeight: "x132q4wb",
                $$css: !0
            },
            17: {
                fontSize: "x1lkfr7t",
                lineHeight: "x1lbecb7",
                $$css: !0
            },
            20: {
                fontSize: "x1603h9y",
                lineHeight: "x1u7k74",
                $$css: !0
            },
            24: {
                fontSize: "xngnso2",
                lineHeight: "x1qb5hxa",
                $$css: !0
            },
            28: {
                fontSize: "x1q74xe4",
                lineHeight: "xyesn5m",
                $$css: !0
            },
            32: {
                fontSize: "x579bpy",
                lineHeight: "xjkpybl",
                $$css: !0
            }
        },
        q = {
            12: {
                fontSize: "x1pg5gke",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            13: {
                fontSize: "x1pg5gke",
                lineHeight: "x1sibtaa",
                $$css: !0
            },
            15: {
                fontSize: "x1f6kntn",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            17: {
                fontSize: "x1jchvi3",
                lineHeight: "x1lbecb7",
                $$css: !0
            },
            20: {
                fontSize: "x1603h9y",
                lineHeight: "x1u7k74",
                $$css: !0
            },
            24: {
                fontSize: "xngnso2",
                lineHeight: "x1qb5hxa",
                $$css: !0
            },
            28: {
                fontSize: "x1q74xe4",
                lineHeight: "xyesn5m",
                $$css: !0
            },
            32: {
                fontSize: "x579bpy",
                lineHeight: "xjkpybl",
                $$css: !0
            }
        },
        r = {
            bold: {
                fontWeight: "x1xlr1w8",
                $$css: !0
            },
            medium: {
                fontWeight: "xk50ysn",
                $$css: !0
            },
            normal: {
                fontWeight: "xo1l8bm",
                $$css: !0
            },
            semibold: {
                fontWeight: "x1s688f",
                $$css: !0
            }
        },
        s = {
            auto: {
                hyphens: "xkjl1po",
                $$css: !0
            },
            manual: {
                hyphens: "xxydokm",
                $$css: !0
            }
        },
        t = {
            0: {
                $$css: !0
            },
            1: {
                "::before_marginTop": "x1ckan80",
                $$css: !0
            },
            2: {
                "::before_marginTop": "x1s3etm8",
                $$css: !0
            },
            3: {
                "::before_marginTop": "x1tu3fi",
                $$css: !0
            },
            4: {
                "::before_marginTop": "x4zkp8e",
                $$css: !0
            },
            5: {
                "::before_marginTop": "xudqn12",
                $$css: !0
            },
            6: {
                "::before_marginTop": "xtoi2st",
                $$css: !0
            },
            7: {
                "::before_marginTop": "x14z4hjw",
                $$css: !0
            },
            8: {
                "::before_marginTop": "x1ill7wo",
                $$css: !0
            },
            9: {
                "::before_marginTop": "xhau9xz",
                $$css: !0
            },
            10: {
                "::before_marginTop": "x14qwyeo",
                $$css: !0
            }
        },
        u = {
            1: {
                "::after_marginBottom": "xo8pqpo",
                $$css: !0
            },
            2: {
                "::after_marginBottom": "xlf94lp",
                $$css: !0
            },
            3: {
                "::after_marginBottom": "x676frb",
                $$css: !0
            },
            4: {
                "::after_marginBottom": "x3x7a5m",
                $$css: !0
            },
            5: {
                "::after_marginBottom": "x41vudc",
                $$css: !0
            },
            6: {
                "::after_marginBottom": "xw06pyt",
                $$css: !0
            },
            7: {
                "::after_marginBottom": "x1g2y4wz",
                $$css: !0
            },
            8: {
                "::after_marginBottom": "x1x48ksl",
                $$css: !0
            },
            9: {
                "::after_marginBottom": "x1guzi96",
                $$css: !0
            },
            10: {
                "::after_marginBottom": "x1y9wsrc",
                $$css: !0
            }
        },
        v = {
            1: {
                paddingBottom: "x1j85h84",
                $$css: !0
            },
            2: {
                paddingBottom: "x1120s5i",
                $$css: !0
            },
            3: {
                paddingBottom: "xg8j3zb",
                $$css: !0
            }
        };
    a = j.forwardRef(e);

    function e(a, b) {
        var e = a.align,
            f = e === void 0 ? "auto" : e,
            g = a.children;
        e = a.color;
        var i = a.dir,
            o = i === void 0 ? "auto" : i;
        i = a.hyphens;
        var x = i === void 0 ? "none" : i,
            y = a.id;
        i = a.isPrimaryHeading;
        i = i === void 0 ? !1 : i;
        var z = a.isSemanticHeading;
        z = z === void 0 ? !1 : z;
        var A = a.numberOfLines,
            B = a.preserveNewLines,
            C = B === void 0 ? !1 : B,
            D = a.suppressHydrationWarning;
        B = a.testid;
        var E = a.truncationTooltip;
        B = a.type;
        a = k(c("CometDensityModeContext"));
        var F = a[0],
            G = k(c("CometTextLangContext"));
        a = c("CometTextTypography")[B];
        var H = a.fontFamily,
            I = a.fontSize,
            J = a.fontWeight,
            K = J === void 0 ? "normal" : J;
        J = a.offsets;
        var L = J === void 0 ? [0, 0] : J,
            M = L.length === 3 ? L[2] : 0,
            N = A != null ? L[1] + M : L[1];
        a = d("BaseTextContext").useBaseTextContext();
        var O = (a == null ? void 0 : a.nested) === !0,
            P = l();
        J = j.jsx(d("BaseTextContext").BaseTextContextProvider, {
            nested: !0,
            children: j.jsx(d("FDSTextContext").FDSTextContextProviderNonNull, {
                color: e,
                type: B,
                children: function(a) {
                    a = a.color;
                    return j.jsx("span", {
                        className: (h || (h = c("stylex")))(m.base, H, !O && m.block, !O && t[L[0]], !O && u[N], F ? q[I] : p[I], r[K], w(a), f !== "auto" && n[f], x !== "none" && s[x], C && m.preserveNewLines),
                        "data-testid": void 0,
                        dir: O ? void 0 : o,
                        id: y,
                        lang: G,
                        ref: b,
                        suppressHydrationWarning: D,
                        children: A != null ? j.jsx(c("CometLineClamp.react"), {
                            lines: A,
                            truncationTooltip: E,
                            xstyle: M !== 0 && v[M],
                            children: g
                        }) : g
                    }, P)
                }
            })
        });
        return z || i ? j.jsx(c("BaseHeading.react"), {
            isPrimaryHeading: i,
            xstyle: m.heading,
            children: J
        }) : J
    }
    e.displayName = e.name + " [from " + f.id + "]";
    b = a;

    function w(a) {
        return a === "highlight" && c("MetaConfig")._("73") ? o.blueLink : o[a]
    }
    g["default"] = b
}), 98);
__d("ReactDOM.classic", ["cr:5277"], (function(a, b, c, d, e, f) {
    e.exports = b("cr:5277")
}), null);
__d("ReactDOM.classic.prod-or-profiling", ["cr:5278"], (function(a, b, c, d, e, f) {
    e.exports = b("cr:5278")
}), null);
__d("ReactDOMCompatibilityLayer", ["ReactDOM"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = typeof WeakMap === "function" ? new WeakMap() : new Map();

    function a(a, b) {
        var c = h.get(b);
        c == null && (c = d("ReactDOM").createRoot(b), h.set(b, c));
        b = null;
        var e = a.props.ref;
        d("ReactDOM").flushSync(function() {
            var d;
            return (d = c) == null ? void 0 : d.render(typeof a.type === "string" || ((d = a.type) == null ? void 0 : (d = d.prototype) == null ? void 0 : d.isReactComponent) ? babelHelpers["extends"]({}, a, {
                props: babelHelpers["extends"]({}, a.props, {
                    ref: function(a) {
                        typeof e === "function" ? e(a) : e != null && (e.current = a), b = a
                    }
                })
            }) : a)
        });
        return b
    }

    function b(a) {
        if (a == null) return !1;
        var b = h.get(a);
        if (b) {
            d("ReactDOM").flushSync(function() {
                b.unmount()
            });
            h["delete"](a);
            return !0
        }
        return !1
    }
    g.render_DEPRECATED = a;
    g.unmountComponentAtNode_DEPRECATED = b
}), 98);
__d("ReactFiberErrorDialog", ["cr:8909"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return b("cr:8909").showErrorDialog(a)
    }
    g.showErrorDialog = a
}), 98);
__d("ReactFiberErrorDialogWWW", ["ErrorNormalizeUtils", "ErrorPubSub", "LogHistory", "getErrorSafe"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a) {
        var c = a.componentStack,
            d = a.errorBoundary,
            e = b("getErrorSafe")(a.error);
        e.componentStack = a.componentStack;
        e.loggingSource = "REACT_FIBER";
        if (d != null && d.suppressReactDefaultErrorLoggingIUnderstandThisWillMakeBugsHarderToFindAndFix) return !1;
        a = b("LogHistory").getInstance("react_fiber_error_logger");
        a.error("capturedError", JSON.stringify({
            componentStack: c,
            error: {
                name: e.name,
                message: e.message,
                stack: e.stack
            }
        }));
        d = b("ErrorNormalizeUtils").normalizeError(e);
        (g || (g = b("ErrorPubSub"))).reportNormalizedError(d);
        return !1
    }
    e.exports = {
        showErrorDialog: a
    }
}), null);
__d("scheduler", ["SchedulerFb-Internals_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("SchedulerFb-Internals_DO_NOT_USE")
}), null);
__d("useHeroBootloadedComponent", ["CometHeroInteractionContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useContext,
        j = b.useEffect;

    function a(a) {
        var b = i(c("CometHeroInteractionContext").Context);
        j(function() {
            b.consumeBootload(a.getModuleId())
        }, [b, a])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
/**
 * License: https://www.facebook.com/legal/license/PAEKTkKqR_S/
 */
__d("msgpack-msgpack-2.8.0", ["regeneratorRuntime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {},
        h = {
            exports: g
        };

    function i() {
        Object.defineProperty(g, "__esModule", {
            value: !0
        });
        g.getUint64 = g.getInt64 = g.setInt64 = g.setUint64 = g.UINT32_MAX = void 0;
        g.UINT32_MAX = 4294967295;

        function a(a, b, c) {
            var d = c / 4294967296;
            c = c;
            a.setUint32(b, d);
            a.setUint32(b + 4, c)
        }
        g.setUint64 = a;

        function b(a, b, c) {
            var d = Math.floor(c / 4294967296);
            c = c;
            a.setUint32(b, d);
            a.setUint32(b + 4, c)
        }
        g.setInt64 = b;

        function c(a, b) {
            var c = a.getInt32(b);
            a = a.getUint32(b + 4);
            return c * 4294967296 + a
        }
        g.getInt64 = c;

        function d(a, b) {
            var c = a.getUint32(b);
            a = a.getUint32(b + 4);
            return c * 4294967296 + a
        }
        g.getUint64 = d
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }
    var l = {},
        m = {
            exports: l
        };

    function n() {
        var a;
        Object.defineProperty(l, "__esModule", {
            value: !0
        });
        l.utf8DecodeTD = l.TEXT_DECODER_THRESHOLD = l.utf8DecodeJs = l.utf8EncodeTE = l.TEXT_ENCODER_THRESHOLD = l.utf8EncodeJs = l.utf8Count = void 0;
        var b = k();
        a = (typeof process === "undefined" || ((a = process === null || process === void 0 ? void 0 : process.env) === null || a === void 0 ? void 0 : a.TEXT_ENCODING) !== "never") && typeof TextEncoder !== "undefined" && typeof TextDecoder !== "undefined";

        function c(a) {
            var b = a.length,
                c = 0,
                d = 0;
            while (d < b) {
                var e = a.charCodeAt(d++);
                if ((e & 4294967168) === 0) {
                    c++;
                    continue
                } else if ((e & 4294965248) === 0) c += 2;
                else {
                    if (e >= 55296 && e <= 56319 && d < b) {
                        var f = a.charCodeAt(d);
                        (f & 64512) === 56320 && (++d, e = ((e & 1023) << 10) + (f & 1023) + 65536)
                    }(e & 4294901760) === 0 ? c += 3 : c += 4
                }
            }
            return c
        }
        l.utf8Count = c;

        function d(a, b, c) {
            var d = a.length;
            c = c;
            var e = 0;
            while (e < d) {
                var f = a.charCodeAt(e++);
                if ((f & 4294967168) === 0) {
                    b[c++] = f;
                    continue
                } else if ((f & 4294965248) === 0) b[c++] = f >> 6 & 31 | 192;
                else {
                    if (f >= 55296 && f <= 56319 && e < d) {
                        var g = a.charCodeAt(e);
                        (g & 64512) === 56320 && (++e, f = ((f & 1023) << 10) + (g & 1023) + 65536)
                    }(f & 4294901760) === 0 ? (b[c++] = f >> 12 & 15 | 224, b[c++] = f >> 6 & 63 | 128) : (b[c++] = f >> 18 & 7 | 240, b[c++] = f >> 12 & 63 | 128, b[c++] = f >> 6 & 63 | 128)
                }
                b[c++] = f & 63 | 128
            }
        }
        l.utf8EncodeJs = d;
        var e = a ? new TextEncoder() : void 0;
        l.TEXT_ENCODER_THRESHOLD = a ? typeof process !== "undefined" && ((c = process === null || process === void 0 ? void 0 : process.env) === null || c === void 0 ? void 0 : c.TEXT_ENCODING) !== "force" ? 200 : 0 : b.UINT32_MAX;

        function f(a, b, c) {
            b.set(e.encode(a), c)
        }

        function g(a, b, c) {
            e.encodeInto(a, b.subarray(c))
        }
        l.utf8EncodeTE = (e === null || e === void 0 ? void 0 : e.encodeInto) ? g : f;
        var h = 4096;

        function i(a, b, c) {
            b = b;
            c = b + c;
            var d = [],
                e = "";
            while (b < c) {
                var f = a[b++];
                if ((f & 128) === 0) d.push(f);
                else if ((f & 224) === 192) {
                    var g = a[b++] & 63;
                    d.push((f & 31) << 6 | g)
                } else if ((f & 240) === 224) {
                    g = a[b++] & 63;
                    var i = a[b++] & 63;
                    d.push((f & 31) << 12 | g << 6 | i)
                } else if ((f & 248) === 240) {
                    g = a[b++] & 63;
                    i = a[b++] & 63;
                    var j = a[b++] & 63;
                    g = (f & 7) << 18 | g << 12 | i << 6 | j;
                    g > 65535 && (g -= 65536, d.push(g >>> 10 & 1023 | 55296), g = 56320 | g & 1023);
                    d.push(g)
                } else d.push(f);
                d.length >= h && (e += String.fromCharCode.apply(String, d), d.length = 0)
            }
            d.length > 0 && (e += String.fromCharCode.apply(String, d));
            return e
        }
        l.utf8DecodeJs = i;
        var j = a ? new TextDecoder() : null;
        l.TEXT_DECODER_THRESHOLD = a ? typeof process !== "undefined" && ((d = process === null || process === void 0 ? void 0 : process.env) === null || d === void 0 ? void 0 : d.TEXT_DECODER) !== "force" ? 200 : 0 : b.UINT32_MAX;

        function m(a, b, c) {
            a = a.subarray(b, b + c);
            return j.decode(a)
        }
        l.utf8DecodeTD = m
    }
    var o = !1;

    function p() {
        o || (o = !0, n());
        return m.exports
    }
    var q = {},
        r = {
            exports: q
        };

    function aa() {
        Object.defineProperty(q, "__esModule", {
            value: !0
        });
        q.ExtData = void 0;
        var a = function(a, b) {
            this.type = a, this.data = b
        };
        q.ExtData = a
    }
    var s = !1;

    function t() {
        s || (s = !0, aa());
        return r.exports
    }
    var u = {},
        ba = {
            exports: u
        };

    function ca() {
        Object.defineProperty(u, "__esModule", {
            value: !0
        });
        u.DecodeError = void 0;
        var a = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(c) {
                c = b.call(this, c) || this;
                var d = Object.create(a.prototype);
                Object.setPrototypeOf(babelHelpers.assertThisInitialized(c), d);
                Object.defineProperty(babelHelpers.assertThisInitialized(c), "name", {
                    configurable: !0,
                    enumerable: !1,
                    value: a.name
                });
                return c
            }
            return a
        }(babelHelpers.wrapNativeSuper(Error));
        u.DecodeError = a
    }
    var v = !1;

    function w() {
        v || (v = !0, ca());
        return ba.exports
    }
    var x = {},
        da = {
            exports: x
        };

    function ea() {
        Object.defineProperty(x, "__esModule", {
            value: !0
        });
        x.timestampExtension = x.decodeTimestampExtension = x.decodeTimestampToTimeSpec = x.encodeTimestampExtension = x.encodeDateToTimeSpec = x.encodeTimeSpecToTimestamp = x.EXT_TIMESTAMP = void 0;
        var a = w(),
            b = k();
        x.EXT_TIMESTAMP = -1;
        var c = 4294967296 - 1,
            d = 17179869184 - 1;

        function e(a) {
            var e = a.sec;
            a = a.nsec;
            if (e >= 0 && a >= 0 && e <= d)
                if (a === 0 && e <= c) {
                    var f = new Uint8Array(4),
                        g = new DataView(f.buffer);
                    g.setUint32(0, e);
                    return f
                } else {
                    g = e / 4294967296;
                    f = e & 4294967295;
                    var h = new Uint8Array(8),
                        i = new DataView(h.buffer);
                    i.setUint32(0, a << 2 | g & 3);
                    i.setUint32(4, f);
                    return h
                }
            else {
                g = new Uint8Array(12);
                i = new DataView(g.buffer);
                i.setUint32(0, a);
                b.setInt64(i, 4, e);
                return g
            }
        }
        x.encodeTimeSpecToTimestamp = e;

        function f(a) {
            a = a.getTime();
            var b = Math.floor(a / 1e3);
            a = (a - b * 1e3) * 1e6;
            var c = Math.floor(a / 1e9);
            return {
                sec: b + c,
                nsec: a - c * 1e9
            }
        }
        x.encodeDateToTimeSpec = f;

        function g(a) {
            if (a instanceof Date) {
                a = f(a);
                return e(a)
            } else return null
        }
        x.encodeTimestampExtension = g;

        function h(c) {
            var d = new DataView(c.buffer, c.byteOffset, c.byteLength);
            switch (c.byteLength) {
                case 4:
                    var e = d.getUint32(0),
                        f = 0;
                    return {
                        sec: e,
                        nsec: f
                    };
                case 8:
                    e = d.getUint32(0);
                    f = d.getUint32(4);
                    f = (e & 3) * 4294967296 + f;
                    e = e >>> 2;
                    return {
                        sec: f,
                        nsec: e
                    };
                case 12:
                    f = b.getInt64(d, 4);
                    e = d.getUint32(0);
                    return {
                        sec: f,
                        nsec: e
                    };
                default:
                    throw new a.DecodeError("Unrecognized data size for timestamp (expected 4, 8, or 12): " + c.length)
            }
        }
        x.decodeTimestampToTimeSpec = h;

        function i(a) {
            a = h(a);
            return new Date(a.sec * 1e3 + a.nsec / 1e6)
        }
        x.decodeTimestampExtension = i;
        x.timestampExtension = {
            type: x.EXT_TIMESTAMP,
            encode: g,
            decode: i
        }
    }
    var y = !1;

    function z() {
        y || (y = !0, ea());
        return da.exports
    }
    var A = {},
        fa = {
            exports: A
        };

    function ga() {
        Object.defineProperty(A, "__esModule", {
            value: !0
        });
        A.ExtensionCodec = void 0;
        var a = t(),
            b = z(),
            c = function() {
                function c() {
                    this.builtInEncoders = [], this.builtInDecoders = [], this.encoders = [], this.decoders = [], this.register(b.timestampExtension)
                }
                var d = c.prototype;
                d.register = function(a) {
                    var b = a.type,
                        c = a.encode;
                    a = a.decode;
                    if (b >= 0) this.encoders[b] = c, this.decoders[b] = a;
                    else {
                        b = 1 + b;
                        this.builtInEncoders[b] = c;
                        this.builtInDecoders[b] = a
                    }
                };
                d.tryToEncode = function(b, c) {
                    for (var d = 0; d < this.builtInEncoders.length; d++) {
                        var e = this.builtInEncoders[d];
                        if (e != null) {
                            e = e(b, c);
                            if (e != null) {
                                var f = -1 - d;
                                return new a.ExtData(f, e)
                            }
                        }
                    }
                    for (f = 0; f < this.encoders.length; f++) {
                        e = this.encoders[f];
                        if (e != null) {
                            d = e(b, c);
                            if (d != null) {
                                e = f;
                                return new a.ExtData(e, d)
                            }
                        }
                    }
                    return b instanceof a.ExtData ? b : null
                };
                d.decode = function(b, c, d) {
                    var e = c < 0 ? this.builtInDecoders[-1 - c] : this.decoders[c];
                    if (e) return e(b, c, d);
                    else return new a.ExtData(c, b)
                };
                return c
            }();
        A.ExtensionCodec = c;
        c.defaultCodec = new c()
    }
    var B = !1;

    function C() {
        B || (B = !0, ga());
        return fa.exports
    }
    var D = {},
        ha = {
            exports: D
        };

    function ia() {
        Object.defineProperty(D, "__esModule", {
            value: !0
        });
        D.createDataView = D.ensureUint8Array = void 0;

        function a(a) {
            if (a instanceof Uint8Array) return a;
            else if (ArrayBuffer.isView(a)) return new Uint8Array(a.buffer, a.byteOffset, a.byteLength);
            else if (a instanceof ArrayBuffer) return new Uint8Array(a);
            else return Uint8Array.from(a)
        }
        D.ensureUint8Array = a;

        function b(b) {
            if (b instanceof ArrayBuffer) return new DataView(b);
            b = a(b);
            return new DataView(b.buffer, b.byteOffset, b.byteLength)
        }
        D.createDataView = b
    }
    var E = !1;

    function F() {
        E || (E = !0, ia());
        return ha.exports
    }
    var G = {},
        ja = {
            exports: G
        };

    function ka() {
        Object.defineProperty(G, "__esModule", {
            value: !0
        });
        G.Encoder = G.DEFAULT_INITIAL_BUFFER_SIZE = G.DEFAULT_MAX_DEPTH = void 0;
        var a = p(),
            b = C(),
            c = k(),
            d = F();
        G.DEFAULT_MAX_DEPTH = 100;
        G.DEFAULT_INITIAL_BUFFER_SIZE = 2048;
        var e = function() {
            function e(a, c, d, e, f, g, h, i) {
                a === void 0 && (a = b.ExtensionCodec.defaultCodec), c === void 0 && (c = void 0), d === void 0 && (d = G.DEFAULT_MAX_DEPTH), e === void 0 && (e = G.DEFAULT_INITIAL_BUFFER_SIZE), f === void 0 && (f = !1), g === void 0 && (g = !1), h === void 0 && (h = !1), i === void 0 && (i = !1), this.extensionCodec = a, this.context = c, this.maxDepth = d, this.initialBufferSize = e, this.sortKeys = f, this.forceFloat32 = g, this.ignoreUndefined = h, this.forceIntegerToFloat = i, this.pos = 0, this.view = new DataView(new ArrayBuffer(this.initialBufferSize)), this.bytes = new Uint8Array(this.view.buffer)
            }
            var f = e.prototype;
            f.reinitializeState = function() {
                this.pos = 0
            };
            f.encodeSharedRef = function(a) {
                this.reinitializeState();
                this.doEncode(a, 1);
                return this.bytes.subarray(0, this.pos)
            };
            f.encode = function(a) {
                this.reinitializeState();
                this.doEncode(a, 1);
                return this.bytes.slice(0, this.pos)
            };
            f.doEncode = function(a, b) {
                if (b > this.maxDepth) throw new Error("Too deep objects in depth " + b);
                a == null ? this.encodeNil() : typeof a === "boolean" ? this.encodeBoolean(a) : typeof a === "number" ? this.encodeNumber(a) : typeof a === "string" ? this.encodeString(a) : this.encodeObject(a, b)
            };
            f.ensureBufferSizeToWrite = function(a) {
                a = this.pos + a;
                this.view.byteLength < a && this.resizeBuffer(a * 2)
            };
            f.resizeBuffer = function(a) {
                a = new ArrayBuffer(a);
                var b = new Uint8Array(a);
                a = new DataView(a);
                b.set(this.bytes);
                this.view = a;
                this.bytes = b
            };
            f.encodeNil = function() {
                this.writeU8(192)
            };
            f.encodeBoolean = function(a) {
                a === !1 ? this.writeU8(194) : this.writeU8(195)
            };
            f.encodeNumber = function(a) {
                Number.isSafeInteger(a) && !this.forceIntegerToFloat ? a >= 0 ? a < 128 ? this.writeU8(a) : a < 256 ? (this.writeU8(204), this.writeU8(a)) : a < 65536 ? (this.writeU8(205), this.writeU16(a)) : a < 4294967296 ? (this.writeU8(206), this.writeU32(a)) : (this.writeU8(207), this.writeU64(a)) : a >= -32 ? this.writeU8(224 | a + 32) : a >= -128 ? (this.writeU8(208), this.writeI8(a)) : a >= -32768 ? (this.writeU8(209), this.writeI16(a)) : a >= -2147483648 ? (this.writeU8(210), this.writeI32(a)) : (this.writeU8(211), this.writeI64(a)) : this.forceFloat32 ? (this.writeU8(202), this.writeF32(a)) : (this.writeU8(203), this.writeF64(a))
            };
            f.writeStringHeader = function(a) {
                if (a < 32) this.writeU8(160 + a);
                else if (a < 256) this.writeU8(217), this.writeU8(a);
                else if (a < 65536) this.writeU8(218), this.writeU16(a);
                else if (a < 4294967296) this.writeU8(219), this.writeU32(a);
                else throw new Error("Too long string: " + a + " bytes in UTF-8")
            };
            f.encodeString = function(b) {
                var c = 1 + 4,
                    d = b.length;
                if (d > a.TEXT_ENCODER_THRESHOLD) {
                    d = a.utf8Count(b);
                    this.ensureBufferSizeToWrite(c + d);
                    this.writeStringHeader(d);
                    a.utf8EncodeTE(b, this.bytes, this.pos);
                    this.pos += d
                } else {
                    d = a.utf8Count(b);
                    this.ensureBufferSizeToWrite(c + d);
                    this.writeStringHeader(d);
                    a.utf8EncodeJs(b, this.bytes, this.pos);
                    this.pos += d
                }
            };
            f.encodeObject = function(a, b) {
                var c = this.extensionCodec.tryToEncode(a, this.context);
                if (c != null) this.encodeExtension(c);
                else if (Array.isArray(a)) this.encodeArray(a, b);
                else if (ArrayBuffer.isView(a)) this.encodeBinary(a);
                else if (typeof a === "object") this.encodeMap(a, b);
                else throw new Error("Unrecognized object: " + Object.prototype.toString.apply(a))
            };
            f.encodeBinary = function(a) {
                var b = a.byteLength;
                if (b < 256) this.writeU8(196), this.writeU8(b);
                else if (b < 65536) this.writeU8(197), this.writeU16(b);
                else if (b < 4294967296) this.writeU8(198), this.writeU32(b);
                else throw new Error("Too large binary: " + b);
                b = d.ensureUint8Array(a);
                this.writeU8a(b)
            };
            f.encodeArray = function(a, b) {
                var c = a.length;
                if (c < 16) this.writeU8(144 + c);
                else if (c < 65536) this.writeU8(220), this.writeU16(c);
                else if (c < 4294967296) this.writeU8(221), this.writeU32(c);
                else throw new Error("Too large array: " + c);
                for (var c = a, a = Array.isArray(c), d = 0, c = a ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var e;
                    if (a) {
                        if (d >= c.length) break;
                        e = c[d++]
                    } else {
                        d = c.next();
                        if (d.done) break;
                        e = d.value
                    }
                    e = e;
                    this.doEncode(e, b + 1)
                }
            };
            f.countWithoutUndefined = function(a, b) {
                var c = 0;
                for (var b = b, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= b.length) break;
                        f = b[e++]
                    } else {
                        e = b.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    a[f] !== void 0 && c++
                }
                return c
            };
            f.encodeMap = function(a, b) {
                var c = Object.keys(a);
                this.sortKeys && c.sort();
                var d = this.ignoreUndefined ? this.countWithoutUndefined(a, c) : c.length;
                if (d < 16) this.writeU8(128 + d);
                else if (d < 65536) this.writeU8(222), this.writeU16(d);
                else if (d < 4294967296) this.writeU8(223), this.writeU32(d);
                else throw new Error("Too large map object: " + d);
                for (d = 0; d < c.length; d++) {
                    var e = c[d],
                        f = a[e];
                    this.ignoreUndefined && f === void 0 || (this.encodeString(e), this.doEncode(f, b + 1))
                }
            };
            f.encodeExtension = function(a) {
                var b = a.data.length;
                if (b === 1) this.writeU8(212);
                else if (b === 2) this.writeU8(213);
                else if (b === 4) this.writeU8(214);
                else if (b === 8) this.writeU8(215);
                else if (b === 16) this.writeU8(216);
                else if (b < 256) this.writeU8(199), this.writeU8(b);
                else if (b < 65536) this.writeU8(200), this.writeU16(b);
                else if (b < 4294967296) this.writeU8(201), this.writeU32(b);
                else throw new Error("Too large extension object: " + b);
                this.writeI8(a.type);
                this.writeU8a(a.data)
            };
            f.writeU8 = function(a) {
                this.ensureBufferSizeToWrite(1), this.view.setUint8(this.pos, a), this.pos++
            };
            f.writeU8a = function(a) {
                var b = a.length;
                this.ensureBufferSizeToWrite(b);
                this.bytes.set(a, this.pos);
                this.pos += b
            };
            f.writeI8 = function(a) {
                this.ensureBufferSizeToWrite(1), this.view.setInt8(this.pos, a), this.pos++
            };
            f.writeU16 = function(a) {
                this.ensureBufferSizeToWrite(2), this.view.setUint16(this.pos, a), this.pos += 2
            };
            f.writeI16 = function(a) {
                this.ensureBufferSizeToWrite(2), this.view.setInt16(this.pos, a), this.pos += 2
            };
            f.writeU32 = function(a) {
                this.ensureBufferSizeToWrite(4), this.view.setUint32(this.pos, a), this.pos += 4
            };
            f.writeI32 = function(a) {
                this.ensureBufferSizeToWrite(4), this.view.setInt32(this.pos, a), this.pos += 4
            };
            f.writeF32 = function(a) {
                this.ensureBufferSizeToWrite(4), this.view.setFloat32(this.pos, a), this.pos += 4
            };
            f.writeF64 = function(a) {
                this.ensureBufferSizeToWrite(8), this.view.setFloat64(this.pos, a), this.pos += 8
            };
            f.writeU64 = function(a) {
                this.ensureBufferSizeToWrite(8), c.setUint64(this.view, this.pos, a), this.pos += 8
            };
            f.writeI64 = function(a) {
                this.ensureBufferSizeToWrite(8), c.setInt64(this.view, this.pos, a), this.pos += 8
            };
            return e
        }();
        G.Encoder = e
    }
    var H = !1;

    function I() {
        H || (H = !0, ka());
        return ja.exports
    }
    var J = {},
        la = {
            exports: J
        };

    function ma() {
        Object.defineProperty(J, "__esModule", {
            value: !0
        });
        J.encode = void 0;
        var a = I(),
            b = {};

        function c(c, d) {
            d === void 0 && (d = b);
            d = new a.Encoder(d.extensionCodec, d.context, d.maxDepth, d.initialBufferSize, d.sortKeys, d.forceFloat32, d.ignoreUndefined, d.forceIntegerToFloat);
            return d.encodeSharedRef(c)
        }
        J.encode = c
    }
    var K = !1;

    function na() {
        K || (K = !0, ma());
        return la.exports
    }
    var L = {},
        oa = {
            exports: L
        };

    function pa() {
        Object.defineProperty(L, "__esModule", {
            value: !0
        });
        L.prettyByte = void 0;

        function a(a) {
            return (a < 0 ? "-" : "") + "0x" + Math.abs(a).toString(16).padStart(2, "0")
        }
        L.prettyByte = a
    }
    var M = !1;

    function qa() {
        M || (M = !0, pa());
        return oa.exports
    }
    var N = {},
        ra = {
            exports: N
        };

    function sa() {
        Object.defineProperty(N, "__esModule", {
            value: !0
        });
        N.CachedKeyDecoder = void 0;
        var a = p(),
            b = 16,
            c = 16,
            d = function() {
                function d(a, d) {
                    a === void 0 && (a = b);
                    d === void 0 && (d = c);
                    this.maxKeyLength = a;
                    this.maxLengthPerKey = d;
                    this.hit = 0;
                    this.miss = 0;
                    this.caches = [];
                    for (a = 0; a < this.maxKeyLength; a++) this.caches.push([])
                }
                var e = d.prototype;
                e.canBeCached = function(a) {
                    return a > 0 && a <= this.maxKeyLength
                };
                e.find = function(a, b, c) {
                    var d = this.caches[c - 1];
                    FIND_CHUNK: for (var d = d, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        var h = g.bytes;
                        for (var i = 0; i < c; i++)
                            if (h[i] !== a[b + i]) continue FIND_CHUNK;
                        return g.str
                    }
                    return null
                };
                e.store = function(a, b) {
                    var c = this.caches[a.length - 1];
                    a = {
                        bytes: a,
                        str: b
                    };
                    c.length >= this.maxLengthPerKey ? c[Math.random() * c.length | 0] = a : c.push(a)
                };
                e.decode = function(b, c, d) {
                    var e = this.find(b, c, d);
                    if (e != null) {
                        this.hit++;
                        return e
                    }
                    this.miss++;
                    e = a.utf8DecodeJs(b, c, d);
                    b = Uint8Array.prototype.slice.call(b, c, c + d);
                    this.store(b, e);
                    return e
                };
                return d
            }();
        N.CachedKeyDecoder = d
    }
    var O = !1;

    function ta() {
        O || (O = !0, sa());
        return ra.exports
    }
    var P = {},
        ua = {
            exports: P
        };

    function va() {
        Object.defineProperty(P, "__esModule", {
            value: !0
        });
        P.Decoder = P.DataViewIndexOutOfBoundsError = void 0;
        var a = qa(),
            c = C(),
            d = k(),
            e = p(),
            f = F(),
            g = ta(),
            h = w(),
            i = function(a) {
                a = typeof a;
                return a === "string" || a === "number"
            },
            j = -1,
            l = new DataView(new ArrayBuffer(0)),
            m = new Uint8Array(l.buffer);
        P.DataViewIndexOutOfBoundsError = function() {
            try {
                l.getInt8(0)
            } catch (a) {
                return a.constructor
            }
            throw new Error("never reached")
        }();
        var n = new P.DataViewIndexOutOfBoundsError("Insufficient data"),
            o = new g.CachedKeyDecoder();
        g = function() {
            function g(a, b, e, f, g, h, i, k) {
                a === void 0 && (a = c.ExtensionCodec.defaultCodec), b === void 0 && (b = void 0), e === void 0 && (e = d.UINT32_MAX), f === void 0 && (f = d.UINT32_MAX), g === void 0 && (g = d.UINT32_MAX), h === void 0 && (h = d.UINT32_MAX), i === void 0 && (i = d.UINT32_MAX), k === void 0 && (k = o), this.extensionCodec = a, this.context = b, this.maxStrLength = e, this.maxBinLength = f, this.maxArrayLength = g, this.maxMapLength = h, this.maxExtLength = i, this.keyDecoder = k, this.totalPos = 0, this.pos = 0, this.view = l, this.bytes = m, this.headByte = j, this.stack = []
            }
            var k = g.prototype;
            k.reinitializeState = function() {
                this.totalPos = 0, this.headByte = j, this.stack.length = 0
            };
            k.setBuffer = function(a) {
                this.bytes = f.ensureUint8Array(a), this.view = f.createDataView(this.bytes), this.pos = 0
            };
            k.appendBuffer = function(a) {
                if (this.headByte === j && !this.hasRemaining(1)) this.setBuffer(a);
                else {
                    var b = this.bytes.subarray(this.pos);
                    a = f.ensureUint8Array(a);
                    var c = new Uint8Array(b.length + a.length);
                    c.set(b);
                    c.set(a, b.length);
                    this.setBuffer(c)
                }
            };
            k.hasRemaining = function(a) {
                return this.view.byteLength - this.pos >= a
            };
            k.createExtraByteError = function(a) {
                var b = this.view,
                    c = this.pos;
                return new RangeError("Extra " + (b.byteLength - c) + " of " + b.byteLength + " byte(s) found at buffer[" + a + "]")
            };
            k.decode = function(a) {
                this.reinitializeState();
                this.setBuffer(a);
                a = this.doDecodeSync();
                if (this.hasRemaining(1)) throw this.createExtraByteError(this.pos);
                return a
            };
            k.decodeMulti = b("regeneratorRuntime").mark(function a(c) {
                return b("regeneratorRuntime").wrap(function(a) {
                    while (1) switch (a.prev = a.next) {
                        case 0:
                            this.reinitializeState(), this.setBuffer(c);
                        case 2:
                            if (!this.hasRemaining(1)) {
                                a.next = 7;
                                break
                            }
                            a.next = 5;
                            return this.doDecodeSync();
                        case 5:
                            a.next = 2;
                            break;
                        case 7:
                        case "end":
                            return a.stop()
                    }
                }, a, this)
            });
            k.decodeAsync = function(c) {
                var d, e, f, g, h, i, j, k, l, m, n, o;
                return b("regeneratorRuntime").async(function(p) {
                    while (1) switch (p.prev = p.next) {
                        case 0:
                            d = !1, f = !0, g = !1, p.prev = 3, i = babelHelpers.asyncIterator(c);
                        case 5:
                            p.next = 7;
                            return b("regeneratorRuntime").awrap(i.next());
                        case 7:
                            j = p.sent;
                            f = j.done;
                            p.next = 11;
                            return b("regeneratorRuntime").awrap(j.value);
                        case 11:
                            k = p.sent;
                            if (f) {
                                p.next = 30;
                                break
                            }
                            l = k;
                            if (!d) {
                                p.next = 16;
                                break
                            }
                            throw this.createExtraByteError(this.totalPos);
                        case 16:
                            this.appendBuffer(l);
                            p.prev = 17;
                            e = this.doDecodeSync();
                            d = !0;
                            p.next = 26;
                            break;
                        case 22:
                            p.prev = 22;
                            p.t0 = p["catch"](17);
                            if (p.t0 instanceof P.DataViewIndexOutOfBoundsError) {
                                p.next = 26;
                                break
                            }
                            throw p.t0;
                        case 26:
                            this.totalPos += this.pos;
                        case 27:
                            f = !0;
                            p.next = 5;
                            break;
                        case 30:
                            p.next = 36;
                            break;
                        case 32:
                            p.prev = 32, p.t1 = p["catch"](3), g = !0, h = p.t1;
                        case 36:
                            p.prev = 36;
                            p.prev = 37;
                            if (!(!f && i["return"] != null)) {
                                p.next = 41;
                                break
                            }
                            p.next = 41;
                            return b("regeneratorRuntime").awrap(i["return"]());
                        case 41:
                            p.prev = 41;
                            if (!g) {
                                p.next = 44;
                                break
                            }
                            throw h;
                        case 44:
                            return p.finish(41);
                        case 45:
                            return p.finish(36);
                        case 46:
                            if (!d) {
                                p.next = 50;
                                break
                            }
                            if (!this.hasRemaining(1)) {
                                p.next = 49;
                                break
                            }
                            throw this.createExtraByteError(this.totalPos);
                        case 49:
                            return p.abrupt("return", e);
                        case 50:
                            m = this.headByte, n = this.pos, o = this.totalPos;
                            throw new RangeError("Insufficient data in parsing " + a.prettyByte(m) + " at " + o + " (" + n + " in the current buffer)");
                        case 52:
                        case "end":
                            return p.stop()
                    }
                }, null, this, [
                    [3, 32, 36, 46],
                    [17, 22],
                    [37, , 41, 45]
                ])
            };
            k.decodeArrayStream = function(a) {
                return this.decodeMultiAsync(a, !0)
            };
            k.decodeStream = function(a) {
                return this.decodeMultiAsync(a, !1)
            };
            k.decodeMultiAsync = function() {
                var a = babelHelpers.wrapAsyncGenerator(b("regeneratorRuntime").mark(function a(c, d) {
                    var e, f, g, h, i, j, k, l, m;
                    return b("regeneratorRuntime").wrap(function(a) {
                        while (1) switch (a.prev = a.next) {
                            case 0:
                                e = d, f = -1, g = !0, h = !1, a.prev = 4, j = babelHelpers.asyncIterator(c);
                            case 6:
                                a.next = 8;
                                return babelHelpers.awaitAsyncGenerator(j.next());
                            case 8:
                                k = a.sent;
                                g = k.done;
                                a.next = 12;
                                return babelHelpers.awaitAsyncGenerator(k.value);
                            case 12:
                                l = a.sent;
                                if (g) {
                                    a.next = 37;
                                    break
                                }
                                m = l;
                                if (!(d && f === 0)) {
                                    a.next = 17;
                                    break
                                }
                                throw this.createExtraByteError(this.totalPos);
                            case 17:
                                this.appendBuffer(m), e && (f = this.readArraySize(), e = !1, this.complete()), a.prev = 19;
                            case 20:
                                a.next = 23;
                                return this.doDecodeSync();
                            case 23:
                                if (!(--f === 0)) {
                                    a.next = 25;
                                    break
                                }
                                return a.abrupt("break", 27);
                            case 25:
                                a.next = 20;
                                break;
                            case 27:
                                a.next = 33;
                                break;
                            case 29:
                                a.prev = 29;
                                a.t0 = a["catch"](19);
                                if (a.t0 instanceof P.DataViewIndexOutOfBoundsError) {
                                    a.next = 33;
                                    break
                                }
                                throw a.t0;
                            case 33:
                                this.totalPos += this.pos;
                            case 34:
                                g = !0;
                                a.next = 6;
                                break;
                            case 37:
                                a.next = 43;
                                break;
                            case 39:
                                a.prev = 39, a.t1 = a["catch"](4), h = !0, i = a.t1;
                            case 43:
                                a.prev = 43;
                                a.prev = 44;
                                if (!(!g && j["return"] != null)) {
                                    a.next = 48;
                                    break
                                }
                                a.next = 48;
                                return babelHelpers.awaitAsyncGenerator(j["return"]());
                            case 48:
                                a.prev = 48;
                                if (!h) {
                                    a.next = 51;
                                    break
                                }
                                throw i;
                            case 51:
                                return a.finish(48);
                            case 52:
                                return a.finish(43);
                            case 53:
                            case "end":
                                return a.stop()
                        }
                    }, a, this, [
                        [4, 39, 43, 53],
                        [19, 29],
                        [44, , 48, 52]
                    ])
                }));

                function c(b, c) {
                    return a.apply(this, arguments)
                }
                return c
            }();
            k.doDecodeSync = function() {
                DECODE: while (!0) {
                    var b = this.readHeadByte(),
                        c = void 0;
                    if (b >= 224) c = b - 256;
                    else if (b < 192)
                        if (b < 128) c = b;
                        else if (b < 144) {
                        var d = b - 128;
                        if (d !== 0) {
                            this.pushMapState(d);
                            this.complete();
                            continue DECODE
                        } else c = {}
                    } else if (b < 160) {
                        d = b - 144;
                        if (d !== 0) {
                            this.pushArrayState(d);
                            this.complete();
                            continue DECODE
                        } else c = []
                    } else {
                        d = b - 160;
                        c = this.decodeUtf8String(d, 0)
                    } else if (b === 192) c = null;
                    else if (b === 194) c = !1;
                    else if (b === 195) c = !0;
                    else if (b === 202) c = this.readF32();
                    else if (b === 203) c = this.readF64();
                    else if (b === 204) c = this.readU8();
                    else if (b === 205) c = this.readU16();
                    else if (b === 206) c = this.readU32();
                    else if (b === 207) c = this.readU64();
                    else if (b === 208) c = this.readI8();
                    else if (b === 209) c = this.readI16();
                    else if (b === 210) c = this.readI32();
                    else if (b === 211) c = this.readI64();
                    else if (b === 217) {
                        d = this.lookU8();
                        c = this.decodeUtf8String(d, 1)
                    } else if (b === 218) {
                        d = this.lookU16();
                        c = this.decodeUtf8String(d, 2)
                    } else if (b === 219) {
                        d = this.lookU32();
                        c = this.decodeUtf8String(d, 4)
                    } else if (b === 220) {
                        d = this.readU16();
                        if (d !== 0) {
                            this.pushArrayState(d);
                            this.complete();
                            continue DECODE
                        } else c = []
                    } else if (b === 221) {
                        d = this.readU32();
                        if (d !== 0) {
                            this.pushArrayState(d);
                            this.complete();
                            continue DECODE
                        } else c = []
                    } else if (b === 222) {
                        d = this.readU16();
                        if (d !== 0) {
                            this.pushMapState(d);
                            this.complete();
                            continue DECODE
                        } else c = {}
                    } else if (b === 223) {
                        d = this.readU32();
                        if (d !== 0) {
                            this.pushMapState(d);
                            this.complete();
                            continue DECODE
                        } else c = {}
                    } else if (b === 196) {
                        d = this.lookU8();
                        c = this.decodeBinary(d, 1)
                    } else if (b === 197) {
                        d = this.lookU16();
                        c = this.decodeBinary(d, 2)
                    } else if (b === 198) {
                        d = this.lookU32();
                        c = this.decodeBinary(d, 4)
                    } else if (b === 212) c = this.decodeExtension(1, 0);
                    else if (b === 213) c = this.decodeExtension(2, 0);
                    else if (b === 214) c = this.decodeExtension(4, 0);
                    else if (b === 215) c = this.decodeExtension(8, 0);
                    else if (b === 216) c = this.decodeExtension(16, 0);
                    else if (b === 199) {
                        d = this.lookU8();
                        c = this.decodeExtension(d, 1)
                    } else if (b === 200) {
                        d = this.lookU16();
                        c = this.decodeExtension(d, 2)
                    } else if (b === 201) {
                        d = this.lookU32();
                        c = this.decodeExtension(d, 4)
                    } else throw new h.DecodeError("Unrecognized type byte: " + a.prettyByte(b));
                    this.complete();
                    d = this.stack;
                    while (d.length > 0) {
                        b = d[d.length - 1];
                        if (b.type === 0) {
                            b.array[b.position] = c;
                            b.position++;
                            if (b.position === b.size) d.pop(), c = b.array;
                            else continue DECODE
                        } else if (b.type === 1) {
                            if (!i(c)) throw new h.DecodeError("The type of key must be string or number but " + typeof c);
                            if (c === "__proto__") throw new h.DecodeError("The key __proto__ is not allowed");
                            b.key = c;
                            b.type = 2;
                            continue DECODE
                        } else {
                            b.map[b.key] = c;
                            b.readCount++;
                            if (b.readCount === b.size) d.pop(), c = b.map;
                            else {
                                b.key = null;
                                b.type = 1;
                                continue DECODE
                            }
                        }
                    }
                    return c
                }
            };
            k.readHeadByte = function() {
                this.headByte === j && (this.headByte = this.readU8());
                return this.headByte
            };
            k.complete = function() {
                this.headByte = j
            };
            k.readArraySize = function() {
                var b = this.readHeadByte();
                switch (b) {
                    case 220:
                        return this.readU16();
                    case 221:
                        return this.readU32();
                    default:
                        if (b < 160) return b - 144;
                        else throw new h.DecodeError("Unrecognized array type byte: " + a.prettyByte(b))
                }
            };
            k.pushMapState = function(a) {
                if (a > this.maxMapLength) throw new h.DecodeError("Max length exceeded: map length (" + a + ") > maxMapLengthLength (" + this.maxMapLength + ")");
                this.stack.push({
                    type: 1,
                    size: a,
                    key: null,
                    readCount: 0,
                    map: {}
                })
            };
            k.pushArrayState = function(a) {
                if (a > this.maxArrayLength) throw new h.DecodeError("Max length exceeded: array length (" + a + ") > maxArrayLength (" + this.maxArrayLength + ")");
                this.stack.push({
                    type: 0,
                    size: a,
                    array: new Array(a),
                    position: 0
                })
            };
            k.decodeUtf8String = function(a, b) {
                var c;
                if (a > this.maxStrLength) throw new h.DecodeError("Max length exceeded: UTF-8 byte length (" + a + ") > maxStrLength (" + this.maxStrLength + ")");
                if (this.bytes.byteLength < this.pos + b + a) throw n;
                var d = this.pos + b;
                this.stateIsMapKey() && ((c = this.keyDecoder) === null || c === void 0 ? void 0 : c.canBeCached(a)) ? c = this.keyDecoder.decode(this.bytes, d, a) : a > e.TEXT_DECODER_THRESHOLD ? c = e.utf8DecodeTD(this.bytes, d, a) : c = e.utf8DecodeJs(this.bytes, d, a);
                this.pos += b + a;
                return c
            };
            k.stateIsMapKey = function() {
                if (this.stack.length > 0) {
                    var a = this.stack[this.stack.length - 1];
                    return a.type === 1
                }
                return !1
            };
            k.decodeBinary = function(a, b) {
                if (a > this.maxBinLength) throw new h.DecodeError("Max length exceeded: bin length (" + a + ") > maxBinLength (" + this.maxBinLength + ")");
                if (!this.hasRemaining(a + b)) throw n;
                var c = this.pos + b;
                c = this.bytes.subarray(c, c + a);
                this.pos += b + a;
                return c
            };
            k.decodeExtension = function(a, b) {
                if (a > this.maxExtLength) throw new h.DecodeError("Max length exceeded: ext length (" + a + ") > maxExtLength (" + this.maxExtLength + ")");
                var c = this.view.getInt8(this.pos + b);
                a = this.decodeBinary(a, b + 1);
                return this.extensionCodec.decode(a, c, this.context)
            };
            k.lookU8 = function() {
                return this.view.getUint8(this.pos)
            };
            k.lookU16 = function() {
                return this.view.getUint16(this.pos)
            };
            k.lookU32 = function() {
                return this.view.getUint32(this.pos)
            };
            k.readU8 = function() {
                var a = this.view.getUint8(this.pos);
                this.pos++;
                return a
            };
            k.readI8 = function() {
                var a = this.view.getInt8(this.pos);
                this.pos++;
                return a
            };
            k.readU16 = function() {
                var a = this.view.getUint16(this.pos);
                this.pos += 2;
                return a
            };
            k.readI16 = function() {
                var a = this.view.getInt16(this.pos);
                this.pos += 2;
                return a
            };
            k.readU32 = function() {
                var a = this.view.getUint32(this.pos);
                this.pos += 4;
                return a
            };
            k.readI32 = function() {
                var a = this.view.getInt32(this.pos);
                this.pos += 4;
                return a
            };
            k.readU64 = function() {
                var a = d.getUint64(this.view, this.pos);
                this.pos += 8;
                return a
            };
            k.readI64 = function() {
                var a = d.getInt64(this.view, this.pos);
                this.pos += 8;
                return a
            };
            k.readF32 = function() {
                var a = this.view.getFloat32(this.pos);
                this.pos += 4;
                return a
            };
            k.readF64 = function() {
                var a = this.view.getFloat64(this.pos);
                this.pos += 8;
                return a
            };
            return g
        }();
        P.Decoder = g
    }
    var Q = !1;

    function R() {
        Q || (Q = !0, va());
        return ua.exports
    }
    var S = {},
        wa = {
            exports: S
        };

    function xa() {
        Object.defineProperty(S, "__esModule", {
            value: !0
        });
        S.decodeMulti = S.decode = S.defaultDecodeOptions = void 0;
        var a = R();
        S.defaultDecodeOptions = {};

        function b(b, c) {
            c === void 0 && (c = S.defaultDecodeOptions);
            c = new a.Decoder(c.extensionCodec, c.context, c.maxStrLength, c.maxBinLength, c.maxArrayLength, c.maxMapLength, c.maxExtLength);
            return c.decode(b)
        }
        S.decode = b;

        function c(b, c) {
            c === void 0 && (c = S.defaultDecodeOptions);
            c = new a.Decoder(c.extensionCodec, c.context, c.maxStrLength, c.maxBinLength, c.maxArrayLength, c.maxMapLength, c.maxExtLength);
            return c.decodeMulti(b)
        }
        S.decodeMulti = c
    }
    var T = !1;

    function U() {
        T || (T = !0, xa());
        return wa.exports
    }
    var V = {},
        ya = {
            exports: V
        };

    function za() {
        Object.defineProperty(V, "__esModule", {
            value: !0
        });
        V.ensureAsyncIterable = V.asyncIterableFromStream = V.isAsyncIterable = void 0;

        function a(a) {
            return a[typeof Symbol === "function" ? Symbol.asyncIterator : "@@asyncIterator"] != null
        }
        V.isAsyncIterable = a;

        function c(a) {
            if (a == null) throw new Error("Assertion Failure: value must not be null nor undefined")
        }

        function d(a) {
            return e.apply(this, arguments)
        }

        function e() {
            e = babelHelpers.wrapAsyncGenerator(b("regeneratorRuntime").mark(function a(d) {
                var e, f, g, h;
                return b("regeneratorRuntime").wrap(function(a) {
                    while (1) switch (a.prev = a.next) {
                        case 0:
                            e = d.getReader(), a.prev = 1;
                        case 2:
                            a.next = 5;
                            return babelHelpers.awaitAsyncGenerator(e.read());
                        case 5:
                            f = a.sent;
                            g = f.done;
                            h = f.value;
                            if (!g) {
                                a.next = 10;
                                break
                            }
                            return a.abrupt("return");
                        case 10:
                            c(h);
                            a.next = 13;
                            return h;
                        case 13:
                            a.next = 2;
                            break;
                        case 15:
                            a.prev = 15;
                            e.releaseLock();
                            return a.finish(15);
                        case 18:
                        case "end":
                            return a.stop()
                    }
                }, a, this, [
                    [1, , 15, 18]
                ])
            }));
            return e.apply(this, arguments)
        }
        V.asyncIterableFromStream = d;

        function f(b) {
            if (a(b)) return b;
            else return d(b)
        }
        V.ensureAsyncIterable = f
    }
    var W = !1;

    function Aa() {
        W || (W = !0, za());
        return ya.exports
    }
    var X = {},
        Ba = {
            exports: X
        };

    function Ca() {
        Object.defineProperty(X, "__esModule", {
            value: !0
        });
        X.decodeStream = X.decodeMultiStream = X.decodeArrayStream = X.decodeAsync = void 0;
        var a = R(),
            c = Aa(),
            d = U();

        function e(e, f) {
            var g, h;
            return b("regeneratorRuntime").async(function(b) {
                while (1) switch (b.prev = b.next) {
                    case 0:
                        f === void 0 && (f = d.defaultDecodeOptions);
                        g = c.ensureAsyncIterable(e);
                        h = new a.Decoder(f.extensionCodec, f.context, f.maxStrLength, f.maxBinLength, f.maxArrayLength, f.maxMapLength, f.maxExtLength);
                        return b.abrupt("return", h.decodeAsync(g));
                    case 4:
                    case "end":
                        return b.stop()
                }
            }, null, this)
        }
        X.decodeAsync = e;

        function f(b, e) {
            e === void 0 && (e = d.defaultDecodeOptions);
            b = c.ensureAsyncIterable(b);
            e = new a.Decoder(e.extensionCodec, e.context, e.maxStrLength, e.maxBinLength, e.maxArrayLength, e.maxMapLength, e.maxExtLength);
            return e.decodeArrayStream(b)
        }
        X.decodeArrayStream = f;

        function g(b, e) {
            e === void 0 && (e = d.defaultDecodeOptions);
            b = c.ensureAsyncIterable(b);
            e = new a.Decoder(e.extensionCodec, e.context, e.maxStrLength, e.maxBinLength, e.maxArrayLength, e.maxMapLength, e.maxExtLength);
            return e.decodeStream(b)
        }
        X.decodeMultiStream = g;

        function h(a, b) {
            b === void 0 && (b = d.defaultDecodeOptions);
            return g(a, b)
        }
        X.decodeStream = h
    }
    var Y = !1;

    function Da() {
        Y || (Y = !0, Ca());
        return Ba.exports
    }
    var Z = {},
        Ea = {
            exports: Z
        };

    function Fa() {
        Object.defineProperty(Z, "__esModule", {
            value: !0
        });
        Z.decodeTimestampExtension = Z.encodeTimestampExtension = Z.decodeTimestampToTimeSpec = Z.encodeTimeSpecToTimestamp = Z.encodeDateToTimeSpec = Z.EXT_TIMESTAMP = Z.ExtData = Z.ExtensionCodec = Z.Encoder = Z.DataViewIndexOutOfBoundsError = Z.DecodeError = Z.Decoder = Z.decodeStream = Z.decodeMultiStream = Z.decodeArrayStream = Z.decodeAsync = Z.decodeMulti = Z.decode = Z.encode = void 0;
        var a = na();
        Object.defineProperty(Z, "encode", {
            enumerable: !0,
            get: function() {
                return a.encode
            }
        });
        var b = U();
        Object.defineProperty(Z, "decode", {
            enumerable: !0,
            get: function() {
                return b.decode
            }
        });
        Object.defineProperty(Z, "decodeMulti", {
            enumerable: !0,
            get: function() {
                return b.decodeMulti
            }
        });
        var c = Da();
        Object.defineProperty(Z, "decodeAsync", {
            enumerable: !0,
            get: function() {
                return c.decodeAsync
            }
        });
        Object.defineProperty(Z, "decodeArrayStream", {
            enumerable: !0,
            get: function() {
                return c.decodeArrayStream
            }
        });
        Object.defineProperty(Z, "decodeMultiStream", {
            enumerable: !0,
            get: function() {
                return c.decodeMultiStream
            }
        });
        Object.defineProperty(Z, "decodeStream", {
            enumerable: !0,
            get: function() {
                return c.decodeStream
            }
        });
        var d = R();
        Object.defineProperty(Z, "Decoder", {
            enumerable: !0,
            get: function() {
                return d.Decoder
            }
        });
        Object.defineProperty(Z, "DataViewIndexOutOfBoundsError", {
            enumerable: !0,
            get: function() {
                return d.DataViewIndexOutOfBoundsError
            }
        });
        var e = w();
        Object.defineProperty(Z, "DecodeError", {
            enumerable: !0,
            get: function() {
                return e.DecodeError
            }
        });
        var f = I();
        Object.defineProperty(Z, "Encoder", {
            enumerable: !0,
            get: function() {
                return f.Encoder
            }
        });
        var g = C();
        Object.defineProperty(Z, "ExtensionCodec", {
            enumerable: !0,
            get: function() {
                return g.ExtensionCodec
            }
        });
        var h = t();
        Object.defineProperty(Z, "ExtData", {
            enumerable: !0,
            get: function() {
                return h.ExtData
            }
        });
        var i = z();
        Object.defineProperty(Z, "EXT_TIMESTAMP", {
            enumerable: !0,
            get: function() {
                return i.EXT_TIMESTAMP
            }
        });
        Object.defineProperty(Z, "encodeDateToTimeSpec", {
            enumerable: !0,
            get: function() {
                return i.encodeDateToTimeSpec
            }
        });
        Object.defineProperty(Z, "encodeTimeSpecToTimestamp", {
            enumerable: !0,
            get: function() {
                return i.encodeTimeSpecToTimestamp
            }
        });
        Object.defineProperty(Z, "decodeTimestampToTimeSpec", {
            enumerable: !0,
            get: function() {
                return i.decodeTimestampToTimeSpec
            }
        });
        Object.defineProperty(Z, "encodeTimestampExtension", {
            enumerable: !0,
            get: function() {
                return i.encodeTimestampExtension
            }
        });
        Object.defineProperty(Z, "decodeTimestampExtension", {
            enumerable: !0,
            get: function() {
                return i.decodeTimestampExtension
            }
        })
    }
    var $ = !1;

    function Ga() {
        $ || ($ = !0, Fa());
        return Ea.exports
    }

    function a(a) {
        switch (a) {
            case void 0:
                return Ga()
        }
    }
    e.exports = a
}), null);
__d("msgpack-msgpack", ["msgpack-msgpack-2.8.0"], (function(a, b, c, d, e, f) {
    e.exports = b("msgpack-msgpack-2.8.0")()
}), null); /*FB_PKG_DELIM*/
__d("GetLsDatabaseForComet", ["asyncToGeneratorRuntime", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("GetLsDatabase").__setRef("GetLsDatabaseForComet");

    function a() {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            var a = (yield h.load());
            return a.get()
        });
        return i.apply(this, arguments)
    }
    g.get = a
}), 98);
__d("LSBitFlag", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b) {
        return (h || (h = d("I64"))).equal(h.and_(b, a), a)
    }

    function b(a, b) {
        return (h || (h = d("I64"))).or_(b, a)
    }

    function c(a, b) {
        return (h || (h = d("I64"))).and_(b, h.lognot(a))
    }
    g.has = a;
    g.set = b;
    g.clear = c;
    g.empty = (h || (h = d("I64"))).zero
}), 98);
__d("LSPersistedDbGating", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("gkx")("24032");
    b = c("gkx")("24032");
    g.anyTablesPersisted = a;
    g.allTablesPersisted = b
}), 98);
__d("LSPlatformLsInitLog", ["ErrorGuard", "ExecutionEnvironment", "QPLUserFlow", "VisibilityAPI", "VisibilityState", "gkx", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = c("qpl")._(25305590, "1127"),
        k = !1,
        l = !1,
        m = [],
        n = c("gkx")("23405"),
        o = c("gkx")("22799"),
        p = function(a, b) {
            q(j, "visibility_change_" + (b ? "hidden" : "visible"))
        };

    function a(a) {
        k || (k = !0, l = !1, (h || (h = c("ExecutionEnvironment"))).isInWorker || a === !1 ? c("QPLUserFlow").start(j, {
            annotations: {
                bool: {
                    initiallyHidden: d("VisibilityAPI").isVisibilityHidden(),
                    isArmadilloPublicLaunchUser: n,
                    mComPreInitLoad: o
                }
            },
            cancelOnUnload: !0,
            timeoutInMs: 6e4
        }) : c("QPLUserFlow").startFromNavStart(j, {
            annotations: {
                bool: {
                    initiallyHidden: d("VisibilityAPI").isVisibilityHidden(),
                    isArmadilloPublicLaunchUser: n,
                    mComPreInitLoad: o
                }
            },
            cancelOnUnload: !0,
            onFlowTimeout: t,
            timeoutInMs: (h || (h = c("ExecutionEnvironment"))).canUseDOM ? 6e4 : 0
        })), d("VisibilityState").subscribe(p)
    }

    function q(a, b, d) {
        s() && (c("QPLUserFlow").addPoint(a, ((h || (h = c("ExecutionEnvironment"))).isInWorker ? "worker_" : "") + b), d != null && c("QPLUserFlow").addAnnotations(a, d))
    }

    function r(a) {
        c("QPLUserFlow").addAnnotations(j, a)
    }

    function b(a, b) {
        q(j, a, b)
    }

    function e() {
        s() && (l = !0, c("QPLUserFlow").endSuccess(j), t())
    }

    function f(a, b) {
        l = !0, c("QPLUserFlow").endFailure(j, a, {
            error: b
        }), t()
    }

    function s() {
        return k && !l
    }

    function t() {
        for (var a = 0; a < m.length; a++) {
            var b = m[a];
            (i || (i = c("ErrorGuard"))).applyWithGuard(b, null, [])
        }
    }

    function u(a) {
        m.push(a)
    }
    var v = {
        addAnnotations: function(a) {
            var b = a.bool,
                c = a["int"];
            a = a.string;
            r({
                bool: b,
                "int": c,
                string: a
            })
        },
        addPoint: b,
        addPointForEvent: q,
        endFail: f,
        endSuccess: e,
        isPending: s,
        onCompleteOrFail: u,
        start: a
    };
    g.start = a;
    g.addPointForEvent = q;
    g.addAnnotations = r;
    g.addPoint = b;
    g.endSuccess = e;
    g.fail = f;
    g.isPending = s;
    g.onCompleteOrFail = u;
    g.lsInitLogger = v
}), 98);
__d("MWIndexedDBDelete", ["ExecutionEnvironment", "FBLogger", "MAWCurrentUser", "MWLSDatabaseNames", "ODS", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j(a) {
        try {
            if (a === 1) return "" + d("MWLSDatabaseNames").name + d("MAWCurrentUser").getID();
            else return d("MWLSDatabaseNames").name + "V" + a + d("MAWCurrentUser").getID()
        } catch (a) {
            return null
        }
    }

    function a(a) {
        var b;
        c("FBLogger")("maw_db").warn("[MWIndexedDBDelete] DELETE ALL DBS CALLED");
        if ((i || (i = c("ExecutionEnvironment"))).canUseDOM && ((b = window) == null ? void 0 : b.indexedDB) != null) {
            var e = j(a);
            if (e != null)
                if (typeof window.indexedDB.databases === "function") {
                    b = window.indexedDB.databases();
                    b.then(function(a) {
                        a.forEach(function(a) {
                            var b = a.name || "";
                            if (b === e) {
                                a = window.indexedDB.deleteDatabase(b);
                                a.onsuccess = function() {
                                    c("FBLogger")("maw_db").info("MW PDB deletion success for " + b)
                                };
                                a.onblocked = function() {
                                    c("recoverableViolation")("[db clean up patch] Cannot delete db: blocked", "maw_db"), (h || (h = d("ODS"))).bumpEntityKey(3185, "mw_pdb_delete", "blocked")
                                };
                                a.onerror = function() {
                                    (h || (h = d("ODS"))).bumpEntityKey(3185, "mw_pdb_delete", "error"), c("recoverableViolation")("[pdb clean up patch] Cannot delete db", "maw_db")
                                }
                            }
                        })
                    })["catch"](function(a) {
                        c("recoverableViolation")("[pdb clean up patch] LS delete databases error", "maw_db", {
                            error: a
                        })
                    })
                } else {
                    a = window.indexedDB.deleteDatabase(e);
                    a.onsuccess = function() {
                        (h || (h = d("ODS"))).bumpEntityKey(3185, "mw_pdb_delete", "success_v2")
                    };
                    a.onblocked = function() {
                        c("recoverableViolation")("[db clean up patch v2] Cannot delete db: blocked", "maw_db"), (h || (h = d("ODS"))).bumpEntityKey(3185, "mw_pdb_delete", "blocked_v2")
                    };
                    a.onerror = function() {
                        (h || (h = d("ODS"))).bumpEntityKey(3185, "mw_pdb_delete", "error_v2"), c("recoverableViolation")("[pdb clean up patch v2] Cannot delete db", "maw_db")
                    }
                }
        }
    }
    g.getUserDbNameForVersion = j;
    g.deleteAllDBs = a
}), 98);
__d("LSLogHistory", ["FBLogger", "performance"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = {},
        j = {
            client_init: 100,
            client_sync: 50,
            client_task: 20,
            db_dump: 200,
            db_init: 100,
            general: 50,
            ls: 50,
            maw_setup: 10,
            user_experience: 200
        },
        k = 10;

    function a() {
        try {
            return Object.values(i).reduce(function(a, b) {
                return a.concat(b)
            }, []).sort(function(a, b) {
                return a.date - b.date
            }).map(function(a) {
                return [a.date.toString(), a.level, a.category, a.event, a.args].join(" | ")
            })
        } catch (a) {
            c("FBLogger")("messenger_browser_clients").catching(a).mustfix("getEntries failed");
            return [
                [Date.now().toString(), "error", "general", "lightspeed_log_event", "cannot create entries"].join(" | ")
            ]
        }
    }

    function b() {
        i = {}
    }

    function d(a, b, d, e) {
        var f;
        d === void 0 && (d = "general");
        e === void 0 && (e = "lightspeed_log_event");
        var g;
        (h || (h = c("performance"))).timing != null ? g = Math.round((h || (h = c("performance"))).timing.navigationStart + h.now()) : g = Date.now();
        i[d] == null && (i[d] = []);
        i[d].length >= ((f = j[d]) != null ? f : k) && i[d].shift();
        i[d].push({
            args: a,
            category: d,
            date: g,
            event: e,
            level: b
        })
    }
    g.MAX_LIMIT = j;
    g.getEntries = a;
    g.clearEntries = b;
    g.log = d
}), 98);
__d("MessengerSimpleLogHistoryFactory", ["LSLogHistory"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getInstance: function(a) {
            return {
                debug: function(b, c) {
                    d("LSLogHistory").log(b, "debug", a, c)
                },
                error: function(b, c) {
                    d("LSLogHistory").log(b, "error", a, c)
                }
            }
        }
    };
    g.simpleFactory = a
}), 98);
__d("MessengerBroadcastLogHistoryFactory", ["FBLogger", "MessengerSimpleLogHistoryFactory", "pageID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a, b) {
        var e = this;
        this.listener = function(a) {
            var b = d("MessengerSimpleLogHistoryFactory").simpleFactory.getInstance(e.$1);
            a.level === "error" && b.error(a.message, "from_" + a.page);
            a.level === "debug" && b.debug(a.message, "from_" + a.page)
        };
        this.debug = function(a) {
            for (var b = arguments.length, f = new Array(b > 1 ? b - 1 : 0), g = 1; g < b; g++) f[g - 1] = arguments[g];
            try {
                d("MessengerSimpleLogHistoryFactory").simpleFactory.getInstance(e.$1).debug(a), e.$2({
                    args: f,
                    category: e.$1,
                    level: "debug",
                    message: a,
                    page: c("pageID")
                })
            } catch (a) {
                c("FBLogger")("messenger_web_product").catching(a).warn("MessengerLogHistory debug")
            }
        };
        this.error = function(a) {
            for (var b = arguments.length, f = new Array(b > 1 ? b - 1 : 0), g = 1; g < b; g++) f[g - 1] = arguments[g];
            try {
                d("MessengerSimpleLogHistoryFactory").simpleFactory.getInstance(e.$1).error(a), e.$2({
                    args: f,
                    category: e.$1,
                    level: "error",
                    message: a,
                    page: c("pageID")
                })
            } catch (a) {
                c("FBLogger")("messenger_web_product").catching(a).warn("MessengerLogHistory error")
            }
        };
        this.$1 = a;
        this.$2 = b
    };
    a = function() {
        function a() {
            var a = this,
                b;
            this.$1 = {};
            this.$3 = "ls_log_history";
            this.$4 = function(b) {
                var c, d = b.args,
                    e = b.category,
                    f = b.level,
                    g = b.message;
                b = b.page;
                (c = a.$2) == null ? void 0 : c.postMessage({
                    args: d,
                    category: e,
                    level: f,
                    message: g,
                    page: b
                })
            };
            this.$2 = self.BroadcastChannel != null ? new self.BroadcastChannel(this.$3) : null;
            (b = this.$2) == null ? void 0 : b.addEventListener("message", function(b) {
                b = b.data;
                if ((b == null ? void 0 : b.category) != null) {
                    var c = a.$1[b == null ? void 0 : b.category];
                    c == null ? void 0 : c.listener(b)
                }
            })
        }
        var b = a.prototype;
        b.getInstance = function(a) {
            this.$1[a] || (this.$1[a] = new h(a, this.$4));
            return this.$1[a]
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MessengerLogHistory", ["MessengerSimpleLogHistoryFactory"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {},
        i = d("MessengerSimpleLogHistoryFactory").simpleFactory;

    function a(a) {
        i = a
    }

    function b(a) {
        h[a] || (h[a] = i.getInstance(a));
        return h[a]
    }
    g.setLogHistoryFactory = a;
    g.getInstance = b
}), 98);
__d("Qe2JsExposureFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1837559");
    b = d("FalcoLoggerInternal").create("qe2_js_exposure", a);
    e = b;
    g["default"] = e
}), 98);
__d("QE2Logger", ["Qe2JsExposureFalcoEvent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {};

    function a(a, b) {
        I(a, (a = b) != null ? a : "", 9)
    }

    function b(a, b) {
        I(a, (a = b) != null ? a : "", 9, null, "immediate")
    }

    function d(a) {
        I(a, "", 32)
    }

    function e(a) {
        I(a, "", 32, null, "immediate")
    }

    function f(a) {
        I(a, "", 54)
    }

    function i(a, b) {
        I(a, b, 126)
    }

    function j(a, b) {
        I(a, "", 54, b, "immediate")
    }

    function k(a, b) {
        I(a, "", 54, b, "critical")
    }

    function l(a, b) {
        I(a, b, 3)
    }

    function m(a) {
        I(a, "", 5)
    }

    function n(a) {
        I(a, "", 5, null, "immediate")
    }

    function o(a) {
        I(a, "", 31)
    }

    function p(a) {
        I(a, "", 98)
    }

    function q(a, b) {
        I(a, b, 7)
    }

    function r(a, b) {
        I(a, b, 7, null, "immediate")
    }

    function s(a, b) {
        I(a, b, 7, null, "critical")
    }

    function t(a, b) {
        I(a, b, 55)
    }

    function u(a, b) {
        I(a, b, 17)
    }

    function v(a, b) {
        I(a, b, 25)
    }

    function w(a, b) {
        I(a, b, 115)
    }

    function x(a, b) {
        I(a, b, 8)
    }

    function y(a, b) {
        I(a, b, 22)
    }

    function z(a, b) {
        I(a, b, 27)
    }

    function A(a, b) {
        I(a, b, 0)
    }

    function B(a, b) {
        I(a, (a = b) != null ? a : "", 89)
    }

    function C(a, b) {
        I(a, (a = b) != null ? a : "", 89, null, "immediate")
    }

    function D(a, b) {
        I(a, b, 60)
    }

    function E(a, b) {
        I(a, b, 90)
    }

    function F(a, b) {
        I(a, b, 144)
    }

    function G(a, b, c) {
        I(a, b, c)
    }

    function H(a, b, c) {
        I(a, b, c, null, "immediate")
    }

    function I(a, b, d, e, f) {
        var g = a + "|" + b;
        e != null && (g = g + "|" + e);
        if (h[g]) return;
        f === "immediate" ? c("Qe2JsExposureFalcoEvent").logImmediately(function() {
            return {
                universe: a,
                unit_id: b,
                unit_type: d,
                param: e
            }
        }) : f === "critical" ? c("Qe2JsExposureFalcoEvent").logCritical(function() {
            return {
                universe: a,
                unit_id: b,
                unit_type: d,
                param: e
            }
        }) : c("Qe2JsExposureFalcoEvent").log(function() {
            return {
                universe: a,
                unit_id: b,
                unit_type: d,
                param: e
            }
        });
        h[g] = !0
    }
    g.logExposureForUser = a;
    g.logExposureForUserImmediately = b;
    g.logExposureForIGUser = d;
    g.logExposureForIGUserImmediately = e;
    g.logExposureForIGWebCookie = f;
    g.logExposureForIGAccountFBIDV2 = i;
    g.logExposureForIGWebCookieImmediately = j;
    g.logExposureForIGWebCookieCritical = k;
    g.logExposureForEmail = l;
    g.logExposureForDatr = m;
    g.logExposureForDatrImmediately = n;
    g.logExposureForOculusLoggedOut = o;
    g.logExposureForOculusLoggedOutCookieID = p;
    g.logExposureForPage = q;
    g.logExposureForPageImmediately = r;
    g.logExposureForPageCritical = s;
    g.logExposureForPaymentAccountID = t;
    g.logExposureForBusiness = u;
    g.logExposureForGroup = v;
    g.logExposureForPhabricatorDiff = w;
    g.logExposureForPhoneNumber = x;
    g.logExposureForScimCompanyID = y;
    g.logExposureForAnalyticsEntityID = z;
    g.logExposureForAdAccountID = A;
    g.logExposureForActingAccount = B;
    g.logExposureForActingAccountImmediately = C;
    g.logExposureForMixedUserAndPage = D;
    g.logExposureForCommerceMerchantSettings = E;
    g.logExposureForShopifyApplicationInstallationID = F;
    g.logExposure = G;
    g.logExposureImmediately = H
}), 98);
__d("LSDatabaseSingleton", ["CurrentUser", "ExecutionEnvironment", "FBLogger", "InteractionTracing", "LSPersistedDbGating", "LSPlatformLsInitLog", "MWIndexedDBDelete", "MessengerBroadcastLogHistoryFactory", "MessengerLogHistory", "Promise", "QE2Logger", "QPLUserFlow", "asyncToGeneratorRuntime", "cr:10191", "cr:1027", "cr:123", "cr:3411", "cr:6587", "gkx", "justknobx", "qpl", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    d("LSPersistedDbGating").anyTablesPersisted && d("MessengerLogHistory").setLogHistoryFactory(new(c("MessengerBroadcastLogHistoryFactory"))());
    var j = (a = b("cr:123")) != null ? a : b("cr:6587");
    d("QE2Logger").logExposureForUser("lightspeed_web_persisted_db");
    b("cr:1027") == null ? void 0 : b("cr:1027").overwriteSamplingRate();
    b("cr:10191") == null ? void 0 : b("cr:10191").overwriteSamplingRate();
    d("LSPlatformLsInitLog").start();
    e = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            c("gkx")("2790") && ((i || (i = c("ExecutionEnvironment"))).isInWorker || (i || (i = c("ExecutionEnvironment"))).isInSharedWorker) && c("FBLogger")("messenger_browser_clients").mustfix("DbSingleton was called in a worker");
            var a = c("gkx")("26383");
            d("LSPlatformLsInitLog").addPoint("get_ls_database_start", {
                bool: {
                    is_pdb: d("LSPersistedDbGating").anyTablesPersisted,
                    loadDbEarlierEnabled: a
                }
            });
            c("InteractionTracing").getPendingInteractions().forEach(function(b) {
                b.addMarkerPoint("get_ls_database_start", "AppTiming"), b.addAnnotationBoolean("loadDbEarlierEnabled", a), b.addAnnotationBoolean("is_pdb", d("LSPersistedDbGating").anyTablesPersisted)
            });
            var e = (yield j.get());
            d("LSPlatformLsInitLog").addPoint("get_ls_database_end");
            c("InteractionTracing").getPendingInteractions().forEach(function(a) {
                a.addMarkerPoint("get_ls_database_end", "AppTiming")
            });
            try {
                var f = c("justknobx")._("541"),
                    g = !d("LSPersistedDbGating").anyTablesPersisted;
                g && f > 0 && (d("LSPlatformLsInitLog").addPoint("should_delete_index_db_start", {
                    "int": {
                        versionToDelete: f
                    }
                }), d("MWIndexedDBDelete").deleteAllDBs(f))
            } catch (a) {
                c("recoverableViolation")("[db clean up patch] Cant delete db", "maw_db")
            }
            d("LSPlatformLsInitLog").addPoint("db_created");
            c("CurrentUser").isWorkUser() && c("QPLUserFlow").addPoint(c("qpl")._(1036588047, "310"), "db_created");
            if (b("cr:3411") !== null) try {
                b("cr:3411").registerDb(e)
            } catch (a) {
                c("FBLogger")("messenger_browser_clients").catching(a).mustfix("LSPlatformDevtools failed to register db.")
            }
            return e
        });
        return function() {
            return a.apply(this, arguments)
        }
    }();
    var k = (i || (i = c("ExecutionEnvironment"))).isInBrowser ? e().then(function(a) {
        k = a;
        return a
    }) : new(h || (h = b("Promise")))(function() {
        c("FBLogger")("messenger_browser_clients").warn("ExecutionEnvironment.isInBrowser returned false, returning never ending promise")
    });
    f = function() {
        return k
    };
    a = (h || (h = b("Promise"))).resolve(k);
    g.getLSDatabaseSingletonPromiseOrValue = f;
    g.LSDatabaseSingleton = a
}), 98);
__d("LSMessageThreadUnsendabilityStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        CAN_UNSEND: 0,
        DENY_FOR_SPECIFIC_IDS: 1,
        DENY_IF_THREAD_CONTAINS_PAU: 2,
        DENY_IF_THREAD_CONTAINS_WORK_USER: 3,
        DENY_IF_PAGE_THREAD: 4,
        DENY_IF_MARKETPLACE_THREAD: 5,
        DENY_IF_CANNOT_LOAD_THREAD: 6,
        DENY_IF_THREAD_CONTAINS_WORK_USER_FAILING_KILLSWITCH: 7,
        DENY_IF_CANONICAL_THREAD_CONTAINS_BLOCKED_USERS: 8,
        DENY_IF_CANNOT_REPLY_TO_VIEWER_THREAD: 9,
        DENY_IF_UNCONNECTED_THREAD: 10
    });
    f["default"] = a
}), 66);
__d("isUnjoinedCMThread", ["I64", "LSIntEnum"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(19)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(24)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(22))
    }
    g.isUnjoinedCMThread = a
}), 98);
__d("LSThreadBitOffset", ["FBLogger", "I64", "LSBitFlag", "isUnjoinedCMThread"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    f = ["capabilities", "capabilities2", "capabilities3", "capabilities4"];
    var i = 4,
        j = i * 64;

    function a(a, b) {
        if (d("isUnjoinedCMThread").isUnjoinedCMThread(b.threadType)) return !1;
        if (a >= j) {
            c("FBLogger")("LSThreadBitOffset", "out_of_bounds_bit_offset").mustfix("Invalid bitOffset; expected a value between 0 and %d but found %s instead", j - 1, a);
            return !1
        }
        if (a >= 192) return d("LSBitFlag").has((h || (h = d("I64"))).lsl_(h.one, a - 192), b.capabilities4);
        if (a >= 128) return d("LSBitFlag").has((h || (h = d("I64"))).lsl_(h.one, a - 128), b.capabilities3);
        return a >= 64 ? d("LSBitFlag").has((h || (h = d("I64"))).lsl_(h.one, a - 64), b.capabilities2) : d("LSBitFlag").has((h || (h = d("I64"))).lsl_(h.one, a), b.capabilities)
    }

    function b(a, b, c, e, f) {
        return a.reduce(function(a, b) {
            var c = a[0],
                e = a[1],
                f = a[2];
            a = a[3];
            if (b >= 192) return [c, e, f, d("LSBitFlag").set((h || (h = d("I64"))).lsl_(h.one, b - 192), a)];
            if (b >= 128) return [c, e, d("LSBitFlag").set((h || (h = d("I64"))).lsl_(h.one, b - 128), f), a];
            return b >= 64 ? [c, d("LSBitFlag").set((h || (h = d("I64"))).lsl_(h.one, b - 64), e), f, a] : [d("LSBitFlag").set((h || (h = d("I64"))).lsl_(h.one, b), c), e, f, a]
        }, [b, c, e, f])
    }

    function e(a, b, c, e, f) {
        return a.reduce(function(a, b) {
            var c = a[0],
                e = a[1],
                f = a[2];
            a = a[3];
            if (b >= 192) return [c, e, f, d("LSBitFlag").clear((h || (h = d("I64"))).lsl_(h.one, b - 192), a)];
            if (b >= 128) return [c, e, d("LSBitFlag").clear((h || (h = d("I64"))).lsl_(h.one, b - 128), f), a];
            return b >= 64 ? [c, d("LSBitFlag").clear((h || (h = d("I64"))).lsl_(h.one, b - 64), e), f, a] : [d("LSBitFlag").clear((h || (h = d("I64"))).lsl_(h.one, b), c), e, f, a]
        }, [b, c, e, f])
    }
    g.threadCapabilityFields = f;
    g.MAX_SUPPORTED_THREAD_CAPABILITY = i;
    g.has = a;
    g.set = b;
    g.clear = e;
    g.empty = (h || (h = d("I64"))).zero
}), 98);
__d("MessagingThreadSubtype", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        ADMIN_MODEL_V2_THREAD: 1,
        FB_GROUP_CHAT: 2,
        MARKETPLACE_THREAD: 3,
        SCHOOL_CHAT: 4,
        DEPRECATED__WORK_SYNCED_CHAT: 5,
        ADMIN_NOT_SUPPORTED_THREAD: 6,
        BELL_SYNCED_CHAT: 7,
        GAMES_APP_THREAD: 8,
        VAULT_CHAT: 9,
        VERSE_CHAT: 10,
        GENERIC_COMMERCE_THREAD: 11,
        USER_JOB_THREAD: 12,
        COWORKER_GROUP_THREAD: 13,
        APPROVAL_ENFORCED_CHATROOM_THREAD: 14,
        PARENT_APPROVED_SHEPHERD_MANAGED_THREAD: 15,
        CAMPUS_GROUP_THREAD: 16,
        LOCAL_COMMUNITIES_THREAD: 17,
        CHAT_FOR_ROOM_THREAD: 18,
        GAMING_PLAY_SQUAD: 19,
        CHAT_FOR_GROUP_ADMIN_TO_MEMBER_THREAD: 20,
        EITM_BACKED_IG_1TO1_THREAD: 21,
        LEARNING_SPACE: 23,
        E2EE_GROUP_THREAD_METADATA: 24,
        IGD_BC_PARTNERSHIP: 25,
        E2EE_1TO1_THREAD_METADATA: 26,
        JOBS_CAREER_GROUP_THREAD: 27,
        IG_CREATOR_SUBSCRIBER_GROUP_THREAD: 28,
        IG_CREATOR_SUBSCRIBER_BROADCAST_CHAT: 29,
        BUSINESS_SUPPORT_THREAD: 30,
        TAGGED_PII_DATA: 31,
        IG_DISCOVERABLE_CHAT_THREAD: 32,
        SUPPORT_MESSAGING_THREAD: 33,
        DISCOVERABLE_PUBLIC_CHAT: 34,
        DISCOVERABLE_PUBLIC_BROADCAST_CHAT: 35,
        DISCOVERABLE_PUBLIC_CHAT_V2: 36,
        IG_DISCOVERABLE_CHAT_THREAD_V2: 37,
        OCULUS_MEDIA_MESSAGING: 38,
        WORK_CHAT_THREAD_CENTRIC: 39,
        COMMUNITY_MESSAGING_PUBLIC_THREAD: 40,
        COMMUNITY_MESSAGING_PRIVATE_THREAD: 41,
        COMMUNITY_MESSAGING_ADMOD_THREAD: 42,
        COMMUNITY_MESSAGING_BROADCAST_THREAD: 43,
        IG_E2EE_GROUP_THREAD_METADATA: 44,
        IG_NFT_BROADCAST_CHAT: 45,
        STANDALONE_COMMUNITY_STANDARD_THREAD: 46,
        IGD_GROUP: 47,
        WORKCHAT_GROUP_THREAD: 48,
        WORKROOM_GROUP_THREAD: 49,
        OCULUS_GROUP_THREAD: 50,
        INTEROP_GROUP: 51,
        IG_BTV_E2EE_1TO1_THREAD_METADATA: 52,
        COMMUNITY_MESSAGING_HELPER_BOT_THREAD: 53,
        COMMUNITY_MESSAGING_SUB_THREAD: 54,
        IG_GROUP_PROFILES: 55,
        IG_PRIVATE_EVENT: 56,
        WA_GENAI_BOT_MAILBOX_THREAD: 57,
        MESSENGER_GENAI_BOT_MAILBOX_THREAD: 58,
        IG_GENAI_BOT_MAILBOX_THREAD: 59,
        E2EE_COMMUNITY_CHAT_METADATA: 60,
        IG_SUBSCRIBER_SOCIAL_CHANNEL: 61,
        IG_SOCIAL_CHANNEL: 62,
        GENERIC_GENAI_BOT_MAILBOX_THREAD: 63,
        GENAI_IMAGINE: 64,
        FB_GENAI_BOT_MAILBOX_THREAD: 65,
        ABRA_GENAI_BOT_MAILBOX_THREAD: 66,
        GENAI_STUDIO_BOT_MAILBOX_THREAD: 67,
        SHOPS_AI_ASSISTANT_THREAD: 68,
        IG_E2EE_1TO1_THREAD_METADATA: 69,
        IG_THREAD_WITH_BOT_PARTICIPANTS: 70,
        IG_SUPPORT_MESSAGING_THREAD: 71,
        ONE_TO_ONE: 1001,
        PARENT_APPROVED_ONE_TO_ONE: 1002,
        IG_ONLY_ONE_TO_ONE: 1003,
        INTEROP_ONE_TO_ONE: 1004,
        WHATSAPP_ONE_TO_ONE: 1005,
        WORKCHAT_ONE_TO_ONE: 1006,
        OC_PROXY_ONE_TO_ONE: 1007,
        MARKETPLACE_ASSISTANT_ONE_TO_ONE: 1008,
        PAGE_TO_USER: 1009,
        PAGE_TO_PAGE: 1010,
        MESSENGER_AI_BOT_ONE_TO_ONE: 1011,
        IG_AI_BOT_ONE_TO_ONE: 1012,
        IG_CREATOR_AGENT_SANDBOX: 1013,
        IG_USER_GENERATED_AI_BOT_ONE_TO_ONE: 1014,
        MSGR_USER_GENERATED_AI_BOT_ONE_TO_ONE: 1015,
        IG_BUSINESS_ACCOUNT_ONE_TO_ONE: 1016,
        OCULUS: 2001
    });
    f["default"] = a
}), 66);
__d("isCommunityContainersEnabled", ["qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("qex")._("792") === !0
    }
    g["default"] = a
}), 98);
__d("mwCMIsAnyCMThread", ["I64", "LSIntEnum", "isCommunityContainersEnabled"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a) {
        var b = c("isCommunityContainersEnabled")();
        if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(18)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(19)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(23)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(24)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(21))) return !0;
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(17)) && b ? !0 : (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(22))
    }
    g["default"] = a
}), 98);
__d("LSMessagingThreadTypeUtil", ["I64", "LSIntEnum", "LSMessageThreadUnsendabilityStatus", "LSThreadBitOffset", "MessagingThreadSubtype", "MetaConfig", "mwCMIsAnyCMThread", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(2)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(8)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(16)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(5)) || c("mwCMIsAnyCMThread")(a) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(3)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(150)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(151)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(154)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(155)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(152)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(153)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(26))
    }

    function j(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(7)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(10)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(13)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(201))
    }

    function b(a) {
        return j(a) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(15))
    }

    function k(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(15)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(16))
    }

    function e(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(15))
    }

    function f(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(15)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(16)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(201)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(2))
    }

    function l(a) {
        return a === "e2ee_cutover" || a === "inbox"
    }

    function m(a, b) {
        b === void 0 && (b = !0);
        return !b && (h || (h = d("I64"))).equal(a.parentThreadKey, (i || (i = d("LSIntEnum"))).ofNumber(0)) ? !1 : d("LSThreadBitOffset").has(21, a)
    }

    function n(a) {
        return a != null && (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingThreadSubtype").IGD_BC_PARTNERSHIP))
    }

    function o(a) {
        return m(a, !1)
    }

    function p(a) {
        return (h || (h = d("I64"))).equal(a.parentThreadKey, (i || (i = d("LSIntEnum"))).ofNumber(-3))
    }

    function q(a) {
        return a == null ? !1 : (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingThreadSubtype").BUSINESS_SUPPORT_THREAD)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingThreadSubtype").SUPPORT_MESSAGING_THREAD))
    }

    function r(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(2))
    }

    function s(a) {
        var b = (h || (h = d("I64"))).equal(a.threadType, (i || (i = d("LSIntEnum"))).ofNumber(2)),
            c = (h || (h = d("I64"))).equal(a.threadType, (i || (i = d("LSIntEnum"))).ofNumber(1)) && !N(a);
        return !q(a.threadSubtype) && (b || c)
    }

    function t(a) {
        return s(a) || k(a.threadType)
    }

    function u(a) {
        return a == null ? !1 : (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingThreadSubtype").PAGE_TO_USER))
    }

    function v(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(150)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(154)) && c("MetaConfig")._("36")
    }

    function w(a) {
        return (y(a) || z(a)) && c("MetaConfig")._("32")
    }

    function x(a) {
        return (y(a) || z(a)) && !c("MetaConfig")._("32")
    }

    function y(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(152))
    }

    function z(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(153))
    }

    function A(a) {
        return ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(155)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(154))) && c("MetaConfig")._("36")
    }

    function B(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(154)) && c("MetaConfig")._("36")
    }

    function C(a) {
        return a == null ? !1 : (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(150)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(154))
    }

    function D(a) {
        return C(a) || w(a)
    }

    function E(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(26))
    }

    function F(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(17))
    }

    function G(a) {
        return (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(19))
    }

    function H(a) {
        return a == null ? !1 : (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(151)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(155))
    }

    function I(a) {
        return a == null ? !1 : H(a) || z(a)
    }

    function J(a) {
        return a == null ? !1 : (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(201))
    }

    function K(a) {
        return d("LSThreadBitOffset").has(183, a)
    }

    function L(a) {
        return k(a) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(2)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(3)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(4)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(5)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(6)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(10)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(11))
    }

    function M(a) {
        return D(a) || H(a) || z(a) || c("mwCMIsAnyCMThread")(a) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(17)) || E(a)
    }

    function N(a) {
        return (h || (h = d("I64"))).equal(a.threadType, (i || (i = d("LSIntEnum"))).ofNumber(1)) && a.cannotUnsendReason != null && (h || (h = d("I64"))).equal(a.cannotUnsendReason, (i || (i = d("LSIntEnum"))).ofNumber(c("LSMessageThreadUnsendabilityStatus").DENY_IF_PAGE_THREAD))
    }

    function O(a) {
        return a != null && ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingThreadSubtype").WORKCHAT_GROUP_THREAD)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingThreadSubtype").WORKROOM_GROUP_THREAD)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingThreadSubtype").WORKCHAT_ONE_TO_ONE)))
    }

    function P(a) {
        if (j(a)) return (i || (i = d("LSIntEnum"))).ofNumber(15);
        if (r(a)) return (i || (i = d("LSIntEnum"))).ofNumber(16);
        throw c("unrecoverableViolation")("Expected either open 1:1 or open group thread", "messenger_web_product")
    }
    g.isGroup = a;
    g.isOpenOneToOne = j;
    g.isOneToOne = b;
    g.isArmadilloSecure = k;
    g.isArmadilloSecureOneToOne = e;
    g.isRecentsSectionAllowedTypes = f;
    g.isMessengerOrE2EEInbox = l;
    g.isMessageRequest = m;
    g.isPartnership = n;
    g.isIGDMessageRequest = o;
    g.isHiddenRequest = p;
    g.isBusinessSupportThread = q;
    g.isOpenGroupFnFThread = r;
    g.isOpenFnFThread = s;
    g.isOpenOrArmadilloFnFThread = t;
    g.isPageToUserThread = u;
    g.isJoinedSocialChannel = v;
    g.isDiscoverablePublicBroadcastChannel = w;
    g.isDiscoverablePublicBroadcastChannelWithNoAccessibility = x;
    g.isJoinedDiscoverablePublicBroadcastChannel = y;
    g.isUnjoinedDiscoverablePublicBroadcastChannel = z;
    g.isSocialChannelV2 = A;
    g.isJoinedSocialChannelV2 = B;
    g.isSocialChannel = C;
    g.isDiscoverableChannel = D;
    g.isCMSubthread = E;
    g.isCMFolder = F;
    g.isCMGroupUnjoined = G;
    g.isSocialChannelUnjoined = H;
    g.isChannelPreview = I;
    g.isAiBot = J;
    g.isAiBotSummoning = K;
    g.isPrivateThread = L;
    g.isPublicCMThread = M;
    g.isThreadForPage = N;
    g.isWorkThread = O;
    g.mapOpenToSecureThreadType = P
}), 98);
__d("WADynamicRouterAsync", ["Promise", "WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " is not defined for ", ""]);
        i = function() {
            return a
        };
        return a
    }
    var j = {
            sentinel: "RESPONSE_NAMESPACE"
        },
        k = {
            sentinel: "NOT_HANDLED"
        };
    a = function() {
        function a() {
            var a = this;
            this.$2 = (h || (h = b("Promise"))).resolve();
            this.$3 = new Map();
            this.$5 = 0;
            this.$6 = null;
            this.$7 = null;
            this.$8 = null;
            this.fireAndForget = function(b, c, d, e) {
                e === void 0 && (e = !1), a.$4 == null ? void 0 : a.$4(b, c, d), a.$10(b, c, d, null, e)
            };
            this.sendAndReceive = function(c, d, e, f) {
                f === void 0 && (f = !1);
                a.$4 == null ? void 0 : a.$4(c, d, e);
                return new(h || (h = b("Promise")))(function(b, g) {
                    a.$10(c, d, e, function(c) {
                        try {
                            var d = n(c);
                            d ? d.call(c, function(c) {
                                a.$10(j, "", c, b, f)
                            }, function(b) {
                                a.$10(j, "", b, g, !1)
                            }) : a.$10(j, "", c, b, f)
                        } catch (b) {
                            a.$10(j, "", b, g, !1)
                        }
                    }, f)
                })
            };
            this.$9 = function() {
                var b = a.$7;
                if (!b) return;
                var c = a.$3,
                    d;
                while (b && !(d = l(c, b))) a.$7 = b = b.nextRoute;
                if (!b || !d) return;
                c = a.$11(d, b);
                var e = !0;
                if (c !== k) {
                    var f = b.prevRoute,
                        g = b.nextRoute;
                    a.$7 === b && (a.$7 = g);
                    f ? f.nextRoute = g : a.$6 = g;
                    g ? g.prevRoute = f : (e = !1, a.$8 = f)
                }
                e && a.$2.then(a.$9)["finally"](function() {});
                return c
            }
        }
        var e = a.prototype;
        e.setAckPayload = function(a) {
            this.$1 = a
        };
        e.getAckPayoad = function() {
            return this.$1
        };
        e.hasHandlerForNamespace = function(a) {
            return this.$3.has(a)
        };
        e.getHandledNamespaces = function() {
            return Array.from(this.$3.keys())
        };
        e.setOnRouteCalled = function(a) {
            this.$4 = a
        };
        e.setNamespaceHandler = function(a, b) {
            var c = this.$3,
                d = c.get(a);
            if (d === b) return;
            ++this.$5;
            c.set(a, b);
            if (!d) {
                c = this.$6;
                c && (this.$7 || this.$2.then(this.$9)["finally"](function() {}), this.$7 = c)
            }
        };
        e.setHandlers = function(a, b) {
            function e(e, f, g) {
                if (b[e] == null) {
                    d("WALogger").ERROR(i(), e, a);
                    throw c("err")(e + " is not defined for " + a)
                }
                e = b[e](f);
                g && g(e)
            }
            this.setNamespaceHandler(a, e)
        };
        e.$10 = function(a, b, c, d, e) {
            var f = this.$8;
            a = {
                namespace: a,
                route: b,
                arg: c,
                resolver: d,
                prevRoute: f,
                nextRoute: null,
                silentLog: e
            };
            this.$8 = a;
            b = !0;
            f ? (f.nextRoute = a, b = !this.$7) : this.$6 = a;
            b && l(this.$3, a) && (this.$7 = a, this.$2.then(this.$9)["finally"](function() {}))
        };
        e.$11 = function(a, d) {
            var e = d.route,
                f = d.arg,
                g = d.resolver;
            d = d.silentLog;
            var i = this.$5,
                j = null,
                l = null;
            try {
                j = a(e, f, g, d)
            } catch (a) {
                l = (h || (h = b("Promise"))).reject(a)
            }
            if (j === k)
                if (i === this.$5) l = (h || (h = b("Promise"))).reject(c("err")("DynamicRouter: NOT_HANDLED can only be used when updating handlers"));
                else return k;
            if (g) {
                l && g(l);
                return
            } else return l
        };
        return a
    }();

    function l(a, b) {
        b = b.namespace;
        return b === j ? m : a.get(b)
    }

    function m(a, b, c) {
        c(b)
    }

    function n(a) {
        if (a != null && (typeof a === "object" || typeof a === "function")) {
            a = a.then;
            return typeof a === "function" ? a : null
        }
        return null
    }
    g.NOT_HANDLED = k;
    g.DynamicRouter = a
}), 98);
__d("WABridge", ["WADynamicRouterAsync", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        if (h != null) return;
        h = a
    }

    function b() {
        if (h == null) {
            h = new(d("WADynamicRouterAsync").DynamicRouter)();
            return h
        }
        return h
    }

    function e(a) {
        throw c("err")("setBridge is only for tests")
    }
    g.makeWABridge = a;
    g.getBridge = b;
    g.setBridge__TESTS_ONLY = e
}), 98);
__d("SharedWorkerUtils", ["WorkerConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function b() {
        return d("WorkerConfig").worker === "shared" && "SharedWorker" in a && typeof a.SharedWorker === "function"
    }
    g.isSharedWorkerSupported = b
}), 98);
__d("shouldUseMAWSharedWorker", ["SharedWorkerUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return d("SharedWorkerUtils").isSharedWorkerSupported()
    }
    g.shouldUseMAWSharedWorker = a
}), 98);
__d("WAResolvable", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;
    a = function() {
        function a() {
            var a = this;
            this.$1 = function() {};
            this.$2 = !1;
            this.isSettled = !1;
            this.promise = new(g || (g = b("Promise")))(function(b) {
                a.$1 = b
            })
        }
        var c = a.prototype;
        c.resolve = function(a) {
            this.$2 = !0, this.isSettled = !0, this.$1(a)
        };
        c.reject = function(a) {
            this.isSettled = !0, this.resolve((g || (g = b("Promise"))).reject(a))
        };
        c.resolveWasCalled = function() {
            return this.$2
        };
        return a
    }();
    f.Resolvable = a
}), 66);
__d("MAWGetIsMediaDownloadStatusEnabled", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        return c("gkx")("7811")
    }

    function a() {
        return !h() ? !1 : c("gkx")("7858")
    }
    g.getIsMediaDownloadStatusEnabled = h;
    g.getIsMediaDownloadStatusForXMAsEnabled = a
}), 98);
__d("WALoggerDeferred", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("WATagsLogger").__setRef("WALoggerDeferred");

    function a(a) {
        for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
        return h.load().then(function(b) {
            return b.whenReady().then(function() {
                var d;
                return (d = b.TAGS([])).DEV.apply(d, [a].concat(c))
            })
        })
    }

    function b(a) {
        for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
        return h.load().then(function(b) {
            return b.whenReady().then(function() {
                var d;
                return (d = b.TAGS([])).DEV_XMPP.apply(d, [a].concat(c))
            })
        })
    }

    function d(a) {
        for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
        return h.load().then(function(b) {
            return b.whenReady().then(function() {
                var d;
                return (d = b.TAGS([])).LOG.apply(d, [a].concat(c))
            })
        })
    }

    function e(a) {
        for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
        return h.load().then(function(b) {
            return b.whenReady().then(function() {
                var d;
                return (d = b.TAGS([])).WARN.apply(d, [a].concat(c))
            })
        })
    }

    function f(a) {
        for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
        return h.load().then(function(b) {
            return b.whenReady().then(function() {
                var d;
                return (d = b.TAGS([])).ERROR.apply(d, [a].concat(c))
            })
        })
    }

    function i(a, b, c) {
        return h.load().then(function(d) {
            return d.whenReady().then(function() {
                return d.TAGS(a)
            }).then(function(a) {
                a[c](b)
            })
        })
    }
    g.DEV = a;
    g.DEV_XMPP = b;
    g.LOG = d;
    g.WARN = e;
    g.ERROR = f;
    g.logWithTags = i
}), 98); /*FB_PKG_DELIM*/
__d("LSTableDefaults", ["I64MigrationHelper"], (function(a, b, c, d, e, f) {
    e.exports = {
        sync_groups: {
            syncStatus: (a = b("I64MigrationHelper")).cast([0, 0]),
            sendSyncParams: !1,
            minTimeToSyncTimestampMs: a.cast([0, 0]),
            canIgnoreTimestamp: !1,
            priority: a.cast([0, 0]),
            lastSyncRequestTimestampMs: a.cast([0, 0]),
            lastSyncCompletedTimestampMs: a.cast([0, 0]),
            syncChannel: a.cast([0, 1])
        },
        pending_tasks: {
            enqueueTimestampMs: a.cast([0, 0]),
            firstExecutedTimestampMs: a.cast([0, 0]),
            failureCount: a.cast([0, 0]),
            minTimeToSyncTimestampMs: a.cast([0, 0]),
            pluginType: a.cast([0, 0]),
            priority: a.cast([0, 0]),
            taskDispatchPriority: a.cast([0, 0])
        },
        pending_fire_and_forget_tasks: {
            enqueueTimestampMs: a.cast([0, 0]),
            priority: a.cast([0, 0])
        },
        contacts: {
            isMessengerUser: !1,
            isMemorialized: !1,
            blockedByViewerStatus: a.cast([0, 0]),
            rank: 0,
            contactType: a.cast([0, 0]),
            contactTypeExact: a.cast([0, 0]),
            canViewerMessage: !0,
            gender: a.cast([0, 0]),
            authorityLevel: a.cast([0, 0]),
            optimisticBlockedByViewerStatus: a.cast([0, 0]),
            optimisticBlockedByViewerStatusTimestampMs: a.cast([0, 0]),
            contactReachabilityStatusType: a.cast([0, 0]),
            restrictionType: a.cast([0, 0]),
            waConnectStatus: a.cast([0, 0]),
            capabilities2: a.cast([0, 0]),
            isEmployee: !1
        },
        ig_contact_info: {
            e2eeEligibility: a.cast([0, 0])
        },
        bot_profile_info_v2: {
            hasEmbodiment: !1
        },
        reactions: {
            timestampMs: a.cast([0, 0]),
            authorityLevel: a.cast([0, 0]),
            reactionCreationTimestampMs: a.cast([0, 0]),
            transportKey: "FBBroker"
        },
        threads: {
            lastActivityTimestampMs: a.cast([0, 0]),
            lastReadWatermarkTimestampMs: a.cast([0, 0]),
            removeWatermarkTimestampMs: a.cast([0, 0]),
            muteExpireTimeMs: a.cast([0, 0]),
            isAdminSnippet: !1,
            ongoingCallState: a.cast([0, 0]),
            snippetHasEmoji: !1,
            hasPersistentMenu: !1,
            disableComposerInput: !1,
            capabilities: a.cast([0, 0]),
            isCustomThreadPicture: !1,
            isDisappearingMode: !1,
            unreadDisappearingMessageCount: a.cast([0, 0]),
            authorityLevel: a.cast([0, 0]),
            capabilities2: a.cast([0, 0]),
            muteCallsExpireTimeMs: a.cast([0, 0]),
            unsendLimitMs: a.cast([0, 0]),
            threadInvitesEnabled: a.cast([0, 0]),
            threadInvitesEnabledV2: a.cast([0, 0]),
            capabilities3: a.cast([0, 0]),
            muteMentionExpireTimeMs: a.cast([0, 0]),
            isReadReceiptsDisabled: !1,
            readReceiptsDisabledV2: a.cast([0, 0]),
            capabilities4: a.cast([0, 0]),
            isHidden: !1,
            typingIndicatorDisabled: a.cast([0, 0])
        },
        threads_ranges_v2__generated: {
            minThreadKey: a.cast([0, 0]),
            minLastActivityTimestampMs: a.cast([0, 0]),
            maxThreadKey: a.cast([0, 0]),
            maxLastActivityTimestampMs: a.cast([0, 0]),
            isLoadingBefore: !1,
            isLoadingAfter: !1,
            hasMoreBefore: !1,
            hasMoreAfter: !1
        },
        messages: {
            timestampMs: a.cast([0, 0]),
            primarySortKey: a.cast([0, 0]),
            secondarySortKey: a.cast([0, 0]),
            isAdminMessage: !1,
            sendStatus: a.cast([0, 0]),
            sendStatusV2: a.cast([0, 0]),
            isUnsent: !1,
            replyStatus: a.cast([0, 0]),
            replyAttachmentType: a.cast([0, 0]),
            hasQuickReplies: !1,
            textHasLinks: !1,
            viewFlags: a.cast([0, 0]),
            displayedContentTypes: a.cast([0, 1]),
            quickReplyType: a.cast([0, 0]),
            authorityLevel: a.cast([0, 0]),
            unsentTimestampMs: a.cast([0, 0]),
            isCollapsed: !1,
            messageRenderingType: a.cast([0, 0]),
            transportKey: "FBBroker",
            isExpired: !1
        },
        messages_ranges_v2__generated: {
            isLoadingBefore: !1,
            isLoadingAfter: !1,
            hasMoreBefore: !1,
            hasMoreAfter: !1
        },
        participants: {
            readWatermarkTimestampMs: a.cast([0, 0]),
            deliveredWatermarkTimestampMs: a.cast([0, 0]),
            authorityLevel: a.cast([0, 0]),
            readActionTimestampMs: a.cast([0, 0]),
            groupParticipantJoinState: a.cast([0, 0]),
            threadRoles: a.cast([0, 0])
        },
        attachments: {
            timestampMs: a.cast([0, 0]),
            attachmentType: a.cast([0, 0]),
            hasMedia: !1,
            isSharable: !1,
            hasXma: !1,
            attachmentIndex: a.cast([0, 0]),
            authorityLevel: a.cast([0, 0]),
            transportKey: "FBBroker"
        },
        attachments_ranges_v2__generated: {
            mediaGroup: a.cast([0, 0]),
            isLoadingBefore: !1,
            isLoadingAfter: !1,
            hasMoreBefore: !1,
            hasMoreAfter: !1
        },
        attachment_items: {
            attachmentIndex: a.cast([0, 0])
        },
        group_membership_approval_requests: {
            authorityLevel: a.cast([0, 0])
        },
        admin_message_ctas: {
            timestampMs: a.cast([0, 0]),
            showAdChoiceIcon: !1
        },
        thread_nullstate: {
            ctaType: a.cast([0, 0]),
            privacyTextCtaType: a.cast([0, 0])
        },
        messages_optimistic_context: {
            transportKey: "FBBroker"
        },
        messages_status: {
            timestampMs: a.cast([0, 0])
        },
        polls: {
            pollType: a.cast([0, 0])
        },
        poll_options_v2: {
            voteCount: a.cast([0, 0]),
            sortKeyVotingTimestamp: a.cast([0, 0]),
            sortKeyCreationTimestamp: a.cast([0, 0])
        },
        filtered_threads_ranges_v3__generated: {
            minThreadKey: a.cast([0, 0]),
            minLastActivityTimestampMs: a.cast([0, 0]),
            maxThreadKey: a.cast([0, 0]),
            maxLastActivityTimestampMs: a.cast([0, 0]),
            isLoadingBefore: !1,
            isLoadingAfter: !1,
            hasMoreBefore: !1,
            hasMoreAfter: !1,
            folderName: "inbox",
            secondaryThreadRangeFilter: a.cast([0, 0]),
            threadRangeFilterValue: "",
            syncGroup: a.cast([0, 1])
        },
        community_folders: {
            capabilities: a.cast([0, 0]),
            notificationMutedUntil: a.cast([0, 0]),
            inviteStatus: a.cast([0, 0]),
            capabilities2: a.cast([0, 0]),
            capabilities3: a.cast([0, 0])
        },
        community_members: {
            source: a.cast([0, 0]),
            adminActions: a.cast([0, 0]),
            contactCapabilities: a.cast([0, 0]),
            channelBadges: a.cast([0, 0]),
            threadRoles: a.cast([0, 0]),
            requestId: ""
        },
        ig_thread_info: {
            igDmSettingsMode: a.cast([0, 0]),
            igDmSettingsTtlSec: a.cast([-1, 4294967295])
        },
        edit_message_history: {
            sendStatus: a.cast([0, 0])
        },
        ig_thread_labels: {
            labelTimestampMs: a.cast([0, 0])
        },
        inbox_threads_ranges: {
            minThreadKey: a.cast([0, 0]),
            minLastActivityTimestampMs: a.cast([0, 0]),
            isLoadingBefore: !1,
            hasMoreBefore: !1
        },
        community_direct_invites_presets: {
            fallbackUrl: "",
            pictureUrlExpirationTimestampMs1: a.cast([0, 0]),
            pictureUrlExpirationTimestampMs2: a.cast([0, 0]),
            presetTypeV2: "ALL_MEMBERS"
        },
        sync_group_threads_ranges: {
            minThreadKey: a.cast([0, 0]),
            minLastActivityTimestampMs: a.cast([0, 0]),
            isLoadingBefore: !1,
            hasMoreBefore: !1
        },
        community_chat_polls: {
            pollType: a.cast([0, 0])
        },
        community_chat_poll_options: {
            voteCount: a.cast([0, 0]),
            sortKeyVotingTimestamp: a.cast([0, 0]),
            sortKeyCreationTimestamp: a.cast([0, 0])
        },
        reactions_v2: {
            viewerReactionTimestampMs: a.cast([0, 0]),
            lastUpdatedTimestampMs: a.cast([0, 0])
        },
        group_invitations_pending: {
            communityJoinRequestStatus: a.cast([0, 0]),
            communityParticipationControlRequestStatus: a.cast([0, 0]),
            communityParticipationControlSetting: a.cast([0, 0])
        },
        thread_label_mappings: {
            sortKey: a.cast([0, 0])
        },
        inbox_view_state: {
            value: ""
        },
        inbox_view_state_v2: {
            value: ""
        },
        discoverable_chat_participants: {
            source: a.cast([0, 0])
        },
        roll_calls: {
            viewerHasContributed: !1,
            viewerCanEditPrompt: !1,
            isBlurred: !1,
            canViewWithoutContributing: !1
        },
        roll_call_contributions_v2: {
            contributorId: a.cast([0, 0]),
            contributionSource: a.cast([0, 0])
        },
        shared_albums: {
            lastActivityTimestampMs: a.cast([0, 0]),
            contributionCount: a.cast([0, 0])
        },
        shared_album_contributions: {
            creationTimestampMs: a.cast([0, 0]),
            creatorId: a.cast([0, 0])
        },
        search_queries: {
            surfaceType: a.cast([0, 1])
        },
        universal_search_recent_searches: {
            lastAccessedTimestampMs: a.cast([0, 0])
        },
        cm_search_nullstate_metadata: {
            score: 0
        },
        ai_bot_search_metadata: {
            displayName: "",
            contactViewerRelationship: a.cast([0, 0]),
            score: 0
        },
        contact_upload_settings: {
            authorityLevel: a.cast([0, 0])
        },
        presence_settings: {
            isActiveStatusViewable: !1,
            isActiveStatusViewableOnFb: !1,
            isActiveStatusViewableOnMessenger: !1,
            hasConvertedToViewSideSettings: !1
        },
        video_chat_links_joining: {
            canAnonymousUsersJoin: !1
        },
        notification_settings: {
            includeInSwitchAccountBadges: !1,
            mutePageAccountMessageReminder: !1
        },
        avatar_settings: {
            enableAvatarHotlike: !1
        },
        messaging_privacy_settings: {
            readReceiptsDisabled: a.cast([0, 0]),
            e2eeXmaPreviewsDisabled: !1
        },
        rtc_call_events: {
            isProcessed: !1
        },
        custom_thread_commands: {
            isOpenPersistentMenu: !1
        },
        transaction_history: {
            timestampMs: a.cast([0, 0])
        },
        thread_themes: {
            isDeprecated: !1,
            iconUrl: "",
            iconUrlFallback: "",
            backgroundUrl: ""
        },
        ranking_scores: {
            score: 0,
            scoreIndex: a.cast([0, 0])
        },
        story_buckets: {
            pageNum: a.cast([0, 0]),
            readState: a.cast([0, 0])
        },
        stories: {
            authorityLevel: a.cast([0, 0])
        },
        story_viewers: {
            interactionType: a.cast([0, 1]),
            authorityLevel: a.cast([0, 0])
        },
        story_reactions: {
            authorityLevel: a.cast([0, 0])
        },
        story_ad_unit: {
            shouldShowAdChoice: !1
        },
        story_overlays: {
            authorityLevel: a.cast([0, 0])
        },
        rooms: {
            notificationMutedUntilMs: a.cast([0, 0])
        },
        media_staging: {
            progress: 0
        },
        client_messages: {
            textSize: a.cast([0, 0]),
            sendStatus: a.cast([0, 0]),
            isHidden: !1,
            isTombstoned: !1,
            isReplyOnly: !1,
            messageContentType: a.cast([0, 0]),
            messageContentSubtype: a.cast([0, 0]),
            messageSource: a.cast([0, 0]),
            messageCreationType: a.cast([0, 0]),
            messageEphemeralityType: a.cast([0, 0]),
            replyStatus: a.cast([0, 0]),
            replyMessageTextSize: a.cast([0, 0]),
            replyVicinityStatus: a.cast([0, 0]),
            isForwarded: !1,
            isReadonly: !1,
            disabledActionsReason: a.cast([0, 0]),
            shouldPersist: !1,
            shouldHideInSnippet: !1
        },
        client_participants: {
            isPending: !1,
            capabilities1: a.cast([0, 0]),
            capabilities2: a.cast([0, 0]),
            readActionTsMs: a.cast([0, 0])
        },
        client_threads: {
            isAdminSnippet: !1,
            isHotlikeSnippet: !1,
            groupMemberAddMode: a.cast([0, 0]),
            capabilities1: a.cast([0, 0]),
            capabilities2: a.cast([0, 0]),
            isHidden: !1,
            isTombstoned: !1,
            isPending: !1,
            isShadowThread: !1,
            pinnedMessagesCount: a.cast([0, 0])
        },
        data_trace_meta: {
            initTimestampMs: a.cast([0, 0]),
            foregroundTimestampMs: a.cast([0, 0]),
            traceType: a.cast([0, 0]),
            shouldFlush: !1
        },
        data_trace_addon: {
            timestampMs: a.cast([0, 0])
        },
        pending_backups_context_v2: {
            isInstamadillo: !1
        },
        secure_encrypted_backups_client_state: {
            authorityLevel: a.cast([0, 0]),
            encryptionVersion: a.cast([0, 0]),
            revisionVersion: a.cast([0, 0])
        },
        secure_encrypted_backups_epochs: {
            authorityLevel: a.cast([0, 0])
        },
        encrypted_backups: {
            authorityLevel: a.cast([0, 0]),
            hasOtcEligibleDevices: !1
        },
        secure_encrypted_backups_generated_recovery_code: {
            virtualDeviceType: a.cast([0, 1])
        },
        encrypted_backups_virtual_devices: {
            virtualDeviceType: a.cast([0, 1]),
            removalStatus: a.cast([0, 1]),
            requiresHsmMigration: !1
        },
        encrypted_backups_metadata: {
            authorityLevel: a.cast([0, 0])
        },
        cutover_threads: {
            isMigrated: !1,
            showOpenMessageHistory: !1
        },
        persistent_menu_ctas: {
            ctaType: "fallback"
        },
        anonymous_task_context: {
            failureCount: a.cast([0, 0])
        },
        lightspeed_task_context: {
            requiresAuthentication: !1
        },
        messenger_fts_threads: {
            nextMessageTimestamp: a.cast([-1, 4294967295]),
            status: a.cast([0, 0]),
            threadType: a.cast([0, 0])
        },
        messenger_fts_threads_queries: {
            sessionId: ""
        }
    }
}), null);
__d("LSTableSchemas", [], (function(a, b, c, d, e, f) {
    e.exports = [
        [{
            name: "sync_groups",
            id: 1,
            primary_key: ["groupId"]
        }, {
            name: "pending_tasks",
            id: 2,
            primary_key: ["taskId"],
            indexes: {
                queueNameTaskId: {
                    columns: ["queueName", "taskId"]
                }
            },
            auto_increment: !0
        }, {
            name: "network_requests",
            id: 3,
            primary_key: ["taskQueueName", "syncDatabaseId"]
        }, {
            name: "_user_info",
            id: 4,
            primary_key: ["id"]
        }, {
            name: "pending_fire_and_forget_tasks",
            id: 5,
            primary_key: ["taskId"],
            auto_increment: !0
        }, {
            name: "user_visible_errors",
            id: 6,
            primary_key: ["errorId"],
            auto_increment: !0
        }, {
            name: "mailbox_task_completion_notification_context",
            id: 232,
            primary_key: ["notificationScopeKey"]
        }, {
            name: "mailbox_task_completion_api_tasks",
            id: 233,
            primary_key: ["taskId"]
        }],
        [{
            name: "contacts",
            id: 7,
            primary_key: ["id"],
            indexes: {
                blockedByViewerStatusId: {
                    columns: ["blockedByViewerStatus", "id"]
                }
            }
        }, {
            name: "ig_contact_info",
            id: 176,
            primary_key: ["contactId"]
        }, {
            name: "work_contact_info",
            id: 210,
            primary_key: ["id"]
        }, {
            name: "contextual_profile_v1",
            id: 216,
            primary_key: ["ownerId", "associatedEntityId"],
            indexes: {
                associatedEntityIdAndOwner: {
                    columns: ["associatedEntityId", "ownerId"]
                }
            }
        }, {
            name: "profile_sheet_information",
            id: 256,
            primary_key: ["userId"]
        }, {
            name: "fb_transport_contacts",
            id: 240,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "bot_profile_info_v2",
            id: 299,
            primary_key: ["botId"]
        }, {
            name: "horizon_contact_info",
            id: 323,
            primary_key: ["contactId"]
        }],
        [{
            name: "reactions",
            id: 8,
            primary_key: ["threadKey", "messageId", "actorId"],
            indexes: {
                fk_messages: {
                    columns: ["threadKey", "timestampMs", "messageId", "actorId"]
                }
            }
        }, {
            name: "threads",
            id: 9,
            primary_key: ["threadKey"],
            indexes: {
                lastActivityTimestampMs: {
                    columns: ["lastActivityTimestampMs", "threadKey"]
                },
                parentThreadKeyLastActivityTimestampMs: {
                    columns: ["parentThreadKey", "lastActivityTimestampMs", "threadKey"]
                },
                secondaryParentThreadKeyLastActivityTimestampMs: {
                    columns: ["secondaryParentThreadKey", "lastActivityTimestampMs", "threadKey"],
                    ignore_nulls: ["secondaryParentThreadKey"]
                },
                clientThreadKey: {
                    columns: ["clientThreadKey", "threadKey"],
                    ignore_nulls: ["clientThreadKey"]
                },
                threadTypeLastActivityTimestampMs: {
                    columns: ["threadType", "lastActivityTimestampMs", "threadKey"]
                },
                syncGroupParentThreadKeyLastActivityTimestampMs: {
                    columns: ["syncGroup", "parentThreadKey", "lastActivityTimestampMs", "threadKey"]
                }
            }
        }, {
            name: "threads_ranges_v2__generated",
            id: 10,
            primary_key: ["parentThreadKey", "minThreadKey", "minLastActivityTimestampMs"]
        }, {
            name: "messages",
            id: 12,
            primary_key: ["threadKey", "timestampMs", "messageId"],
            indexes: {
                optimistic: {
                    columns: ["offlineThreadingId"]
                },
                messageDisplayOrder: {
                    columns: ["threadKey", "primarySortKey", "secondarySortKey", "messageId", "isCollapsed"]
                },
                messageId: {
                    columns: ["messageId"]
                },
                messageSubthreadKey: {
                    columns: ["subthreadKey", "primarySortKey", "secondarySortKey", "messageId", "isCollapsed"],
                    ignore_nulls: ["subthreadKey"]
                },
                replySourceIdMessageID: {
                    columns: ["replySourceId", "messageId"],
                    ignore_nulls: ["replySourceId"]
                },
                ephemeralExpirationTs: {
                    columns: ["ephemeralExpirationTs", "messageId"],
                    ignore_nulls: ["ephemeralExpirationTs"]
                },
                threadKeyPrimarySortKeySecondarySortKeyBotResponseId: {
                    columns: ["threadKey", "primarySortKey", "secondarySortKey", "botResponseId", "messageId"],
                    ignore_nulls: ["botResponseId"]
                },
                messageGroupId: {
                    columns: ["groupId", "messageId"],
                    ignore_nulls: ["groupId"]
                }
            }
        }, {
            name: "messages_ranges_v2__generated",
            id: 13,
            primary_key: ["threadKey", "minTimestampMs", "minMessageId"]
        }, {
            name: "participants",
            id: 14,
            primary_key: ["threadKey", "contactId"],
            indexes: {
                threadKeyReadWatermarkTimestampMs: {
                    columns: ["threadKey", "readWatermarkTimestampMs", "contactId"]
                },
                threadKeyDeliveredWatermarkTimestampMs: {
                    columns: ["threadKey", "deliveredWatermarkTimestampMs", "contactId"]
                },
                contactIdThreadKey: {
                    columns: ["contactId", "threadKey"]
                }
            }
        }, {
            name: "ctas",
            id: 15,
            primary_key: ["ctaId"]
        }, {
            name: "attachments",
            id: 16,
            primary_key: ["threadKey", "messageId", "attachmentFbid"],
            indexes: {
                fk_messages: {
                    columns: ["threadKey", "timestampMs", "messageId", "attachmentFbid"]
                },
                idx_attachments_collapsible_id: {
                    columns: ["threadKey", "collapsibleId", "messageId", "attachmentFbid"]
                }
            }
        }, {
            name: "attachments_ranges_v2__generated",
            id: 17,
            primary_key: ["threadKey", "mediaGroup", "minTimestampMs"]
        }, {
            name: "attachment_items",
            id: 18,
            primary_key: ["attachmentFbid", "attachmentIndex"],
            indexes: {
                fk_attachments: {
                    columns: ["threadKey", "messageId", "attachmentFbid", "attachmentIndex"]
                }
            }
        }, {
            name: "attachment_ctas",
            id: 19,
            primary_key: ["ctaId"],
            indexes: {
                fk_attachments: {
                    columns: ["threadKey", "messageId", "attachmentFbid", "ctaId"]
                }
            }
        }, {
            name: "quick_reply_ctas",
            id: 20,
            primary_key: ["threadKey", "messageId", "ctaId"]
        }, {
            name: "m_suggestions",
            id: 21,
            primary_key: ["threadKey", "timestampMs", "suggestionId"]
        }, {
            name: "rtc_signals",
            id: 22,
            primary_key: ["timestampMs", "type_"]
        }, {
            name: "rtc_ongoing_calls_on_threads_v2",
            id: 23,
            primary_key: ["threadKey"]
        }, {
            name: "rtc_multiway_call_initiation_conference_names",
            id: 24,
            primary_key: ["threadKey"]
        }, {
            name: "mailbox_metadata",
            id: 25,
            primary_key: ["id"]
        }, {
            name: "group_membership_approval_requests",
            id: 26,
            primary_key: ["threadKey", "contactId"]
        }, {
            name: "admin_message_ctas",
            id: 27,
            primary_key: ["threadKey", "messageId", "ctaId"],
            indexes: {
                ctaId: {
                    columns: ["ctaId"]
                }
            }
        }, {
            name: "thread_nullstate",
            id: 28,
            primary_key: ["threadKey"]
        }, {
            name: "thread_nullstate_ctas",
            id: 29,
            primary_key: ["ctaId"],
            indexes: {
                threadKeyCtaId: {
                    columns: ["threadKey", "ctaId"]
                }
            }
        }, {
            name: "focus_mode_ctas",
            id: 30,
            primary_key: ["threadKey", "messageId", "ctaId"]
        }, {
            name: "messages_optimistic_context",
            id: 31,
            primary_key: ["taskId"]
        }, {
            name: "threads_optimistic_context",
            id: 32,
            primary_key: ["taskId"]
        }, {
            name: "messages_status",
            id: 33,
            primary_key: ["messageId", "threadKey", "timestampMs", "threadKeyFromParticipants", "contactId", "type_"]
        }, {
            name: "message_requests",
            id: 34,
            primary_key: ["threadKey"]
        }, {
            name: "folder_metadata",
            id: 35,
            primary_key: ["parentThreadKey"]
        }, {
            name: "polls",
            id: 38,
            primary_key: ["pollId"]
        }, {
            name: "poll_options_v2",
            id: 39,
            primary_key: ["pollId", "optionId"]
        }, {
            name: "poll_votes_v2",
            id: 40,
            primary_key: ["pollId", "optionId", "contactId"]
        }, {
            name: "pinned_messages_v2",
            id: 155,
            primary_key: ["threadKey", "messageId"]
        }, {
            name: "filtered_threads_ranges_v3__generated",
            id: 247,
            primary_key: ["parentThreadKey", "minThreadKey", "minLastActivityTimestampMs", "threadRangeFilter", "folderName", "secondaryThreadRangeFilter", "threadRangeFilterValue"]
        }, {
            name: "community_folders",
            id: 162,
            primary_key: ["folderId"],
            indexes: {
                byFbGroupId: {
                    columns: ["fbGroupId", "folderId"]
                }
            }
        }, {
            name: "community_members",
            id: 170,
            primary_key: ["communityId", "contactId", "source", "requestId"],
            indexes: {
                communitySource: {
                    columns: ["communityId", "source", "requestId", "contactId", "name"]
                },
                communityContact: {
                    columns: ["communityId", "contactId", "requestId", "source", "name"]
                }
            }
        }, {
            name: "community_members_ranges_v2__generated",
            id: 189,
            primary_key: ["communityId", "isAdmin", "minName", "source", "requestId"]
        }, {
            name: "attachment_conversion",
            id: 164,
            primary_key: ["attachmentFbid"]
        }, {
            name: "saved_messages",
            id: 165,
            primary_key: ["threadKey", "messageId"]
        }, {
            name: "rtc_rooms_on_threads",
            id: 181,
            primary_key: ["threadKey"]
        }, {
            name: "ig_thread_info",
            id: 194,
            primary_key: ["threadKey"],
            indexes: {
                igThreadID: {
                    columns: ["igThreadId"]
                }
            }
        }, {
            name: "edit_message_history",
            id: 322,
            primary_key: ["pk"],
            indexes: {
                originalMsgPkEditTs: {
                    columns: ["originalMessagePk", "serverAdjustedEditTsMs"]
                }
            },
            auto_increment: !0
        }, {
            name: "ig_thread_labels",
            id: 318,
            primary_key: ["threadKey", "labelType"]
        }, {
            name: "group_invites",
            id: 197,
            primary_key: ["threadKey", "inviterId", "inviteeId"]
        }, {
            name: "inbox_threads_ranges",
            id: 198,
            primary_key: ["syncGroup"]
        }, {
            name: "community_direct_invites_presets",
            id: 199,
            primary_key: ["communityId", "presetType", "source"]
        }, {
            name: "client_web_pinned_messages",
            id: 328,
            primary_key: ["threadKey", "offlineThreadingId", "pinnedTimestampMs"],
            indexes: {
                pinnedMessageDisplayOrder: {
                    columns: ["threadKey", "pinnedTimestampMs", "offlineThreadingId"]
                }
            }
        }, {
            name: "msg_pinned_messages_v2",
            id: 205,
            primary_key: ["threadKey", "messageId", "pinnedTimestampMs"],
            indexes: {
                pinnedMessageDisplayOrder: {
                    columns: ["threadKey", "pinnedTimestampMs", "messageId"]
                }
            }
        }, {
            name: "filtered_messages_ranges_v2__generated",
            id: 211,
            primary_key: ["threadKey", "mailboxType", "minTimestampMs", "minMessageId", "messageRangeFilter"]
        }, {
            name: "taken_down_threads",
            id: 212,
            primary_key: ["threadKey"]
        }, {
            name: "participant_list_queries",
            id: 219,
            primary_key: ["threadKey"]
        }, {
            name: "sync_group_threads_ranges",
            id: 220,
            primary_key: ["syncGroup", "parentThreadKey"]
        }, {
            name: "community_chat_message_seen_count",
            id: 221,
            primary_key: ["threadKey", "messageId"]
        }, {
            name: "community_chat_polls",
            id: 223,
            primary_key: ["pollId"]
        }, {
            name: "community_chat_poll_options",
            id: 224,
            primary_key: ["pollId", "optionId"]
        }, {
            name: "community_chat_poll_votes",
            id: 225,
            primary_key: ["pollId", "optionId", "contactId"]
        }, {
            name: "reactions_v2",
            id: 226,
            primary_key: ["threadKey", "messageId", "reactionFbid", "messageTimestamp"],
            indexes: {
                optimistic: {
                    columns: ["threadKey", "messageId", "reactionFbid"]
                }
            }
        }, {
            name: "reactions_v2_details_users",
            id: 227,
            primary_key: ["reactorId", "reactionFbid"]
        }, {
            name: "reactions_v2_details_users_ranges_v2__generated",
            id: 228,
            primary_key: ["reactorId", "reactionFbid", "minTimestampMs"]
        }, {
            name: "reaction_v2_types",
            id: 229,
            primary_key: ["reactionFbid"]
        }, {
            name: "bots",
            id: 230,
            primary_key: ["threadKey", "botId"]
        }, {
            name: "business_comm_items",
            id: 234,
            primary_key: ["threadKey", "entId"]
        }, {
            name: "group_invitations_pending",
            id: 235,
            primary_key: ["linkHash"]
        }, {
            name: "business_support_notification_settings",
            id: 236,
            primary_key: ["userId"]
        }, {
            name: "thread_label_mappings",
            id: 237,
            primary_key: ["threadKey", "labelId"]
        }, {
            name: "inbox_view_state",
            id: 277,
            primary_key: ["interface_", "configName"]
        }, {
            name: "inbox_view_state_v2",
            id: 281,
            primary_key: ["configName"]
        }, {
            name: "audio_channel_events",
            id: 238,
            primary_key: ["eventId", "roomId"]
        }, {
            name: "reactions_v2_details",
            id: 239,
            primary_key: ["threadId", "messageId", "reactorId", "reactionFbid"]
        }, {
            name: "reactions_v2_details_ranges_v2__generated",
            id: 243,
            primary_key: ["threadId", "messageId", "reactionFbid", "minTimestampMs"]
        }, {
            name: "community_chat_poll_votes_ranges_v2__generated",
            id: 244,
            primary_key: ["pollId", "optionId", "minTimestampMs"]
        }, {
            name: "discoverable_chat_participants",
            id: 248,
            primary_key: ["threadId", "contactId", "source"]
        }, {
            name: "discoverable_chat_participants_ranges_v2__generated",
            id: 249,
            primary_key: ["threadId", "source", "minName"]
        }, {
            name: "roll_calls",
            id: 250,
            primary_key: ["rollCallId", "threadKey"]
        }, {
            name: "community_surface_ranges",
            id: 253,
            primary_key: ["surfaceType", "communityKey"]
        }, {
            name: "community_rules",
            id: 254,
            primary_key: ["communityId", "ruleId"]
        }, {
            name: "roll_call_contributions_v2",
            id: 255,
            primary_key: ["rollCallContributionId", "rollCallId", "messageId", "messageTimestampMs", "threadKey"],
            indexes: {
                optimistic: {
                    columns: ["rollCallContributionId", "rollCallId", "messageId", "messageTimestampMs"]
                }
            }
        }, {
            name: "business_thread_info",
            id: 260,
            primary_key: ["threadKey"]
        }, {
            name: "thread_creation_status",
            id: 278,
            primary_key: ["taskId"]
        }, {
            name: "shared_albums",
            id: 279,
            primary_key: ["sharedAlbumId", "threadKey"]
        }, {
            name: "shared_album_contributions",
            id: 280,
            primary_key: ["sharedAlbumId", "sharedAlbumContributionId", "threadKey", "messageId"]
        }, {
            name: "shared_albums_multimedia_upload_jobs",
            id: 283,
            primary_key: ["offlineThreadingId"]
        }, {
            name: "shared_albums_multimedia_upload_subjobs_status",
            id: 284,
            primary_key: ["offlineThreadingId", "jobId"]
        }, {
            name: "thread_point_query_ttrc",
            id: 286,
            primary_key: ["threadKey"]
        }, {
            name: "business_thread_suggestions",
            id: 290,
            primary_key: ["threadKey", "suggestionType"]
        }, {
            name: "community_chat_admin_assist_command_sequences",
            id: 291,
            primary_key: ["commandSequenceId"]
        }, {
            name: "community_thread_sync_info",
            id: 294,
            primary_key: ["threadKey"]
        }, {
            name: "thread_bans",
            id: 297,
            primary_key: ["threadKey", "contactId"]
        }, {
            name: "support_translations",
            id: 300,
            primary_key: ["messageId", "targetLocale"]
        }, {
            name: "support_translation_feedback",
            id: 336,
            primary_key: ["messageId", "targetLocale"]
        }, {
            name: "threads_optimistic_metadata",
            id: 312,
            primary_key: ["threadKey"]
        }, {
            name: "ai_bot_feedback_submission_status",
            id: 315,
            primary_key: ["botResponseId"]
        }, {
            name: "igd_xma_receiver_fetch",
            id: 316,
            primary_key: ["messageId"]
        }, {
            name: "thread_seen_heads_queries",
            id: 325,
            primary_key: ["threadKey"]
        }, {
            name: "discoverable_chats_personal_inbox_info",
            id: 326,
            primary_key: ["threadKey"]
        }, {
            name: "e2ee_composer_draft_link_preview",
            id: 329,
            primary_key: ["draftId"]
        }],
        [{
            name: "media_send_jobs",
            id: 51,
            primary_key: ["offlineAttachmentId"]
        }],
        [{
            name: "typing_indicator",
            id: 52,
            primary_key: ["threadKey", "senderId"]
        }],
        [{
            name: "server_search_results",
            id: 65,
            primary_key: ["query", "resultId", "globalIndex"]
        }, {
            name: "server_search_sections",
            id: 66,
            primary_key: ["query", "globalIndex"]
        }, {
            name: "search_queries",
            id: 67,
            primary_key: ["query", "surfaceType"]
        }, {
            name: "universal_search_recent_searches",
            id: 68,
            primary_key: ["resultId"]
        }, {
            name: "message_search_results",
            id: 69,
            primary_key: ["type_", "query", "threadKey", "globalIndex"]
        }, {
            name: "message_search_queries",
            id: 70,
            primary_key: ["type_", "query", "threadKeyV2"]
        }, {
            name: "participant_search_queries",
            id: 214,
            primary_key: ["query", "threadKey"]
        }],
        [{
            name: "cm_search_nullstate_metadata",
            id: 289,
            primary_key: ["threadKey", "scoreType"]
        }],
        [{
            name: "ai_bot_search_metadata",
            id: 298,
            primary_key: ["botId"]
        }],
        [{
            name: "contact_upload_settings",
            id: 74,
            primary_key: ["userid"]
        }, {
            name: "gdpr_settings",
            id: 75,
            primary_key: ["userid"]
        }, {
            name: "presence_settings",
            id: 187,
            primary_key: ["userId"]
        }, {
            name: "persistent_menu_items",
            id: 77,
            primary_key: ["threadKey", "ctaId"]
        }, {
            name: "video_chat_links_joining",
            id: 78,
            primary_key: ["url", "optimisticClientToken"],
            indexes: {
                optimistic: {
                    columns: ["optimisticClientToken"]
                }
            }
        }, {
            name: "video_chat_links_attempted_joiners",
            id: 79,
            primary_key: ["userId", "url"]
        }, {
            name: "cowatch_sessions",
            id: 80,
            primary_key: ["cowatchSessionId"]
        }, {
            name: "self_profile",
            id: 81,
            primary_key: ["userId"]
        }, {
            name: "pinned_threads",
            id: 82,
            primary_key: ["threadKey"],
            indexes: {
                pinnedTimestamp: {
                    columns: ["pinnedTimestamp", "threadKey"]
                }
            }
        }, {
            name: "messaging_settings",
            id: 83,
            primary_key: ["id"]
        }, {
            name: "reachability_settings",
            id: 148,
            primary_key: ["audience"]
        }, {
            name: "feature_limits",
            id: 150,
            primary_key: ["type_"]
        }, {
            name: "emoji_sets",
            id: 151,
            primary_key: ["categoryIdx", "emojiIdx", "type_"]
        }, {
            name: "epd_cookie_settings",
            id: 163,
            primary_key: []
        }, {
            name: "cm_community_list",
            id: 166,
            primary_key: ["communityId"]
        }, {
            name: "cm_channel_list",
            id: 167,
            primary_key: ["communityId", "threadId"],
            indexes: {
                threadIdCommunityId: {
                    columns: ["threadId", "communityId"]
                }
            }
        }, {
            name: "cm_category_list",
            id: 182,
            primary_key: ["communityId", "categoryId"]
        }, {
            name: "notification_settings",
            id: 175,
            primary_key: ["id"]
        }, {
            name: "encrypted_backups_status_trigger",
            id: 195,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "fb_events",
            id: 200,
            primary_key: ["eventId"]
        }, {
            name: "cm_channel_events",
            id: 201,
            primary_key: ["eventId", "threadId"],
            indexes: {
                eventsInThread: {
                    columns: ["threadId", "eventId"]
                }
            }
        }, {
            name: "community_events",
            id: 202,
            primary_key: ["eventId", "communityId"]
        }, {
            name: "avatar_settings",
            id: 209,
            primary_key: ["threadId"]
        }, {
            name: "thread_labels",
            id: 215,
            primary_key: ["labelId"]
        }, {
            name: "thread_limits",
            id: 287,
            primary_key: ["threadKey"]
        }, {
            name: "business_support_case_details",
            id: 222,
            primary_key: ["threadId"]
        }, {
            name: "messaging_privacy_settings",
            id: 288,
            primary_key: ["userId"]
        }, {
            name: "rtc_call_events",
            id: 245,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "custom_thread_commands",
            id: 296,
            primary_key: ["threadKey", "commandId"],
            indexes: {
                rank: {
                    columns: ["threadKey", "rank"]
                },
                commandId: {
                    columns: ["commandId"]
                }
            }
        }, {
            name: "msgr_quiet_time",
            id: 317,
            primary_key: ["quietTimeId"],
            indexes: {
                quietTimeId: {
                    columns: ["quietTimeId"]
                }
            }
        }],
        [{
            name: "payment_type_paypal",
            id: 85,
            primary_key: ["paymentCredentialId"]
        }, {
            name: "payment_type_card",
            id: 86,
            primary_key: ["paymentCredentialId"]
        }, {
            name: "payment_type_bank_v2",
            id: 88,
            primary_key: ["paymentMethodId"]
        }, {
            name: "payment_method",
            id: 89,
            primary_key: ["paymentMethodId"]
        }, {
            name: "new_payment_credential_option",
            id: 90,
            primary_key: ["credentialType"]
        }, {
            name: "paypal_funding_options",
            id: 91,
            primary_key: ["optionId"]
        }, {
            name: "payments_eligibility",
            id: 92,
            primary_key: ["userId"]
        }, {
            name: "payments_ofac_blacklisted_countries",
            id: 93,
            primary_key: ["isoCountryCode"]
        }, {
            name: "p2m_invoice",
            id: 94,
            primary_key: ["orderId"]
        }, {
            name: "p2m_invoice_attachment",
            id: 95,
            primary_key: ["orderId", "productItemId"]
        }, {
            name: "payment_price_list_item",
            id: 96,
            primary_key: ["orderId", "id"]
        }, {
            name: "p2m_charge",
            id: 97,
            primary_key: ["orderId"]
        }, {
            name: "payment_p2p_risk_verification",
            id: 98,
            primary_key: ["requestId", "transactionId"]
        }, {
            name: "payment_transaction_v2",
            id: 99,
            primary_key: ["timestampMs", "transactionId"],
            indexes: {
                optimistic: {
                    columns: ["optimisticTransactionId"]
                }
            }
        }, {
            name: "p2p_request_v2",
            id: 100,
            primary_key: ["timestampMs", "transactionId"],
            indexes: {
                optimistic: {
                    columns: ["optimisticTransactionId"]
                }
            }
        }, {
            name: "p2p_transfer_v2",
            id: 101,
            primary_key: ["timestampMs", "transactionId"],
            indexes: {
                optimistic: {
                    columns: ["optimisticTransactionId"]
                }
            }
        }, {
            name: "transaction_history",
            id: 102,
            primary_key: ["transactionId"]
        }, {
            name: "payments_transaction_details_core",
            id: 103,
            primary_key: ["transactionId"]
        }, {
            name: "payments_transaction_details_ctas",
            id: 104,
            primary_key: ["transactionId", "ctaId"]
        }, {
            name: "payments_transaction_details_rows",
            id: 105,
            primary_key: ["transactionId", "rowOrder"]
        }, {
            name: "payment_user_auth",
            id: 106,
            primary_key: ["userId"]
        }, {
            name: "payment_client_auth_token",
            id: 107,
            primary_key: ["userId", "deviceId", "appId"]
        }, {
            name: "payment_auth_request_results",
            id: 108,
            primary_key: ["requestId"]
        }, {
            name: "payment_server_request_results",
            id: 109,
            primary_key: ["requestId"]
        }, {
            name: "payment_pin_verification_results",
            id: 113,
            primary_key: ["requestId"]
        }],
        [{
            name: "connectivity_status",
            id: 114,
            primary_key: ["statusId"],
            auto_increment: !0
        }, {
            name: "user_visible_network_connectivity_error",
            id: 115,
            primary_key: ["statusId"],
            auto_increment: !0
        }],
        [{
            name: "thread_themes",
            id: 116,
            primary_key: ["fbid"]
        }, {
            name: "gradient_colors",
            id: 117,
            primary_key: ["themeFbid", "gradientIndex"]
        }],
        [{
            name: "in_thread_banner",
            id: 118,
            primary_key: ["threadKey", "bannerId"]
        }, {
            name: "in_thread_banner_ctas",
            id: 119,
            primary_key: ["bannerId", "ctaId"]
        }, {
            name: "in_thread_banner_overflow_menu",
            id: 120,
            primary_key: ["threadKey", "bannerId"]
        }],
        [{
            name: "stickers",
            id: 121,
            primary_key: ["stickerId"],
            indexes: {
                stickerPackId: {
                    columns: ["stickerPackId", "stickerId"]
                }
            }
        }, {
            name: "sticker_packs",
            id: 122,
            primary_key: ["packId"]
        }, {
            name: "sticker_search_results",
            id: 123,
            primary_key: ["resultIndex", "query", "type_"]
        }, {
            name: "sticker_search_queries",
            id: 124,
            primary_key: ["query"]
        }, {
            name: "sticker_search_featured_tags",
            id: 125,
            primary_key: ["tagIndex"]
        }, {
            name: "sticker_to_collection",
            id: 126,
            primary_key: ["stickerId", "collectionId"]
        }, {
            name: "sticker_pack_details",
            id: 127,
            primary_key: ["packId"]
        }, {
            name: "sticker_store_pack_indices",
            id: 128,
            primary_key: ["packId"]
        }],
        [{
            name: "forward_content",
            id: 129,
            primary_key: ["value", "type_"]
        }],
        [{
            name: "linked_groups",
            id: 130,
            primary_key: ["id"],
            indexes: {
                threadKey: {
                    columns: ["threadKey"]
                }
            }
        }],
        [{
            name: "ranking_scores",
            id: 134,
            primary_key: ["contactId", "scoreType"],
            indexes: {
                scoreTypeContactId: {
                    columns: ["scoreType", "contactId"]
                }
            }
        }, {
            name: "ranking_requests",
            id: 135,
            primary_key: ["scoreType"]
        }, {
            name: "value_model_rules",
            id: 136,
            primary_key: ["product", "ruleIndex"]
        }, {
            name: "value_model_features",
            id: 137,
            primary_key: ["feature"]
        }, {
            name: "value_model_output",
            id: 138,
            primary_key: ["product", "contactId"]
        }],
        [{
            name: "story_buckets",
            id: 53,
            primary_key: ["bucketId"],
            indexes: {
                optimistic: {
                    columns: ["ownerId", "bucketType"]
                }
            }
        }, {
            name: "stories",
            id: 54,
            primary_key: ["storyId"],
            indexes: {
                optimistic: {
                    columns: ["optimisticClientId"]
                }
            }
        }, {
            name: "story_viewers",
            id: 55,
            primary_key: ["storyId", "viewerContactId", "interactionType"]
        }, {
            name: "story_reactions",
            id: 56,
            primary_key: ["reactionId"],
            indexes: {
                optimistic: {
                    columns: ["optimisticClientId"]
                }
            }
        }, {
            name: "story_ad_unit",
            id: 57,
            primary_key: ["adPosition", "clientToken"]
        }, {
            name: "story_ad_card",
            id: 58,
            primary_key: ["adPosition", "clientToken", "cardId"]
        }, {
            name: "story_ad_ctas",
            id: 59,
            primary_key: ["ctaId"]
        }, {
            name: "story_overlays",
            id: 60,
            primary_key: ["storyId", "storyOverlayId"]
        }, {
            name: "story_buckets_paginated_queries",
            id: 61,
            primary_key: ["queryId"]
        }, {
            name: "status",
            id: 62,
            primary_key: ["statusId"],
            indexes: {
                optimistic: {
                    columns: ["optimisticClientId"]
                }
            }
        }, {
            name: "rooms",
            id: 63,
            primary_key: ["roomId"],
            indexes: {
                optimistic: {
                    columns: ["optimisticClientToken"]
                }
            }
        }, {
            name: "room_participants",
            id: 64,
            primary_key: ["roomId", "participantId", "type_"],
            indexes: {
                optimistic: {
                    columns: ["roomId", "participantId"]
                }
            }
        }],
        [{
            name: "live_location_sharers",
            id: 149,
            primary_key: ["threadKey", "userId"]
        }],
        [{
            name: "mi_act_mapping_table",
            id: 173,
            primary_key: ["serverThreadKey", "clientThreadPk", "jid"],
            indexes: {
                fk_threads: {
                    columns: ["serverThreadKey"]
                },
                chat_id: {
                    columns: ["clientThreadPk"]
                },
                jid: {
                    columns: ["jid"]
                }
            }
        }, {
            name: "media_staging",
            id: 161,
            primary_key: ["offlineAttachmentId"]
        }, {
            name: "client_accounts",
            id: 272,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "client_messages",
            id: 273,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "client_participants",
            id: 274,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "client_threads",
            id: 276,
            primary_key: ["pk"],
            auto_increment: !0
        }],
        [{
            name: "data_trace_meta",
            id: 153,
            primary_key: ["traceId"],
            indexes: {
                shouldFlushInitTimestampMsTraceId: {
                    columns: ["shouldFlush", "initTimestampMs", "traceId"]
                }
            }
        }, {
            name: "data_trace_addon",
            id: 154,
            primary_key: ["addonId"],
            indexes: {
                traceIdAddonId: {
                    columns: ["traceId", "addonId"]
                }
            },
            auto_increment: !0
        }],
        [{
            name: "ad_context",
            id: 160,
            primary_key: ["adId"]
        }],
        [{
            name: "thread_proactive_warning_settings",
            id: 183,
            primary_key: ["threadKey"]
        }, {
            name: "client_thread_proactive_warning_settings",
            id: 241,
            primary_key: ["threadPk"]
        }],
        [{
            name: "presence_states",
            id: 186,
            primary_key: ["contactId"],
            indexes: {
                statusContactId: {
                    columns: ["status", "contactId"]
                }
            }
        }],
        [{
            name: "available_reactions",
            id: 188,
            primary_key: ["emojiIdx"]
        }],
        [{
            name: "pending_backups_context_v2",
            id: 177,
            primary_key: ["pk"],
            indexes: {
                fk_pending_tasks: {
                    columns: ["pendingBackupTaskId"]
                }
            },
            auto_increment: !0
        }, {
            name: "secure_encrypted_backups_client_state",
            id: 168,
            primary_key: ["backupId"]
        }, {
            name: "encrypted_backups_debug_metadata",
            id: 206,
            primary_key: ["backupId"]
        }, {
            name: "encrypted_backups_epoch_debug_metadata",
            id: 207,
            primary_key: ["epochId"]
        }, {
            name: "encrypted_backups_debug_metadata_v2",
            id: 217,
            primary_key: ["backupId"]
        }, {
            name: "encrypted_backups_epoch_debug_metadata_v2",
            id: 218,
            primary_key: ["epochId"]
        }, {
            name: "secure_encrypted_backups_epochs",
            id: 169,
            primary_key: ["epochId"],
            indexes: {
                fk_secure_encrypted_backups_client_state: {
                    columns: ["backupId", "epochId"]
                }
            }
        }, {
            name: "encrypted_backups",
            id: 172,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "secure_encrypted_backups_generated_recovery_code",
            id: 174,
            primary_key: ["pk"]
        }, {
            name: "secure_encrypted_backups_recovery_code_status",
            id: 178,
            primary_key: ["pk"]
        }, {
            name: "secure_recovery_code_data",
            id: 179,
            primary_key: ["taskId"],
            indexes: {
                fk_pending_tasks: {
                    columns: ["taskId"]
                }
            }
        }, {
            name: "secure_encrypted_backups_message_thread_id_context",
            id: 180,
            primary_key: ["taskId", "listId"],
            indexes: {
                fk_pending_tasks: {
                    columns: ["taskId"]
                }
            }
        }, {
            name: "encrypted_backups_virtual_devices",
            id: 184,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "encrypted_backups_metadata",
            id: 196,
            primary_key: ["backupId"]
        }, {
            name: "device_metadata",
            id: 185,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "encrypted_backup_restore_task_payload_context",
            id: 190,
            primary_key: ["taskId"]
        }, {
            name: "encrypted_backups_dyi_backup_restore_status",
            id: 208,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "encrypted_backups_message_backup_status",
            id: 213,
            primary_key: ["messagePk"]
        }, {
            name: "encrypted_backups_client_restore_status",
            id: 231,
            primary_key: ["threadId"]
        }, {
            name: "third_party_id_store",
            id: 242,
            primary_key: ["platform"]
        }, {
            name: "secure_get_secrets_context",
            id: 259,
            primary_key: ["deviceRegistrationId"]
        }, {
            name: "encrypted_backups_otc_devices",
            id: 261,
            primary_key: ["deviceId"]
        }, {
            name: "experiences_shared_state",
            id: 282,
            primary_key: ["stateKey"]
        }, {
            name: "encrypted_backups_otc_notification_sending_status",
            id: 285,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "pending_protobuf_backups_context",
            id: 305,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "auto_restore_opt_out",
            id: 330,
            primary_key: ["optOutKey"]
        }, {
            name: "encrypted_backup_user_preferences",
            id: 335,
            primary_key: ["pk"],
            auto_increment: !0
        }],
        [{
            name: "secure_encrypted_backups_devices",
            id: 191,
            primary_key: ["deviceId"]
        }, {
            name: "secure_encrypted_backups_device_supported_versions",
            id: 192,
            primary_key: ["deviceId", "supportedVersion"],
            indexes: {
                fk_secure_encrypted_backups_device_supported_versions_device_id: {
                    columns: ["deviceId", "supportedVersion"]
                }
            }
        }],
        [{
            name: "e2ee_dummy_table_for_sync",
            id: 171,
            primary_key: ["placeholder"]
        }, {
            name: "cutover_threads",
            id: 193,
            primary_key: ["openThreadId"]
        }, {
            name: "occamadillo_most_recent_message_per_thread",
            id: 292,
            primary_key: ["threadKey"],
            indexes: {
                fetchTimestamp: {
                    columns: ["fetchTimestampMs"]
                }
            }
        }, {
            name: "offline_queue_thread_status",
            id: 295,
            primary_key: ["threadJid"]
        }, {
            name: "client_message_translation_info",
            id: 324,
            primary_key: ["pk"]
        }],
        [{
            name: "community_messaging_aggregated_user_presence_counts_for_community",
            id: 203,
            primary_key: ["folderId"]
        }, {
            name: "community_messaging_aggregated_copresence_counts_for_chat",
            id: 204,
            primary_key: ["threadId"]
        }],
        [{
            name: "workrooms_co_presence_states",
            id: 246,
            primary_key: ["userId"],
            indexes: {
                userCoPresence: {
                    columns: ["userId", "coPresenceObjectId"]
                }
            }
        }],
        [{
            name: "persistent_menu_ctas",
            id: 251,
            primary_key: ["threadKey", "ctaId"]
        }],
        [{
            name: "workroom_creation_requests",
            id: 252,
            primary_key: ["creationId"]
        }],
        [{
            name: "pake_messages",
            id: 258,
            primary_key: ["sessionId"]
        }],
        [{
            name: "workroom_invites",
            id: 257,
            primary_key: ["inviteId"]
        }],
        [{
            name: "work_genai",
            id: 293,
            primary_key: ["threadKey", "messageId"]
        }],
        [{
            name: "local_message_persistence_store",
            id: 301,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "local_message_persistence_store_supplemental",
            id: 302,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "local_message_persistence_store_deleted_messages",
            id: 303,
            primary_key: ["pk"],
            auto_increment: !0
        }, {
            name: "local_message_persistence_store_tag_index",
            id: 304,
            primary_key: ["pk"],
            indexes: {
                offlineThreadingId: {
                    columns: ["offlineThreadingId", "threadId"]
                }
            },
            auto_increment: !0
        }],
        [{
            name: "secure_acs_configurations",
            id: 307,
            primary_key: ["configId"]
        }, {
            name: "secure_acs_blinded_tokens",
            id: 308,
            primary_key: ["tokenId"],
            auto_increment: !0
        }, {
            name: "secure_acs_tokens",
            id: 309,
            primary_key: ["tokenId"]
        }, {
            name: "acs_request_context",
            id: 310,
            primary_key: ["taskId"]
        }, {
            name: "anonymous_task_context",
            id: 311,
            primary_key: ["taskId"]
        }],
        [{
            name: "lightspeed_task_context",
            id: 306,
            primary_key: ["taskId"]
        }],
        [{
            name: "ohai_gateway_key_configs",
            id: 313,
            primary_key: ["keyId"]
        }],
        [{
            name: "client_xmas",
            id: 314,
            primary_key: ["pk"],
            auto_increment: !0
        }],
        [{
            name: "supervision_edge",
            id: 319,
            primary_key: ["edgeId"]
        }, {
            name: "supervision_metadata",
            id: 320,
            primary_key: ["supervisionMetadataId"]
        }, {
            name: "screen_time",
            id: 321,
            primary_key: ["recordId"],
            auto_increment: !0
        }],
        [{
            name: "mwb_safety_interventions",
            id: 327,
            primary_key: ["interventionId", "interventionEntId"]
        }],
        [{
            name: "messenger_fts_threads",
            id: 331,
            primary_key: ["threadId"]
        }, {
            name: "messenger_fts_threads_queries",
            id: 332,
            primary_key: ["queryId"]
        }],
        [{
            name: "media_receiver_fetch_transport_mappings",
            id: 333,
            primary_key: ["receiverFetchId"]
        }],
        [{
            name: "account_synced_fields",
            id: 334,
            primary_key: ["accountId", "syncedField"]
        }]
    ]
}), null);
__d("LSHashSchemaProvider", ["LSConstants", "LSDbForeignKeys", "LSTableDefaults", "LSTableSchemas", "ReStoreHashSchemaProvider", "ReStoreMetadata", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return new(c("ReStoreHashSchemaProvider"))(d("LSConstants").LS_SCHEMA_NAME, d("ReStoreMetadata").getBuildTableData(c("LSDbForeignKeys"))(a), c("LSTableDefaults"))
    }
    b = a(c("LSTableSchemas").map(function(a) {
        return a.map(function(a) {
            var b;
            return babelHelpers["extends"]({}, a, {
                indexes: Object.fromEntries(Object.keys((b = a.indexes) != null ? b : {}).map(function(b) {
                    var e = c("nullthrows")(a.indexes)[b],
                        f = e.ignore_nulls;
                    e = babelHelpers.objectWithoutPropertiesLoose(e, ["ignore_nulls"]);
                    return [b, babelHelpers["extends"]({}, e, {
                        predicate: f ? d("ReStoreMetadata").createPredicate(f) : void 0
                    })]
                }))
            })
        })
    }));
    g.buildSchemaProvider = a;
    g.schemaProvider = b
}), 98);
__d("LSSetBotResponseInfo", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(12).fetch([
                [
                    [a[1]]
                ], "messageId"
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[0]) && c.messageId === a[1]
            }), function(b) {
                var c = b.update;
                b.item;
                return c({
                    botResponseId: a[2],
                    metadataDataclass: a[3]
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxSetBotResponseInfoStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("MAWConvertExtendedContentOverlayIconGlyphToXMAGatingType", ["EchoMessageXMAFieldUtils", "WAArmadilloXMA.pb", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid ExtendedContentOverlayIconGlyph: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.INFO:
                return d("EchoMessageXMAFieldUtils").XMAGatingType.INFO;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.EYE_OFF:
                return d("EchoMessageXMAFieldUtils").XMAGatingType.EYE_OFF;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.NEWS_OFF:
                return d("EchoMessageXMAFieldUtils").XMAGatingType.NEWS_OFF;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.WARNING:
                return d("EchoMessageXMAFieldUtils").XMAGatingType.WARNING;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.PRIVATE:
                return d("EchoMessageXMAFieldUtils").XMAGatingType.PRIVATE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.NONE:
                return d("EchoMessageXMAFieldUtils").XMAGatingType.NONE;
            default:
                d("WALogger").ERROR(h(), a);
                return d("EchoMessageXMAFieldUtils").XMAGatingType.NONE
        }
    }
    g.convertExtendedContentOverlayIconGlyphToXMAGatingType = a
}), 98);
__d("MAWConvertExtendedContentTargetTypeToXMATargetType", ["EchoMessageXMAFieldUtils", "WAArmadilloXMA.pb", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid ExtendedContentTargetType: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_MENTION:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_PHOTO_MENTION;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_SINGLE_IMAGE_POST_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_SINGLE_IMAGE_POST_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_MULTIPOST_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_MULTIPOST_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_SINGLE_VIDEO_POST_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_SINGLE_VIDEO_POST_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_PHOTO_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_VIDEO_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_VIDEO_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_CLIPS_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_CLIPS_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_IGTV_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_IGTV_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_SHOP_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_SHOP_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_PROFILE_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_PROFILE_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_HIGHLIGHT_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_PHOTO_HIGHLIGHT_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_VIDEO_HIGHLIGHT_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_VIDEO_HIGHLIGHT_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_REPLY:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_REPLY;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_REACTION:
                return d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_REACTION;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_FEED_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_FEED_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_REPLY:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_STORY_REPLY;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_STORY_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_MENTION:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_STORY_MENTION;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_FEED_VIDEO_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_FEED_VIDEO_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_GAMING_CUSTOM_UPDATE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_GAMING_CUSTOM_UPDATE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_PRODUCER_STORY_REPLY:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_PRODUCER_STORY_REPLY;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_EXTERNAL_LINK_SHARE:
                return d("EchoMessageXMAFieldUtils").XMAContentType.MSG_EXTERNAL_LINK_SHARE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_AUDIO_CALL:
                return d("EchoMessageXMAFieldUtils").XMAContentType.RTC_AUDIO_CALL;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_VIDEO_CALL:
                return d("EchoMessageXMAFieldUtils").XMAContentType.RTC_VIDEO_CALL;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_MISSED_AUDIO_CALL:
                return d("EchoMessageXMAFieldUtils").XMAContentType.RTC_MISSED_AUDIO_CALL;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_MISSED_VIDEO_CALL:
                return d("EchoMessageXMAFieldUtils").XMAContentType.RTC_MISSED_VIDEO_CALL;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_GROUP_AUDIO_CALL:
                return d("EchoMessageXMAFieldUtils").XMAContentType.RTC_GROUP_AUDIO_CALL;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_GROUP_VIDEO_CALL:
                return d("EchoMessageXMAFieldUtils").XMAContentType.RTC_GROUP_VIDEO_CALL;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_EVENT:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_EVENT;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_RECEIVER_FETCH:
                return d("EchoMessageXMAFieldUtils").XMAContentType.MSG_RECEIVER_FETCH;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_SHORT:
                return d("EchoMessageXMAFieldUtils").XMAContentType.FB_SHORT;
            default:
                d("WALogger").ERROR(h(), a);
                return d("EchoMessageXMAFieldUtils").XMAContentType.NONE
        }
    }
    g.convertExtendedContentTargetTypeToXMATargetType = a
}), 98);
__d("MAWConvertExtendedContentXMLLayoutTypeToXMALayoutType", ["EchoMessageXMAFieldUtils", "WAArmadilloXMA.pb", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid ExtendedContentXMLLayoutType: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_XMA_LAYOUT_TYPE.SINGLE:
                return d("EchoMessageXMAFieldUtils").XMALayoutType.SINGLE;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_XMA_LAYOUT_TYPE.PORTRAIT:
                return d("EchoMessageXMAFieldUtils").XMALayoutType.PORTRAIT;
            default:
                d("WALogger").ERROR(h(), a);
                return d("EchoMessageXMAFieldUtils").XMALayoutType.SINGLE
        }
    }
    g.convertExtendedContentXMLLayoutTypeToXMALayoutType = a
}), 98);
__d("MAWGetAttachmentTypeForServerMediaType", ["EchoMessageMediaFieldUtils", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid AttachmentType: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case "image":
                return d("EchoMessageMediaFieldUtils").AttachmentType.IMAGE;
            case "video":
                return d("EchoMessageMediaFieldUtils").AttachmentType.VIDEO;
            case "ptt":
                return d("EchoMessageMediaFieldUtils").AttachmentType.PTT;
            case "gif":
                return d("EchoMessageMediaFieldUtils").AttachmentType.GIF;
            case "sticker":
                return d("EchoMessageMediaFieldUtils").AttachmentType.STICKER;
            case "xma-image":
                return d("EchoMessageMediaFieldUtils").AttachmentType.XMA;
            case "document":
                return d("EchoMessageMediaFieldUtils").AttachmentType.DOCUMENT;
            default:
                d("WALogger").WARN(h(), a);
                return null
        }
    }
    g.getAttachmentTypeForServerMediaType = a
}), 98);
__d("MAWGetMediaAttachmentTypeForServerMediaType", ["EchoMessageMediaFieldUtils", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid EchoMessageActMediaAttachmentType: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case "image":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE;
            case "video":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.VIDEO;
            case "ptt":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.PTT;
            case "gif":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.GIF;
            case "sticker":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.STICKER;
            case "audio":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.AUDIO;
            case "document":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.DOCUMENT;
            case "ppic":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.PROFILE_PICTURE;
            case "md-app-state":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.APP_STATE;
            case "md-msg-hist":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.HISTORY_SYNC;
            case "thumbnail-image":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.THUMBNAIL_IMAGE;
            case "thumbnail-video":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.THUMBNAIL_VIDEO;
            case "thumbnail-gif":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.THUMBNAIL_GIF;
            case "thumbnail-document":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.THUMBNAIL_DOCUMENT;
            case "thumbnail-link":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.THUMBNAIL_LINK;
            case "novi-video":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.NOVI_VIDEO;
            case "novi-image":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.NOVI_IMAGE;
            case "xma-image":
                return d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.XMA_IMAGE;
            default:
                d("WALogger").ERROR(h(), a);
                return null
        }
    }
    g.getMediaAttachmentTypeForServerMediaType = a
}), 98);
__d("MAWGetPreviewContentTypeForMediaType", ["EchoMessageMediaFieldUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a) {
            case "image":
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.IMAGE_JPEG;
            case "gif":
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.GIF;
            case "sticker":
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.STICKER;
            case "video":
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.AUDIO_MP4;
            case "ptt":
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.AUDIO_WAV;
            case "xma-image":
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.IMAGE_JPEG;
            default:
                return null
        }
    }
    g.getPreviewContentTypeForMediaType = a
}), 98);
__d("MAWUploadMessageTxns", ["EBUploadMessages", "EchoCommonUtils", "EchoEncodingUtils", "EchoMessage", "EchoMessageMediaFieldUtils", "EchoMessageQuoteFieldUtils", "LSEBPayloadSerializerError", "LSMEBTaskCreationSource", "MAWBridgeEventTransmitter", "MAWConvertExtendedContentOverlayIconGlyphToXMAGatingType", "MAWConvertExtendedContentTargetTypeToXMATargetType", "MAWConvertExtendedContentXMLLayoutTypeToXMALayoutType", "MAWDbEditMsgHistoryTxns", "MAWDbMediaTxns", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbMsgUtil", "MAWDbReactionsTxns", "MAWDbReceiverFetchTxns", "MAWDbXMATxns", "MAWDexieTable", "MAWEBUploadMessageUtils", "MAWEncryptedBackupCacheManager", "MAWGetAttachmentTypeForServerMediaType", "MAWGetMediaAttachmentTypeForServerMediaType", "MAWGetPreviewContentTypeForMediaType", "MAWJidUtils", "MAWJids", "MAWMsgType", "MAWUserJidWrapper", "MAWVault", "MAWXMAUtils", "WAArmadilloXMA.pb", "WABase64", "WAJids", "WALogger", "WAMediaUtils", "WATagsLogger", "WATimeUtils", "err", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["no objectId to construct mediaMetadata isXMA: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] edit history has length ", ", but edit count on message is ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] No XMA object found for msg with external id ", ". Cannot upload XMA"]);
        l = function() {
            return a
        };
        return a
    }
    var m = "You unsent a message";

    function n(a) {
        switch (a.specialTextSize) {
            case 1:
                return d("EchoMessage").MessageTextSize.SMALL;
            case 2:
                return d("EchoMessage").MessageTextSize.MEDIUM;
            case 3:
                return d("EchoMessage").MessageTextSize.LARGE;
            default:
                return d("EchoMessage").MessageTextSize.NONE
        }
    }

    function o(a, b) {
        return d("MAWDbXMATxns").maybeGetXMAFromProtocolMsgId(a, d("MAWJidUtils").maybeToProtocolMsgId(b.author, b.threadJid, b.externalId)).then(function(e) {
            if (e != null) return e.previewMediaIds != null ? d("MAWDexieTable").dexieAll(e.previewMediaIds.map(function(b) {
                return d("MAWDbMediaTxns").maybeGetMediaFromMediaId(a, b)
            })).then(function(a) {
                for (var a = a, b = Array.isArray(a), f = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var g;
                    if (b) {
                        if (f >= a.length) break;
                        g = a[f++]
                    } else {
                        f = a.next();
                        if (f.done) break;
                        g = f.value
                    }
                    g = g;
                    if (g == null) return d("MAWDexieTable").dexieResolve({
                        maybeErrorDetail: {
                            errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                            errorMsg: "constructEchoMessage: DbMedia is null for the XMA message",
                            uploadErrorType: d("EBUploadMessages").UploadErrorType.WARN
                        },
                        xmaData: void 0
                    })
                }
                return v(e)
            }) : v(e);
            else {
                d("WALogger").ERROR(l(), b.externalId);
                return d("MAWDexieTable").dexieResolve({
                    maybeErrorDetail: {
                        errorCode: c("LSEBPayloadSerializerError").UNKNOWN_ERROR,
                        errorMsg: "constructEchoMessage: no xma object found for msg with external id " + b.externalId,
                        uploadErrorType: d("EBUploadMessages").UploadErrorType.WARN
                    },
                    xmaData: void 0
                })
            }
        })
    }

    function p(a, b) {
        try {
            return d("MAWDbMsg").isMediaMsg(a) || a.type === d("MAWMsgType").MSG_TYPE.XMA || a.type === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH
        } catch (e) {
            a = "[labyrinth_web] Invalid msg type for isMediaMsg check: " + e;
            d("WALogger").ERROR(k(), a);
            b.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: a,
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return !1
        }
    }

    function q(a, b) {
        return {
            echoMessage: null,
            externalId: a,
            maybeErrorDetail: {
                errorCode: c("LSEBPayloadSerializerError").NOT_IMPLEMENTED,
                errorMsg: b,
                uploadErrorType: d("EBUploadMessages").UploadErrorType.WARN
            }
        }
    }

    function r(a, b, c) {
        var e = d("MAWDexieTable").dexieResolve(c.threadJid),
            f = {
                mediaMetadata: null,
                previewMetadata: null
            },
            g = p(c, f);
        g = g ? t(a, c) : d("MAWDexieTable").dexieResolve(f);
        f = u(a, c);
        b = c.quote != null ? B(a, c.quote, e, b) : d("MAWDexieTable").dexieResolve();
        var h = d("MAWDbMsg").isXMAMsg(c) ? o(a, c) : d("MAWDexieTable").dexieResolve(null);
        a = d("MAWDbEditMsgHistoryTxns").getEditHistoryAsEchoWithJidPromise(a, c.externalId, c.author, e);
        return {
            editHistoryPromise: a,
            mediaMetadataUploadPromise: g,
            quotedMsgPromise: b,
            reactionsPromise: f,
            threadJidPromise: e,
            xmaDataUploadRequestPromise: h
        }
    }

    function s(a, b, e, f, g, h, i, k) {
        var l, o = d("WAJids").threadIdForChatJid(a),
            p = i.serverTs;
        l = (l = i.editCount) != null ? l : 0;
        h.length > 0 && h.length - 1 !== i.editCount && (d("WALogger").WARN(j(), h.length, i.editCount), l = h.length - 1);
        p = {
            authoritativeTimestampMs: p != null ? p * 1e3 : void 0,
            contentSubtype: d("EchoMessage").EchoMessageContentSubtype.NONE,
            contentType: d("EchoMessage").EchoMessageContentType.TEXT,
            displayTimestampMs: i.ts * 1e3,
            editCount: l,
            editHistory: h,
            from: d("EchoCommonUtils").craftEchoAddress(null, k, "AdvancedCrypto"),
            groupId: i.groupId,
            groupIndex: i.groupIndex,
            groupSize: i.groupSize,
            isForwarded: i.isForwarded,
            messageId: i.externalId,
            serializationOrigin: d("EchoMessage").EchoSerializationOriginType.WEB,
            sortOrderMs: d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(i),
            textSize: n(i),
            threadId: o,
            version: d("EchoMessage").ECHO_MESSAGE_MIGRATION_DOCUMENT_VERSION,
            xContentType: d("EchoEncodingUtils").convertDbMsgTypeToXMessageContentType(i.type),
            xMessagePlaceholderType: d("EchoMessage").EchoMessagePlaceholderType.NO_PLACEHOLDER,
            xOfflineThreadingId: i.externalId,
            xThreadId: o
        };
        ((l = i.msgContent) == null ? void 0 : l.content) != null && (p = babelHelpers["extends"]({}, p, {
            text: d("MAWVault").unvault(i.msgContent.content)
        }));
        i.type === d("MAWMsgType").MSG_TYPE.REVOKED && (p.contentType = d("EchoMessage").EchoMessageContentType.PLACEHOLDER, p.contentSubtype = d("EchoMessage").EchoMessageContentSubtype.UNSEND, p.revokeSentTimestampMs = i.originalTs, p.revokeUnsentTimestampMS = i.unsendMsgContentDeleteTs, p.text = m);
        if (f != null) {
            h = A(f);
            k = d("MAWXMAUtils").isXMAStoryReply(f.xmaMessageType) ? C(h.senderId, a) : h.senderId;
            o = d("EchoCommonUtils").craftEchoAddress(null, k, "AdvancedCrypto");
            f.sortOrderMs != null && (p.quoteData = {
                quoteMessageId: f.externalId,
                quoteMessageSender: o,
                quoteSortOrderInMs: f.sortOrderMs,
                replyType: i.type === d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE ? d("EchoMessageQuoteFieldUtils").EchoMessageQuoteReplyType.BUMP : void 0,
                status: d("EchoMessageQuoteFieldUtils").EchoMessageQuoteStatus.VALID
            }, f.type === d("MAWMsgType").MSG_TYPE.XMA && c("gkx")("458") && (p.xContentType = d("EchoEncodingUtils").convertDbMsgTypeToXMessageContentType(f.type)))
        }
        if (d("MAWMsgType").isMAWSupportedMediaType(i.type)) {
            l = b.mediaMetadata;
            if (l != null) {
                p = babelHelpers["extends"]({}, p, {
                    contentType: d("EchoMessage").EchoMessageContentType.MEDIA,
                    mediaData: l
                });
                a = b.previewMetadata;
                a != null && (p = babelHelpers["extends"]({}, p, {
                    previewMediaData: a
                }))
            } else if (i.type !== d("MAWMsgType").MSG_TYPE.XMA) return {
                echoMessage: p,
                externalId: i.externalId,
                maybeErrorDetail: b.maybeErrorDetail
            }
        }
        if (g != null && g.xmaData != null && i.type === d("MAWMsgType").MSG_TYPE.XMA) {
            p.xmaData = g.xmaData;
            p.contentType = d("EchoMessage").EchoMessageContentType.XMA;
            if (p.mediaData == null && ((h = g.xmaData) == null ? void 0 : h.xmaDefaultCTA) != null && p.text == null) {
                p.text = (k = g.xmaData) == null ? void 0 : k.xmaDefaultCTA
            }
        } else if (g != null && g.xmaData == null && i.type === d("MAWMsgType").MSG_TYPE.XMA) return {
            echoMessage: p,
            externalId: i.externalId,
            maybeErrorDetail: g.maybeErrorDetail
        };
        i.type === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH && (p.receiverFetchId = i.receiverFetchId);
        return {
            echoMessage: babelHelpers["extends"]({}, p, e),
            externalId: i.externalId
        }
    }

    function a(a, b) {
        return d("MAWDexieTable").dexieAll(b.map(function(b) {
            var e = b.dbMsg;
            b = b.quotedMsg;
            if (!d("MAWMsgType").isEBSupportedMsgType(e.type) || e.type === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH && !c("gkx")("5177")) return d("MAWDexieTable").dexieResolve(q(e.externalId, 'constructEchoMessage: "' + String(e.type) + '" NYI'));
            if (e.serverTs == null) return d("MAWDexieTable").dexieResolve(q(e.externalId, 'constructEchoMessage: "' + String(e.type) + '" Not authoritative msg. '));
            var f = d("WATimeUtils").castToUnixTime(0);
            if (e.serverTs === f || e.serverTs === null && e.ts === f) {
                f = "constructEchoMessage: Invalid timestamp - timestamp for message corresponds to 1/1/1970";
                d("WALogger").ERROR(i(), f);
                return d("MAWDexieTable").dexieResolve(q(e.externalId, f))
            }
            f = A(e);
            var g = f.senderId;
            f = r(a, b, e);
            b = f.editHistoryPromise;
            var h = f.mediaMetadataUploadPromise,
                j = f.quotedMsgPromise,
                k = f.reactionsPromise,
                l = f.threadJidPromise;
            f = f.xmaDataUploadRequestPromise;
            return d("MAWDexieTable").dexieAll([l, h, k, j, f, b]).then(function(a) {
                var b = a[0],
                    c = a[1],
                    d = a[2],
                    f = a[3],
                    h = a[4];
                a = a[5];
                return s(b, c, d, f, h, a, e, g)
            })
        }))
    }

    function t(a, b) {
        var e = {
            mediaMetadata: null,
            previewMetadata: null
        };
        if (b.type === d("MAWMsgType").MSG_TYPE.XMA) return d("MAWDbXMATxns").maybeGetXMAFromProtocolMsgId(a, d("MAWJidUtils").maybeToProtocolMsgId(b.author, b.threadJid, b.externalId)).then(function(b) {
            if (b != null) return w(a, b);
            else {
                e.maybeErrorDetail = {
                    errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                    errorMsg: "[labyrinth_web] Media meta data couldn't be created for XMA because DbXMA is not in IndexedDB. This probably means the XMA message was not sent properly by ChatX.",
                    uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
                };
                return d("MAWDexieTable").dexieResolve(e)
            }
        });
        if (b.type === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH) {
            if (b.receiverFetchId == null) {
                e.maybeErrorDetail = {
                    errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                    errorMsg: "[labyrinth_web] No receiver fetch id found in a receiver fetch msg",
                    uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
                };
                return d("MAWDexieTable").dexieResolve(e)
            }
            return d("MAWDbReceiverFetchTxns").maybeGetReceiverFetchInfoFromReceiverFetchId(a, b.receiverFetchId).then(function(a) {
                if (a == null) {
                    e.maybeErrorDetail = {
                        errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                        errorMsg: "[labyrinth_web] No corresponding receiver fetch info found for receiver fetch msg",
                        uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
                    };
                    return d("MAWDexieTable").dexieResolve(e)
                } else return d("MAWDexieTable").dexieResolve(D(a))
            })
        }
        if (!d("MAWMsgType").isMAWSupportedMediaType(b.type)) {
            e.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").NOT_SUPPORTED_ON_WEB,
                errorMsg: "[labyrinth_web] Media type is not supported for msg, type: " + b.type,
                uploadErrorType: d("EBUploadMessages").UploadErrorType.WARN
            };
            return d("MAWDexieTable").dexieResolve(e)
        }
        if (b.mediaId == null) {
            e.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] No media id found in a media msg",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return d("MAWDexieTable").dexieResolve(e)
        }
        var f = d("WATimeUtils").DAY_SECONDS * 28,
            g = b.serverTs;
        if (g != null && d("WATimeUtils").unixTime() - g > f) {
            e.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] Media is older than 28 days and is not being uploaded.",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.WARN
            };
            return d("MAWDexieTable").dexieResolve(e)
        }
        return d("MAWDbMediaTxns").maybeGetMediaFromMediaId(a, b.mediaId).then(function(f) {
            if (!f) {
                e.maybeErrorDetail = {
                    errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                    errorMsg: "[labyrinth_web] No media db entry for media id",
                    uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
                };
                return d("MAWDexieTable").dexieResolve(e)
            }
            if (c("gkx")("4663")) return d("MAWDexieTable").dexieResolve(x(b.msgId, f, !1));
            else {
                var g = d("MAWDbMediaTxns").maybeGetMediaBackupRowFromMsgId(a, b.msgId);
                return g.then(function(a) {
                    return d("MAWDexieTable").dexieResolve(x(b.msgId, f, !1, a))
                })
            }
        })
    }

    function u(a, b) {
        b = d("MAWDbMsgUtil").getProtocolMsgIdFromDbMsg(b);
        return b == null ? d("MAWDexieTable").dexieResolve() : d("MAWDbReactionsTxns").getReactionForEcho(a, b).then(function(a) {
            if (a != null && a.length > 0) {
                var b = d("WAJids").extractUserId(d("MAWUserJidWrapper").getMyUserJid()),
                    c = a.map(function(a) {
                        var c = d("WAJids").authorToUserId(a.author, b);
                        return d("EchoCommonUtils").craftEchoAddress(a.reaction, c, "AdvancedCrypto")
                    }),
                    e = a.map(function(a) {
                        var c = d("WAJids").authorToUserId(a.author, b);
                        return d("EchoCommonUtils").craftEchoAddress((a.ts * 1e3).toString(), c, "AdvancedCrypto")
                    });
                a = a.map(function(a) {
                    var c = d("WAJids").authorToUserId(a.author, b);
                    return d("EchoCommonUtils").craftEchoAddress(a.externalId.toString(), c, "AdvancedCrypto")
                });
                return {
                    reactionAuthoritativeTimestampMs: e,
                    reactions: c,
                    reactionXOfflineThreadingIds: a
                }
            }
        })
    }

    function v(a) {
        var b = {
            xmaData: null
        };
        if (a.isTombstoned == null) {
            b.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no isTombstoned to construct XMAData",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return b
        }
        var e = {
                xmaContentRef: a.contentRef,
                xmaHeaderSubtitle: a.overlayTitle,
                xmaHeaderTitle: a.headerTitle,
                xmaIsTombstoned: a.isTombstoned,
                xmaMaxSubtitleNumLines: a.maxSubtitleNumOfLines,
                xmaMaxTitleNumLines: a.maxTitleNumOfLines,
                xmaSubtitleText: a.subtitleText,
                xmaTargetExpiry: a.targetExpiringAtSec,
                xmaTargetId: a.targetId,
                xmaTargetUsername: a.targetUsername,
                xmaTitleText: a.titleText
            },
            f = a.xmaLayoutType || d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_XMA_LAYOUT_TYPE.SINGLE;
        e = babelHelpers["extends"]({}, e, {
            xmaLayoutType: d("MAWConvertExtendedContentXMLLayoutTypeToXMALayoutType").convertExtendedContentXMLLayoutTypeToXMALayoutType(f)
        });
        a.targetType != null && (e = babelHelpers["extends"]({}, e, {
            xmaTargetType: d("MAWConvertExtendedContentTargetTypeToXMATargetType").convertExtendedContentTargetTypeToXMATargetType(a.targetType)
        }));
        a.overlayIconGlyph != null && (e = babelHelpers["extends"]({}, e, {
            xmaGatingType: d("MAWConvertExtendedContentOverlayIconGlyphToXMAGatingType").convertExtendedContentOverlayIconGlyphToXMAGatingType(a.overlayIconGlyph)
        }));
        a.defaultCTA != null && a.defaultCTA.nativeUrl != null && (e = babelHelpers["extends"]({}, e, {
            xmaDefaultCTA: a.defaultCTA.nativeUrl
        }));
        b.xmaData = e;
        return b
    }

    function w(a, b) {
        var e = {
            mediaMetadata: null,
            previewMetadata: null
        };
        if (b.previewMediaIds != null) {
            var f = b.previewMediaIds[0];
            return d("MAWDbMediaTxns").maybeGetMediaFromMediaId(a, f).then(function(f) {
                if (!f) {
                    e.maybeErrorDetail = {
                        errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                        errorMsg: "[labyrinth_web] No media db entry for media id to be used for xma",
                        uploadErrorType: d("EBUploadMessages").UploadErrorType.WARN
                    };
                    return d("MAWDexieTable").dexieResolve(e)
                }
                var g = b.msgId;
                if (g == null) {
                    e.maybeErrorDetail = {
                        errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                        errorMsg: "[labyrinth_web] No message id found in a xma msg",
                        uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
                    };
                    return d("MAWDexieTable").dexieResolve(e)
                }
                if (c("gkx")("4663")) return d("MAWDexieTable").dexieResolve(x(g, f, !0));
                else {
                    var h = d("MAWDbMediaTxns").maybeGetMediaBackupRowFromMsgId(a, g);
                    return h.then(function(a) {
                        return d("MAWDexieTable").dexieResolve(x(g, f, !0, a))
                    })
                }
            })
        } else return d("MAWDexieTable").dexieResolve(e)
    }

    function x(a, b, e, f) {
        var g;
        f = {
            mediaMetadata: null,
            previewMetadata: null
        };
        g = (g = b.mediaEntries) == null ? void 0 : g.get(a);
        if (g == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no media entry to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        a = d("WAMediaUtils").decodeMediaEntryData(g);
        g = (a == null ? void 0 : a.objectId) != null ? d("WAMediaUtils").stringToDeliveryObjectId(a.objectId) : null;
        if (g == null) {
            d("WATagsLogger").TAGS(["labyrinth_web"]).ERROR(h(), e);
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no objectId to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        var i = d("MAWGetAttachmentTypeForServerMediaType").getAttachmentTypeForServerMediaType(a.serverMediaType);
        if (i == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no attachment type to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        var j = a.mediaKey;
        if (j == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no mediaKey to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        var k = a.mediaKeyTimestamp;
        if (k == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no mediaKeyTimestamp to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        var l = a.directPath;
        if (l == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no directPath to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        if (a.serverMediaType == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no mediaContentType to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        e = e ? "image/jpeg" : d("WAMediaUtils").getMimeTypeFromServerMediaType(a.serverMediaType);
        var m = d("MAWGetMediaAttachmentTypeForServerMediaType").getMediaAttachmentTypeForServerMediaType(a.serverMediaType);
        if (m == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no xAttachmentType to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        if (a.serverMediaType != null && a.serverMediaType in {
                gif: 1,
                image: 1,
                sticker: 1
            } && b.validatedImageInfo == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no imageinfo to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        if (a.serverMediaType === "video" && b.validatedVideoInfo == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no videoinfo to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        if (a.serverMediaType === "ptt" && b.validatedAudioInfo == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no audioinfo to construct mediaMetadata",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        if (a.fileSha256 == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no WA fileSha256 found",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        var n = d("WABase64").encodeB64UrlSafe(a.fileSha256);
        if (a.fileEncSha256 == null) {
            f.maybeErrorDetail = {
                errorCode: c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID,
                errorMsg: "[labyrinth_web] no WA fileEncSha256 found",
                uploadErrorType: d("EBUploadMessages").UploadErrorType.FATAL
            };
            return f
        }
        f = d("WABase64").encodeB64UrlSafe(a.fileEncSha256);
        var o = null,
            p = null,
            q = null,
            r = null,
            s = null,
            t = void 0,
            u = d("MAWGetPreviewContentTypeForMediaType").getPreviewContentTypeForMediaType(a.serverMediaType);
        if (b.validatedImageInfo != null) {
            var v;
            o = (v = b.validatedImageInfo.width) != null ? v : 0;
            p = (v = b.validatedImageInfo.height) != null ? v : 0;
            r = (v = b.validatedImageInfo.jpegThumbnailWidth) != null ? v : 0;
            s = (v = b.validatedImageInfo.jpegThumbnailHeight) != null ? v : 0
        }
        if (b.validatedVideoInfo != null) {
            o = (v = b.validatedVideoInfo.width) != null ? v : 0;
            p = (v = b.validatedVideoInfo.height) != null ? v : 0;
            r = (v = b.validatedVideoInfo.jpegThumbnailWidth) != null ? v : 0;
            s = (v = b.validatedVideoInfo.jpegThumbnailHeight) != null ? v : 0;
            q = (v = b.validatedVideoInfo.duration) != null ? v : 0
        }
        if (b.validatedAudioInfo != null) {
            q = (v = b.validatedAudioInfo.duration) != null ? v : 0
        }
        b.validatedDocumentFileInfo != null && (t = b.validatedDocumentFileInfo.filename);
        v = {
            attachmentObjectId: g,
            attachmentType: i,
            directPath: l,
            encryptedHash: f,
            mediaBackupStatus: "success",
            mediaContentType: e,
            mediaKey: d("EchoEncodingUtils").convertMediaKeyToString(j),
            mediaKeyTimestamp: k,
            plaintextHash: n,
            size: b.size,
            xAttachmentType: m,
            xContentType: "full"
        };
        g = null;
        i = a.downloadableThumbnail;
        if ((i == null ? void 0 : i.objectId) != null) {
            g = {
                attachmentObjectId: i.objectId,
                attachmentType: d("EchoMessageMediaFieldUtils").AttachmentType.IMAGE,
                directPath: l,
                encryptedHash: f,
                mediaBackupStatus: "success",
                mediaContentType: "image/jpeg",
                mediaKey: d("EchoEncodingUtils").convertMediaKeyToString(j),
                mediaKeyTimestamp: k,
                plaintextHash: n,
                size: b.size,
                xAttachmentType: d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.MESSENGER_PREVIEW,
                xContentType: "preview"
            };
            e = i.fileSha256 != null ? d("WABase64").encodeB64UrlSafe(i.fileSha256) : null;
            m = i.fileEncSha256 != null ? d("WABase64").encodeB64UrlSafe(i.fileEncSha256) : null;
            a = i.mediaKey != null ? d("EchoEncodingUtils").convertMediaKeyToString(j) : null;
            g = z(g, i.directPath, m, e, a, i.mediaKeyTimestamp)
        }
        v = y(v, null, u, o, p, q, r, s, t);
        return {
            mediaMetadata: v,
            previewMetadata: g
        }
    }

    function y(a, b, c, d, e, f, g, h, i) {
        a = a;
        b != null && (a = babelHelpers["extends"]({}, a, {
            backupEntFbid: b
        }));
        c != null && (a = babelHelpers["extends"]({}, a, {
            previewContentType: c
        }));
        d != null && (a = babelHelpers["extends"]({}, a, {
            width: d
        }));
        e != null && (a = babelHelpers["extends"]({}, a, {
            height: e
        }));
        f != null && (a = babelHelpers["extends"]({}, a, {
            mediaPlayableDuration: f * 1e3
        }));
        g != null && (a = babelHelpers["extends"]({}, a, {
            previewContentWidth: g
        }));
        h != null && (a = babelHelpers["extends"]({}, a, {
            previewContentHeight: h
        }));
        i != null && (a = babelHelpers["extends"]({}, a, {
            filename: i
        }));
        return a
    }

    function z(a, b, c, d, e, f) {
        a = a;
        b != null && (a = babelHelpers["extends"]({}, a, {
            directPath: b
        }));
        c != null && (a = babelHelpers["extends"]({}, a, {
            encryptedHash: c
        }));
        d != null && (a = babelHelpers["extends"]({}, a, {
            plaintextHash: d
        }));
        e != null && (a = babelHelpers["extends"]({}, a, {
            mediaKey: e
        }));
        f != null && (a = babelHelpers["extends"]({}, a, {
            mediaKeyTimestamp: f
        }));
        return a
    }

    function A(a) {
        a = d("WAJids").authorToUserId(a.author, d("WAJids").userIdFromJid(d("MAWUserJidWrapper").getMyUserJid()));
        var b = d("MAWJids").toUserJid(a);
        return {
            senderId: a,
            senderJid: b
        }
    }

    function B(a, b, e, f) {
        var g = b.content.msgId,
            h = b.content.externalId;
        return f != null ? d("MAWDexieTable").dexieResolve(f) : d("MAWDbMsgTxns").maybeGetMsg(a, g).then(function(a) {
            if (a == null) return e.then(function(a) {
                var b = d("WAJids").threadIdForChatJid(a);
                if (!d("MAWEncryptedBackupCacheManager").peekRestoreCache(h)) {
                    d("MAWEncryptedBackupCacheManager").addMsgEntryToReuploadCache(a, h);
                    d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(h, b, void 0, c("LSMEBTaskCreationSource").POINT_QUERY_FROM_EB, a);
                    return null
                } else {
                    a = (b = d("MAWEncryptedBackupCacheManager").getRestoredCache(h)) == null ? void 0 : b.dbMsg;
                    return d("MAWDexieTable").dexieResolve(a)
                }
            });
            else return d("MAWDexieTable").dexieResolve(a)
        })
    }

    function C(a, b) {
        var e = d("WAJids").extractUserId(d("MAWUserJidWrapper").getMyUserJid());
        b = d("WAJids").interpretAsUserJid(b);
        if (b == null) throw c("err")("this is a flow check, participant jid can not be null");
        return a === e ? d("WAJids").extractUserId(b) : e
    }

    function D(a) {
        return {
            mediaMetadata: {
                attachmentObjectId: a.receiverFetchId,
                attachmentType: d("EchoMessageMediaFieldUtils").AttachmentType.STICKER,
                directPath: "",
                encryptedHash: null,
                height: a.previewHeight,
                mediaContentType: "image/webp",
                plaintextHash: a.receiverFetchId,
                previewContentHeight: a.previewHeight,
                previewContentType: d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.STICKER,
                previewContentWidth: a.previewWidth,
                width: a.previewWidth,
                xAttachmentType: d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.STICKER,
                xContentType: d("EchoMessage").EchoXMessageContentType.STICKER
            },
            previewMetadata: null
        }
    }
    g.constructEchoMessage = a;
    g.constructXMAData = v;
    g.constructMediaMetadata = x;
    g.setConditionalFields = y
}), 98);
__d("WAAPIDeferred", ["WAAPIMetrics", "WADexieToWormMigration", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = (a = c("requireDeferred"))("WABulkSetRotateSenderKeyToTrueApi").__setRef("WAAPIDeferred"),
        i = a("WADbRegistrationApi").__setRef("WAAPIDeferred"),
        j = a("WADbRegistrationApiV2").__setRef("WAAPIDeferred"),
        k = a("WADownloadMedia").__setRef("WAAPIDeferred"),
        l = a("WAGenerateAndUploadPreKeys").__setRef("WAAPIDeferred"),
        m = a("WAGetCurrentUserDeviceList").__setRef("WAAPIDeferred"),
        n = a("WAGetDevices").__setRef("WAAPIDeferred"),
        o = a("WANotifyDeviceChange").__setRef("WAAPIDeferred"),
        p = a("WAPreEstablishOutgoingSessionForGroup").__setRef("WAAPIDeferred"),
        q = a("WAQueryGroups").__setRef("WAAPIDeferred"),
        r = a("WARemoveCurrentDevice").__setRef("WAAPIDeferred"),
        s = a("WARemoveDevice").__setRef("WAAPIDeferred"),
        t = a("WASendAppDataFanoutProtocol").__setRef("WAAPIDeferred"),
        u = a("WASendMsgUtilV2").__setRef("WAAPIDeferred"),
        v = a("WASendPing").__setRef("WAAPIDeferred"),
        w = a("WASyncAbProps").__setRef("WAAPIDeferred"),
        x = a("WAUploadMedia").__setRef("WAAPIDeferred");
    b = {
        getCurrentUserDeviceList: function() {
            return m.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.getCurrentUserDeviceList, "getCurrentUserDeviceList")()
            })
        },
        syncAbProps: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return w.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.syncAbProps, "syncAbProps").apply(void 0, b)
            })
        },
        generateAndUploadPreKeys: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return l.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.generateAndUploadPreKeys, "generateAndUploadPreKeys", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        getDevicesBeforeSend: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return u.load().then(function(a) {
                a = a.getDevicesBeforeSend;
                return d("WAAPIMetrics").withMetrics(a, "getDevicesBeforeSend", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        preEstablishSession: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return p.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.preEstablishSession, "preEstablishSession", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        sendChatMessage: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return u.load().then(function(a) {
                a = a.sendChatMessage;
                return d("WAAPIMetrics").withMetrics(a, "sendChatMessage", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        updateClockSkew: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return v.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.updateClockSkew, "updateClockSkew", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        queryGroups: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return q.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.queryGroups, "queryGroups", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        getDevices: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return n.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.getDevices, "getDevices", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        removeDevice: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return s.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.removeDevice, "=>", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        removeCurrentDevice: function() {
            return r.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.removeCurrentDevice, "removeCurrentDevice", {
                    bool: {
                        deferred_load: !0
                    }
                })()
            })
        },
        notifyDeviceChange: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return o.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.notifyDeviceChange, "notifyDeviceChange", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        saveLastSessionDeviceWasLinkedTo: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return (d("WADexieToWormMigration").isWorm("WAAPIEager") ? j : i).load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.saveLastSessionDeviceWasLinkedTo, "saveLastSessionDeviceWasLinkedTo").apply(void 0, b)
            })
        },
        sendAppData: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return t.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.sendAppDataToDevicesProtocol, "sendAppData", {
                    bool: {
                        deferred_load: !0
                    }
                }).apply(void 0, b)
            })
        },
        setRotateSenderKeyToTrue: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return h.load().then(function(a) {
                return d("WAAPIMetrics").withMetrics(a.bulkSetRotateSenderKeyToTrue, "setRotateSenderKeyToTrue").apply(void 0, b)
            })
        },
        uploadMedia: function(a) {
            return x.load().then(function(b) {
                return b.uploadMedia(a)
            })
        },
        downloadMedia: function(a) {
            return k.load().then(function(b) {
                return b.downloadMedia(a)
            })
        },
        cachedDownloadFullMediaOnly: function(a) {
            return k.load().then(function(b) {
                return b.cachedDownloadFullMediaOnly(a)
            })
        }
    };
    e = b;
    g["default"] = e
}), 98);
__d("WAAPIEager", ["WAAPIMetrics", "WABulkSetRotateSenderKeyToTrueApi", "WADbRegistrationApi", "WADbRegistrationApiV2", "WADexieToWormMigration", "WADownloadMedia", "WAGenerateAndUploadPreKeys", "WAGetCurrentUserDeviceList", "WAGetDevices", "WANotifyDeviceChange", "WAPreEstablishOutgoingSessionForGroup", "WAQueryGroups", "WARemoveCurrentDevice", "WARemoveDevice", "WASendAppDataFanoutProtocol", "WASendMsgUtilV2", "WASendPing", "WASyncAbProps", "WAUploadMedia"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getCurrentUserDeviceList: function() {
            return d("WAAPIMetrics").withMetrics(d("WAGetCurrentUserDeviceList").getCurrentUserDeviceList, "getCurrentUserDeviceList")()
        },
        syncAbProps: function() {
            return d("WAAPIMetrics").withMetrics(d("WASyncAbProps").syncAbProps, "syncAbProps").apply(void 0, arguments)
        },
        generateAndUploadPreKeys: function() {
            return d("WAAPIMetrics").withMetrics(d("WAGenerateAndUploadPreKeys").generateAndUploadPreKeys, "generateAndUploadPreKeys").apply(void 0, arguments)
        },
        getDevicesBeforeSend: function() {
            return d("WAAPIMetrics").withMetrics(d("WASendMsgUtilV2").getDevicesBeforeSend, "getDevicesBeforeSend").apply(void 0, arguments)
        },
        preEstablishSession: function() {
            return d("WAAPIMetrics").withMetrics(d("WAPreEstablishOutgoingSessionForGroup").preEstablishSession, "preEstablishSession").apply(void 0, arguments)
        },
        sendChatMessage: function() {
            return d("WAAPIMetrics").withMetrics(d("WASendMsgUtilV2").sendChatMessage, "sendChatMessage").apply(void 0, arguments)
        },
        updateClockSkew: function() {
            return d("WAAPIMetrics").withMetrics(d("WASendPing").updateClockSkew, "updateClockSkew").apply(void 0, arguments)
        },
        queryGroups: function() {
            return d("WAAPIMetrics").withMetrics(d("WAQueryGroups").queryGroups, "queryGroups").apply(void 0, arguments)
        },
        getDevices: function() {
            return d("WAAPIMetrics").withMetrics(d("WAGetDevices").getDevices, "getDevices").apply(void 0, arguments)
        },
        removeDevice: function() {
            return d("WAAPIMetrics").withMetrics(d("WARemoveDevice").removeDevice, "removeDevice").apply(void 0, arguments)
        },
        removeCurrentDevice: function() {
            return d("WAAPIMetrics").withMetrics(d("WARemoveCurrentDevice").removeCurrentDevice, "removeCurrentDevice")()
        },
        notifyDeviceChange: function() {
            return d("WAAPIMetrics").withMetrics(d("WANotifyDeviceChange").notifyDeviceChange, "notifyDeviceChange").apply(void 0, arguments)
        },
        saveLastSessionDeviceWasLinkedTo: function() {
            return d("WAAPIMetrics").withMetrics(d("WADexieToWormMigration").isWorm("WAAPIEager") ? d("WADbRegistrationApiV2").saveLastSessionDeviceWasLinkedTo : d("WADbRegistrationApi").saveLastSessionDeviceWasLinkedTo, "saveLastSessionDeviceWasLinkedTo").apply(void 0, arguments)
        },
        sendAppData: function() {
            return d("WAAPIMetrics").withMetrics(d("WASendAppDataFanoutProtocol").sendAppDataToDevicesProtocol, "sendAppData").apply(void 0, arguments)
        },
        setRotateSenderKeyToTrue: function() {
            return d("WAAPIMetrics").withMetrics(d("WABulkSetRotateSenderKeyToTrueApi").bulkSetRotateSenderKeyToTrue, "setRotateSenderKeyToTrue").apply(void 0, arguments)
        },
        uploadMedia: function(a) {
            return d("WAUploadMedia").uploadMedia(a)
        },
        downloadMedia: function(a) {
            return d("WADownloadMedia").downloadMedia(a)
        },
        cachedDownloadFullMediaOnly: function(a) {
            return d("WADownloadMedia").cachedDownloadFullMediaOnly(a)
        }
    };
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("MAWAdminMsgType", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = "currentUserAddedDevice";
    b = "participantAddedDevice";
    c = "currentUserRemovedDevice";
    d = "participantRemovedDevice";
    e = "currentUserUpdatedDevice";
    var g = "participantUpdatedDevice",
        h = "participantAddedYou",
        i = "participantAddedYouAndOneUser",
        j = "participantAddedYouAndMoreThanOneUsers",
        k = "unknowUserAddedYou",
        l = "unknowUserAddedYouAndOneUser",
        m = "unknowUserAddedYouAndMoreThanOneUser",
        n = "unknownUserAddedOneUser",
        o = "unknownUserAddedTwoUser",
        p = "unknownUserAddedMoreThanTwoUser",
        q = "participantAddedOneUser",
        r = "participantAddedTwoUser",
        s = "participantAddedMoreThanTwoUser",
        t = "currentUserRemovedOneParticipant",
        u = "currentUserRemovedTwoParticipant",
        v = "currentUserRemovedMoreThanTwoParticipant",
        w = "currentUserAddedOneParticipant",
        x = "currentUserAddedTwoParticipant",
        y = "currentUserAddedMoreThanTwoParticipant",
        z = "participantRemovedYou",
        A = "participantRemovedYouAndOneUser",
        B = "participantRemovedYouAndMoreThanOneUsers",
        C = "unknowUserRemovedYou",
        D = "unknowUserRemovedYouAndOneUser",
        E = "unknowUserRemovedYouAndMoreThanOneUser",
        F = "unknownUserRemovedOneUser",
        G = "unknownUserRemovedTwoUser",
        H = "unknownUserRemovedMoreThanTwoUser",
        I = "participantRemovedOneUser",
        J = "participantRemovedTwoUser",
        K = "participantRemovedMoreThanTwoUser",
        L = "participantLeftGroup",
        M = "currentUserLeftGroup",
        N = "participantCustomizeParticipantNickname",
        O = "participantClearParticipantNickname",
        P = "participantCustomizeCurrentUserNickname",
        Q = "currentUserSetOwnNickname",
        R = "currentUserClearOwnNickname",
        aa = "currentUserClearParticipantNickname",
        ba = "participantSetOwnNickname",
        ca = "participantClearOwnNickname",
        da = "participantClearCurrentUserNickname",
        ea = "currentUserCustomizeNickname",
        fa = "currentUserNamedGroup",
        ga = "unkonwnUserNamedGroup",
        ha = "participantNamedGroup",
        ia = "currentUserCustomizeHotlike",
        ja = "participantCustomizeHotlike",
        ka = "currentUserCustomizeTheme",
        la = "currentUserCustomizePhoto",
        ma = "participantCustomizeTheme",
        na = "participantCustomizePhoto",
        oa = "currentUserSetAddModeAdminOnly",
        pa = "currentUserSetAddModeAllMembers",
        qa = "participantSetAddModeAdminOnly",
        ra = "participantSetAddModeAllMembers",
        sa = "serverSetAddModeAdminOnly",
        ta = "serverSetAddModeAllMembers",
        S = "currentUserPinnedMessage",
        T = "currentUserUnpinnedMessage",
        U = "participantPinnedMessage",
        V = "participantUnpinnedMessage",
        W = "cutoverThreadAdminMessage",
        X = "cutoverIGDThreadAdminMessage",
        Y = "cutoverRollbackAdminMessage",
        Z = "dualThreadCutoverAdminMessage",
        $ = "e2eeThreadDescription",
        ua = "debugMsg",
        va = "reachabilityError",
        wa = "twoUsersConnected",
        xa = "twoUsersConnectedOneMSplit";
    y = {
        CURRENT_USER_ADDED_DEVICE: a,
        CURRENT_USER_ADDED_MORE_THAN_TWO_PARTICIPANTS: y,
        CURRENT_USER_ADDED_ONE_PARTICIPANT: w,
        CURRENT_USER_ADDED_TWO_PARTICIPANTS: x,
        CURRENT_USER_CLEAR_OWN_NICKNAME: R,
        CURRENT_USER_CLEAR_PARTICIPANT_NICKNAME: aa,
        CURRENT_USER_CUSTOMIZE_HOTLIKE: ia,
        CURRENT_USER_CUSTOMIZE_NICKNAME: ea,
        CURRENT_USER_CUSTOMIZE_PHOTO: la,
        CURRENT_USER_CUSTOMIZE_THEME: ka,
        CURRENT_USER_LEFT_GROUP: M,
        CURRENT_USER_NAMED_GROUP: fa,
        CURRENT_USER_PINNED_MESSAGE: S,
        CURRENT_USER_REMOVED_DEVICE: c,
        CURRENT_USER_REMOVED_MORE_THAN_TWO_PARTICIPANTS: v,
        CURRENT_USER_REMOVED_ONE_PARTICIPANT: t,
        CURRENT_USER_REMOVED_TWO_PARTICIPANTS: u,
        CURRENT_USER_SET_ADD_MODE_ADMIN_ONLY: oa,
        CURRENT_USER_SET_ADD_MODE_ALL_MEMBERS: pa,
        CURRENT_USER_SET_OWN_NICKNAME: Q,
        CURRENT_USER_UNPINNED_MESSAGE: T,
        CURRENT_USER_UPDATED_DEVICE: e,
        CUTOVER_IGD_THREAD_ADMIN_MESSAGE: X,
        CUTOVER_ROLLBACK_ADMIN_MESSAGE: Y,
        CUTOVER_THREAD_ADMIN_MESSAGE: W,
        DEBUG_MSG: ua,
        DUAL_THREAD_CUTOVER_ADMIN_MESSAGE: Z,
        E2EE_THREAD_DESCRIPTION: $,
        PARTICIPANT_ADDED_DEVICE: b,
        PARTICIPANT_ADDED_MORE_THAN_TWO_USER: s,
        PARTICIPANT_ADDED_ONE_USER: q,
        PARTICIPANT_ADDED_TWO_USER: r,
        PARTICIPANT_ADDED_YOU: h,
        PARTICIPANT_ADDED_YOU_AND_MORE_THAN_ONE_USERS: j,
        PARTICIPANT_ADDED_YOU_AND_ONE_USER: i,
        PARTICIPANT_CLEAR_CURRENT_USER_NICKNAME: da,
        PARTICIPANT_CLEAR_OWN_NICKNAME: ca,
        PARTICIPANT_CLEAR_PARTICIPANT_NICKNAME: O,
        PARTICIPANT_CUSTOMIZE_CURRENT_USER_NICKNAME: P,
        PARTICIPANT_CUSTOMIZE_HOTLIKE: ja,
        PARTICIPANT_CUSTOMIZE_PARTICIPANT_NICKNAME: N,
        PARTICIPANT_CUSTOMIZE_PHOTO: na,
        PARTICIPANT_CUSTOMIZE_THEME: ma,
        PARTICIPANT_LEFT_GROUP: L,
        PARTICIPANT_NAMED_GROUP: ha,
        PARTICIPANT_PINNED_MESSAGE: U,
        PARTICIPANT_REMOVED_DEVICE: d,
        PARTICIPANT_REMOVED_MORE_THAN_TWO_USER: K,
        PARTICIPANT_REMOVED_ONE_USER: I,
        PARTICIPANT_REMOVED_TWO_USER: J,
        PARTICIPANT_REMOVED_YOU: z,
        PARTICIPANT_REMOVED_YOU_AND_MORE_THAN_ONE_USERS: B,
        PARTICIPANT_REMOVED_YOU_AND_ONE_USER: A,
        PARTICIPANT_SET_ADD_MODE_ADMIN_ONLY: qa,
        PARTICIPANT_SET_ADD_MODE_ALL_MEMBERS: ra,
        PARTICIPANT_SET_OWN_NICKNAME: ba,
        PARTICIPANT_UNPINNED_MESSAGE: V,
        PARTICIPANT_UPDATED_DEVICE: g,
        REACHABILITY_ERROR: va,
        SERVER_SET_ADD_MODE_ADMIN_ONLY: sa,
        SERVER_SET_ADD_MODE_ALL_MEMBERS: ta,
        TWO_USERS_CONNECTED: wa,
        TWO_USERS_CONNECTED_ONE_MSPLIT: xa,
        UNKNOWN_USER_ADDED_MORE_THAN_TWO_USER: p,
        UNKNOWN_USER_ADDED_ONE_USER: n,
        UNKNOWN_USER_ADDED_TWO_USER: o,
        UNKNOWN_USER_ADDED_YOU: k,
        UNKNOWN_USER_ADDED_YOU_AND_MORE_THAN_ONE_USER: m,
        UNKNOWN_USER_ADDED_YOU_AND_ONE_USER: l,
        UNKNOWN_USER_NAMED_GROUP: ga,
        UNKNOWN_USER_REMOVED_MORE_THAN_TWO_USER: H,
        UNKNOWN_USER_REMOVED_ONE_USER: F,
        UNKNOWN_USER_REMOVED_TWO_USER: G,
        UNKNOWN_USER_REMOVED_YOU: C,
        UNKNOWN_USER_REMOVED_YOU_AND_MORE_THAN_ONE_USER: E,
        UNKNOWN_USER_REMOVED_YOU_AND_ONE_USER: D
    };
    f.CURRENT_USER_ADDED_DEVICE = a;
    f.CURRENT_USER_PINNED_MESSAGE = S;
    f.CURRENT_USER_UNPINNED_MESSAGE = T;
    f.PARTICIPANT_PINNED_MESSAGE = U;
    f.PARTICIPANT_UNPINNED_MESSAGE = V;
    f.CUTOVER_THREAD_ADMIN_MESSAGE = W;
    f.CUTOVER_IGD_THREAD_ADMIN_MESSAGE = X;
    f.CUTOVER_ROLLBACK_ADMIN_MESSAGE = Y;
    f.DUAL_THREAD_CUTOVER_ADMIN_MESSAGE = Z;
    f.E2EE_THREAD_DESCRIPTION = $;
    f.ADMIN_MSG_TYPE = y
}), 66);
__d("MAWLocalizationType", ["MAWAdminMsgType"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = "emptySnippet";
    b = "currentUserCreatedGroup";
    c = "participantCreatedGroup";
    e = "unknownUserCreatedGroup";
    f = "currentUserGotPromoted";
    var h = "currentUserGotDemoted",
        i = "participantGotPromoted",
        j = "participantGotDemoted",
        k = "participantPromotedYou",
        l = "participantDemotedYou",
        m = "currentUserPromotedParticipant",
        n = "currentUserDemotedParticipant",
        o = "participantDemotedParticipant",
        p = "participantPromotedParticipant",
        q = "participantSelfDemoted",
        r = "currentUserSelfDemoted",
        s = "currentUserSendText",
        t = "currentUserSendImage",
        u = "currentUserSendVideo",
        v = "currentUserSendAudio",
        w = "currentUserSendGif",
        x = "currentUserSendSticker",
        y = "participantSendText",
        z = "participantSendTextInGroup",
        A = "participantSendImage",
        B = "participantSendVideo",
        C = "participantSendAudio",
        D = "participantSendGif",
        E = "participantSendSticker",
        F = "unavailableSnippet",
        G = "unknownUserEphemeralSettingTurnedOnSeconds",
        H = "unknownUserEphemeralSettingTurnedOnMinutes",
        I = "unknownUserEphemeralSettingTurnedOnHours",
        J = "unknownUserEphemeralSettingTurnedOnDays",
        K = "youEphemeralSettingTurnedOnSeconds",
        L = "youEphemeralSettingTurnedOnMinutes",
        M = "youEphemeralSettingTurnedOnHours",
        N = "youEphemeralSettingTurnedOnDays",
        O = "participantEphemeralSettingTurnedOnSeconds",
        P = "participantEphemeralSettingTurnedOnMinutes",
        Q = "participantEphemeralSettingTurnedOnHours",
        R = "participantEphemeralSettingTurnedOnDays",
        S = "unknownUserEphemeralSettingChangeSeconds",
        T = "unknownUserEphemeralSettingChangeMinutes",
        U = "unknownUserEphemeralSettingChangeHours",
        V = "unknownUserEphemeralSettingChangeDays",
        W = "youEphemeralSettingChangeSeconds",
        X = "youEphemeralSettingChangeMinutes",
        Y = "youEphemeralSettingChangeHours",
        aa = "youEphemeralSettingChangeDays",
        ba = "participantEphemeralSettingChangeSeconds",
        ca = "participantEphemeralSettingChangeMinutes",
        da = "participantEphemeralSettingChangeHours",
        ea = "participantEphemeralSettingChangeDays",
        fa = "unknownUserEphemeralSettingTurnedOff",
        ga = "youEphemeralSettingTurnedOff",
        ha = "participantEphemeralSettingTurnedOff",
        ia = "ephemeralSettingsAutoReset",
        ja = "currentUserUnsentMessage",
        ka = "participantUnsentMessage",
        la = "participantReactMessage",
        ma = "participantReactMessageInGroup",
        Z = "unknownUserEphemeralTakeScreenshot",
        na = "unknownUserEphemeralRecordScreen",
        oa = "youEphemeralTakeScreenshot",
        pa = "youEphemeralRecordScreen",
        qa = "participantEphemeralTakeScreenshot",
        ra = "participantEphemeralRecordScreen",
        sa = "icdcAlertAdminMessage",
        ta = "yourDeviceICDCAlertAdminMessage",
        $ = "currentUserSendAttachment",
        ua = "participantSendAttachment",
        va = "currentUserSentPost",
        wa = "currentUserSentReel",
        xa = "currentUserSentStory",
        ya = "currentUserSentEvent",
        za = "currentUserMentionedStoryIG",
        Aa = "currentUserReceivedStoryMentionIG",
        Ba = "participantSentPost",
        Ca = "participantSentReel",
        Da = "participantSentStory",
        Ea = "participantSentEvent",
        Fa = "currentUserSentStoryHighlight",
        Ga = "participantSentStoryHighlight",
        Ha = "currentUserMissedAudioCall",
        Ia = "participantMissedAudioCall",
        Ja = "currentUserMissedVideoCall",
        Ka = "participantMissedVideoCall",
        La = "currentUserAudioCalled",
        Ma = "participantAudioCalled",
        Na = "currentUserVideoCalled",
        Oa = "participantVideoCalled",
        Pa = "currentUserStartedGroupAudioCall",
        Qa = "participantStartedGroupAudioCall",
        Ra = "currentUserStartedGroupVideoCall",
        Sa = "participantStartedGroupVideoCall",
        Ta = "currentUserBumpedOwnMessage",
        Ua = "currentUserBumpedMessage",
        Va = "participantBumpedOwnMessage",
        Wa = "participantBumpedParticipantMessage",
        Xa = "participantBumpedCurrentUserMessage",
        Ya = "userSendUnavailableMessage",
        Za = "userSendEncryptedMessage",
        $a = "currentUserSendUnrenderableMessage",
        ab = "participantSendUnrenderableMessage",
        bb = "currentUserSendLocationFallback",
        cb = "participantSendLocation",
        db = "currentUserSendLocation",
        eb = "participantSendLocation",
        fb = "currentUserSendPollCreationFallback",
        gb = "participantSendPollCreation",
        hb = "currentUserSendContactShareFallback",
        ib = "participantSendContactShareFallback",
        jb = "currentUserSendStoryMentionFallback",
        kb = "currentUserSendStoryMention",
        lb = "participantSendStoryMention",
        mb = "participantSendStoryMentionFallback",
        nb = "currentUserSendNoteMentionFallback",
        ob = "participantSendNoteMentionFallback",
        pb = "metaAISendMessageFallback",
        qb = "currentUserSendBumpMessageFallback",
        rb = "participantSendBumpMessageFallback",
        sb = "participantSendBumpMessageOriginalUnavailable",
        tb = "currentUserSendStickerReceiverFetchMessageFallback",
        ub = "participantSendStickerReceiverFetchMessageFallback",
        vb = "viewOncePhotoMessageFallback",
        wb = "viewOnceVideoMessageFallback",
        xb = "unavailableStory";
    d = babelHelpers["extends"]({}, d("MAWAdminMsgType").ADMIN_MSG_TYPE, {
        CURRENT_USER_AUDIO_CALLED: La,
        CURRENT_USER_BUMPED_MESSAGE: Ua,
        CURRENT_USER_BUMPED_OWN_MESSAGE: Ta,
        CURRENT_USER_CREATED_GROUP: b,
        CURRENT_USER_DEMOTED_PARTICIPANT: n,
        CURRENT_USER_GOT_DEMOTED: h,
        CURRENT_USER_GOT_PROMOTED: f,
        CURRENT_USER_MENTIONED_STORY_IG: za,
        CURRENT_USER_MISSED_AUDIO_CALL: Ha,
        CURRENT_USER_MISSED_VIDEO_CALL: Ja,
        CURRENT_USER_PROMOTED_PARTICIPANT: m,
        CURRENT_USER_RECEIVED_STORY_MENTION_IG: Aa,
        CURRENT_USER_SELF_DEMOTED: r,
        CURRENT_USER_SEND_ATTACHMENT: $,
        CURRENT_USER_SEND_AUDIO: v,
        CURRENT_USER_SEND_BUMP_MESSAGE_FALLBACK: qb,
        CURRENT_USER_SEND_CONTACT_SHARE_FALLBACK: hb,
        CURRENT_USER_SEND_GIF: w,
        CURRENT_USER_SEND_IMAGE: t,
        CURRENT_USER_SEND_LOCATION: db,
        CURRENT_USER_SEND_LOCATION_FALLBACK: bb,
        CURRENT_USER_SEND_NOTE_MENTION_FALLBACK: nb,
        CURRENT_USER_SEND_POLL_CREATION_FALLBACK: fb,
        CURRENT_USER_SEND_STICKER: x,
        CURRENT_USER_SEND_STICKER_RECEIVER_FETCH_MESSAGE_FALLBACK: tb,
        CURRENT_USER_SEND_STORY_MENTION: kb,
        CURRENT_USER_SEND_STORY_MENTION_FALLBACK: jb,
        CURRENT_USER_SEND_TEXT: s,
        CURRENT_USER_SEND_UNRENDERABLE_MESSAGE_FALLBACK: $a,
        CURRENT_USER_SEND_VIDEO: u,
        CURRENT_USER_SENT_EVENT: ya,
        CURRENT_USER_SENT_POST: va,
        CURRENT_USER_SENT_REEL: wa,
        CURRENT_USER_SENT_STORY: xa,
        CURRENT_USER_SENT_STORY_HIGHLIGHT: Fa,
        CURRENT_USER_STARTED_GROUP_AUDIO_CALL: Pa,
        CURRENT_USER_STARTED_GROUP_VIDEO_CALL: Ra,
        CURRENT_USER_UNSENT_MESSAGE: ja,
        CURRENT_USER_VIDEO_CALLED: Na,
        EMPTY_SNIPPET: a,
        EPHEMERAL_SETTINGS_AUTO_RESET: ia,
        ICDC_ALERT_ADMIN_MESSAGE: sa,
        META_AI_SEND_MESSAGE_FALLBACK: pb,
        PARTICIPANT_AUDIO_CALLED: Ma,
        PARTICIPANT_BUMPED_CURRENT_USER_MESSAGE: Xa,
        PARTICIPANT_BUMPED_OWN_MESSAGE: Va,
        PARTICIPANT_BUMPED_PARTICIPANT_MESSAGE: Wa,
        PARTICIPANT_CREATED_GROUP: c,
        PARTICIPANT_DEMOTED_PARTICIPANT: o,
        PARTICIPANT_DEMOTED_YOU: l,
        PARTICIPANT_EPHEMERAL_RECORD_SCREEN: ra,
        PARTICIPANT_EPHEMERAL_SETTING_CHANGE_DAYS: ea,
        PARTICIPANT_EPHEMERAL_SETTING_CHANGE_HOURS: da,
        PARTICIPANT_EPHEMERAL_SETTING_CHANGE_MINUTES: ca,
        PARTICIPANT_EPHEMERAL_SETTING_CHANGE_SECONDS: ba,
        PARTICIPANT_EPHEMERAL_SETTING_TURNED_OFF: ha,
        PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_DAYS: R,
        PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_HOURS: Q,
        PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_MINUTES: P,
        PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_SECONDS: O,
        PARTICIPANT_EPHEMERAL_TAKE_SCREENSHOT: qa,
        PARTICIPANT_GOT_DEMOTED: j,
        PARTICIPANT_GOT_PROMOTED: i,
        PARTICIPANT_MISSED_AUDIO_CALL: Ia,
        PARTICIPANT_MISSED_VIDEO_CALL: Ka,
        PARTICIPANT_PROMOTED_PARTICIPANT: p,
        PARTICIPANT_PROMOTED_YOU: k,
        PARTICIPANT_REACT_MESSAGE: la,
        PARTICIPANT_REACT_MESSAGE_IN_GROUP: ma,
        PARTICIPANT_SELF_DEMOTED: q,
        PARTICIPANT_SEND_ATTACHMENT: ua,
        PARTICIPANT_SEND_AUDIO: C,
        PARTICIPANT_SEND_BUMP_MESSAGE: rb,
        PARTICIPANT_SEND_BUMP_MESSAGE_ORIGINAL_UNAVAILABLE_FALLBACK: sb,
        PARTICIPANT_SEND_CONTACT_SHARE_FALLBACK: ib,
        PARTICIPANT_SEND_GIF: D,
        PARTICIPANT_SEND_IMAGE: A,
        PARTICIPANT_SEND_LOCATION: eb,
        PARTICIPANT_SEND_LOCATION_FALLBACK: cb,
        PARTICIPANT_SEND_NOTE_MENTION_FALLBACK: ob,
        PARTICIPANT_SEND_POLL_CREATION_FALLBACK: gb,
        PARTICIPANT_SEND_STICKER: E,
        PARTICIPANT_SEND_STICKER_RECEIVER_FETCH_MESSAGE_FALLBACK: ub,
        PARTICIPANT_SEND_STORY_MENTION: lb,
        PARTICIPANT_SEND_STORY_MENTION_FALLBACK: mb,
        PARTICIPANT_SEND_TEXT: y,
        PARTICIPANT_SEND_TEXT_IN_GROUP: z,
        PARTICIPANT_SEND_UNRENDERABLE_MESSAGE_FALLBACK: ab,
        PARTICIPANT_SEND_VIDEO: B,
        PARTICIPANT_SENT_EVENT: Ea,
        PARTICIPANT_SENT_POST: Ba,
        PARTICIPANT_SENT_REEL: Ca,
        PARTICIPANT_SENT_STORY: Da,
        PARTICIPANT_SENT_STORY_HIGHLIGHT: Ga,
        PARTICIPANT_STARTED_GROUP_AUDIO_CALL: Qa,
        PARTICIPANT_STARTED_GROUP_VIDEO_CALL: Sa,
        PARTICIPANT_UNSENT_MESSAGE: ka,
        PARTICIPANT_VIDEO_CALLED: Oa,
        UNAVAILABLE_SNIPPET: F,
        UNAVAILABLE_STORY: xb,
        UNKNOWN_USER_CREATED_GROUP: e,
        UNKNOWN_USER_EPHEMERAL_RECORD_SCREEN: na,
        UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_DAYS: V,
        UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_HOURS: U,
        UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_MINUTES: T,
        UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_SECONDS: S,
        UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_OFF: fa,
        UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_DAYS: J,
        UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_HOURS: I,
        UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_MINUTES: H,
        UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_SECONDS: G,
        UNKNOWN_USER_EPHEMERAL_TAKE_SCREENSHOT: Z,
        USER_SEND_ENCRYPTED_MESSAGE_FALLBACK: Za,
        USER_SEND_UNAVAILABLE_MESSAGE_FALLBACK: Ya,
        VIEW_ONCE_PHOTO_MESSAGE: vb,
        VIEW_ONCE_VIDEO_MESSAGE: wb,
        YOU_EPHEMERAL_RECORD_SCREEN: pa,
        YOU_EPHEMERAL_SETTING_CHANGE_DAYS: aa,
        YOU_EPHEMERAL_SETTING_CHANGE_HOURS: Y,
        YOU_EPHEMERAL_SETTING_CHANGE_MINUTES: X,
        YOU_EPHEMERAL_SETTING_CHANGE_SECONDS: W,
        YOU_EPHEMERAL_SETTING_TURNED_OFF: ga,
        YOU_EPHEMERAL_SETTING_TURNED_ON_DAYS: N,
        YOU_EPHEMERAL_SETTING_TURNED_ON_HOURS: M,
        YOU_EPHEMERAL_SETTING_TURNED_ON_MINUTES: L,
        YOU_EPHEMERAL_SETTING_TURNED_ON_SECONDS: K,
        YOU_EPHEMERAL_TAKE_SCREENSHOT: oa,
        YOUR_DEVICE_ICDC_ALERT_ADMIN_MESSAGE: ta
    });
    g.CURRENT_USER_CREATED_GROUP = b;
    g.CURRENT_USER_SEND_TEXT = s;
    g.CURRENT_USER_SEND_IMAGE = t;
    g.CURRENT_USER_SEND_VIDEO = u;
    g.CURRENT_USER_SEND_AUDIO = v;
    g.CURRENT_USER_SEND_GIF = w;
    g.CURRENT_USER_SEND_STICKER = x;
    g.UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_SECONDS = G;
    g.UNKNOWN_USER_EPHEMERAL_TAKE_SCREENSHOT = Z;
    g.CURRENT_USER_SEND_ATTACHMENT = $;
    g.LOCALIZATION_TYPE = d
}), 98);
__d("MAWDbChatId__UNSAFE_DO_NOT_USE", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        return (h || (h = d("I64"))).of_float(a)
    }

    function b(a, b) {
        return a + "_" + b
    }
    g.convertToChatId64__DEPRECATED = a;
    g.craftAltIndex__DEPRECATED = b
}), 98);
__d("MAWHexUtils", ["err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = a.toString(16);
        return (a.length - 1).toString(16) + a
    }

    function b(a) {
        for (var b = 1; b < a.length; b++) {
            var d = a.substring(0, b),
                e = a.substring(b);
            if (e.length - 1 === parseInt(d, 16)) return parseInt(e, 16)
        }
        throw c("err")("Cannot convert the order-preserving-hex back to number")
    }
    g.orderPreservingHex = a;
    g.reverseOrderPreservingHex = b
}), 98);
__d("WAMsg", ["WAAssertUnreachable", "WAJids", "WAMsgType", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.author,
            c = a.chat;
        a = a.externalId;
        return c + "_" + a + "_" + b
    }

    function h(a) {
        switch (a.type) {
            case d("WAMsgType").MSG_TYPE.TEXT:
            case d("WAMsgType").MSG_TYPE.IMAGE:
            case d("WAMsgType").MSG_TYPE.VIDEO:
            case d("WAMsgType").MSG_TYPE.PTT:
            case d("WAMsgType").MSG_TYPE.GIF:
            case d("WAMsgType").MSG_TYPE.STICKER:
            case d("WAMsgType").MSG_TYPE.RECEIVER_FETCH:
                return {
                    author: a.id.author,
                    deleteTs: a.deleteTs,
                    ephemeralSetting: a.ephemeralSetting,
                    expirationTs: a.expirationTs,
                    externalId: a.id.externalId,
                    sentTs: a.sentTs,
                    serverTs: a.serverTs,
                    ts: a.ts
                };
            case d("WAMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("WAMsgType").MSG_TYPE.UNAVAILABLE:
                return {
                    author: a.id.author,
                    externalId: a.id.externalId,
                    sentTs: a.sentTs,
                    ts: a.ts
                };
            default:
                a.type;
                return null
        }
    }

    function b(a) {
        var b = h(a);
        if (b == null) return null;
        switch (a.type) {
            case d("WAMsgType").MSG_TYPE.TEXT:
                return babelHelpers["extends"]({}, b, {
                    msgContent: a.msgContent,
                    type: d("WAMsgType").MSG_TYPE.TEXT
                });
            case d("WAMsgType").MSG_TYPE.IMAGE:
                return babelHelpers["extends"]({}, b, {
                    mediaId: a.mediaId,
                    type: d("WAMsgType").MSG_TYPE.IMAGE
                });
            case d("WAMsgType").MSG_TYPE.VIDEO:
                return babelHelpers["extends"]({}, b, {
                    mediaId: a.mediaId,
                    type: d("WAMsgType").MSG_TYPE.VIDEO
                });
            case d("WAMsgType").MSG_TYPE.PTT:
                return babelHelpers["extends"]({}, b, {
                    mediaId: a.mediaId,
                    type: d("WAMsgType").MSG_TYPE.PTT
                });
            case d("WAMsgType").MSG_TYPE.STICKER:
                return babelHelpers["extends"]({}, b, {
                    mediaId: a.mediaId,
                    type: d("WAMsgType").MSG_TYPE.STICKER
                });
            case d("WAMsgType").MSG_TYPE.RECEIVER_FETCH:
                return babelHelpers["extends"]({}, b, {
                    type: d("WAMsgType").MSG_TYPE.RECEIVER_FETCH
                });
            case d("WAMsgType").MSG_TYPE.GIF:
                return babelHelpers["extends"]({}, b, {
                    mediaId: a.mediaId,
                    type: d("WAMsgType").MSG_TYPE.PTT
                });
            case d("WAMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
                return babelHelpers["extends"]({}, b, {
                    type: d("WAMsgType").MSG_TYPE.EXPIRED_EPHEMERAL
                });
            case d("WAMsgType").MSG_TYPE.UNAVAILABLE:
                return babelHelpers["extends"]({}, b, {
                    type: d("WAMsgType").MSG_TYPE.UNAVAILABLE
                });
            case d("WAMsgType").MSG_TYPE.REVOKED:
            case d("WAMsgType").MSG_TYPE.REACTION:
            case d("WAMsgType").MSG_TYPE.ICDC_ALERT:
            case d("WAMsgType").MSG_TYPE.ADMIN:
            case d("WAMsgType").MSG_TYPE.FUTUREPROOF:
            case d("WAMsgType").MSG_TYPE.CIPHERTEXT:
            case d("WAMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("WAMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("WAMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE:
            case d("WAMsgType").MSG_TYPE.GROUP_INVITE:
            case d("WAMsgType").MSG_TYPE.DELETE_FOR_ME:
            case d("WAMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("WAMsgType").MSG_TYPE.EDIT_ACTION:
                return null;
            default:
                return c("WAAssertUnreachable")(a.type)
        }
    }

    function e(a) {
        if (d("WAJids").isAuthorSystem(a.author)) throw c("err")("Cannot send @system messages");
        else return {
            author: a.author,
            chat: a.chat,
            externalId: a.externalId
        }
    }
    g.craftWAMsgIdString = a;
    g.asQuotedMsg = b;
    g.asProtocolMsgId = e
}), 98);
__d("MAWDbMsg", ["FBLogger", "I64", "MAWDbChatId__UNSAFE_DO_NOT_USE", "MAWHexUtils", "MAWMsgType", "WAMsg", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    i = [(i = d("MAWMsgType")).MSG_TYPE.REVOKED, i.MSG_TYPE.EPHEMERAL_SYNC_RESPONSE, i.MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE, i.MSG_TYPE.GROUP_INVITE, i.MSG_TYPE.SK_DISTRIBUTION, i.MSG_TYPE.RAVEN_ACTION];
    var j = 0,
        k = Number.MAX_SAFE_INTEGER;

    function a(a) {
        return v(a) ? a : null
    }

    function b(a) {
        return a
    }

    function e(a) {
        return a
    }
    var l = "futureproof",
        m = "futureproof_spam",
        n = "spam",
        o = "toBeRead",
        p = "e2ee_admin_msg",
        q = "cutover_admin_msg";

    function r(a, b) {
        return d("MAWHexUtils").orderPreservingHex(a) + "_" + d("MAWHexUtils").orderPreservingHex(b) + "_m"
    }

    function f(a, b, e) {
        a = d("MAWHexUtils").orderPreservingHex(a) + "_" + d("MAWHexUtils").orderPreservingHex(b) + "_m";
        return !c("justknobx")._("621") ? a : a + "_" + e.externalId
    }

    function s(a, b) {
        return !c("justknobx")._("1903") ? r(a, b) : d("MAWHexUtils").orderPreservingHex(a) + "_" + d("MAWHexUtils").orderPreservingHex(b) + "_um"
    }

    function t(a, b) {
        return !c("justknobx")._("1903") ? r(a, b) : d("MAWHexUtils").orderPreservingHex(a) + "_" + d("MAWHexUtils").orderPreservingHex(b) + "_r"
    }

    function u(a, b) {
        return d("MAWHexUtils").orderPreservingHex(a) + "_" + d("MAWHexUtils").orderPreservingHex(b) + "_DEBUG_" + d("MAWHexUtils").orderPreservingHex(Math.floor(Math.random() * 1e4))
    }

    function v(a) {
        a = a.split("_");
        return a.length >= 3 && a[0] !== "" && a[1] !== "" && a[2] === "m"
    }

    function w(a) {
        return d("MAWDbChatId__UNSAFE_DO_NOT_USE").craftAltIndex__DEPRECATED(a, o)
    }

    function x(a) {
        return d("MAWDbChatId__UNSAFE_DO_NOT_USE").craftAltIndex__DEPRECATED(a, p)
    }

    function y(a) {
        return d("MAWDbChatId__UNSAFE_DO_NOT_USE").craftAltIndex__DEPRECATED(a, q)
    }

    function z(a) {
        a = a.split("_");
        a[0];
        a = a[1];
        return d("MAWHexUtils").reverseOrderPreservingHex(a)
    }

    function A(a) {
        return d("MAWHexUtils").orderPreservingHex(a) + "_"
    }

    function B(a) {
        return d("MAWHexUtils").orderPreservingHex(a) + "_z"
    }

    function C(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.XMA:
                return !0;
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return !1
        }
        throw c("FBLogger")("maw_db").mustfixThrow('Invalid msg type for isXMAMsg check: "%s"', a.type)
    }

    function D(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
                return !0;
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.XMA:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return !1
        }
        throw c("FBLogger")("maw_db").mustfixThrow('Invalid msg type for isMediaMsg check: "%s"', a.type)
    }

    function E(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
                return !0;
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.XMA:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return !1;
            default:
                c("FBLogger")("maw_db").mustfix('Invalid msg type for isPhotoOrVideoMediaMsg check: "%s"', a.type);
                return !1
        }
    }

    function F(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                return !0;
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.XMA:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return !1;
            default:
                c("FBLogger")("maw_db").mustfix('Invalid msg type for isDocumentFileMediaMsg check: "%s"', a.type);
                return !1
        }
    }

    function G(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME:
            case d("MAWMsgType").MSG_TYPE.XMA:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return !0;
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.SK_DISTRIBUTION:
            case d("MAWMsgType").MSG_TYPE.RAVEN_ACTION:
            case d("MAWMsgType").MSG_TYPE.EDIT_ACTION:
                return !1
        }
        throw c("FBLogger")("maw_db").mustfixThrow('Invalid msg type for isContentMsg check: "%s"', a.type)
    }

    function H(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.XMA:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return !0;
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME:
            case d("MAWMsgType").MSG_TYPE.SK_DISTRIBUTION:
            case d("MAWMsgType").MSG_TYPE.EDIT_ACTION:
                return !1
        }
        throw c("FBLogger")("maw_db").mustfixThrow('Invalid msg type for isMsgEligibleForTriggeringEphemeralSyncResponse check: "%s"', a.type)
    }

    function I(a) {
        return K(a.type)
    }

    function J(a) {
        return a.type === d("MAWMsgType").MSG_TYPE.ADMIN
    }

    function K(a) {
        return a === "EphemeralSyncResponse" || a === "EphemeralSettingChangeFromCurrentDevice" || a === "GroupInvite" || a === "SenderKeyDistribution" || a === "RavenAction" || a === "EditAction"
    }

    function L(a) {
        return a === "RavenAction"
    }

    function M(a) {
        return a.originalTs != null ? a.originalTs : N(a)
    }

    function N(a) {
        return a.serverTs != null ? a.serverTs : a.ts
    }

    function O(a) {
        if (a.sortOrderMs != null) return a.sortOrderMs;
        else return N(a) * 1e3
    }

    function P(a, b) {
        if (a.serverTs != null) return Math.max(b + 1, a.serverTs * 1e3);
        else return b + 1
    }

    function Q(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
                return a.msgContent;
            case d("MAWMsgType").MSG_TYPE.EDIT_ACTION:
                return a.editMsgContent;
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME:
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.XMA:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return
        }
        throw c("FBLogger")("maw_db").mustfixThrow('Invalid msg type for getMsgContent check: "%s"', a.type)
    }

    function R(a) {
        return d("WAMsg").craftWAMsgIdString({
            author: a.author,
            chat: a.threadJid,
            externalId: a.externalId
        })
    }

    function S(a) {
        return (h || (h = d("I64"))).to_float(a)
    }
    g.NO_CONTENT_MESSAGE_TYPES_ALLOWLIST = i;
    g.MIN_MSG_SORT_ORDER = j;
    g.MAX_MSG_SORT_ORDER = k;
    g.toMsgId = a;
    g.stanzaIdToMsgId = b;
    g.instamadilloMsgIdToMsgId = e;
    g.FUTUREPROOF_ALT_INDEX = l;
    g.FUTUREPROOF_SPAM_ALT_INDEX = m;
    g.SPAM_ALT_INDEX = n;
    g.craftMsgId = r;
    g.craftMsgIdV2 = f;
    g.craftUnrenderedMsgId = s;
    g.craftReactionId = t;
    g.craftDebugMsgId = u;
    g.isValidMsgId = v;
    g.craftToBeReadAltIndex = w;
    g.craftE2eeAdminMsgAltIndex = x;
    g.craftCutoverAdminMsgAltIndex = y;
    g.getInChatMsgIdFromMsgId = z;
    g.msgIdsInChatLowerBound = A;
    g.msgIdsInChatUpperBound = B;
    g.isXMAMsg = C;
    g.isMediaMsg = D;
    g.isPhotoOrVideoMediaMsg = E;
    g.isDocumentFileMediaMsg = F;
    g.isContentMsg = G;
    g.isMsgEligibleForTriggeringEphemeralSyncResponse = H;
    g.isUnrenderedMsg = I;
    g.isAdminMsg = J;
    g.isUnrenderedMsgType = K;
    g.isRavenActionMsgType = L;
    g.getOriginalTsFromMsg = M;
    g.getCanonicalTsFromMsg = N;
    g.getSortOrderWithFallback = O;
    g.getSortOrderFromPrevious = P;
    g.getMsgContent = Q;
    g.getWAMsgId = R;
    g.convertMsgRowId64 = S
}), 98);
__d("MAWUserJidWrapper", ["ExecutionEnvironment", "MAWCurrentUser", "MAWODSProxy", "WAGlobals", "WAJids", "WAOdsEnums"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        var a = d("WAJids").toMsgrUserJid(d("MAWCurrentUser").getID());
        if ((h || (h = c("ExecutionEnvironment"))).isInWorker) {
            var b = d("WAGlobals").getMyUserJid();
            d("MAWODSProxy").odsBumpEntityKey({
                entity: d("WAOdsEnums").Entity.MAW_MY_USER_JID_GETTER,
                key: b === a ? "same" : "different"
            });
            return b
        }
        return a
    }
    g.getMyUserJid = a
}), 98);
__d("MAWJobActionsV2", ["MAWTransactionMode", "Promise", "WAHex", "WALRUMap", "WATimeUtils", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a) {
        return new(h || (h = b("Promise")))(function(b, c) {
            a.onsuccess = b, a.onerror = c
        })
    }

    function j(a) {
        return i(a).then(function(a) {
            return a.target.result
        })
    }

    function k(a, c, e) {
        return new(h || (h = b("Promise")))(function(b, f) {
            var g = a(d("MAWTransactionMode").READONLY).index(c);
            g = g.openCursor(IDBKeyRange.only(e));
            var h = [];
            g.onsuccess = function(a) {
                a = a.target.result;
                if (!a) {
                    b(h);
                    return
                }
                h.push(a.value);
                a["continue"]()
            };
            g.onerror = function(a) {
                return f(a)
            }
        })
    }
    var l = new(d("WALRUMap").LRUMap)({
        max: 100
    });

    function a(a, c) {
        var e, f = c.args,
            g = c.scheduleConfig,
            i = c.type,
            l = c.uniqKey;
        c = c.version;
        c = c === void 0 ? 1 : c;
        e = JSON.stringify([i, (e = l) != null ? e : d("WAHex").randomHex(32)]);
        var n = {
                backedOffCount: 0,
                current: f,
                original: f,
                scheduleConfig: g,
                startTime: d("WATimeUtils").unixTime(),
                step: "$unstarted",
                stepFirstStartTime: null,
                stepHardStartCountAfterTimeout: 0,
                stepUnexpectedErrorCount: 0,
                type: i,
                uniqKey: e,
                version: c,
                waitUntil: null
            },
            o = function() {
                var b, c = a().add(n),
                    d = j(c);
                if (n.uniqKey == null && typeof((b = c.transaction) == null ? void 0 : b.commit) === "function") try {
                    c.transaction.commit()
                } catch (a) {}
                return d.then(function(a) {
                    return {
                        id: a,
                        newlyCreated: !0
                    }
                })
            };
        if (l != null) return k(a, "uniqKey", e).then(function(c) {
            if (c.length === 0) return o();
            var d = [],
                e = null;
            c.forEach(function(b) {
                b.step !== "$finished" ? e = b : d.push(m(a, b.jobId))
            });
            return (h || (h = b("Promise"))).all(d).then(function() {
                return e != null ? {
                    id: e.jobId,
                    newlyCreated: !1
                } : o()
            })
        });
        else return o()
    }

    function m(a, b) {
        return j(a()["delete"](b))
    }

    function e(a, b) {
        return j(a().get(b))
    }

    function f(a, b) {
        return j(a().put(b))
    }

    function n(a) {
        return j(a().getAll())
    }

    function o(a) {
        try {
            return i(a().clear()).then(c("emptyFunction"))
        } catch (a) {
            if (a.name === "NotFoundError") return (h || (h = b("Promise"))).resolve();
            throw a
        }
    }
    g.recentFinishedJobsCache = l;
    g.maybeCreateJob = a;
    g.deletePersistedJob = m;
    g.readPersistedJob = e;
    g.updatePersistedJob = f;
    g.readAllPersistedJobs = n;
    g.clearJobs = o
}), 98);
__d("MAWLoggerUtils", ["Random"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c = {
        CleanerPurge: "CleanerPurge",
        CleanerStart: "CleanerStart",
        CleanerTimestamp: "CleanerTimestamp",
        CleanerUpdate: "CleanerUpdate",
        Countdown: "Countdown",
        Ephemeral: "Ephemeral",
        Incoming: "Incoming",
        MsgCleaner: "MsgCleaner",
        OnLoad: "OnLoad",
        OnRead: "OnRead",
        Outgoing: "Outgoing",
        PeerReceipt: "PeerReceipt",
        SettingChange: "SettingChange",
        SettingSync: "SettingSync",
        DeviceRegistration: "DeviceRegistration",
        MessageReceive: "MessageReceive",
        MediaDownload: "MediaDownload",
        WorkerSetup: "WorkerSetup",
        MAWWorker: "MAWWorker",
        MAWInit: "MAWInit",
        LogoutHandler: "LogoutHandler",
        MiActMapping: "MiActMapping",
        ThreadReady: "ThreadReady"
    };

    function a() {
        return Math.floor(Date.now() + d("Random").random() * 1e4 + 1e4)
    }

    function b(a) {
        a = a.split("");
        return a.reduce(function(a, b) {
            b = b.charCodeAt(0);
            a = (a << 5) - a + b;
            a &= a;
            return a
        }, 0)
    }
    g.Tag = c;
    g.getInstanceKey = a;
    g.getInstanceKeyFromId = b
}), 98); /*FB_PKG_DELIM*/
__d("WAAPIMetrics", ["WAGlobals", "WAJids", "WAPREList", "WAPREMetrics"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c) {
        c === void 0 && (c = {});
        return function() {
            var d = h(b, c);
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return a.apply(void 0, [d].concat(f)).then(function(a) {
                d.endSuccess();
                return a
            })["catch"](function(a) {
                d.endFail("error", {
                    string: {
                        error: "" + a.toString()
                    }
                });
                throw a
            })
        }
    }

    function h(a, b) {
        b === void 0 && (b = {});
        var c = null;
        try {
            c = d("WAGlobals").getDependencies().isEmployee() && d("WAGlobals").getDependencies().isUseridAnnotationEnabled() ? d("WAJids").extractUserId(d("WAGlobals").getMyUserJid()).slice(-5) : null
        } catch (a) {}
        return d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.WA_JOB_MANAGER, babelHelpers["extends"]({}, b, {
            string: babelHelpers["extends"]({}, (b = (b = b) == null ? void 0 : b.string) != null ? b : {}, {
                name: a,
                userHash: c
            })
        }))
    }
    g.withMetrics = a
}), 98);
__d("WADexieToWormMigration", ["MAWDexieTable", "MAWIndexedDb", "MAWTransactionMode", "Promise", "WADbTransactor", "WADexieToWormMigrationStatus", "WALogger", "asyncToGeneratorRuntime", "gkx", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["['WORM'] Error performing migration: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["['WORM'] Error reading property isWorm. Worm <-> Dexie migration was not complete. Reason: ", ""]);
        j = function() {
            return a
        };
        return a
    }
    var k = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a() {
            var a, c = "MigrationTimeoutError";
            a = b.call(this, c) || this;
            a.name = c;
            a.message = c;
            return a
        }
        return a
    }(babelHelpers.wrapNativeSuper(Error));

    function a(a) {
        var b = d("WADexieToWormMigrationStatus").getWormStatus();
        if (b == null) {
            d("WALogger").ERROR(j(), a);
            return !1
        }
        return b
    }
    var l = 1e4;

    function e(a, b) {
        return m.apply(this, arguments)
    }

    function m() {
        m = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            if (!c("gkx")("6294")) {
                d("WADexieToWormMigrationStatus").setWormStatus(!1);
                return
            }
            var e = c("gkx")("2284");
            b.addPoint("migration_start", {
                bool: {
                    isCopyingInChunks: e
                }
            });
            try {
                yield v(a, e, b), b.addPoint("migration_end"), d("WADexieToWormMigrationStatus").setWormStatus(!0)
            } catch (a) {
                d("WADexieToWormMigrationStatus").setWormStatus(!1), a instanceof k ? b.addPoint("migration_timeout") : b.addPoint("migration_fail"), d("WALogger").ERROR(i(), a)
            }
        });
        return m.apply(this, arguments)
    }

    function n(a, b) {
        return o.apply(this, arguments)
    }

    function o() {
        o = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            var d = ["identity", "contacts", "session", "senderKeySessions", "prekey", "prekeyGeneration", "signedPrekey", "meta"];
            d = (yield(h || (h = b("Promise"))).all(d.map(function(b) {
                c.addPoint("migration_copy_" + b + "_start");
                return p(a, b).then(function(a) {
                    c.addPoint("migration_copy_" + b + "_end", {
                        bool: {
                            needToMigrate: a
                        }
                    });
                    return a
                })
            })));
            return d.some(function(a) {
                return a === !0
            })
        });
        return o.apply(this, arguments)
    }

    function p(a, b) {
        return q.apply(this, arguments)
    }

    function q() {
        q = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            var e = (yield d("MAWIndexedDb").getSignalDB());
            e = e.stores[b].schema.primKey.keyPath;
            var f = c("justknobx")._("3166"),
                g = 0,
                h = null;
            while ((h = (yield r(a, b, e, h, f))) != null) g++;
            return g > 0
        });
        return q.apply(this, arguments)
    }

    function r(a, b, c, d, e) {
        return s.apply(this, arguments)
    }

    function s() {
        s = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e, f) {
            var g, h = (yield d("WADbTransactor").makeSignalTransactor((g = {}, g[b] = d("MAWTransactionMode").READONLY, g), "MigrationReadChunkFromDexie", function(a) {
                return function() {
                    return e != null ? a[b].where(":id").above(e).limit(f).toArray() : a[b].limit(f).toArray()
                }
            })());
            h.length > 0 && (yield a.runInTransaction([b], "readwrite", function(a) {
                return a.stores[b].bulkPut(h.filter(Boolean))
            }));
            return h.length > 0 ? h[h.length - 1][c] : null
        });
        return s.apply(this, arguments)
    }

    function t(a, b) {
        return u.apply(this, arguments)
    }

    function u() {
        u = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            var e;
            c.addPoint("migration_read_dexie_start");
            e = (yield d("WADbTransactor").makeSignalTransactor({
                identity: (e = d("MAWTransactionMode")).READONLY,
                contacts: e.READONLY,
                session: e.READONLY,
                senderKeySessions: e.READONLY,
                prekey: e.READONLY,
                prekeyGeneration: e.READONLY,
                signedPrekey: e.READONLY,
                meta: e.READONLY
            }, "MigrationReadFromDexie", function(a) {
                return function() {
                    return d("MAWDexieTable").dexieAll([a.identity.toArray(), a.contacts.toArray(), a.session.toArray(), a.senderKeySessions.toArray(), a.prekey.toArray(), a.prekeyGeneration.toArray(), a.signedPrekey.toArray(), a.meta.toArray()])
                }
            })());
            var f = e[0],
                g = e[1],
                i = e[2],
                j = e[3],
                k = e[4],
                l = e[5],
                m = e[6],
                n = e[7];
            e = f.length > 0 || g.length > 0 || i.length > 0 || j.length > 0 || k.length > 0 || l.length > 0 || m.length > 0 || n.length > 0;
            c.addPoint("migration_read_dexie_end", {
                bool: {
                    needToMigrate: e
                }
            });
            if (!e) return e;
            c.addPoint("migration_write_worm_start", {
                "int": {
                    identities: f.length,
                    contacts: g.length,
                    sessions: i.length,
                    senderKeySessions: j.length,
                    prekeys: k.length,
                    prekeyGenerations: l.length,
                    signedPrekeys: m.length
                }
            });
            yield a.runInTransaction(["identity", "contacts", "session", "senderKeySessions", "prekey", "prekeyGeneration", "signedPrekey", "meta"], "readwrite", function(a) {
                return (h || (h = b("Promise"))).all([a.stores.identity.bulkPut(f.filter(Boolean)), a.stores.contacts.bulkPut(g.filter(Boolean)), a.stores.session.bulkPut(i.filter(Boolean)), a.stores.senderKeySessions.bulkPut(j.filter(Boolean)), a.stores.prekey.bulkPut(k.filter(Boolean)), a.stores.prekeyGeneration.bulkPut(l.filter(Boolean)), a.stores.signedPrekey.bulkPut(m.filter(Boolean)), a.stores.meta.bulkPut(n.filter(Boolean))])
            });
            c.addPoint("migration_write_worm_end");
            return e
        });
        return u.apply(this, arguments)
    }

    function v(a, b, c) {
        return w.apply(this, arguments)
    }

    function w() {
        w = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c, e) {
            c = c ? n : t;
            c = (yield(h || (h = b("Promise"))).race([c(a, e), new h(function(a, b) {
                self.setTimeout(function() {
                    b(new k())
                }, l)
            })]));
            if (!c) return;
            try {
                e.addPoint("migration_clear_dexie_start");
                yield d("WADbTransactor").makeSignalTransactor({
                    identity: (c = d("MAWTransactionMode")).READWRITE,
                    contacts: c.READWRITE,
                    session: c.READWRITE,
                    senderKeySessions: c.READWRITE,
                    prekey: c.READWRITE,
                    prekeyGeneration: c.READWRITE,
                    signedPrekey: c.READWRITE,
                    meta: c.READWRITE
                }, "MigrationClearDexie", function(a) {
                    return function() {
                        return d("MAWDexieTable").dexieAll([a.identity.clear(), a.contacts.clear(), a.session.clear(), a.senderKeySessions.clear(), a.prekey.clear(), a.prekeyGeneration.clear(), a.signedPrekey.clear(), a.meta.clear()])
                    }
                })();
                e.addPoint("migration_clear_dexie_end")
            } catch (c) {
                e.addPoint("migration_clear_worm_start");
                yield a.runInTransaction(["identity", "contacts", "session", "senderKeySessions", "prekey", "prekeyGeneration", "signedPrekey", "meta"], "readwrite", function(a) {
                    return (h || (h = b("Promise"))).all([a.stores.identity.clear(), a.stores.contacts.clear(), a.stores.session.clear(), a.stores.senderKeySessions.clear(), a.stores.prekey.clear(), a.stores.prekeyGeneration.clear(), a.stores.signedPrekey.clear(), a.stores.meta.clear()])
                });
                e.addPoint("migration_clear_worm_end");
                throw c
            }
        });
        return w.apply(this, arguments)
    }
    g.isWorm = a;
    g.runMigration = e
}), 98);
__d("WADbRegistrationApi", ["MAWTransactionMode", "WADbSignal", "WADbTransactor", "WAJids", "WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["worker: got db data"]);
        h = function() {
            return a
        };
        return a
    }

    function i(a) {
        return a.meta.bulkGet([(a = d("WADbSignal")).MetaKeysEnum.fbid, a.MetaKeysEnum.deviceId, a.MetaKeysEnum.cat, a.MetaKeysEnum.regId, a.MetaKeysEnum.identityKeyPair, a.MetaKeysEnum.authKeyPair]).then(function(a) {
            var b = a[0],
                e = a[1],
                f = a[2],
                g = a[3],
                i = a[4];
            a = a[5];
            d("WALogger").LOG(h());
            b = b == null ? void 0 : b.value.fbid;
            e = e == null ? void 0 : e.value.deviceId;
            f = f == null ? void 0 : f.value.cat;
            g = g == null ? void 0 : g.value.regId;
            i = i == null ? void 0 : i.value.identityKeyPair;
            a = a == null ? void 0 : a.value.authKeyPair;
            if (b == null) throw c("err")("fbid not set");
            if (e == null) throw c("err")("deviceId not set");
            if (f == null) throw c("err")("fbCat not set");
            if (g == null || i == null) throw c("err")("regInfo not set");
            return {
                deviceJid: d("WAJids").toDeviceJid(d("WAJids").toMsgrUserJid(b), e),
                fbCat: f.encrypted_serialized_cat,
                regInfo: {
                    authKeyPair: a,
                    regId: g,
                    staticKeyPair: i
                },
                userJid: d("WAJids").toMsgrUserJid(b)
            }
        })
    }

    function a() {
        return d("WADbTransactor").makeSignalTransactor({
            meta: d("MAWTransactionMode").READONLY
        }, "loadAllRegistrationMeta", function(a) {
            return function() {
                return i(a)
            }
        })()
    }
    b = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READWRITE
    }, "saveLastSessionDeviceWasLinkedTo", function(a) {
        return function(b, c) {
            b = c.sessionId;
            return a.meta.put({
                key: d("WADbSignal").MetaKeysEnum.lastSessionDeviceWasLinkedTo,
                value: {
                    lastSessionDeviceWasLinkedTo: b
                }
            }).then(function() {})
        }
    });
    e = function(a) {
        return d("WADbTransactor").makeSignalTransactor({
            meta: d("MAWTransactionMode").READWRITE,
            signedPrekey: d("MAWTransactionMode").READWRITE
        }, "inMetaStoreAndSignedPreKey", function(b) {
            return function(c) {
                return a(b, c)
            }
        })
    };
    f = function(a) {
        return d("WADbTransactor").makeSignalTransactor({
            meta: d("MAWTransactionMode").READWRITE
        }, "saveDeviceId", function(b) {
            return function(c) {
                return a(b, c)
            }
        })
    };
    var j = function(a) {
            return d("WADbTransactor").makeSignalTransactor({
                identity: d("MAWTransactionMode").READONLY,
                meta: d("MAWTransactionMode").READONLY,
                signedPrekey: d("MAWTransactionMode").READONLY
            }, "checkExistingRegistration", function(b) {
                return function() {
                    return a(b)
                }
            })()
        },
        k = function(a) {
            return d("WADbTransactor").makeSignalTransactor({
                contacts: d("MAWTransactionMode").READWRITE
            }, "saveICDC", function(b) {
                return function(c, d) {
                    return a(b, c, d)
                }
            })
        };
    g.loadAllRegistrationMetaInTransaction = a;
    g.saveLastSessionDeviceWasLinkedTo = b;
    g.inMetaStoreAndSignedPreKeyTransaction = e;
    g.inSaveDeviceIdTransaction = f;
    g.checkExistingRegTransaction = j;
    g.saveICDCInTransaction = k
}), 98);
__d("WormDb", ["WADexieToWormMigration", "WAHex", "WALogger", "WAPREList", "WAPREMetrics", "Worm", "WormEAR", "WormIDbDriver", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[WORM] Error performing initDb: ", ""]);
        h = function() {
            return a
        };
        return a
    }
    var i = {
            stanzaQueue: {
                autoIncrement: !0,
                primaryKey: "stanzaQueueId",
                indexes: {
                    "[jid+priority]": {
                        fields: ["jid", "priority"],
                        unique: !1
                    },
                    priority: {
                        fields: ["priority"],
                        unique: !1
                    },
                    jid: {
                        fields: ["jid"],
                        unique: !1
                    }
                },
                secure: !1
            },
            danglingQueue: {
                autoIncrement: !0,
                primaryKey: "queueId",
                secure: !1
            },
            identity: {
                primaryKey: "deviceJid",
                indexes: {
                    userJid: {
                        fields: ["userJid"],
                        unique: !1
                    }
                }
            },
            contacts: {
                primaryKey: "contactJid"
            },
            session: {
                primaryKey: "id"
            },
            senderKeySessions: {
                primaryKey: "id",
                indexes: {
                    groupJid: {
                        fields: ["groupJid"],
                        unique: !1
                    },
                    userJid: {
                        fields: ["userJid"],
                        unique: !1
                    }
                }
            },
            prekey: {
                primaryKey: "keyId"
            },
            prekeyGeneration: {
                primaryKey: "generationId"
            },
            signedPrekey: {
                primaryKey: "keyId"
            },
            meta: {
                primaryKey: "key"
            }
        },
        j;

    function a(a, b, c, d) {
        return k.apply(this, arguments)
    }

    function k() {
        k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e) {
            var f = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.WORM, {
                string: {
                    operationType: "initDb"
                },
                bool: {
                    isWorm: !0
                }
            }, void 0, 15e3);
            try {
                b = d("WAHex").parseHex(b);
                b = new(d("WormEAR").WormEAR)(i, b);
                a = new(d("Worm").WormDatabase)(new(d("WormIDbDriver").WormIDbDriver)(a, i, b, {
                    storesToArchiveInEmergency: ["meta"],
                    blockingErrorThreshold: c,
                    onBlockingError: e
                }));
                j = a;
                yield a.init({
                    eventFlow: f
                });
                yield d("WADexieToWormMigration").runMigration(a, f);
                f.endSuccess();
                return a
            } catch (a) {
                f.endFail("error");
                d("WALogger").ERROR(h(), a);
                throw a
            }
        });
        return k.apply(this, arguments)
    }

    function e() {
        if (j == null) throw c("err")("Signal Db v3 is not initialized");
        return j
    }

    function f(a) {
        return "Signal - " + a
    }
    g.makeDb = a;
    g.getDb = e;
    g.signalOp = f
}), 98);
__d("WADbRegistrationApiV2", ["Promise", "WADbSignal", "WAJids", "WALogger", "WormDb", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["worker: got db data"]);
        i = function() {
            return a
        };
        return a
    }
    var j = function(a, c) {
        return d("WormDb").getDb().runInTransaction(["contacts"], "readwrite", function() {
            var d = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                var d = (yield b.stores.contacts.get(a));
                if (d != null) return b.stores.contacts.bulkPut([babelHelpers["extends"]({}, d, {
                    icdcInfo: c
                })]);
                else return b.stores.contacts.bulkPut([{
                    contactJid: a,
                    dhash: null,
                    icdcInfo: c
                }])
            });
            return function(a) {
                return d.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("saveICDC"))
    };

    function a(a) {
        return d("WormDb").getDb().runInTransaction(["meta"], "readwrite", function(b) {
            return b.stores.meta.bulkPut([{
                key: d("WADbSignal").MetaKeysEnum.deviceId,
                value: {
                    deviceId: a
                }
            }])
        }, d("WormDb").signalOp("saveDeviceId"))
    }

    function e(a, c) {
        return d("WormDb").getDb().runInTransaction(["meta", "signedPrekey"], "readwrite", function() {
            var e = b("asyncToGeneratorRuntime").asyncToGenerator(function*(e) {
                yield(h || (h = b("Promise"))).all([e.stores.meta.bulkPut([{
                    key: d("WADbSignal").MetaKeysEnum.deviceUUID,
                    value: {
                        deviceUUID: c.deviceUUID
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.fbid,
                    value: {
                        fbid: a
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.regId,
                    value: {
                        regId: c.signalRegInfo.regId
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.identityKeyPair,
                    value: {
                        identityKeyPair: c.signalRegInfo.identityKeyPair
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.lastSignedPrekeyId,
                    value: {
                        lastSignedPrekeyId: c.signalRegInfo.signedPreKey.keyId
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.registrationVersion,
                    value: {
                        registrationVersion: c.registrationVersion
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.authKeyPair,
                    value: {
                        authKeyPair: c.signalRegInfo.authKeyPair
                    }
                }]), e.stores.signedPrekey.bulkPut([c.signalRegInfo.signedPreKey])])
            });
            return function(a) {
                return e.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("saveRegistrationMeta"))
    }
    var k = function(a, b) {
        var c = b.sessionId;
        return d("WormDb").getDb().runInTransaction(["meta"], "readwrite", function(a) {
            return a.stores.meta.bulkPut([{
                key: d("WADbSignal").MetaKeysEnum.lastSessionDeviceWasLinkedTo,
                value: {
                    lastSessionDeviceWasLinkedTo: c
                }
            }])
        }, d("WormDb").signalOp("saveLastSessionDeviceWasLinkedTo"))
    };

    function f() {
        return d("WormDb").getDb().runInTransaction(["meta"], "readonly", function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                a = (yield a.stores.meta.bulkGet([(a = d("WADbSignal")).MetaKeysEnum.fbid, a.MetaKeysEnum.deviceId, a.MetaKeysEnum.cat, a.MetaKeysEnum.regId, a.MetaKeysEnum.identityKeyPair, a.MetaKeysEnum.authKeyPair]));
                var b = a[0],
                    e = a[1],
                    f = a[2],
                    g = a[3],
                    h = a[4];
                a = a[5];
                d("WALogger").LOG(i());
                b = b == null ? void 0 : b.value.fbid;
                e = e == null ? void 0 : e.value.deviceId;
                f = f == null ? void 0 : f.value.cat;
                g = g == null ? void 0 : g.value.regId;
                h = h == null ? void 0 : h.value.identityKeyPair;
                a = a == null ? void 0 : a.value.authKeyPair;
                if (b == null) throw c("err")("fbid not set");
                if (e == null) throw c("err")("deviceId not set");
                if (f == null) throw c("err")("fbCat not set");
                if (g == null || h == null) throw c("err")("regInfo not set");
                return {
                    deviceJid: d("WAJids").toDeviceJid(d("WAJids").toMsgrUserJid(b), e),
                    fbCat: f.encrypted_serialized_cat,
                    regInfo: {
                        authKeyPair: a,
                        regId: g,
                        staticKeyPair: h
                    },
                    userJid: d("WAJids").toMsgrUserJid(b)
                }
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("loadAllRegistrationMeta"))
    }
    g.saveICDC = j;
    g.saveDeviceId = a;
    g.saveRegistrationMeta = e;
    g.saveLastSessionDeviceWasLinkedTo = k;
    g.loadAllRegistrationMetaInTransaction = f
}), 98);
__d("WAArmadilloICDC.pb", ["WAProtoConst"], (function(a, b, c, d, e, f, g) {
    a = {};
    b = {};
    a.internalSpec = {
        seq: [1, (c = d("WAProtoConst")).TYPES.INT32],
        timestamp: [2, c.TYPES.INT64],
        devices: [3, c.FLAGS.REPEATED | c.TYPES.BYTES],
        signingDeviceIndex: [4, c.TYPES.INT32]
    };
    b.internalSpec = {
        details: [1, c.TYPES.BYTES],
        signature: [2, c.TYPES.BYTES]
    };
    g.ICDCIdentityListSpec = a;
    g.SignedICDCIdentityListSpec = b
}), 98);
__d("WAIdentityUtils", ["WABinary", "WACryptoDependencies", "WASignalOther"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = a.length === 33 && a[0] === 5;
        return b ? a.slice(1) : a
    }

    function i(a, b) {
        for (var c = 0; c < a.length && c < b.length; ++c)
            if (a[c] !== b[c]) return a[c] - b[c];
        return a.length - b.length
    }

    function a(a) {
        a = a.map(function(a) {
            return h(a)
        });
        var b = new(d("WABinary").Binary)();
        a.sort(i).forEach(function(a) {
            return b.writeByteArray(a)
        });
        a = d("WACryptoDependencies").getCrypto().subtle.digest("SHA-256", b.readByteArray());
        return a.then(function(a) {
            a = new Uint8Array(a);
            return d("WASignalOther").sliceBytes(a, 0, 10)
        })
    }
    g.removeKeyTypeIfNeeded = h;
    g.computeIdentitiesHash = a
}), 98);
__d("WAICDCUtils", ["WAArmadilloICDC.pb", "WABase64", "WABinary", "WABridge", "WACryptoDependencies", "WACryptoEd25519", "WACryptoUtils", "WAIdentityUtils", "WAJids", "WALogger", "WAOdsEnums", "WASignalKeys", "WASignalOther", "WASignalSignatures", "WATimeUtils", "decodeProtobuf", "encodeProtobuf", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["ICDC timestamp is negative. time: ", ", closkSkew: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["signingDeviceIndex not found. This should never happen. ", ". caller: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Received ICDC has mismatched missed signingDeviceIndex"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Received ICDC has mismatched timestamp between XML node and byte structure"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Received ICDC has mismatched sequence between XML node and byte structure"]);
        l = function() {
            return a
        };
        return a
    }

    function a(a, b, c, e) {
        if (a !== e.details.seq) {
            d("WALogger").ERROR(l());
            return null
        }
        if (c !== e.details.timestamp) {
            d("WALogger").ERROR(k());
            return null
        }
        if (e.details.signingDeviceIndex == null) {
            d("WALogger").ERROR(j());
            return null
        }
        var f = e.details.signingDeviceIndex;
        return {
            dirty: b,
            sequence: a,
            timestamp: c,
            signingDeviceIndex: f,
            devices: e.details.devices.map(function(a) {
                return new Uint8Array(a)
            })
        }
    }

    function m(a) {
        return a.signingDeviceIndex < 0 || a.signingDeviceIndex >= a.devices.length
    }

    function n(a, b) {
        if (m(b)) return null;
        var c = new Set(),
            e = new Set();
        b.devices.forEach(function(a) {
            c.add(a.id), e.add(a.identity.toString())
        });
        var f = new Set(),
            g = new Set();
        a.devicesInfo.forEach(function(a) {
            var b = d("WAJids").extractDeviceId(a.jid);
            a = d("WAIdentityUtils").removeKeyTypeIfNeeded(a.identity);
            (!c.has(b) || !e.has(a.toString())) && (f.add(b), g.add(a.buffer))
        });
        return {
            seq: b.sequence,
            signingDevice: d("WAIdentityUtils").removeKeyTypeIfNeeded(b.devices[b.signingDeviceIndex].identity).buffer,
            unknownDevices: Array.from(g),
            unknownDeviceIds: Array.from(f)
        }
    }

    function b(a, b, c) {
        var d = new Map();
        c.forEach(function(a) {
            d.set(a.user, a)
        });
        c = d.get(a.user);
        var e = void 0;
        c != null && (e = n(a, c));
        var f = [],
            g = [];
        b.forEach(function(a) {
            var b = d.get(a.user);
            if (b != null) {
                b = n(a, b);
                b != null && f.push(b)
            }
            g.push(a.user)
        });
        return {
            senderIdentity: (a = e) != null ? a : void 0,
            recipientIdentities: f,
            recipientUserJids: g
        }
    }

    function e(a, b, c) {
        if (a == null) {
            d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                entity: d("WAOdsEnums").Entity.ICDC,
                key: "missing_icdc_payload"
            });
            return {
                action: "none"
            }
        } else if (b == null || a.seq == null || a.signingDevice == null) {
            b == null && d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                entity: d("WAOdsEnums").Entity.ICDC,
                key: "error.missing_stored_icdc"
            });
            (a.seq == null || a.signingDevice == null) && d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                entity: d("WAOdsEnums").Entity.ICDC,
                key: "error.invalid_icdc_payload"
            });
            return {
                action: "error",
                failureTs: d("WATimeUtils").unixTime(),
                sync: !0
            }
        }
        var e = a.seq,
            f = a.signingDevice;
        if (e === b.sequence) {
            var g = new Set();
            c.forEach(function(a) {
                return g.add(d("WAIdentityUtils").removeKeyTypeIfNeeded(a).toString())
            });
            e = !g.has(new Uint8Array(f).toString());
            b = a.unknownDevices.some(function(a) {
                return !g.has(new Uint8Array(a).toString())
            });
            if (e || b) {
                d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                    entity: d("WAOdsEnums").Entity.ICDC,
                    key: "error.unknow_device"
                });
                return {
                    action: "error",
                    failureTs: d("WATimeUtils").unixTime(),
                    sync: !0
                }
            }
        } else {
            d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                entity: d("WAOdsEnums").Entity.ICDC,
                key: "error.incorrect_seq"
            });
            return {
                action: "error",
                failureTs: d("WATimeUtils").unixTime(),
                sync: !0
            }
        }
        return {
            action: "none"
        }
    }

    function f(a) {
        a = d("decodeProtobuf").decodeProtobuf(d("WAArmadilloICDC.pb").SignedICDCIdentityListSpec, a);
        var b = a.signature;
        a = d("decodeProtobuf").decodeProtobuf(d("WAArmadilloICDC.pb").ICDCIdentityListSpec, a.details);
        return {
            signature: b,
            details: a
        }
    }

    function o(a) {
        return a.map(function(a) {
            return d("WASignalKeys").serializeIdentity(new Uint8Array(d("WABase64").decodeB64UrlSafe(a)))
        })
    }

    function p(a, b, e, f, g) {
        var j = d("WAIdentityUtils").removeKeyTypeIfNeeded(a.publicKey);
        e = e.map(function(a) {
            return d("WAIdentityUtils").removeKeyTypeIfNeeded(a)
        });
        var k = e.findIndex(function(a) {
            return d("WACryptoUtils").uint8ArraysEqual(a, j)
        });
        if (k === -1) {
            d("WALogger").ERROR(i(), f, g);
            throw c("err")("signingDeviceIndex not found")
        }
        f = b == null ? 1 : b + 1;
        g = d("WATimeUtils").unixTime();
        g < 0 && d("WALogger").ERROR(h(), Date.now(), d("WATimeUtils").getClockSkew());
        b = {
            seq: f,
            timestamp: g,
            devices: e,
            signingDeviceIndex: k
        };
        f = d("encodeProtobuf").encodeProtobuf(d("WAArmadilloICDC.pb").ICDCIdentityListSpec, b).readBuffer();
        g = q(a, d("WABinary").Binary.build(f).readByteArray());
        e = {
            details: f,
            signature: g
        };
        k = d("encodeProtobuf").encodeProtobuf(d("WAArmadilloICDC.pb").SignedICDCIdentityListSpec, e).readBuffer();
        return {
            icdcInfo: b,
            encodedSignedICDC: k
        }
    }

    function q(a, b) {
        var c = d("WASignalOther").makeBytes(64);
        d("WACryptoDependencies").getCrypto().getRandomValues(c);
        var e = new Uint8Array(64);
        d("WACryptoEd25519").hashSha512(e, b, b.length);
        e = d("WASignalSignatures").makeSignature(a, b, c);
        return d("WABinary").Binary.build(e).readBuffer()
    }
    var r = 4 * d("WATimeUtils").HOUR_SECONDS;

    function s(a) {
        return a == null ? !0 : !d("WATimeUtils").happenedWithin(a, r)
    }
    g.validateAndPrepareICDCFromNotification = a;
    g.isICDCIndexInvalid = m;
    g.computeICDCParticipantDevices = b;
    g.validateICDCInfo = e;
    g.decodeICDCInfo = f;
    g.base64DeviceIdentitiesToSerializedPubKeys = o;
    g.computeICDCInfoForUpload = p;
    g.isLastSyncTsExpired = s
}), 98);
__d("WADbIdentityTxns", ["MAWDexieTable", "WACryptoUtils", "WAGlobals", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Invalidate dhash for ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        if (b == null) return void 0;
        a = d("WAJids").isAuthorMe(a) ? d("WAGlobals").getMyUserJid() : a;
        return d("WAJids").toDeviceJid(a, b)
    }

    function b(a, b) {
        return i(a, b).then(function(a) {
            return a.map(function(a) {
                if (a == null) return;
                return {
                    id: a.deviceJid,
                    identity: a.identity
                }
            }).filter(Boolean)
        })
    }

    function c(a, b) {
        return a.identity.bulkPut(b).then(function() {})
    }

    function e(a, b) {
        return i(a, b).then(function(a) {
            var c = new Map();
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = b[d];
                e != null && c.set(f, {
                    pubKey: e.identity
                })
            }
            return c
        })
    }

    function i(a, b) {
        return a.identity.bulkGet(b)
    }

    function j(a, b) {
        return a.identity.where("userJid").equals(b).toArray()
    }

    function f(a, b) {
        return a.identity.where("userJid").anyOf(b).toArray()
    }

    function k(a, b, c) {
        var e = [],
            f = new Map();
        b.forEach(function(b) {
            var d = j(a, b).then(function(a) {
                var d = [];
                a.forEach(function(a) {
                    if (c != null && a.deviceJid === c) return;
                    d.push(a)
                });
                d.length > 0 && f.set(b, d)
            });
            e.push(d)
        });
        return d("MAWDexieTable").dexieAll(e).then(function() {
            return f
        })
    }

    function l(a, b) {
        var c = b.find(function(a) {
            return a.deviceJid === d("WAGlobals").getMyDeviceJid()
        });
        if (c != null) return a.identity.get(c.deviceJid).then(function(a) {
            if (a != null && !d("WACryptoUtils").uint8ArraysEqual(c.identity, a.identity)) return !0;
            else return !1
        });
        else return d("MAWDexieTable").dexieResolve(!1)
    }

    function m(a, b) {
        d("WALogger").DEV(h(), b);
        return a.contacts.bulkGet(b).then(function(b) {
            b = b.filter(Boolean);
            b.forEach(function(a) {
                a.dhash = null
            });
            return a.contacts.bulkPut(b)
        }).then(function() {})
    }
    g.getDeviceJid = a;
    g.bulkGetIdentities = b;
    g.bulkPutIdentities = c;
    g.getIdentitiesForDevices = e;
    g.bulkGetIdentityRows = i;
    g.getIdentitiesForUser = j;
    g.getIdentitiesForUsers = f;
    g.getIdentitiesForMultipleUsers = k;
    g.compareIdentityMismatch = l;
    g.invalidateDhash = m
}), 98);
__d("WADbIdentityTxnsV2", ["WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Invalidate dhash for ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        d("WALogger").DEV(h(), b);
        return a.contacts.bulkGet(b).then(function(b) {
            b = b.filter(Boolean);
            b.forEach(function(a) {
                a.dhash = null
            });
            return a.contacts.bulkPut(b)
        }).then(function() {})
    }

    function b(a, b) {
        return a.identity.bulkGet(b).then(function(a) {
            return a.map(function(a) {
                if (a == null) return;
                return {
                    id: a.deviceJid,
                    identity: a.identity
                }
            }).filter(Boolean)
        })
    }
    g.invalidateDhash = a;
    g.bulkGetIdentities = b
}), 98);
__d("WADbMetaTxns", ["MAWTransactionMode", "WADbSignal", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READWRITE
    }, "saveCAT", function(a) {
        return function(b) {
            return a.meta.put({
                key: d("WADbSignal").MetaKeysEnum.cat,
                value: {
                    cat: b
                }
            }).then(function() {
                return b
            })
        }
    });

    function a(a) {
        return a.meta.get(d("WADbSignal").MetaKeysEnum.deviceUUID).then(function(a) {
            return {
                deviceUUID: a == null ? void 0 : a.value.deviceUUID
            }
        })
    }

    function b(a) {
        return a.meta.bulkGet([d("WADbSignal").MetaKeysEnum.lastSignedPrekeyId, d("WADbSignal").MetaKeysEnum.identityKeyPair]).then(function(a) {
            var b = a[0];
            a = a[1];
            b = b == null ? void 0 : b.value.lastSignedPrekeyId;
            a = a == null ? void 0 : a.value.identityKeyPair;
            return {
                identityPair: a,
                keyId: b
            }
        })
    }

    function c(a) {
        return a.meta.get(d("WADbSignal").MetaKeysEnum.lastPrekeyId).then(function(a) {
            return a == null ? void 0 : a.value.lastPrekeyId
        })
    }

    function e(a) {
        return a.meta.get(d("WADbSignal").MetaKeysEnum.lastPrekeyGenerationId).then(function(a) {
            return a == null ? void 0 : a.value.lastPrekeyGenerationId
        })
    }

    function f(a) {
        return a.meta.toArray()
    }
    g.saveCAT = h;
    g.getPushMetaData = a;
    g.maybeGetLastSignedPrekeyIdAndIdentity = b;
    g.maybeGetLastPrekeyId = c;
    g.maybeGetLastPrekeyGenerationId = e;
    g.getAllMeta = f
}), 98);
__d("WADbMetaTxnsV2", ["WADbSignal", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a.meta.bulkGet([d("WADbSignal").MetaKeysEnum.lastSignedPrekeyId, d("WADbSignal").MetaKeysEnum.identityKeyPair]).then(function(a) {
            var b = a[0];
            a = a[1];
            b = b == null ? void 0 : b.value.lastSignedPrekeyId;
            a = a == null ? void 0 : a.value.identityKeyPair;
            return {
                identityPair: a,
                keyId: b
            }
        })
    }
    c = function(a) {
        return d("WormDb").getDb().runInTransaction(["meta"], "readwrite", function() {
            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                yield b.stores.meta.bulkPut([{
                    key: d("WADbSignal").MetaKeysEnum.cat,
                    value: {
                        cat: a
                    }
                }]);
                return a
            });
            return function(a) {
                return c.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("saveCAT"))
    };
    g.maybeGetLastSignedPrekeyIdAndIdentity = a;
    g.saveCAT = c
}), 98);
__d("WACompareIdentity", ["MAWODSProxy", "WABase64", "WACryptoUtils", "WADbIdentityTxns", "WADbSignal", "WAJids", "WALogger", "WAOdsEnums", "WASignalKeys", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Got identity mismatch ", ", ", " in compare identity"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        return a.meta.bulkGet([d("WADbSignal").MetaKeysEnum.fbid, d("WADbSignal").MetaKeysEnum.deviceId, d("WADbSignal").MetaKeysEnum.identityKeyPair]).then(function(b) {
            var e = b[0],
                f = b[1];
            b = b[2];
            e = e == null ? void 0 : e.value.fbid;
            f = f == null ? void 0 : f.value.deviceId;
            var g = b == null ? void 0 : b.value.identityKeyPair;
            if (e != null && f != null) {
                b = d("WAJids").toDeviceJid(d("WAJids").toMsgrUserJid(e), f);
                return d("WADbIdentityTxns").bulkGetIdentities(a, [b]).then(function(a) {
                    if (!(a.length === 0)) {
                        a = a[0];
                        if ((g == null ? void 0 : g.publicKey) == null) return !0;
                        if (!d("WACryptoUtils").serializedPubKeysEqual(a.identity, d("WASignalKeys").serializePubKey(g))) {
                            d("MAWODSProxy").odsBumpEntityKey({
                                entity: d("WAOdsEnums").Entity.COMPARE_IDENTITY,
                                key: "meta_identity_mismatch"
                            });
                            c("gkx")("23915") && c("gkx")("23916") && d("WALogger").ERROR(h(), d("WABase64").encodeB64(a.identity), d("WABase64").encodeB64(d("WASignalKeys").serializePubKey(g)));
                            return !1
                        }
                    }
                    return !0
                })
            }
            return !0
        })
    }
    g.compareIdentityDexie = a
}), 98); /*FB_PKG_DELIM*/
__d("DoubleKeyMap", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = new Map()
        }
        var b = a.prototype;
        b.set = function(a, b, c) {
            var d = this.$1.get(a);
            d || this.$1.set(a, d = new Map());
            d.set(b, c)
        };
        b.get = function(a, b) {
            return (a = this.$1.get(a)) == null ? void 0 : a.get(b)
        };
        b["delete"] = function(a, b) {
            var c = this.$1.get(a);
            c && (c["delete"](b), c.size === 0 && this.$1["delete"](a))
        };
        b.getAll = function(a) {
            return this.$1.get(a)
        };
        b.deleteAll = function(a) {
            this.$1["delete"](a)
        };
        return a
    }();
    f.DoubleKeyMap = a
}), 66);
__d("FuncChannel", ["FBLogger", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function() {
        function a(a) {
            var d = this,
                e;
            this.$2 = [];
            this.callMessageHandler = function(a) {
                return new(h || (h = b("Promise")))(function(b, c) {
                    a.result = {
                        resolveFunc: b,
                        rejectFunc: c
                    }, d.$2.push(a)
                })
            };
            this.messageToCall = function(a) {
                var b, e, f = d.proxyMethods[a.method];
                if (typeof f !== "function") {
                    c("FBLogger")("worker").mustfix("proxyMethods[%s] is not a functions", a.method);
                    return
                }
                b = (b = a.result) == null ? void 0 : b.resolveFunc;
                e = (e = a.result) == null ? void 0 : e.rejectFunc;
                if (typeof b === "function" && typeof e === "function") try {
                    var g = f.apply(a.thisArg, a.argList);
                    b(g)
                } catch (a) {
                    e(a)
                } else return f.apply(a.thisArg, a.argList)
            };
            var f = this,
                g = {},
                i = (e = a == null ? void 0 : a(g)) != null ? e : {},
                j = babelHelpers["extends"]({}, g);

            function k(a) {
                j[a] = function() {
                    var b = {
                        type: "call",
                        method: a,
                        thisArg: null,
                        argList: Array.from(arguments)
                    };
                    return f.callMessageHandler(b)
                }, g[a] = function() {
                    var b = f.$1[a];
                    if (typeof b !== "function") {
                        c("FBLogger")("worker").mustfix("_backend[%s] is not a functions", a);
                        return
                    }
                    return b.apply(f.$1, arguments)
                }, i[a] == null && (i[a] = g[a])
            }
            this.$1 = j;
            if (a != null) {
                e = Object.keys(i);
                e.forEach(k);
                this.proxyMethods = i
            } else this.proxyMethods = new Proxy(i, {
                get: function(a, b) {
                    a = b;
                    i[a] == null && k(a);
                    return i[a]
                }
            })
        }
        var d = a.prototype;
        d.flushBuffer = function() {
            var a = this.$2;
            this.$2 = [];
            a.forEach(this.messageToCall)
        };
        d.setBackend = function(a) {
            this.$1 !== a && (this.$1 = a, this.flushBuffer());
            return this
        };
        d.setCallMessageHandler = function(a) {
            this.callMessageHandler = a, this.flushBuffer()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MainPageUrl", ["ExecutionEnvironment", "FBLogger", "SimpleHook"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new URL("http://undefined"),
        j = new(d("SimpleHook").SimpleHook)();

    function k() {
        var a;
        return (h || (h = c("ExecutionEnvironment"))).isInBrowser && (i == null ? void 0 : (a = i.searchParams) == null ? void 0 : a.get("workerlog")) === "debug"
    }

    function a(a) {
        try {
            k() && c("FBLogger")("worker").debug("received url " + a);
            var b = new URL(a, i.href || "http://undefined");
            i.href !== b.href ? (i.href = b.href, j.call(i)) : k() && c("FBLogger")("worker").debug("ignoring url: path didn't change in " + a)
        } catch (a) {
            c("FBLogger")("worker").catching(a).warn("invalid url")
        }
    }
    typeof window === "object" && typeof window.location === "object" && typeof window.location.href === "string" && a(window.location.href);
    g.mainPageUrl = i;
    g.onMainPageUrlChange = j;
    g.isWorkerLogEnabled = k;
    g.updateMainPageUrl = a
}), 98);
__d("NestedTimeRange", ["SimpleHook", "performance", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = new(d("SimpleHook").SimpleHook)(),
        k = new(d("SimpleHook").SimpleHook)(),
        l = "/";

    function m(a, b) {
        return "" + a + l + b
    }
    b = function() {
        function a(a, b) {
            b === void 0 && (b = null), this.$3 = 0, this.$1 = a, this.$2 = b
        }
        var b = a.prototype;
        b.isRunning = function() {
            return this.$3 > 0
        };
        b.fullname = function() {
            return this.$2 !== null ? m(this.$2.fullname(), this.$1) : this.$1
        };
        b.start = function(a) {
            a === void 0 && (a = (h || (h = c("performanceAbsoluteNow")))());
            if (this.$3 === 0) {
                var b;
                (b = this.$2) == null ? void 0 : b.start(a);
                this.__onStart(a)
            }++this.$3;
            return a
        };
        b.__onStart = function(a) {
            j.call(this, a)
        };
        b.stop = function(a) {
            a === void 0 && (a = (h || (h = c("performanceAbsoluteNow")))());
            --this.$3;
            if (this.$3 === 0) {
                var b;
                this.__onStop(a);
                (b = this.$2) == null ? void 0 : b.stop(a)
            }
            return a
        };
        b.__onStop = function(a) {
            k.call(this, a)
        };
        return a
    }();

    function a() {
        (i || (i = c("performance"))).mark && (i || (i = c("performance"))).measure && (j.add(function(a, b) {
            (i || (i = c("performance"))).mark(a.fullname() + "_start")
        }), k.add(function(a, b) {
            (i || (i = c("performance"))).measure(a.fullname(), a.fullname() + "_start")
        }))
    }
    g.OnRangeStart = j;
    g.OnRangeStop = k;
    g.TIME_RANGE_LEVEL_SEPARATOR = l;
    g.rangeFullName = m;
    g.NestedTimeRange = b;
    g.enableDevConsoleTimeline = a
}), 98);
__d("QLogEvent", ["DoubleKeyMap", "FBLogger", "NestedTimeRange", "QPLEvent", "SimpleHook", "performanceNavigationStart"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new(d("DoubleKeyMap").DoubleKeyMap)(),
        j = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(a, c, d) {
                a = b.call(this, a, d) || this;
                a.$QPLRange$p_1 = c;
                i.set(c, a.fullname(), babelHelpers.assertThisInitialized(a));
                return a
            }
            var e = a.prototype;
            e.__onStart = function(a) {
                b.prototype.__onStart.call(this, a), this.$QPLRange$p_1.point(this.fullname() + "_START", {
                    timestamp: a
                })
            };
            e.__onStop = function(a) {
                b.prototype.__onStop.call(this, a), this.$QPLRange$p_1.point(this.fullname() + "_END", {
                    timestamp: a
                }), i["delete"](this.$QPLRange$p_1, this.fullname())
            };
            e.range = function(b) {
                this.fullname().startsWith(d("NestedTimeRange").TIME_RANGE_LEVEL_SEPARATOR) || c("FBLogger")("qpl").warn("Range %s cannot have subrange since root name does not start with /", this.fullname());
                var e = d("NestedTimeRange").rangeFullName(this.fullname(), b);
                return (e = i.get(this.$QPLRange$p_1, e)) != null ? e : new a(b, this.$QPLRange$p_1, this)
            };
            return a
        }(d("NestedTimeRange").NestedTimeRange),
        k = new(d("DoubleKeyMap").DoubleKeyMap)(),
        l = new((b = d("SimpleHook")).SimpleHook)(),
        m = new b.SimpleHook(),
        n = new b.SimpleHook(),
        o = new b.SimpleHook(),
        p = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(a, c, e, f, g) {
                var i;
                c === void 0 && (c = 0);
                e === void 0 && (e = 2);
                f === void 0 && (f = !1);
                var j = (h || (h = d("QPLEvent"))).getMarkerId(a);
                i = b.call(this, "event_" + j) || this;
                i.event = a;
                i.instanceKey = c;
                i.$QPLEvent$p_1 = e;
                i.isUserFlow = f;
                i.$QPLEvent$p_2 = g;
                k.set(j, c, babelHelpers.assertThisInitialized(i));
                return i
            }
            var e = a.prototype;
            e.action = function(a) {
                this.$QPLEvent$p_1 = a;
                return this
            };
            e.getAction = function() {
                return this.$QPLEvent$p_1
            };
            e.setIsUserFlow = function(a) {
                this.isUserFlow = a;
                return this
            };
            e.startFromNavStart = function() {
                this.start(c("performanceNavigationStart")());
                return this
            };
            e.startFromTime = function(a) {
                this.start(a);
                return this
            };
            e.__onStart = function(a) {
                var b;
                (b = this.$QPLEvent$p_2) == null ? void 0 : b.onStart(this, a);
                l.call(this, a)
            };
            e.__onStop = function(a) {
                var b;
                (b = this.$QPLEvent$p_2) == null ? void 0 : b.onStop(this, a);
                m.call(this, a);
                i.deleteAll(this);
                k["delete"]((h || (h = d("QPLEvent"))).getMarkerId(this.event), this.instanceKey)
            };
            e.range = function(a) {
                var b;
                return (b = i.get(this, a)) != null ? b : new j(a, this)
            };
            e.point = function(a, b) {
                var c;
                b === void 0 && (b = {});
                (c = this.$QPLEvent$p_2) == null ? void 0 : c.onPoint(this, a, b);
                n.call(this, a, b);
                return this
            };
            e.annotate = function(a) {
                var b;
                (b = this.$QPLEvent$p_2) == null ? void 0 : b.onAnnotate(this, a);
                o.call(this, a);
                return this
            };
            return a
        }(d("NestedTimeRange").NestedTimeRange);

    function a(a, b, c) {
        var e;
        b === void 0 && (b = 0);
        return (e = k.get((h || (h = d("QPLEvent"))).getMarkerId(a), b)) != null ? e : new p(a, b, 2, !1, c)
    }
    g.OnEventStart = l;
    g.OnEventStop = m;
    g.OnEventPoint = n;
    g.OnEventAnnotate = o;
    g.QPLEvent = p;
    g.event = a
}), 98);
__d("TimedOnceFunc", ["ExecutionEnvironment"], (function(a, b, c, d, e, f, g) {
    var h;
    a = function() {
        function a(a, b) {
            this.$2 = !1, this.$4 = a, this.$3 = b, (h || (h = c("ExecutionEnvironment"))).isInBrowser && this.$5()
        }
        var b = a.prototype;
        b.$6 = function() {
            this.$1 != null && clearTimeout(this.$1), this.$1 = null
        };
        b.$5 = function() {
            var a = this;
            this.isDone() || (this.$6(), this.$1 = setTimeout(function() {
                a.$2 = !0, a.run()
            }, this.$3))
        };
        b.isDone = function() {
            return this.$4 === null
        };
        b.isCancelled = function() {
            return this.$1 === null && this.$4 !== null
        };
        b.run = function() {
            this.$6();
            if (this.$4 != null) {
                var a = this.$4;
                this.$4 = null;
                a(this.$2)
            }
        };
        b.getDelay = function() {
            return this.$3
        };
        b.delay = function(a) {
            this.$3 = (a = a) != null ? a : this.$3;
            this.$5()
        };
        b.cancel = function() {
            this.$6()
        };
        return a
    }();
    g.TimedOnceFunc = a
}), 98);
__d("VirtualMessageChannel", ["invariant", "Promise", "SimpleHook", "nullthrows", "promiseDone"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = function() {
        function a(a) {
            a === void 0 && (a = !1), this.$2 = new(d("SimpleHook").SimpleHook)(), this.onmessage = null, this.onmessageerror = null, this.$3 = a
        }
        var e = a.prototype;
        e.setRemotePort = function(a) {
            this.$1 = a
        };
        e.addEventListener = function(a, b, c) {
            (a === "message" || a === "error") && c == null || h(0, 55320, a);
            if (a === "message")
                if (typeof b === "function") this.$2.add(b);
                else {
                    c = b.handleEvent.bind(b);
                    this.$2.add(c);
                    b.__handler = c
                }
        };
        e.removeEventListener = function(a, b, c) {
            if (typeof b === "function") this.$2.remove(b);
            else {
                a = b.__handler;
                this.$2.remove(a)
            }
        };
        e.postMessage = function(a, d) {
            var e = this,
                f = function() {
                    var b = c("nullthrows")(e.$1, "By now remote port must have value!");
                    b.$2.call({
                        data: a,
                        ports: d
                    })
                };
            this.$3 ? f() : c("promiseDone")((i || (i = b("Promise"))).resolve(), f)
        };
        e.start = function() {};
        return a
    }();
    a = function(a, b) {
        this.port1 = new j(a), this.port2 = new j(b), this.port1.setRemotePort(this.port2), this.port2.setRemotePort(this.port1)
    };
    g.VirtualMessagePort = j;
    g.VirtualMessageChannel = a
}), 98);
__d("WorkerMessagePortLogging", ["MainPageUrl", "QLogEvent", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = Math.random() < .1,
        i = 20,
        j = 100,
        k = 50;

    function a() {
        return d("MainPageUrl").isWorkerLogEnabled() || d("MainPageUrl").mainPageUrl.searchParams.get("worker_log") === 1
    }
    var l = 0;

    function m() {
        return d("QLogEvent").event(c("qpl")._(41497718, "106"), l++)
    }

    function b(a, b, c) {
        c === void 0 && (c = !1);
        if (b == null || !h) return;
        var d = b.sendDelayHighPrecision,
            e = b.sendTimestamp,
            f = b.sendDateTime,
            g = b.receiveTimestamp,
            l = b.receiveDateTime,
            n = m();
        n.startFromTime();
        var o = n.range("SEND_DELAY");
        o.start(e);
        o.stop(g);
        o = n.range("SEND_DELAY_LOW_PRECISION");
        o.start(f);
        o.stop(l);
        o = Math.abs(e - f);
        e = Math.abs(g - l);
        n.annotate({
            string: {
                port_name: a
            },
            "int": {
                send_delay: d,
                send_drift: o,
                receive_drift: e
            },
            bool: {
                send_delay_above_max: d != null && d > i,
                send_drift_above_max: o > j,
                receive_drift_above_max: e > j
            }
        });
        if (c) {
            f = n.range("ROUND_TRIP");
            f.start(b.sendTimestamp);
            f.stop(b.receiveTimestamp);
            g = b.receiveTimestamp - b.sendTimestamp;
            n.annotate({
                "int": {
                    round_trip: g
                },
                bool: {
                    round_trip_above_max: g > k
                }
            })
        }
        n.stop()
    }
    g.isWorkerLogEnabled = a;
    g.logMessageTiming = b
}), 98);
__d("WorkerMessagePort", ["Deferred", "FBLogger", "MainPageUrl", "Promise", "PromiseAnnotate", "SimpleHook", "VirtualMessageChannel", "WorkerMessagePortLogging", "performanceAbsoluteNow", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;

    function k(a) {
        return a
    }
    var l = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a() {
            return b.apply(this, arguments) || this
        }
        return a
    }(d("SimpleHook").SimpleHook);

    function m(a, b) {
        a = k(a);
        a.__timing = b
    }

    function n(a) {
        return a.__timing
    }
    a = function() {
        var a = e.prototype;
        a.onMessageHandler = function(a) {
            try {
                this.onMessage.call(a);
                var b = this.$1[a.type];
                !b ? this.onUnhandledMessage.call(a) : b.call(a)
            } catch (a) {
                this.onError.call(a)
            }
        };

        function e(a, b) {
            var e = this;
            this.$1 = {};
            this.onUnhandledMessage = new l();
            this.onMessage = new l();
            this.onPostMessage = new l();
            this.onError = new l();
            this.$2 = a;
            this.name = b;
            this.$2.addEventListener("message", function(a) {
                return e.onMessageHandler(k(a.data))
            });
            this.$2.addEventListener("error", function(a) {
                return e.onError.call(a)
            });
            this.onPostMessage.add(function(a) {
                m(a, {
                    receiveDateTime: -1,
                    receiveTimestamp: -1,
                    sendDateTime: Date.now(),
                    sendDelayHighPrecision: 0,
                    sendDelayLowPrecision: 0,
                    sendTimestamp: (j || (j = c("performanceAbsoluteNow")))()
                })
            });
            this.onMessage.add(function(a) {
                a = n(a);
                if (a != null) {
                    var b = a.sendDateTime,
                        f = a.sendTimestamp,
                        g = (j || (j = c("performanceAbsoluteNow")))(),
                        h = Date.now();
                    a.receiveTimestamp = g;
                    a.receiveDateTime = h;
                    a.sendDelayHighPrecision = g - f;
                    a.sendDelayLowPrecision = h - b;
                    d("WorkerMessagePortLogging").logMessageTiming(e.name, a)
                }
            })
        }
        a.postMessage = function(a, b) {
            this.onPostMessage.call(a), b ? this.$2.postMessage(a, b) : this.$2.postMessage(a)
        };
        a.addMessageListener = function(a, b) {
            var c = this.$1[a];
            c || (c = new l(), this.$1[a] = c);
            return c.add(b)
        };
        a.removeMessageListener = function(a, b) {
            a = this.$1[a];
            return !!a && a.remove(b)
        };
        a.onMessageOnce = function(a, c) {
            var d = this;
            return new(i || (i = b("Promise")))(function(b) {
                var e = d.addMessageListener(a, function(f) {
                    c(f) && (d.removeMessageListener(a, e), b(f))
                })
            })
        };
        a.close = function() {
            if (this.$2 instanceof MessagePort) this.$2.close();
            else if (this.$2 instanceof Worker) this.$2.terminate();
            else if (this.$2 instanceof DedicatedWorkerGlobalScope) this.$2.close();
            else {
                var a;
                (a = (a = this.$2.close) != null ? a : this.$2.terminate) == null ? void 0 : a.call(this.$2)
            }
        };
        a.isWrappingVirtualMessagePort = function() {
            return this.$2 instanceof d("VirtualMessageChannel").VirtualMessagePort
        };
        return e
    }();

    function o(a) {
        return k(a)
    }
    e = function(a) {
        babelHelpers.inheritsLoose(e, a);

        function e(e, f) {
            var g;
            g = a.call(this, e, f) || this;
            var j = o(babelHelpers.assertThisInitialized(g)),
                k = new(c("Deferred"))();
            e = k.getPromise();
            j.addMessageListener("endpoint_started", function(a) {
                k.resolve(a);
                var b = n(a);
                j.postMessage({
                    endpoint: a.endpoint,
                    startSendTimestamp: b == null ? void 0 : b.sendTimestamp,
                    targetEndpoint: g.name,
                    type: "endpoint_started_received"
                })
            });
            f = j.onMessageOnce("endpoint_started_received", function() {
                return !0
            });
            void(h || (h = d("PromiseAnnotate"))).setDisplayName(e, "endpoint_started");
            void h.setDisplayName(f, "endpoint_started_received");
            j.postMessage({
                endpoint: g.name,
                type: "endpoint_started"
            });
            c("promiseDone")(e, function(a) {
                a = n(a);
                d("WorkerMessagePortLogging").logMessageTiming(g.name, a)
            });
            c("promiseDone")(f, function(a) {
                a = n(a);
                a != null && d("WorkerMessagePortLogging").logMessageTiming(g.name, a, !0)
            });
            g.fullyConnected = (i || (i = b("Promise"))).race([e, f]).then(function() {
                return babelHelpers.assertThisInitialized(g)
            });
            return g
        }
        return e
    }(a);
    g.getMessageTiming = n;
    g.WorkerMessagePort = a;
    g.CastWorkerMessagePort = o;
    g.WorkerSyncedMessagePort = e
}), 98);
__d("WorkerFuncChannel", ["invariant", "DateConsts", "ExecutionEnvironment", "FBLogger", "FuncChannel", "MainPageUrl", "Promise", "TimedOnceFunc", "VirtualMessageChannel", "WorkerMessagePort", "err", "promiseDone"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = {
            serialize: function(a, b) {
                b.push(a);
                return a
            },
            deserialize: function(a) {
                return a
            }
        },
        l = 1e4,
        m = 0,
        n = 5,
        o = n + 1,
        p = function() {
            function a(a) {
                var b = self.WeakRef;
                b && (this.$1 = new b(a))
            }
            var b = a.prototype;
            b.isDead = function() {
                return this.$1 != null && this.$1.deref() == null
            };
            return a
        }(),
        q = function(e) {
            babelHelpers.inheritsLoose(a, e);

            function a(a, b, f, g) {
                var i;
                f === void 0 && (f = null);
                g === void 0 && (g = {});
                i = e.call(this, a) || this;
                i.$WorkerFuncChannel1 = new Map();
                i.$WorkerFuncChannel2 = new Map();
                i.$WorkerFuncChannel5 = {
                    "function": {
                        serialize: function(a, b) {
                            b = o++;
                            i.$WorkerFuncChannel1.set(b, a);
                            a = {
                                type: "function",
                                value: b
                            };
                            return a
                        },
                        deserialize: function(a) {
                            var b = babelHelpers.assertThisInitialized(i),
                                c = a.value;
                            a = function() {
                                var a = {
                                    type: "call",
                                    id: c,
                                    method: "__anonymous",
                                    thisArg: null,
                                    argList: Array.from(arguments)
                                };
                                return b.callMessageHandler(a)
                            };
                            i.$WorkerFuncChannel2.set(c, new p(a));
                            return a
                        }
                    },
                    custom: {
                        serialize: function(a, b) {
                            var c = a.constructor.name,
                                d = i.$WorkerFuncChannel4[c];
                            d != null || h(0, 63779, c);
                            d = d.serialize(a, b);
                            return {
                                type: "custom",
                                custom: c,
                                value: d
                            }
                        },
                        deserialize: function(a) {
                            var b = a.custom,
                                c = i.$WorkerFuncChannel4[b];
                            c != null || h(0, 63779, b);
                            return c.deserialize(a.value)
                        }
                    },
                    error: {
                        serialize: function(a, b) {
                            b = {
                                name: a.name,
                                message: a.message,
                                stack: a.stack
                            };
                            return {
                                type: "error",
                                value: b
                            }
                        },
                        deserialize: function(a) {
                            var b = c("err")(a.value.message);
                            b.name = a.value.name;
                            b.stack = a.value.stack;
                            return b
                        }
                    },
                    object: {
                        serialize: function(a, b) {
                            b = a.constructor;
                            if (b !== Object) throw new Error("Cannot clone class object");
                            return {
                                type: "object",
                                value: a
                            }
                        },
                        deserialize: function(a) {
                            return a.value
                        }
                    },
                    raw: {
                        serialize: function(a, b) {
                            return {
                                type: "raw",
                                value: a
                            }
                        },
                        deserialize: function(a) {
                            return a.value
                        }
                    }
                };
                i.name = b;
                i.$WorkerFuncChannel3 = f;
                i.$WorkerFuncChannel4 = g;
                a = function(a) {
                    d("MainPageUrl").isWorkerLogEnabled() && c("FBLogger")("adsworker").debug("[Channel] removing callback ids: %s", a.join()), a.forEach(function(a) {
                        return i.$WorkerFuncChannel1["delete"](a)
                    })
                };
                var k = i.__remoteInternalFunc(m, a);
                typeof jest === typeof void 0 && (j || (j = c("ExecutionEnvironment"))).isInBrowser && setInterval(function() {
                    var a = [];
                    i.$WorkerFuncChannel2.forEach(function(b, c) {
                        b.isDead() && (a.push(c), i.$WorkerFuncChannel2["delete"](c))
                    });
                    a.length > 0 ? k(a) : i.$WorkerFuncChannel2.size > 5e3 && c("FBLogger")("adsworker").warn("[%s] has too many remaining refs %s", i.name, i.$WorkerFuncChannel2.size)
                }, l);
                return i
            }
            var f = a.prototype;
            f.__remoteInternalFunc = function(a, b) {
                (a > n || this.$WorkerFuncChannel1.get(a) != null) && c("FBLogger")("adsworker").mustfix("invalid internal func id %s", a);
                this.$WorkerFuncChannel1.set(a, b);
                b = this.$WorkerFuncChannel5["function"].deserialize({
                    type: "function",
                    value: a
                });
                return b
            };
            f.$WorkerFuncChannel6 = function(a) {
                return a instanceof Int8Array || a instanceof Int16Array || a instanceof Int32Array || a instanceof Uint8Array || a instanceof Uint8ClampedArray || a instanceof Uint16Array || a instanceof Uint32Array || a instanceof Float32Array || a instanceof Float64Array
            };
            f.$WorkerFuncChannel7 = function(a) {
                if (typeof a === "function") return "function";
                if (a === null) return "raw";
                if (typeof a !== "object") return "raw";
                if (Array.isArray(a)) return "raw";
                if (this.$WorkerFuncChannel6(a)) return "raw";
                var b = a.constructor.name;
                if (this.$WorkerFuncChannel4[b]) return "custom";
                return a instanceof Error ? "error" : "object"
            };
            f.$WorkerFuncChannel8 = function(a, b) {
                var c = this.$WorkerFuncChannel7(a);
                return this.$WorkerFuncChannel5[c].serialize(a, b)
            };
            f.$WorkerFuncChannel9 = function(a) {
                var b = a;
                if (a !== null && typeof a === "object" && typeof a.type === "string") {
                    var c = this.$WorkerFuncChannel5[a.type];
                    if (c) return c.deserialize(a)
                }
                return b
            };
            f.__onPostOutMessage = function(a) {
                return a
            };
            f.__callCallback = function(a, b) {
                a.apply(null, b.argList)
            };
            f.setOutMessagePort = function(a, d) {
                var e = this,
                    f = [];
                this.setCallMessageHandler(function(d) {
                    d.thisArg = e.name;
                    var g = [];
                    d.argList = d.argList.map(function(a) {
                        return e.$WorkerFuncChannel8(a, g)
                    });
                    var h = new(i || (i = b("Promise")))(function(a, b) {
                            d.result = {
                                resolveFunc: e.$WorkerFuncChannel8(a, g),
                                rejectFunc: e.$WorkerFuncChannel8(b, g)
                            }
                        }),
                        j = e.__onPostOutMessage(d);
                    j != null && (f != null ? f.push({
                        message: d,
                        transferList: g
                    }) : a.postMessage(d, g));
                    h["catch"](function(a) {
                        c("FBLogger")("worker").catching(a).mustfix("Error: channel %s, remote call of %s returned error %s", e.name, d.method, a.message)
                    });
                    return h
                });
                c("promiseDone")(d || x.waitForRemote(this.name), function() {
                    var b = f;
                    f = null;
                    b == null ? void 0 : b.forEach(function(b) {
                        a.postMessage(b.message, b.transferList)
                    });
                    e.$WorkerFuncChannel3 == null ? void 0 : e.$WorkerFuncChannel3()
                })
            };
            f.__messageToCall = function(a) {
                var b = this;
                a.argList = a.argList.map(function(a) {
                    return b.$WorkerFuncChannel9(a)
                });
                if (a.result) {
                    var d = a.result,
                        e = d.resolveFunc;
                    d = d.rejectFunc;
                    e = this.$WorkerFuncChannel9(e);
                    d = this.$WorkerFuncChannel9(d);
                    a.result = {
                        resolveFunc: e,
                        rejectFunc: d
                    }
                }
                e = a.id;
                if (e === void 0) this.messageToCall(a);
                else {
                    d = this.$WorkerFuncChannel1.get(e);
                    d ? this.__callCallback(d, a) : c("FBLogger")("adsworker").mustfix("Error: callback is called but no longer available")
                }
            };
            f.setInMessagePort = function(a) {
                var b = this;
                a.addMessageListener("call", function(a) {
                    typeof a.thisArg === "string" && a.thisArg === b.name && b.__messageToCall(a)
                });
                x.notifyReady(this.name)
            };
            f.setMessagePort = function(a) {
                this.setInMessagePort(a);
                this.setOutMessagePort(a);
                return this
            };
            return a
        }(c("FuncChannel")),
        r = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a() {
                return b.apply(this, arguments) || this
            }
            return a
        }(d("WorkerMessagePort").WorkerMessagePort);

    function s(a, b, d, e) {
        x.exportChannel(a, function(e) {
            var f = e.syncPort;
            e = e.remoteNativePort;
            var g = b();
            a === g.name || h(0, 54247, a, g.name);
            var i;
            e ? (i = new r(e, f.name + "(" + g.name + ")"), e.start(), i.onError.add(function(a) {
                c("FBLogger")("worker").catching(a).mustfix("error caught in remotePort");
                throw a
            })) : i = f;
            g.setMessagePort(i).setBackend(d);
            c("promiseDone")(f.fullyConnected, function() {
                f.postMessage({
                    type: "channelReady",
                    channelName: g.name
                }), x.logState("EXPORTED", a)
            })
        })
    }

    function a(a, b, c, d) {
        d === void 0 && (d = {});
        return s(c, function() {
            return new q(function(b) {
                return a
            }, c, null, d)
        }, a, b)
    }
    var t = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a(a, e) {
            e === void 0 && (e = "");
            var f = d("DateConsts").MS_PER_MIN * 1;
            return b.call(this, function() {
                c("FBLogger")("worker").warn("Channel %s did not establish eventually. %s", a, e)
            }, f) || this
        }
        return a
    }(d("TimedOnceFunc").TimedOnceFunc);

    function u(a, b) {
        var e, f = null,
            g, h;
        b.isWrappingVirtualMessagePort() ? (h = new(d("VirtualMessageChannel").VirtualMessageChannel)(!0, !0), e = "on virtual dedicated channel") : (h = new MessageChannel(), e = "on native dedicated channel", g = [h.port2]);
        var i = h.port1;
        f = h.port2;
        i.start();
        var j = new r(i, b.name + "(" + a.name + ")");
        c("promiseDone")(b.fullyConnected, function() {
            x.logState("IMPORTING " + e + " ", a.name);
            a.setInMessagePort(j);
            var d = new t(a.name, e);
            c("promiseDone")(b.onMessageOnce("channelReady", function(b) {
                return b.channelName === a.name
            }), function(b) {
                a.setOutMessagePort(j), d.cancel(), x.logState("ESTABLISHED", a.name)
            });
            b.postMessage({
                type: "channelImport",
                channelName: a.name,
                port: f
            }, g)
        });
        return a.proxyMethods
    }

    function v(a, b, c, d) {
        c === void 0 && (c = null);
        d === void 0 && (d = {});
        b = new q(function(b) {
            return a
        }, b, c, d);
        return b
    }

    function e(a, b, c, d, e) {
        d === void 0 && (d = null);
        e === void 0 && (e = {});
        return u(v(a, c, d, e), b)
    }
    var w = function() {
            function a() {
                this.name = self.name + "_P" + Math.round(10 * Math.random()), this.$1 = new Map(), this.$2 = new Set()
            }
            var e = a.prototype;
            e.logState = function(a, b) {
                d("MainPageUrl").isWorkerLogEnabled() && c("FBLogger")("worker").debug("%s-%s %s", this.name, a, b)
            };
            e.$3 = function(a) {
                var b = this.$1.get(a);
                b == null && (b = {
                    pendingPorts: null,
                    onImportRequest: null
                }, this.$1.set(a, b));
                return b
            };
            e.exportChannel = function(a, b) {
                var d = this,
                    e = this.$3(a);
                e.onImportRequest != null && c("FBLogger")("worker").debug("Re-exporting channel %s", a);
                e.onImportRequest = b;
                this.logState("REGISTERED", a);
                a = e.pendingPorts;
                if (a != null) {
                    var f = a.filter(function(a) {
                        return d.$2.has(a.syncPort)
                    });
                    f.forEach(b);
                    f.length < a.length ? e.pendingPorts = a.filter(function(a) {
                        return !d.$2.has(a.syncPort)
                    }) : e.pendingPorts = null
                }
                return e
            };
            e.activate = function(a, b, d) {
                var e = this;
                if (this.$2.has(a)) {
                    c("FBLogger")("worker").debug("Port %sis already duplicated ", a.name);
                    return
                }
                this.$2.add(a);
                a.addMessageListener("channelImport", function(b) {
                    var c = b.channelName,
                        d = e.$3(c);
                    b = {
                        syncPort: a,
                        remoteNativePort: b.port
                    };
                    d.onImportRequest != null ? d.onImportRequest(b) : d.pendingPorts != null ? d.pendingPorts.push(b) : d.pendingPorts = [b];
                    e.logState("IMPORT REQUEST", c)
                })
            };
            e.notifyReady = function(a) {};
            e.waitForRemote = function(a) {
                return (i || (i = b("Promise"))).resolve()
            };
            return a
        }(),
        x = new w();

    function f(a, b, c) {
        x.activate(a, b, c)
    }
    g.TransferableTransformer = k;
    g.WorkerFuncChannel = q;
    g.exportChannelOnPort = s;
    g.exportChannel = a;
    g.importChannelOnPort = u;
    g.makeChannel = v;
    g.importChannel = e;
    g.activateChannels = f
}), 98);
__d("WorkerQPLChannel", ["WorkerFuncChannel", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new(d("WorkerFuncChannel").WorkerFuncChannel)(function(a) {
        return {
            markerStartFromNavStart: null,
            markerStart: function(b, d, e) {
                e === void 0 && (e = (h || (h = c("performanceAbsoluteNow")))());
                return a.markerStart(b, d, e)
            },
            markerAnnotate: function(b, c, d) {
                return a.markerAnnotate(b, c, d)
            },
            markerPoint: function(b, d, e) {
                e = (e == null ? void 0 : e.timestamp) === void 0 ? babelHelpers["extends"]({}, e, {
                    timestamp: (h || (h = c("performanceAbsoluteNow")))()
                }) : e;
                return a.markerPoint(b, d, e)
            },
            markerEnd: function(b, d, e, f) {
                f === void 0 && (f = (h || (h = c("performanceAbsoluteNow")))());
                return a.markerEnd(b, d, e, f)
            }
        }
    }, "qpl");

    function a(a) {
        i.setMessagePort(a)
    }

    function b(a) {
        i.setBackend(a)
    }
    g.setMessagePort = a;
    g.initQPL = b
}), 98); /*FB_PKG_DELIM*/
/**
 * License: https://www.facebook.com/legal/license/t3hOLs8wlXy/
 */
__d("minisearch-3.0.2", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {},
        h = {
            exports: g
        };

    function i() {
        (function(b, c) {
            typeof g === "object" && typeof h !== "undefined" ? h.exports = c() : (b = typeof globalThis !== "undefined" ? globalThis : b || self, b.MiniSearch = c())
        })(this, function() {
            var a = function() {
                a = Object.assign || function(a) {
                    for (var b, c = 1, d = arguments.length; c < d; c++) {
                        b = arguments[c];
                        for (var e in b) Object.prototype.hasOwnProperty.call(b, e) && (a[e] = b[e])
                    }
                    return a
                };
                return a.apply(this, arguments)
            };

            function b(a) {
                var b = typeof Symbol === "function" && Symbol.iterator,
                    c = b && a[b],
                    d = 0;
                if (c) return c.call(a);
                if (a && typeof a.length === "number") return {
                    next: function() {
                        a && d >= a.length && (a = void 0);
                        return {
                            value: a && a[d++],
                            done: !a
                        }
                    }
                };
                throw new TypeError(b ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }

            function c(a, b) {
                var c = typeof Symbol === "function" && a[Symbol.iterator];
                if (!c) return a;
                a = c.call(a);
                var d, e = [],
                    f;
                try {
                    while ((b === void 0 || b-- > 0) && !(d = a.next()).done) e.push(d.value)
                } catch (a) {
                    f = {
                        error: a
                    }
                } finally {
                    try {
                        d && !d.done && (c = a["return"]) && c.call(a)
                    } finally {
                        if (f) throw f.error
                    }
                }
                return e
            }

            function d() {
                for (var a = [], b = 0; b < arguments.length; b++) a = a.concat(c(arguments[b]));
                return a
            }
            var e = "ENTRIES",
                f = "KEYS",
                g = "VALUES",
                h = "",
                i = function() {
                    function a(a, b) {
                        var c = a._tree,
                            d = Object.keys(c);
                        this.set = a;
                        this._type = b;
                        this._path = d.length > 0 ? [{
                            node: c,
                            keys: d
                        }] : []
                    }
                    a.prototype.next = function() {
                        var a = this.dive();
                        this.backtrack();
                        return a
                    };
                    a.prototype.dive = function() {
                        if (this._path.length === 0) return {
                            done: !0,
                            value: void 0
                        };
                        var a = j(this._path),
                            b = a.node;
                        a = a.keys;
                        if (j(a) === h) return {
                            done: !1,
                            value: this.result()
                        };
                        this._path.push({
                            node: b[j(a)],
                            keys: Object.keys(b[j(a)])
                        });
                        return this.dive()
                    };
                    a.prototype.backtrack = function() {
                        if (this._path.length === 0) return;
                        j(this._path).keys.pop();
                        if (j(this._path).keys.length > 0) return;
                        this._path.pop();
                        this.backtrack()
                    };
                    a.prototype.key = function() {
                        return this.set._prefix + this._path.map(function(a) {
                            a = a.keys;
                            return j(a)
                        }).filter(function(a) {
                            return a !== h
                        }).join("")
                    };
                    a.prototype.value = function() {
                        return j(this._path).node[h]
                    };
                    a.prototype.result = function() {
                        if (this._type === g) return this.value();
                        return this._type === f ? this.key() : [this.key(), this.value()]
                    };
                    a.prototype[Symbol.iterator] = function() {
                        return this
                    };
                    return a
                }(),
                j = function(a) {
                    return a[a.length - 1]
                },
                k = 0,
                l = 1,
                m = 2,
                n = 3,
                o = function(a, b, d) {
                    var e = [{
                            distance: 0,
                            i: 0,
                            key: "",
                            node: a
                        }],
                        f = {},
                        g = [];
                    a = function() {
                        var a = e.pop(),
                            i = a.node,
                            j = a.distance,
                            k = a.key,
                            l = a.i,
                            m = a.edit;
                        Object.keys(i).forEach(function(n) {
                            if (n === h) {
                                var o = j + (b.length - l),
                                    a = c(f[k] || [null, Infinity], 2);
                                a = a[1];
                                o <= d && o < a && (f[k] = [i[n], o])
                            } else p(b, n, d - j, l, m, g).forEach(function(a) {
                                var c = a.distance,
                                    b = a.i;
                                a = a.edit;
                                e.push({
                                    node: i[n],
                                    distance: j + c,
                                    key: k + n,
                                    i: b,
                                    edit: a
                                })
                            })
                        })
                    };
                    while (e.length > 0) a();
                    return f
                },
                p = function(a, b, c, d, e, f) {
                    f.push({
                        distance: 0,
                        ia: d,
                        ib: 0,
                        edit: e
                    });
                    d = [];
                    while (f.length > 0) {
                        e = f.pop();
                        var g = e.distance,
                            h = e.ia,
                            i = e.ib;
                        e = e.edit;
                        if (i === b.length) {
                            d.push({
                                distance: g,
                                i: h,
                                edit: e
                            });
                            continue
                        }
                        if (a[h] === b[i]) f.push({
                            distance: g,
                            ia: h + 1,
                            ib: i + 1,
                            edit: k
                        });
                        else {
                            if (g >= c) continue;
                            e !== m && f.push({
                                distance: g + 1,
                                ia: h,
                                ib: i + 1,
                                edit: n
                            });
                            h < a.length && (e !== n && f.push({
                                distance: g + 1,
                                ia: h + 1,
                                ib: i,
                                edit: m
                            }), e !== n && e !== m && f.push({
                                distance: g + 1,
                                ia: h + 1,
                                ib: i + 1,
                                edit: l
                            }))
                        }
                    }
                    return d
                },
                q = function() {
                    function a(a, b) {
                        a === void 0 && (a = {}), b === void 0 && (b = ""), this._tree = a, this._prefix = b
                    }
                    a.prototype.atPrefix = function(d) {
                        var b;
                        if (!d.startsWith(this._prefix)) throw new Error("Mismatched prefix");
                        var e = c(r(this._tree, d.slice(this._prefix.length)), 2),
                            f = e[0];
                        e = e[1];
                        if (f === void 0) {
                            e = c(y(e), 2);
                            var g = e[0],
                                i = e[1];
                            e = Object.keys(g).find(function(a) {
                                return a !== h && a.startsWith(i)
                            });
                            if (e !== void 0) return new a((b = {}, b[e.slice(i.length)] = g[e], b), d)
                        }
                        return new a(f || {}, d)
                    };
                    a.prototype.clear = function() {
                        delete this._size, this._tree = {}
                    };
                    a.prototype["delete"] = function(a) {
                        delete this._size;
                        return v(this._tree, a)
                    };
                    a.prototype.entries = function() {
                        return new i(this, e)
                    };
                    a.prototype.forEach = function(d) {
                        var e, a;
                        try {
                            for (var f = b(this), g = f.next(); !g.done; g = f.next()) {
                                var h = c(g.value, 2),
                                    i = h[0];
                                h = h[1];
                                d(i, h, this)
                            }
                        } catch (a) {
                            e = {
                                error: a
                            }
                        } finally {
                            try {
                                g && !g.done && (a = f["return"]) && a.call(f)
                            } finally {
                                if (e) throw e.error
                            }
                        }
                    };
                    a.prototype.fuzzyGet = function(a, b) {
                        return o(this._tree, a, b)
                    };
                    a.prototype.get = function(a) {
                        a = s(this._tree, a);
                        return a !== void 0 ? a[h] : void 0
                    };
                    a.prototype.has = function(a) {
                        a = s(this._tree, a);
                        return a !== void 0 && a.hasOwnProperty(h)
                    };
                    a.prototype.keys = function() {
                        return new i(this, f)
                    };
                    a.prototype.set = function(a, b) {
                        if (typeof a !== "string") throw new Error("key must be a string");
                        delete this._size;
                        a = t(this._tree, a);
                        a[h] = b;
                        return this
                    };
                    Object.defineProperty(a.prototype, "size", {
                        get: function() {
                            var a = this;
                            if (this._size) return this._size;
                            this._size = 0;
                            this.forEach(function() {
                                a._size += 1
                            });
                            return this._size
                        },
                        enumerable: !1,
                        configurable: !0
                    });
                    a.prototype.update = function(a, b) {
                        if (typeof a !== "string") throw new Error("key must be a string");
                        delete this._size;
                        a = t(this._tree, a);
                        a[h] = b(a[h]);
                        return this
                    };
                    a.prototype.values = function() {
                        return new i(this, g)
                    };
                    a.prototype[Symbol.iterator] = function() {
                        return this.entries()
                    };
                    a.from = function(e) {
                        var f, d, g = new a();
                        try {
                            for (var h = b(e), i = h.next(); !i.done; i = h.next()) {
                                e = c(i.value, 2);
                                var j = e[0];
                                e = e[1];
                                g.set(j, e)
                            }
                        } catch (a) {
                            f = {
                                error: a
                            }
                        } finally {
                            try {
                                i && !i.done && (d = h["return"]) && d.call(h)
                            } finally {
                                if (f) throw f.error
                            }
                        }
                        return g
                    };
                    a.fromObject = function(b) {
                        return a.from(Object.entries(b))
                    };
                    return a
                }(),
                r = function(a, b, c) {
                    c === void 0 && (c = []);
                    if (b.length === 0 || a == null) return [a, c];
                    var d = Object.keys(a).find(function(a) {
                        return a !== h && b.startsWith(a)
                    });
                    if (d === void 0) {
                        c.push([a, b]);
                        return r(void 0, "", c)
                    }
                    c.push([a, d]);
                    return r(a[d], b.slice(d.length), c)
                },
                s = function(a, b) {
                    if (b.length === 0 || a == null) return a;
                    var c = Object.keys(a).find(function(a) {
                        return a !== h && b.startsWith(a)
                    });
                    return c === void 0 ? void 0 : s(a[c], b.slice(c.length))
                },
                t = function(b, c) {
                    var a;
                    if (c.length === 0 || b == null) return b;
                    var d = Object.keys(b).find(function(a) {
                        return a !== h && c.startsWith(a)
                    });
                    if (d === void 0) {
                        var e = Object.keys(b).find(function(a) {
                            return a !== h && a.startsWith(c[0])
                        });
                        if (e === void 0) b[c] = {};
                        else {
                            var f = u(c, e);
                            b[f] = (a = {}, a[e.slice(f.length)] = b[e], a);
                            delete b[e];
                            return t(b[f], c.slice(f.length))
                        }
                        return b[c]
                    }
                    return t(b[d], c.slice(d.length))
                },
                u = function(a, b, c, d, e) {
                    c === void 0 && (c = 0);
                    d === void 0 && (d = Math.min(a.length, b.length));
                    e === void 0 && (e = "");
                    if (c >= d) return e;
                    return a[c] !== b[c] ? e : u(a, b, c + 1, d, e + a[c])
                },
                v = function(a, b) {
                    a = c(r(a, b), 2);
                    b = a[0];
                    a = a[1];
                    if (b === void 0) return;
                    delete b[h];
                    var d = Object.keys(b);
                    d.length === 0 && w(a);
                    d.length === 1 && x(a, d[0], b[d[0]])
                },
                w = function(b) {
                    if (b.length === 0) return;
                    var a = c(y(b), 2),
                        d = a[0];
                    a = a[1];
                    delete d[a];
                    Object.keys(d).length === 0 && w(b.slice(0, -1))
                },
                x = function(a, b, d) {
                    if (a.length === 0) return;
                    a = c(y(a), 2);
                    var e = a[0];
                    a = a[1];
                    e[a + b] = d;
                    delete e[a]
                },
                y = function(a) {
                    return a[a.length - 1]
                },
                z, A = "or",
                B = "and",
                C = function() {
                    function b(b) {
                        if ((b === null || b === void 0 ? void 0 : b.fields) == null) throw new Error('MiniSearch: option "fields" must be provided');
                        this._options = a(a(a({}, J), b), {
                            searchOptions: a(a({}, K), b.searchOptions || {})
                        });
                        this._index = new q();
                        this._documentCount = 0;
                        this._documentIds = {};
                        this._fieldIds = {};
                        this._fieldLength = {};
                        this._averageFieldLength = {};
                        this._nextId = 0;
                        this._storedFields = {};
                        this.addFields(this._options.fields)
                    }
                    b.prototype.add = function(b) {
                        var c = this,
                            a = this._options,
                            d = a.extractField,
                            e = a.tokenize,
                            f = a.processTerm,
                            g = a.fields;
                        a = a.idField;
                        var h = d(b, a);
                        if (h == null) throw new Error('MiniSearch: document does not have ID field "' + a + '"');
                        var i = this.addDocumentId(h);
                        this.saveStoredFields(i, b);
                        g.forEach(function(a) {
                            var g = d(b, a);
                            if (g == null) return;
                            g = e(g.toString(), a);
                            c.addFieldLength(i, c._fieldIds[a], c.documentCount - 1, g.length);
                            g.forEach(function(b) {
                                b = f(b, a);
                                b && c.addTerm(c._fieldIds[a], i, b)
                            })
                        })
                    };
                    b.prototype.addAll = function(a) {
                        var b = this;
                        a.forEach(function(a) {
                            return b.add(a)
                        })
                    };
                    b.prototype.addAllAsync = function(a, b) {
                        var c = this;
                        b === void 0 && (b = {});
                        b = b.chunkSize;
                        var d = b === void 0 ? 10 : b;
                        b = {
                            chunk: [],
                            promise: Promise.resolve()
                        };
                        a = a.reduce(function(a, e, f) {
                            var b = a.chunk;
                            a = a.promise;
                            b.push(e);
                            if ((f + 1) % d === 0) return {
                                chunk: [],
                                promise: a.then(function() {
                                    return new Promise(function(a) {
                                        return setTimeout(a, 0)
                                    })
                                }).then(function() {
                                    return c.addAll(b)
                                })
                            };
                            else return {
                                chunk: b,
                                promise: a
                            }
                        }, b);
                        var e = a.chunk;
                        b = a.promise;
                        return b.then(function() {
                            return c.addAll(e)
                        })
                    };
                    b.prototype.remove = function(b) {
                        var d = this,
                            a = this._options,
                            e = a.tokenize,
                            f = a.processTerm,
                            g = a.extractField,
                            h = a.fields;
                        a = a.idField;
                        var i = g(b, a);
                        if (i == null) throw new Error('MiniSearch: document does not have ID field "' + a + '"');
                        a = c(Object.entries(this._documentIds).find(function(a) {
                            a = c(a, 2);
                            a[0];
                            a = a[1];
                            return i === a
                        }) || [], 1);
                        var j = a[0];
                        if (j == null) throw new Error("MiniSearch: cannot remove document with ID " + i + ": it is not in the index");
                        h.forEach(function(a) {
                            var c = g(b, a);
                            if (c == null) return;
                            c = e(c.toString(), a);
                            c.forEach(function(b) {
                                b = f(b, a);
                                b && d.removeTerm(d._fieldIds[a], j, b)
                            })
                        });
                        delete this._storedFields[j];
                        delete this._documentIds[j];
                        this._documentCount -= 1
                    };
                    b.prototype.removeAll = function(a) {
                        var b = this;
                        if (a) a.forEach(function(a) {
                            return b.remove(a)
                        });
                        else if (arguments.length > 0) throw new Error("Expected documents to be present. Omit the argument to remove all documents.");
                        else this._index = new q(), this._documentCount = 0, this._documentIds = {}, this._fieldLength = {}, this._averageFieldLength = {}, this._storedFields = {}, this._nextId = 0
                    };
                    b.prototype.search = function(d, e) {
                        var f = this;
                        e === void 0 && (e = {});
                        var b = this._options,
                            g = b.tokenize,
                            h = b.processTerm;
                        b = b.searchOptions;
                        var i = a(a({
                            tokenize: g,
                            processTerm: h
                        }, b), e);
                        g = i.tokenize;
                        var j = i.processTerm;
                        h = g(d).map(function(a) {
                            return j(a)
                        }).filter(function(a) {
                            return !!a
                        });
                        b = h.map(H(i));
                        e = b.map(function(a) {
                            return f.executeQuery(a, i)
                        });
                        g = this.combineResults(e, i.combineWith);
                        return Object.entries(g).reduce(function(d, a) {
                            a = c(a, 2);
                            var e = a[0];
                            a = a[1];
                            var b = a.score,
                                g = a.match;
                            a = a.terms;
                            a = {
                                id: f._documentIds[e],
                                terms: I(a),
                                score: b,
                                match: g
                            };
                            Object.assign(a, f._storedFields[e]);
                            (i.filter == null || i.filter(a)) && d.push(a);
                            return d
                        }, []).sort(function(a, b) {
                            a = a.score;
                            b = b.score;
                            return a < b ? 1 : -1
                        })
                    };
                    b.prototype.autoSuggest = function(b, d) {
                        d === void 0 && (d = {});
                        d = a(a({}, L), d);
                        b = this.search(b, d).reduce(function(c, a) {
                            var b = a.score;
                            a = a.terms;
                            var d = a.join(" ");
                            c[d] == null ? c[d] = {
                                score: b,
                                terms: a,
                                count: 1
                            } : (c[d].score += b, c[d].count += 1);
                            return c
                        }, {});
                        return Object.entries(b).map(function(a) {
                            a = c(a, 2);
                            var d = a[0];
                            a = a[1];
                            var b = a.score,
                                e = a.terms;
                            a = a.count;
                            return {
                                suggestion: d,
                                terms: e,
                                score: b / a
                            }
                        }).sort(function(a, b) {
                            a = a.score;
                            b = b.score;
                            return a < b ? 1 : -1
                        })
                    };
                    Object.defineProperty(b.prototype, "documentCount", {
                        get: function() {
                            return this._documentCount
                        },
                        enumerable: !1,
                        configurable: !0
                    });
                    b.loadJSON = function(a, c) {
                        if (c == null) throw new Error("MiniSearch: loadJSON should be given the same options used when serializing the index");
                        return b.loadJS(JSON.parse(a), c)
                    };
                    b.getDefault = function(a) {
                        if (J.hasOwnProperty(a)) return D(J, a);
                        else throw new Error('MiniSearch: unknown option "' + a + '"')
                    };
                    b.loadJS = function(a, c) {
                        var d = a.index,
                            e = a.documentCount,
                            f = a.nextId,
                            g = a.documentIds,
                            h = a.fieldIds,
                            i = a.fieldLength,
                            j = a.averageFieldLength;
                        a = a.storedFields;
                        c = new b(c);
                        c._index = new q(d._tree, d._prefix);
                        c._documentCount = e;
                        c._nextId = f;
                        c._documentIds = g;
                        c._fieldIds = h;
                        c._fieldLength = i;
                        c._averageFieldLength = j;
                        c._fieldIds = h;
                        c._storedFields = a || {};
                        return c
                    };
                    b.prototype.executeQuery = function(b, d) {
                        var e = this;
                        d = a(a({}, this._options.searchOptions), d);
                        var f = (d.fields || this._options.fields).reduce(function(c, d) {
                                var b;
                                return a(a({}, c), (b = {}, b[d] = D(c, d) || 1, b))
                            }, d.boost || {}),
                            g = d.boostDocument;
                        d = d.weights;
                        d = a(a({}, K.weights), d);
                        var h = d.fuzzy,
                            i = d.prefix;
                        d = this.termResults(b.term, f, g, this._index.get(b.term));
                        if (!b.fuzzy && !b.prefix) return d;
                        var j = [d];
                        b.prefix && this._index.atPrefix(b.term).forEach(function(a, c) {
                            var d = .3 * (a.length - b.term.length) / a.length;
                            j.push(e.termResults(a, f, g, c, i, d))
                        });
                        if (b.fuzzy) {
                            d = b.fuzzy === !0 ? .2 : b.fuzzy;
                            d = d < 1 ? Math.round(b.term.length * d) : d;
                            Object.entries(this._index.fuzzyGet(b.term, d)).forEach(function(a) {
                                a = c(a, 2);
                                var b = a[0];
                                a = c(a[1], 2);
                                var d = a[0];
                                a = a[1];
                                a = a / b.length;
                                j.push(e.termResults(b, f, g, d, h, a))
                            })
                        }
                        return j.reduce(E[A], {})
                    };
                    b.prototype.combineResults = function(a, b) {
                        b === void 0 && (b = A);
                        if (a.length === 0) return {};
                        b = b.toLowerCase();
                        return a.reduce(E[b], null) || {}
                    };
                    b.prototype.toJSON = function() {
                        return {
                            index: this._index,
                            documentCount: this._documentCount,
                            nextId: this._nextId,
                            documentIds: this._documentIds,
                            fieldIds: this._fieldIds,
                            fieldLength: this._fieldLength,
                            averageFieldLength: this._averageFieldLength,
                            storedFields: this._storedFields
                        }
                    };
                    b.prototype.termResults = function(a, b, d, e, f, g) {
                        var h = this;
                        g === void 0 && (g = 0);
                        return e == null ? {} : Object.entries(b).reduce(function(f, b) {
                            b = c(b, 2);
                            var i = b[0],
                                j = b[1],
                                k = h._fieldIds[i];
                            b = e[k] || {
                                ds: {}
                            };
                            var l = b.df;
                            b = b.ds;
                            Object.entries(b).forEach(function(b) {
                                b = c(b, 2);
                                var e = b[0];
                                b = b[1];
                                var m = d ? d(h._documentIds[e], a) : 1;
                                if (!m) return;
                                var n = h._fieldLength[e][k] / h._averageFieldLength[k];
                                f[e] = f[e] || {
                                    score: 0,
                                    match: {},
                                    terms: []
                                };
                                f[e].terms.push(a);
                                f[e].match[a] = D(f[e].match, a) || [];
                                f[e].score += m * G(b, l, h._documentCount, n, j, g);
                                f[e].match[a].push(i)
                            });
                            return f
                        }, {})
                    };
                    b.prototype.addTerm = function(b, c, d) {
                        this._index.update(d, function(d) {
                            d = d || {};
                            var e = d[b] || {
                                df: 0,
                                ds: {}
                            };
                            e.ds[c] == null && (e.df += 1);
                            e.ds[c] = (e.ds[c] || 0) + 1;
                            return a(a({}, d), (d = {}, d[b] = e, d))
                        })
                    };
                    b.prototype.removeTerm = function(b, c, d) {
                        var e = this;
                        if (!this._index.has(d)) {
                            this.warnDocumentChanged(c, b, d);
                            return
                        }
                        this._index.update(d, function(f) {
                            var g = f[b];
                            if (g == null || g.ds[c] == null) {
                                e.warnDocumentChanged(c, b, d);
                                return f
                            }
                            if (g.ds[c] <= 1) {
                                if (g.df <= 1) {
                                    delete f[b];
                                    return f
                                }
                                g.df -= 1
                            }
                            if (g.ds[c] <= 1) {
                                delete g.ds[c];
                                return f
                            }
                            g.ds[c] -= 1;
                            return a(a({}, f), (f = {}, f[b] = g, f))
                        });
                        Object.keys(this._index.get(d)).length === 0 && this._index["delete"](d)
                    };
                    b.prototype.warnDocumentChanged = function(a, b, d) {
                        if (console == null || emptyFunction == null) return;
                        a = Object.entries(this._fieldIds).find(function(a) {
                            a = c(a, 2);
                            a[0];
                            a = a[1];
                            return a === b
                        })[0]
                    };
                    b.prototype.addDocumentId = function(a) {
                        var b = this._nextId.toString(36);
                        this._documentIds[b] = a;
                        this._documentCount += 1;
                        this._nextId += 1;
                        return b
                    };
                    b.prototype.addFields = function(a) {
                        var b = this;
                        a.forEach(function(a, c) {
                            b._fieldIds[a] = c
                        })
                    };
                    b.prototype.addFieldLength = function(a, b, c, d) {
                        this._averageFieldLength[b] = this._averageFieldLength[b] || 0;
                        var e = this._averageFieldLength[b] * c + d;
                        this._fieldLength[a] = this._fieldLength[a] || {};
                        this._fieldLength[a][b] = d;
                        this._averageFieldLength[b] = e / (c + 1)
                    };
                    b.prototype.saveStoredFields = function(b, c) {
                        var d = this,
                            a = this._options,
                            e = a.storeFields,
                            f = a.extractField;
                        if (e == null || e.length === 0) return;
                        this._storedFields[b] = this._storedFields[b] || {};
                        e.forEach(function(a) {
                            var e = f(c, a);
                            if (e === void 0) return;
                            d._storedFields[b][a] = e
                        })
                    };
                    return b
                }(),
                D = function(a, b) {
                    return Object.prototype.hasOwnProperty.call(a, b) ? a[b] : void 0
                },
                E = (z = {}, z[A] = function(a, b) {
                    return Object.entries(b).reduce(function(e, a) {
                        a = c(a, 2);
                        var f = a[0];
                        a = a[1];
                        var b = a.score,
                            g = a.match;
                        a = a.terms;
                        e[f] == null ? e[f] = {
                            score: b,
                            match: g,
                            terms: a
                        } : (e[f].score += b, e[f].score *= 1.5, (b = e[f].terms).push.apply(b, d(a)), Object.assign(e[f].match, g));
                        return e
                    }, a || {})
                }, z[B] = function(b, e) {
                    return b == null ? e : Object.entries(e).reduce(function(g, e) {
                        e = c(e, 2);
                        var h = e[0];
                        e = e[1];
                        var f = e.score,
                            i = e.match;
                        e = e.terms;
                        if (b[h] === void 0) return g;
                        g[h] = g[h] || {};
                        g[h].score = b[h].score + f;
                        g[h].match = a(a({}, b[h].match), i);
                        g[h].terms = d(b[h].terms, e);
                        return g
                    }, {})
                }, z),
                F = function(a, b, c) {
                    return a * Math.log(c / b)
                },
                G = function(a, b, c, d, e, f) {
                    e = e / (1 + .333 * e * f);
                    return e * F(a, b, c) / d
                },
                H = function(a) {
                    return function(b, c, d) {
                        var e = typeof a.fuzzy === "function" ? a.fuzzy(b, c, d) : a.fuzzy || !1;
                        c = typeof a.prefix === "function" ? a.prefix(b, c, d) : a.prefix === !0;
                        return {
                            term: b,
                            fuzzy: e,
                            prefix: c
                        }
                    }
                },
                I = function(a) {
                    return a.filter(function(b, c, a) {
                        return a.indexOf(b) === c
                    })
                },
                J = {
                    idField: "id",
                    extractField: function(a, b) {
                        return a[b]
                    },
                    tokenize: function(a, b) {
                        return a.split(M)
                    },
                    processTerm: function(a, b) {
                        return a.toLowerCase()
                    },
                    fields: void 0,
                    searchOptions: void 0,
                    storeFields: []
                },
                K = {
                    combineWith: A,
                    prefix: !1,
                    fuzzy: !1,
                    boost: {},
                    weights: {
                        fuzzy: .9,
                        prefix: .75
                    }
                },
                L = {
                    prefix: function(a, b, c) {
                        return b === c.length - 1
                    }
                },
                M = /[\n\r -#%-*,-/:;?@[-\]_{}\u00A0\u00A1\u00A7\u00AB\u00B6\u00B7\u00BB\u00BF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u09FD\u0A76\u0AF0\u0C77\u0C84\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166E\u1680\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2000-\u200A\u2010-\u2029\u202F-\u2043\u2045-\u2051\u2053-\u205F\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E4F\u3000-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]+/u;
            return C
        })
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }

    function a(a) {
        switch (a) {
            case void 0:
                return k()
        }
    }
    e.exports = a
}), null);
__d("minisearch", ["minisearch-3.0.2"], (function(a, b, c, d, e, f) {
    e.exports = b("minisearch-3.0.2")()
}), null);
/**
 * License: https://www.facebook.com/legal/license/CCT5pM3qiNk/
 */
__d("tweetnacl-util-0.15.1", [], (function(a, b, c, d, e, f) {
    "use strict";
    b = {};
    var g = {
        exports: b
    };

    function h() {
        (function(a, b) {
            typeof g !== "undefined" && g.exports ? g.exports = b() : a.nacl ? a.nacl.util = b() : (a.nacl = {}, a.nacl.util = b())
        })(this, function() {
            var a = {};

            function b(a) {
                if (!/^(?:[A-Za-z0-9+\/]{2}[A-Za-z0-9+\/]{2})*(?:[A-Za-z0-9+\/]{2}==|[A-Za-z0-9+\/]{3}=)?$/.test(a)) throw new TypeError("invalid encoding")
            }
            a.decodeUTF8 = function(a) {
                if (typeof a !== "string") throw new TypeError("expected string");
                var b;
                a = unescape(encodeURIComponent(a));
                var c = new Uint8Array(a.length);
                for (b = 0; b < a.length; b++) c[b] = a.charCodeAt(b);
                return c
            };
            a.encodeUTF8 = function(a) {
                var b, c = [];
                for (b = 0; b < a.length; b++) c.push(String.fromCharCode(a[b]));
                return decodeURIComponent(escape(c.join("")))
            };
            typeof atob === "undefined" ? typeof Buffer.from !== "undefined" ? (a.encodeBase64 = function(a) {
                return Buffer.from(a).toString("base64")
            }, a.decodeBase64 = function(a) {
                b(a);
                return new Uint8Array(Array.prototype.slice.call(Buffer.from(a, "base64"), 0))
            }) : (a.encodeBase64 = function(a) {
                return new Buffer(a).toString("base64")
            }, a.decodeBase64 = function(a) {
                b(a);
                return new Uint8Array(Array.prototype.slice.call(new Buffer(a, "base64"), 0))
            }) : (a.encodeBase64 = function(a) {
                var b, c = [],
                    d = a.length;
                for (b = 0; b < d; b++) c.push(String.fromCharCode(a[b]));
                return btoa(c.join(""))
            }, a.decodeBase64 = function(a) {
                b(a);
                var c;
                a = atob(a);
                var d = new Uint8Array(a.length);
                for (c = 0; c < a.length; c++) d[c] = a.charCodeAt(c);
                return d
            });
            return a
        })
    }
    var i = !1;

    function j() {
        i || (i = !0, h());
        return g.exports
    }

    function a(a) {
        switch (a) {
            case void 0:
                return j()
        }
    }
    e.exports = a
}), null);
__d("tweetnacl-util", ["tweetnacl-util-0.15.1"], (function(a, b, c, d, e, f) {
    e.exports = b("tweetnacl-util-0.15.1")()
}), null); /*FB_PKG_DELIM*/
__d("EncryptedBackupsMediaRestoreProbeQpl", ["MAWQplProxy", "justknobx", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.mediaType,
            e = a.msgType,
            f = a.probeDelayMs,
            g = a.restoreMethod,
            h = a.sampleRate;
        a = a.triggerSource;
        return d("MAWQplProxy").startQplUserFlow(c("qpl")._(521473213, "27"), {
            "int": {
                probeDelayMs: f,
                sampleRate: h
            },
            string: {
                mediaType: b,
                msgType: e,
                restoreMethod: g,
                triggerSource: a
            }
        }, void 0, c("justknobx")._("3047"))
    }
    g.startMediaRestoreProbeQPLFlow = a
}), 98);
__d("EncryptedBackupsResignCdnUrl", ["MAWBridge", "MAWConfig", "MAWLoggerUtils", "WAJids", "WAResolvable", "WAResultOrError", "asyncToGeneratorRuntime", "cr:10071"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map();

    function a(a) {
        return h.get(a)
    }

    function c(a) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var c = a.deliveryObjectId,
                e = a.mediaType,
                f = a.msgId,
                g = a.protocolMsgId;
            a = a.sortOrderMs;
            if (b("cr:10071") !== null) {
                var i = (yield b("cr:10071").eblsResignCdnUrlWithGraphQL({
                    chatJid: g.chat,
                    deliveryObjectId: c,
                    externalId: g.externalId,
                    mediaType: e,
                    sortOrderMs: a
                }));
                return !i.success ? i : d("WAResultOrError").makeResult(i.value)
            } else {
                i = d("MAWLoggerUtils").getInstanceKey();
                var j = new(d("WAResolvable").Resolvable)();
                h.set(i, j);
                d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
                    events: [{
                        tag: "ResignAttachmentCDNUrl",
                        value: {
                            deliveryObjectId: c,
                            mediaType: e,
                            messageId: g.externalId,
                            msgId: f,
                            productType: d("MAWConfig").getConfig().productTypeForEBAttachments,
                            skipLegacyMediaDownloadFlow: !0,
                            sortOrder: a,
                            threadId: d("WAJids").threadIdForChatJid(g.chat),
                            threadJid: g.chat,
                            traceId: i
                        }
                    }]
                });
                return j.promise
            }
        });
        return i.apply(this, arguments)
    }
    g.getRestoredCdnUrlResolvable = a;
    g.resignCdnUrl = c
}), 98);
__d("MAWGetMediaApi", ["MAWDbMediaTxns", "MAWDexieTable", "MAWIndexedDb", "MAWTransactionMode"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["cannot find xma with xmaId ", ""]);
        h = function() {
            return a
        };
        return a
    }
    b = d("MAWIndexedDb").makeMsgrTransactor({
        media: (a = d("MAWTransactionMode")).READONLY
    }, "getMediaByPlaintextHash", function(a) {
        return function(b) {
            return d("MAWDbMediaTxns").maybeGetMediaFromPlaintextHash(a, b)
        }
    });
    c = d("MAWIndexedDb").makeMsgrTransactor({
        media: a.READONLY
    }, "getMediaByMediaId", function(a) {
        return function(b) {
            return d("MAWDbMediaTxns").maybeGetMediaFromMediaId(a, b)
        }
    });
    e = d("MAWIndexedDb").makeMsgrTransactor({
        media: a.READONLY,
        xma: a.READONLY
    }, "getMediaByXMAId", function(a) {
        return function(b, c) {
            return a.xma.get(b).then(function(e) {
                if (e == null) {
                    c.ERROR(h(), b);
                    return []
                }
                return d("MAWDexieTable").dexieAll([d("MAWDbMediaTxns").maybeGetMediaFromMediaId(a, e.defaultPreviewMediaId), d("MAWDbMediaTxns").maybeGetMediaFromMediaId(a, e.headerMediaId), d("MAWDbMediaTxns").maybeGetMediaFromMediaId(a, e.faviconMediaId)])
            })
        }
    });
    g.getMediaByPlaintextHash = b;
    g.getMediaByMediaId = c;
    g.getMediaByXMAId = e
}), 98);
__d("MAWGetMsgByProtocolIdApi", ["MAWDbMsgTxns", "MAWIndexedDb", "MAWTransactionMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MAWIndexedDb").makeMsgrTransactor({
        messages: d("MAWTransactionMode").READONLY
    }, "getMsgsByProtocolMsgIdsTxn", function(a) {
        return function(b) {
            return d("MAWDbMsgTxns").getMsgsByProtocolMsgId(a, b)
        }
    });
    g.getMsgsByProtocolMsgIdsTxn = a
}), 98);
__d("MAWDeletedMsgApi", ["MAWIndexedDb", "MAWTransactionMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MAWIndexedDb").makeMsgrTransactor({
        deletedMessages: d("MAWTransactionMode").READONLY
    }, "getDeletedMsgByProtocolIdApi", function(a) {
        return function(b) {
            return a.deletedMessages.get(babelHelpers["extends"]({}, b))
        }
    });
    g.getDeletedMsgByProtocolIdApi = a
}), 98);
__d("MAWIsMsgDeletedWithReason", ["MAWDbDeletedMessages", "MAWDeletedMsgApi", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return h.apply(this, arguments)
    }

    function h() {
        h = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            a = (yield d("MAWDeletedMsgApi").getDeletedMsgByProtocolIdApi(a));
            return !a ? !1 : a.reason === d("MAWDbDeletedMessages").DbDeletedMsgReasonEnum.ChatDelete || a.reason === d("MAWDbDeletedMessages").DbDeletedMsgReasonEnum.Revoke
        });
        return h.apply(this, arguments)
    }
    g.isMsgDeletedWithReason = a
}), 98);
__d("EncryptedBackupsMediaRestoreProbe", ["EncryptedBackupsMediaRestoreProbeQpl", "EncryptedBackupsResignCdnUrl", "MAWCastToMsgrServerMediaType", "MAWDbXMATxns", "MAWGetMediaApi", "MAWGetMsgByProtocolIdApi", "MAWIndexedDb", "MAWIsMsgDeletedWithReason", "MAWMsgType", "MAWTransactionMode", "Promise", "WAMediaUtils", "WAPromiseDelays", "WAResultOrError", "WATagsLogger", "asyncToGeneratorRuntime", "cr:10071", "gkx", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["restore media success for ", ". mediaType: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["failed to restore media for ", ". mediaType: ", ", error: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["unsupported media type ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sortOrderMs is required for media restore, but not found for ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["skip restore probe because no attachment found"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["no dbMsg found for ", " - msgType: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["msg is deleted"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["start probe media backup through ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["cannot find media for xma with protocolMsgId ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["preview object id is null for recent thumbnail"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["preview object id is null and mediaKeyTimestamp is null"]);
        s = function() {
            return a
        };
        return a
    }
    var t = d("WATagsLogger").TAGS(["MediaRestoreProbe"]),
        u = c("justknobx")._("2045"),
        v = 1713191110;

    function a(a) {
        return w.apply(this, arguments)
    }

    function w() {
        w = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var c = a.triggerSource;
            a = a.uploadEntity;
            switch (a.dbMsgType) {
                case d("MAWMsgType").MSG_TYPE.REACTION:
                case d("MAWMsgType").MSG_TYPE.EDIT_ACTION:
                    return d("WAResultOrError").makeResult("no-attachment-with-msg")
            }
            var e = D(),
                f = a.dbMsgType;
            f = f === d("MAWMsgType").MSG_TYPE.VIDEO ? 13 : 1;
            f = Math.random() < e * f / 100;
            if (!f) return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult("not-sampled"));
            var g = b("cr:10071") == null ? "sproc" : "gql";
            t.LOG(p(), g);
            yield d("WAPromiseDelays").delayMs(u);
            var i = a.msgId;
            f = (yield d("MAWGetMsgByProtocolIdApi").getMsgsByProtocolMsgIdsTxn([i]));
            var j = f[0];
            if (j == null) {
                f = (yield d("MAWIsMsgDeletedWithReason").isMsgDeletedWithReason(i));
                if (f) {
                    t.LOG(o());
                    return d("WAResultOrError").makeResult("msg-deleted")
                }
                t.ERROR(n(), i, a.dbMsgType);
                return d("WAResultOrError").makeError("missing-db-msg")
            }
            f = (yield A({
                dbMsg: j,
                protocolMsgId: i
            }));
            if (f.type === "no-attachment") {
                t.LOG(m());
                return d("WAResultOrError").makeResult("no-attachment-with-msg")
            }
            a = x(f, j.msgId);
            if (!a.success) return d("WAResultOrError").makeError([a.error]);
            f = a.value;
            a = (yield(h || (h = b("Promise"))).all(f.map(function(a) {
                var b = d("EncryptedBackupsMediaRestoreProbeQpl").startMediaRestoreProbeQPLFlow({
                    mediaType: a.serverMediaType,
                    msgType: j.type,
                    probeDelayMs: u,
                    restoreMethod: g,
                    sampleRate: e,
                    triggerSource: c
                });
                return y({
                    dbMsg: j,
                    payload: a,
                    protocolMsgId: i
                }).then(function(a) {
                    if (a.success) {
                        b.endSuccess();
                        return a
                    }
                    b.endFail(a.error, {
                        string: {
                            failReason: a.error
                        }
                    });
                    return a
                })["catch"](function(a) {
                    b.endFail("runtime-error", {
                        string: {
                            failReason: a.toString()
                        }
                    });
                    return d("WAResultOrError").makeError("runtime-error")
                })
            })));
            f = a.map(function(a) {
                return a.success ? null : a.error
            }).filter(Boolean);
            return f.length > 0 ? d("WAResultOrError").makeError(f) : d("WAResultOrError").makeResult("restore-media-success")
        });
        return w.apply(this, arguments)
    }

    function x(a, b) {
        var c = [],
            e = a.type === "xma" ? a.medias : [a];
        e.forEach(function(a) {
            a = a.fullsize;
            a = a.mediaEntries.get(b);
            if (a == null) return d("WAResultOrError").makeError("missing-media-entry");
            a = d("WAMediaUtils").decodeMediaEntryData(a);
            var e = a.objectId;
            a = a.serverMediaType;
            c.push({
                objectId: e,
                serverMediaType: a
            })
        });
        a.type === "media-with-preview" && (c.push({
            objectId: a.preview.objectId,
            serverMediaType: "preview"
        }), a.preview.objectId == null && (a.preview.mediaKeyTimestamp == null ? t.ERROR(s()) : a.preview.mediaKeyTimestamp > v && t.ERROR(r())));
        return d("WAResultOrError").makeResult(c)
    }

    function y(a) {
        return z.apply(this, arguments)
    }

    function z() {
        z = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = a.dbMsg,
                c = a.payload;
            a = a.protocolMsgId;
            var e = b.msgId,
                f = b.sortOrderMs;
            if (f == null) {
                t.ERROR(l(), a);
                return d("WAResultOrError").makeError("missing-sort-order-ms")
            }
            var g = c.objectId;
            c = c.serverMediaType;
            if (c == null || g == null) return d("WAResultOrError").makeError("invalid-media-entry");
            b = d("MAWCastToMsgrServerMediaType").castToMsgrServerMediaType(c, b.type === d("MAWMsgType").MSG_TYPE.XMA);
            if (b == null) {
                t.ERROR(k(), c);
                return d("WAResultOrError").makeError("unsupported-media-type")
            }
            c = (yield d("EncryptedBackupsResignCdnUrl").resignCdnUrl({
                deliveryObjectId: g,
                mediaType: b,
                msgId: e,
                protocolMsgId: a,
                sortOrderMs: f
            }));
            if (!c.success) {
                t.ERROR(j(), a, b, c.error);
                return c
            }
            t.LOG(i(), a, b);
            return d("WAResultOrError").makeResult("restore-media-success")
        });
        return z.apply(this, arguments)
    }

    function A(a) {
        return B.apply(this, arguments)
    }

    function B() {
        B = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = a.dbMsg;
            a = a.protocolMsgId;
            switch (b.type) {
                case d("MAWMsgType").MSG_TYPE.IMAGE:
                case d("MAWMsgType").MSG_TYPE.VIDEO:
                    if (b.plaintextHash == null) return {
                        type: "no-attachment"
                    };
                    var e = (yield d("MAWGetMediaApi").getMediaByPlaintextHash(b.plaintextHash));
                    if (c("gkx")("6038") && e != null) {
                        var f = e == null ? void 0 : e.mediaEntries.get(b.msgId);
                        if (f != null) {
                            f = d("WAMediaUtils").decodeMediaEntryData(f).downloadableThumbnail;
                            if (f != null) return {
                                fullsize: e,
                                preview: f,
                                type: "media-with-preview"
                            }
                        }
                    }
                    return e == null ? {
                        type: "no-attachment"
                    } : {
                        fullsize: e,
                        type: "media"
                    };
                case d("MAWMsgType").MSG_TYPE.PTT:
                case d("MAWMsgType").MSG_TYPE.GIF:
                case d("MAWMsgType").MSG_TYPE.STICKER:
                case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                    if (b.plaintextHash == null) return {
                        type: "no-attachment"
                    };
                    f = (yield d("MAWGetMediaApi").getMediaByPlaintextHash(b.plaintextHash));
                    return f == null ? {
                        type: "no-attachment"
                    } : {
                        fullsize: f,
                        type: "media"
                    };
                case d("MAWMsgType").MSG_TYPE.RAVEN:
                case d("MAWMsgType").MSG_TYPE.TEXT:
                case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
                case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
                case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
                case d("MAWMsgType").MSG_TYPE.ADMIN:
                case d("MAWMsgType").MSG_TYPE.REVOKED:
                case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
                case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
                case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
                case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
                case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
                case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
                case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                    return {
                        type: "no-attachment"
                    };
                default:
                    b.type;
                    e = (yield C(a));
                    return e.length === 0 ? {
                        type: "no-attachment"
                    } : {
                        medias: e.map(function(a) {
                            return {
                                fullsize: a
                            }
                        }),
                        type: "xma"
                    }
            }
        });
        return B.apply(this, arguments)
    }
    var C = d("MAWIndexedDb").makeMsgrTransactor({
        media: d("MAWTransactionMode").READONLY,
        messages: d("MAWTransactionMode").READONLY,
        xma: d("MAWTransactionMode").READONLY
    }, "getMediaByXMAId", function(a) {
        return function(b) {
            return d("MAWDbXMATxns").maybeGetXMAPayloadFromProtocolMsgId(a, b).then(function(a) {
                if (!a.success) {
                    t.ERROR(q(), b);
                    return []
                }
                a = a.value;
                var c = a.defaultPreview,
                    d = a.favicon,
                    e = a.header;
                a = a.previews;
                return [c, d, e].concat(a == null ? [] : a).filter(Boolean)
            })
        }
    });

    function D() {
        return c("gkx")("2067") ? 100 : c("justknobx")._("2722")
    }
    g.sampleProbeMediaRestore = a
}), 98);
__d("MAWEBScheduler", ["WorkerScheduler"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        h == null && (h = d("WorkerScheduler").makeScheduler("eb", {
            concurrency: 1,
            maxConcurrency: 1,
            maxThrottleMs: 1e3,
            timeToStuckMs: 3e4
        }));
        return h
    }
    g.ebScheduler = a
}), 98);
__d("MAWEbUploadQueue", ["EBUploadMessages", "EncryptedBackupsMediaRestoreProbe", "EncryptedBackupsUploadQueue", "EncryptedBackupsUtils", "MAWBridge", "MAWEBScheduler", "MAWEBSwitch", "MAWEBUploadTrackingUtils", "MAWGetMsgByProtocolIdApi", "WAGetSafeQPLError", "WAGlobals", "WAJids", "WAPromiseBackoffs", "WAShiftTimer", "WATimeUtils", "WAWaitForUserUnblocked", "WorkerScheduler", "asyncToGeneratorRuntime", "gkx", "justknobx", "promiseDone", "setInterval"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unexpected runtime error in probeMediaRestore: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Cannot get message from db: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["upload queue uploading ", " messages"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " cannot process EB upload"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["upload queue - instanceKey not found from uploadTrackingInstanceKeyMap, in checkMsgExist msg found 2"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["upload queue - instanceKey not found from uploadTrackingInstanceKeyMap, in checkMsgExist msg not found 1"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["upload queue - instanceKey not found from uploadTrackingInstanceKeyMap, in checkMsgExist msg found"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " cannot process EB upload"]);
        o = function() {
            return a
        };
        return a
    }
    var p = d("EncryptedBackupsUploadQueue").logger.TAGS(["labyrinth-web"]),
        q = new Map(),
        r = new Map(),
        s = new Set(),
        t = {
            algo: {
                first: c("justknobx")._("2366"),
                type: "exponential"
            },
            max: d("WATimeUtils").HOUR_MILLISECONDS
        },
        u = d("WAPromiseBackoffs").createTimer(t);
    a = u();
    c("setInterval")(e, 1e3);
    var v = new(d("WAShiftTimer").ShiftTimer)(f),
        w = null;

    function x() {
        return y.apply(this, arguments)
    }

    function y() {
        y = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            yield d("WAWaitForUserUnblocked").waitForUserUnblocked();
            var e = !0;
            if (w != null) return;
            w = d("MAWEBScheduler").ebScheduler().task({
                fn: function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                        if (c("MAWEBSwitch").isEnabled()) {
                            var a = (yield C());
                            a = a.isEmpty;
                            e = !a
                        } else d("MAWEBUploadTrackingUtils").getUploadQueueStartedCache().forEach(function(a, b) {
                            d("MAWEBUploadTrackingUtils").removeExternalIdFromUploadQueueStartedCache(b)
                        }), e = !1
                    });

                    function f() {
                        return a.apply(this, arguments)
                    }
                    return f
                }(),
                name: "eb_upload",
                priority: d("WorkerScheduler").BACKGROUND_PRIORITY
            });
            w.run().then(function() {
                u = d("WAPromiseBackoffs").createTimer(t), a = u(), w = null, e && void x()
            })["catch"](function(b) {
                w = null, p.ERROR(k(), b), q.forEach(function(a, c, e) {
                    d("MAWEBUploadTrackingUtils").endFailWorkerOnly(c, "upload_eb_msgs_error", {
                        string: {
                            reason: d("WAGetSafeQPLError").getSafeQPLErrorMessage(b)
                        }
                    })
                }), q.clear(), e && (a = u(), window.setTimeout(function() {
                    void x()
                }, c("justknobx")._("2366") + a))
            })
        });
        return y.apply(this, arguments)
    }

    function e() {
        var a = d("WATimeUtils").performanceAbsoluteNow();
        s.forEach(function(b) {
            a - b > c("justknobx")._("2366") && (s["delete"](b), c("promiseDone")(z()))
        });
        var b = [];
        for (var e of r) {
            var f = e[0],
                g = e[1];
            s.has(g) || b.push(f)
        }
        b.forEach(function(a) {
            return r["delete"](a)
        })
    }

    function f() {
        c("MAWEBSwitch").isEnabled() ? void C()["catch"](function(a) {
            p.ERROR(o(), a), q.forEach(function(b, c, e) {
                d("MAWEBUploadTrackingUtils").endFailWorkerOnly(c, "upload_eb_msgs_error", {
                    string: {
                        reason: d("WAGetSafeQPLError").getSafeQPLErrorMessage(a)
                    }
                })
            }), q.clear(), v.onOrAfter(c("justknobx")._("2366"))
        }) : (d("MAWEBUploadTrackingUtils").getUploadQueueStartedCache().forEach(function(a, b) {
            d("MAWEBUploadTrackingUtils").removeExternalIdFromUploadQueueStartedCache(b)
        }), v.onOrAfter(c("justknobx")._("2366")))
    }

    function z() {
        return A.apply(this, arguments)
    }

    function A() {
        A = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            if (c("gkx")("5625")) {
                c("promiseDone")(x());
                return
            }
            yield d("WAWaitForUserUnblocked").waitForUserUnblocked();
            v.onOrBefore(c("justknobx")._("2367"))
        });
        return A.apply(this, arguments)
    }

    function B() {
        c("MAWEBSwitch").onSet(function() {
            c("MAWEBSwitch").isEnabled() && c("promiseDone")(z())
        });
        c("promiseDone")(z());
        var a = d("EncryptedBackupsUploadQueue").ebUploadQueue();
        a.subscribe(function(a) {
            a.type === "flush" && c("promiseDone")(z())
        })
    }

    function C() {
        return D.apply(this, arguments)
    }

    function D() {
        D = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            var a = d("EncryptedBackupsUploadQueue").ebUploadQueue(),
                b = [],
                e = (yield a.read({
                    filter: function(a) {
                        if (a.sortOrderMs == null || d("EncryptedBackupsUtils").entryOlderThan30Days(a.sortOrderMs)) {
                            b.push(a.queueId);
                            return !1
                        } else return !q.has(d("MAWEBUploadTrackingUtils").genInstanceKeyForUploadQueue(a.msgId))
                    },
                    limit: c("justknobx")._("2368"),
                    order: "desc"
                }));
            yield a["delete"](b);
            if (e.length === 0) return {
                isEmpty: !0
            };
            p.LOG(j(), e.length);
            a = e.map(function(a) {
                var b;
                return {
                    backupActionType: a.backupActionType,
                    msgId: a.msgId,
                    originalMsgProtocolId: (b = a.backupDirective) == null ? void 0 : b.originalMsgProtocolId,
                    protobuf: a.protobuf,
                    senderId: a.senderId,
                    serverTs: a.serverTs,
                    sortOrderMs: a.sortOrderMs,
                    supplementalKey: a.supplementalKey
                }
            });
            var f = new Map(),
                g = [],
                h = [],
                k = new Map(),
                l = new Map();
            for (var m of e)
                if (m.originalMsgProtocolId.author != null) {
                    var n, o = m.originalMsgProtocolId.author,
                        t = m.originalMsgProtocolId.chat;
                    o = {
                        author: d("WAGlobals").getMyUserJid() === m.originalMsgProtocolId.author ? d("WAJids").AUTHOR_ME : o,
                        chat: t,
                        externalId: m.backupActionType === 4 ? m.msgId.externalId : m.originalMsgProtocolId.externalId
                    };
                    t = d("MAWEBUploadTrackingUtils").genInstanceKeyForUploadQueue(m.msgId);
                    q.set(t, m.queueId);
                    k.set(o.externalId, (n = m.attachmentContext) != null ? n : h);
                    n = m.msgId.externalId;
                    var u = m.originalMsgProtocolId.externalId;
                    n !== u && l.set(n, {
                        currentExternalId: n,
                        originalMsgExternalId: u
                    });
                    if (!f.has(o.externalId)) {
                        f.set(o.externalId, t);
                        n = d("MAWEBUploadTrackingUtils").getAndRemoveFromUploadQueueStartedCache(m.msgId.externalId);
                        u = n == null ? "uploadqueue" : H(o.author);
                        d("MAWEBUploadTrackingUtils").startUploadTracking(o.externalId, n == null ? void 0 : n.msgType, u, t, !0);
                        g.push(o)
                    }
                } else c("promiseDone")(d("EncryptedBackupsUploadQueue").ebUploadQueue().ack([m.queueId]));
            f.forEach(function(a, b) {
                d("MAWEBUploadTrackingUtils").addPointWorkerOnly(a, "queue_get_original_msg_ids_done")
            });
            d("EBUploadMessages").logIfExtIdsNotInAttachmentContextArrayMap(k, g.map(function(a) {
                return {
                    extId: a.externalId
                }
            }), "after_originalMsgIdArray", f);
            n = (yield d("MAWGetMsgByProtocolIdApi").getMsgsByProtocolMsgIdsTxn(g)["catch"](function(a) {
                g.forEach(function(b) {
                    b = f.get(b.externalId);
                    b != null ? d("MAWEBUploadTrackingUtils").endFailWorkerOnly(b, "get_db_msgs_error", {
                        string: {
                            reason: d("WAGetSafeQPLError").getSafeQPLErrorMessage(a)
                        }
                    }) : p.WARN(i(), a)
                });
                throw a
            }));
            var w = d("WATimeUtils").performanceAbsoluteNow();
            s.add(w);
            var x = new Map();
            n.forEach(function(a) {
                var b = f.get(a.externalId);
                if (b == null) return;
                r.set(b, w);
                d("MAWEBUploadTrackingUtils").addPointWorkerOnly(b, "queue_get_msgs_done");
                var c = l.get(a.externalId);
                c != null && d("MAWEBUploadTrackingUtils").addPointWorkerOnly(b, "external_id_mismatch", {
                    string: {
                        currentExternalId: c.currentExternalId,
                        differing_ids_type: a.type,
                        originalMsgExternalId: c.originalMsgExternalId
                    }
                });
                x.set(a.externalId, (b = k.get(a.externalId)) != null ? b : h)
            });
            G(f, g, n);
            d("EBUploadMessages").logIfExtIdsNotInAttachmentContextArrayMap(k, n.map(function(a) {
                return {
                    extId: a.externalId,
                    type: a.type
                }
            }), "after_msgArray", f);
            var y = [];
            e.forEach(function(a) {
                a.legacyAttachmentContext != null && a.legacyAttachmentContext.forEach(function(a) {
                    y.push({
                        tag: "UploadAttachment",
                        value: a
                    })
                })
            });
            y.length > 0 && d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
                events: y
            });
            yield d("EBUploadMessages").uploadMessageFromUploadQueue(n, f, a, x);
            c("gkx")("5625") || v.onOrBefore(c("justknobx")._("2366"));
            return {
                isEmpty: !1
            }
        });
        return D.apply(this, arguments)
    }

    function E(a, b) {
        return F.apply(this, arguments)
    }

    function F() {
        F = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            var e = d("EncryptedBackupsUploadQueue").ebUploadQueue();
            b ? d("MAWEBUploadTrackingUtils").endSuccessWorkerOnly(a, "upload_queue_ack_worker_success") : d("MAWEBUploadTrackingUtils").endFailWorkerOnly(a, "upload_queue_ack_worker_fail");
            var f = r.get(a);
            f != null && (r["delete"](a), s["delete"](f));
            var g = q.get(a);
            if (g == null) return;
            if (b) {
                f = (yield e.read({
                    filter: function(a) {
                        return a.queueId === g
                    },
                    limit: 1
                }));
                b = f[0];
                if (b == null) return;
                void d("EncryptedBackupsMediaRestoreProbe").sampleProbeMediaRestore({
                    triggerSource: H(b.msgId.author),
                    uploadEntity: b
                })["catch"](function(a) {
                    p.ERROR(h(), a)
                })
            }
            yield e.ack([g]);
            q["delete"](a);
            c("promiseDone")(z())
        });
        return F.apply(this, arguments)
    }

    function G(a, c, e) {
        if (c.length > e.length) {
            var f = new Set(c.map(function(a) {
                return a.externalId
            }));
            e.forEach(function(b) {
                if (f.has(b.externalId)) {
                    f["delete"](b.externalId);
                    var c = a.get(b.externalId);
                    c != null ? d("MAWEBUploadTrackingUtils").addPointWorkerOnly(c, "msg_found", {
                        string: {
                            originalMsgType: b.type
                        }
                    }) : p.WARN(n())
                }
            });
            f.forEach(function() {
                var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                    b = a.get(b);
                    if (b != null) {
                        d("MAWEBUploadTrackingUtils").endSuccessWorkerOnly(b, "upload_queue_msg_not_found");
                        var c = q.get(b);
                        q["delete"](b);
                        if (c == null) return;
                        yield d("EncryptedBackupsUploadQueue").ebUploadQueue()["delete"]([c])
                    } else p.WARN(m())
                });
                return function(a) {
                    return c.apply(this, arguments)
                }
            }())
        } else e.forEach(function(b) {
            var c = a.get(b.externalId);
            c != null ? d("MAWEBUploadTrackingUtils").addPointWorkerOnly(c, "msg_found", {
                string: {
                    originalMsgType: b.type
                }
            }) : p.WARN(l())
        })
    }

    function H(a) {
        return a === d("WAJids").AUTHOR_ME || a === d("WAGlobals").getMyUserJid() ? "send" : "receive"
    }
    g.scheduleNextRun = z;
    g.listenForEbUploadQueueFlush = B;
    g.uploadEBMsgs = C;
    g.ackWithInstanceKey = E
}), 98); /*FB_PKG_DELIM*/
__d("ConstUriUtils", ["CometLruCache", "ExecutionEnvironment", "FBLogger", "PHPQuerySerializer", "PHPQuerySerializerNoEncoding", "URIRFC3986", "URISchemes", "UriNeedRawQuerySVConfig", "isSameOrigin", "nullthrows", "recoverableViolation", "structuredClone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = d("CometLruCache").create(5e3),
        m = new RegExp("(^|\\.)facebook\\.com$", "i"),
        n = new RegExp("(^|\\.)messenger\\.com$", "i"),
        o = new RegExp("^(?:[^/]*:|[\\x00-\\x1f]*/[\\x00-\\x1f]*/)"),
        p = new RegExp("[\\x00-\\x2c\\x2f\\x3b-\\x40\\x5c\\x5e\\x60\\x7b-\\x7f\\uFDD0-\\uFDEF\\uFFF0-\\uFFFF\\u2047\\u2048\\uFE56\\uFE5F\\uFF03\\uFF0F\\uFF1F]"),
        q = c("UriNeedRawQuerySVConfig").uris.map(function(a) {
            return {
                domain: a,
                valid: x(a)
            }
        }),
        r = [],
        s = [];

    function t(a, b) {
        var d = {};
        if (a != null)
            for (var a = a.entries(), e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= a.length) break;
                    g = a[f++]
                } else {
                    f = a.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                d[g[0]] = g[1]
            } else c("FBLogger")("ConstUriUtils").warn("Passed a null query map in, this means poor client side flow coverage or client/server boundary type issue.");
        return b.serialize(d)
    }

    function u(a, b, d) {
        var e = k || (k = c("PHPQuerySerializer"));
        if (["http", "https"].includes(b) && v(a)) {
            if (a.includes("doubleclick.net") && d != null && !d.startsWith("http")) return e;
            e = c("PHPQuerySerializerNoEncoding")
        }
        return e
    }

    function v(a) {
        return a != null && q.some(function(b) {
            return b.valid && w(a, b.domain)
        })
    }

    function w(a, b) {
        if (b === "" || a === "") return !1;
        if (a.endsWith(b)) {
            b = a.length - b.length - 1;
            if (b === -1 || a[b] === ".") return !0
        }
        return !1
    }

    function x(a) {
        return !p.test(a)
    }

    function y(a, b) {
        var c = b.protocol != null && b.protocol !== "" ? b.protocol : a.getProtocol();
        c = b.domain != null ? u(b.domain, c) : a.getSerializer();
        c = {
            domain: a.getDomain(),
            fragment: a.getFragment(),
            fragmentSeparator: a.hasFragmentSeparator(),
            isGeneric: a.isGeneric(),
            originalRawQuery: a.getOriginalRawQuery(),
            path: a.getPath(),
            port: a.getPort(),
            protocol: a.getProtocol(),
            queryParams: a.getQueryParams(),
            serializer: c,
            subdomain: a.getSubdomain()
        };
        a = babelHelpers["extends"]({}, c, b);
        c = b.queryParams != null && b.queryParams.size !== 0;
        return D.getUribyObject(a, c)
    }

    function z(a, b, c, d) {
        c === void 0 && (c = !1);
        var e = a.protocol !== "" ? a.protocol + ":" + (a.isGeneric ? "" : "//") : "",
            f = a.domain !== "" ? a.domain : "",
            g = a.port !== "" ? ":" + a.port : "",
            h = a.path !== "" ? a.path : e !== "" && e !== "mailto:" || f !== "" || g !== "" ? "/" : "";
        c = A(f, a.originalRawQuery, a.queryParams, b, c, (b = d) != null ? b : a.serializer);
        d = c.length > 0 ? "?" : "";
        b = a.fragment !== "" ? "#" + a.fragment : "";
        a = a.fragment === "" && a.fragmentSeparator ? "#" : "";
        return "" + e + f + g + h + d + c + a + b
    }

    function A(a, b, c, d, e, f) {
        e === void 0 && (e = !1);
        if (!d && (e || v(a))) {
            return (d = b) != null ? d : ""
        }
        return t(c, f)
    }

    function B(a) {
        var b = a.trim();
        b = (h || (h = d("URIRFC3986"))).parse(b) || {
            fragment: null,
            host: null,
            isGenericURI: !1,
            query: null,
            scheme: null,
            userinfo: null
        };
        var c = b.host || "",
            e = c.split(".");
        e = e.length >= 3 ? e[0] : "";
        var f = u(c, b.scheme || "", b.query),
            g = f.deserialize(b.query || "") || {};
        g = new Map(Object.entries(g));
        g = C({
            domain: c,
            fragment: b.fragment || "",
            fragmentSeparator: b.fragment === "",
            isGeneric: b.isGenericURI,
            originalRawQuery: b.query,
            path: b.path || "",
            port: b.port != null ? String(b.port) : "",
            protocol: (b.scheme || "").toLowerCase(),
            queryParams: g,
            serializer: f,
            subdomain: e,
            userInfo: (c = b == null ? void 0 : b.userinfo) != null ? c : ""
        }, a);
        return g
    }

    function C(a, b, c, e) {
        c === void 0 && (c = (j || (j = d("URISchemes"))).Options.INCLUDE_DEFAULTS);
        var f = {
                components: babelHelpers["extends"]({}, a),
                error: "",
                valid: !0
            },
            g = f.components;
        if (!(j || (j = d("URISchemes"))).isAllowed(a.protocol, c, e)) {
            f.valid = !1;
            f.error = 'The URI protocol "' + String(a.protocol) + '" is not allowed.';
            return f
        }
        if (!x(a.domain || "")) {
            f.valid = !1;
            f.error = "This is an unsafe domain " + String(a.domain);
            return f
        }
        g.port = a.port != null && String(a.port) || "";
        if (Boolean(a.userInfo)) {
            f.valid = !1;
            f.error = "Invalid URI: (userinfo is not allowed in a URI " + String(a.userInfo) + ")";
            return f
        }
        c = b != null && b !== "" ? b : z(g, !1);
        if (g.domain === "" && g.path.indexOf("\\") !== -1) {
            f.valid = !1;
            f.error = "Invalid URI: (no domain but multiple back-slashes " + c + ")";
            return f
        }
        if (!g.protocol && o.test(c)) {
            f.valid = !1;
            f.error = "Invalid URI: (unsafe protocol-relative URI " + c + ")";
            return f
        }
        if (g.domain !== "" && g.path !== "" && !g.path.startsWith("/")) {
            f.valid = !1;
            f.error = "Invalid URI: (domain and pathwhere path lacks leading slash " + c + ")";
            return f
        }
        return f
    }
    var D = function() {
        function a(a) {
            this.queryParams = new Map(), this.domain = a.domain, this.fragment = a.fragment, this.fragmentSeparator = Boolean(a.fragmentSeparator), this.isGenericProtocol = Boolean(a.isGeneric), this.path = a.path, this.originalRawQuery = a.originalRawQuery, this.port = a.port, this.protocol = a.protocol, this.queryParams = a.queryParams, this.serializer = a.serializer, this.subdomain = a.subdomain
        }
        var b = a.prototype;
        b.addQueryParam = function(a, b) {
            if (Boolean(a)) {
                var c = this.getQueryParams();
                c.set(a, b);
                return y(this, {
                    queryParams: c
                })
            }
            return this
        };
        b.addQueryParams = function(a) {
            if (a.size > 0) {
                var b = this.getQueryParams();
                a.forEach(function(a, c) {
                    b.set(c, a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.addQueryParamString = function(a) {
            if (Boolean(a)) {
                a = a.startsWith("?") ? a.slice(1) : a;
                var b = this.getQueryParams();
                a.split("&").map(function(a) {
                    a = a.split("=");
                    var c = a[0];
                    a = a[1];
                    b.set(c, a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.addTrailingSlash = function() {
            var a = this.getPath();
            return a.length > 0 && a[a.length - 1] !== "/" ? this.setPath(a + "/") : this
        };
        b.getDomain = function() {
            return this.domain
        };
        b.getFragment = function() {
            return this.fragment
        };
        b.getOrigin = function() {
            var a = this.getPort();
            return this.getProtocol() + "://" + this.getDomain() + (a ? ":" + a : "")
        };
        b.getOriginalRawQuery = function() {
            return this.originalRawQuery
        };
        b.getPath = function() {
            return this.path
        };
        b.getPort = function() {
            return this.port
        };
        b.getProtocol = function() {
            return this.protocol.toLowerCase()
        };
        b.getQualifiedUri = function() {
            if (!this.getDomain()) {
                var b;
                b = (b = typeof window !== "undefined" ? window : self) == null ? void 0 : (b = b.location) == null ? void 0 : b.href;
                if (b == null) {
                    c("FBLogger")("ConstUriUtils").blameToPreviousFile().warn("Cannot get qualified URI for current URI as there is no current location");
                    return null
                }(i || (i = c("ExecutionEnvironment"))).isInWorker && b.startsWith("blob:") && (b = b.substring(5, b.length));
                b = b.slice(0, b.indexOf("/", b.indexOf(":") + 3));
                return a.getUri(b + this.toString())
            }
            return this
        };
        b.getQueryParam = function(a) {
            a = this.queryParams.get(a);
            if (typeof a === "string") return a;
            else {
                a = JSON.stringify(a);
                return a == null ? a : JSON.parse(a)
            }
        };
        b.getQueryData = function() {
            return Object.fromEntries(this.getQueryParams())
        };
        b.getQueryParams = function() {
            if (c("structuredClone") != null) return c("structuredClone")(this.queryParams);
            var a = JSON.stringify(Array.from(this.queryParams), function(a, b) {
                return Array.isArray(b) ? {
                    __CUUArr: !0,
                    value: babelHelpers["extends"]({}, b)
                } : b
            });
            a = JSON.parse(a, function(a, b) {
                return b != null && typeof b === "object" && b.__CUUArr ? Object.keys(b.value).reduce(function(a, c) {
                    a[c] = b.value[c];
                    return a
                }, []) : b
            });
            return new Map(a)
        };
        b.getQueryString = function(a) {
            a === void 0 && (a = !1);
            return A(this.domain, this.originalRawQuery, this.queryParams, !1, a, this.serializer)
        };
        b.getRegisteredDomain = function() {
            if (!this.getDomain()) return "";
            if (!this.isFacebookUri()) return null;
            var a = this.getDomain().split("."),
                b = a.indexOf("facebook");
            b === -1 && (b = a.indexOf("workplace"));
            return a.slice(b).join(".")
        };
        b.getSerializer = function() {
            return this.serializer
        };
        b.getSubdomain = function() {
            return this.subdomain
        };
        b.getUnqualifiedUri = function() {
            if (this.getDomain()) {
                var b = this.toString();
                return a.getUri(b.slice(b.indexOf("/", b.indexOf(":") + 3)))
            }
            return this
        };
        a.getUri = function(b) {
            b = b.trim();
            var d = l.get(b);
            if (d == null) {
                var e = B(b);
                if (e.valid) d = new a(e.components), l.set(b, d);
                else {
                    c("FBLogger")("ConstUriUtils").blameToPreviousFrame().warn(e.error);
                    return null
                }
            }
            return d
        };
        a.getUriOrThrow = function(b) {
            return c("nullthrows")(a.getUri(b))
        };
        a.getUribyObject = function(b, d) {
            var e = z(b, d),
                f = l.get(e);
            if (f == null) {
                d && (b.originalRawQuery = t(b.queryParams, b.serializer));
                d = C(b);
                if (d.valid) f = new a(d.components), l.set(e, f);
                else {
                    c("recoverableViolation")(d.error, "ConstUri");
                    return null
                }
            }
            return f
        };
        b.hasFragmentSeparator = function() {
            return this.fragmentSeparator
        };
        b.isEmpty = function() {
            return !(this.getPath() || this.getProtocol() || this.getDomain() || this.getPort() || this.queryParams.size > 0 || this.getFragment())
        };
        b.isFacebookUri = function() {
            var a = this.toString();
            if (a === "") return !1;
            return !this.getDomain() && !this.getProtocol() ? !0 : ["https", "http"].indexOf(this.getProtocol()) !== -1 && (m.test(this.getDomain()) || n.test(this.getDomain()))
        };
        b.isGeneric = function() {
            return this.isGenericProtocol
        };
        b.isSameOrigin = function(a) {
            return c("isSameOrigin")(this, a)
        };
        b.isSubdomainOfDomain = function(b) {
            var c = a.getUri(b);
            return c != null && w(this.domain, b)
        };
        b.isSecure = function() {
            return this.getProtocol() === "https"
        };
        b.removeQueryParams = function(a) {
            if (Array.isArray(a) && a.length > 0) {
                var b = this.getQueryParams();
                a.map(function(a) {
                    return b["delete"](a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.removeQueryParam = function(a) {
            if (Boolean(a)) {
                var b = this.getQueryParams();
                b["delete"](a);
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.removeSubdomain = function() {
            var a = this.getQualifiedUri();
            if (a == null) return null;
            var b = a.getDomain();
            b = b.split(".");
            b.length >= 3 && (b = b.slice(-2));
            return y(a, {
                domain: b.join("."),
                subdomain: ""
            })
        };
        b.replaceQueryParam = function(a, b) {
            if (Boolean(a)) {
                var c = this.getQueryParams();
                c.set(a, b);
                return y(this, {
                    queryParams: c
                })
            }
            return this
        };
        b.replaceQueryParams = function(a) {
            return y(this, {
                queryParams: a
            })
        };
        b.replaceQueryParamString = function(a) {
            if (a != null) {
                a = a.startsWith("?") ? a.slice(1) : a;
                var b = this.getQueryParams();
                a.split("&").map(function(a) {
                    a = a.split("=");
                    var c = a[0];
                    a = a[1];
                    b.set(c, a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.setDomain = function(a) {
            if (Boolean(a)) {
                var b = a.split(".");
                b = b.length >= 3 ? b[0] : "";
                return y(this, {
                    domain: a,
                    subdomain: b
                })
            }
            return this
        };
        b.setFragment = function(a) {
            return a === "#" ? y(this, {
                fragment: "",
                fragmentSeparator: !0
            }) : y(this, {
                fragment: a,
                fragmentSeparator: a !== ""
            })
        };
        b.setPath = function(a) {
            return a != null ? y(this, {
                path: a
            }) : this
        };
        b.setPort = function(a) {
            return Boolean(a) ? y(this, {
                port: a
            }) : this
        };
        b.setProtocol = function(a) {
            return Boolean(a) ? y(this, {
                protocol: a
            }) : this
        };
        b.setSecure = function(a) {
            return this.setProtocol(a ? "https" : "http")
        };
        b.setSubDomain = function(a) {
            if (Boolean(a)) {
                var b = this.getQualifiedUri();
                if (b == null) return null;
                var c = b.getDomain();
                c = c.split(".");
                c.length >= 3 ? c[0] = a : c.unshift(a);
                return y(b, {
                    domain: c.join("."),
                    subdomain: a
                })
            }
            return this
        };
        b.stripTrailingSlash = function() {
            return this.setPath(this.getPath().replace(/\/$/, ""))
        };
        a.$1 = function(a) {
            a = a;
            for (var b = 0; b < r.length; b++) {
                var c = r[b];
                a = c(a)
            }
            return a
        };
        a.$2 = function(a, b) {
            b = b;
            for (var c = 0; c < s.length; c++) {
                var d = s[c];
                b = d(a, b)
            }
            return b
        };
        b.$3 = function(b, c) {
            c === void 0 && (c = !1);
            return z({
                domain: a.$1(this.domain),
                fragment: this.fragment,
                fragmentSeparator: this.fragmentSeparator,
                isGeneric: this.isGenericProtocol,
                originalRawQuery: this.originalRawQuery,
                path: this.path,
                port: this.port,
                protocol: this.protocol,
                queryParams: a.$2(this.domain, this.queryParams),
                serializer: b,
                subdomain: this.subdomain,
                userInfo: ""
            }, !1, c)
        };
        b.toStringRawQuery = function() {
            this.rawStringValue == null && (this.rawStringValue = this.$3(c("PHPQuerySerializerNoEncoding")));
            return this.rawStringValue
        };
        b.toString = function() {
            this.stringValue == null && (this.stringValue = this.$3(this.serializer));
            return this.stringValue
        };
        b.toStringPreserveQuery = function() {
            return this.$3(this.serializer, !0)
        };
        a.isValidUri = function(b) {
            var c = l.get(b);
            if (c != null) return !0;
            c = B(b);
            if (c.valid) {
                l.set(b, new a(c.components));
                return !0
            }
            return !1
        };
        return a
    }();

    function a(a) {
        if (a instanceof D) return a;
        else return null
    }

    function b(a) {
        r.push(a)
    }

    function e(a) {
        s.push(a)
    }
    f = D.getUri;
    var E = D.getUriOrThrow,
        F = D.isValidUri;
    g.isSubdomainOfDomain = w;
    g.isConstUri = a;
    g.registerDomainFilter = b;
    g.registerQueryParamsFilter = e;
    g.getUri = f;
    g.getUriOrThrow = E;
    g.isValidUri = F
}), 98);
__d("WebStorageCleanupReason", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = null;

    function a() {
        return g
    }

    function b(a) {
        g = a
    }
    f.getLastCleanupReason = a;
    f.setLastCleanupReason = b
}), 66);
__d("checkForIndexedDbSupported", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return !window.indexedDB ? !1 : !0
    }
    f["default"] = a
}), 66);
__d("cometAsyncFetchShared", ["cr:1396"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1396")
}), 98);
__d("isMessengerPWA", ["Env", "ExecutionEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function b() {
        var b;
        return (h || (h = c("ExecutionEnvironment"))).canUseDOM && a.matchMedia !== void 0 && a.matchMedia("(display-mode: standalone)").matches && ((b = (i || (i = c("Env"))).isMessengerDotComOnComet) != null ? b : !1)
    }
    g["default"] = b
}), 98);
__d("isRelativeURL", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /^(#|\/\w)/;

    function a(a) {
        return g.test(a)
    }
    f["default"] = a
}), 66);
__d("routeBuilderUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.split("/");
        return a.filter(function(a) {
            return a !== ""
        }).map(function(a) {
            var b = a.split(/{|}/);
            if (b.length < 3) return {
                isToken: !1,
                part: a
            };
            else {
                a = b[0];
                var c = b[1];
                b = b[2];
                var d = c[0] === "?",
                    e = c[d ? 1 : 0] === "*";
                c = c.substring((d ? 1 : 0) + (e ? 1 : 0));
                return {
                    isToken: !0,
                    optional: d,
                    catchAll: e,
                    prefix: a,
                    suffix: b,
                    token: c
                }
            }
        })
    }
    f.getPathParts = a
}), 66);
__d("jsRouteBuilder", ["ConstUriUtils", "FBLogger", "routeBuilderUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "#";

    function a(a, b, e, f, g) {
        g === void 0 && (g = !1);
        var i = d("routeBuilderUtils").getPathParts(a);

        function j(j) {
            try {
                var k = f != null ? babelHelpers["extends"]({}, f, j) : (j = j) != null ? j : {},
                    l = {};
                j = "";
                var m = !1;
                j = i.reduce(function(a, c) {
                    if (!c.isToken) return a + "/" + c.part;
                    else {
                        var d, e = c.optional,
                            f = c.prefix,
                            g = c.suffix;
                        c = c.token;
                        if (e && m) return a;
                        d = (d = k[c]) != null ? d : b[c];
                        if (d == null && e) {
                            m = !0;
                            return a
                        }
                        if (d == null) throw new Error("Missing required template parameter: " + c);
                        if (d === "") throw new Error("Required template parameter is an empty string: " + c);
                        l[c] = !0;
                        return a + "/" + f + d + g
                    }
                }, "");
                a.slice(-1) === "/" && (j += "/");
                j === "" && (j = "/");
                var n = d("ConstUriUtils").getUri(j);
                for (var o in k) {
                    var p = k[o];
                    !l[o] && p != null && n != null && (e != null && e.has(o) ? p !== !1 && (n = n.addQueryParam(o, null)) : n = n.addQueryParam(o, p))
                }
                return [n, j]
            } catch (b) {
                p = b == null ? void 0 : b.message;
                o = c("FBLogger")("JSRouteBuilder").blameToPreviousFrame().blameToPreviousFrame();
                g && (o = o.blameToPreviousFrame());
                o.mustfix("Failed building URI for base path: %s message: %s", a, p);
                return [null, h]
            }
        }
        return {
            buildUri: function(a) {
                a = (a = j(a)[0]) != null ? a : d("ConstUriUtils").getUri(h);
                if (a == null) throw new Error("Not even the fallback URL parsed validly!");
                return a
            },
            buildUriNullable: function(a) {
                return j(a)[0]
            },
            buildURL: function(a) {
                a = j(a);
                var b = a[0];
                a = a[1];
                return (b = b == null ? void 0 : b.toString()) != null ? b : a
            },
            buildURLStringDEPRECATED: function(a) {
                a = j(a);
                var b = a[0];
                a = a[1];
                return (b = b == null ? void 0 : b.toString()) != null ? b : a
            },
            getPath: function() {
                return a
            }
        }
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("IGDRouteProvider.react", ["I64", "react", "useCurrentRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react"));
    e = h;
    var k = e.createContext,
        l = e.useContext;

    function m(a) {
        try {
            return (i || (i = d("I64"))).of_string(a)
        } catch (a) {
            return
        }
    }

    function n(a) {
        if (a == null) return;
        a = a.params.thread_key;
        if (a != null && typeof a === "string") return m(a)
    }
    var o = k();

    function a(a) {
        a = a.children;
        var b = c("useCurrentRoute")();
        b = n(b);
        return j.jsx(o.Provider, {
            value: b,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return l(o)
    }
    g.IGDRouteContextProvider = a;
    g.useThreadKeyFromCurrentRoute = b
}), 98);
__d("IGDInteractionTraceAnnotations", ["I64", "IGDInstamadilloUtils", "IGDRouteProvider.react", "IGDThreadTTLCUtils", "Int64Hooks", "InteractionTracing", "LSIntEnum", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = (h || d("react")).useEffect;

    function a(a) {
        return babelHelpers["extends"]({}, d("IGDThreadTTLCUtils").getTTLCBooleanAnnotations(a), {
            is_dm: d("IGDInstamadilloUtils").isIGDDisappearingModeEnabled(a),
            is_instamadillo: d("IGDInstamadilloUtils").isInstamadilloTransportEnabled(a),
            is_instamadillo_tlc: d("IGDInstamadilloUtils").isInstamadilloCutover(a)
        })
    }

    function l(a, b) {
        var c = d("IGDInstamadilloUtils").isInstamadilloCutover(a),
            e = d("IGDInstamadilloUtils").isInstamadilloTransportEnabled(a),
            f = d("IGDInstamadilloUtils").isIGDDisappearingModeEnabled(a);
        b.addAnnotationBoolean("is_instamadillo", e);
        b.addAnnotationBoolean("is_instamadillo_tlc", c);
        b.addAnnotationBoolean("is_dm", f);
        b.addAnnotationBoolean("is_instamadillo_ttlc", (e = d("IGDThreadTTLCUtils")).isIGDTTLCEnabledForThread(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_audio", e.isInstamadilloTTLCAudioEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_clip", e.isInstamadilloTTLCClipEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_generic_xma", e.isInstamadilloTTLCGenericXmaEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_image", e.isInstamadilloTTLCImageEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_link", e.isInstamadilloTTLCLinkEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_media_share", e.isInstamadilloTTLCMediaShareEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_profile", e.isInstamadilloTTLCProfileEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_reel_share", e.isInstamadilloTTLCReelShareEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_story_share", e.isInstamadilloTTLCStoryShareEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_text", e.isInstamadilloTTLCTextEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_video", e.isInstamadilloTTLCVideoEnabled(a))
    }

    function b(a) {
        d("Int64Hooks").useEffectInt64(function() {
            c("InteractionTracing").getPendingInteractions().forEach(function(b) {
                l(a, b)
            })
        }, [a])
    }
    var m = new Set();

    function e(a) {
        d("Int64Hooks").useEffectInt64(function() {
            var b = (i || (i = d("I64"))).to_string(a.threadKey);
            c("InteractionTracing").getPendingInteractions().forEach(function(c) {
                var e = m.has(b);
                c.addAnnotationBoolean("is_thread_visited", e);
                c.addAnnotation("thread_key", (i || (i = d("I64"))).to_string(a.threadKey));
                a.consistentThreadFbid != null && c.addAnnotation("consistent_thread_fbid", (i || (i = d("I64"))).to_string(a.consistentThreadFbid));
                c.addAnnotationInt("thread_type", (j || (j = d("LSIntEnum"))).toNumber(a.threadType));
                a.threadSubtype != null && c.addAnnotation("thread_subtype", (i || (i = d("I64"))).to_string(a.threadSubtype))
            });
            return function() {
                m.add(b)
            }
        }, [a])
    }

    function f() {
        var a = d("IGDRouteProvider.react").useThreadKeyFromCurrentRoute(),
            b = a != null ? (i || (i = d("I64"))).to_string(a) : null;
        k(function() {
            c("InteractionTracing").getPendingInteractions().forEach(function(a) {
                if (b == null) {
                    a.addAnnotationInt("rendered_direct_null_state", 1);
                    a.addAnnotationInt("has_thread_key", 0);
                    return
                }
                a.addAnnotationInt("has_thread_key", 1);
                a.addAnnotationInt("rendered_direct_null_state", 0)
            })
        }, [b])
    }
    g.getInstamadilloBooleanAnnotations = a;
    g.addInstamadilloAnnotationsToInteractionTrace = l;
    g.useAddInstamadilloAnnotationsToInteractionTraces = b;
    g.useAddThreadAnnotationToInteractionTraces = e;
    g.useAddThreadRouteAnnotations = f
}), 98);
__d("MWGetOriginalEntrypoint", ["I64", "InteractionTracingMetrics", "MWChatInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var b, e = d("MWChatInteraction").get((h || (h = d("I64"))).to_string(a));
        e = e != null ? c("InteractionTracingMetrics").get(e) : null;
        e = (b = e == null ? void 0 : (b = e.annotations.string) == null ? void 0 : b.inboxEntrypoint) != null ? b : e == null ? void 0 : (b = e.annotations.string) == null ? void 0 : b.entrypoint;
        if (e != null && e !== "unknown") return e;
        b = d("MWChatInteraction").get("inbox_init");
        if (b != null && (h || (h = d("I64"))).equal(a, (h || (h = d("I64"))).of_string(b))) return "initInbox";
        e = d("MWChatInteraction").get(d("MWChatInteraction").MW_AUTO_CHAT_TAB_OPEN);
        b = e != null ? (b = c("InteractionTracingMetrics").get(e)) == null ? void 0 : (e = b.annotations.string) == null ? void 0 : e.thread_id : null;
        return b === (h || (h = d("I64"))).to_string(a) ? "auto_open" : "unknown"
    }
    g["default"] = a
}), 98);
__d("MWHasLinksUtil", ["URLMatcher", "isStringNullOrEmpty"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("isStringNullOrEmpty")(a) ? !1 : c("URLMatcher").match(a) != null
    }
    g.getHasLinks = a
}), 98);
__d("MWMsgMediaTypeLogUtils", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("$InternalEnum")({
        Application: "application",
        Audio: "audio",
        Avatar: "avatar",
        HotEmoji: "hot_emoji",
        File: "file",
        Gif: "gif",
        Image: "image",
        Link: "link",
        None: "none",
        Poll: "poll",
        Reaction: "reaction",
        Sticker: "sticker",
        Video: "video",
        Share: "share"
    });

    function a(a) {
        var b = a.hasFile;
        b = b === void 0 ? !1 : b;
        var c = a.hasGif;
        c = c === void 0 ? !1 : c;
        var d = a.hasHotEmoji;
        d = d === void 0 ? !1 : d;
        var e = a.hasImage;
        e = e === void 0 ? !1 : e;
        var f = a.hasLinks;
        f = f === void 0 ? !1 : f;
        var h = a.hasShare;
        h = h === void 0 ? !1 : h;
        var i = a.hasSticker;
        i = i === void 0 ? !1 : i;
        var j = a.hasVideo;
        j = j === void 0 ? !1 : j;
        a = a.hasVoiceClip;
        a = a === void 0 ? !1 : a;
        var k = g.None;
        e ? k = g.Image : j ? k = g.Video : d ? k = g.HotEmoji : i ? k = g.Sticker : c ? k = g.Gif : a ? k = g.Audio : f ? k = g.Link : b ? k = g.File : h && (k = g.Share);
        return k
    }
    f.AttachmentType = g;
    f.getAttachmentType = a
}), 66);
__d("MWVersion", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("I64")).of_string("2");
    g.v2 = a
}), 98);
__d("MWSharedMsgLogUtils", ["$InternalEnum", "I64", "IGDInteractionTraceAnnotations", "LSIntEnum", "LSMessagingThreadAttributionType", "LSMessagingThreadTypeUtil", "MAWEBSwitch", "MWGetOriginalEntrypoint", "MWHasLinksUtil", "MWMsgMediaTypeLogUtils", "MWVersion", "MultipleTabsLogger", "asyncToGeneratorRuntime", "cr:6985", "gkx", "isArmadillo", "isStringNullOrEmpty", "promiseDone", "shouldUseMAWSharedWorker"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = b("$InternalEnum")({
            Send: "send",
            Reaction: "reaction",
            Reply: "reply",
            Forward: "forward",
            Share: "share",
            StoryReply: "story-reply",
            Unsend: "unsend",
            GroupInvite: "group-invite",
            SenderKeyDistribution: "sender-key-distribution",
            EphemeralSetting: "ephemeral-setting"
        }),
        k = b("$InternalEnum")({
            Text: "text",
            NonText: "non-text"
        });

    function l(a, b, c) {
        return m.apply(this, arguments)
    }

    function m() {
        m = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e) {
            var f = a.hasAttachment,
                g = a.hasEphemeralSetting,
                i = a.hasGroupInvite,
                l = a.hasReaction,
                m = a.hasReply,
                n = a.hasSenderKeyDistribution,
                p = a.hasStoryReply,
                q = a.hasText,
                r = a.isUnsend;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["hasAttachment", "hasEphemeralSetting", "hasGroupInvite", "hasReaction", "hasReply", "hasSenderKeyDistribution", "hasStoryReply", "hasText", "isUnsend"]);
            var s = j.Send;
            m ? s = j.Reply : p ? s = j.StoryReply : r ? s = j.Unsend : l ? s = j.Reaction : i ? s = j.GroupInvite : g ? s = j.EphemeralSetting : n && (s = j.SenderKeyDistribution);
            m = d("MWMsgMediaTypeLogUtils").getAttachmentType(a);
            p = q && (!m || m === d("MWMsgMediaTypeLogUtils").AttachmentType.None) ? k.Text : k.NonText;
            return {
                bool: {
                    has_attachment: f,
                    has_sticker: a.hasSticker,
                    is_attachments_grouped: a.isAttachmentsGrouped,
                    is_eb_enabled: c("MAWEBSwitch").isEnabled(),
                    is_pdb: Boolean(c("gkx")("24032")),
                    is_tlc_public_user: c("gkx")("24028"),
                    use_maw_shared_worker: d("shouldUseMAWSharedWorker").shouldUseMAWSharedWorker()
                },
                "int": {
                    number_of_attachments: a.numberOfAttachments,
                    number_of_grouped_attachments: a.numberOfGroupedAttachments
                },
                string: {
                    action_type: s,
                    attachment_type: m,
                    entrypoint: o(b),
                    message_type: p,
                    multipleTabs: yield d("MultipleTabsLogger").getMultipleTabsAnnotation(), mw_version: (h || (h = d("I64"))).to_string(d("MWVersion").v2), root_component: e
                }
            }
        });
        return m.apply(this, arguments)
    }

    function a(a, b, c, d) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f, g) {
            var i = b("cr:6985") != null ? yield b("cr:6985").isCutoverThreadKey(a.threadKey): !1;
            e = (yield l(e, f, g));
            return {
                bool: babelHelpers["extends"]({}, e.bool, d("IGDInteractionTraceAnnotations").getInstamadilloBooleanAnnotations(a), {
                    is_community_event: a.eventStartTimestampMs != null,
                    is_cutover: c("isArmadillo")() && i,
                    is_message_request: d("LSMessagingThreadTypeUtil").isMessageRequest(a),
                    is_secure: d("LSMessagingThreadTypeUtil").isArmadilloSecure(a.threadType)
                }),
                "int": babelHelpers["extends"]({}, e["int"]),
                string: babelHelpers["extends"]({}, e.string, {
                    consistent_thread_fbid: a.consistentThreadFbid != null ? (h || (h = d("I64"))).to_string(a.consistentThreadFbid) : null,
                    original_entrypoint: c("MWGetOriginalEntrypoint")(a.threadKey),
                    thread_id: (h || (h = d("I64"))).to_string(a.threadKey),
                    thread_subtype: a.threadSubtype != null ? (h || (h = d("I64"))).to_string(a.threadSubtype) : null,
                    thread_type: h.to_string(a.threadType)
                })
            }
        });
        return n.apply(this, arguments)
    }

    function e(a, e, f, g) {
        var i = e.hasFile;
        i = i === void 0 ? !1 : i;
        var l = e.hasGif;
        l = l === void 0 ? !1 : l;
        var m = e.hasHotEmoji;
        m = m === void 0 ? !1 : m;
        var n = e.hasImage;
        n = n === void 0 ? !1 : n;
        var o = e.hasLinks;
        o = o === void 0 ? !1 : o;
        var p = e.hasReply;
        p = p === void 0 ? !1 : p;
        var q = e.hasShare;
        q = q === void 0 ? !1 : q;
        var r = e.hasSticker;
        r = r === void 0 ? !1 : r;
        var s = e.hasStoryReply;
        s = s === void 0 ? !1 : s;
        var t = e.hasText;
        t = t === void 0 ? !1 : t;
        var u = e.hasVideo;
        u = u === void 0 ? !1 : u;
        var v = e.hasVoiceClip;
        v = v === void 0 ? !1 : v;
        var w = e.isAttachmentsGrouped,
            x = e.numberOfAttachments;
        x = x === void 0 ? 0 : x;
        e = e.numberOfGroupedAttachments;
        e = e === void 0 ? 0 : e;
        var y = j.Send;
        p ? y = j.Reply : s && (y = j.StoryReply);
        p = d("MWMsgMediaTypeLogUtils").getAttachmentType({
            hasFile: i,
            hasGif: l,
            hasHotEmoji: m,
            hasImage: n,
            hasLinks: o,
            hasShare: q,
            hasSticker: r,
            hasVideo: u,
            hasVoiceClip: v,
            numberOfAttachments: x,
            numberOfGroupedAttachments: e
        });
        s = t && (!p || p === d("MWMsgMediaTypeLogUtils").AttachmentType.None) ? k.Text : k.NonText;
        d("MultipleTabsLogger").addAnnotationWithInteractionUuid(a.getTraceId());
        a.addAnnotation("attachment_type", p);
        a.addAnnotation("action_type", y);
        a.addAnnotation("message_type", s);
        a.addAnnotation("original_entrypoint", c("MWGetOriginalEntrypoint")(f.threadKey));
        g != null && a.addAnnotation("root_component", g);
        a.addAnnotationInt("number_of_attachments", x);
        w != null && a.addAnnotationBoolean("is_attachments_grouped", w);
        a.addAnnotation("thread_id", (h || (h = d("I64"))).to_string(f.threadKey));
        f.consistentThreadFbid != null && a.addAnnotation("consistent_thread_fbid", (h || (h = d("I64"))).to_string(f.consistentThreadFbid));
        a.addAnnotation("thread_type", h.to_string(f.threadType));
        f.threadSubtype != null && a.addAnnotation("thread_subtype", (h || (h = d("I64"))).to_string(f.threadSubtype));
        b("cr:6985") != null && c("promiseDone")(b("cr:6985").isCutoverThreadKey(f.threadKey), function(b) {
            a.addAnnotationBoolean("is_cutover", b)
        });
        d("IGDInteractionTraceAnnotations").addInstamadilloAnnotationsToInteractionTrace(f, a);
        a.addAnnotationBoolean("is_secure", d("LSMessagingThreadTypeUtil").isArmadilloSecure(f.threadType));
        a.addAnnotationBoolean("is_eb_enabled", c("MAWEBSwitch").isEnabled());
        a.addAnnotationBoolean("use_maw_shared_worker", d("shouldUseMAWSharedWorker").shouldUseMAWSharedWorker());
        a.addAnnotationBoolean("is_pdb", Boolean(c("gkx")("24032")))
    }

    function f(a) {
        var b = a.externalAttachmentUrl,
            e = a.hotEmojiSize,
            f = a.isEphemeralSetting,
            g = a.isGroupInvite,
            h = a.isReaction,
            i = a.isSenderKeyDistribution,
            j = a.isUnsend,
            k = a.mediaGroupInfo,
            l = a.mediaStagings,
            m = a.messageText,
            n = a.reply,
            o = a.sentFromShareSheet,
            p = a.stickerId,
            q = a.threadType;
        a = a.voiceClip;
        var r = !c("isStringNullOrEmpty")(m);
        m = d("MWHasLinksUtil").getHasLinks(m);
        var s = !1;
        a = a != null;
        a ? s = !0 : b != null && (s = !0);
        var t = !1,
            u = !1,
            v = !1,
            w = 0,
            x = 0,
            y;
        if (l != null && l.length > 0) {
            s = !0;
            for (var z of l) {
                var A = z.mimeType;
                A.indexOf("image") !== -1 && (t = !0);
                A.indexOf("video") !== -1 && (u = !0);
                A.indexOf("application") !== -1 && (v = !0)
            }
            if (t && q != null) {
                A = d("LSMessagingThreadTypeUtil").isArmadilloSecure(q);
                y = !A || c("gkx")("5318") === !0
            }
            w = l.length
        }
        k != null && (y = !0, x = k.messagesAndAttachments.length);
        z = e != null;
        q = n != null;
        A = n != null;
        l = p != null && !z;
        k = !l && b != null;
        e = o === !0;
        n = h === !0;
        p = g === !0;
        b = f === !0;
        o = i === !0;
        return {
            hasAttachment: s,
            hasEphemeralSetting: b,
            hasFile: v,
            hasGif: k,
            hasGroupInvite: p,
            hasHotEmoji: z,
            hasImage: t,
            hasLinks: m,
            hasReaction: n,
            hasReply: q,
            hasSenderKeyDistribution: o,
            hasShare: e,
            hasSticker: l,
            hasStoryReply: A,
            hasText: r,
            hasVideo: u,
            hasVoiceClip: a,
            isAttachmentsGrouped: y,
            isUnsend: (h = j) != null ? h : !1,
            numberOfAttachments: w,
            numberOfGroupedAttachments: x
        }
    }

    function o(a) {
        var b;
        return (b = Object.keys(c("LSMessagingThreadAttributionType")).find(function(b) {
            return c("LSMessagingThreadAttributionType")[b] === a
        })) != null ? b : "UNKNOWN"
    }

    function p(a) {
        if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(2))) return "media";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(4))) return "audio";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(4096)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(134217728))) return "sticker";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(16384))) return "gif";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(64))) return "file";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1))) return "text";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1024)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(536870912))) return "XMA";
        else return "unknown"
    }
    g.ActionType = j;
    g.MsgType = k;
    g.getSendToSentBaseAnnotations = l;
    g.getSendToSentAnnotations = a;
    g.addSendMessageMetadataForInteractionTrace = e;
    g.getMessageTypeParams = f;
    g.getEntrypointAnnotation = o;
    g.getMessageTypeFromDisplayedContentType = p
}), 98);
__d("MessengerChevronLeftFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M21.884 8.866a1.25 1.25 0 0 1 0 1.768l-7.19 7.19a.25.25 0 0 0 0 .353l7.19 7.19a1.25 1.25 0 0 1-1.768 1.767l-8.25-8.25a1.25 1.25 0 0 1 0-1.768l8.25-8.25a1.25 1.25 0 0 1 1.768 0z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("MessengerChevronRightFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M14.116 27.134a1.25 1.25 0 0 1 0-1.768l7.19-7.19a.25.25 0 0 0 0-.353l-7.19-7.19a1.25 1.25 0 0 1 1.768-1.767l8.25 8.25a1.25 1.25 0 0 1 0 1.768l-8.25 8.25a1.25 1.25 0 0 1-1.768 0z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("FalcoAppUniverse", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        FACEBOOK: 1,
        INSTAGRAM: 2,
        OCULUS: 3
    });
    c = a;
    f["default"] = c
}), 66);
__d("Queue", [], (function(a, b, c, d, e, f) {
    var g = {};
    a = function() {
        function a(a) {
            this._timeout = null, this._interval = (a == null ? void 0 : a.interval) || 0, this._processor = a == null ? void 0 : a.processor, this._queue = [], this._stopped = !0
        }
        var b = a.prototype;
        b._dispatch = function(a) {
            var b = this;
            a === void 0;
            if (this._stopped || this._queue.length === 0) return;
            a = this._processor;
            if (a == null) {
                this._stopped = !0;
                throw new Error("No processor available")
            }
            var c = this._interval;
            if (c != null) a.call(this, this._queue.shift()), this._timeout = setTimeout(function() {
                return b._dispatch()
            }, c);
            else
                while (this._queue.length) a.call(this, this._queue.shift())
        };
        b.enqueue = function(a) {
            this._processor && !this._stopped ? this._processor(a) : this._queue.push(a);
            return this
        };
        b.start = function(a) {
            a && (this._processor = a);
            this._stopped = !1;
            this._dispatch();
            return this
        };
        b.isStarted = function() {
            return !this._stopped
        };
        b.dispatch = function() {
            this._dispatch(!0)
        };
        b.stop = function(a) {
            this._stopped = !0;
            a && this._timeout != null && clearTimeout(this._timeout);
            return this
        };
        b.merge = function(a, b) {
            if (b) {
                (b = this._queue).unshift.apply(b, a._queue)
            } else {
                (b = this._queue).push.apply(b, a._queue)
            }
            a._queue = [];
            this._dispatch();
            return this
        };
        b.getLength = function() {
            return this._queue.length
        };
        a.get = function(b, c) {
            var d;
            b in g ? d = g[b] : d = g[b] = new a(c);
            return d
        };
        a.exists = function(a) {
            return a in g
        };
        a.remove = function(a) {
            return delete g[a]
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("FalcoLoggerTransports", ["AnalyticsCoreData", "Banzai", "ExecutionEnvironment", "FalcoAppUniverse", "FalcoUtils", "ODS", "PersistedQueue", "Queue", "WebSession", "performanceAbsoluteNow", "promiseDone", "requireDeferredForDisplay", "uuidv4"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = c("requireDeferredForDisplay")("TransportSelectingClientSingletonConditional").__setRef("FalcoLoggerTransports"),
        m = 5 * 1024,
        n = (b = (i || (i = c("AnalyticsCoreData"))).max_delay_br_queue) != null ? b : 60 * 1e3,
        o = (e = (i || (i = c("AnalyticsCoreData"))).max_delay_br_queue_immediate) != null ? e : 1e3;
    b = (f = (i || (i = c("AnalyticsCoreData"))).max_delay_br_init_not_complete) != null ? f : 1e3;
    var p = "falco:",
        q = new(c("Queue"))(),
        r = 5e3,
        s = 6e4,
        aa = c("uuidv4")(),
        ba = "ods_web_batch",
        t = new Map(),
        u = new Set(),
        v = new Set(),
        w = d("FalcoUtils").getTaggedBitmap(38),
        x = (e = c("FalcoAppUniverse").cast((i || (i = c("AnalyticsCoreData"))).app_universe)) != null ? e : 1,
        y = [],
        z = 0,
        A = null,
        B = !1,
        C = !1,
        D = !1,
        E = !0,
        F = !1,
        G = Date.now() - s,
        H = 1,
        I = b > n ? b : n,
        J = b;
    Y();
    for (e = (f = (i || (i = c("AnalyticsCoreData"))).stateful_events_list_for_br) != null ? f : [], b = Array.isArray(e), f = 0, e = b ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
        var K;
        if (b) {
            if (f >= e.length) break;
            K = e[f++]
        } else {
            f = e.next();
            if (f.done) break;
            K = f.value
        }
        K = K;
        u.add(K)
    }
    for (f = (K = (i || (i = c("AnalyticsCoreData"))).stateless_non_fb_events_for_br) != null ? K : [], b = Array.isArray(f), e = 0, f = b ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
        if (b) {
            if (e >= f.length) break;
            K = f[e++]
        } else {
            e = f.next();
            if (e.done) break;
            K = e.value
        }
        K = K;
        v.add(K)
    }

    function L() {
        return (i || (i = c("AnalyticsCoreData"))).enable_bladerunner && !(k || (k = c("ExecutionEnvironment"))).isInWorker
    }

    function M(a, b) {
        d("FalcoUtils").bumpODSMetrics(b.item.name, "event.info.streaming.batched", 1);
        var c = b.item.extra.length;
        z + c > m && (clearTimeout(A), N());
        y.push([a, b]);
        z += c
    }

    function N() {
        A = null;
        B = !1;
        var a = y;
        S("event.info.streaming.batch_processing", a.map(function(a) {
            return a[1].item
        }));
        !F ? O(a, "event.non_critical_failure.streaming_init_not_complete") : q.enqueue(function(b) {
            return b.log(a.map(function(a) {
                return a[1].item
            }), function(b) {
                if (!b) {
                    O(a, "event.info.banzai_fallback");
                    return
                }
                P(a, b, "event.info.streaming.enqueued")
            })
        });
        y = [];
        z = 0
    }

    function O(a, b) {
        var c = function() {
            var c, f = a[e],
                g = f[0],
                h = f[1];
            f = h.item;
            d("FalcoUtils").bumpODSMetrics(f.name, b, 1);
            if ((c = f.logCritical) != null ? c : !1) U.logCritical([f], function(a) {
                return g.markItem(h, a)
            });
            else {
                ((c = f.logImmediate) != null ? c : !1) ? U.logImmediately([f], function(a) {
                    return g.markItem(h, a)
                }): U.log([f], function(a) {
                    return g.markItem(h, a)
                })
            }
        };
        for (var e = 0; e < a.length; e++) c();
        return
    }

    function P(a, b, c) {
        for (var e = 0; e < a.length; e++) {
            var f = a[e],
                g = f[0];
            f = f[1];
            d("FalcoUtils").bumpODSMetrics(f.item.name, c, 1);
            g.markItem(f, b)
        }
    }

    function ca(a) {
        return {
            events: a.map(function(a) {
                return {
                    name: a.name,
                    extra: a.extra,
                    rate: a.policy.r,
                    time: a.time / 1e3,
                    tag: 0,
                    tags: a.tags,
                    shouldAddState: a.shouldAddState,
                    identity: Q(a.identity),
                    expTags: a.exptTags,
                    sessionID: a.sessionId,
                    deviceID: a.deviceId
                }
            })
        }
    }

    function da(a) {
        var b;
        a = {
            deviceId: (i || (i = c("AnalyticsCoreData"))).device_id,
            familyDeviceId: null,
            osBuildNumber: null,
            sessionId: a,
            appId: i.app_id,
            appVersion: (a = (i || (i = c("AnalyticsCoreData"))).app_version) != null ? a : null,
            bundleId: null,
            consentState: null,
            identity: null,
            pushPhase: i.push_phase
        };
        ((b = (b = (i || (i = c("AnalyticsCoreData"))).stateful_events_list_for_br) == null ? void 0 : b.length) != null ? b : 0) > 0 && (a.ambientState = (i || (i = c("AnalyticsCoreData"))).state_for_br);
        a.identity = Q(i.identity);
        return Object.freeze(a)
    }

    function Q(a) {
        if (x === 2 || x === 3) {
            var b = a == null ? void 0 : a.appScopedIdentity;
            if (b !== void 0) return {
                appScopedIdentity: {
                    uid: b,
                    identifier: b,
                    claims: []
                }
            }
        } else {
            b = a == null ? void 0 : a.fbIdentity;
            if (b !== void 0) return {
                facebookIdentity: {
                    actorId: b.actorId,
                    accountId: b.accountId,
                    claims: []
                }
            }
        }
        return null
    }

    function R(a, b) {
        for (var e = 0; e < a.length; e++) {
            var f, g, h = a[e];
            f = (g = {}, g.e = h.extra, g.r = h.policy.r, g.d = (f = h.deviceId) != null ? f : (i || (i = c("AnalyticsCoreData"))).device_id, g.s = (f = h.sessionId) != null ? f : d("WebSession").getId(), g.t = h.time, g);
            h.privacyContext && (f.p = h.privacyContext);
            h.tags != null && (f.b = h.tags);
            g = h.identity;
            g && (f.id = g);
            c("Banzai").post(p + h.name, f, b)
        }
        S("event.uploaded", a)
    }

    function S(a, b) {
        for (var c = 0; c < b.length; c++) {
            var e = b[c];
            e.name !== ba && d("FalcoUtils").bumpODSMetrics(e.name, a, 1)
        }
    }

    function T(a, b) {
        var e = "falco.fabric.www." + (i || (i = c("AnalyticsCoreData"))).push_phase;
        (h || (h = d("ODS"))).bumpEntityKey(1344, e, a, b)
    }
    var U = {
        log: function(a, b) {
            S("event.info.banzai.log.upload_processing", a), R(a, c("Banzai").BASIC), b(!0)
        },
        logImmediately: function(a, b) {
            S("event.info.banzai.log_immediately.upload_processing", a), R(a, c("Banzai").VITAL), b(!0)
        },
        logCritical: function(a, b) {
            S("event.info.banzai.log_critical.upload_processing", a), R(a, {
                signal: !0,
                retry: !0
            }), b(!0)
        }
    };

    function ea(a) {
        Y();
        var b = V(a, "banzai_data_loss", "log"),
            d = V(a, "banzai_data_loss", "logImmediately"),
            e = V(a, "banzai_data_loss", "logCritical"),
            f = V(a, "bladerunner_data_loss", ""),
            g = V(a, "bladerunner_data_loss", "logCritical");
        T("js.br_data_loss.posted." + a, 1);
        if (F && E) try {
            q.enqueue(function(b) {
                return b.log([f], function(b) {
                    if (!b) {
                        T("js.br.transport_failure." + a, 1);
                        U.logCritical([g], function(b) {
                            T("js.br.failure_fallback_success_callback." + a, 1)
                        });
                        return
                    }
                    T("js.br.success_callback." + a, 1)
                })
            })
        } catch (b) {
            T("js.br.error_enqueueing." + a, 1), U.logCritical([g], function(b) {
                T("js.br.enqueuing_fallback_success_callback." + a, 1)
            })
        } else E || T("js.br.failed." + a, 1), F || T("js.br.init_not_complete." + a, 1), U.logCritical([g], function(b) {
            T("js.br.init_fallback_success_callback." + a, 1)
        });
        R([b], c("Banzai").BASIC);
        R([d], c("Banzai").VITAL);
        R([e], {
            signal: !0,
            retry: !0
        })
    }

    function V(a, b, d) {
        return {
            name: b,
            time: (j || (j = c("performanceAbsoluteNow")))(),
            policy: {
                r: 1
            },
            extra: JSON.stringify({
                event_index: a,
                falco_js_connection_id: aa,
                logging_mode: d,
                logging_flow_flag: "original_flow"
            })
        }
    }

    function W() {
        G + r < Date.now() && (ea(H), G = Date.now(), H++)
    }

    function X() {
        window.setTimeout(function() {
            W(), H <= 40 && X()
        }, s)
    }

    function fa(a) {
        q.start(function(b) {
            return b({
                log: function(d, b) {
                    S("event.info.streaming.queue_processing", d);
                    var e = JSON.stringify(ca(d));
                    a ? (i || (i = c("AnalyticsCoreData"))).enable_ack ? c("promiseDone")(a.amendWithAck(e), function(a) {
                        a ? (S("event.streamed.with_ack", d), S("event.uploaded", d)) : S("event.non_critical_failure.streaming.ack_failed", d), b(a)
                    }, function() {
                        S("event.non_critical_failure.streaming.ack_rejected", d), b(!1)
                    }) : (a.amendWithoutAck(e), S("event.streamed.without_ack", d), S("event.uploaded", d)) : (S("event.non_critical_error.streaming.stream_not_available", d), b(!1))
                },
                logImmediately: function(b, a) {
                    this.log(b, a)
                },
                logCritical: function(b, a) {
                    this.log(b, a)
                }
            })
        })
    }

    function Y() {
        if (C) return;
        F = !1;
        if (!L()) return;
        l.onReady(function(a) {
            if (!a) {
                E = !1;
                q.start(function(a) {
                    return a(U)
                });
                return
            }
            a = a;
            var b = {
                onTermination: function(a) {
                    a.message === "Stream closed" ? (q.stop(!0), C = !1) : (d("FalcoUtils").bumpODSMetrics("", "streaming.non_critical_failure.rejected", 1), E = !1, q.start(function(a) {
                        return a(U)
                    }))
                },
                onFlowStatus: function() {}
            };
            c("promiseDone")(a.requestStream({
                method: "Falco"
            }, JSON.stringify(da(d("WebSession").getId())), b, {
                requestId: ""
            }).then(function(b) {
                a = b, fa(a), F = !0, I = n, J = o
            })["catch"](function(a) {
                d("FalcoUtils").bumpODSMetrics("", "streaming.non_critical_failure.failed", 1), q.stop(!0), C = !1
            }))
        });
        C = !0
    }

    function Z(a) {
        var b, e = a.name;
        if (!L() || !E) return !1;
        if (u.has(e) || a.policy.s !== 1 && ((b = (i || (i = c("AnalyticsCoreData"))).br_stateful_migration_on) != null ? b : !1)) {
            a.shouldAddState = !0;
            a.tags = d("FalcoUtils").xorBitmap((b = a.tags) != null ? b : [0, 0], w);
            return !0
        }
        if (x !== 1 && (i || (i = c("AnalyticsCoreData"))).enable_non_fb_br_stateless_by_default !== !0 && !v.has(e)) return !1;
        if (a.policy.s === 1) {
            a.tags = d("FalcoUtils").xorBitmap((b = a.tags) != null ? b : [0, 0], w);
            return !0
        }
        return !1
    }

    function $(a) {
        if (a === "") return null;
        if (t.has(a)) return t.get(a);
        else {
            var b = {
                    claim: ""
                },
                c = a.split("^#");
            if (c.length >= 4) {
                var d = c[0],
                    e = c[1],
                    f = c[2];
                c = c[3];
                f !== "" ? b = {
                    appScopedIdentity: f,
                    claim: c
                } : d !== "" && (b = {
                    fbIdentity: {
                        accountId: d,
                        actorId: e
                    },
                    claim: c
                });
                t.set(a, b)
            }
            return b
        }
    }

    function a() {
        if (D) return;
        D = !0;
        c("PersistedQueue").setHandler("falco_queue_log", function(b) {
            var c, e = b.getQueueNameSuffix(),
                f = $(e);
            while (c = b.dequeueItem())(function(c) {
                Z(c.item) ? (d("FalcoUtils").bumpODSMetrics(c.item.name, "event.info.upload_method.streaming.log", 1), Y(), A == null && (A = setTimeout(N, I)), f && !a(e) && (c.item.identity = f), M(b, c)) : (f && (c.item.identity = f), U.log([c.item], function(a) {
                    return b.markItem(c, a)
                }))
            })(c)
        });
        c("PersistedQueue").setHandler("falco_queue_immediately", function(b) {
            var e, f = b.getQueueNameSuffix(),
                g = $(f);
            while (e = b.dequeueItem())(function(e) {
                Z(e.item) ? (d("FalcoUtils").bumpODSMetrics(e.item.name, "event.info.upload_method.streaming.log_immediately", 1), Y(), (A == null || !B) && (clearTimeout(A), A = setTimeout(N, J), B = !0), e.item.logImmediate = !0, g && !a(f) && (e.item.identity = g), M(b, e), c("PersistedQueue").isPersistenceAllowed() || (d("FalcoUtils").bumpODSMetrics(e.item.name, "event.info.streaming_no_persistence.log_immediately", 1), N())) : (d("FalcoUtils").bumpODSMetrics(e.item.name, "event.info.upload_method.banzai.log_immediately", 1), g && (e.item.identity = g), U.logImmediately([e.item], function(a) {
                    return b.markItem(e, a)
                }))
            })(e)
        });
        c("PersistedQueue").setHandler("falco_queue_critical", function(b) {
            var c, e = b.getQueueNameSuffix(),
                f = $(e);
            while (c = b.dequeueItem())(function(c) {
                var g = c.item;
                Z(g) ? (d("FalcoUtils").bumpODSMetrics(c.item.name, "event.info.upload_method.streaming.log_critical", 1), Y(), g.logCritical = !0, !F ? (f && (g.identity = f), O([
                    [b, c]
                ], "event.non_critical_failure.streaming_init_not_complete.log_critical")) : (f && !a(e) && (g.identity = f), q.enqueue(function(a) {
                    return a.logCritical([g], function(a) {
                        if (!a) {
                            !g.identity && f && (g.identity = f);
                            O([
                                [b, c]
                            ], "event.info.banzai_fallback.log_critical");
                            return
                        }
                        P([
                            [b, c]
                        ], a, "event.uploaded")
                    })
                }))) : (f && (g.identity = f), d("FalcoUtils").bumpODSMetrics(c.item.name, "event.info.upload_method.banzai.log_critical", 1), U.logCritical([g], function(a) {
                    return b.markItem(c, a)
                }))
            })(c)
        });
        (i || (i = c("AnalyticsCoreData"))).enable_dataloss_timer && (Y(), W(), X());

        function a(a) {
            try {
                var b = d("FalcoUtils").identityToString((i || (i = c("AnalyticsCoreData"))).identity);
                return a === b
            } catch (a) {
                (h || (h = d("ODS"))).bumpEntityKey(1344, "js.br.identity.check", "exception.when.comparing.with.current.user.identity", 1);
                return !0
            }
        }
    }
    g.attach = a
}), 98);
__d("MAWBridgeTraceEvent", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["ReceivedReceipt", "ReceivedSent", "FlowEndForFailure", "FlowEndForSuccess"]);
    c = a;
    f["default"] = c
}), 66);
__d("TransportSelectingClientSingletonConditional", ["cr:710"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:710")
}), 98); /*FB_PKG_DELIM*/
__d("CometCompositeFocusIndicator.react", ["fbt", "BaseFocusRing.react", "CometComponentWithKeyCommands.react", "CometCompositeStructureContext", "CometKeys", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useMemo;

    function a(a) {
        var b = a.children,
            d = a.compositeInfo,
            e = a.elementType;
        a = a.suppressFocusRing;
        var f = k(function() {
            var a = [];
            d.horizontal === !0 && a.push({
                command: {
                    key: c("CometKeys").RIGHT
                },
                description: h._("__JHASH__1VqMgLPpraa__JHASH__"),
                handler: function() {}
            }, {
                command: {
                    key: c("CometKeys").LEFT
                },
                description: h._("__JHASH__7zajSsSIBFZ__JHASH__"),
                handler: function() {}
            });
            d.vertical === !0 && a.push({
                command: {
                    key: c("CometKeys").UP
                },
                description: h._("__JHASH__1VqMgLPpraa__JHASH__"),
                handler: function() {}
            }, {
                command: {
                    key: c("CometKeys").DOWN
                },
                description: h._("__JHASH__7zajSsSIBFZ__JHASH__"),
                handler: function() {}
            });
            return a
        }, [d]);
        return j.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: f,
            debugName: "composite-role_" + (d.role || ""),
            elementType: e,
            children: j.jsx(c("CometCompositeStructureContext").Provider, {
                value: d,
                children: j.jsx(c("BaseFocusRing.react"), {
                    suppressFocusRing: a,
                    children: function(a) {
                        return b(a)
                    }
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("CometFocusGroup.react", ["CometCompositeFocusIndicator.react", "CometFocusGroupContext", "FocusGroup.react", "focusScopeQueries", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;
    b = d("FocusGroup.react").createFocusGroup(d("focusScopeQueries").tabbableScopeQuery);
    var k = b[0],
        l = b[1];

    function a(a) {
        var b = a.children,
            d = a.hideArrowSignifiers,
            e = a.role,
            f = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "hideArrowSignifiers", "role"]),
            g = j(function() {
                return {
                    FocusContainer: k,
                    FocusItem: l
                }
            }, []),
            h = j(function() {
                return {
                    hideArrowSignifiers: d === !0,
                    horizontal: a.orientation !== "vertical",
                    role: e,
                    vertical: a.orientation !== "horizontal"
                }
            }, [d, a.orientation, e]);
        return i.jsx(c("CometCompositeFocusIndicator.react"), {
            compositeInfo: h,
            children: function(a) {
                return i.jsx(c("CometFocusGroupContext").Provider, {
                    value: g,
                    children: i.jsx(k, babelHelpers["extends"]({}, f, {
                        children: b(a)
                    }))
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometLiveResolverStore", ["relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.Store = d("relay-runtime").Store, g.RecordSource = d("relay-runtime").RecordSource
}), 98);
__d("CometRelayEnvironmentProvider", ["CometRelay", "CometRelayEnvironment", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.children;
        a = a.environment;
        return i.jsx(d("CometRelay").RelayEnvironmentProvider, {
            environment: a || c("CometRelayEnvironment"),
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometRelayEnvironmentWWW", ["CometRelayEnvironmentFactory"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("CometRelayEnvironmentFactory").CometRelayEnvironmentFactory.defaultEnvironment
}), 98);
__d("CometRelayScheduler", ["gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).startTransition;
    a = c("gkx")("2442") ? {
        cancel: function() {},
        schedule: function(a, b) {
            b === "low" ? i(a) : a();
            return ""
        }
    } : {
        cancel: function() {},
        schedule: function(a) {
            i(a);
            return ""
        }
    };
    g["default"] = a
}), 98);
__d("ErrorSetup", ["fb-error"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("fb-error").ErrorSetup
}), 98);
__d("JavascriptWebErrorFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1828905");
    b = d("FalcoLoggerInternal").create("javascript_web_error", a);
    e = b;
    g["default"] = e
}), 98);
__d("ErrorTransport", ["JavascriptWebErrorFalcoEvent"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        c("JavascriptWebErrorFalcoEvent").log(function() {
            return a
        })
    }
    g.log = a
}), 98);
__d("IntlCLDRNumberType05", ["IntlVariations"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getVariation: function(a) {
            if (a === 1) return c("IntlVariations").NUMBER_ONE;
            else return c("IntlVariations").NUMBER_OTHER
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("SecuredActionBlockDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6108889802569432"
}), null);
__d("SecuredActionBlockDialogQuery$Parameters", ["SecuredActionBlockDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionBlockDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionBlockDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionBlockDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionBlockDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionBlockDialogQuery$Parameters"),
                        variables: {
                            accountType: "FACEBOOK"
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionBlockDialog.react").__setRef("SecuredActionBlockDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionChallengeCDSPasswordDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8355842131166910"
}), null);
__d("SecuredActionChallengeCDSPasswordDialogQuery$Parameters", ["SecuredActionChallengeCDSPasswordDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionChallengeCDSPasswordDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionChallengeCDSPasswordDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionChallengeCDSPasswordDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionChallengeCDSPasswordDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionChallengeCDSPasswordDialogQuery$Parameters"),
                        variables: {
                            account_id: a.account_id,
                            category_name: a.category_name
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionChallengeCDSPasswordDialog.react").__setRef("SecuredActionChallengeCDSPasswordDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionChallengePasswordDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8171723236271662"
}), null);
__d("SecuredActionChallengePasswordDialogQuery$Parameters", ["SecuredActionChallengePasswordDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionChallengePasswordDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionChallengePasswordDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionChallengePasswordDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionChallengePasswordDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionChallengePasswordDialogQuery$Parameters"),
                        variables: {
                            height: 60,
                            scale: 1,
                            width: 60
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionChallengePasswordDialog.react").__setRef("SecuredActionChallengePasswordDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("TwoStepVerificationFlow", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        LOGIN_CHALLENGES: "login_challenges",
        SECURED_ACTION: "secured_action",
        TWO_FACTOR_LOGIN: "two_factor_login",
        PRE_AUTHENTICATION: "pre_authentication"
    });
    c = a;
    f["default"] = c
}), 66);
__d("TwoStepVerificationRootQuery$Parameters", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: "7956533077718689",
            metadata: {},
            name: "TwoStepVerificationRootQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionDialogRoot.entrypoint", ["JSResourceForInteraction", "TwoStepVerificationRootQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            return {
                queries: {
                    query: {
                        parameters: c("TwoStepVerificationRootQuery$Parameters"),
                        variables: {
                            encryptedContext: a.encryptedContext,
                            isLoginChallenges: a.flow === "login_challenges",
                            isPreAuthentication: a.flow === "pre_authentication"
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("TwoStepVerificationRoot.react").__setRef("SecuredActionDialogRoot.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionNoChallengeAvailableCDSDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7620111951371116"
}), null);
__d("SecuredActionNoChallengeAvailableCDSDialogQuery$Parameters", ["SecuredActionNoChallengeAvailableCDSDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionNoChallengeAvailableCDSDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionNoChallengeAvailableCDSDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionNoChallengeAvailableCDSDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionNoChallengeAvailableCDSDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionNoChallengeAvailableCDSDialogQuery$Parameters"),
                        variables: {}
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionNoChallengeAvailableCDSDialog.react").__setRef("SecuredActionNoChallengeAvailableCDSDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionReauthDialog.entrypoint", ["JSResourceForInteraction", "TwoStepVerificationRootQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            a = a.encryptedContext;
            return {
                queries: {
                    query: {
                        parameters: c("TwoStepVerificationRootQuery$Parameters"),
                        variables: {
                            encryptedContext: a,
                            isLoginChallenges: !1,
                            isPreAuthentication: !1
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("TwoStepVerificationRoot.react").__setRef("SecuredActionReauthDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "Re-authentication canceled.";

    function a(a) {
        return (a == null ? void 0 : a.message) === g
    }
    f.SECURED_ACTION_REAUTH_CANCELED_ERROR = g;
    f.isSecuredActionError = a
}), 66);
__d("securedActionChallengeToEntrypoints", ["SecuredActionBlockDialog.entrypoint", "SecuredActionChallengeCDSPasswordDialog.entrypoint", "SecuredActionChallengePasswordDialog.entrypoint", "SecuredActionNoChallengeAvailableCDSDialog.entrypoint", "SecuredActionReauthDialog.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a) {
            case "block":
                return {
                    CDS: c("SecuredActionBlockDialog.entrypoint"),
                    "default": c("SecuredActionBlockDialog.entrypoint")
                };
            case "no_challenge_available":
                return {
                    CDS: c("SecuredActionNoChallengeAvailableCDSDialog.entrypoint"),
                    "default": c("SecuredActionNoChallengeAvailableCDSDialog.entrypoint")
                };
            case "password":
                return {
                    CDS: c("SecuredActionChallengeCDSPasswordDialog.entrypoint"),
                    "default": c("SecuredActionChallengePasswordDialog.entrypoint")
                };
            case "captcha_cardnumber":
            case "captcha_comment":
            case "captcha_email":
            case "captcha_security_key":
            case "captcha_sms":
            case "captcha_smsscarce":
            case "captcha_templar":
            case "captcha_whatsapp":
            case "captcha_work_email":
            case "established_device":
            case "fido":
            case "first_factor":
            case "mfs_totp":
            case "mwa_business":
            case "password_continue_only":
            case "password_redirect":
            case "post_login_delta":
            case "reauth":
            case "step_up":
            case "test":
            case "two_fac_with_password_fallback":
            case "2fac":
            case "2fac_for_biz":
            case "2fac_setup":
            case "work_sso":
            case "work_sso_embedded":
                return null
        }
    }

    function b(a) {
        switch (a) {
            case "reauth":
                return {
                    CDS: c("SecuredActionReauthDialog.entrypoint"),
                    "default": c("SecuredActionReauthDialog.entrypoint")
                };
            case "block":
            case "captcha_cardnumber":
            case "captcha_comment":
            case "captcha_email":
            case "captcha_security_key":
            case "captcha_sms":
            case "captcha_smsscarce":
            case "captcha_templar":
            case "captcha_whatsapp":
            case "captcha_work_email":
            case "established_device":
            case "fido":
            case "first_factor":
            case "mfs_totp":
            case "mwa_business":
            case "no_challenge_available":
            case "password":
            case "password_continue_only":
            case "password_redirect":
            case "post_login_delta":
            case "step_up":
            case "test":
            case "two_fac_with_password_fallback":
            case "2fac":
            case "2fac_for_biz":
            case "2fac_setup":
            case "work_sso":
            case "work_sso_embedded":
                return null
        }
    }
    g.securedActionChallengeToEntrypointsWithAccountID = a;
    g.securedActionChallengeToEntrypointsWithEncryptedContext = b
}), 98);
__d("securedActionTriggerChallenge", ["CometErrorOverlay", "CometRelayEnvironmentProvider", "CometTransientDialogProvider.react", "FBLogger", "OutsideExceptionKeyCommandListener.react", "SecuredActionDialogRoot.entrypoint", "deferredLoadComponent", "react", "requireDeferredForDisplay", "securedActionChallengeToEntrypoints"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferredForDisplay")("SecuredActionTriggerWithEncryptedContext.react").__setRef("securedActionTriggerChallenge")),
        k = c("deferredLoadComponent")(c("requireDeferredForDisplay")("SecuredActionTriggerWithAccountID.react").__setRef("securedActionTriggerChallenge"));

    function l() {
        var a;
        return (a = document.location.href) == null ? void 0 : a.includes("accountscenter")
    }

    function m(a) {
        return l() ? a.CDS || a["default"] : a["default"]
    }

    function n(a) {
        return l() ? a.CDS || a["default"] : a["default"]
    }

    function a(a, b) {
        a.challenge_type === "2fac" ? r(b, a) : o(b, a)
    }

    function o(a, b) {
        return s(a, function(a) {
            var c = a.onCancel,
                d = a.onExit,
                e = a.onFailure;
            a = a.onSuccess;
            var f = b.challenge_type;
            switch (f) {
                case "reauth":
                    return p(f, b, d, a);
                default:
                    return q(f, b, d, a, c, e)
            }
        })
    }

    function p(a, b, e, f) {
        var g = d("securedActionChallengeToEntrypoints").securedActionChallengeToEntrypointsWithEncryptedContext(a);
        if (g === null) {
            e();
            throw c("FBLogger")("secured_action").mustfixThrow('unsuported challenge type "%s"', a)
        }
        return i.jsx(j, {
            encryptedContext: (a = b.encrypted_context) != null ? a : "",
            entrypoint: n(g),
            flow: "secured_action",
            onExit: e,
            onSuccess: f
        })
    }
    p.displayName = p.name + " [from " + f.id + "]";

    function q(a, b, e, f, g, h) {
        var j = d("securedActionChallengeToEntrypoints").securedActionChallengeToEntrypointsWithAccountID(a);
        if (j === null) {
            e();
            throw c("FBLogger")("secured_action").mustfixThrow('unsuported challenge type "%s"', a)
        }
        return i.jsx(k, {
            accountID: b.account_id,
            categoryName: b.category_name,
            entrypoint: m(j),
            onCancel: g,
            onExit: e,
            onFailure: h,
            onSuccess: f
        })
    }
    q.displayName = q.name + " [from " + f.id + "]";

    function r(a, b) {
        return s(a, function(a) {
            var d = a.onExit;
            a = a.onSuccess;
            var e = b.encrypted_context;
            if (e === void 0) {
                d();
                throw c("FBLogger")("secured_action").mustfixThrow("two_factor challenge was thrown without a context")
            }
            return i.jsx(j, {
                encryptedContext: e,
                entrypoint: c("SecuredActionDialogRoot.entrypoint"),
                flow: "secured_action",
                onExit: d,
                onSuccess: a
            })
        })
    }

    function s(a, b) {
        var e = a.onCancel,
            f = a.onExit,
            g = a.onFailure,
            h = a.onSuccess;
        return d("CometErrorOverlay").injectComponent(function(a) {
            return i.jsx(c("CometRelayEnvironmentProvider"), {
                children: i.jsx(c("OutsideExceptionKeyCommandListener.react"), {
                    children: i.jsx(c("CometTransientDialogProvider.react"), {
                        children: b({
                            onCancel: function() {
                                e == null ? void 0 : e()
                            },
                            onExit: function() {
                                f(), a()
                            },
                            onFailure: function() {
                                g == null ? void 0 : g()
                            },
                            onSuccess: function() {
                                h(), a()
                            }
                        })
                    })
                })
            })
        })
    }
    g["default"] = a
}), 98);
__d("handleCometReauthenticationSideEffects", ["errorCode", "FBLogger", "SecuredActionUtils", "cr:5888", "err", "securedActionTriggerChallenge"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = new Set(),
        j = new Set();

    function k() {
        var a = c("err")(d("SecuredActionUtils").SECURED_ACTION_REAUTH_CANCELED_ERROR);
        a.type = "info";
        for (var b = j, e = Array.isArray(b), f = 0, b = e ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g;
            if (e) {
                if (f >= b.length) break;
                g = b[f++]
            } else {
                f = b.next();
                if (f.done) break;
                g = f.value
            }
            g = g;
            g = g.onError;
            g(a)
        }
    }

    function l() {
        for (var a = j, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var d;
            if (b) {
                if (c >= a.length) break;
                d = a[c++]
            } else {
                c = a.next();
                if (c.done) break;
                d = c.value
            }
            d = d;
            d = d.onSuccess;
            d()
        }
    }

    function m(a) {
        try {
            return JSON.parse(a)
        } catch (a) {
            a instanceof Error && c("FBLogger")("secured_action").catching(a)
        }
        return {
            account_id: "",
            challenge_type: "password"
        }
    }

    function a(a, d, e) {
        var f, g = a == null ? void 0 : a.source,
            h = (f = (f = g == null ? void 0 : g.errorCode) != null ? f : g == null ? void 0 : g.code) != null ? f : g == null ? void 0 : g.error;
        if (h !== 2136001 && h !== 3490037) return !1;
        j.add({
            onError: e,
            onSuccess: d
        });
        if (i.has(h)) return !0;
        i.add(h);
        var n = function() {
            i["delete"](h), j.clear()
        };
        f = b("cr:5888") == null ? void 0 : b("cr:5888")({
            error: a,
            onCleanup: n,
            onError: k,
            onSuccess: l
        });
        if (f === !0) return !0;
        try {
            d = m((e = g == null ? void 0 : g.description) != null ? e : "");
            c("securedActionTriggerChallenge")(d, {
                onExit: function() {
                    k(), n()
                },
                onSuccess: function() {
                    l(), n()
                }
            })
        } catch (a) {
            i["delete"](h);
            if (a instanceof Error) throw c("FBLogger")("secured_action").mustfixThrow("Something when wrong while triggering the dialog: %s", a.message);
            return !1
        }
        return !0
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
/**
 * License: https://www.facebook.com/legal/license/V9vdYColc4k/
 */
__d("react-0.0.0", ["React"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a && typeof a === "object" && "default" in a ? a["default"] : a
    }
    var g = a(b("React"));
    d = {};
    var h = {
        exports: d
    };

    function i() {
        h.exports = g
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }

    function c(a) {
        switch (a) {
            case void 0:
                return k()
        }
    }
    e.exports = c
}), null);
__d("react", ["react-0.0.0"], (function(a, b, c, d, e, f) {
    e.exports = b("react-0.0.0")()
}), null);
/**
 * License: https://www.facebook.com/legal/license/t3hOLs8wlXy/
 */
__d("resize-observer-polyfill-1.5.1", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {},
        h = {
            exports: g
        };

    function i() {
        (function(b, c) {
            typeof g === "object" && typeof h !== "undefined" ? h.exports = c() : b.ResizeObserver = c()
        })(this, function() {
            var b = function() {
                    if (typeof Map !== "undefined") return Map;

                    function a(a, b) {
                        var c = -1;
                        a.some(function(d, a) {
                            if (d[0] === b) {
                                c = a;
                                return !0
                            }
                            return !1
                        });
                        return c
                    }
                    return function() {
                        function b() {
                            this.__entries__ = []
                        }
                        Object.defineProperty(b.prototype, "size", {
                            get: function() {
                                return this.__entries__.length
                            },
                            enumerable: !0,
                            configurable: !0
                        });
                        b.prototype.get = function(b) {
                            b = a(this.__entries__, b);
                            b = this.__entries__[b];
                            return b && b[1]
                        };
                        b.prototype.set = function(c, d) {
                            var b = a(this.__entries__, c);
                            ~b ? this.__entries__[b][1] = d : this.__entries__.push([c, d])
                        };
                        b.prototype["delete"] = function(b) {
                            var c = this.__entries__;
                            b = a(c, b);
                            ~b && c.splice(b, 1)
                        };
                        b.prototype.has = function(b) {
                            return !!~a(this.__entries__, b)
                        };
                        b.prototype.clear = function() {
                            this.__entries__.splice(0)
                        };
                        b.prototype.forEach = function(a, b) {
                            b === void 0 && (b = null);
                            for (var c = 0, d = this.__entries__; c < d.length; c++) {
                                var e = d[c];
                                a.call(b, e[1], e[0])
                            }
                        };
                        return b
                    }()
                }(),
                c = typeof window !== "undefined" && typeof document !== "undefined" && window.document === document,
                d = function() {
                    if (typeof a !== "undefined" && a.Math === Math) return a;
                    if (typeof self !== "undefined" && self.Math === Math) return self;
                    return typeof window !== "undefined" && window.Math === Math ? window : Function("return this")()
                }(),
                e = function() {
                    return typeof requestAnimationFrame === "function" ? requestAnimationFrame.bind(d) : function(a) {
                        return setTimeout(function() {
                            return a(Date.now())
                        }, 1e3 / 60)
                    }
                }(),
                f = 2;

            function g(a, b) {
                var c = !1,
                    d = !1,
                    g = 0;

                function h() {
                    c && (c = !1, a()), d && j()
                }

                function i() {
                    e(h)
                }

                function j() {
                    var a = Date.now();
                    if (c) {
                        if (a - g < f) return;
                        d = !0
                    } else c = !0, d = !1, setTimeout(i, b);
                    g = a
                }
                return j
            }
            var h = 20,
                i = ["top", "right", "bottom", "left", "width", "height", "size", "weight"],
                j = typeof MutationObserver !== "undefined",
                k = function() {
                    function a() {
                        this.connected_ = !1, this.mutationEventsAdded_ = !1, this.mutationsObserver_ = null, this.observers_ = [], this.onTransitionEnd_ = this.onTransitionEnd_.bind(this), this.refresh = g(this.refresh.bind(this), h)
                    }
                    a.prototype.addObserver = function(a) {
                        ~this.observers_.indexOf(a) || this.observers_.push(a), this.connected_ || this.connect_()
                    };
                    a.prototype.removeObserver = function(b) {
                        var a = this.observers_;
                        b = a.indexOf(b);
                        ~b && a.splice(b, 1);
                        !a.length && this.connected_ && this.disconnect_()
                    };
                    a.prototype.refresh = function() {
                        var a = this.updateObservers_();
                        a && this.refresh()
                    };
                    a.prototype.updateObservers_ = function() {
                        var a = this.observers_.filter(function(a) {
                            return a.gatherActive(), a.hasActive()
                        });
                        a.forEach(function(a) {
                            return a.broadcastActive()
                        });
                        return a.length > 0
                    };
                    a.prototype.connect_ = function() {
                        if (!c || this.connected_) return;
                        document.addEventListener("transitionend", this.onTransitionEnd_);
                        window.addEventListener("resize", this.refresh);
                        j ? (this.mutationsObserver_ = new MutationObserver(this.refresh), this.mutationsObserver_.observe(document, {
                            attributes: !0,
                            childList: !0,
                            characterData: !0,
                            subtree: !0
                        })) : (document.addEventListener("DOMSubtreeModified", this.refresh), this.mutationEventsAdded_ = !0);
                        this.connected_ = !0
                    };
                    a.prototype.disconnect_ = function() {
                        if (!c || !this.connected_) return;
                        document.removeEventListener("transitionend", this.onTransitionEnd_);
                        window.removeEventListener("resize", this.refresh);
                        this.mutationsObserver_ && this.mutationsObserver_.disconnect();
                        this.mutationEventsAdded_ && document.removeEventListener("DOMSubtreeModified", this.refresh);
                        this.mutationsObserver_ = null;
                        this.mutationEventsAdded_ = !1;
                        this.connected_ = !1
                    };
                    a.prototype.onTransitionEnd_ = function(a) {
                        a = a.propertyName;
                        var b = a === void 0 ? "" : a;
                        a = i.some(function(a) {
                            return !!~b.indexOf(a)
                        });
                        a && this.refresh()
                    };
                    a.getInstance = function() {
                        this.instance_ || (this.instance_ = new a());
                        return this.instance_
                    };
                    a.instance_ = null;
                    return a
                }(),
                l = function(a, b) {
                    for (var c = 0, d = Object.keys(b); c < d.length; c++) {
                        var e = d[c];
                        Object.defineProperty(a, e, {
                            value: b[e],
                            enumerable: !1,
                            writable: !1,
                            configurable: !0
                        })
                    }
                    return a
                },
                m = function(a) {
                    a = a && a.ownerDocument && a.ownerDocument.defaultView;
                    return a || d
                },
                n = x(0, 0, 0, 0);

            function o(a) {
                return parseFloat(a) || 0
            }

            function p(a) {
                var b = [];
                for (var c = 1; c < arguments.length; c++) b[c - 1] = arguments[c];
                return b.reduce(function(b, c) {
                    c = a["border-" + c + "-width"];
                    return b + o(c)
                }, 0)
            }

            function q(a) {
                var b = ["top", "right", "bottom", "left"],
                    c = {};
                for (var d = 0, b = b; d < b.length; d++) {
                    var e = b[d],
                        f = a["padding-" + e];
                    c[e] = o(f)
                }
                return c
            }

            function r(a) {
                a = a.getBBox();
                return x(0, 0, a.width, a.height)
            }

            function s(a) {
                var b = a.clientWidth,
                    c = a.clientHeight;
                if (!b && !c) return n;
                var d = m(a).getComputedStyle(a),
                    e = q(d),
                    f = e.left + e.right,
                    g = e.top + e.bottom,
                    h = o(d.width),
                    i = o(d.height);
                d.boxSizing === "border-box" && (Math.round(h + f) !== b && (h -= p(d, "left", "right") + f), Math.round(i + g) !== c && (i -= p(d, "top", "bottom") + g));
                if (!u(a)) {
                    d = Math.round(h + f) - b;
                    a = Math.round(i + g) - c;
                    Math.abs(d) !== 1 && (h -= d);
                    Math.abs(a) !== 1 && (i -= a)
                }
                return x(e.left, e.top, h, i)
            }
            var t = function() {
                return typeof SVGGraphicsElement !== "undefined" ? function(a) {
                    return a instanceof m(a).SVGGraphicsElement
                } : function(a) {
                    return a instanceof m(a).SVGElement && typeof a.getBBox === "function"
                }
            }();

            function u(a) {
                return a === m(a).document.documentElement
            }

            function v(a) {
                if (!c) return n;
                return t(a) ? r(a) : s(a)
            }

            function w(a) {
                var b = a.x,
                    c = a.y,
                    d = a.width;
                a = a.height;
                var e = typeof DOMRectReadOnly !== "undefined" ? DOMRectReadOnly : Object;
                e = Object.create(e.prototype);
                l(e, {
                    x: b,
                    y: c,
                    width: d,
                    height: a,
                    top: c,
                    right: b + d,
                    bottom: a + c,
                    left: b
                });
                return e
            }

            function x(a, b, c, d) {
                return {
                    x: a,
                    y: b,
                    width: c,
                    height: d
                }
            }
            var y = function() {
                    function a(a) {
                        this.broadcastWidth = 0, this.broadcastHeight = 0, this.contentRect_ = x(0, 0, 0, 0), this.target = a
                    }
                    a.prototype.isActive = function() {
                        var a = v(this.target);
                        this.contentRect_ = a;
                        return a.width !== this.broadcastWidth || a.height !== this.broadcastHeight
                    };
                    a.prototype.broadcastRect = function() {
                        var a = this.contentRect_;
                        this.broadcastWidth = a.width;
                        this.broadcastHeight = a.height;
                        return a
                    };
                    return a
                }(),
                z = function() {
                    function a(a, b) {
                        b = w(b);
                        l(this, {
                            target: a,
                            contentRect: b
                        })
                    }
                    return a
                }(),
                A = function() {
                    function a(a, c, d) {
                        this.activeObservations_ = [];
                        this.observations_ = new b();
                        if (typeof a !== "function") throw new TypeError("The callback provided as parameter 1 is not a function.");
                        this.callback_ = a;
                        this.controller_ = c;
                        this.callbackCtx_ = d
                    }
                    a.prototype.observe = function(a) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if (typeof Element === "undefined" || !(Element instanceof Object)) return;
                        if (!(a instanceof m(a).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                        var b = this.observations_;
                        if (b.has(a)) return;
                        b.set(a, new y(a));
                        this.controller_.addObserver(this);
                        this.controller_.refresh()
                    };
                    a.prototype.unobserve = function(a) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if (typeof Element === "undefined" || !(Element instanceof Object)) return;
                        if (!(a instanceof m(a).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                        var b = this.observations_;
                        if (!b.has(a)) return;
                        b["delete"](a);
                        b.size || this.controller_.removeObserver(this)
                    };
                    a.prototype.disconnect = function() {
                        this.clearActive(), this.observations_.clear(), this.controller_.removeObserver(this)
                    };
                    a.prototype.gatherActive = function() {
                        var a = this;
                        this.clearActive();
                        this.observations_.forEach(function(b) {
                            b.isActive() && a.activeObservations_.push(b)
                        })
                    };
                    a.prototype.broadcastActive = function() {
                        if (!this.hasActive()) return;
                        var a = this.callbackCtx_,
                            b = this.activeObservations_.map(function(a) {
                                return new z(a.target, a.broadcastRect())
                            });
                        this.callback_.call(a, b, a);
                        this.clearActive()
                    };
                    a.prototype.clearActive = function() {
                        this.activeObservations_.splice(0)
                    };
                    a.prototype.hasActive = function() {
                        return this.activeObservations_.length > 0
                    };
                    return a
                }(),
                B = typeof WeakMap !== "undefined" ? new WeakMap() : new b(),
                C = function() {
                    function a(b) {
                        if (!(this instanceof a)) throw new TypeError("Cannot call a class as a function.");
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        var c = k.getInstance(),
                            d = new A(b, c, this);
                        B.set(this, d)
                    }
                    return a
                }();
            ["observe", "unobserve", "disconnect"].forEach(function(a) {
                C.prototype[a] = function() {
                    var b;
                    return (b = B.get(this))[a].apply(b, arguments)
                }
            });
            var D = function() {
                return typeof d.ResizeObserver !== "undefined" ? d.ResizeObserver : C
            }();
            return D
        })
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }

    function b(a) {
        switch (a) {
            case void 0:
                return k()
        }
    }
    e.exports = b
}), null);
/**
 * License: https://www.facebook.com/legal/license/t3hOLs8wlXy/
 */
__d("styleq-0.1.3", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {},
        h = {
            exports: g
        };

    function i() {
        Object.defineProperty(g, "__esModule", {
            value: !0
        });
        g.styleq = void 0;
        var a = new WeakMap(),
            b = "$$css";

        function c(c) {
            var d, e, f;
            c != null && (d = c.disableCache === !0, e = c.disableMix === !0, f = c.transform);
            return function() {
                var c = [],
                    g = "",
                    h = null,
                    i = d ? null : a,
                    j = new Array(arguments.length);
                for (var k = 0; k < arguments.length; k++) j[k] = arguments[k];
                while (j.length > 0) {
                    var l = j.pop();
                    if (l == null || l === !1) continue;
                    if (Array.isArray(l)) {
                        for (var m = 0; m < l.length; m++) j.push(l[m]);
                        continue
                    }
                    var n = f != null ? f(l) : l;
                    if (n.$$css) {
                        var o = "";
                        if (i != null && i.has(n)) {
                            var p = i.get(n);
                            p != null && (o = p[0], c.push.apply(c, p[1]), i = p[2])
                        } else {
                            var q = [];
                            for (var r in n) {
                                var s = n[r];
                                if (r === b) continue;
                                (typeof s === "string" || s === null) && (c.includes(r) || (c.push(r), i != null && q.push(r), typeof s === "string" && (o += o ? " " + s : s)))
                            }
                            if (i != null) {
                                var t = new WeakMap();
                                i.set(n, [o, q, t]);
                                i = t
                            }
                        }
                        o && (g = g ? o + " " + g : o)
                    } else if (e) h == null && (h = {}), h = Object.assign({}, n, h);
                    else {
                        var u = null;
                        for (var v in n) {
                            var w = n[v];
                            w !== void 0 && (c.includes(v) || (w != null && (h == null && (h = {}), u == null && (u = {}), u[v] = w), c.push(v), i = null))
                        }
                        u != null && (h = Object.assign(u, h))
                    }
                }
                var x = [g, h];
                return x
            }
        }
        var d = c();
        g.styleq = d;
        d.factory = c
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }
    b = {};
    var l = {
        exports: b
    };

    function m() {
        l.exports = k()
    }
    var n = !1;

    function o() {
        n || (n = !0, m());
        return l.exports
    }

    function a(a) {
        switch (a) {
            case void 0:
                return o()
        }
    }
    e.exports = a
}), null);
__d("styleq", ["styleq-0.1.3"], (function(a, b, c, d, e, f) {
    e.exports = b("styleq-0.1.3")()
}), null);
/**
 * License: https://www.facebook.com/legal/license/CCT5pM3qiNk/
 */
__d("tweetnacl-auth-1.0.1", ["tweetnacl-1.0.3"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("tweetnacl-1.0.3");
    c = {};
    var h = {
        exports: c
    };

    function i() {
        (function(a, b) {
            typeof h !== "undefined" && h.exports ? h.exports = b(g()) : a.nacl.auth = b(a.nacl)
        })(this, function(a) {
            if (!a) throw new Error("tweetnacl not loaded");
            var b = 128,
                c = 64;

            function d(d, e) {
                var f = new Uint8Array(b + Math.max(c, d.length)),
                    g;
                e.length > b && (e = a.hash(e));
                for (g = 0; g < b; g++) f[g] = 54;
                for (g = 0; g < e.length; g++) f[g] ^= e[g];
                f.set(d, b);
                d = a.hash(f.subarray(0, b + d.length));
                for (g = 0; g < b; g++) f[g] = 92;
                for (g = 0; g < e.length; g++) f[g] ^= e[g];
                f.set(d, b);
                return a.hash(f.subarray(0, b + d.length))
            }

            function e(a, b) {
                var c = new Uint8Array(32);
                c.set(d(a, b).subarray(0, 32));
                return c
            }
            e.full = function(a, b) {
                return d(a, b)
            };
            e.authLength = 32;
            e.authFullLength = 64;
            e.keyLength = 32;
            return e
        })
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }

    function a(a) {
        switch (a) {
            case void 0:
                return k()
        }
    }
    e.exports = a
}), null);
__d("tweetnacl-auth", ["tweetnacl-auth-1.0.1"], (function(a, b, c, d, e, f) {
    e.exports = b("tweetnacl-auth-1.0.1")()
}), null); /*FB_PKG_DELIM*/
__d("Int64Hooks", ["I64", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    f = h || d("react");
    var j = f.useCallback,
        k = f.useEffect,
        l = f.useMemo;

    function m(a) {
        var b = [];
        for (var a = a, c = Array.isArray(a), d = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var e;
            if (c) {
                if (d >= a.length) break;
                e = a[d++]
            } else {
                d = a.next();
                if (d.done) break;
                e = d.value
            }
            e = e;
            Array.isArray(e) && e.length === 2 && Number.isInteger(e[0]) && Number.isInteger(e[1]) ? b.push(e[0], e[1]) : b.push(e, void 0)
        }
        return b
    }

    function a(a, b) {
        return k(a, b == null ? null : m(b))
    }

    function b(a, b) {
        return j(a, b == null ? null : m(b))
    }

    function n(a, b) {
        return l(a, b == null ? null : m(b))
    }

    function c(a, b) {
        return n(function() {
            return a
        }, [a == null].concat(b.map(function(b) {
            return a == null ? void 0 : a[b]
        })))
    }

    function o(a, b) {
        if (a === b) return a !== 0 || b !== 0 || 1 / a === 1 / b;
        else {
            var c = (i || (i = d("I64"))).cast(a);
            if (c != null) {
                var e = (i || (i = d("I64"))).cast(b);
                if (e != null) return (i || (i = d("I64"))).equal(c, e)
            }
            return a !== a && b !== b
        }
    }
    var p = Object.prototype.hasOwnProperty;

    function e(a, b) {
        if (o(a, b)) return !0;
        if (typeof a !== "object" || a === null || typeof b !== "object" || b === null) return !1;
        var c = Object.keys(a),
            d = Object.keys(b);
        if (c.length !== d.length) return !1;
        for (d = 0; d < c.length; d++)
            if (!p.call(b, c[d]) || !o(a[c[d]], b[c[d]])) return !1;
        return !0
    }
    g.useEffectInt64 = a;
    g.useCallbackInt64 = b;
    g.useMemoInt64 = n;
    g.usePickInt64 = c;
    g.mostlyShallowEqual = e
}), 98);
__d("LSFeatureLimitsType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        READ_ONLY: 1,
        GENERIC_READ_ONLY_BLOCK: 2,
        MESSAGE_SEND: 4,
        MESSENGER_ONLY_ACCOUNTS_READ_ONLY_BLOCK: 8,
        MESSAGE_SEND_PRIVATE: 16,
        MESSAGE_SEND_PUBLIC: 32,
        MESSAGE_SEND_FROM_PAGE: 64,
        COMMERCE_MESSAGE_SEND: 128,
        PAGE_MESSAGING: 256
    });
    f["default"] = a
}), 66);
__d("LSMarkThreadRead", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(9).fetch([
                [
                    [a[1]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[1]) && b.i64.gt(a[0], c.lastReadWatermarkTimestampMs)
            }), function(b) {
                var c = b.update;
                b.item;
                return c({
                    lastReadWatermarkTimestampMs: a[0]
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxMarkThreadReadStoredProcedure";
    e.exports = a
}), null);
__d("LSOptimisticMarkThreadReadV2", ["LSIssueNewTask", "LSMarkThreadRead"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(d) {
                return c.storedProcedure(b("LSMarkThreadRead"), a[1], a[0])
            }, function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var e = a.done;
                    a = a.value;
                    return e ? d[0] = c.i64.cast([0, 1]) : (b = a.item, d[6] = b.syncGroup, c.i64.neq(d[6], void 0) ? d[5] = d[6] : d[5] = c.i64.cast([0, 1]), d[0] = d[5])
                })
            }, function(e) {
                return d[2] = new c.Map(), d[2].set("thread_id", a[0]), d[2].set("last_read_watermark_ts", a[1]), d[2].set("sync_group", d[0]), d[3] = d[2].get("thread_id"), d[2], d[4] = c.toJSON(d[2]), c.storedProcedure(b("LSIssueNewTask"), c.i64.to_string(d[3]), c.i64.cast([0, 21]), d[4], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxOptimisticMarkThreadReadV2StoredProcedure";
    e.exports = a
}), null);
__d("MWChatMessageId", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        if (a.type === "sent") return a.value.messageId
    }

    function b(a) {
        if (a.type === "sent") return a.value.threadId
    }

    function c(a) {
        if (a.type === "sent") return a.value.timestamp
    }

    function e(a, b, c) {
        return {
            type: "sent",
            value: {
                messageId: b,
                threadId: (h || (h = d("I64"))).of_string(a),
                timestamp: h.of_string(c)
            }
        }
    }

    function f(a) {
        return {
            type: "sent",
            value: {
                messageId: a,
                threadId: (h || (h = d("I64"))).zero,
                timestamp: h.zero
            }
        }
    }
    var i = {
        type: "sent",
        value: {
            messageId: "",
            threadId: (h || (h = d("I64"))).zero,
            timestamp: h.zero
        }
    };
    g.getMessageId = a;
    g.getThreadId = b;
    g.getTimestamp = c;
    g.makeSent = e;
    g.emptyForExamplesWithId = f;
    g.emptyForExamples = i
}), 98);
__d("MWLSThread", ["FBLogger", "Promise", "ReQL", "ReQLSuspense", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = function(a) {
        return a
    };

    function a(a, b) {
        b === void 0 && (b = j);
        var e = (i || (i = c("useReStore")))();
        return d("ReQLSuspense").useFirst(function() {
            return a != null ? d("ReQL").fromTableAscending(e.tables.threads).getKeyRange(a).map(function(a) {
                return b(a)
            }) : d("ReQL").empty()
        }, [e, a], f.id + ":29")
    }

    function e(a, b) {
        b === void 0 && (b = j);
        var e = (i || (i = c("useReStore")))();
        return d("ReQLSuspense").useFirstExn(function() {
            return d("ReQL").fromTableAscending(e.tables.threads).getKeyRange(a).map(function(a) {
                var c;
                return (c = b == null ? void 0 : b(a)) != null ? c : a
            })
        }, [e, a], f.id + ":48")
    }

    function k(a, b, e) {
        e === void 0 && (e = j);
        a = d("ReQLSuspense").first(d("ReQL").fromTableAscending(a.tables.threads).getKeyRange(b), f.id + ":65");
        if (!a) throw c("FBLogger")("messenger_web").mustfixThrow("thread is null/undefined");
        return e(a)
    }

    function l(a, c, e) {
        e === void 0 && (e = j);
        return c != null ? d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.tables.threads).getKeyRange(c)).then(function(a) {
            return a ? e(a) : void 0
        }) : (h || (h = b("Promise"))).resolve(void 0)
    }
    g.useThread = a;
    g.useThreadExn = e;
    g.getThreadExn = k;
    g.getThreadAsync = l
}), 98);
__d("MWPFeatureLimitedData", ["I64", "Int64Hooks", "LSFeatureLimitsType", "LSIntEnum", "LSMessagingThreadTypeUtil", "ReQL", "ReQLSuspense", "ServerTime", "gkx", "useReStore", "useServerTime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = [(i || (i = d("LSIntEnum"))).ofNumber(c("LSFeatureLimitsType").READ_ONLY), i.ofNumber(c("LSFeatureLimitsType").GENERIC_READ_ONLY_BLOCK), i.ofNumber(c("LSFeatureLimitsType").MESSAGE_SEND)];

    function l(a) {
        for (var b = 0; b < k.length; b++) {
            var c = k[b];
            if ((j || (j = d("I64"))).equal(c, a.type_)) return !0
        }
        return !1
    }

    function m(a, b) {
        return (j || (j = d("I64"))).equal((i || (i = d("LSIntEnum"))).ofNumber(c("LSFeatureLimitsType").MESSAGE_SEND_PUBLIC), a.type_) && d("LSMessagingThreadTypeUtil").isPublicCMThread(b) && c("gkx")("26351")
    }

    function n(a, b) {
        return (j || (j = d("I64"))).equal((i || (i = d("LSIntEnum"))).ofNumber(c("LSFeatureLimitsType").MESSAGE_SEND_PRIVATE), a.type_) && d("LSMessagingThreadTypeUtil").isPrivateThread(b) && c("gkx")("26352")
    }
    var o = function(a) {
        var b = (j || (j = d("I64"))).of_float(d("ServerTime").getMillis() / 1e3);
        return d("ReQL").fromTableAscending(a.tables.feature_limits).filter(function(a) {
            return l(a) && (j || (j = d("I64"))).gt(a.expirationTimestampSeconds, b)
        })
    };

    function p(a, b) {
        var e = (j || (j = d("I64"))).of_float(c("useServerTime")().valueOf() / 1e3);
        return d("Int64Hooks").useMemoInt64(function() {
            return d("ReQL").fromTableAscending(a.tables.feature_limits).filter(function(a) {
                return (b != null ? l(a) || m(a, b) || n(a, b) : l(a)) && (j || (j = d("I64"))).gt(a.expirationTimestampSeconds, e)
            })
        }, [e, a, b])
    }

    function a() {
        var a = (h || (h = c("useReStore")))();
        return d("ReQLSuspense").useFirst(function() {
            return o(a)
        }, [a], f.id + ":129")
    }

    function b(a) {
        var b = (h || (h = c("useReStore")))(),
            e = p(b, a);
        return d("ReQLSuspense").useFirst(function() {
            return e
        }, [e], f.id + ":138")
    }
    g.readonlyFeatureLimitQuery = o;
    g.useReadOnlyFeatureLimitData = a;
    g.useReadOnlyFeatureLimitDataWithThreadType = b
}), 98);
__d("MWThreadKey.react", ["I64", "Int64Hooks", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react")),
        k = h,
        l = k.createContext,
        m = k.useContext,
        n = l(void 0);

    function o(a) {
        var b = a.children,
            e = a.id;
        a = a.isSubthread;
        a = a === void 0 ? !1 : a;
        var f = m(n),
            g = d("Int64Hooks").useMemoInt64(function() {
                return e
            }, [e]);
        if (f != null && !a) throw c("unrecoverableViolation")("You can't nest MWThreadKey in another MWThreadKey. This will cause SEVs as things might think they're in the wrong thread", "messenger_web_messaging");
        return j.jsx(n.Provider, {
            value: g,
            children: b
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.children,
            c = a.id;
        a = a.isSubthread;
        a = a === void 0 ? !1 : a;
        return c != null ? j.jsx(o, {
            id: (i || (i = d("I64"))).of_string(c),
            isSubthread: a,
            children: b
        }) : j.jsx(j.Fragment, {
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return m(n)
    }

    function e() {
        var a = m(n);
        if (a != null) return a;
        throw c("unrecoverableViolation")("Tried to get a thread key when there was none", "messenger_web_ia")
    }
    g.MWThreadKeyProvider = o;
    g.XPlatThreadKeyProvider = a;
    g.useMWThreadKeyMemoized = b;
    g.useMWThreadKeyMemoizedExn = e
}), 98);
__d("ThreadStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        DEFAULT: 0,
        PAUSED: 1,
        PAUSED_AND_UPGRADED_TO_COMMUNITY: 2,
        UPGRADED_TO_COMMUNITY_AND_TO_BE_PAUSED: 3
    });
    f["default"] = a
}), 66);
__d("VirtualizationContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useIsReadOnlyFeatureLimitedWithThreadType", ["MWPFeatureLimitedData", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = d("MWPFeatureLimitedData").useReadOnlyFeatureLimitDataWithThreadType(a);
        if (a != null) return c("gkx")("24070");
        else return !1
    }
    g["default"] = a
}), 98);
__d("useIsSecureMessage", ["LSMessagingThreadTypeUtil", "ReQL", "ReQLSuspense"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c) {
        var e;
        e = (e = d("ReQLSuspense").useFirst(function() {
            return b == null ? d("ReQL").empty() : d("ReQL").fromTableAscending(a.tables.threads, ["threadType"]).getKeyRange(b.threadKey).map(function(a) {
                a = a.threadType;
                return a
            })
        }, [a, b], f.id + ":37")) != null ? e : c.fallbackThreadType;
        if (e == null) {
            return (c = c.fallbackIsSecure) != null ? c : !1
        }
        return d("LSMessagingThreadTypeUtil").isArmadilloSecure(e)
    }
    g["default"] = a
}), 98);
__d("useMWXEntryPointDialog", ["cr:5835", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");

    function a(a, c, d, e, f) {
        d === void 0 && (d = "button");
        return b("cr:5835")(a, c, d, e, f)
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("EBLSDeferred", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("EBLS").__setRef("EBLSDeferred");

    function a() {
        return h.load().then(function(a) {
            return a.init()
        })
    }

    function b() {
        return h.load().then(function(a) {
            return a.genLSClient()
        })
    }

    function d() {
        return h.load().then(function(a) {
            return a.getLSStorage()
        })
    }

    function e(a, b, c) {
        return h.load().then(function(d) {
            return d.platformClientInit(a, b, c)
        })
    }
    g.init = a;
    g.genLSClient = b;
    g.getLSStorage = d;
    g.platformClientInit = e
}), 98);
__d("WASmaxInPreKeysIQErrorItemNotFoundMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "item-not-found");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 404);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorItemNotFoundMixin = a
}), 98);
__d("WASmaxInPreKeysRequestErrorsFetchDigest", ["WAResultOrError", "WASmaxInPreKeysIQErrorFallbackClientMixin", "WASmaxInPreKeysIQErrorItemNotFoundMixin", "WASmaxInPreKeysIQErrorNotAcceptableMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInPreKeysIQErrorNotAcceptableMixin").parseIQErrorNotAcceptableMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "IQErrorNotAcceptable",
            value: b.value
        });
        var c = d("WASmaxInPreKeysIQErrorItemNotFoundMixin").parseIQErrorItemNotFoundMixin(a);
        if (c.success) return d("WAResultOrError").makeResult({
            name: "IQErrorItemNotFound",
            value: c.value
        });
        var e = d("WASmaxInPreKeysIQErrorFallbackClientMixin").parseIQErrorFallbackClientMixin(a);
        return e.success ? d("WAResultOrError").makeResult({
            name: "IQErrorFallbackClient",
            value: e.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["IQErrorNotAcceptable", "IQErrorItemNotFound", "IQErrorFallbackClient"], [b, c, e])
    }
    g.parseRequestErrorsFetchDigest = a
}), 98);
__d("WASmaxInPreKeysFetchDigestResponseRequestError", ["WAResultOrError", "WASmaxInPreKeysIQErrorResponseMixin", "WASmaxInPreKeysRequestErrorsFetchDigest", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInPreKeysIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInPreKeysRequestErrorsFetchDigest").parseRequestErrorsFetchDigest(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorRequestErrorsFetchDigest: b.value
        }))
    }
    g.parseFetchDigestResponseRequestError = a
}), 98);
__d("WASmaxInPreKeysFetchDigestResponseServerError", ["WAResultOrError", "WASmaxInPreKeysIQErrorResponseMixin", "WASmaxInPreKeysServerErrors", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInPreKeysIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInPreKeysServerErrors").parseServerErrors(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorServerErrors: b.value
        }))
    }
    g.parseFetchDigestResponseServerError = a
}), 98);
__d("WASmaxInPreKeysKeysHashMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").flattenedChildWithTag(a, "hash");
        if (!a.success) return a;
        a = d("WASmaxParseUtils").contentBytesRange(a.value, 20, 20);
        return !a.success ? a : d("WAResultOrError").makeResult({
            hashElementValue: a.value
        })
    }
    g.parseKeysHashMixin = a
}), 98);
__d("WASmaxInPreKeysPreKeyIDListMixin", ["WAResultOrError", "WASmaxInPreKeysKeyIDMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "id");
        if (!b.success) return b;
        b = d("WASmaxInPreKeysKeyIDMixin").parseKeyIDMixin(a);
        return !b.success ? b : b
    }

    function a(a) {
        a = d("WASmaxParseUtils").flattenedChildWithTag(a, "list");
        if (!a.success) return a;
        a = d("WASmaxParseUtils").mapChildrenWithTag(a.value, "id", 0, 2e4, h);
        return !a.success ? a : d("WAResultOrError").makeResult({
            listId: a.value
        })
    }
    g.parsePreKeyIDListListId = h;
    g.parsePreKeyIDListMixin = a
}), 98);
__d("WASmaxInPreKeysIdentityDigestBundleMixin", ["WAResultOrError", "WASmaxInPreKeysIdentityKeyMixin", "WASmaxInPreKeysKeyTypeMixin", "WASmaxInPreKeysKeysHashMixin", "WASmaxInPreKeysPreKeyIDListMixin", "WASmaxInPreKeysRegistrationIDMixin", "WASmaxInPreKeysSignedPreKeyMixin"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInPreKeysRegistrationIDMixin").parseRegistrationIDMixin(a);
        if (!b.success) return b;
        var c = d("WASmaxInPreKeysIdentityKeyMixin").parseIdentityKeyMixin(a);
        if (!c.success) return c;
        var e = d("WASmaxInPreKeysPreKeyIDListMixin").parsePreKeyIDListMixin(a);
        if (!e.success) return e;
        var f = d("WASmaxInPreKeysSignedPreKeyMixin").parseSignedPreKeyMixin(a);
        if (!f.success) return f;
        var g = d("WASmaxInPreKeysKeyTypeMixin").parseKeyTypeMixin(a);
        a = d("WASmaxInPreKeysKeysHashMixin").parseKeysHashMixin(a);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, b.value, c.value, e.value, f.value, {
            keyTypeMixin: g.success ? g.value : null
        }, a.value))
    }
    g.parseIdentityDigestBundleMixin = a
}), 98);
__d("WASmaxInPreKeysFetchDigestResponseSuccess", ["WAResultOrError", "WASmaxInPreKeysIQResultResponseMixin", "WASmaxInPreKeysIdentityDigestBundleMixin", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "digest");
        if (!c.success) return c;
        var e = d("WASmaxParseReference").optionalAttrStringFromReference(b, ["digest", "identity_type"]);
        if (!e.success) return e;
        e = d("WASmaxParseUtils").optionalLiteral(d("WASmaxParseUtils").attrString, c.value, "identity_type", e.value);
        if (!e.success) return e;
        c = d("WASmaxInPreKeysIdentityDigestBundleMixin").parseIdentityDigestBundleMixin(c.value);
        if (!c.success) return c;
        a = d("WASmaxInPreKeysIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            hasDigestIdentityType: e.value != null,
            digestIdentityDigestBundleMixin: c.value
        }, a.value))
    }
    g.parseFetchDigestResponseSuccess = a
}), 98);
__d("WASmaxOutPreKeysFetchDigestRequest", ["WASmaxJsx", "WASmaxOutPreKeysClientRequestMixin"], (function(a, b, c, d, e, f, g) {
    function a() {
        var a = d("WASmaxOutPreKeysClientRequestMixin").mergeClientRequestMixin(d("WASmaxJsx").smax("iq", {
            type: "get"
        }, d("WASmaxJsx").smax("digest", null)));
        return a
    }
    g.makeFetchDigestRequest = a
}), 98);
__d("WASmaxPreKeysFetchDigestRPC", ["WAComms", "WASmaxInPreKeysFetchDigestResponseRequestError", "WASmaxInPreKeysFetchDigestResponseServerError", "WASmaxInPreKeysFetchDigestResponseSuccess", "WASmaxOutPreKeysFetchDigestRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var c, e, f, g, h;
        return b("regeneratorRuntime").async(function(i) {
            while (1) switch (i.prev = i.next) {
                case 0:
                    c = d("WASmaxOutPreKeysFetchDigestRequest").makeFetchDigestRequest();
                    i.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(c, a));
                case 3:
                    e = i.sent;
                    f = d("WASmaxInPreKeysFetchDigestResponseSuccess").parseFetchDigestResponseSuccess(e, c);
                    if (!f.success) {
                        i.next = 7;
                        break
                    }
                    return i.abrupt("return", {
                        name: "FetchDigestResponseSuccess",
                        value: f.value
                    });
                case 7:
                    g = d("WASmaxInPreKeysFetchDigestResponseRequestError").parseFetchDigestResponseRequestError(e, c);
                    if (!g.success) {
                        i.next = 10;
                        break
                    }
                    return i.abrupt("return", {
                        name: "FetchDigestResponseRequestError",
                        value: g.value
                    });
                case 10:
                    h = d("WASmaxInPreKeysFetchDigestResponseServerError").parseFetchDigestResponseServerError(e, c);
                    if (!h.success) {
                        i.next = 13;
                        break
                    }
                    return i.abrupt("return", {
                        name: "FetchDigestResponseServerError",
                        value: h.value
                    });
                case 13:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("FetchDigest", {
                        Success: f,
                        RequestError: g,
                        ServerError: h
                    }));
                case 14:
                case "end":
                    return i.stop()
            }
        }, null, this)
    }
    g.sendFetchDigestRPC = a
}), 98);
__d("WARequestPreKeyDigestProtocol", ["WABinary", "WAConvertRegistrationIdMixin", "WAConvertSignedPreKeyMixin", "WACryptoDependencies", "WACryptoUtils", "WAParsableXmlNode", "WAResultOrError", "WASignalKeys", "WASmaxPreKeysFetchDigestRPC", "WATagsLogger", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": ", ""]);
        i = function() {
            return a
        };
        return a
    }
    var j = d("WATagsLogger").TAGS(["requestPreKeyDigestProtocol"]);

    function a(a) {
        return d("WASmaxPreKeysFetchDigestRPC").sendFetchDigestRPC({
            withoutRetry: !1
        }).then(function(b) {
            switch (b.name) {
                case "FetchDigestResponseServerError":
                    var c = b.value.errorServerErrors.name;
                    j.ERROR(i(), b.name, c);
                    return d("WAResultOrError").makeError({
                        type: "server-error",
                        payload: c
                    });
                case "FetchDigestResponseRequestError":
                    c = b.value.errorRequestErrorsFetchDigest.name;
                    j.ERROR(h(), b.name, c);
                    return d("WAResultOrError").makeError({
                        type: "request-error",
                        payload: c
                    });
                default:
                    b.name;
                    c = k(b.value.digestIdentityDigestBundleMixin);
                    return l(c, a).then(function(a) {
                        return a === "ok" ? d("WAResultOrError").makeResult() : d("WAResultOrError").makeError({
                            type: "compare-error",
                            payload: a
                        })
                    })
            }
        })
    }

    function k(a) {
        var b = d("WAConvertRegistrationIdMixin").registrationIdMixin(a),
            c = d("WAConvertSignedPreKeyMixin").convertSignedPreKeyMixin(a),
            e = a.listId.map(function(a) {
                return d("WASignalKeys").castToPreKeyId(d("WAParsableXmlNode").convertBytesToUint(a.elementValue, 3))
            });
        a = a.hashElementValue;
        return {
            regId: b,
            skeyId: c.id,
            preKeyIds: e,
            hash: a
        }
    }

    function l(a, c) {
        var e, f, g, h;
        return b("regeneratorRuntime").async(function(i) {
            while (1) switch (i.prev = i.next) {
                case 0:
                    if (!(a.regId !== c.regInfo.regId)) {
                        i.next = 2;
                        break
                    }
                    return i.abrupt("return", "RegIdMismatch");
                case 2:
                    if (!(a.skeyId !== c.signedPreKey.id)) {
                        i.next = 4;
                        break
                    }
                    return i.abrupt("return", "SignedPreKeyIdMismatch");
                case 4:
                    e = new Map();
                    c.preKeys.forEach(function(a) {
                        return e.set(a.id, a)
                    });
                    f = a.preKeyIds.some(function(a) {
                        return !e.has(a)
                    });
                    if (!f) {
                        i.next = 9;
                        break
                    }
                    return i.abrupt("return", "UnknownPreKey");
                case 9:
                    g = a.preKeyIds.map(function(a) {
                        return e.get(a)
                    }).filter(Boolean);
                    i.next = 12;
                    return b("regeneratorRuntime").awrap(m(c, g));
                case 12:
                    h = i.sent;
                    if (d("WACryptoUtils").uint8ArraysEqual(h, a.hash)) {
                        i.next = 15;
                        break
                    }
                    return i.abrupt("return", "HashMismatch");
                case 15:
                    return i.abrupt("return", "ok");
                case 16:
                case "end":
                    return i.stop()
            }
        }, null, this)
    }

    function m(a, b) {
        var c = new(d("WABinary").Binary)();
        c.writeByteArray(a.regInfo.staticKeyPair.publicKey);
        c.writeByteArray(a.signedPreKey.keyPair.publicKey);
        c.writeByteArray(a.signedPreKey.signature);
        b.forEach(function(a) {
            c.writeByteArray(a.keyPair.publicKey)
        });
        return d("WACryptoDependencies").getCrypto().subtle.digest("SHA-1", c.readByteArray()).then(function(a) {
            return new Uint8Array(a)
        })
    }
    g.requestPreKeyDigestProtocol = a
}), 98);
__d("WARequestPreKeyDigest", ["WABridge", "WAGenerateAndUploadPreKeys", "WAGetKeysForUpload", "WAGlobals", "WALogger", "WAOdsEnums", "WARequestPreKeyDigestProtocol", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error while generating and uploading prekeys: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["PreKey digest comparison failed: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j(a) {
        var e, f;
        return b("regeneratorRuntime").async(function(g) {
            while (1) switch (g.prev = g.next) {
                case 0:
                    g.next = 2;
                    return b("regeneratorRuntime").awrap(a(function(a) {
                        a = a.cryptoManager;
                        return d("WAGetKeysForUpload").getKeysForUpload(a)
                    }));
                case 2:
                    e = g.sent;
                    if (!(e.success === !1)) {
                        g.next = 6;
                        break
                    }
                    d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                        entity: d("WAOdsEnums").Entity.PREKEY_DIGEST,
                        key: "fail"
                    });
                    throw c("err")("Error while loading keys: " + e.error);
                case 6:
                    g.next = 8;
                    return b("regeneratorRuntime").awrap(d("WARequestPreKeyDigestProtocol").requestPreKeyDigestProtocol(e.value));
                case 8:
                    f = g.sent;
                    if (!(f.success === !1)) {
                        g.next = 16;
                        break
                    }
                    d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                        entity: d("WAOdsEnums").Entity.PREKEY_DIGEST,
                        key: "fail"
                    });
                    if (!(f.error.type === "compare-error")) {
                        g.next = 15;
                        break
                    }
                    d("WALogger").ERROR(i(), f.error.payload);
                    d("WAGenerateAndUploadPreKeys").generateAndUploadPreKeys(null, {
                        reason: "prekey digest comparison failed"
                    })["catch"](function(a) {
                        d("WALogger").ERROR(h(), a)
                    });
                    return g.abrupt("return");
                case 15:
                    throw c("err")("Error while requesting key digest: " + f.error.type + " " + f.error.payload);
                case 16:
                    f.success, d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                        entity: d("WAOdsEnums").Entity.PREKEY_DIGEST,
                        key: "success"
                    });
                case 18:
                case "end":
                    return g.stop()
            }
        }, null, this)
    }

    function a(a) {
        return j(function(a) {
            return d("WAGlobals").getWaOneQueue().enqueue(a, {
                operationType: "request_prekey_digest",
                flush: !1
            })
        })
    }
    g.requestPreKeyDigestFn = j;
    g.requestPreKeyDigest = a
}), 98); /*FB_PKG_DELIM*/
__d("MAWInitError", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c) {
            var d;
            d = a.call(this, b) || this;
            d.error = void 0;
            d.name = "MAWInitError";
            d.message = b;
            d.error = c;
            return d
        }
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    f.MAWInitError = a
}), 66);
__d("mergeHelpers", ["invariant", "FbtResultBase"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = 36,
        j = function(a) {
            return typeof a !== "object" || a instanceof Date || a === null || a instanceof c("FbtResultBase")
        },
        k = {
            MAX_MERGE_DEPTH: i,
            isTerminal: j,
            normalizeMergeArg: function(a) {
                return a == null ? {} : a
            },
            checkMergeArrayArgs: function(a, b) {
                Array.isArray(a) && Array.isArray(b) || h(0, 3714, a, b)
            },
            checkMergeObjectArgs: function(a, b) {
                k.checkMergeObjectArg(a), k.checkMergeObjectArg(b)
            },
            checkMergeObjectArg: function(a) {
                !j(a) && !Array.isArray(a) || h(0, 3715, a)
            },
            checkMergeIntoObjectArg: function(a) {
                (!j(a) || typeof a === "function") && !Array.isArray(a) || h(0, 3716, a)
            },
            checkMergeLevel: function(a) {
                a < i || h(0, 3717)
            },
            checkArrayStrategy: function(a) {
                a == null || a in k.ArrayStrategies || h(0, 3718)
            },
            ArrayStrategies: {
                Clobber: "Clobber",
                Concat: "Concat",
                IndexByIndex: "IndexByIndex"
            }
        };
    a = k;
    g["default"] = a
}), 98);
__d("mergeDeepInto", ["invariant", "mergeHelpers"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = (c = b("mergeHelpers")).ArrayStrategies,
        i = c.checkArrayStrategy,
        j = c.checkMergeArrayArgs,
        k = c.checkMergeLevel,
        l = c.checkMergeObjectArgs,
        m = c.isTerminal,
        n = c.normalizeMergeArg,
        o = function(a, b, c, d) {
            l(a, b);
            k(d);
            var e = b ? Object.keys(b) : [];
            for (var f = 0; f < e.length; f++) {
                var g = e[f];
                q(a, b, g, c, d)
            }
        },
        p = function(a, b, c, d) {
            j(a, b);
            k(d);
            if (c === h.Concat) a.push.apply(a, b);
            else {
                var e = Math.max(a.length, b.length);
                for (var f = 0; f < e; f++) q(a, b, f, c, d)
            }
        },
        q = function(a, b, c, d, e) {
            var f = b[c];
            b = Object.prototype.hasOwnProperty.call(b, c);
            var i = b && m(f),
                j = b && Array.isArray(f),
                k = b && !j && !j,
                l = a[c],
                n = Object.prototype.hasOwnProperty.call(a, c),
                q = n && m(l),
                r = n && Array.isArray(l),
                s = n && !r && !r;
            q ? i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k ? (a[c] = {}, o(a[c], f, d, e + 1)) : b || (a[c] = l) : r ? i ? a[c] = f : j ? (d && h[d] || g(0, 5117), d === h.Clobber && (l.length = 0), p(l, f, d, e + 1)) : k && (a[c] = {}, o(a[c], f, d, e + 1)) : s ? i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k && o(l, f, d, e + 1) : n || (i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k && (a[c] = {}, o(a[c], f, d, e + 1)))
        };

    function a(a, b, c) {
        b = n(b);
        i(c);
        o(a, b, c, 0)
    }
    f["default"] = a
}), 66);
__d("WebAsyncStorage", ["Deferred", "Promise", "err", "mergeDeepInto", "mergeHelpers"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = typeof window !== "undefined" ? window : self;
    var i = a.indexedDB,
        j = 1,
        k = "data",
        l = !1,
        m;
    d = Date.now();
    var n = new(c("Deferred"))(),
        o = 3;

    function p() {
        var a = i.open("AsyncStorage", j);
        a.onerror = function(b) {
            b = (b = a.error) != null ? b : new Error("Failed to open AsyncStorage IndexedDB instance.");
            if (b.name === "UnknownError" && o > 0) {
                o--;
                return p()
            }
            n.reject(b)
        };
        a.onsuccess = function(a) {
            l && !1, m = a.target.result, n.resolve({
                db: m
            }), m.onerror = function(a) {
                a = new Error("AsyncStorage error: " + a.target.error.message);
                n.reject(a)
            }
        };
        a.onupgradeneeded = function(a) {
            a = a.currentTarget.result;
            if (a.objectStoreNames && a.objectStoreNames.contains(k)) return;
            a.createObjectStore(k, {
                keyPath: "key"
            })
        }
    }
    i && p();

    function q(a, b) {
        if (m) try {
            a()
        } catch (a) {
            b && b(a)
        } else n.getPromise().then(function() {
            l && !1, q(a, b)
        }, function(a) {
            b && b(a)
        })
    }
    e = {
        setItem: function(a, b, c) {
            this.multiSet([
                [a, b]
            ], function(a) {
                c(a && a[0] || null)
            })
        },
        getItem: function(a, b) {
            this.multiGet([a], function(a, c) {
                c = c !== void 0 && c[0] !== void 0 && c[0][1] !== void 0 ? c[0][1] : null;
                b(a && a[0] || null, c)
            })
        },
        removeItem: function(a, b) {
            this.multiRemove([a], function(a) {
                b(a && a[0] || null)
            })
        },
        multiGet: function(a, b) {
            var c = [];
            this._multiOp(a, "readonly", function(a) {
                return b(a, c)
            }, function(a) {
                return a
            }, function(a, b, d) {
                b && a === b.key ? (l && !1, c.push([a, b.value.value])) : c.push([a, null])
            })
        },
        multiSet: function(a, b) {
            if (this._persistentWritesDisabled) {
                b(new Array(a.length).fill("writes disabled"));
                return
            }
            this._multiOp(a, "readwrite", b, function(a) {
                return a[0]
            }, function(a, b, c) {
                if (b && a[0] === b.key) {
                    var d = b.value;
                    d.value = a[1];
                    l && !1;
                    b.update(d)
                } else c.push(a)
            })
        },
        multiMerge: function(a, b) {
            this._multiOp(a, "readwrite", b, function(a) {
                return a[0]
            }, function(a, b, d) {
                if (b && a[0] === b.key) {
                    var e = b.value,
                        f = JSON.parse(e.value);
                    c("mergeDeepInto")(f, JSON.parse(a[1]), c("mergeHelpers").ArrayStrategies.Clobber);
                    l && !1;
                    e.value = JSON.stringify(f);
                    b.update(e)
                } else l && !1, d.push(a)
            })
        },
        multiRemove: function(a, b) {
            this._multiOp(a, "readwrite", b, function(a) {
                return a
            }, function(a, b, c) {
                b && a === b.key && (l && !1, b["delete"]())
            })
        },
        getAllKeys: function(a) {
            q(function() {
                var b = m.transaction([k], "readonly");
                b = b.objectStore(k).openCursor();
                var c = [];
                b.onsuccess = function(b) {
                    b = b.target.result;
                    if (!b) {
                        a(null, c);
                        return
                    }
                    c.push(b.key);
                    b["continue"]()
                }
            }, function(b) {
                return a(null, [])
            })
        },
        clear: function(a) {
            q(function() {
                var b = m.transaction([k], "readwrite");
                b = b.objectStore(k).openCursor();
                b.onsuccess = function(b) {
                    b = b.target.result;
                    if (!b) {
                        a(null);
                        return
                    }
                    b["delete"]();
                    b["continue"]()
                }
            }, function(b) {
                return a(null)
            })
        },
        _multiOp: function(a, b, c, d, e) {
            q(function() {
                var f = !1,
                    g = a.slice().sort(function(a, b) {
                        a = d(a);
                        b = d(b);
                        if (a === b) {
                            var e = new Error("AsyncStorage._multiOp cannot process duplicate keys.");
                            c && c([e]);
                            f = !0;
                            return 0
                        }
                        return a < b ? -1 : 1
                    });
                if (f) return;
                var h = m.transaction([k], b),
                    i = h.objectStore(k).openCursor(),
                    j = [],
                    n = 0;
                i.onsuccess = function(a) {
                    a = a.target.result;
                    if (!a) {
                        while (n < g.length) e(g[n], a, j), n++;
                        o();
                        return
                    }
                    var b = a.key;
                    l && !1;
                    while (d(g[n]) <= b) {
                        l && !1;
                        e(g[n], a, j);
                        n++;
                        if (n === g.length) {
                            o();
                            return
                        }
                    }
                    b = d(g[n]);
                    a["continue"](b)
                };

                function o() {
                    var a = h.objectStore(k);
                    j.forEach(function(b) {
                        l && !1, a.add({
                            key: b[0],
                            value: b[1]
                        })
                    })
                }
                h.oncomplete = function() {
                    c && c(null)
                };
                h.onerror = function(a) {
                    a = new Error("IndexedDB error: " + a.target.error.message);
                    c && c([a])
                };
                l && !1
            }, function(a) {
                c && c([a])
            })
        },
        _persistentWritesDisabled: !1,
        disablePersistentWrites: function() {
            this._persistentWritesDisabled = !0
        },
        isOpenPromiseSettled: function() {
            return n.isSettled()
        },
        isOperational: function() {
            return i == null ? (h || (h = b("Promise"))).resolve({
                success: !1,
                error: c("err")("IDB interface not available")
            }) : n.getPromise().then(function() {
                return {
                    success: !0
                }
            })["catch"](function(a) {
                return {
                    success: !1,
                    error: a
                }
            })
        }
    };
    f = e;
    g["default"] = f
}), 98); /*FB_PKG_DELIM*/
__d("regeneratorRuntime", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = Object.prototype.hasOwnProperty,
        i = typeof Symbol === "function" && (typeof Symbol === "function" ? Symbol.iterator : "@@iterator") || "@@iterator",
        j = e.exports;

    function k(a, b, c, d) {
        b = Object.create((b || r).prototype);
        d = new A(d || []);
        b._invoke = x(a, c, d);
        return b
    }
    j.wrap = k;

    function l(a, b, c) {
        try {
            return {
                type: "normal",
                arg: a.call(b, c)
            }
        } catch (a) {
            return {
                type: "throw",
                arg: a
            }
        }
    }
    var m = "suspendedStart",
        n = "suspendedYield",
        o = "executing",
        p = "completed",
        q = {};

    function r() {}

    function s() {}

    function t() {}
    var u = t.prototype = r.prototype;
    s.prototype = u.constructor = t;
    t.constructor = s;
    s.displayName = "GeneratorFunction";

    function a(a) {
        ["next", "throw", "return"].forEach(function(b) {
            a[b] = function(a) {
                return this._invoke(b, a)
            }
        })
    }
    j.isGeneratorFunction = function(a) {
        a = typeof a === "function" && a.constructor;
        return a ? a === s || (a.displayName || a.name) === "GeneratorFunction" : !1
    };
    j.mark = function(a) {
        Object.setPrototypeOf ? Object.setPrototypeOf(a, t) : Object.assign(a, t);
        a.prototype = Object.create(u);
        return a
    };
    j.awrap = function(a) {
        return new v(a)
    };

    function v(a) {
        this.arg = a
    }

    function w(a) {
        function c(c, f) {
            var h = a[c](f);
            c = h.value;
            return c instanceof v ? (g || (g = b("Promise"))).resolve(c.arg).then(d, e) : (g || (g = b("Promise"))).resolve(c).then(function(a) {
                h.value = a;
                return h
            })
        }
        typeof process === "object" && process.domain && (c = process.domain.bind(c));
        var d = c.bind(a, "next"),
            e = c.bind(a, "throw");
        c.bind(a, "return");
        var f;

        function h(a, d) {
            var e = f ? f.then(function() {
                return c(a, d)
            }) : new(g || (g = b("Promise")))(function(b) {
                b(c(a, d))
            });
            f = e["catch"](function(a) {});
            return e
        }
        this._invoke = h
    }
    a(w.prototype);
    j.async = function(a, b, c, d) {
        var e = new w(k(a, b, c, d));
        return j.isGeneratorFunction(b) ? e : e.next().then(function(a) {
            return a.done ? a.value : e.next()
        })
    };

    function x(a, b, c) {
        var d = m;
        return function(e, f) {
            if (d === o) throw new Error("Generator is already running");
            if (d === p) {
                if (e === "throw") throw f;
                return C()
            }
            while (!0) {
                var g = c.delegate;
                if (g) {
                    if (e === "return" || e === "throw" && g.iterator[e] === void 0) {
                        c.delegate = null;
                        var h = g.iterator["return"];
                        if (h) {
                            h = l(h, g.iterator, f);
                            if (h.type === "throw") {
                                e = "throw";
                                f = h.arg;
                                continue
                            }
                        }
                        if (e === "return") continue
                    }
                    h = l(g.iterator[e], g.iterator, f);
                    if (h.type === "throw") {
                        c.delegate = null;
                        e = "throw";
                        f = h.arg;
                        continue
                    }
                    e = "next";
                    f = void 0;
                    var i = h.arg;
                    if (i.done) c[g.resultName] = i.value, c.next = g.nextLoc;
                    else {
                        d = n;
                        return i
                    }
                    c.delegate = null
                }
                if (e === "next") d === n ? c.sent = f : c.sent = void 0;
                else if (e === "throw") {
                    if (d === m) {
                        d = p;
                        throw f
                    }
                    c.dispatchException(f) && (e = "next", f = void 0)
                } else e === "return" && c.abrupt("return", f);
                d = o;
                h = l(a, b, c);
                if (h.type === "normal") {
                    d = c.done ? p : n;
                    var i = {
                        value: h.arg,
                        done: c.done
                    };
                    if (h.arg === q) c.delegate && e === "next" && (f = void 0);
                    else return i
                } else h.type === "throw" && (d = p, e = "throw", f = h.arg)
            }
        }
    }
    a(u);
    u[i] = function() {
        return this
    };
    u.toString = function() {
        return "[object Generator]"
    };

    function y(a) {
        var b = {
            tryLoc: a[0]
        };
        1 in a && (b.catchLoc = a[1]);
        2 in a && (b.finallyLoc = a[2], b.afterLoc = a[3]);
        this.tryEntries.push(b)
    }

    function z(a) {
        var b = a.completion || {};
        b.type = "normal";
        delete b.arg;
        a.completion = b
    }

    function A(a) {
        this.tryEntries = [{
            tryLoc: "root"
        }], a.forEach(y, this), this.reset(!0)
    }
    j.keys = function(a) {
        var b = [];
        for (var c in a) b.push(c);
        b.reverse();
        return function c() {
            while (b.length) {
                var d = b.pop();
                if (d in a) {
                    c.value = d;
                    c.done = !1;
                    return c
                }
            }
            c.done = !0;
            return c
        }
    };

    function B(a) {
        if (a) {
            var b = a[i];
            if (b) return b.call(a);
            if (typeof a.next === "function") return a;
            if (!isNaN(a.length)) {
                var c = -1;
                b = function b() {
                    while (++c < a.length)
                        if (h.call(a, c)) {
                            b.value = a[c];
                            b.done = !1;
                            return b
                        }
                    b.value = void 0;
                    b.done = !0;
                    return b
                };
                return b.next = b
            }
        }
        return {
            next: C
        }
    }
    j.values = B;

    function C() {
        return {
            value: void 0,
            done: !0
        }
    }
    A.prototype = {
        constructor: A,
        reset: function(a) {
            this.prev = 0;
            this.next = 0;
            this.sent = void 0;
            this.done = !1;
            this.delegate = null;
            this.tryEntries.forEach(z);
            if (!a)
                for (a in this) a.charAt(0) === "t" && h.call(this, a) && !isNaN(+a.slice(1)) && (this[a] = void 0)
        },
        stop: function() {
            this.done = !0;
            var a = this.tryEntries[0];
            a = a.completion;
            if (a.type === "throw") throw a.arg;
            return this.rval
        },
        dispatchException: function(a) {
            if (this.done) throw a;
            var b = this;

            function c(c, d) {
                f.type = "throw";
                f.arg = a;
                b.next = c;
                return !!d
            }
            for (var d = this.tryEntries.length - 1; d >= 0; --d) {
                var e = this.tryEntries[d],
                    f = e.completion;
                if (e.tryLoc === "root") return c("end");
                if (e.tryLoc <= this.prev) {
                    var g = h.call(e, "catchLoc"),
                        i = h.call(e, "finallyLoc");
                    if (g && i) {
                        if (this.prev < e.catchLoc) return c(e.catchLoc, !0);
                        else if (this.prev < e.finallyLoc) return c(e.finallyLoc)
                    } else if (g) {
                        if (this.prev < e.catchLoc) return c(e.catchLoc, !0)
                    } else if (i) {
                        if (this.prev < e.finallyLoc) return c(e.finallyLoc)
                    } else throw new Error("try statement without catch or finally")
                }
            }
        },
        abrupt: function(a, b) {
            for (var c = this.tryEntries.length - 1; c >= 0; --c) {
                var d = this.tryEntries[c];
                if (d.tryLoc <= this.prev && h.call(d, "finallyLoc") && this.prev < d.finallyLoc) {
                    var e = d;
                    break
                }
            }
            e && (a === "break" || a === "continue") && e.tryLoc <= b && b <= e.finallyLoc && (e = null);
            d = e ? e.completion : {};
            d.type = a;
            d.arg = b;
            e ? this.next = e.finallyLoc : this.complete(d);
            return q
        },
        complete: function(a, b) {
            if (a.type === "throw") throw a.arg;
            a.type === "break" || a.type === "continue" ? this.next = a.arg : a.type === "return" ? (this.rval = a.arg, this.next = "end") : a.type === "normal" && b && (this.next = b)
        },
        finish: function(a) {
            for (var b = this.tryEntries.length - 1; b >= 0; --b) {
                var c = this.tryEntries[b];
                if (c.finallyLoc === a) {
                    this.complete(c.completion, c.afterLoc);
                    z(c);
                    return q
                }
            }
        },
        "catch": function(a) {
            for (var b = this.tryEntries.length - 1; b >= 0; --b) {
                var c = this.tryEntries[b];
                if (c.tryLoc === a) {
                    var d = c.completion;
                    if (d.type === "throw") {
                        var e = d.arg;
                        z(c)
                    }
                    return e
                }
            }
            throw new Error("illegal catch attempt")
        },
        delegateYield: function(a, b, c) {
            this.delegate = {
                iterator: B(a),
                resultName: b,
                nextLoc: c
            };
            return q
        }
    }
}), null);
__d("asyncToGeneratorRuntime", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function h(a, c, d, e, f, h, i) {
        try {
            var j = a[h](i),
                k = j.value
        } catch (a) {
            d(a);
            return
        }
        j.done ? c(k) : (g || (g = b("Promise"))).resolve(k).then(e, f)
    }

    function a(a) {
        return function() {
            var c = this,
                d = arguments;
            return new(g || (g = b("Promise")))(function(b, e) {
                var f = a.apply(c, d);

                function g(a) {
                    h(f, b, e, g, i, "next", a)
                }

                function i(a) {
                    h(f, b, e, g, i, "throw", a)
                }
                g(void 0)
            })
        }
    }
    f.asyncToGenerator = a
}), 66); /*FB_PKG_DELIM*/
__d("BaseModal.react", ["cr:1824473", "cr:994756", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");
    a = b("cr:1824473") != null ? b("cr:1824473") : b("cr:994756");
    g["default"] = a
}), 98);
__d("EBAPIWorkerCheck", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        try {
            return WorkerGlobalScope !== void 0 && self instanceof WorkerGlobalScope
        } catch (a) {
            return !1
        }
    }
    f.runningInWorker = a
}), 66);
__d("LSInitSyncCompleteSubscription", ["I64", "LSIntEnum", "Promise", "ReQL"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;

    function k(a, c) {
        return new(j || (j = b("Promise")))(function(b, e) {
            var f = d("ReQL").fromTableAscending(a.tables.sync_groups).getKeyRange(c).subscribe(function(a, c) {
                if (c.operation === "delete") return;
                if ((h || (h = d("I64"))).equal(c.value.syncStatus, (i || (i = d("LSIntEnum"))).ofNumber(2))) {
                    f();
                    return b()
                }
            })
        })
    }

    function a(a, b) {
        return d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.tables.sync_groups).getKeyRange(b)).then(function(c) {
            if (c != null && (h || (h = d("I64"))).equal(c.syncStatus, (i || (i = d("LSIntEnum"))).ofNumber(2))) return;
            return k(a, b)
        })
    }

    function c(a) {
        return k(a, (i || (i = d("LSIntEnum"))).ofNumber(1))
    }
    g.maybeWaitForSyncGroup = a;
    g.use = c
}), 98);
__d("MAWTrackPendingOccamadilloThreads", ["Deferred", "LSDatabaseSingleton", "LSInitSyncCompleteSubscription", "LSIntEnum", "MAWMIC", "MAWMICSchema", "QuickPerformanceLogger", "asyncToGeneratorRuntime", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = (h = {}, h[d("MAWMICSchema").ANNOTATIONS.occamadilloBatchesSentToWorker] = 0, h[d("MAWMICSchema").ANNOTATIONS.occamadilloPendingThreadsAfterInitSync] = 0, h[d("MAWMICSchema").ANNOTATIONS.occamadilloDuplicateThreads] = 0, h);
    (function() {
        Object.keys(l).forEach(function(a) {
            d("MAWMIC").addIntAnnotation(a, 0)
        })
    })();

    function m(a) {
        d("MAWMIC").addIntAnnotation(a, ++l[a])
    }
    var n = new(c("Deferred"))(),
        o = new Set(),
        p = new Set();

    function a() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_first_nop_start")
    }

    function e() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_acto_nop_start")
    }
    var q = null;

    function f(a) {
        d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_start);
        if (o.has(a)) {
            m(d("MAWMICSchema").ANNOTATIONS.occamadilloDuplicateThreads);
            return
        }
        p.add(a);
        q = (k || (k = c("QuickPerformanceLogger"))).currentTimestamp();
        o.add(a);
        d("MAWMIC").addIntAnnotation("occamadilloThreadCount", o.size);
        d("MAWMIC").wasEventLogged(d("MAWMICSchema").POINTS.ls_sync_end) && (m(d("MAWMICSchema").ANNOTATIONS.occamadilloPendingThreadsAfterInitSync), d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_new_pending_thread_after_init_sync))
    }

    function r() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_first_thread_check_in_ui_start")
    }

    function s() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_acto_check_in_ui_start")
    }

    function t() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_first_thread_check_in_worker_start")
    }

    function u() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_acto_check_in_worker_start")
    }

    function v(a) {
        d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_bridge_call_acked, a)
    }
    var w = [];

    function x(a) {
        d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_first_bulk_batch_run), m("occamadilloBatchesSentToWorker"), w.push(a), d("MAWMIC").addIntArrayAnnotation(d("MAWMICSchema").ANNOTATIONS.occamadilloBulkBatchSizes, w)
    }

    function y(a) {
        return z.apply(this, arguments)
    }

    function z() {
        z = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            if (c("gkx")("2661")) yield n.getPromise();
            else {
                var b = (yield(i || (i = d("LSDatabaseSingleton"))).LSDatabaseSingleton);
                yield d("LSInitSyncCompleteSubscription").maybeWaitForSyncGroup(b, (j || (j = d("LSIntEnum"))).ofNumber(95))
            }
            d("MAWMIC").markEvent("occamadillo_sync_group_complete");
            p["delete"](a);
            d("MAWMIC").addIntAnnotation("occamadilloCompleteThreadCount", o.size - p.size);
            B()
        });
        return z.apply(this, arguments)
    }

    function A() {
        n.resolve(), B()
    }

    function B() {
        p.size === 0 && (d("MAWMIC").addIntAnnotation("occamadilloThreadCount", o.size), q != null && d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_last_thread_added_to_pending, q), d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_end))
    }
    g.incrementCounter = m;
    g.markFirstThreadPassedToNativeOp = a;
    g.markACTOPassedToNativeOp = e;
    g.addPendingThread = f;
    g.markFirstThreadCheckedInUiThread = r;
    g.markACTOCheckedInUiThread = s;
    g.markFirstThreadCheckedInWorker = t;
    g.markACTOCheckedInWorker = u;
    g.markBridgeCallAcked = v;
    g.markBulkBatchRun = x;
    g.removePendingThread = y;
    g.completeSync = A;
    g.maybeEndOccamadilloThreadMapping = B
}), 98);
__d("MWEncryptedBackupsFirstRestoreUpsellTime", ["EBAPIWorkerCheck", "FBLogger", "WebStorage", "getMWEncryptedBackupsIsLocalStorageSupported", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = "mw_encrypted_backups_restore_upsell_first_impression_time_key";

    function a() {
        var a = Date.now().toString();
        if (c("gkx")("3551") === !0 && d("EBAPIWorkerCheck").runningInWorker()) return k(a);
        if (!d("getMWEncryptedBackupsIsLocalStorageSupported").getMWEncryptedBackupsIsLocalStorageSupported()) return a;
        try {
            var b;
            b = (b = (h || (h = c("WebStorage"))).getLocalStorage()) == null ? void 0 : b.getItem(i);
            if (b == null) {
                var e;
                (e = (h || (h = c("WebStorage"))).getLocalStorage()) == null ? void 0 : e.setItem(i, a);
                return a
            }
            return b
        } catch (b) {
            c("FBLogger")("labyrinth_web").warn("[labyrinth][web] Failed to set EB session identifier due to %s", b);
            return a
        }
    }
    var j = null;

    function k(a) {
        j == null && (j = a);
        return j
    }
    g.getFirstRestoreUpsellTime = a;
    g.getFirstRestoreUpsellTimeForEBLS = k
}), 98);
__d("ZenonRTWebBrowserFeatureSupport", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return typeof window.HTMLCanvasElement === "function" && typeof window.HTMLCanvasElement.prototype.captureStream === "function"
    }

    function b() {
        return g("getSenders")
    }

    function c() {
        return typeof window.RTCRtpSender === "function" && typeof window.RTCRtpSender.prototype.replaceTrack === "function"
    }

    function d() {
        return typeof window.RTCRtpSender === "function" && typeof window.RTCRtpSender.prototype.createEncodedStreams === "function"
    }

    function e() {
        return window.RTCRtpSender && "transform" in RTCRtpSender.prototype
    }

    function g(a) {
        return typeof RTCPeerConnection.prototype[a] === "function"
    }
    f.isCanvasStreamSupported = a;
    f.isGetSendersSupported = b;
    f.isReplaceTrackSupported = c;
    f.isInsertableStreamsSupported = d;
    f.isInsertableStreamsSupportedInSafari = e
}), 66);
__d("useEmptyFunction", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return
    }
    b = a;
    f["default"] = b
}), 66);
__d("usePrevious", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useRef;

    function a(a) {
        var b = j(null);
        i(function() {
            b.current = a
        });
        return b.current
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("EBSMGating", ["MAWWaitForBackendSetup", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        return c("gkx")("24151")
    }

    function a() {
        return d("MAWWaitForBackendSetup").isBackendSetupSuccessful() || h()
    }
    g.isPersistedEBTableEnabled = h;
    g.isBackendSetupSuccessfulForEBSM = a
}), 98);
__d("EBSMProperties", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = ["encrypted_backups_virtual_devices", "secure_encrypted_backups_recovery_code_status", "device_metadata", "secure_encrypted_backups_epochs", "secure_encrypted_backups_client_state", "encrypted_backups", "experiences_shared_state", "occamadillo_most_recent_message_per_thread", "auto_restore_opt_out"];
    b = new Set(["secure_encrypted_backups_client_state", "secure_encrypted_backups_epochs"]);
    c = {
        dbVersion: 5,
        mandatoryTables: b,
        persistedTables: new Set(a),
        persistedTablesArray: a
    };
    d = c;
    f["default"] = d
}), 66);
__d("MAWEncryptedBackupsPersistedDB", ["EBSMGating", "EBSMProperties", "FBLogger", "LSMetadata", "MAWCurrentUser", "MAWIndexedDBDeletion", "MAWIndexedDbMetadata", "MWEBODSCategory", "MWEBODSEntityKey.enum", "MWEBODSEntityName.enum", "ODS", "Promise", "QPLUserFlow", "WALoggerDeferred", "err", "gkx", "justknobx", "qex", "qpl", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB upgrade needed"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EBSM upgrade failed: ", ". Falling back to ephemeral LSDB"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB onVersionChange: closing the db"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB initialization successsful"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB initialization: db blocked"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB initialization failed"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Initializing EB state DB"]);
        p = function() {
            return a
        };
        return a
    }
    var q = null,
        r = c("justknobx")._("2243");

    function a() {
        if (q == null) throw c("err")("EB state IndexedDB should've been initialized");
        return q
    }
    var s = (i || (i = b("Promise"))).resolve();

    function e() {
        return s
    }

    function f(a) {
        a === void 0 && (a = !1);
        return !a && !d("EBSMGating").isPersistedEBTableEnabled() ? (i || (i = b("Promise"))).resolve() : (i || (i = b("Promise"))).resolve().then(function() {
            if (q == null) {
                c("QPLUserFlow").start(c("qpl")._(521471732, "1454"));
                (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").START);
                void d("WALoggerDeferred").LOG(p());
                var a = indexedDB.open(d("MAWIndexedDbMetadata").ebLSDBName(d("MAWCurrentUser").getID()), c("EBSMProperties").dbVersion);
                return new(i || (i = b("Promise")))(function(e, f) {
                    a.onerror = function(a) {
                        c("QPLUserFlow").endFailure(c("qpl")._(521471732, "1454"), "EB state idb initialization failed"), void d("WALoggerDeferred").ERROR(o()), c("QPLUserFlow").endFailure(c("qpl")._(521477507, "1406"), "Initialisation failed. Reached onerror."), c("FBLogger")("labyrinth_web").catching(a).mustfix("[labyrinth_web] EBSM idb init failed: %s", a), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").FAIL), f(a)
                    }, a.onblocked = function() {
                        void d("WALoggerDeferred").LOG(n()), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, "blocked")
                    }, a.onsuccess = function(a) {
                        var b = a.target.result;
                        void d("WALoggerDeferred").LOG(m());
                        b.onversionchange = function() {
                            void d("WALoggerDeferred").LOG(l()), b.close()
                        };
                        q = b;
                        return s.then(function() {
                            c("QPLUserFlow").endSuccess(c("qpl")._(521471732, "1454")), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").SUCCESS), e(b)
                        })["catch"](function(a) {
                            void d("WALoggerDeferred").ERROR(k(), a.message), c("QPLUserFlow").endFailure(c("qpl")._(521471732, "1454"), "EB state idb upgrade failed"), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, "upgrade.fail"), h.bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").FAIL), e(null)
                        })
                    }, a.onupgradeneeded = function(a) {
                        var e = a.target.result;
                        a = new(i || (i = b("Promise")))(function(a, b) {
                            setTimeout(function() {
                                b(c("err")("EBSM upgrade timeout"))
                            }, r)
                        });
                        var f = new i(function(a) {
                            c("QPLUserFlow").addPoint(c("qpl")._(521471732, "1454"), "eb_state_idb_upgrade_start", {
                                data: {
                                    bool: {
                                        eb_state_upgrade: !0
                                    }
                                }
                            });
                            void d("WALoggerDeferred").LOG(j());
                            var b = Object.keys(d("LSMetadata").schema.tableNames);
                            for (var f = 0; f < b.length; f++) {
                                var g = b[f];
                                c("EBSMProperties").persistedTables.has(g) && !e.objectStoreNames.contains(g) && e.createObjectStore(g, {
                                    autoIncrement: !0
                                })
                            }
                            c("QPLUserFlow").addPoint(c("qpl")._(521471732, "1454"), "eb_state_idb_upgrade_end", {
                                data: {
                                    bool: {
                                        eb_state_upgrade: !0
                                    }
                                }
                            });
                            a()
                        });
                        s = i.race([f, a])
                    }
                })
            } else return q
        })
    }

    function t(a) {
        a = a.hasUserGivenAutoRestoreConsent;
        var b = a ? ["secure_encrypted_backups_epochs", "secure_encrypted_backups_client_state"] : [];
        c("qex")._("926") && b.push("occamadillo_most_recent_message_per_thread");
        c("gkx")("5229") && b.push("auto_restore_opt_out");
        a = Array.from(c("EBSMProperties").persistedTables).filter(function(a) {
            return !b.includes(a)
        });
        try {
            if (q != null) {
                var d = q.transaction(a, "readwrite");
                a.forEach(function(a) {
                    a = d.objectStore(a);
                    a.clear()
                });
                d.oncomplete = function() {
                    d.db.close()
                }
            }
        } catch (a) {
            c("recoverableViolation")(a, "labyrinth_web")
        }
    }

    function u() {
        var a = d("MAWIndexedDbMetadata").ebLSDBName(d("MAWCurrentUser").getID());
        return d("MAWIndexedDBDeletion").deleteDB(a, "ebsm")
    }

    function v(a) {
        if (q != null) {
            var c = q.transaction([a], "readwrite");
            a = c.objectStore(a);
            a.clear();
            c.oncomplete = function() {
                c.db.close()
            }
        }
        return (i || (i = b("Promise"))).resolve()
    }
    g.getEBLSDB = a;
    g.isDBBeingUpgraded = e;
    g.makeEBIDB = f;
    g.clearEBIDBNonPersistedRows = t;
    g.deleteEBIDB = u;
    g.clearEBSMTable = v
}), 98); /*FB_PKG_DELIM*/
__d("JSResource", ["JSResourceReferenceImpl"], (function(a, b, c, d, e, f, g) {
    var h = {};

    function i(a, b) {
        h[a] = b
    }

    function j(a) {
        return h[a]
    }

    function a(a) {
        a = a;
        var b = j(a);
        if (b) return b;
        b = new(c("JSResourceReferenceImpl"))(a);
        i(a, b);
        return b
    }
    a.loadAll = c("JSResourceReferenceImpl").loadAll;
    g["default"] = a
}), 98);
__d("JSResourceForInteraction", ["JSResource"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return c("JSResource").call(null, a)
    }
    b = a;
    g["default"] = b
}), 98);
__d("MWCMChatsFullBannerRootQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5804383839665166"
}), null);
__d("MWCMChatsFullBannerRootQuery$Parameters", ["MWCMChatsFullBannerRootQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWCMChatsFullBannerRootQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWCMChatsFullBannerRootQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6072064999529637"
}), null);
__d("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery$Parameters", ["MWCMInboxLeftRailSidebarBusinessSupportButtonQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWCMInboxLeftRailSidebarBusinessSupportButtonQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWCMThreadListQPBannerContainerQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6673229072767704"
}), null);
__d("MWCMThreadListQPBannerContainerQuery$Parameters", ["MWCMThreadListQPBannerContainerQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWCMThreadListQPBannerContainerQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWCMThreadListQPBannerContainerQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWChatEncryptedBackupsUpsellMessengerInboxQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "26639038685694819"
}), null);
__d("MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters", ["MWChatEncryptedBackupsUpsellMessengerInboxQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWChatEncryptedBackupsUpsellMessengerInboxQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWChatEncryptedBackupsUpsellMessengerInboxQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWChatMediaRootQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6057149221048635"
}), null);
__d("MWEncryptedBackupsThreadListNuxWrapperQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8425379747569466"
}), null);
__d("MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters", ["MWEncryptedBackupsThreadListNuxWrapperQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWEncryptedBackupsThreadListNuxWrapperQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWEncryptedBackupsThreadListNuxWrapperQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWLSInboxQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6909378019106583"
}), null);
__d("MWLSInboxQuery$Parameters", ["MWLSInboxQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWLSInboxQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWLSInboxQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWQuickPromotionDesktopInterstitialUpsellQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6587787004613839"
}), null);
__d("MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters", ["MWQuickPromotionDesktopInterstitialUpsellQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWQuickPromotionDesktopInterstitialUpsellQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWQuickPromotionDesktopInterstitialUpsellQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("createGenericCompoundEntryPointBuilder", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return function(c) {
            return {
                getPreloadProps: function(a) {
                    return {
                        entryPoints: c(a),
                        extraProps: null,
                        queries: b(a)
                    }
                },
                root: a
            }
        }
    }
    f["default"] = a
}), 66);
__d("createContentAreaCompoundEntryPointBuilder", ["createGenericCompoundEntryPointBuilder"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var d = c("createGenericCompoundEntryPointBuilder")(a, b);
        return function(a, b) {
            var c = {
                getPreloadProps: b,
                root: a
            };
            return d(function(a) {
                return {
                    contentEntryPoint: {
                        entryPoint: c,
                        entryPointParams: a
                    }
                }
            })
        }
    }
    g["default"] = a
}), 98);
__d("buildMWInboxRoot.entrypoint", ["JSResourceForInteraction", "MWCMInboxLeftRailSidebarBusinessSupportButtonQuery$Parameters", "MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters", "MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters", "MWLSInboxQuery$Parameters", "MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters", "createContentAreaCompoundEntryPointBuilder", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("gkx")("33119"),
        i = c("gkx")("1625"),
        j = i || h,
        k = c("gkx")("3730");
    a = c("createContentAreaCompoundEntryPointBuilder")(c("JSResourceForInteraction")("MWInboxRoot.react").__setRef("buildMWInboxRoot.entrypoint"), function(a) {
        a = {};
        j && (a.mWChatEncryptedBackupsRestoreUpsellMessengerInboxQueryReference = {
            parameters: b("MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters"),
            variables: {
                doesUserHaveAnEB: i,
                isEBWebOnlyOnboardingEnabled: h
            }
        });
        a.mWEncryptedBackupsThreadListNuxWrapper = {
            parameters: b("MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters"),
            variables: {
                qpWithPinEnabled: k
            }
        };
        !c("gkx")("2669") && c("gkx")("1002") && (a.mWQuickPromotionDesktopInterstitialUpsell = {
            parameters: b("MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters"),
            variables: {}
        }, a.mCMInboxLeftRailSidebarBusinessSupportButtonQueryRef = {
            parameters: b("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery$Parameters"),
            variables: {}
        });
        return a
    });
    d = c("createContentAreaCompoundEntryPointBuilder")(c("JSResourceForInteraction")("MWLSInbox.react").__setRef("buildMWInboxRoot.entrypoint"), function(a) {
        a = {
            mWLSInboxQueryReference: {
                parameters: b("MWLSInboxQuery$Parameters"),
                variables: {}
            }
        };
        j && (a.mWChatEncryptedBackupsRestoreUpsellMessengerInboxQueryReference = {
            parameters: b("MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters"),
            variables: {
                doesUserHaveAnEB: i,
                isEBWebOnlyOnboardingEnabled: h
            }
        });
        a.mWEncryptedBackupsThreadListNuxWrapper = {
            parameters: b("MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters"),
            variables: {
                qpWithPinEnabled: k
            }
        };
        !c("gkx")("2669") && c("gkx")("1002") && (a.mWQuickPromotionDesktopInterstitialUpsell = {
            parameters: b("MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters"),
            variables: {}
        });
        return a
    });
    e = c("gkx")("23433") ? a : d;
    f = e;
    g["default"] = f
}), 98);
__d("MWInboxArchivedThreadsRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxArchivedThreadsRoot.react").__setRef("MWInboxArchivedThreadsRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("MWInboxCommunityThreadsRoot.entrypoint", ["JSResourceForInteraction", "MWCMChatsFullBannerRootQuery$Parameters", "MWCMThreadListQPBannerContainerQuery$Parameters", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxCommunityThreadsRoot.react").__setRef("MWInboxCommunityThreadsRoot.entrypoint"), function(a) {
        a = a.routeProps;
        return {
            queries: {
                qpBannerContainerQueryRef: {
                    parameters: c("MWCMThreadListQPBannerContainerQuery$Parameters"),
                    variables: {
                        fb_group_id: a.fb_group_id
                    }
                },
                queryReference: {
                    parameters: b("MWCMChatsFullBannerRootQuery$Parameters"),
                    variables: {
                        folderID: a.folder_id
                    }
                }
            }
        }
    });
    g["default"] = a
}), 98);
__d("MWInboxHomeRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxHomeRoot.react").__setRef("MWInboxHomeRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("MWInboxMarketplaceThreadsRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxMarketplaceThreadsRoot.react").__setRef("MWInboxMarketplaceThreadsRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("MWInboxMessageRequestsRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxMessageRequestsRoot.react").__setRef("MWInboxMessageRequestsRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("ServerJsRuntimeEnvironment", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;

    function a(a, b) {
        i == null || h(0, 71696), i = {
            platform: a,
            executionContext: b
        }
    }

    function b() {
        return i != null
    }

    function c() {
        var a;
        return (a = i) == null ? void 0 : a.executionContext
    }

    function d() {
        var a;
        return (a = i) == null ? void 0 : a.platform
    }
    g.init = a;
    g.isRunningServerJsRuntime = b;
    g.getExecutionContext = c;
    g.getPlatform = d
}), 98);
__d("WAGetSafeQPLError", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a == null) return "<null>";
        return a instanceof Error || typeof a === "string" ? a.toString() : "<unknown>"
    }
    f.getSafeQPLErrorMessage = a
}), 66);
__d("WebPixelRatio", ["SiteData"], (function(a, b, c, d, e, f, g) {
    function a() {
        return c("SiteData").pr != null && c("SiteData").pr > 0 ? c("SiteData").pr : window.devicePixelRatio || 1
    }
    g.get = a
}), 98); /*FB_PKG_DELIM*/
__d("TrustedTypesWebWorkerScriptURLPolicy", ["TrustedTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        createScriptURL: function(a) {
            return a
        }
    };
    b = c("TrustedTypes").createPolicy("web-worker-url", a);
    d = b;
    g["default"] = d
}), 98);
__d("XCometFBMultiSiteWebWorkerV2HasteResponseControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/static_resources/webworker/rsrc/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("WebWorkerV2DynamicData", ["Promise", "XCometFBMultiSiteWebWorkerV2HasteResponseControllerRouteBuilder", "cometAsyncFetchShared", "err", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new Map();

    function a(a) {
        var b = a.name,
            c = i.get(b);
        c == null && (c = j(a), i.set(b, c));
        return c
    }

    function j(a) {
        var d = a.name,
            e = a.v2HasteResponsePreloader;
        if (e == null) return k(d);
        var f = null;
        a = new(h || (h = b("Promise")))(function(a, b) {
            e.onLoaded(function(b) {
                b = b.data;
                f = b;
                a(b)
            }).onError(b)
        });
        return h.race([a, new h(function(a, b) {
            window.setTimeout(function() {
                f == null ? c("promiseDone")(k(d), a, b) : a(f)
            }, 1e4)
        })])
    }

    function k(a) {
        return c("cometAsyncFetchShared")(c("XCometFBMultiSiteWebWorkerV2HasteResponseControllerRouteBuilder").buildUri({
            worker_module: a
        }).toString(), {
            data: {},
            getFullPayload: !0,
            method: "POST",
            skipSRState: !0
        }).then(function(b) {
            if (b != null && typeof b === "object" && Object.prototype.hasOwnProperty.call(b, "hrp") && typeof b.hrp === "object") return b;
            throw c("err")("Unexpected data from WorkerInitResourceDeliveryController for worker %s", a)
        })
    }
    g.readDynamicDataForWorker = a
}), 98);
__d("getWorkerInitScriptSPINParams", ["SiteData", "StaticSiteData", "objectEntries"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a, b, d, e = (b = c("SiteData"))[(d = c("StaticSiteData")).spin_mhenv_key];
        d = babelHelpers["extends"]((a = {}, a[d.hs_key] = b.haste_session, a[d.spin_rev_key] = b[d.spin_rev_key], a[d.spin_branch_key] = b[d.spin_branch_key], a[d.spin_time_key] = b[d.spin_time_key], a), Boolean(e) ? (b = {}, b[c("StaticSiteData").spin_mhenv_key] = e, b) : null);
        return new Map(c("objectEntries")(d))
    }
    g["default"] = a
}), 98);
__d("XCometFBMultiSiteWebWorkerV2InitScriptControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/static_resources/webworker/init_script/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("supportsModuleWorker", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;

    function a(a) {
        if (h != null) return h;
        if (h != null) return h;
        if (c("UserAgent").isEngine("Blink")) {
            h = a ? c("UserAgent").isEngine_DEPRECATED_DANGEROUS("Blink > 83") : c("UserAgent").isEngine_DEPRECATED_DANGEROUS("Blink > 80.1");
            return h
        }
        if (c("UserAgent").isBrowser("Safari")) {
            h = c("UserAgent").isBrowser("Safari > 14.9");
            return h
        }
        if (c("UserAgent").isBrowser("Firefox")) {
            h = c("UserAgent").isBrowser("Firefox > 113");
            return h
        }
        if (c("UserAgent").isEngine("WebKit")) {
            h = c("UserAgent").isEngine_DEPRECATED_DANGEROUS("WebKit > 606");
            return h
        }
        if (c("UserAgent").isBrowser("IE")) {
            h = !1;
            return h
        }
        var b = {
            get type() {
                h = !0
            }
        };
        try {
            a ? new SharedWorker("blob://", b) : new Worker("blob://", b)
        } finally {
            h = (a = h) != null ? a : !1;
            return h
        }
    }
    g["default"] = a
}), 98);
__d("WebWorkerV2Resource", ["TrustedTypesWebWorkerScriptURLPolicy", "WebWorkerV2DynamicData", "XCometFBMultiSiteWebWorkerV2InitScriptControllerRouteBuilder", "forEachObject", "getAsyncParamsFromCurrentPageURI", "getWorkerInitScriptSPINParams", "nullthrows", "promiseDone", "supportsModuleWorker"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = (b = b) != null ? b : a.name;
        var e = c("supportsModuleWorker")(!1) ? "module" : "classic",
            f = c("getWorkerInitScriptSPINParams")();
        c("forEachObject")(c("getAsyncParamsFromCurrentPageURI")(), function(a, b) {
            f.set(b, a)
        });
        var g = c("nullthrows")(c("XCometFBMultiSiteWebWorkerV2InitScriptControllerRouteBuilder").buildUri({
            worker_type: c("supportsModuleWorker")(!1) ? "MODULE" : "CLASSIC"
        }).addQueryParams(f)).toString();
        g = c("TrustedTypesWebWorkerScriptURLPolicy").createScriptURL(g);
        var h = new Worker(g, {
            name: b,
            type: e
        });
        c("promiseDone")(d("WebWorkerV2DynamicData").readDynamicDataForWorker(a).then(function(a) {
            h.postMessage({
                type: "ww-hrp-init",
                hrp: a.hrp,
                js_env: a.js_env,
                is_dev: !1,
                tiered: !0
            })
        }));
        return {
            worker: h,
            url: g.toString()
        }
    }
    g.createDedicatedV2WebWorker = a
}), 98); /*FB_PKG_DELIM*/
__d("BrowserLockManager", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = typeof window !== "undefined" ? window : self;
    c = a == null ? void 0 : (b = a.navigator) == null ? void 0 : b.locks;
    f["default"] = c
}), 66);
__d("LockManager", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        Exclusive: "exclusive",
        Shared_NOT_IMPLEMENTED: "shared"
    });
    f.LockMode = a
}), 66);
__d("hasMultipleTabs", ["BrowserLockManager", "FBLogger", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "multiple_tab_lock";

    function a(a) {
        var d, e;
        return b("regeneratorRuntime").async(function(f) {
            while (1) switch (f.prev = f.next) {
                case 0:
                    a === void 0 && (a = !0);
                    f.prev = 1;
                    if (!c("BrowserLockManager")) {
                        f.next = 11;
                        break
                    }
                    f.next = 5;
                    return b("regeneratorRuntime").awrap(c("BrowserLockManager").query());
                case 5:
                    d = f.sent;
                    e = d.held.filter(function(a) {
                        return a.name === h
                    }).length + d.pending.filter(function(a) {
                        return a.name === h
                    }).length;
                    a || e++;
                    if (!(e > 1)) {
                        f.next = 10;
                        break
                    }
                    return f.abrupt("return", !0);
                case 10:
                    return f.abrupt("return", !1);
                case 11:
                    return f.abrupt("return");
                case 14:
                    f.prev = 14;
                    f.t0 = f["catch"](1);
                    c("FBLogger")("messenger_e2ee_web").catching(f.t0).warn("[MultipleTabsLogger] Fail to query lock manager");
                    return f.abrupt("return");
                case 18:
                case "end":
                    return f.stop()
            }
        }, null, this, [
            [1, 14]
        ])
    }
    g.MULTIPLE_TAB_LOCK_NAME = h;
    g.hasMultipleTabs = a
}), 98);
__d("memoizeOneWithArgs", ["areEqual"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b) {
        b === void 0 && (b = h || (h = c("areEqual")));
        var d, e, f = !1;
        return function() {
            for (var c = arguments.length, g = new Array(c), h = 0; h < c; h++) g[h] = arguments[h];
            if (f && b(g, d)) return e;
            d = g;
            e = a.apply(void 0, g);
            f = !0;
            return e
        }
    }
    g["default"] = a
}), 98);
__d("MultipleTabsLogger", ["BrowserLockManager", "InteractionTracingMetrics", "LockManager", "Promise", "QPLUserFlow", "hasMultipleTabs", "memoizeOneWithArgs", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = !1,
        j = !1;

    function a() {
        return i
    }

    function k() {
        return d("hasMultipleTabs").hasMultipleTabs(j)
    }

    function l() {
        var a;
        return b("regeneratorRuntime").async(function(c) {
            while (1) switch (c.prev = c.next) {
                case 0:
                    c.next = 2;
                    return b("regeneratorRuntime").awrap(k());
                case 2:
                    a = c.sent;
                    return c.abrupt("return", a != null ? a.toString() : "undefined");
                case 4:
                case "end":
                    return c.stop()
            }
        }, null, this)
    }

    function e(a) {
        void l().then(function(b) {
            return c("InteractionTracingMetrics").addMetadata(a, "multipleTabs", b)
        })
    }

    function f(a, b) {
        void l().then(function(d) {
            b !== null ? c("QPLUserFlow").addAnnotations(a, {
                string: {
                    multipleTabs: d
                }
            }, {
                instanceKey: b
            }) : c("QPLUserFlow").addAnnotations(a, {
                string: {
                    multipleTabs: d
                }
            })
        })
    }
    var m = c("memoizeOneWithArgs")(function(a) {
        c("BrowserLockManager") && (j = !0, void c("BrowserLockManager").request(d("hasMultipleTabs").MULTIPLE_TAB_LOCK_NAME, {
            mode: d("LockManager").LockMode.Exclusive
        }, function(c) {
            if (c) {
                i = !0;
                return new(h || (h = b("Promise")))(function(b) {
                    if (a) return b(a())
                })
            }
        }))
    });
    g.hasUniqueLock = a;
    g.hasMultipleTabs = k;
    g.getMultipleTabsAnnotation = l;
    g.addAnnotationWithInteractionUuid = e;
    g.addAnnotationToQPLEvent = f;
    g.init = m
}), 98); /*FB_PKG_DELIM*/
__d("Deferred", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;
    (g || (g = b("Promise"))).resolve();
    a = function() {
        function a(a) {
            var c = this;
            a = a || g || (g = b("Promise"));
            this.$1 = !1;
            this.$2 = new a(function(a, b) {
                c.$3 = a, c.$4 = b
            })
        }
        var c = a.prototype;
        c.getPromise = function() {
            return this.$2
        };
        c.resolve = function(a) {
            this.$1 = !0, this.$3(a)
        };
        c.reject = function(a) {
            this.$1 = !0, this.$4(a)
        };
        c.isSettled = function() {
            return this.$1
        };
        return a
    }();
    f["default"] = a
}), 66); /*FB_PKG_DELIM*/
__d("WAHashStringToNumber", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = 0;
        for (var c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            b = (b << 5) - b + d;
            b |= 0
        }
        return Math.abs(b)
    }
    f.hashStringToNumber = a
}), 66);