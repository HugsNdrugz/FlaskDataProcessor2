; /*FB_PKG_DELIM*/

__d("CometFullScreen", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a) {
        var c = a.requestFullscreen || a.mozRequestFullScreen || a.msRequestFullscreen || a.webkitRequestFullscreen;
        return typeof c === "function" ? c.call(a) : (g || (g = b("Promise"))).reject()
    }

    function c() {
        var a = document.exitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen || document.webkitExitFullscreen;
        return typeof a === "function" ? a.call(document) : (g || (g = b("Promise"))).reject()
    }

    function d() {
        return (document.webkitFullscreenEnabled === !0 || document.mozFullScreenEnabled === !0 || document.msFullscreenEnabled === !0 || document.fullscreenEnabled === !0) && (typeof document.webkitExitFullscreen === "function" || typeof document.mozCancelFullScreen === "function" || typeof document.msExitFullscreen === "function" || typeof document.exitFullscreen === "function")
    }

    function h() {
        return document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement || document.mozFullScreenElement || null
    }

    function e() {
        return h() != null
    }

    function i() {
        return ["webkitfullscreenchange", "mozfullscreenchange", "MSFullscreenChange", "fullscreenchange"]
    }

    function j(a) {
        var b = window.document,
            c = !1,
            d = !0;
        i().forEach(function(e) {
            b.addEventListener(e, a, {
                capture: c,
                passive: d
            })
        });
        return function() {
            i().forEach(function(d) {
                b.removeEventListener(d, a, c)
            })
        }
    }
    f.requestFullScreen = a;
    f.exitFullScreen = c;
    f.isSupported = d;
    f.getFullScreenElement = h;
    f.isFullScreen = e;
    f.getFullScreenChangeEventNames = i;
    f.subscribeToFullScreenChangeEvent = j
}), 66);
__d("CometNotificationsRootContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = {
        isNotificationsRoute: !1,
        source: null
    };
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("CometVideoPictureInPictureManagerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    c = (h || d("react")).createContext;
    e = c({
        openPipPlayer: function() {},
        setController: function() {},
        setPipPortableVideoID: function() {}
    });
    f = c({
        hasNextChainedVideo: !1,
        isPipEnabled: !1,
        setHasNextChainedVideo: function() {},
        setSkippedFromPipPlayer: function() {},
        skippedFromPipPlayer: !1
    });

    function a() {
        return !1
    }

    function b() {
        return !1
    }
    g.CometVideoPictureInPictureManagerAPIContext = e;
    g.CometVideoPictureInPictureManagerContext = f;
    g.isInPictureInPictureExp = a;
    g.isInPictureInPictureExpControlGroup = b
}), 98);
__d("PlaybackSpeedExperiments", ["CurrentUser", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        return c("gkx")("26216")
    }

    function i() {
        return !1
    }

    function a() {
        return h() || i() ? !0 : !1
    }

    function j() {
        return i() ? !1 : !1
    }

    function b() {
        return c("CurrentUser").getID() !== "0"
    }

    function d() {
        if (h()) return !1;
        if (i()) return !0;
        return j() ? !1 : !1
    }

    function e() {
        return !0
    }
    g.enableWwwPlaybackSpeedControl = a;
    g.isInCometHeadroomTest = j;
    g.enableCometPlaybackSpeedControl = b;
    g.enableCometPlaybackSpeedControlNUX = d;
    g.enablePlaybackSpeedLogging = e
}), 98);
__d("VideoControlsContainerFocusedContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("VideoHomeTypedLiteLogger", ["generateLiteTypedLogger"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("generateLiteTypedLogger")("logger:VideoHomeLoggerConfig")
}), null);
__d("VideoPlaybackQuality", [], (function(a, b, c, d, e, f) {
    function a(a) {
        if (typeof a.getVideoPlaybackQuality === "function") return a.getVideoPlaybackQuality().droppedVideoFrames;
        a = a.webkitDroppedFrameCount;
        return typeof a === "number" ? a : 0
    }

    function b(a) {
        if (typeof a.getVideoPlaybackQuality === "function") return a.getVideoPlaybackQuality().totalVideoFrames;
        a = a.webkitDecodedFrameCount;
        return typeof a === "number" ? a : 0
    }
    f.getDroppedFrames = a;
    f.getTotalFrames = b
}), 66);
__d("VideoPlayerContextSensitiveConfigUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = function(a, b) {
        return b.every(function(b) {
            return a[b.name] === b.value
        })
    };
    a = function(a, b) {
        return b.find(function(b) {
            return g(a, b.contexts)
        })
    };
    f.getFirstMatchingValueAndContextTargets = a
}), 66);
__d("VideoPlayerContextSensitiveConfigResolver", ["VideoPlayerContextSensitiveConfigPayload", "VideoPlayerContextSensitiveConfigUtils", "cr:1724253"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            this.$1 = {}, this.$2 = {}, a == null ? (this.$3 = c("VideoPlayerContextSensitiveConfigPayload").static_values, this.$4 = c("VideoPlayerContextSensitiveConfigPayload").context_sensitive_values) : (this.$3 = a.staticValues, this.$4 = a.contextSensitiveValues)
        }
        var e = a.prototype;
        e.setContexts = function(a) {
            this.$1 = a, this.$2 = this.$5(a)
        };
        e.getValue = function(a) {
            if (this.$2[a] != null) return this.$2[a];
            return this.$3[a] != null ? this.$3[a] : null
        };
        e.$5 = function(a) {
            var b = this;
            return Object.keys(this.$4).reduce(function(c, e) {
                var f = b.$4[e];
                if (f != null) {
                    f = d("VideoPlayerContextSensitiveConfigUtils").getFirstMatchingValueAndContextTargets(a, f);
                    f != null && (c[e] = f.value)
                }
                return c
            }, {})
        };
        a.getPayload = function() {
            return c("VideoPlayerContextSensitiveConfigPayload")
        };
        a.getSources = function() {
            return b("cr:1724253")
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoPlayerControlsHiddenContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("VideoPlayerControlIcon.react", ["BaseFocusRing.react", "BaseTooltip.react", "CometPressable.react", "CometTooltipImpl.react", "TetraIcon.react", "VideoPlayerControlsHiddenContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            "default": {
                backgroundColor: "xjbqb8w",
                borderTop: "x76ihet",
                borderEnd: "xwmqs3e",
                borderBottom: "x112ta8",
                borderStart: "xxxdfa6",
                cursor: "x1ypdohk",
                display: "x1rg5ohu",
                height: "x1qx5ct2",
                marginTop: "x1k70j0n",
                marginEnd: "x1w0mnb",
                marginBottom: "xzueoph",
                marginStart: "x1mnrxsn",
                opacity: "x1iy03kw",
                outline: "x1a2a7pz",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                ":hover_opacity": "x1o7uuvo",
                $$css: !0
            },
            disabled: {
                cursor: "xt0e3qv",
                opacity: "xbyyjgo",
                ":hover_opacity": "xj34u2y",
                $$css: !0
            },
            dropShadow: {
                filter: "x1qo4wvw",
                $$css: !0
            }
        };

    function l(a) {
        var b = a.tooltipOffsetY,
            d = a.children;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["tooltipOffsetY", "children"]);
        b = Math.min(0, (b = b) != null ? b : 0);
        return i.jsx("span", {
            className: "xuk3077 x78zum5 x14atkfc",
            style: {
                marginTop: b
            },
            children: i.jsx(c("BaseTooltip.react"), babelHelpers["extends"]({}, a, {
                children: i.jsx("span", {
                    className: "xuk3077 x78zum5 x14atkfc",
                    style: {
                        paddingTop: -b
                    },
                    children: d
                })
            }))
        })
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.color,
            d = b === void 0 ? "white" : b,
            e = a.disabled,
            f = a.icon,
            g = a.label;
        b = a.tooltip;
        b = b === void 0 ? null : b;
        var h = a.tooltipAlign;
        h = h === void 0 ? "start" : h;
        var m = a.tooltipImpl,
            n = a.tooltipOffsetY,
            o = babelHelpers.objectWithoutPropertiesLoose(a, ["color", "disabled", "icon", "label", "tooltip", "tooltipAlign", "tooltipImpl", "tooltipOffsetY"]),
            p = j(c("VideoPlayerControlsHiddenContext"));
        return i.jsx(l, {
            align: h,
            position: "above",
            tooltip: b,
            tooltipImpl: (a = m) != null ? a : c("CometTooltipImpl.react"),
            tooltipOffsetY: n,
            children: i.jsx(c("BaseFocusRing.react"), {
                children: function(a) {
                    return i.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, o, {
                        disabled: e,
                        display: "inline",
                        label: g,
                        overlayDisabled: !0,
                        testid: void 0,
                        xstyle: [k["default"], e === !0 && k.disabled, a, p === !0 && k.dropShadow],
                        children: i.jsx(c("TetraIcon.react"), {
                            color: d,
                            icon: f
                        })
                    }))
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerControlsBottomRowAddOnContext", ["react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    d = h;
    var j = d.useContext,
        k = d.useEffect,
        l = d.useState,
        m = i.createContext(null);

    function a(a) {
        a = a.children;
        var b = c("useStable")(function() {
            var a = null,
                b = null,
                c = null;
            return {
                getBottomRowAddOn: function() {
                    return b
                },
                initialize: function(d) {
                    c = function(a) {
                        b = a, d(a)
                    };
                    if (a == null) return;
                    c(a);
                    a = null
                },
                setBottomRowAddOn: function(b) {
                    if (c == null) {
                        a = b;
                        return
                    }
                    c(b)
                }
            }
        });
        return i.jsx(m.Provider, {
            value: b,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = j(m);
        a = l(a);
        var c = a[0],
            d = a[1];
        k(function() {
            if (b == null) return;
            b.initialize(d)
        }, [b]);
        return c
    }
    b.displayName = b.name + " [from " + f.id + "]";

    function e(a) {
        var b = j(m);
        k(function() {
            if (b == null) return;
            b.setBottomRowAddOn(a)
        }, [a, b])
    }
    g.VideoPlayerControlsBottomRowAddOnContext = m;
    g.VideoPlayerControlsBottomRowAddOnContextProvider = a;
    g.useVideoPlayerControlsBottomRowAddOn = b;
    g.useSetVideoPlayerControlsBottomRowAddOn = e
}), 98);
__d("VideoPlayerControlsContainerOverlay.react", ["CometErrorBoundary.react", "FocusWithinHandler.react", "VideoControlsContainerFocusedContext", "VideoPlayerControlsBottomRowAddOnContext", "VideoPlayerControlsHiddenContext", "VideoPlayerHooks", "gkx", "react", "stylex", "useResizeObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = i || (i = d("react"));
    b = i;
    var l = b.useEffect,
        m = b.useState,
        n = 44,
        o = {
            backgroundGradient: {
                backgroundImage: "x11v4dcs",
                bottom: "x1ey2m1c",
                position: "x10l6tqk",
                transitionDuration: "x1d8287x",
                transitionProperty: "x6o7n8i",
                transitionTimingFunction: "xl405pv",
                width: "xh8yej3",
                zIndex: "x8knxv4",
                $$css: !0
            },
            "default": {
                bottom: "x1ey2m1c",
                flexDirection: "x1q0g3np",
                position: "x10l6tqk",
                transitionDuration: "x1d8287x",
                transitionProperty: "x6o7n8i",
                transitionTimingFunction: "xl405pv",
                width: "xh8yej3",
                zIndex: "x11uqc5h",
                $$css: !0
            },
            firstRow: {
                alignItems: "x6s0dn4",
                direction: "xzt5al7",
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                $$css: !0
            },
            hidden: {
                opacity: "xg01cxk",
                pointerEvents: "x47corl",
                visibility: "xlshs6z",
                $$css: !0
            },
            visible: {
                opacity: "x1hc1fzr",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.children,
            e = a.height,
            f = a.initialBottomRowAddOn;
        f = f === void 0 ? null : f;
        var g = a.isBackgroundVisible,
            i = a.isVisible,
            p = a.xstyle;
        a = m(0);
        var q = a[0],
            r = a[1],
            s = c("useResizeObserver")(function(a) {
                r(a.height)
            }),
            t = d("VideoPlayerControlsBottomRowAddOnContext").useVideoPlayerControlsBottomRowAddOn(f);
        a = (j || (j = d("VideoPlayerHooks"))).useVideoPlayerCaptionsReservationActions();
        var u = a.release,
            v = a.reserve,
            w = (f = e) != null ? f : n;
        l(function() {
            if (Boolean(i) || Boolean(g)) {
                var a = v({
                    location: "bottom",
                    size: w
                });
                return function() {
                    u(a)
                }
            }
        }, [i, g, v, u, w]);
        var x = g === !1 || i === !1,
            y = g === !0 || i === !0;
        return k.jsx(c("FocusWithinHandler.react"), {
            children: function(a, d) {
                return k.jsx(c("VideoControlsContainerFocusedContext").Provider, {
                    value: d,
                    children: k.jsxs("div", {
                        className: (h || (h = c("stylex")))(o["default"], t == null && o.firstRow, i === !1 && o.hidden, i === !0 && o.visible),
                        "data-testid": void 0,
                        children: [k.jsx("div", {
                            className: h(o.backgroundGradient, x && o.hidden, y && o.visible, p),
                            style: {
                                height: w + (c("gkx")("6991") ? q : 0)
                            }
                        }), k.jsx(c("VideoPlayerControlsHiddenContext").Provider, {
                            value: x,
                            children: t == null ? b : k.jsxs(k.Fragment, {
                                children: [k.jsx("div", {
                                    className: "x6s0dn4 xzt5al7 x78zum5 x1q0g3np",
                                    children: b
                                }), k.jsx(c("CometErrorBoundary.react"), {
                                    children: c("gkx")("6991") ? k.jsx("div", {
                                        ref: s,
                                        children: t
                                    }) : t
                                })]
                            })
                        })]
                    })
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerControlsGroups.react", ["VideoControlsContainerFocusedContext", "VideoPlayerControlsHiddenContext", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useContext,
        l = {
            contracted: {
                paddingTop: "xexx8yu",
                paddingEnd: "x1mpkggp",
                paddingBottom: "x18d9i69",
                paddingStart: "x1t2a60a",
                $$css: !0
            },
            "default": {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                flexShrink: "x2lah0s",
                flexWrap: "xozqiw3",
                $$css: !0
            },
            expanded: {
                flexGrow: "x1iyjqo2",
                $$css: !0
            },
            hidden: {
                opacity: "x1fmh03i",
                pointerEvents: "x47corl",
                $$css: !0
            },
            noPaddingEnd: {
                paddingEnd: "x4uap5",
                $$css: !0
            },
            noPaddingStart: {
                paddingStart: "xkhd6sd",
                $$css: !0
            },
            visible: {
                opacity: "x1hc1fzr",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.children,
            d = a.isVisible;
        d = d === void 0 ? !0 : d;
        var e = a.noPaddingEnd;
        e = e === void 0 ? !1 : e;
        a = a.noPaddingStart;
        a = a === void 0 ? !1 : a;
        var f = k(c("VideoControlsContainerFocusedContext"));
        d = d || f;
        f = k(c("VideoPlayerControlsHiddenContext"));
        return j.jsx("div", {
            className: (h || (h = c("stylex")))(l["default"], l.contracted, e && l.noPaddingEnd, a && l.noPaddingStart, d ? l.visible : l.hidden),
            children: j.jsx(c("VideoPlayerControlsHiddenContext").Provider, {
                value: f || !d,
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = a.children,
            d = a.isVisible;
        d = d === void 0 ? !0 : d;
        a.noPaddingEnd;
        a.noPaddingStart;
        a = k(c("VideoControlsContainerFocusedContext"));
        d = d || a;
        a = k(c("VideoPlayerControlsHiddenContext"));
        return j.jsx("div", {
            className: (h || (h = c("stylex")))(l["default"], l.expanded, d ? l.visible : l.hidden),
            children: j.jsx(c("VideoPlayerControlsHiddenContext").Provider, {
                value: a || !d,
                children: b
            })
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g.Contracted = a;
    g.Expanded = b
}), 98);
__d("VideoPlayerDefaultControlsProperties", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["SAME_AS_OTHER_CONTROLS", "SEPARATE_FROM_OTHER_CONTROLS"]);
    c = b("$InternalEnum")({
        VIDEO_CAPTIONS_MENU: "video_captions_menu",
        VIDEO_SETTINGS_MENU: "video_settings_menu"
    });
    f.MutedButtonVisibility = a;
    f.VideoMenuType = c
}), 66);
__d("VideoPlayerFallbackLearnMoreLink.react", ["fbt", "CometLink.react", "FDSText.react", "gkx", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a() {
        var a = c("gkx")("20836") ? "/help/work/1876956335887765/i-cant-view-or-play-videos-on-workplace" : "https://www.facebook.com/help/396404120401278/list";
        return j.jsx(c("FDSText.react"), {
            color: "primaryOnMedia",
            type: "headlineEmphasized3",
            children: j.jsx(c("CometLink.react"), {
                href: a,
                target: "_blank",
                children: h._("__JHASH__GWeGP0j1NWF__JHASH__")
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerFallbackCoverImplWithoutRetry.react", ["FDSText.react", "VideoPlayerFallbackLearnMoreLink.react", "cr:1672302", "cr:4149", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            banner: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                width: "x3es6ox",
                $$css: !0
            },
            showOverBackground: {
                zIndex: "x1vjfegm",
                $$css: !0
            }
        };

    function a(a) {
        var d = a.background,
            e = a.debugError,
            f = a.message,
            g = a.showDebugWithoutError;
        g = g === void 0 ? !0 : g;
        a = a.showLearnMoreLink;
        a = a === void 0 ? !0 : a;
        return j.jsxs("div", {
            className: "x6s0dn4 xatbrnm x9f619 x78zum5 x5yr21d xl56j7k x6ikm8r x10wlt62 x889kno x1iji9kk x1a8lsjc x1sln4lm x1n2onr6 xh8yej3",
            children: [j.jsxs("div", {
                className: (h || (h = c("stylex")))([k.banner, d != null && k.showOverBackground]),
                children: [j.jsx("div", {
                    className: "x6s0dn4 x78zum5 xdt5ytf x193iq5w",
                    children: j.jsx(c("FDSText.react"), {
                        align: "center",
                        color: "primaryOnMedia",
                        type: "bodyLink3",
                        children: f
                    })
                }), a && j.jsx("div", {
                    className: "x6s0dn4 x78zum5 xdt5ytf xw7yly9 x193iq5w",
                    children: j.jsx(c("VideoPlayerFallbackLearnMoreLink.react"), {})
                }), (e != null || g) && j.jsxs(j.Fragment, {
                    children: [b("cr:4149") ? j.jsx(b("cr:4149"), {
                        error: e
                    }) : null, b("cr:1672302") ? j.jsx(b("cr:1672302"), {
                        error: e
                    }) : null]
                })]
            }), d != null && j.jsx("div", {
                className: "x1ey2m1c xds687c x17qophe x10l6tqk x13vifvy",
                children: d
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerFallbackCover.react", ["fbt", "VideoPlayerFallbackCoverImplWithoutRetry.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        var b = a.background,
            d = a.debugError,
            e = a.message,
            f = a.showDebugWithoutError;
        a = a.showLearnMoreLink;
        e = (e = e) != null ? e : h._("__JHASH__dzG08k88Xfs__JHASH__");
        return j.jsx(c("VideoPlayerFallbackCoverImplWithoutRetry.react"), {
            background: b,
            debugError: d,
            message: e,
            showDebugWithoutError: f,
            showLearnMoreLink: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerInstreamAdsStateHooks", ["createVideoStateHook"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = (d = d("createVideoStateHook")).createVideoStateHook(),
        i = h.stateHook,
        j = h.valueHook,
        k = [];

    function a() {
        return i(k)
    }

    function b() {
        return j(k)
    }
    h = d.createVideoStateHook();
    var l = h.stateHook,
        m = h.valueHook,
        n = null;

    function c() {
        return l(n)
    }

    function e() {
        return m(n)
    }
    h = d.createVideoStateHook();
    var o = h.setterHook,
        p = h.valueHook,
        q = !0;

    function f() {
        return o(q)
    }

    function r() {
        return p(q)
    }
    h = d.createVideoStateHook();
    var s = h.stateHook,
        t = h.valueHook,
        u = "INIT";

    function v() {
        return s(u)
    }

    function w() {
        return t(u)
    }
    h = d.createVideoStateHook();
    var x = h.stateHook,
        y = h.valueHook,
        z = !0;

    function A() {
        return x(z)
    }

    function B() {
        return y(z)
    }
    h = d.createVideoStateHook();
    var C = h.stateHook,
        D = h.valueHook,
        E = null;

    function F() {
        return C(E)
    }

    function G() {
        return D(E)
    }
    h = d.createVideoStateHook();
    var H = h.stateHook,
        I = h.valueHook,
        J = null;

    function K() {
        return H(J)
    }

    function L() {
        return I(J)
    }
    h = d.createVideoStateHook();
    var M = h.stateHook,
        N = h.valueHook,
        O = null;

    function P() {
        return M(O)
    }

    function Q() {
        return N(O)
    }
    h = d.createVideoStateHook();
    var R = h.stateHook,
        S = h.valueHook,
        T = null;

    function U() {
        return R(T)
    }

    function aa() {
        return S(T)
    }
    h = d.createVideoStateHook();
    var ba = h.stateHook,
        ca = h.valueHook,
        V = null;

    function da() {
        return ba(V)
    }

    function ea() {
        return ca(V)
    }
    h = d.createVideoStateHook();
    var fa = h.stateHook,
        ga = h.valueHook,
        W = 0;

    function ha() {
        return fa(W)
    }

    function ia() {
        return ga(W)
    }
    h = d.createVideoStateHook();
    var ja = h.stateHook,
        ka = h.valueHook,
        X = !1;

    function la() {
        return ja(X)
    }

    function ma() {
        return ka(X)
    }
    h = d.createVideoStateHook();
    var na = h.stateHook,
        oa = h.valueHook,
        Y = !1;

    function pa() {
        return na(Y)
    }

    function qa() {
        return oa(Y)
    }
    h = d.createVideoStateHook();
    var ra = h.stateHook,
        sa = h.valueHook,
        Z = null;

    function ta() {
        return ra(Z)
    }

    function ua() {
        return sa(Z)
    }
    h = d.createVideoStateHook();
    var va = h.stateHook,
        wa = h.valueHook,
        $ = null;

    function xa() {
        return va($)
    }

    function ya() {
        return wa($)
    }

    function za() {
        var a = w();
        return a === "STARTING_INDICATOR" || a === "START" || a === "START_AD" || a === "PLAY_NI_VIDEO"
    }
    g.useInstreamAdsMidRollsState = a;
    g.useInstreamAdsMidRollsValue = b;
    g.useInstreamAdsPostRollState = c;
    g.useInstreamAdsPostRollValue = e;
    g.useInstreamAdsPostRollEndedOrSkippedStateSetter = f;
    g.useInstreamAdsPostRollEndedOrSkippedStateValue = r;
    g.useInstreamAdsState = v;
    g.useInstreamAdsStateValue = w;
    g.useInstreamAdsIsEmptyState = A;
    g.useInstreamAdsIsEmptyStateValue = B;
    g.useInstreamAdsCurrentInsertionState = F;
    g.useInstreamAdsCurrentInsertionStateValue = G;
    g.useStartIndicatorBeginningTimeState = K;
    g.useStartIndicatorBeginningTimeStateValue = L;
    g.useAdBreaksTimeOffsetBeginningState = P;
    g.useAdBreaksTimeOffsetBeginningStateValue = Q;
    g.useInstreamAdsExtraFieldsState = U;
    g.useInstreamAdsExtraFieldsStateValue = aa;
    g.useInstreamAdsHideAdBehaviorState = da;
    g.useInstreamAdsHideAdBehaviorStateValue = ea;
    g.useUnifiedSchedulerLastFetchTimeState = ha;
    g.useUnifiedSchedulerLastFetchTimeStateValue = ia;
    g.useWaitingForAdFetchState = la;
    g.useWaitingForAdFetchStateValue = ma;
    g.useInstreamAdsHasCTAState = pa;
    g.useInstreamAdsHasCTAStateValue = qa;
    g.useInstreamAdsFeedContextCardState = ta;
    g.useInstreamAdsFeedContextCardStateValue = ua;
    g.useInstreamAdsFullScreenContextCardState = xa;
    g.useInstreamAdsFullScreenContextCardStateValue = ya;
    g.useInstreamAdsIsStart = za
}), 98);
__d("VideoPlayerInteractionOverlay.react", ["VideoPlayerHooks", "createVideoStateHook", "performanceNow", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = k || (k = d("react")),
        m = k.useCallback,
        n = {
            hiddenCursor: {
                cursor: "xjfk50j",
                $$css: !0
            },
            pointer: {
                cursor: "x1ypdohk",
                $$css: !0
            },
            root: {
                bottom: "x1ey2m1c",
                boxSizing: "x9f619",
                end: "xds687c",
                start: "x17qophe",
                position: "x10l6tqk",
                top: "x13vifvy",
                $$css: !0
            }
        };
    b = d("createVideoStateHook").createVideoStateHook(null);
    var o = b.setterHook;
    e = b.valueHook;
    b = l.forwardRef(a);

    function a(a, b) {
        var e = a.children,
            f = a.pressInteraction,
            g = a.style;
        a = a.xstyle;
        var k = o(),
            p = m(function(a) {
                a.preventDefault(), k({
                    left: a.clientX,
                    time: (h || (h = c("performanceNow")))(),
                    top: a.clientY
                })
            }, [k]),
            q = f == null ? void 0 : f.handler,
            r = f == null ? void 0 : f.onPressStart,
            s = f == null ? void 0 : f.onMouseEnter;
        f = f == null ? void 0 : f.onMouseLeave;
        var t = (j || (j = d("VideoPlayerHooks"))).useIsFullscreen(),
            u = j.useIsMouseIdle();
        return l.jsx("div", {
            className: (i || (i = c("stylex")))(n.root, !!q && n.pointer, t && u && n.hiddenCursor, a),
            onClick: q,
            onContextMenu: p,
            onMouseEnter: s,
            onMouseLeave: f,
            onPointerDown: r,
            ref: b,
            role: "presentation",
            style: g,
            children: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a = b;
    f = e;
    g.VideoPlayerInteractionOverlay = a;
    g.useLastRightClick = f
}), 98);
__d("VideoPlayerLiveRewindControlContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        cachedLiveRewindTimestamp: null,
        onLiveRewindControlEvent: function() {}
    });
    g["default"] = b
}), 98);
__d("VideoPlayerPlayButton.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k, l = k || d("react"),
        m = {
            playIcon: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                cursor: "x1ypdohk",
                start: "xtzzx4i",
                opacity: "x1hc1fzr",
                position: "x10l6tqk",
                top: "xwa60dl",
                $$css: !0
            },
            playIconHidden: {
                opacity: "xg01cxk",
                visibility: "xlshs6z",
                $$css: !0
            },
            playIconLarge: {
                height: "xy75621",
                marginTop: "xafmxuu",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x4mskuk",
                width: "xni59qk",
                $$css: !0
            },
            playIconMedium: {
                height: "xsdox4t",
                marginTop: "xs9mwh0",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x10ndw75",
                width: "x1useyqa",
                $$css: !0
            },
            playIconSmall: {
                height: "xxk0z11",
                marginTop: "x7wgvq7",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x16hk5td",
                width: "xvy4d1p",
                $$css: !0
            }
        };

    function n(a) {
        switch (a) {
            case "LARGE":
                return i("352839");
            case "MEDIUM":
                return i("101640");
            case "SMALL":
                return i("354763")
        }
    }

    function a(a) {
        var b = a.iconSize;
        b = b === void 0 ? "LARGE" : b;
        var d = a.isVisible;
        a = a.onClick;
        var e = l.jsx(c("CometImage.react"), {
            src: n(b)
        });
        a = a != null ? l.jsx(c("CometPressable.react"), {
            display: "inline",
            label: h._("__JHASH__pymzrO9zrya__JHASH__"),
            onPress: a,
            overlayDisabled: !0,
            children: e
        }) : e;
        return l.jsx("i", {
            className: (j || (j = c("stylex")))(b === "LARGE" && m.playIconLarge, b === "MEDIUM" && m.playIconMedium, b === "SMALL" && m.playIconSmall, m.playIcon, !d && m.playIconHidden),
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerPlaybackControlBase.react", ["fbt", "ix", "VideoPlayerControlIcon.react", "fbicon", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = j || d("react");

    function a(a) {
        var b = a.onPress;
        a = a.playbackIcon;
        var e, f;
        switch (a) {
            case "pause":
                e = h._("__JHASH__neZzFA-dHLC__JHASH__");
                f = d("fbicon")._(i("497675"), 20);
                break;
            case "replay":
                e = h._("__JHASH__HFCl7btmLVQ__JHASH__");
                f = d("fbicon")._(i("534219"), 20);
                break;
            case "play":
                e = h._("__JHASH__Pdft-1wnTrL__JHASH__");
                f = d("fbicon")._(i("484863"), 20);
                break;
            default:
                a;
                throw c("unrecoverableViolation")("The playback icon is unsupported " + a, "comet_video_player")
        }
        return k.jsx(c("VideoPlayerControlIcon.react"), {
            icon: f,
            label: e,
            onPress: b,
            tooltip: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("useFeedClickEventHandler", ["react", "useStoryClickEventLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useCallback;

    function a(a, b) {
        var d = c("useStoryClickEventLogger")();
        return i(function(c) {
            a && a(c);
            var e = c.type;
            if (e === "click" || e === "contextmenu" || e === "mousedown" && typeof c.button === "number" && (c.button === 1 || c.button === 2) || e === "keydown" && (c.key === "Enter" || c.key === " ")) {
                e = typeof c.button === "number" ? c.button : 0;
                d(c.timeStamp, e, b)
            }
        }, [a, d, b])
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerControllerSubscription", ["VideoPlayerHooks", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    b = h || d("react");
    var j = b.useEffect,
        k = b.useLayoutEffect,
        l = b.useRef,
        m = b.useState;

    function a(a) {
        var b = (i || (i = d("VideoPlayerHooks"))).useController(),
            c = m(function() {
                return a(b, null)
            }),
            e = c[0],
            f = c[1],
            g = l(a);
        k(function() {
            g.current = a
        }, [a]);
        j(function() {
            f(function(a) {
                return g.current(b, a)
            });
            var a = b.subscribe(function() {
                f(function(a) {
                    return g.current(b, a)
                })
            });
            return function() {
                a.remove()
            }
        }, [b]);
        return e
    }
    g["default"] = a
}), 98);
__d("VideoPlayerPlaybackControl.react", ["VideoHomeTypedLiteLogger", "VideoPlayerHooks", "VideoPlayerPlaybackControlBase.react", "react", "useFeedClickEventHandler", "useMinifiedProductAttribution", "useVideoPlayerControllerSubscription"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react")),
        k = h.useEffect;

    function a(a) {
        var b = a.isNPC,
            e = b === void 0 ? !1 : b;
        b = a.unmuteOnPlay;
        var f = b === void 0 ? !1 : b;
        k(function() {
            e && c("VideoHomeTypedLiteLogger").log({
                event: "npc_control_playback_button_impression"
            })
        }, [e]);
        a = c("useVideoPlayerControllerSubscription")(function(a, b) {
            var c = a.getCurrentState(),
                d = c.ended,
                e = c.paused,
                f = c.playing,
                g = c.stalling;
            a = a.getPlayheadPosition();
            c = c.duration;
            e = !e && (f || g);
            g = !f && d && a >= c;
            return b != null && b.showPauseButton === e && b.showReplayButton === g ? b : {
                showPauseButton: e,
                showReplayButton: g
            }
        });
        var g = a.showPauseButton;
        b = a.showReplayButton;
        var h = (i || (i = d("VideoPlayerHooks"))).useController(),
            l = c("useMinifiedProductAttribution")();
        a = c("useFeedClickEventHandler")(function() {
            e && c("VideoHomeTypedLiteLogger").log({
                attribution_id_v2: l,
                click_point: "npc_control_playback_button",
                event: "click",
                event_target: "video"
            }), g ? h.pause("user_initiated") : (f && h.setMuted(!1, "user_initiated"), h.play("user_initiated"))
        });
        b = g ? "pause" : b ? "replay" : "play";
        return j.jsx(c("VideoPlayerPlaybackControlBase.react"), {
            onPress: a,
            playbackIcon: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getFormattedTimestamp", ["DateConsts"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = "";
        a = a;
        isNaN(a) ? a = 0 : a < 0 && (a *= -1, b = "-");
        var c = Math.floor(a / d("DateConsts").SEC_PER_HOUR),
            e = Math.floor((a - c * d("DateConsts").SEC_PER_HOUR) / d("DateConsts").SEC_PER_MIN);
        a = Math.round(a - c * d("DateConsts").SEC_PER_HOUR - e * d("DateConsts").SEC_PER_MIN);
        a === d("DateConsts").SEC_PER_MIN && (a = 0, e++);
        e === d("DateConsts").MIN_PER_HOUR && (e = 0, c++);
        a = ("0" + a).slice(-2);
        if (c === 0) return "" + b + e + ":" + a;
        else {
            e = ("0" + e).slice(-2);
            return "" + b + c + ":" + e + ":" + a
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerPlaybackTimerBase.react", ["getFormattedTimestamp", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.currentTime;
        a = a.duration;
        return i.jsxs("div", {
            className: "x14ctfv x1rg5ohu x1pg5gke xss6m8b x7h9g57 x1t4t16n x8j4wrb x9hgts1 x2b8uid x27saw0 x3ajldb",
            children: [i.jsx("span", {
                className: "x1s688f x15hfatp",
                children: c("getFormattedTimestamp")(b)
            }), a != null && i.jsxs(i.Fragment, {
                children: [i.jsx("span", {
                    children: " / "
                }), i.jsx("span", {
                    children: c("getFormattedTimestamp")(a)
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useLiveRewindUtils", ["VideoPlayerHooks", "VideoPlayerLiveRewindControlContext", "react", "useVideoPlayerControllerSubscription"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || d("react"),
        k = j.useCallback,
        l = j.useContext,
        m = 10,
        n = 10;

    function a() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function() {
            var c = a.getCurrentState().seekableRanges;
            c = c != null ? (c = c.end(c.length() - 1)) != null ? c : 0 : 0;
            var d = Math.min(a.getPlayheadPosition() + m, c);
            d === c ? (a.setIsLiveRewindActive(!1), a.seek(c)) : a.seek(d);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function b() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function() {
            var c = a.getCurrentState().seekableRanges;
            c = (c = c == null ? void 0 : c.start(0)) != null ? c : 0;
            c = Math.max(a.getPlayheadPosition() - n, c);
            a.seek(c);
            a.setIsLiveRewindActive(!0);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function e() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function() {
            var c = a.getCurrentState().seekableRanges;
            c = c != null ? (c = c.end(c.length() - 1)) != null ? c : 0 : 0;
            a.seek(c);
            a.play("user_initiated");
            a.setIsLiveRewindActive(!1);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function f() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function() {
            var c = a.getCurrentState().seekableRanges;
            c = (c = c == null ? void 0 : c.start(0)) != null ? c : 0;
            a.seek(c);
            a.setIsLiveRewindActive(!0);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function o() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function() {
            a.play("user_initiated"), b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function p() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function() {
            a.pause("user_initiated"), a.setIsLiveRewindActive(!0), b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function q() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function() {
            var c = a.getCurrentState().seekableRanges;
            c = (c = c == null ? void 0 : c.start(0)) != null ? c : 0;
            a.seek(c);
            a.setIsLiveRewindActive(!0);
            a.play("user_initiated");
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function r() {
        var a = (i || (i = d("VideoPlayerHooks"))).useController(),
            b = l(c("VideoPlayerLiveRewindControlContext"));
        return k(function(c) {
            var d, e = a.getCurrentState().seekableRanges;
            d = (d = e == null ? void 0 : e.start(0)) != null ? d : 0;
            e = e != null ? (e = e.end(e.length() - 1)) != null ? e : 0 : 0;
            d = Math.min(d + c, e);
            a.scrubEnd(d);
            d === e ? a.setIsLiveRewindActive(!1) : a.setIsLiveRewindActive(!0);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function s() {
        return c("useVideoPlayerControllerSubscription")(function(a) {
            return (a = (a = a.getCurrentState().seekableRanges) == null ? void 0 : a.start(0)) != null ? a : 0
        })
    }
    g.useLiveRewindForward = a;
    g.useLiveRewindBack = b;
    g.useLiveRewindLive = e;
    g.useLiveRewindStart = f;
    g.useLiveRewindPlay = o;
    g.useLiveRewindPause = p;
    g.useLiveRewindReplay = q;
    g.useLiveRewindScrub = r;
    g.useLiveRewindSeekableStartTime = s
}), 98);
__d("VideoPlayerPlaybackTimer.react", ["VideoPlayerHooks", "VideoPlayerPlaybackTimerBase.react", "react", "useLiveRewindUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || d("react");
    b = a;

    function k() {
        var a = d("useLiveRewindUtils").useLiveRewindSeekableStartTime(),
            b = (i || (i = d("VideoPlayerHooks"))).useCurrentTimeThrottled(200),
            e = i.useCurrentTimeThrottled(1e3, function(a) {
                var b = a.getCurrentState();
                a = a.getPlayheadPosition();
                return a - b.duration
            }),
            f = i.useIsLiveRewindActive();
        f = f ? e : b - a;
        return j.jsx(c("VideoPlayerPlaybackTimerBase.react"), {
            currentTime: f,
            duration: null
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function l() {
        var a = (i || (i = d("VideoPlayerHooks"))).useDuration(),
            b = i.useCurrentTimeThrottled(200);
        return j.jsx(c("VideoPlayerPlaybackTimerBase.react"), {
            currentTime: b,
            duration: a
        })
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function a() {
        var a = (i || (i = d("VideoPlayerHooks"))).useIsLive();
        if (a) return j.jsx(k, {});
        else return j.jsx(l, {})
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("VideoPlayerPointerDrag", ["react", "useResizeObserver", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    f = h || d("react");
    var i = f.useEffect,
        j = f.useRef,
        k = f.useState;

    function a() {
        var a = j(null),
            b = j(null),
            d = c("useResizeObserver")(function(c, d) {
                a.current = d.getBoundingClientRect(), b.current = d
            }),
            e = c("useStable")(function() {
                return function() {
                    var c = b.current;
                    c ? a.current = c.getBoundingClientRect() : a.current = null
                }
            });
        return {
            invalidateRootRect: e,
            rootRectRef: a,
            rootSizeRefCallback: d
        }
    }

    function b(a, b) {
        if (b == null) return null;
        var c = Math.max(0, Math.min(b.width, a.clientX - b.left));
        a = Math.max(0, Math.min(b.height, a.clientY - b.top));
        return {
            ratioX: b.width > 0 ? c / b.width : 0,
            ratioY: b.height > 0 ? a / b.height : 0
        }
    }

    function l(a, b) {
        a = a.changedTouches;
        if (b == null || !a) return null;
        for (var c = 0; c < a.length; ++c) {
            var d = a[c];
            if (d.identifier === b) return {
                clientX: d.clientX,
                clientY: d.clientY
            }
        }
        return null
    }

    function m(a, b) {
        var c = a;
        switch (b.type) {
            case "start":
                c = babelHelpers["extends"]({}, a, {
                    clientX: b.clientX,
                    clientY: b.clientY,
                    dragState: "dragging",
                    lastEffect: a.dragState === "idle" ? "start" : a.lastEffect
                });
                break;
            case "move":
                if (a.dragState !== "dragging") break;
                c = {
                    clientX: b.clientX,
                    clientY: b.clientY,
                    dragState: "dragging",
                    lastEffect: a.dragState === "idle" ? "start" : "move"
                };
                break;
            case "end":
                if (a.dragState !== "dragging") break;
                c = {
                    clientX: b.clientX,
                    clientY: b.clientY,
                    dragState: "idle",
                    lastEffect: a.dragState === "idle" ? a.lastEffect : "end"
                };
                break;
            case "cancel":
                if (a.dragState !== "dragging") break;
                c = {
                    clientX: a.clientX,
                    clientY: a.clientY,
                    dragState: "idle",
                    lastEffect: a.dragState === "idle" ? a.lastEffect : "cancel"
                };
                break;
            default:
                break
        }
        return c.dragState !== a.dragState || c.lastEffect !== a.lastEffect || c.clientX !== a.clientX || c.clientY !== a.clientY ? c : a
    }
    var n = {
            clientX: 0,
            clientY: 0,
            dragState: "idle",
            lastEffect: null
        },
        o = function() {
            return window.navigator.userAgent.indexOf("MSIE") >= 0
        };

    function p(a, b, c) {
        var d = n,
            e = null,
            f = null,
            g = function(b) {
                d = m(d, b), a(d)
            },
            h = function(a) {
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "move"
                });
                a = b.current.onDragMoveSync;
                a == null ? void 0 : a(d)
            },
            i = function(a) {
                e && e();
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "end"
                });
                a = b.current.onDragEndSync;
                a == null ? void 0 : a(d)
            },
            j = function() {
                e && e();
                g({
                    type: "cancel"
                });
                var a = b.current.onDragCancelSync;
                a == null ? void 0 : a(d)
            },
            k = function(a) {
                a = l(a, c.current);
                if (a == null) return;
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "move"
                });
                a = b.current.onDragMoveSync;
                a == null ? void 0 : a(d)
            },
            p = function(a) {
                a = l(a, c.current);
                if (a == null) return;
                f && f();
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "end"
                });
                a = b.current.onDragEndSync;
                a == null ? void 0 : a(d)
            },
            q = p;
        return {
            destroy: function() {
                e && e(), f && f()
            },
            onMouseDown: function(a) {
                o() || a.preventDefault();
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "start"
                });
                a = b.current.onDragStartSync;
                a == null ? void 0 : a(d);
                e || (window.addEventListener("mousemove", h), window.addEventListener("mouseup", i), window.addEventListener("blur", j), window.addEventListener("mouseleave", j), e = function() {
                    e = null, window.removeEventListener("mousemove", h), window.removeEventListener("mouseup", i), window.removeEventListener("blur", j), window.removeEventListener("mouseleave", j)
                })
            },
            onTouchStart: function(a) {
                a.preventDefault();
                var e = a.changedTouches[0];
                e != null && (c.current = e.identifier);
                e = l(a, c.current);
                if (e == null) return;
                g({
                    clientX: e.clientX,
                    clientY: e.clientY,
                    type: "start"
                });
                a = b.current.onDragStartSync;
                a == null ? void 0 : a(d);
                f || (window.addEventListener("touchmove", k), window.addEventListener("touchend", p), window.addEventListener("touchcancel", q), window.addEventListener("blur", j), f = function() {
                    f = null, window.removeEventListener("touchmove", k), window.removeEventListener("touchend", p), window.removeEventListener("touchcancel", q), window.removeEventListener("blur", j)
                })
            }
        }
    }

    function q(a, b) {
        i(function() {
            var c = b.current,
                d = c.onDragCancel,
                e = c.onDragEnd,
                f = c.onDragMove;
            c = c.onDragStart;
            switch (a.lastEffect) {
                case "start":
                    c(a);
                    return;
                case "move":
                    f(a);
                    return;
                case "end":
                    e(a);
                    return;
                case "cancel":
                    d(a);
                    return
            }
        }, [a, b])
    }

    function r(a, b, d) {
        var e = k(n),
            f = e[0],
            g = e[1];
        e = c("useStable")(function() {
            return p(g, a, b)
        });
        var h = e.destroy,
            j = e.onMouseDown;
        e = e.onTouchStart;
        i(function() {
            return h
        }, [h]);
        return {
            dragState: f,
            rootProps: {
                onClick: function(a) {
                    a.stopPropagation(), a.preventDefault()
                },
                onMouseDown: j,
                onTouchStart: (d == null ? void 0 : d.hasTouchEvents) === !0 ? e : void 0
            }
        }
    }

    function e(a, b) {
        var c = j(a),
            d = j(null);
        i(function() {
            c.current = a
        }, [a]);
        d = r(c, d, b);
        b = d.dragState;
        d = d.rootProps;
        q(b, c);
        return {
            dragState: b,
            isDragging: b.dragState === "dragging",
            rootProps: d
        }
    }
    g.usePointerDragResizeObserver = a;
    g.computePointerOffsetRatio = b;
    g.usePointerDrag = e
}), 98);
__d("VideoPlayerSliderNub.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            "default": {
                backgroundColor: "x14hiurz",
                borderTopColor: "x1g7gg9k",
                borderEndColor: "xenha5r",
                borderBottomColor: "x1eoefnw",
                borderStartColor: "x124h113",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "xamhcws",
                borderEndWidth: "xol2nv",
                borderBottomWidth: "xlxy82",
                borderStartWidth: "x19p7ews",
                boxShadow: "x1nqv1ya",
                display: "x1s85apg",
                height: "xdk7pt",
                marginRight: "x1x862rh",
                marginTop: "x1rdy4ex",
                position: "x10l6tqk",
                right: "x3m8u43",
                width: "x1xc55vz",
                zIndex: "x1vjfegm",
                $$css: !0
            },
            visible: {
                display: "x1lliihq",
                $$css: !0
            }
        };

    function a(a) {
        a = a.isVisible;
        return j.jsx("div", {
            className: (h || (h = c("stylex")))(k["default"], a && k.visible),
            "data-testid": void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerScrubberBaseContentDefault.react", ["CometVisualCompletionAttributes", "VideoPlayerSliderNub.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            liveRewindTimePlayed: {
                backgroundColor: "xh1tjdi",
                $$css: !0
            },
            liveTimePlayed: {
                backgroundColor: "x1ciooss",
                $$css: !0
            },
            timelineBackground: {
                backgroundColor: "x1rwy58d",
                borderTopStartRadius: "xm3z3ea",
                borderTopEndRadius: "x1x8b98j",
                borderBottomEndRadius: "x131883w",
                borderBottomStartRadius: "x16mih1h",
                boxShadow: "xpdb0fs",
                height: "xuoj239",
                textShadow: "xd9u3wd",
                userSelect: "x87ps6o",
                $$css: !0
            },
            timelineBuffered: {
                height: "xuoj239",
                position: "x10l6tqk",
                $$css: !0
            },
            timelineBufferedBackground: {
                backgroundColor: "x17j41np",
                $$css: !0
            },
            timelinePlayed: {
                backgroundColor: "x1evw4sf",
                borderTopStartRadius: "xm3z3ea",
                borderTopEndRadius: "x1x8b98j",
                borderBottomEndRadius: "x131883w",
                borderBottomStartRadius: "x16mih1h",
                height: "xuoj239",
                position: "x10l6tqk",
                userSelect: "x87ps6o",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.bufferedRatio;
        a.duration;
        a.hoveringPositionSec;
        a.isHovering;
        var d = a.isLive,
            e = a.isLiveRewindActive,
            f = a.isNubVisible,
            g = a.playedRatio,
            i = a.timelineBackgroundXStyle,
            l = a.timelineBufferedXStyle;
        a = a.timelinePlayedXStyle;
        return j.jsxs("div", {
            className: (h || (h = c("stylex")))(k.timelineBackground, i),
            children: [j.jsx("div", babelHelpers["extends"]({
                className: h(k.timelineBuffered, !d && k.timelineBufferedBackground, l)
            }, c("CometVisualCompletionAttributes").IGNORE, {
                style: {
                    width: (100 * b).toFixed(5) + "%"
                }
            })), j.jsx("div", babelHelpers["extends"]({
                className: h(k.timelinePlayed, d && !e && k.liveTimePlayed, d && e && k.liveRewindTimePlayed, a)
            }, c("CometVisualCompletionAttributes").IGNORE, {
                style: {
                    width: (100 * g).toFixed(5) + "%"
                },
                children: j.jsx(c("VideoPlayerSliderNub.react"), {
                    isVisible: f
                })
            }))]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerUserInteractionCounter", ["react", "unrecoverableViolation", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    e = h || d("react");
    var i = e.useCallback,
        j = e.useEffect,
        k = e.useRef,
        l = e.useState;

    function a(a, b, d) {
        var e = k(a);
        j(function() {
            if (a !== e.current) throw c("unrecoverableViolation")("User interaction name should not change between renders ('" + e.current + "' -> '" + a + "').", "comet_video_player")
        }, [a]);
        var f = k(d);
        j(function() {
            f.current = d
        }, [d]);
        var g = c("usePrevious")(b),
            h = k(!1);
        j(function() {
            var a = e.current,
                c = f.current;
            c && ((g === null || b !== g) && (b ? (h.current = !0, c({
                name: a,
                type: "started"
            })) : g !== null && (h.current = !1, c({
                name: a,
                type: "ended"
            }))))
        }, [b, g]);
        j(function() {
            var a = e.current,
                b = f.current;
            return function() {
                b && h.current && b({
                    name: a,
                    type: "ended"
                })
            }
        }, [])
    }

    function b() {
        var a = k(new Set()),
            b = l(0),
            c = b[0],
            d = b[1];
        b = i(function(b) {
            var c = a.current;
            b.type === "started" || b.type === "happening" ? (c.add(b.name), d(c.size)) : b.type === "ended" && (c["delete"](b.name), d(c.size))
        }, []);
        return {
            ongoingInteractionsCount: c,
            onUserInteraction: b
        }
    }
    g.useVideoPlayerUserInteraction = a;
    g.useVideoPlayerUserInteractionCounter = b
}), 98);
__d("useVideoPlayerScrubberState", ["VideoPlayerPointerDrag", "react", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useState;

    function k(a, b) {
        return Math.min(a > 0 ? b / a : 0, 1)
    }

    function a(a) {
        var b = a.bufferEnd,
            e = a.currentTime,
            f = a.duration,
            g = a.onScrubCancel,
            h = a.onScrubEnd,
            l = a.onScrubStart;
        a = a.supportsTouch;
        var m = d("VideoPlayerPointerDrag").usePointerDragResizeObserver(),
            n = m.invalidateRootRect,
            o = m.rootRectRef;
        m = m.rootSizeRefCallback;
        var p = j(0),
            q = p[0],
            r = p[1];
        p = j(!1);
        var s = p[0],
            t = p[1],
            u = c("usePrevious")(e);
        i(function() {
            e !== u && t(!1)
        }, [e, u]);
        p = d("VideoPlayerPointerDrag").usePointerDrag({
            onDragCancel: function(a) {
                g()
            },
            onDragEnd: function(a) {
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, o.current);
                if (!a) {
                    g();
                    return
                }
                r(a.ratioX);
                a = a.ratioX * f;
                h(a)
            },
            onDragEndSync: function() {
                t(!0)
            },
            onDragMove: function(a) {
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, o.current);
                if (!a) return;
                r(a.ratioX)
            },
            onDragStart: function(a) {
                n();
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, o.current);
                if (!a) return;
                r(a.ratioX);
                l()
            }
        }, {
            hasTouchEvents: a === !0
        });
        a = p.isDragging;
        p = p.rootProps;
        b = k(f, b);
        var v = k(f, e);
        return {
            bufferedRatio: b,
            currentPlayedRatio: v,
            invalidateRootRect: n,
            isDragging: a,
            isWaitingForSeek: s,
            pointerOffsetRatio: q,
            rootProps: p,
            rootRectRef: o,
            rootSizeRefCallback: m
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerScrubberBase.react", ["fbt", "CometComponentWithKeyCommands.react", "CometKeys", "VideoPlayerScrubberBaseContentDefault.react", "VideoPlayerUserInteractionCounter", "cr:2236", "react", "stylex", "useVideoPlayerScrubberState"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || (j = d("react"));
    e = j;
    var l = e.useCallback,
        m = e.useMemo,
        n = e.useState,
        o = {
            root: {
                cursor: "x1ypdohk",
                paddingTop: "x1y1aw1k",
                paddingEnd: "x4uap5",
                paddingBottom: "xwib8y2",
                paddingStart: "xkhd6sd",
                position: "x1n2onr6",
                userSelect: "x87ps6o",
                width: "xh8yej3",
                $$css: !0
            },
            rootWithReelsScrubber: {
                alignItems: "x6s0dn4",
                bottom: "xq6397w",
                cursor: "x1ypdohk",
                display: "x78zum5",
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v",
                position: "x1n2onr6",
                userSelect: "x87ps6o",
                width: "xh8yej3",
                $$css: !0
            },
            withoutVerticalPadding: {
                paddingBottom: "x18d9i69",
                paddingTop: "xexx8yu",
                $$css: !0
            }
        };

    function a(a) {
        var e = a.bufferEnd,
            f = a.currentTime,
            g = a.disableKeyCommands,
            j = a.duration,
            p = a.hasReelsScrubber;
        p = p === void 0 ? !1 : p;
        var q = a.hideNub;
        q = q === void 0 ? !1 : q;
        var r = a.isLive,
            s = a.isLiveRewindActive,
            t = a.keyLeftDescription,
            u = a.keyRightDescription,
            v = a.onScrubCancel,
            w = a.onScrubEnd,
            x = a.onScrubStart,
            y = a.onUserInteraction,
            z = a.playFromBeginningImpl,
            A = a.renderScrubber,
            B = a.renderTooltip,
            C = a.skipBackwardImpl,
            D = a.skipForwardImpl,
            E = a.skipToEndImpl,
            F = a.supportsTouch,
            G = a.timelineBackgroundXStyle,
            H = a.timelineBufferedXStyle,
            I = a.timelinePlayedXStyle;
        a = a.withoutVerticalPadding;
        a = a === void 0 ? !1 : a;
        var J = n(!1),
            K = J[0],
            L = J[1];
        J = n(0);
        var M = J[0],
            N = J[1];
        J = n(null);
        var O = J[0],
            P = J[1];
        J = c("useVideoPlayerScrubberState")({
            bufferEnd: e,
            currentTime: f,
            duration: j,
            onScrubCancel: v,
            onScrubEnd: w,
            onScrubStart: x,
            supportsTouch: F
        });
        e = J.bufferedRatio;
        v = J.currentPlayedRatio;
        var Q = J.invalidateRootRect;
        w = J.isDragging;
        x = J.isWaitingForSeek;
        F = J.pointerOffsetRatio;
        var R = J.rootProps,
            S = J.rootRectRef;
        J = J.rootSizeRefCallback;
        var T = l(function() {
                L(!0)
            }, []),
            U = l(function() {
                L(!1)
            }, []),
            V = l(function(a) {
                Q();
                if (S.current != null) {
                    var b = S.current.left,
                        c = S.current.width,
                        d = Math.max(0, Math.min(c, a.clientX - b));
                    d = c > 0 ? d / c : 0;
                    c = Number.isFinite(j) && j > 0 ? j * d : null;
                    N(a.clientX - b);
                    P(c)
                }
            }, [j, Q, S]),
            W = K || w;
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_scrubber", W, y);
        y = K || w || x;
        x = w || x ? F : r && !s ? 1 : v;
        F = m(function() {
            return g === !0 ? [] : [{
                command: {
                    key: c("CometKeys").RIGHT
                },
                description: u,
                handler: D
            }, {
                command: {
                    key: c("CometKeys").LEFT
                },
                description: t,
                handler: C
            }, {
                command: {
                    key: c("CometKeys").HOME
                },
                description: h._("__JHASH__3cUloDtyzSK__JHASH__"),
                handler: z
            }, {
                command: {
                    key: c("CometKeys").END
                },
                description: h._("__JHASH__jTksR1FMT97__JHASH__"),
                handler: E
            }]
        }, [g, u, D, t, C, z, E]);
        v = {
            bufferedRatio: e,
            duration: j,
            hoveringPositionSec: O,
            isHovering: K,
            isLive: r,
            isLiveRewindActive: s,
            isNubVisible: !q && y,
            playedRatio: x,
            timelineBackgroundXStyle: G,
            timelineBufferedXStyle: H,
            timelinePlayedXStyle: I
        };
        return k.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: F,
            children: k.jsxs("div", babelHelpers["extends"]({}, R, {
                "aria-label": h._("__JHASH__69czi8qDKMx__JHASH__"),
                "aria-orientation": "horizontal",
                "aria-valuemax": j,
                "aria-valuemin": "0",
                "aria-valuenow": f,
                className: (i || (i = c("stylex")))(p && b("cr:2236") ? o.rootWithReelsScrubber : o.root, a && o.withoutVerticalPadding),
                "data-testid": void 0,
                onMouseEnter: T,
                onMouseLeave: U,
                onMouseMove: V,
                ref: J,
                role: "slider",
                tabIndex: "0",
                children: [p && b("cr:2236") ? k.jsx(b("cr:2236"), {
                    bufferedRatio: e,
                    isDragging: w,
                    isInteracting: W,
                    playedRatio: x
                }) : k.jsx(k.Fragment, {
                    children: A != null ? A(v) : k.jsx(c("VideoPlayerScrubberBaseContentDefault.react"), babelHelpers["extends"]({}, v))
                }), B != null && O != null && K && k.jsx("div", {
                    className: "xfqi8uc x10l6tqk",
                    style: {
                        left: M
                    },
                    children: B(O)
                })]
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerScrubber.react", ["fbt", "VideoPlayerHooks", "VideoPlayerScrubberBase.react", "react", "useLiveRewindUtils"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = i || (i = d("react")),
        l = i.useCallback;

    function m() {
        return (j || (j = d("VideoPlayerHooks"))).useCurrentTimeThrottled(200)
    }

    function a(a) {
        var b = a.onUserInteraction,
            e = a.renderScrubber;
        a = a.renderTooltip;
        var f = m(),
            g = (j || (j = d("VideoPlayerHooks"))).useDuration(),
            i = j.useController(),
            n = j.useBufferEnd(),
            o = j.useIsLive(),
            p = j.useIsLiveRewindActive(),
            q = d("useLiveRewindUtils").useLiveRewindScrub(),
            r = d("useLiveRewindUtils").useLiveRewindForward(),
            s = d("useLiveRewindUtils").useLiveRewindBack(),
            t = d("useLiveRewindUtils").useLiveRewindStart(),
            u = d("useLiveRewindUtils").useLiveRewindLive(),
            v = d("useLiveRewindUtils").useLiveRewindSeekableStartTime();
        o && (g -= v, f -= v);
        v = l(function() {
            if (o) r();
            else {
                var a = i.getPlayheadPosition() + 5;
                a >= g ? i.seek(g - .01) : i.seek(a)
            }
        }, [i, o, r, g]);
        var w = o ? h._("__JHASH__Fazg7jyI-AJ__JHASH__") : h._("__JHASH__Hz44qTuOc36__JHASH__"),
            x = l(function() {
                if (o) s();
                else {
                    var a = i.getPlayheadPosition() - 5;
                    a < 0 ? i.seek(0) : i.seek(a)
                }
            }, [i, o, s]),
            y = o ? h._("__JHASH__fXj-dMG-OtJ__JHASH__") : h._("__JHASH__KzLU7zLc4h8__JHASH__"),
            z = l(function() {
                o ? t() : i.seek(0)
            }, [i, o, t]),
            A = l(function() {
                o ? u() : i.seek(g - .01)
            }, [i, o, u, g]),
            B = l(function() {
                i.scrubEnd(null)
            }, [i]),
            C = l(function() {
                i.scrubBegin()
            }, [i]),
            D = l(function(a) {
                !o ? i.scrubEnd(a) : q(a)
            }, [i, o, q]);
        return k.jsx(c("VideoPlayerScrubberBase.react"), {
            bufferEnd: n,
            currentTime: f,
            duration: g,
            isLive: o,
            isLiveRewindActive: p,
            keyLeftDescription: y,
            keyRightDescription: w,
            onScrubCancel: B,
            onScrubEnd: D,
            onScrubStart: C,
            onUserInteraction: b,
            playFromBeginningImpl: z,
            renderScrubber: e,
            renderTooltip: a,
            skipBackwardImpl: x,
            skipForwardImpl: v,
            skipToEndImpl: A
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerShakaGlobalConfig", ["VideoPlayerContextSensitiveConfigResolver"], (function(a, b, c, d, e, f, g) {
    var h = new(c("VideoPlayerContextSensitiveConfigResolver"))(),
        i = {};
    a = function(a) {
        i = a
    };
    b = function(a, b) {
        if (!!i && typeof i[a] === "boolean") return i[a];
        a = h.getValue(a);
        return a != null && typeof a === "boolean" ? a : b
    };
    d = function(a, b) {
        if (!!i && typeof i[a] === "number") return i[a];
        a = h.getValue(a);
        return a != null && typeof a === "number" ? a : b
    };
    e = function(a, b) {
        if (!!i && typeof i[a] === "string") return i[a];
        a = h.getValue(a);
        return a != null && typeof a === "string" ? a : b
    };
    g.setGlobalOverrideConfig = a;
    g.getBool = b;
    g.getNumber = d;
    g.getString = e
}), 98);
__d("VideoPlayerSmallPlayButton.react", ["fbt", "CometImage.react", "CometPressable.react", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || d("react"),
        l = {
            playIcon: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                cursor: "x1ypdohk",
                height: "xsdox4t",
                start: "xtzzx4i",
                marginTop: "xs9mwh0",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x10ndw75",
                opacity: "x1hc1fzr",
                position: "x10l6tqk",
                top: "xwa60dl",
                width: "x1useyqa",
                $$css: !0
            },
            playIconHidden: {
                opacity: "xg01cxk",
                visibility: "xlshs6z",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.isVisible;
        a = a.onClick;
        var d = k.jsx(c("CometImage.react"), {
            src: "/images/video/play_48dp.png"
        });
        a = a != null ? k.jsx(c("CometPressable.react"), {
            display: "inline",
            label: h._("__JHASH__pymzrO9zrya__JHASH__"),
            onPress: a,
            overlayDisabled: !0,
            children: d
        }) : d;
        return k.jsx("i", {
            className: (i || (i = c("stylex")))(l.playIcon, !b && l.playIconHidden),
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerVolumeControlBase.react", ["fbt", "ix", "FocusWithinHandler.react", "VideoPlayerControlIcon.react", "fbicon", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = j || (j = d("react")),
        l = j.useState,
        m = .33,
        n = .66;

    function a(a) {
        var b = a.audioAvailabilityUI,
            e = a.isMuted,
            f = a.onMouseEnter,
            g = a.onMouseLeave,
            j = a.onSetMuted,
            o = a.onUserInteraction,
            p = a.renderVolumeSlider;
        a = a.volume;
        var q = !e && a > 0,
            r;
        b != null && b.shouldShowNullIcon ? r = d("fbicon")._(i("944792"), 20) : q ? a <= m ? r = d("fbicon")._(i("1104387"), 20) : a <= n ? r = d("fbicon")._(i("1104390"), 20) : r = d("fbicon")._(i("564390"), 20) : r = d("fbicon")._(i("564396"), 20);
        q = l(!1);
        var s = q[0],
            t = q[1],
            u = e ? h._("__JHASH__2eve7xHkp9w__JHASH__") : h._("__JHASH__5xFv4FPvBT3__JHASH__");
        return k.jsx(c("FocusWithinHandler.react"), {
            children: function(a, d) {
                return k.jsxs("div", {
                    className: "x1ypdohk x1rg5ohu xhsvlbd xyamay9 xsyo7zv x10b6aqq x16hj40l x1n2onr6",
                    onMouseEnter: f,
                    onMouseLeave: g,
                    children: [b != null && b.shouldDisableVolumeControl ? null : k.jsx("div", {
                        className: "xk7dvq3 x9f619 x17qophe x1yrsyyn xsyo7zv x10b6aqq x16hj40l x10l6tqk xh8yej3",
                        children: p({
                            focusVisible: d,
                            onVisibilityChange: t
                        })
                    }), k.jsx(c("VideoPlayerControlIcon.react"), {
                        icon: r,
                        label: u,
                        onPress: function() {
                            b && b.onVolumeControlPress(), b != null && b.shouldDisableVolumeControl || j(!e, "user_initiated"), o && o({
                                name: "video_mute_button",
                                type: "happened"
                            })
                        },
                        tooltip: b != null ? b.tooltipContent : null,
                        tooltipAlign: "end",
                        tooltipImpl: b != null ? b.tooltipImpl : null,
                        tooltipOffsetY: s ? -80 : 0
                    })]
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerVolumeSliderBase.react", ["fbt", "CometComponentWithKeyCommands.react", "CometKeys", "VideoPlayerPointerDrag", "VideoPlayerSliderNub.react", "VideoPlayerUserInteractionCounter", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || (j = d("react"));
    b = j;
    var l = b.useEffect,
        m = b.useMemo,
        n = b.useRef,
        o = b.useState,
        p = {
            root: {
                cursor: "x1ypdohk",
                height: "xng8ra",
                opacity: "xg01cxk",
                pointerEvents: "x47corl",
                position: "x1n2onr6",
                transitionDuration: "x1d8287x",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "xl405pv",
                width: "x1td3qas",
                zIndex: "x1ja2u2z",
                $$css: !0
            },
            rootVisible: {
                opacity: "x1hc1fzr",
                pointerEvents: "x67bb7w",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.isHovering,
            e = a.isMuted,
            f = a.onChangeVolumeDown,
            g = a.onChangeVolumeUp,
            j = a.onSetMuted,
            q = a.onSetVolume,
            r = a.onUserInteraction,
            s = a.onVisibilityChange,
            t = a.volume;
        a = d("VideoPlayerPointerDrag").usePointerDragResizeObserver();
        var u = a.invalidateRootRect,
            v = a.rootRectRef;
        a = a.rootSizeRefCallback;
        var w = n(t),
            x = n(e),
            y = e ? 0 : t,
            z = o(y),
            A = z[0],
            B = z[1],
            C = function(a) {
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, v.current);
                if (!a) return;
                a = Math.max(0, Math.min(1, 1 - a.ratioY));
                B(a);
                q(a);
                e && j(!1, "user_initiated")
            };
        z = d("VideoPlayerPointerDrag").usePointerDrag({
            onDragCancel: function(a) {
                B(w.current), q(w.current), j(x.current, "user_initiated")
            },
            onDragEnd: function(a) {
                C(a)
            },
            onDragMove: function(a) {
                C(a)
            },
            onDragStart: function(a) {
                u(), w.current = t, x.current = e, B(y), C(a)
            }
        });
        var D = z.isDragging;
        z = z.rootProps;
        A = D ? A : y;
        var E = b || D,
            F = n(E);
        l(function() {
            F.current !== E && (s && s(E)), F.current = E
        }, [s, E]);
        b = E;
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_volume_slider", b, r);
        D = m(function() {
            return [{
                command: {
                    key: c("CometKeys").UP
                },
                description: h._("__JHASH__2--dERDMJls__JHASH__"),
                handler: function() {
                    g()
                }
            }, {
                command: {
                    key: c("CometKeys").DOWN
                },
                description: h._("__JHASH__rnGEAKbNBgc__JHASH__"),
                handler: function() {
                    f()
                }
            }]
        }, [g, f]);
        return k.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: D,
            children: k.jsx("div", babelHelpers["extends"]({}, z, {
                "aria-label": h._("__JHASH__qjrL7gM7Ew1__JHASH__"),
                "aria-orientation": "vertical",
                "aria-valuemax": "1",
                "aria-valuemin": "0",
                "aria-valuenow": t,
                className: (i || (i = c("stylex")))(p.root, E && p.rootVisible),
                ref: a,
                role: "slider",
                tabIndex: "0",
                children: k.jsx("div", {
                    className: "x18fn2jl x1lcm9me x1yr5g0i xrt01vj x10y3i5r x1ey2m1c xng8ra xoyjkpr x10l6tqk x1xc55vz",
                    children: k.jsx("div", {
                        className: "x1spa7qu x1lcm9me x1yr5g0i xrt01vj x10y3i5r x1ey2m1c x10l6tqk xh8yej3",
                        style: {
                            height: A * 100 + "%"
                        },
                        children: k.jsx("div", {
                            className: "x1c7jfne x1f4buv5 x1n2onr6",
                            children: k.jsx(c("VideoPlayerSliderNub.react"), {
                                isVisible: E
                            })
                        })
                    })
                })
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("VideoPlayerVolumeSlider.react", ["VideoPlayerHooks", "VideoPlayerVolumeSliderBase.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react")),
        k = h.useCallback;

    function a(a) {
        var b = a.isHovering,
            e = a.onUserInteraction;
        a = a.onVisibilityChange;
        var f = (i || (i = d("VideoPlayerHooks"))).useController(),
            g = i.useMuted(),
            h = i.useVolume(),
            l = k(function(a) {
                f.setVolume(a)
            }, [f]),
            m = k(function(a, b) {
                f.setMuted(a, b)
            }, [f]),
            n = k(function(a) {
                var b = f.getCurrentState();
                a = Math.max(0, Math.min(1, b.volume + a));
                f.setVolume(a);
                a === 0 ? f.setMuted(!0, "user_initiated") : b.muted && f.setMuted(!1, "user_initiated")
            }, [f]),
            o = k(function() {
                n(.05)
            }, [n]),
            p = k(function() {
                n(-.05)
            }, [n]);
        return j.jsx(c("VideoPlayerVolumeSliderBase.react"), {
            isHovering: b,
            isMuted: g,
            onChangeVolumeDown: p,
            onChangeVolumeUp: o,
            onSetMuted: m,
            onSetVolume: l,
            onUserInteraction: e,
            onVisibilityChange: a,
            volume: h
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerVolumeControl.react", ["VideoPlayerHooks", "VideoPlayerVolumeControlBase.react", "VideoPlayerVolumeSlider.react", "cr:1826284", "react", "useEmptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react"));
    e = h;
    var k = e.useCallback,
        l = e.useState,
        m = (e = b("cr:1826284")) != null ? e : c("useEmptyFunction");

    function a(a) {
        var b = a.onUserInteraction;
        a = l(!1);
        var e = a[0],
            f = a[1],
            g = (i || (i = d("VideoPlayerHooks"))).useController();
        a = i.useMuted();
        var h = i.useVolume(),
            n = function() {
                f(!0)
            },
            o = function() {
                f(!1)
            },
            p = k(function(a, b) {
                g.setMuted(a, b)
            }, [g]),
            q = !a && h > 0;
        q = m({
            canPlayerProduceSound: q,
            isHovering: e
        }) || null;
        return j.jsx(c("VideoPlayerVolumeControlBase.react"), {
            audioAvailabilityUI: q,
            isMuted: a,
            onMouseEnter: n,
            onMouseLeave: o,
            onSetMuted: p,
            onUserInteraction: b,
            renderVolumeSlider: function(a) {
                var d = a.focusVisible;
                a = a.onVisibilityChange;
                return j.jsx(c("VideoPlayerVolumeSlider.react"), {
                    isHovering: e || d,
                    onUserInteraction: b,
                    onVisibilityChange: a
                })
            },
            volume: h
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getMAWCanThreadBeCutoverOnDemand", ["I64", "LSContactBitOffset", "LSMessagingThreadTypeUtil", "MAWThreadCutover", "MWPreloadableQueries", "Promise", "ReQL", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a, b) {
        return j.apply(this, arguments)
    }

    function j() {
        j = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            if (a.isTargetE2E === !0 || a.targetType !== "USER") return !1;
            a = (i || (i = d("I64"))).of_string(a.targetID);
            var e = (yield(h || (h = b("Promise"))).resolve(d("ReQL").firstAsync(d("ReQL").fromTableAscending(c.tables.contacts).getKeyRange(a))));
            e = e != null && d("LSContactBitOffset").has(76, e);
            if (!e) return !1;
            e = (yield h.resolve(d("ReQL").firstAsync(d("ReQL").fromTableAscending(c.tables.threads).getKeyRange(a))));
            e = e ? d("LSMessagingThreadTypeUtil").isOpenOneToOne(e.threadType) : !1;
            if (!e) return !1;
            e = (yield h.resolve(d("ReQL").firstAsync(d("MWPreloadableQueries").getCutoverThreadByThreadKey(c, a))));
            if (e) return !1;
            c = (yield d("MAWThreadCutover").isCutoverThreadKey(a));
            return c ? !1 : !0
        });
        return j.apply(this, arguments)
    }
    g["default"] = a
}), 98);
__d("getOwnObjectValues", [], (function(a, b, c, d, e, f) {
    function a(a) {
        return Object.keys(a).map(function(b) {
            return a[b]
        })
    }
    f["default"] = a
}), 66);
__d("useParentRoute", ["CometRouterParentRouteContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        return i(c("CometRouterParentRouteContext"))
    }
    g["default"] = a
}), 98);
__d("usePlayerOriginRouteTracePolicy", ["CometNotificationsRootContext", "CometRouteRenderType", "react", "useCometRouteTracePolicy", "useCometRouterState", "useParentRoute", "useRoutePassthroughProps"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        var a = i(c("CometNotificationsRootContext"));
        a = a.isNotificationsRoute;
        var b = c("useCometRouteTracePolicy")(),
            e = d("CometRouteRenderType").useIsPushView(),
            f = c("useParentRoute")(),
            g = c("useCometRouterState")(),
            h = c("useRoutePassthroughProps")();
        if ((h == null ? void 0 : h.isARLTW) === !0) return "comet.watch.arltw";
        h = b === "comet.videos.tahoe";
        var j = b === "comet.stories.viewer",
            k = b === "comet.reels.home";
        if (e) {
            if (h) return "unknown";
            if (j) return b;
            if (k && (f == null ? void 0 : f.tracePolicy) == null && g != null) {
                e = g.main;
                j = g.pushViewStack;
                k = j && j.length > 1 ? j[j.length - 2] : e;
                g = k.route;
                return (j = g.tracePolicy) != null ? j : b
            }
        }
        return a && !h ? b : (e = f == null ? void 0 : f.tracePolicy) != null ? e : b
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerHasStartedPlayingAtLeastOnce", ["VideoPlayerHooks", "createVideoStateHook", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (h || d("react")).useEffect;
    b = d("createVideoStateHook").createVideoStateHook(null);
    var k = b.stateHook;

    function a() {
        var a = k(!1),
            b = a[0],
            c = a[1],
            e = (i || (i = d("VideoPlayerHooks"))).usePlaying();
        j(function() {
            e && c(!0)
        }, [e, c]);
        return b
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerBigPlayButtonOverlay", ["VideoPlayerHooks", "VideoPlayerPlayButton.react", "VideoPlayerSmallPlayButton.react", "react", "useVideoPlayerHasStartedPlayingAtLeastOnce"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react")),
        k = h.useCallback;

    function a(a) {
        a = a === void 0 ? {} : a;
        var b = a.buttonSize;
        b = b === void 0 ? "large" : b;
        var e = a.forceVisible,
            f = a.overrideInteraction,
            g = a.shouldUnmute;
        a = c("useVideoPlayerHasStartedPlayingAtLeastOnce")();
        var h = (i || (i = d("VideoPlayerHooks"))).usePaused(),
            l = i.useLastMuteReason(),
            m = i.useController(),
            n = k(function() {
                m.play("user_initiated"), g === !0 && l !== "user_initiated" && m.setMuted(!1, "product_initiated")
            }, [m, l, g]);
        f = f != null ? f.handler : n;
        n = e === !0 || e === !1 ? e : !a && h;
        e = b === "small" ? j.jsx(c("VideoPlayerSmallPlayButton.react"), {
            isVisible: n,
            onClick: f
        }) : j.jsx(c("VideoPlayerPlayButton.react"), {
            isVisible: n,
            onClick: f
        });
        return {
            bigPlayButtonElement: e,
            bigPlayButtonIsVisible: n
        }
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerDefaultControlsVisibility", ["VideoPlayerHooks", "VideoPlayerInstreamAdsStateHooks", "VideoPlayerUserInteractionCounter", "clearTimeout", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    b = h || d("react");
    var j = b.useEffect,
        k = b.useState,
        l = 5e3;

    function a(a) {
        a = a === void 0 ? {} : a;
        var b = a.forceVisible,
            e = a.forceVisibleOnMount;
        a.isInteracting;
        a = d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteractionCounter();
        var f = a.ongoingInteractionsCount;
        a = a.onUserInteraction;
        var g = (i || (i = d("VideoPlayerHooks"))).useEnded(),
            h = i.useIsHovering(),
            m = i.usePaused(),
            n = i.useIsMouseIdle(),
            o = i.useVideoPlaybackEnded(),
            p = d("VideoPlayerInstreamAdsStateHooks").useInstreamAdsIsStart();
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_pointer_active", h && !n, a);
        h = k(e === !0);
        var q = h[0],
            r = h[1];
        j(function() {
            if (!m && q) {
                var a = c("setTimeout")(function() {
                    r(!1)
                }, l);
                return function() {
                    c("clearTimeout")(a)
                }
            }
        }, [q, m]);
        b === !0 || b === !1 ? n = b : p ? n = !1 : f > 0 || q ? n = !0 : m ? n = g ? o : !0 : n = !1;
        return {
            isControlsVisible: n,
            onUserInteraction: a
        }
    }
    g["default"] = a
}), 98);