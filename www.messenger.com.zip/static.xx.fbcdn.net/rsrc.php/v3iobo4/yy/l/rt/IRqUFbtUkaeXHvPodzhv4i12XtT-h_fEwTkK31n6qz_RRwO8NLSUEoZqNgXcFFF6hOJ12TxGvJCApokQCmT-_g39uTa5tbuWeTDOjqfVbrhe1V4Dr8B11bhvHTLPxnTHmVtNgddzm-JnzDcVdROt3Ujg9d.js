; /*FB_PKG_DELIM*/

__d("MAWEncryptedBackupsRestoreDialogContexts_query.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "MAWEncryptedBackupsRestoreDialogContexts_query",
        selections: [{
            alias: null,
            args: null,
            concreteType: "XFBEncryptedBackup",
            kind: "LinkedField",
            name: "xfb_backup",
            plural: !1,
            selections: [{
                args: null,
                kind: "FragmentSpread",
                name: "useMWEncryptedBackupsGetVirtualDevicesPreloaded_xfbEncryptedBackup"
            }, {
                alias: null,
                args: [{
                    kind: "Literal",
                    name: "family_device_id",
                    value: ""
                }],
                kind: "ScalarField",
                name: "has_otc_eligible_devices",
                storageKey: 'has_otc_eligible_devices(family_device_id:"")'
            }],
            storageKey: null
        }, {
            kind: "RequiredField",
            field: {
                alias: null,
                args: null,
                concreteType: "Viewer",
                kind: "LinkedField",
                name: "viewer",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "MessengerDefaultEncryptedBackup",
                    kind: "LinkedField",
                    name: "messenger_default_encrypted_backup",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "VestaGetUserInfoResponse",
                        kind: "LinkedField",
                        name: "vesta_user_info",
                        plural: !1,
                        selections: [{
                            args: null,
                            kind: "FragmentSpread",
                            name: "useMWChatEncryptedBackupsVestaUserInfo_vestaGetUserInfoResponse"
                        }],
                        storageKey: null
                    }],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "XFBEncryptedBackup",
                    kind: "LinkedField",
                    name: "encrypted_backup",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "has_seen_eb_auto_restore_notice",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            },
            action: "THROW",
            path: "viewer"
        }],
        type: "Query",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("MWChatEncryptedBackupsDismissalDialogContextProvider.react", ["MWChatEncryptedBackupsDismissalDialogContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useMemo,
        k = b.useState;

    function a(a) {
        var b = a.children;
        a = a.isDismissedDisabledValue;
        a = k(a);
        var d = a[0],
            e = a[1];
        a = j(function() {
            return {
                isDismissedDisabled: d,
                setIsDismissedDisabled: e
            }
        }, [d]);
        return i.jsx(c("MWChatEncryptedBackupsDismissalDialogContext").Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWChatEncryptedBackupsRestoreUpsellDialogContextProvider.react", ["MWChatEncryptedBackupsSetIsDialogPersistedContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;

    function a(a) {
        var b = a.children,
            d = a.setIsDialogPersisted;
        a = j(function() {
            return {
                setIsDialogPersisted: d
            }
        }, [d]);
        return d != null ? i.jsx(c("MWChatEncryptedBackupsSetIsDialogPersistedContext").Provider, {
            value: a,
            children: b
        }) : b
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEBHasSeenAutoRestoreNoticeContextProvider.react", ["MWEBHasSeenAutoRestoreNoticeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;

    function a(a) {
        var b = a.children,
            d = a.hasSeenNotice;
        a = j(function() {
            return {
                hasSeenNotice: d
            }
        }, [d]);
        return i.jsx(c("MWEBHasSeenAutoRestoreNoticeContext").Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWEncryptedBackupsRestoreDialogContexts.react", ["CometRelay", "CometTransientDialogProvider.react", "MAWEncryptedBackupsRestoreDialogContexts_query.graphql", "MWChatEncryptedBackupsDismissalDialogContextProvider.react", "MWChatEncryptedBackupsRestoreUpsellDialogContextProvider.react", "MWEBFlowSourceContextProvider.react", "MWEBHasSeenAutoRestoreNoticeContextProvider.react", "MWEBVestaUserInfoContext.react", "MWEBVirtualDevicesContextProvider.react", "react", "useMWChatEncryptedBackupsVestaUserInfo", "useMWEncryptedBackupsGetVirtualDevicesPreloaded"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useMemo;

    function a(a) {
        var e, f, g = a.children,
            i = a.query,
            l = a.setIsDialogPersisted;
        a = a.source;
        i = d("CometRelay").useFragment(h !== void 0 ? h : h = b("MAWEncryptedBackupsRestoreDialogContexts_query.graphql"), i);
        e = (e = i.viewer.messenger_default_encrypted_backup) == null ? void 0 : e.vesta_user_info;
        var m = c("useMWChatEncryptedBackupsVestaUserInfo")({
            vestaGetUserInfoResponse$key: e
        });
        e = c("useMWEncryptedBackupsGetVirtualDevicesPreloaded")({
            encryptedBackup: i.xfb_backup
        });
        e = e.getVirtualDevices;
        e = e();
        var n = e.offlineDevicesCount;
        e = e.vestaClientID;
        var o = k(function() {
            return {
                attemptsRemaining: m.attemptsRemaining,
                loginTimeoutRemainingSecs: m.loginTimeoutRemainingSecs,
                vestaClientID: null
            }
        }, [m.attemptsRemaining, m.loginTimeoutRemainingSecs]);
        return j.jsx(c("MWEBVirtualDevicesContextProvider.react"), {
            hasOtcEligibleDevicesInitialValue: (f = (f = i.xfb_backup) == null ? void 0 : f.has_otc_eligible_devices) != null ? f : void 0,
            offlineDevicesCountInitialValue: n,
            vestaClientIDInitialValue: e,
            children: j.jsx(c("MWEBHasSeenAutoRestoreNoticeContextProvider.react"), {
                hasSeenNotice: (n = (f = i.viewer.encrypted_backup) == null ? void 0 : f.has_seen_eb_auto_restore_notice) != null ? n : !1,
                children: j.jsx(c("MWEBFlowSourceContextProvider.react"), {
                    source: a,
                    children: j.jsx(c("MWChatEncryptedBackupsDismissalDialogContextProvider.react"), {
                        isDismissedDisabledValue: !1,
                        children: j.jsx(c("MWChatEncryptedBackupsRestoreUpsellDialogContextProvider.react"), {
                            setIsDialogPersisted: function(a) {
                                l == null ? void 0 : l(a)
                            },
                            children: j.jsx(d("MWEBVestaUserInfoContext.react").MWEBVestaUserInfoContext.Provider, {
                                value: o,
                                children: j.jsx(c("CometTransientDialogProvider.react"), {
                                    children: g
                                })
                            })
                        })
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWSecureInboxInfoSharedContentFile.react", ["CometHeroHoldTrigger.react", "CometPlaceholder.react", "LSMessagingThreadTypeUtil", "MAWFilePressable.react", "MWInboxInfoSharedContentFilePreview.react", "MWMediaGalleryRenderQpl", "MWV2AttachmentErrorPlaceholder.react", "MWV2AttachmentLoadingPlaceholder.react", "MWXRow.react", "MWXRowItem.react", "MWXTextPairing.react", "cr:7482", "react", "useEmptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo,
        k = 60,
        l = 350,
        m = (e = b("cr:7482")) != null ? e : c("useEmptyFunction"),
        n = {
            contentRowItem: {
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            errorPlaceholder: {
                borderTopStartRadius: "xhw592a",
                borderTopEndRadius: "xwihvcr",
                borderBottomEndRadius: "x7wuybg",
                borderBottomStartRadius: "xb9tvrk",
                $$css: !0
            },
            fileRow: {
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                $$css: !0
            },
            iconRowItem: {
                backgroundColor: "xlhe6ec",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                height: "xdd8jsf",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "xyinxu5",
                paddingEnd: "xmns6w2",
                paddingBottom: "x1g2khh7",
                paddingStart: "xpkgp8e",
                width: "xvni27",
                $$css: !0
            },
            loadingPlaceholder: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.file,
            e = a.onPress;
        a = a.threadType;
        var f = d("MWMediaGalleryRenderQpl").useMediaGalleryRenderQpl(b, a);
        a = d("LSMessagingThreadTypeUtil").isArmadilloSecure(a);
        var g = j(function() {
            return [b]
        }, [b]);
        m({
            attachments: g,
            isSecure: a,
            mediaRenderQpl: f,
            triggerUIView: "gallery"
        });
        return b.hasMedia === !1 ? i.jsxs(i.Fragment, {
            children: [i.jsx(c("MWV2AttachmentLoadingPlaceholder.react"), {
                descriptionForLogging: "MAWSecureInboxInfoSharedContentFile.NoMedia",
                height: k,
                mediaRenderQpl: f,
                width: l,
                xstyle: n.loadingPlaceholder
            }), i.jsx(c("CometHeroHoldTrigger.react"), {
                description: "MAWSecureInboxInfoSharedContentFile.NoMedia",
                hold: !0
            })]
        }) : i.jsx(c("CometPlaceholder.react"), {
            fallback: i.jsx(c("MWV2AttachmentLoadingPlaceholder.react"), {
                descriptionForLogging: "MAWSecureInboxInfoSharedContentFile.Suspense",
                height: k,
                mediaRenderQpl: f,
                width: l,
                xstyle: n.loadingPlaceholder
            }),
            name: "MAWSecureInboxInfoSharedContentFile",
            children: i.jsx(o, {
                file: b,
                mediaRenderQpl: f,
                onPress: e
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function o(a) {
        var b = a.file,
            d = a.mediaRenderQpl;
        a = a.onPress;
        return i.jsx(c("MAWFilePressable.react"), {
            entrypoint: "inbox_info_v1",
            file: b,
            mediaRenderQpl: d,
            onPress: a,
            renderUnsupportedAttachment: function() {
                return i.jsx(c("MWV2AttachmentErrorPlaceholder.react"), {
                    height: k,
                    width: l,
                    xstyle: n.errorPlaceholder
                })
            },
            children: function(a) {
                var b = a.filename,
                    d = a.messageID;
                a = a.size;
                return i.jsxs(c("MWXRow.react"), {
                    expanding: !0,
                    paddingTop: 0,
                    verticalAlign: "center",
                    xstyle: n.fileRow,
                    children: [i.jsx(c("MWXRowItem.react"), {
                        xstyle: n.iconRowItem,
                        children: i.jsx(c("MWInboxInfoSharedContentFilePreview.react"), {
                            messageID: d
                        })
                    }), i.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        xstyle: n.contentRowItem,
                        children: i.jsx(c("MWXTextPairing.react"), {
                            body: a,
                            bodyColor: "secondary",
                            headline: b,
                            headlineLineLimit: 1,
                            level: 4
                        })
                    })]
                })
            }
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWChatEncryptedBackupsAutoRestoreConsentStepDeferred.react", ["deferredLoadComponent", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferred")("MWChatEncryptedBackupsAutoRestoreConsentStep.react").__setRef("MWChatEncryptedBackupsAutoRestoreConsentStepDeferred.react"));

    function a(a) {
        return i.jsx(j, babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint", ["JSResourceForInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {}
            }
        },
        root: c("JSResourceForInteraction")("MWChatEncryptedBackupsOTCHelpDialogPage.react").__setRef("MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint")
    };
    g["default"] = a
}), 98);
__d("MWEBQPResetPIN.react", ["ix", "CometImageFromIXValue.react", "gkx", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react"),
        k = c("gkx")("23433");
    b = j.forwardRef(a);

    function a(a, b) {
        var d = a.alt;
        a = a.xstyle;
        var e = k ? h("421464") : h("421459");
        return j.jsx(c("CometImageFromIXValue.react"), {
            alt: d,
            ref: b,
            source: e,
            xstyle: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("MWChatEncryptedBackupsPinCodeRestoreStep.react", ["fbt", "CometPlaceholder.react", "FocusRegion.react", "JSResourceForInteraction", "MWChatEBPinCodeVerifyIndicator.react", "MWChatEncryptedBackupsNumericCodeErrorWrapper.react", "MWChatEncryptedBackupsNumericCodeInput.react", "MWChatEncryptedBackupsQPLEvents", "MWEBQPResetPIN.react", "MWEBVestaUserInfoContext.react", "MWXColumn.react", "MWXColumnItem.react", "MWXDialogPageLegacy.react", "MWXLink.react", "MWXMultiStepDialogHeader.react", "MWXText.react", "QPLUserFlow", "cr:6247", "focusScopeQueries", "gkx", "lazyLoadComponent", "promiseDone", "react", "useEncryptedBackupsQplImpressionRef", "useMWChatEncryptedBackupsPinCodeRestore", "xplatToDOMRef"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react"));
    e = i;
    var k = e.useEffect,
        l = e.useState,
        m = c("gkx")("23219"),
        n = c("JSResourceForInteraction")("MWChatEncryptedBackupsPinCodeBlockedStep.react").__setRef("MWChatEncryptedBackupsPinCodeRestoreStep.react"),
        o = "chat-encrypted-backups-dialog-layout-restore-step";

    function a(a) {
        var e = a.clientID,
            f = a.onChooseOtc,
            g = a.onClose,
            i = a.onComplete,
            p = a.onForgotPin;
        a = a.shouldShowForgotButton;
        a = a === void 0 ? !0 : a;
        var q = l(null),
            r = q[0];
        q = q[1];
        e = d("useMWChatEncryptedBackupsPinCodeRestore").useMWChatEncryptedBackupsPinCodeRestore({
            clientID: e,
            focusRegionId: o,
            onVestaComplete: i
        });
        var s = e.focusOnInput,
            t = e.inputProps,
            u = e.isInProgress,
            v = e.isLabyrinthError,
            w = e.isPinCodeIncorrect;
        e = e.isVestaError;
        var x = l(!1),
            y = x[0];
        x = x[1];
        u = u || y;
        y = h._("__JHASH__9V8QrautPXH__JHASH__");
        var z = d("MWEBVestaUserInfoContext.react").useMWEBVestaUserInfo(),
            A = z.attemptsRemaining;
        z = z.loginTimeoutRemainingSecs;
        var B = A === 0,
            C = d("MWEBVestaUserInfoContext.react").useMWEBIsCooldownOrLockOutState(),
            D = c("useEncryptedBackupsQplImpressionRef")(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "PIN_CODE_RESTORE_SCREEN", void 0, function() {
                s(), E != null && c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_OPTION_DISPLAYED_RESTORE_SCREEN")
            });
        a = a ? j.jsx(c("MWXLink.react"), {
            disabled: C || u,
            onClick: function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "PIN_CODE_RESTORE_FORGOT_PIN_CLICK"), p()
            },
            rel: "noreferrer",
            testid: void 0,
            children: j.jsx(c("MWXText.react"), {
                color: C || u ? "disabled" : "highlight",
                type: "button2",
                children: h._("__JHASH__UY_FDJp7Rzt__JHASH__")
            })
        }) : null;
        var E = f !== null ? j.jsx(c("MWXText.react"), {
            color: C || u ? "disabled" : "highlight",
            type: "button2",
            children: j.jsx(c("MWXLink.react"), {
                disabled: C || u,
                onClick: function() {
                    c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_USE_ONE_TIME_CODE_CLICK"), f()
                },
                rel: "noreferrer",
                testid: void 0,
                children: h._("__JHASH__rIytKXj5Yr0__JHASH__")
            })
        }) : null;
        a = E != null ? E : a;
        var F = h._("__JHASH__6pjlJMQcqkh__JHASH__"),
            G = c("lazyLoadComponent")(n);
        G = C ? j.jsx(G, {
            attemptsRemaining: A,
            loginTimeoutRemainingSecs: z,
            onClose: g,
            onComplete: i
        }) : j.jsx(c("MWXDialogPageLegacy.react"), {
            callToActionGroupLayout: "expanded",
            includeFDSContentPadding_REMOVE_THIS_AFTER_CONTENT_PADDING_MIGRATION: !1,
            ref: d("xplatToDOMRef").xplatToDOMRef(D),
            children: j.jsxs(c("MWXColumn.react"), {
                align: "center",
                paddingHorizontal: 16,
                paddingVertical: 16,
                spacing: 0,
                children: [j.jsx(c("MWXColumnItem.react"), {
                    align: "center",
                    paddingTop: 16,
                    children: j.jsx("div", {
                        className: "xg87l8a",
                        children: j.jsx(c("MWEBQPResetPIN.react"), {})
                    })
                }), j.jsx(c("MWXColumnItem.react"), {
                    align: "center",
                    paddingVertical: 16,
                    children: j.jsx(c("MWXText.react"), {
                        align: "center",
                        type: "headlineEmphasized2",
                        children: F
                    })
                }), j.jsx(c("MWXColumnItem.react"), {
                    align: "center",
                    children: j.jsx(c("MWXText.react"), {
                        align: "center",
                        color: "secondary",
                        type: "body3",
                        children: j.jsx("div", {
                            className: "x1l90r2v x2b8uid",
                            children: y
                        })
                    })
                }), j.jsx(c("MWXColumnItem.react"), {
                    align: "center",
                    children: j.jsx(c("MWChatEncryptedBackupsNumericCodeErrorWrapper.react"), {
                        error: (C = r) != null ? C : w && E != null ? h._("__JHASH__92mf973T2UM__JHASH__") : w ? h._("__JHASH__TG8l6XqQAul__JHASH__") : v || e ? h._("__JHASH__oI6Lha5PMTv__JHASH__") : void 0,
                        children: j.jsx(d("FocusRegion.react").FocusRegion, {
                            autoFocusQuery: d("focusScopeQueries").tabbableScopeQuery,
                            id: o,
                            children: j.jsx(c("MWChatEncryptedBackupsNumericCodeInput.react"), babelHelpers["extends"]({}, t, {
                                disabled: z != null || B || u,
                                testid: void 0
                            }))
                        })
                    })
                }), u && j.jsx(c("MWXColumnItem.react"), {
                    align: "center",
                    children: j.jsx(c("MWChatEBPinCodeVerifyIndicator.react"), {
                        isMessenger: m
                    })
                }), !u && j.jsx(c("MWXColumnItem.react"), {
                    align: "center",
                    children: j.jsx("div", {
                        className: "x1y1aw1k",
                        children: a
                    })
                }), b("cr:6247") != null && j.jsx(c("CometPlaceholder.react"), {
                    fallback: null,
                    name: "MWChatEncryptedBackupsPinCodeRestoreStep",
                    children: j.jsx(b("cr:6247"), {
                        onComplete: i,
                        onError: q,
                        setIsLoading: x
                    })
                })]
            })
        });
        k(function() {
            c("promiseDone")(n.load())
        }, []);
        return j.jsxs(j.Fragment, {
            children: [j.jsx(c("MWXMultiStepDialogHeader.react"), {
                withCloseButton: !1,
                withoutBackButton: !0
            }), G]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWChatEncryptedBackupsRingIndeterminateIcon.react", ["CometHeroHoldTrigger.react", "MWXSpinner.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            large: {
                minHeight: "x1zwvfr",
                $$css: !0
            },
            root: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                justifyContent: "xl56j7k",
                $$css: !0
            },
            small: {
                minHeight: "x1edz59j",
                $$css: !0
            }
        };

    function a(a) {
        a = a.size;
        a = a === void 0 ? "large" : a;
        return j.jsxs("div", {
            className: (h || (h = c("stylex")))(k.root, k[a]),
            children: [j.jsx(c("CometHeroHoldTrigger.react"), {
                description: "MWEBRingSpinner",
                hold: !0
            }), j.jsx(c("MWXSpinner.react"), {
                color: "blue",
                size: 60
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEBOTCErrorMessages", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = function() {
        return h._("__JHASH__lBlURV9iIv0__JHASH__")
    };
    b = function() {
        return h._("__JHASH__rIH_-tfv2x2__JHASH__")
    };
    c = function() {
        return h._("__JHASH__WypD50Gdi03__JHASH__")
    };
    d = function() {
        return h._("__JHASH__7uRJ4wtXcoz__JHASH__")
    };
    e = function() {
        return h._("__JHASH__XUu1h3R4qPj__JHASH__")
    };
    f = function() {
        return h._("__JHASH__ndaWq552FSK__JHASH__")
    };
    var i = function() {
        return h._("__JHASH__WoNRZZnIdhP__JHASH__")
    };
    g.getOtcIsWrongErrorMessage = a;
    g.getNoSessionOngoingErrorMessage = b;
    g.getMaxAttemptsReachedErrorMessage = c;
    g.getSessionExpiredErrorMessage = d;
    g.getGeneralErrorMessage = e;
    g.getNotificationFailedToSendErrorMessage = f;
    g.getFailedToFetchOtcDevicesErrorMessage = i
}), 226);
__d("MWEBQPOneTimeCode.react", ["ix", "CometImageFromIXValue.react", "gkx", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react"),
        k = c("gkx")("23433");
    b = j.forwardRef(a);

    function a(a, b) {
        var d = a.alt;
        a = a.xstyle;
        var e = k ? h("421460") : h("421458");
        return j.jsx(c("CometImageFromIXValue.react"), {
            alt: d,
            ref: b,
            source: e,
            xstyle: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("PAKEClientTypeEnum", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        PAKE_TEST: -1,
        ENCRYPTED_BACKUPS: 0,
        EB_MULTI_USER_OTC: 1
    });
    f["default"] = a
}), 66);
__d("usePakeInitiatorManager", ["FBLogger", "PakeCpaceWasm", "Promise", "asyncToGeneratorRuntime", "promiseDone", "react", "requireDeferred", "useAsyncReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    e = i || d("react");
    var j = e.useCallback,
        k = e.useEffect,
        l = e.useRef,
        m = c("requireDeferred")("establishPakeHandshakeAsInitiator").__setRef("usePakeInitiatorManager"),
        n = 3e4;

    function a(a) {
        var e = a.onGeneralFailure,
            f = a.onMaxAttemptsReached,
            g = a.onNoSessionExists,
            i = a.onSessionExpired,
            o = a.onSuccessfulSecretDecryption,
            p = a.onWrongOtc,
            q = a.timeout,
            r = q === void 0 ? n : q,
            s = a.clientType,
            t = c("useAsyncReStore")(),
            u = l(null),
            v = l(function() {}),
            w = l(function() {}),
            x = l(null),
            y = l(!1);
        k(function() {
            y.current === !1 && (y.current = !0, c("promiseDone")(d("PakeCpaceWasm").PakeCPaceWasm().then(function(a) {
                x.current = a
            }), void 0, function() {
                c("FBLogger")("labyrinth_web").mustfix("PAKE: Error loading WASM module")
            }));
            return function() {
                var a;
                w.current();
                (a = u.current) == null ? void 0 : a["delete"]();
                v.current()
            }
        }, []);
        return {
            establishPakeHandshakeAsInitiator: j(function(a) {
                return (h || (h = b("Promise"))).all([t, m.load()]).then(function() {
                    var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                        var c = b[0];
                        b = b[1];
                        b = (yield b({
                            clientType: s,
                            onGeneralFailure: e,
                            onMaxAttemptsReached: f,
                            onNoSessionExists: g,
                            onSessionExpired: i,
                            onSuccessfulSecretDecryption: o,
                            onWrongOtc: p,
                            otc: a,
                            pakeCpaceModule: x.current,
                            storage: c,
                            timeout: r
                        }));
                        c = b.pakeClient;
                        var d = b.stopTimeout;
                        b = b.unsubFromMessagesTable;
                        u.current = c;
                        v.current = d;
                        w.current = b
                    });
                    return function(a) {
                        return c.apply(this, arguments)
                    }
                }())
            }, [s, t, e, f, g, i, o, p, r])
        }
    }
    g["default"] = a
}), 98);
__d("usePushFDSMultiStepDialogEntryPointPage", ["BaseMultiPageEntryPointImpl.react", "CometRelay", "FDSMultiStepDialogPushPageContext.react", "react", "useCometRelayEntrypointContextualEnvironmentProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useContext,
        l = b.useTransition;

    function a(a, b) {
        var e = l(),
            f = e[0],
            g = e[1],
            h = c("useCometRelayEntrypointContextualEnvironmentProvider")(),
            m = k(d("FDSMultiStepDialogPushPageContext.react").FDSMultiStepDialogPushPageContext);
        e = j(function(e, f) {
            if (b == null) return;
            g(function() {
                var g, j = d("CometRelay").loadEntryPoint(h, a, b);
                g = (g = f) != null ? g : {};
                var k = g.fallback;
                g = babelHelpers.objectWithoutPropertiesLoose(g, ["fallback"]);
                m(function() {
                    return i.jsx(c("BaseMultiPageEntryPointImpl.react"), {
                        entryPoint: a,
                        environmentProvider: h,
                        fallback: k,
                        loadedEntryPoint: j,
                        otherProps: e,
                        preloadParams: b,
                        usePlaceholder: k != null
                    })
                }, g)
            })
        }, [m, h, a, b, g]);
        return [f, e]
    }
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsInsertOTCStep.react", ["fbt", "EBSMGating", "FBLogger", "FocusRegion.react", "JSResourceForInteraction", "MWChatEncryptedBackupsLogging", "MWChatEncryptedBackupsNumericCodeErrorWrapper.react", "MWChatEncryptedBackupsNumericCodeInput.react", "MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint", "MWChatEncryptedBackupsQPLEvents", "MWChatEncryptedBackupsSetIsDialogPersistedContext", "MWEBOTCErrorMessages", "MWEBQPOneTimeCode.react", "MWEncrypedBackupsSendOTCNotifications", "MWEncryptedBackupsLocalStorageEntryEnum", "MWXColumn.react", "MWXColumnItem.react", "MWXDeferredPopoverTrigger.react", "MWXDialogPageLegacy.react", "MWXLink.react", "MWXMultiStepDialogHeader.react", "MWXRow.react", "MWXRowItem.react", "MWXSpinner.react", "MWXText.react", "PAKEClientTypeEnum", "QPLUserFlow", "focusScopeQueries", "gkx", "promiseDone", "qex", "react", "requireDeferred", "useAsyncReStore", "useFetchOTCEligibleEBDevices", "useMWChatEncryptedBackupsNumericCode", "useMWEBFlowSourceContext", "usePakeInitiatorManager", "usePushFDSMultiStepDialogEntryPointPage", "useVisibilityObserver"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react"));
    b = i;
    var k = b.useCallback,
        l = b.useContext,
        m = b.useEffect,
        n = b.useMemo,
        o = b.useRef,
        p = b.useState,
        q = c("requireDeferred")("MWEBUseLocalStorage").__setRef("MWEncryptedBackupsInsertOTCStep.react"),
        r = c("requireDeferred")("MWEncryptedBackupsFetchBackupIds").__setRef("MWEncryptedBackupsInsertOTCStep.react"),
        s = c("requireDeferred")("MWEncryptedBackupsOTCEligibleDevicesPopover.react").__setRef("MWEncryptedBackupsInsertOTCStep.react"),
        t = c("requireDeferred")("MWEncryptedBackupsSharedState").__setRef("MWEncryptedBackupsInsertOTCStep.react"),
        u = c("requireDeferred")("deserializeSecretsAndAddDevice").__setRef("MWEncryptedBackupsInsertOTCStep.react"),
        v = c("JSResourceForInteraction")("MWEBPushResetPinPage").__setRef("MWEncryptedBackupsInsertOTCStep.react"),
        w = "chat-encrypted-backups-dialog-layout-second-step",
        x = 6,
        y = c("gkx")("23219"),
        z = c("gkx")("20861"),
        A = (e = c("qex")._("2054")) != null ? e : !1,
        B = (b = c("qex")._("2118")) != null ? b : !1,
        C = (e = c("qex")._("2119")) != null ? e : !1,
        D = (b = c("qex")._("2117")) != null ? b : !1;

    function a(a) {
        var b = a.isSecondStep,
            e = b === void 0 ? !1 : b,
            f = a.onComplete,
            g = a.onViewAllDevices,
            i = a.onClose,
            E = a.onSkip;
        b = p(!1);
        a = b[0];
        var F = b[1],
            G = o(!1),
            H = o(!1),
            I = o(function() {});
        b = p(null);
        var J = b[0],
            K = b[1],
            L = c("useAsyncReStore")();
        b = c("useFetchOTCEligibleEBDevices")(e ? "store-or-network" : "network-only");
        var M = b.triggerFetchOtcEligibleDevices,
            N = c("useMWEBFlowSourceContext")(),
            O = l(c("MWChatEncryptedBackupsSetIsDialogPersistedContext")).setIsDialogPersisted;
        m(function() {
            return function() {
                I.current()
            }
        }, []);
        b = d("MWEncrypedBackupsSendOTCNotifications").useSendOTCNotifications();
        var P = b[0],
            Q = b[1],
            R = k(function() {
                P()["catch"](function() {
                    c("FBLogger")("labyrinth_web").mustfix("OTC: Send otc notifications sproc failed."), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_SEND_NOTIFICATION_FAILURE"), K(d("MWEBOTCErrorMessages").getNotificationFailedToSendErrorMessage())
                })
            }, [P]);
        m(function() {
            G.current === !1 && (G.current = !0, c("promiseDone")(v.load()), c("MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint").root.preload(), e || R())
        }, [e, R]);
        b = c("usePakeInitiatorManager")({
            clientType: c("PAKEClientTypeEnum").ENCRYPTED_BACKUPS,
            onGeneralFailure: k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_API_FAILURE"), K(d("MWEBOTCErrorMessages").getGeneralErrorMessage()), H.current = !0, F(!1), O == null ? void 0 : O(!1)
            }, [O]),
            onMaxAttemptsReached: k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_MAX_ATTEMPTS_REACHED"), K(d("MWEBOTCErrorMessages").getMaxAttemptsReachedErrorMessage()), H.current = !0, F(!1)
            }, []),
            onNoSessionExists: k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_NO_SESSION"), K(d("MWEBOTCErrorMessages").getNoSessionOngoingErrorMessage()), H.current = !0, F(!1)
            }, []),
            onSessionExpired: k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_SESSION_EXPIRED"), K(d("MWEBOTCErrorMessages").getSessionExpiredErrorMessage()), H.current = !0, F(!1)
            }, []),
            onSuccessfulSecretDecryption: k(function(a) {
                var b = a.decryptedSecret,
                    e = a.initiatorId;
                O == null ? void 0 : O(!0);
                c("promiseDone")(u.load(), function(a) {
                    c("promiseDone")(L.then(function(g) {
                        return a({
                            db: g,
                            initiatorId: e,
                            onAddDeviceFailure: function() {
                                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_ADD_DEVICE_FAILURE"), K(d("MWEBOTCErrorMessages").getGeneralErrorMessage()), H.current = !0, F(!1), O == null ? void 0 : O(!1)
                            },
                            onAddDeviceFinish: function() {
                                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_ADD_DEVICE_FINISHED"), d("MWChatEncryptedBackupsLogging").endSuccess({
                                    annotations: {
                                        bool: {
                                            is_backend_setup: d("EBSMGating").isBackendSetupSuccessfulForEBSM()
                                        }
                                    },
                                    event: d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent
                                }), t.onReady(function(a) {
                                    a = a.upsertEBSharedStateEntry;
                                    c("promiseDone")(a({
                                        db: g,
                                        stateKey: c("MWEncryptedBackupsLocalStorageEntryEnum").ENCRYPTED_BACKUPS_RESTORED_SUCCESSFULLY
                                    }))
                                }), q.onReady(function(a) {
                                    var b = a.mwEBCreateLocalStorageEntry;
                                    a = a.mwEBDeleteLocalStorageEntry;
                                    b(c("MWEncryptedBackupsLocalStorageEntryEnum").MW_EB_HAS_RESTORED_IN_CURRENT_SESSION);
                                    b(c("MWEncryptedBackupsLocalStorageEntryEnum").MW_EB_HAS_RESTORED_IN_CURRENT_SESSION_2);
                                    a(c("MWEncryptedBackupsLocalStorageEntryEnum").EBSM_CORRUPTION_WIPE)
                                }), f(), F(!1), r.onReady(function(a) {
                                    a = a.encryptedBackupsFetchBackupIds;
                                    a(g)["catch"](function(a) {
                                        return c("FBLogger")("labyrinth_web").mustfix("OTC Restore: Error when fetching backup ids, %s", a)
                                    })
                                })
                            },
                            secrets: b
                        })
                    }), function(a) {
                        I.current = a
                    })
                })
            }, [L, f, O]),
            onWrongOtc: k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_INCORRECT_CODE"), K(d("MWEBOTCErrorMessages").getOtcIsWrongErrorMessage()), H.current = !0, F(!1)
            }, [])
        });
        var aa = b.establishPakeHandshakeAsInitiator;
        b = d("useMWChatEncryptedBackupsNumericCode").useMWChatEncryptedBackupsNumericCode({
            focusRegionId: w,
            inputSize: x,
            onChange: function() {
                K()
            },
            onComplete: function(a) {
                var b = N();
                c("QPLUserFlow").addAnnotations(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, {
                    string: {
                        restore_type: "one_time_code",
                        source: b
                    }
                });
                F(!0);
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_SUBMIT");
                c("promiseDone")(aa(a))
            }
        });
        var ba = b[0];
        b = b[1];
        var S = b.clearNumericInput,
            T = b.focusOnInput,
            U = b.isLoading,
            V = k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_RESEND_CLICK"), R(), T()
            }, [T, R]);
        b = c("usePushFDSMultiStepDialogEntryPointPage")(c("MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint"), {});
        b[0];
        var W = b[1],
            X = k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_HELP_CLICK"), D && W({
                    onClose: i,
                    onSkip: E
                })
            }, [i, E, W]);
        m(function() {
            H.current && (S(), H.current = !1)
        }, [S]);
        b = c("useVisibilityObserver")({
            onVisible: function() {
                c("QPLUserFlow").addAnnotations(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, {
                    bool: {
                        otc_check_first: e,
                        otc_devices_popover: A
                    }
                }), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_SCREEN"), T()
            }
        });
        var ca = C && !e ? h._("__JHASH__ZdKKLkchlbs__JHASH__") : h._("__JHASH__mdY4-jjsr2I__JHASH__"),
            Y = n(function() {
                return B ? {
                    disabled: U || Q,
                    label: h._("__JHASH__UA_X5BHDdA7__JHASH__"),
                    onPress: V,
                    testid: "mw-eb-otc-insert-resend-code-button"
                } : {
                    disabled: U,
                    label: h._("__JHASH__UdIx77e_03V__JHASH__"),
                    onPress: function() {
                        S(), K(), g({
                            onFetchOtcEligibleDevicesError: function() {
                                K(d("MWEBOTCErrorMessages").getFailedToFetchOtcDevicesErrorMessage()), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_FETCH_OTC_ELIGIBLE_DEVICES_FAILURE"), M()
                            },
                            onResendCodeFailure: function() {
                                K(d("MWEBOTCErrorMessages").getNotificationFailedToSendErrorMessage()), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESEND_NOTIFICATION_FAILURE")
                            }
                        }), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_VIEW_ALL_DEVICES_CLICK")
                    }
                }
            }, [S, U, Q, V, g, M]),
            Z = n(function() {
                return B && !e ? {
                    label: h._("__JHASH__94rkJHAT5R0__JHASH__"),
                    linkProps: D ? void 0 : {
                        target: "_blank",
                        url: "https://www.facebook.com/help/messenger-app/431055522328649?ref=learn_more"
                    },
                    onPress: X,
                    testid: "mw-eb-otc-insert-help-button"
                } : void 0
            }, [e, X]),
            $ = Z != null;
        return j.jsxs(j.Fragment, {
            children: [j.jsx(c("MWXMultiStepDialogHeader.react"), {
                withCloseButton: !1,
                withoutBackButton: !0,
                withoutHeaderBottomBorder: !0
            }), j.jsx(c("MWXDialogPageLegacy.react"), {
                callToActionGroupLayout: "expanded",
                includeFDSContentPadding_REMOVE_THIS_AFTER_CONTENT_PADDING_MIGRATION: !1,
                primaryCallToAction: $ && !a ? Y : void 0,
                ref: b,
                secondaryCallToAction: $ && !a ? Z : void 0,
                children: j.jsx("div", {
                    className: "x2lwn1j",
                    children: j.jsxs(c("MWXColumn.react"), {
                        align: "center",
                        paddingHorizontal: 16,
                        paddingTop: 16,
                        paddingVertical: $ && !a ? void 0 : 16,
                        spacing: 8,
                        children: [j.jsx(c("MWXColumnItem.react"), {
                            align: "center",
                            paddingTop: 16,
                            children: j.jsx("div", {
                                className: "xg87l8a",
                                children: j.jsx(c("MWEBQPOneTimeCode.react"), {})
                            })
                        }), j.jsx(c("MWXColumnItem.react"), {
                            align: "center",
                            paddingVertical: 16,
                            children: j.jsx(c("MWXText.react"), {
                                align: "center",
                                type: "headlineEmphasized2",
                                children: ca
                            })
                        }), !e && j.jsx(c("MWXColumnItem.react"), {
                            align: "center",
                            children: j.jsx("div", {
                                className: "x1l90r2v x2b8uid",
                                children: A ? j.jsx(c("MWXDeferredPopoverTrigger.react"), {
                                    align: "middle",
                                    popoverProps: {},
                                    popoverResource: s,
                                    position: "above",
                                    children: function(a, b) {
                                        return j.jsx(c("MWXText.react"), {
                                            color: "secondary",
                                            type: "body3",
                                            children: h._("__JHASH__qB8i3rbuT2p__JHASH__", [h._param("device", j.jsx(c("MWXText.react"), {
                                                color: "blueLink",
                                                ref: a,
                                                type: "bodyLink3",
                                                children: j.jsx(c("MWXLink.react"), {
                                                    onClick: function() {
                                                        c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_DEVICES_POPOVER_CLICK"), b()
                                                    },
                                                    testid: void 0,
                                                    children: h._("__JHASH__l-i0ZTsx1AJ__JHASH__")
                                                })
                                            }))])
                                        })
                                    }
                                }) : j.jsx(c("MWXText.react"), {
                                    color: "secondary",
                                    type: "body3",
                                    children: h._("__JHASH__lzSAd4UfKCU__JHASH__")
                                })
                            })
                        }), j.jsxs(c("MWXColumnItem.react"), {
                            align: "center",
                            children: [j.jsx(c("MWChatEncryptedBackupsNumericCodeErrorWrapper.react"), {
                                error: J,
                                children: j.jsx(d("FocusRegion.react").FocusRegion, {
                                    autoFocusQuery: d("focusScopeQueries").tabbableScopeQuery,
                                    id: w,
                                    children: j.jsx(c("MWChatEncryptedBackupsNumericCodeInput.react"), babelHelpers["extends"]({}, ba, {
                                        disabled: U || a,
                                        testid: void 0
                                    }))
                                })
                            }), z && J === d("MWEBOTCErrorMessages").getGeneralErrorMessage() ? j.jsx("div", {
                                className: "xwib8y2",
                                children: j.jsx(c("MWXText.react"), {
                                    align: "center",
                                    color: "negative",
                                    type: "body4",
                                    children: h._("__JHASH__47yJJ8U23lB__JHASH__")
                                })
                            }) : null]
                        }), a && j.jsx(c("MWXColumnItem.react"), {
                            align: "center",
                            paddingTop: $ ? 16 : 0,
                            paddingVertical: $ ? 8 : 0,
                            children: j.jsxs(c("MWXRow.react"), {
                                align: "center",
                                paddingTop: 8,
                                spacing: 8,
                                children: [j.jsx(c("MWXRowItem.react"), {
                                    verticalAlign: "center",
                                    children: j.jsx(c("MWXSpinner.react"), {
                                        color: y ? "disabled" : "blue",
                                        size: 12
                                    })
                                }), j.jsx(c("MWXRowItem.react"), {
                                    verticalAlign: "center",
                                    children: j.jsx(c("MWXText.react"), {
                                        color: "secondary",
                                        testid: void 0,
                                        type: "body3",
                                        children: h._("__JHASH__G3IwntRJlbU__JHASH__")
                                    })
                                })]
                            })
                        }), !$ && !a && j.jsx(c("MWXColumnItem.react"), {
                            align: "center",
                            paddingTop: 8,
                            children: j.jsx(c("MWXText.react"), {
                                color: Y.disabled ? "disabled" : "highlight",
                                type: "button2",
                                children: j.jsx(c("MWXLink.react"), {
                                    disabled: Y.disabled,
                                    onClick: Y.onPress,
                                    rel: "noreferrer",
                                    children: Y.label
                                })
                            })
                        })]
                    })
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("useIsPakeAwaitingClient", ["I64", "PAKEMessageTypeEnum", "ReQL", "ReQLSuspense", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a() {
        var a = (i || (i = c("useReStore")))();
        return d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(a.tables.pake_messages).filter(function(a) {
                return (h || (h = d("I64"))).to_int32(a.messageType) === c("PAKEMessageTypeEnum").AWAITING_CLIENT
            })
        }, [a.tables.pake_messages], f.id + ":22") != null
    }
    g["default"] = a
}), 98);
__d("MWEBOTCCheckFirstStep.react", ["fbt", "FBLogger", "FDSMultiStepDialogPushPageContext.react", "MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint", "MWChatEncryptedBackupsQPLEvents", "MWEBOTCErrorMessages", "MWEBQPOneTimeCode.react", "MWEncrypedBackupsSendOTCNotifications", "MWEncryptedBackupsInsertOTCStep.react", "MWEncryptedBackupsOTCEligibleDevicesList.react", "MWXColumn.react", "MWXColumnItem.react", "MWXDeferredPopoverTrigger.react", "MWXDialogFooter.react", "MWXDialogPage.react", "MWXLink.react", "MWXText.react", "QPLUserFlow", "qex", "react", "requireDeferred", "useFetchOTCEligibleEBDevices", "useIsPakeAwaitingClient", "usePushFDSMultiStepDialogEntryPointPage", "useVisibilityObserver"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react"));
    b = i;
    var k = b.useCallback,
        l = b.useEffect,
        m = b.useRef,
        n = b.useState,
        o = c("requireDeferred")("MWEncryptedBackupsOTCEligibleDevicesPopover.react").__setRef("MWEBOTCCheckFirstStep.react"),
        p = (e = c("qex")._("2054")) != null ? e : !1,
        q = (b = c("qex")._("2117")) != null ? b : !1;

    function a(a) {
        c("useFetchOTCEligibleEBDevices")("network-only");
        var b = c("usePushFDSMultiStepDialogEntryPointPage")(c("MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint"), {});
        b[0];
        var e = b[1];
        b = d("MWEncrypedBackupsSendOTCNotifications").useSendOTCNotifications();
        var f = b[0];
        b = b[1];
        var g = n(null),
            i = g[0],
            r = g[1];
        g = n(!1);
        var s = g[0],
            t = g[1],
            u = k(function() {
                r(null), f().then(function() {
                    c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_CHECK_FIRST_SEND_NOTIFICATION_SUCCESS")
                })["catch"](function() {
                    c("FBLogger")("labyrinth_web").mustfix("OTC: Send otc notifications sproc failed."), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_CHECK_FIRST_SEND_NOTIFICATION_FAILURE"), r(d("MWEBOTCErrorMessages").getNotificationFailedToSendErrorMessage())
                })["finally"](function() {
                    t(!0)
                })
            }, [f]);
        g = k(function() {
            c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_CHECK_FIRST_RESEND_CLICK"), u()
        }, [u]);
        var v = m(!1);
        l(function() {
            v.current === !1 && (v.current = !0, u(), c("MWChatEncryptedBackupsOTCHelpDialogPage.entrypoint").root.preload())
        }, [u]);
        var w = k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_CHECK_FIRST_HELP_CLICK"), q && e({
                    onClose: a.onClose,
                    onSkip: a.onSkip
                })
            }, [a.onClose, a.onSkip, e]),
            x = d("FDSMultiStepDialogPushPageContext.react").useCometMultiStepDialogPushPage(),
            y = c("useIsPakeAwaitingClient")() && s && !b,
            z = m(!1),
            A = k(function() {
                x(function() {
                    return j.jsx(c("MWEncryptedBackupsInsertOTCStep.react"), babelHelpers["extends"]({}, a, {
                        isSecondStep: !0
                    }))
                })
            }, [a, x]),
            B = k(function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_CHECK_FIRST_ENTER_CODE_CLICK"), A()
            }, [A]),
            C = c("useVisibilityObserver")({
                onVisible: function() {
                    c("QPLUserFlow").addAnnotations(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, {
                        bool: {
                            otc_check_first: !0,
                            otc_devices_popover: p
                        }
                    }), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, z.current ? "OTC_CHECK_FIRST_SCREEN_RETURN_IMPRESSION" : "OTC_CHECK_FIRST_SCREEN_IMPRESSION")
                }
            });
        l(function() {
            y && !z.current && (z.current = !0, A())
        }, [s, a, x, y, A]);
        return j.jsxs(c("MWXDialogPage.react"), {
            footer: j.jsx(c("MWXDialogFooter.react"), {
                callToActionGroupDirection: "backward",
                primaryCallToAction: y ? {
                    label: h._("__JHASH__hzCD1i1Wn-E__JHASH__"),
                    onPress: B,
                    type: "secondary"
                } : {
                    disabled: b,
                    label: h._("__JHASH__UA_X5BHDdA7__JHASH__"),
                    onPress: g,
                    testid: "mw-eb-otc-check-first-resend-code-button",
                    type: "secondary"
                },
                secondaryCallToAction: {
                    label: h._("__JHASH__94rkJHAT5R0__JHASH__"),
                    linkProps: q ? void 0 : {
                        target: "_blank",
                        url: "https://www.facebook.com/help/messenger-app/431055522328649?ref=learn_more"
                    },
                    onPress: w
                }
            }),
            header: null,
            children: [j.jsxs(c("MWXColumn.react"), {
                paddingHorizontal: 16,
                paddingTop: 16,
                ref: C,
                spacing: 20,
                children: [j.jsx(c("MWXColumnItem.react"), {
                    align: "center",
                    paddingTop: 40,
                    children: j.jsx(c("MWEBQPOneTimeCode.react"), {})
                }), j.jsx(c("MWXColumnItem.react"), {
                    children: j.jsx(c("MWXText.react"), {
                        align: "center",
                        type: "headlineEmphasized2",
                        children: h._("__JHASH__8OCZxcRqTua__JHASH__")
                    })
                }), j.jsx(c("MWXColumnItem.react"), {
                    children: p ? j.jsx(c("MWXDeferredPopoverTrigger.react"), {
                        align: "middle",
                        popoverProps: {},
                        popoverResource: o,
                        position: "above",
                        children: function(a, b) {
                            return j.jsx(c("MWXText.react"), {
                                align: "center",
                                color: "secondary",
                                type: "body3",
                                children: h._("__JHASH__wQDh8Xe3noO__JHASH__", [h._param("device", j.jsx(c("MWXText.react"), {
                                    color: "blueLink",
                                    ref: a,
                                    testid: void 0,
                                    type: "bodyLink3",
                                    children: j.jsx(c("MWXLink.react"), {
                                        onClick: function() {
                                            c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_CHECK_FIRST_DEVICES_POPOVER_CLICK"), b()
                                        },
                                        children: h._("__JHASH__l-i0ZTsx1AJ__JHASH__")
                                    })
                                }))])
                            })
                        }
                    }) : j.jsx(c("MWXText.react"), {
                        align: "center",
                        color: "secondary",
                        type: "body3",
                        children: h._("__JHASH__EG07cVojIno__JHASH__")
                    })
                }), !p && j.jsxs(j.Fragment, {
                    children: [j.jsx(c("MWXColumnItem.react"), {
                        children: j.jsx(c("MWXText.react"), {
                            color: "secondary",
                            testid: void 0,
                            type: "headline4",
                            children: h._("__JHASH__CJ-H7hw2E8Q__JHASH__")
                        })
                    }), j.jsx(c("MWXColumnItem.react"), {
                        align: "stretch",
                        paddingHorizontal: 8,
                        paddingTop: 8,
                        children: j.jsx(c("MWEncryptedBackupsOTCEligibleDevicesList.react"), {})
                    })]
                })]
            }), i != null && j.jsx(c("MWXColumnItem.react"), {
                paddingTop: 12,
                children: j.jsx(c("MWXText.react"), {
                    align: "center",
                    color: "negative",
                    type: "body4",
                    children: i
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("useMWAbandonRestoreConfirmationDialog", ["fbt", "MWChatEncryptedBackupsQPLEvents", "QPLUserFlow", "gkx", "react", "useMWXConfirmationDialog"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = (i || d("react")).useCallback;

    function a(a) {
        var b = c("useMWXConfirmationDialog")(),
            e = c("gkx")("23219");
        return j(function() {
            b({
                body: e ? h._("__JHASH__igJ7_fPkBWf__JHASH__") : h._("__JHASH__mJ4KzCvoneV__JHASH__"),
                confirm: h._("__JHASH__NclomsdgTqa__JHASH__"),
                title: h._("__JHASH__Lc-TiofSivN__JHASH__")
            }, function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "DONT_RESTORE_CONFIRMATION_CLICK"), a == null ? void 0 : a()
            }, function() {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "DONT_RESTORE_CANCEL_CLICK")
            })
        }, [b, e, a])
    }
    g["default"] = a
}), 226);
__d("MWEBRestoreDialog.react", ["InteractionTracing.xplat", "MAWEncryptedBackupsRestoreStep.react", "MAWPinCodeGating", "MWChatEncryptedBackupsDismissalDialogContext", "MWChatEncryptedBackupsLogging", "MWChatEncryptedBackupsQPLEvents", "MWChatEncryptedBackupsQPLSource.enum", "MWChatEncryptedBackupsRingIndeterminateIcon.react", "MWEBHasSeenAutoRestoreNoticeContext", "MWEBLazyLoadResetPinPage", "MWEBVirtualDevicesContext.react", "MWEncryptedBackupsDeviceRegistrationId", "MWEncryptedBackupsForgotPinStep", "MWEncryptedBackupsForgotRCStep", "MWEncryptedBackupsOtcRestoreSteps", "MWEncryptedBackupsRetrieveQplLoggingAnnotations", "MWXMultiStepDialog.react", "PAKECleanupSessionReasonEnum", "PAKEClientTypeEnum", "QPLUserFlow", "cr:6320", "cr:6321", "promiseDone", "react", "requireDeferred", "useLabyrinthLogging", "useMWAbandonRestoreConfirmationDialog", "useMWEBFlowSourceContext", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    e = i;
    var k = e.useCallback,
        l = e.useContext,
        m = e.useEffect,
        n = e.useRef,
        o = c("requireDeferred")("CleanupPakeSession").__setRef("MWEBRestoreDialog.react"),
        p = c("requireDeferred")("mwEBCheckIfEBKeysExistInDisk").__setRef("MWEBRestoreDialog.react");

    function a(a) {
        var e = a.cancellable;
        e = e === void 0 ? !0 : e;
        var f = a.onClose,
            g = a.onDismissUpsell,
            i = n(!1),
            q = (h || (h = c("useReStore")))();
        a = d("useLabyrinthLogging").useLabyrinthLoggingFlow();
        var r = a.startFlow,
            s = c("useMWEBFlowSourceContext")();
        a = l(c("MWChatEncryptedBackupsDismissalDialogContext"));
        var t = a.isDismissedDisabled,
            u = a.setIsDismissedDisabled;
        a = d("MWEBVirtualDevicesContext.react").useMWEBVirtualDevices();
        var v = a.virtualDeviceInfo;
        a = l(c("MWEBHasSeenAutoRestoreNoticeContext"));
        var w = a.hasSeenNotice,
            x = k(function() {
                g == null ? void 0 : g(), v.doesUserHaveOtcEligibleDevices === !0 && o.onReady(function(a) {
                    c("promiseDone")(a({
                        cleanupReason: c("PAKECleanupSessionReasonEnum").FLOW_ABANDONED,
                        clientType: c("PAKEClientTypeEnum").ENCRYPTED_BACKUPS,
                        deviceId: d("MWEncryptedBackupsDeviceRegistrationId").getDeviceRegistrationId(),
                        storage: q
                    }))
                })
            }, [g, v.doesUserHaveOtcEligibleDevices, q]);
        a = k(function() {
            d("MWChatEncryptedBackupsLogging").closeDialogCancelFlow({
                event: d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent,
                onClose: function() {
                    return f()
                }
            }), x()
        }, [f, x]);
        var y = c("useMWAbandonRestoreConfirmationDialog")(a),
            z = k(function() {
                d("MWChatEncryptedBackupsLogging").cancelFlow({
                    cancelEndPoint: "reset_skip",
                    event: d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent
                }), f(), x()
            }, [f, x]),
            A = b("cr:6320") == null ? void 0 : b("cr:6320")(),
            B = b("cr:6321") == null ? void 0 : b("cr:6321")(),
            C = v.vestaClientID != null;
        m(function() {
            i.current || (i.current = !0, d("MWEncryptedBackupsRetrieveQplLoggingAnnotations").encryptedBackupsRetrieveQplLoggingAnnotations({
                db: q,
                onFetch: function(a) {
                    var b = a.ebsmWiped,
                        e = a.firstUpsellTime,
                        f = a.hasEbKeysLocally,
                        g = a.hasEBSM,
                        h = a.hasPDB,
                        i = a.hasUserRestoredBefore;
                    a = a.hasUserRestoredBeforeTemp;
                    var j = s();
                    r({
                        additionalAnnotations: {
                            eb_session_identifier: e,
                            ebsm_wiped: b,
                            has_eb_keys_locally: f,
                            has_ebsm: g,
                            has_pdb: h,
                            has_user_restored_before: i,
                            has_user_restored_before_temp: a,
                            restore_upsell_first_impression_time: e
                        },
                        event: d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent,
                        source: j
                    });
                    j === c("MWChatEncryptedBackupsQPLSource.enum").INBOX_INTERSTITIAL_SOFTBLOCK && (c("InteractionTracing.xplat").getPendingInteractions().forEach(function(a) {
                        a.addAnnotationBoolean("eb_soft_block", !0)
                    }), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "INBOX_SOFTBLOCK_RESTORE_SCREEN"));
                    c("promiseDone")(p.load(), function(a) {
                        return a(f)
                    })
                }
            }))
        }, [s, r, q]);
        return j.jsx(c("MWXMultiStepDialog.react"), {
            onClose: t ? f : y,
            size: "small",
            withCloseButton: e,
            children: function(a) {
                if (v.offlineDevicesCount === -1) return j.jsx(c("MWChatEncryptedBackupsRingIndeterminateIcon.react"), {});
                var b = function(b) {
                    return A != null ? A({
                        onNextStep: b,
                        pushPage: a
                    }) : B != null ? B({
                        hasSeenNotice: w,
                        onNextStep: b,
                        pushPage: a
                    }) : f()
                };
                return j.jsx(c("MAWEncryptedBackupsRestoreStep.react"), {
                    clientID: d("MAWPinCodeGating").isPinCodeEnabled() && C ? v.vestaClientID : null,
                    offlineDevicesCount: v.offlineDevicesCount,
                    onChooseOtc: v.doesUserHaveOtcEligibleDevices ? function() {
                        return d("MWEncryptedBackupsOtcRestoreSteps").pushByOneTimeCodePage({
                            onClose: y,
                            onOtcComplete: function() {
                                b(function() {
                                    u(!0), c("MWEBLazyLoadResetPinPage")(f, a)
                                })
                            },
                            onSkip: z,
                            pushPage: a
                        })
                    } : null,
                    onClose: y,
                    onComplete: function() {
                        b(f)
                    },
                    onForgotPin: function() {
                        d("MWEncryptedBackupsForgotPinStep").pushForgotPinPage({
                            offlineDeviceCount: v.offlineDevicesCount,
                            onClose: f,
                            onComplete: f,
                            pushPage: a
                        })
                    },
                    onForgotRC: function() {
                        d("MWEncryptedBackupsForgotRCStep").pushForgotRCPage({
                            onClose: f,
                            onComplete: f,
                            pushPage: a
                        })
                    },
                    onSkip: z,
                    pushPage: a,
                    shouldShowForgotButton: !0,
                    source: s()
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEBRestoreInterstitialDialogWrapper_query.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "MWEBRestoreInterstitialDialogWrapper_query",
        selections: [{
            args: null,
            kind: "FragmentSpread",
            name: "MAWEncryptedBackupsRestoreDialogContexts_query"
        }],
        type: "Query",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("MWEBRestoreInterstitialDialogWrapper.react", ["CometRelay", "MAWEncryptedBackupsRestoreDialogContexts.react", "MWChatEncryptedBackupsQPLSource.enum", "MWEBRestoreDialog.react", "MWEBRestoreInterstitialDialogWrapper_query.graphql", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react");

    function a(a) {
        var e = a.query,
            f = a.setIsClosed,
            g = a.setIsDialogPersisted;
        a = a.setIsDismissed;
        e = d("CometRelay").useFragment(h !== void 0 ? h : h = b("MWEBRestoreInterstitialDialogWrapper_query.graphql"), e);
        var i = c("MWChatEncryptedBackupsQPLSource.enum").INBOX_INTERSTITIAL_SOFTBLOCK;
        return j.jsx(c("MAWEncryptedBackupsRestoreDialogContexts.react"), {
            query: e,
            setIsDialogPersisted: g,
            source: i,
            children: j.jsx(c("MWEBRestoreDialog.react"), {
                onClose: function() {
                    return f(!0)
                },
                onDismissUpsell: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useMWEBIsUpsellDeferred", ["MWEncryptedBackupsDeferLocalStorageUpsell", "ReQL", "ReQLSuspense", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (i || d("react")).useMemo;

    function a(a) {
        var b = a.upsellType,
            e = (h || (h = c("useReStore")))();
        a = j(function() {
            return d("MWEncryptedBackupsDeferLocalStorageUpsell").getLocalStorageKeys(b)
        }, [b]);
        var g = a.countdownInMS,
            i = a.impressionsCountKey,
            k = a.lastImpressionTimeKey,
            l = a.maxImpressionLimit;
        a = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(e.tables.experiences_shared_state).getKeyRange(k).map(function(a) {
                a = a.stateValue;
                return a != null && +a + g > Date.now() ? !0 : !1
            })
        }, [g, e, k], f.id + ":41");
        var m = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(e.tables.experiences_shared_state).getKeyRange(i).map(function(a) {
                a = a.stateValue;
                return l === d("MWEncryptedBackupsDeferLocalStorageUpsell").INFINITE_IMPRESSIONS_LIMIT || +a < l ? !1 : !0
            })
        }, [e, i, l], f.id + ":56");
        return a === !0 || m === !0
    }
    g["default"] = a
}), 98);
__d("MWEBThreadListPersistentBannerWrapperDeferred.react", ["MWEncryptedBackupsDeferLocalStorageUpsell", "deferredLoadComponent", "react", "requireDeferred", "useMWEBGetUpsellState", "useMWEBIsUpsellDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useState,
        k = c("deferredLoadComponent")(c("requireDeferred")("MWEBThreadListPersistentBannerWrapper.react").__setRef("MWEBThreadListPersistentBannerWrapperDeferred.react"));

    function a(a) {
        var b = a.children;
        a = a.trigger;
        var e = c("useMWEBIsUpsellDeferred")({
            upsellType: d("MWEncryptedBackupsDeferLocalStorageUpsell").MWEncryptedBackupsDeferableUpsellType.PERSISTENT_BANNER_JEWEL
        });
        e = j(e);
        var f = e[0];
        e = e[1];
        var g = c("useMWEBGetUpsellState")();
        g = g.isRestoreUpsellsDismissed;
        return !g && !f ? i.jsx(k, {
            setHasDismissedBanner: e,
            trigger: a
        }) : b
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsQPWithPinPlaceholder.react", ["MWXColumn.react", "MWXGlimmer.react", "MWXRow.react", "MWXRowItem.react", "gkx", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = c("gkx")("23433"),
        l = {
            logoGlimmer: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                height: "xxk0z11",
                width: "xvy4d1p",
                $$css: !0
            },
            pinInputGlimmer: {
                borderTopStartRadius: "xhk9q7s",
                borderTopEndRadius: "x1otrzb0",
                borderBottomEndRadius: "x1i1ezom",
                borderBottomStartRadius: "x1o6z2jb",
                height: "xc9qbxq",
                $$css: !0
            },
            root: {
                backgroundColor: "xlhe6ec",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxShadow: "xjf5wm9",
                boxSizing: "x9f619",
                minWidth: "xeuugli",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "x1iorvi4",
                paddingEnd: "x150jy0e",
                paddingBottom: "xjkvuk6",
                paddingStart: "x1e558r4",
                $$css: !0
            },
            rootComet: {
                marginTop: "xw7yly9",
                marginEnd: "xktsk01",
                marginBottom: "x1yztbdb",
                marginStart: "x1d52u69",
                paddingBottom: "x1l90r2v",
                paddingTop: "xyamay9",
                $$css: !0
            },
            rootMessenger: {
                marginTop: "xw7yly9",
                marginEnd: "xktsk01",
                marginBottom: "x1yztbdb",
                marginStart: "x1d52u69",
                minHeight: "x2lwn1j",
                paddingBottom: "xsag5q8",
                paddingTop: "xz9dl7a",
                $$css: !0
            },
            textGlimmer: {
                borderTopStartRadius: "xhk9q7s",
                borderTopEndRadius: "x1otrzb0",
                borderBottomEndRadius: "x1i1ezom",
                borderBottomStartRadius: "x1o6z2jb",
                height: "x1qx5ct2",
                $$css: !0
            }
        };

    function a() {
        return j.jsx("div", {
            className: (h || (h = c("stylex")))([l.root, k ? l.rootMessenger : l.rootComet]),
            children: j.jsxs(c("MWXColumn.react"), {
                spacing: 8,
                style: l.root,
                children: [j.jsxs(c("MWXRow.react"), {
                    spacingVertical: 0,
                    verticalAlign: "center",
                    children: [j.jsx(c("MWXRowItem.react"), {
                        verticalAlign: "center",
                        children: j.jsx(c("MWXGlimmer.react"), {
                            index: 0,
                            xstyle: l.logoGlimmer
                        })
                    }), j.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        children: j.jsx(c("MWXGlimmer.react"), {
                            index: 0,
                            xstyle: l.textGlimmer
                        })
                    })]
                }), j.jsx(c("MWXRow.react"), {
                    wrap: "none",
                    children: j.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        children: j.jsx("div", {
                            className: "x1kvlpi xwib8y2",
                            children: j.jsx(c("MWXGlimmer.react"), {
                                index: 0,
                                xstyle: l.textGlimmer
                            })
                        })
                    })
                }), j.jsx(c("MWXRow.react"), {
                    direction: "forward",
                    wrap: "none",
                    children: j.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        children: j.jsx(c("MWXGlimmer.react"), {
                            index: 1,
                            xstyle: l.pinInputGlimmer
                        })
                    })
                }), j.jsx(c("MWXRow.react"), {
                    wrap: "none",
                    children: j.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        children: j.jsx("div", {
                            className: "x14n70j1 x7i73kt x1y1aw1k",
                            children: j.jsx(c("MWXGlimmer.react"), {
                                index: 0,
                                xstyle: l.textGlimmer
                            })
                        })
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsThreadListRestoreQPWrapperDeferred_query.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [{
            defaultValue: null,
            kind: "LocalArgument",
            name: "qpWithPinEnabled"
        }],
        kind: "Fragment",
        metadata: null,
        name: "MWEncryptedBackupsThreadListRestoreQPWrapperDeferred_query",
        selections: [{
            kind: "Defer",
            selections: [{
                args: [{
                    kind: "Variable",
                    name: "qpWithPinEnabled",
                    variableName: "qpWithPinEnabled"
                }],
                kind: "FragmentSpread",
                name: "MWEncryptedBackupsThreadListRestoreQPWrapper_query"
            }]
        }],
        type: "Query",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useMWEncryptedBackupsIsUpsellDismissed", ["react", "useMWEBIsUpsellDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useState;

    function a(a) {
        a = a.upsellType;
        var b = i(!1),
            d = b[0];
        b = b[1];
        a = c("useMWEBIsUpsellDeferred")({
            upsellType: a
        });
        return [a === !0 || d, b]
    }
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsThreadListRestoreQPWrapperDeferred.react", ["CometPlaceholder.react", "CometRelay", "EncryptedBackupsSupportedPlatformUtils", "MWEncryptedBackupsDeferLocalStorageUpsell", "MWEncryptedBackupsThreadListRestoreQPWrapperDeferred_query.graphql", "cr:2874", "deferredLoadComponent", "gkx", "react", "requireDeferred", "useHasRestoreInterstitialSoftblockBeenDismissed", "useMWEBGetUpsellState", "useMWEncryptedBackupsIsUpsellDismissed"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = c("deferredLoadComponent")(c("requireDeferred")("MWEncryptedBackupsThreadListRestoreQPWrapper.react").__setRef("MWEncryptedBackupsThreadListRestoreQPWrapperDeferred.react")),
        l = c("gkx")("3952");

    function a(a) {
        var e = a.children,
            f = a.fragmentKey;
        a = a.trigger;
        f = d("CometRelay").useFragment(h !== void 0 ? h : h = b("MWEncryptedBackupsThreadListRestoreQPWrapperDeferred_query.graphql"), f);
        var g = c("useMWEBGetUpsellState")();
        g = g.isRestoreUpsellsDismissed;
        var i = c("useMWEncryptedBackupsIsUpsellDismissed")({
                upsellType: d("MWEncryptedBackupsDeferLocalStorageUpsell").MWEncryptedBackupsDeferableUpsellType.QP_JEWEL
            }),
            m = i[0];
        i = i[1];
        var n = c("useMWEncryptedBackupsIsUpsellDismissed")({
                upsellType: d("MWEncryptedBackupsDeferLocalStorageUpsell").MWEncryptedBackupsDeferableUpsellType.QP_WITH_PIN_JEWEL
            }),
            o = n[0];
        n = n[1];
        var p = c("useMWEncryptedBackupsIsUpsellDismissed")({
                upsellType: d("MWEncryptedBackupsDeferLocalStorageUpsell").MWEncryptedBackupsDeferableUpsellType.PERSISTENT_BANNER_JEWEL
            }),
            q = p[0];
        p = p[1];
        var r = c("useHasRestoreInterstitialSoftblockBeenDismissed")({
                backupState: 4
            }),
            s = d("EncryptedBackupsSupportedPlatformUtils").useMWEncryptedBackupsGetCurrentSupportedPlatform();
        m = m || o;
        if (g || m && !l || m && l && q) return e;
        o = j.jsx(c("CometPlaceholder.react"), {
            fallback: j.jsx(b("cr:2874"), {}),
            name: "MWEncryptedBackupsThreadListRestoreQPWrapperDeferred",
            children: j.jsx(k, {
                children: e,
                currentSupportedPlatform: s,
                fragmentKey: f,
                hasDismissedQps: m,
                setHasDismissedBanner: p,
                setHasDismissedQp: i,
                setHasDismissedQpWithPin: n,
                trigger: a
            })
        });
        switch (s) {
            case d("EncryptedBackupsSupportedPlatformUtils").EncryptedBackupsSupportedPlatform.INSTAGRAM_DIRECT_INBOX:
                return e;
            case d("EncryptedBackupsSupportedPlatformUtils").EncryptedBackupsSupportedPlatform.MESSENGER_DOT_COM:
            case d("EncryptedBackupsSupportedPlatformUtils").EncryptedBackupsSupportedPlatform.FACEBOOK_INBOX:
                return r ? o : e;
            case d("EncryptedBackupsSupportedPlatformUtils").EncryptedBackupsSupportedPlatform.FACEBOOK_DOT_COM:
                return o
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MessengerExclamationMarkCircleOutline.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M16.594 13.497a1.41 1.41 0 1 1 2.812 0l-.344 5.505a1.064 1.064 0 0 1-2.124 0l-.344-5.505zM19.25 22.75a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0z"
            }), i.jsx(d("XPlatReactSVG").Path, {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M29 18c0 6.075-4.925 11-11 11S7 24.075 7 18 11.925 7 18 7s11 4.925 11 11zm-2.5 0a8.5 8.5 0 1 1-17 0 8.5 8.5 0 0 1 17 0z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("MessengerMobileFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M15.75 24.5a.75.75 0 0 0 0 1.5h4.5a.75.75 0 0 0 0-1.5h-4.5z"
            }), i.jsx(d("XPlatReactSVG").Path, {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M10.5 9.5a3 3 0 0 1 3-3h9a3 3 0 0 1 3 3v17a3 3 0 0 1-3 3h-9a3 3 0 0 1-3-3v-17zm3-.5h9a.5.5 0 0 1 .5.5v17a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5v-17a.5.5 0 0 1 .5-.5z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("MessengerTabletFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M14.75 22.5a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5z"
            }), i.jsx(d("XPlatReactSVG").Path, {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M6.5 11.5a3 3 0 0 1 3-3h17a3 3 0 0 1 3 3v13a3 3 0 0 1-3 3h-17a3 3 0 0 1-3-3v-13zm3-.5h17a.5.5 0 0 1 .5.5v13a.5.5 0 0 1-.5.5h-17a.5.5 0 0 1-.5-.5v-13a.5.5 0 0 1 .5-.5z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("MessengerThreadlistFooterDesktopAppLinkV2.react", ["ix", "Actor", "CometPlaceholder.react", "CurrentEnvironment", "MWFacebookUserWithoutMessengerAccess", "MWXIcon.react", "MWXPressable.react", "MWXRow.react", "MWXRowItem.react", "MWXText.react", "MessengerDesktopDeepLinkUtils", "MessengerMSplitFlag", "fbicon", "gkx", "react", "uuidv4"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useRef,
        l = {
            root: {
                boxShadow: "xknmibj",
                flexGrow: "x1c4vz4f",
                minHeight: "xt55aet",
                paddingTop: "xexx8yu",
                paddingEnd: "xc73u3c",
                paddingBottom: "x18d9i69",
                paddingStart: "x5ib6vp",
                ":hover_textDecoration": "x1lku1pv",
                $$css: !0
            },
            rootResponsive: {
                "@media (max-width: 900px)_display": "xzd29fr",
                $$css: !0
            }
        };

    function m() {
        var a = k(c("uuidv4")()).current,
            b = d("Actor").useActor();
        b = b[0];
        var e = d("MessengerDesktopDeepLinkUtils").useMessengerDesktopPromoEventLogger(a, "MessengerThreadlistFooterDesktopAppLink"),
            f = c("CurrentEnvironment").facebookdotcom ? "FB" : "MSGR";
        a = d("MessengerDesktopDeepLinkUtils").getDeeplinkButtonURI({
            funnel_session_id: a,
            id: b,
            origin: f,
            thread: void 0
        });
        b = d("MessengerDesktopDeepLinkUtils").getDeeplinkButtonLabel();
        f = d("MWFacebookUserWithoutMessengerAccess").useIsFacebookUserWithoutMessengerAccess();
        return !d("MessengerDesktopDeepLinkUtils").isMessengerDesktopDeeplinkEligible() && !d("MessengerDesktopDeepLinkUtils").isMessengerDesktopPromoEligible() || f || c("MessengerMSplitFlag").is_msplit_account ? null : j.jsx(c("MWXRow.react"), {
            expanding: !0,
            paddingHorizontal: 8,
            paddingVertical: 8,
            spacing: 0,
            testid: void 0,
            verticalAlign: "center",
            xstyle: [l.root, c("gkx")("24056") === !1 && l.rootResponsive],
            children: j.jsx(c("MWXRowItem.react"), {
                expanding: !0,
                children: j.jsx(c("MWXPressable.react"), {
                    "aria-label": b,
                    expanding: !0,
                    linkProps: {
                        target: "_blank",
                        url: a
                    },
                    onPress: e,
                    overlayOffset: 10,
                    overlayRadius: "normal",
                    children: j.jsxs("div", {
                        className: "x6s0dn4 x78zum5 xl56j7k",
                        children: [j.jsx("span", {
                            className: "x1w0mnb",
                            children: j.jsx(c("MWXIcon.react"), {
                                color: "primary",
                                icon: d("fbicon")._(h("520490"), 16)
                            })
                        }), j.jsx(c("MWXText.react"), {
                            align: "center",
                            type: "bodyLink3",
                            children: b.toString()
                        })]
                    })
                })
            })
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";

    function a() {
        return j.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            name: "MessengerThreadlistFooterDesktopAppLinkV2",
            children: j.jsx(m, {})
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useMWChatEncryptedBackupsAutoRestoreConsentStep", ["MWChatEncryptedBackupsAutoRestoreConsentStepDeferred.react", "MWChatEncryptedBackupsDismissalDialogContext", "MWChatEncryptedBackupsQPLEvents", "react", "useLabyrinthLogging", "useMWEBFlowSourceContext"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useContext;

    function a() {
        var a = k(c("MWChatEncryptedBackupsDismissalDialogContext")).setIsDismissedDisabled,
            b = c("useMWEBFlowSourceContext")(),
            e = d("useLabyrinthLogging").useLabyrinthLoggingFlow(),
            f = e.startFlow;
        return j(function(e) {
            var g = e.onNextStep;
            e = e.pushPage;
            a(!0);
            f({
                event: d("MWChatEncryptedBackupsQPLEvents").restoreWithAutoRestoreConsentQplEvent,
                source: b()
            });
            e(function() {
                return i.jsx(c("MWChatEncryptedBackupsAutoRestoreConsentStepDeferred.react"), {
                    onComplete: g
                })
            }, {
                withoutBackButton: !0,
                withoutCloseButton: !0
            })
        }, [b, a, f])
    }
    g["default"] = a
}), 98);
__d("useMWEBAutoRestoreNoticeStep", ["MWChatEncryptedBackupsDismissalDialogContext", "MWChatEncryptedBackupsLogging", "MWChatEncryptedBackupsQPLEvents", "MWEBUseLocalStorage", "MWEncryptedBackupsLocalStorageEntryEnum", "QPLUserFlow", "ReQL", "ReQLSuspense", "deferredLoadComponent", "react", "requireDeferred", "useLabyrinthLogging", "useMWEBFlowSourceContext", "useMWEBSetHasSeenNotice", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;
    b = j || d("react");
    var k = h || (h = c("react")),
        l = b.useCallback,
        m = b.useContext,
        n = c("deferredLoadComponent")(c("requireDeferred")("MWEBAutoRestoreNoticeDialogStep.react").__setRef("useMWEBAutoRestoreNoticeStep"));

    function a() {
        var a = d("useLabyrinthLogging").useLabyrinthLoggingFlow(),
            b = a.startFlow;
        a = m(c("MWChatEncryptedBackupsDismissalDialogContext"));
        var e = a.setIsDismissedDisabled,
            g = c("useMWEBFlowSourceContext")(),
            h = (i || (i = c("useReStore")))(),
            j = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(h.tables.auto_restore_opt_out)
            }, [h], f.id + ":55"),
            o = c("useMWEBSetHasSeenNotice")();
        return l(function(a) {
            var f = a.hasSeenNotice,
                h = a.onNextStep,
                i = a.pushPage;
            a = j.filter(function(a) {
                return a.optOutKey === c("MWEncryptedBackupsLocalStorageEntryEnum").MW_EB_HAS_OPTED_OUT_OF_AUTO_RESTORE
            }).length > 0;
            var l = function() {
                d("MWChatEncryptedBackupsLogging").endSuccess({
                    event: d("MWChatEncryptedBackupsQPLEvents").restoreWithAutoRestoreConsentQplEvent
                }), h()
            };
            b({
                event: d("MWChatEncryptedBackupsQPLEvents").restoreWithAutoRestoreConsentQplEvent,
                source: g()
            });
            if (a) {
                c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreWithAutoRestoreConsentQplEvent, "AUTO_RESTORE_NOTICE_SCREEN_OPTED_OUT");
                l();
                return
            }
            c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreWithAutoRestoreConsentQplEvent, "AUTO_RESTORE_NOTICE_SCREEN_OPTED_IN");
            d("MWEBUseLocalStorage").mwEBCreateLocalStorageEntry(c("MWEncryptedBackupsLocalStorageEntryEnum").ENCRYPTED_BACKUPS_REMEMBER_BROWSER_CONSENT);
            if (f) {
                l();
                return
            }
            e(!0);
            o();
            i(function() {
                return k.jsx(n, {
                    onComplete: l,
                    pushPage: i
                })
            }, {
                withoutBackButton: !0,
                withoutCloseButton: !0
            })
        }, [j, g, o, e, b])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("MWChatColors", [], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        action: {
            alignContent: "xc26acl",
            alignItems: "x6s0dn4",
            borderTopStartRadius: "x14yjl9h",
            borderTopEndRadius: "xudhj91",
            borderBottomEndRadius: "x18nykt9",
            borderBottomStartRadius: "xww2gxu",
            cursor: "x1ypdohk",
            display: "x78zum5",
            flexShrink: "x2lah0s",
            height: "xxk0z11",
            justifyContent: "xl56j7k",
            marginEnd: "x11i5rnm",
            marginStart: "x1mh8g0r",
            position: "x1n2onr6",
            textAlign: "x2b8uid",
            width: "xvy4d1p",
            ":hover_backgroundColor": "x15vn3sj",
            $$css: !0
        },
        icon: {
            height: "x17rw0jw",
            opacity: "x197sbye",
            width: "x17z2i9w",
            ":active_opacity": "x4gyw5p",
            ":hover_opacity": "x1o7uuvo",
            $$css: !0
        },
        svgFill: {
            fill: "x148u3ch",
            $$css: !0
        },
        svgStroke: {
            fill: "xbh8q5q",
            stroke: "xmb71p3",
            $$css: !0
        }
    };
    b = {
        styles: a
    };
    g.MessageActions = b
}), 98);
__d("MWMessageReactionIcon.react", ["fbt", "MWChatColors", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || d("react");

    function a(a) {
        var b = a.size;
        b = b === void 0 ? 16 : b;
        a = a.viewBox;
        a = a === void 0 ? "0 0 16 16" : a;
        return k.jsxs("svg", {
            fill: "none",
            height: b,
            viewBox: a,
            width: b,
            xmlns: "http://www.w3.org/2000/svg",
            children: [k.jsx("title", {
                children: h._("__JHASH__Wo2O5nlXhKT__JHASH__")
            }), k.jsx("path", {
                className: (i || (i = c("stylex")))(d("MWChatColors").MessageActions.styles.svgFill),
                d: "M12.48 0.64C12.48 0.286538 12.7665 0 13.12 0C13.4735 0 13.76 0.286538 13.76 0.64V2.08C13.76 2.16837 13.8316 2.24 13.92 2.24H15.36C15.7135 2.24 16 2.52654 16 2.88C16 3.23346 15.7135 3.52 15.36 3.52H13.92C13.8316 3.52 13.76 3.59163 13.76 3.68V5.12C13.76 5.47346 13.4735 5.76 13.12 5.76C12.7665 5.76 12.48 5.47346 12.48 5.12V3.68C12.48 3.59163 12.4084 3.52 12.32 3.52H10.88C10.5265 3.52 10.24 3.23346 10.24 2.88C10.24 2.52654 10.5265 2.24 10.88 2.24H12.32C12.4084 2.24 12.48 2.16837 12.48 2.08V0.64Z"
            }), k.jsx("path", {
                className: i(d("MWChatColors").MessageActions.styles.svgFill),
                clipRule: "evenodd",
                d: "M8.96 2.42705C8.96 2.28386 8.86505 2.15735 8.726 2.12317C8.18582 1.99041 7.62113 1.92 7.04 1.92C3.15192 1.92 0 5.07192 0 8.96C0 12.8481 3.15192 16 7.04 16C10.9281 16 14.08 12.8481 14.08 8.96C14.08 8.37887 14.0096 7.81418 13.8768 7.274C13.8427 7.13495 13.7161 7.04 13.573 7.04H13.12C12.0596 7.04 11.2 6.18039 11.2 5.12C11.2 4.94327 11.0567 4.8 10.88 4.8C9.81961 4.8 8.96 3.94039 8.96 2.88V2.42705ZM4.63999 6.4C4.03999 6.4 3.67999 6.88 3.67999 7.68C3.67999 8.48 4.03999 8.96 4.63999 8.96C5.23999 8.96 5.59999 8.48 5.59999 7.68C5.59999 6.88 5.23999 6.4 4.63999 6.4ZM9.43999 6.4C8.83999 6.4 8.47999 6.88 8.47999 7.68C8.47999 8.48 8.83999 8.96 9.43999 8.96C10.04 8.96 10.4 8.48 10.4 7.68C10.4 6.88 10.04 6.4 9.43999 6.4ZM10.56 11.2C10.56 12.48 8.96 13.76 7.04 13.76C5.12 13.76 3.52 12.48 3.52 11.2C3.52 11.0233 3.66327 10.88 3.84 10.88H10.24C10.4167 10.88 10.56 11.0233 10.56 11.2Z",
                fillRule: "evenodd"
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWAddReactionButton.react", ["fbt", "I64", "LSMessagingThreadTypeUtil", "MWCMThreadTypes.react", "MWChatMessageId", "MWChatReactionsActionContainer.react", "MWMessageReactionIcon.react", "MWXPressable.react", "MWXTooltip.react", "ODS", "emptyFunction", "react", "useIsReactionsV2Enabled"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = i || (i = d("react"));
    e = i;
    var m = e.useCallback,
        n = e.useMemo,
        o = {
            emojiRowContainer: {
                borderTopStartRadius: "xdxvlk3",
                borderTopEndRadius: "x1fglp",
                borderBottomEndRadius: "x1rp6h8o",
                borderBottomStartRadius: "xg6i1s1",
                marginBottom: "x12nagc",
                marginEnd: "xw3qccf",
                $$css: !0
            }
        },
        p = l.forwardRef(a);

    function a(a, b) {
        var e = a.onHoverInPrerenderer,
            f = a.onHoverOutPrerenderer,
            g = a.onPressInPrerenderer,
            i = a.showPopover;
        a = h._("__JHASH__czR8vxcW0mN__JHASH__");
        var k = m(function() {
            i(), (j || (j = d("ODS"))).bumpEntityKey(3185, "mwchat_actions", "reaction")
        }, [i]);
        return l.jsx(c("MWXTooltip.react"), {
            align: "middle",
            position: "above",
            tooltip: a,
            children: l.jsx(c("MWXPressable.react"), {
                "aria-label": a,
                expanding: !0,
                loggingEvent: "click_react_to_message",
                onHoverIn: e,
                onHoverOut: f,
                onPress: k,
                onPressIn: g,
                overlayRadius: "inherit",
                ref: b,
                role: "button",
                testid: void 0,
                xstyle: o.emojiRowContainer,
                children: l.jsx("div", {
                    className: "x6s0dn4 xnmxlks xdxvlk3 x1fglp x1rp6h8o xg6i1s1 x78zum5 xl56j7k x10b6aqq xsyo7zv xurb0ha x1yrsyyn x1n2onr6 xp4054r",
                    role: "none",
                    children: l.jsx("div", {
                        className: "x6s0dn4 x14yjl9h xudhj91 x18nykt9 xww2gxu x1ypdohk x14ju556 x11i5rnm x78zum5 xdt5ytf xl56j7k x1npj6m0",
                        children: l.jsx(c("MWMessageReactionIcon.react"), {
                            size: "1.125rem"
                        })
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = a.isSecure,
            e = a.message,
            f = a.sendReaction,
            g = a.setShouldRowStayExpanded,
            h = a.threadKey;
        a = a.threadType;
        var i = (k || (k = d("I64"))).to_string(h),
            j = k.to_string(e.timestampMs),
            m = n(function() {
                return d("MWChatMessageId").makeSent(i, e.messageId, j)
            }, [i, e.messageId, j]),
            o = d("MWCMThreadTypes.react").isBroadcastThread(a);
        a = d("LSMessagingThreadTypeUtil").isDiscoverablePublicBroadcastChannel(a);
        h = d("useIsReactionsV2Enabled").useIsReactionsV2Enabled(h);
        return l.jsx(c("MWChatReactionsActionContainer.react"), {
            alwaysShowEmojiPicker: !0,
            closeActionsMenu: c("emptyFunction"),
            disableCustomReactions: h && o,
            hasReactionsV2: h,
            isBroadcastChannel: a,
            isBroadcastThread: o,
            isSecure: b,
            messageID: m,
            onVisibilityChange: g,
            sendReaction: f,
            children: function(a, b, c, d, e, f) {
                return l.jsx(p, {
                    messageID: m,
                    onHoverInPrerenderer: d,
                    onHoverOutPrerenderer: e,
                    onPressInPrerenderer: f,
                    ref: a,
                    showPopover: b
                })
            }
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g["default"] = b
}), 226);
__d("MWChatMultiReactionsTooltip.react", ["fbt", "I64", "Int64Hooks", "LSClearReactionsV2DetailsAndRangeStoredProcedure", "LSFactory", "LSIssueReactionsV2DetailsUsersListFetchStoredProcedure", "LSPlatformWaitForTaskCompletion", "MWPActor.react", "MWXPressable.react", "MWXText.react", "ReQL", "ReQLSuspense", "intlSummarizeNumber", "promiseDone", "react", "usePrevious", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = k || (k = d("react"));
    b = k;
    var m = b.useEffect,
        n = b.useRef,
        o = b.useState,
        p = 9;

    function a(a) {
        var b = a.isProcessingReactions,
            e = a.messageId,
            g = a.onTooltipCTAPress,
            k = a.reactionFbid,
            q = a.threadKey,
            r = (i || (i = c("useReStore")))();
        a = o(!0);
        var s = a[0],
            t = a[1];
        d("Int64Hooks").useEffectInt64(function() {
            b || (t(!0), c("promiseDone")(c("LSPlatformWaitForTaskCompletion")(r, function(a) {
                return c("LSIssueReactionsV2DetailsUsersListFetchStoredProcedure")(c("LSFactory")(a), {
                    messageId: e,
                    reactionFbid: k,
                    threadId: q
                })
            }, "issueReactionsV2DetailsUsersListFetch").then(function() {
                t(!1)
            })))
        }, [r, q, e, k, t, b]);
        var u = d("MWPActor.react").useActor();
        a = d("ReQLSuspense").useArray(function() {
            return d("ReQL").fromTableAscending(r.tables.reactions_v2_details).getKeyRange(q, e).filter(function(a) {
                return (j || (j = d("I64"))).equal(a.reactionFbid, k)
            })
        }, [r, q, e, k], f.id + ":84");
        var v = new Map();
        a.forEach(function(a) {
            return v.set((j || (j = d("I64"))).to_string(a.reactorId), a.fullName)
        });
        var w = d("ReQLSuspense").useFirst(function() {
                return d("ReQL").fromTableAscending(r.tables.threads).getKeyRange(q).map(function(a) {
                    var b = a.parentThreadKey;
                    return d("ReQLSuspense").toArray(d("ReQL").fromTableAscending(r.tables.contextual_profile_v1).filter(function(a) {
                        return (j || (j = d("I64"))).equal(a.associatedEntityId, b)
                    }), f.id + ":102")
                })
            }, [r, q], f.id + ":97"),
            x = null;
        w != null && w.forEach(function(a) {
            var b = (j || (j = d("I64"))).to_string(a.ownerId),
                c = a.profileName;
            if (c == null) return;
            v.has(b) && v.set(b, c);
            (j || (j = d("I64"))).equal(a.ownerId, u) && (x = c)
        });
        var y = a.map(function(a) {
            return v.get((j || (j = d("I64"))).to_string(a.reactorId))
        }).filter(Boolean);
        w = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(r.tables.reactions_v2).getKeyRange(q, e, k)
        }, [r, q, e, k], f.id + ":131");
        a = (a = w == null ? void 0 : w.viewerIsReactor) != null ? a : !1;
        var z = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(r.tables.contacts).getKeyRange(u).map(function(a) {
                return a.name
            })
        }, [r, u], f.id + ":143");
        z = x != null ? x : z;
        var A = w != null ? (j || (j = d("I64"))).to_int32(w.count) : 0;
        A === 1 && a && y.length === 0 && z != null ? y.push(z) : a && y[0] != null && z != null && ((w = y[0]) == null ? void 0 : w.toString()) !== z && y.unshift(z);
        var B = h._("__JHASH__GTBXwO8BaZr__JHASH__");
        a = function() {
            var a = [].concat(y.slice(0, p)),
                d = !1;
            if (y.length > p) {
                var e = A - p;
                if (e < 0) return [B, !0];
                a.push(h._("__JHASH__KVtJcih6CQz__JHASH__", [h._plural(e), h._param("count", String(c("intlSummarizeNumber")(e)))]).toString())
            } else d = (!s || !b) && y.length !== A;
            return a.length === 0 ? [B, d] : [a.map(function(a, b) {
                return l.jsx("div", {
                    children: a
                }, String(b))
            }), d]
        }();
        w = a[0];
        var C = a[1],
            D = c("usePrevious")(C),
            E = n(null);
        m(function() {
            return function() {
                E.current != null && window.clearTimeout(E.current)
            }
        }, []);
        m(function() {
            if (D === C) return;
            if (!C) E.current != null && (window.clearTimeout(E.current), E.current = null);
            else {
                if (E.current != null) return;
                E.current = window.setTimeout(function() {
                    E.current = null, c("promiseDone")(r.runInTransaction(function(a) {
                        return c("LSClearReactionsV2DetailsAndRangeStoredProcedure")(c("LSFactory")(a))
                    }, "readwrite", void 0, void 0, f.id + ":241")), c("promiseDone")(r.runInTransaction(function(a) {
                        return c("LSIssueReactionsV2DetailsUsersListFetchStoredProcedure")(c("LSFactory")(a), {
                            messageId: e,
                            threadId: q
                        })
                    }, "readwrite", void 0, void 0, f.id + ":249"))
                }, 700)
            }
        }, [r, C, D, e, k, q]);
        return l.jsx(c("MWXPressable.react"), {
            "aria-label": h._("__JHASH__g_e4jdcSB-i__JHASH__"),
            onPress: g,
            overlayDisabled: !0,
            children: l.jsx(c("MWXText.react"), {
                color: "tooltip",
                type: "body4",
                children: w
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWEncryptedBackupsThreadListQPWrapper.react", ["$InternalEnum", "MWThreadListConsts", "gkx", "qex", "react", "stylex", "useMatchViewport"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = b("$InternalEnum").Mirrored(["JEWEL", "THREAD_LIST", "CHAT_TAB"]),
        l = {
            qpHiddenContent: {
                display: "x1lliihq",
                height: "xqtp20y",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                width: "xnalus7",
                $$css: !0
            },
            root: {
                position: "x1n2onr6",
                zIndex: "x1vjfegm",
                $$css: !0
            }
        };

    function a(a) {
        var b, e = a.children,
            f = a.testid;
        f = a.trigger;
        a = c("gkx")("23433");
        b = (b = c("qex")._("2100")) != null ? b : !1;
        b = b && (a || f === k.JEWEL);
        a = c("useMatchViewport")("min", "width", d("MWThreadListConsts").minimumPixelsNeededForMaxDisplay);
        f = !c("gkx")("24056");
        return j.jsx("div", {
            className: (h || (h = c("stylex")))([l.root, !a && !b && f && l.qpHiddenContent]),
            "data-testid": void 0,
            children: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.MWEncryptedBackupsQPTrigger = k;
    g.MWEncryptedBackupsThreadListQPWrapper = a
}), 98);
__d("MWExpandReactionsButton.react", ["fbt", "I64", "MWCMThreadTypes.react", "MWChatMessageId", "MWChatReactionsActionContainer.react", "MWMultiReactConstants", "MWXPressable.react", "MWXTooltip.react", "emptyFunction", "intlSummarizeNumber", "react", "stylex", "useIsReactionsV2Enabled"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = j || (j = d("react"));
    b = j;
    var m = b.useCallback,
        n = b.useMemo,
        o = {
            additionalInlineButton: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                height: "xlup9mm",
                justifyContent: "xl56j7k",
                width: "x1npj6m0",
                $$css: !0
            },
            emoji: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                cursor: "x1ypdohk",
                lineHeight: "x14ju556",
                marginEnd: "x11i5rnm",
                $$css: !0
            },
            emojiNum: {
                paddingStart: "x1k2j06m",
                paddingEnd: "x10ogl3i",
                textAlign: "x2b8uid",
                $$css: !0
            },
            emojiRowContainer: {
                borderTopStartRadius: "xdxvlk3",
                borderTopEndRadius: "x1fglp",
                borderBottomEndRadius: "x1rp6h8o",
                borderBottomStartRadius: "xg6i1s1",
                marginBottom: "x12nagc",
                marginEnd: "xw3qccf",
                $$css: !0
            },
            fontStyles: {
                color: "xi81zsa",
                fontSize: "x1nxh6w3",
                fontWeight: "x1s688f",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.isMultiReactExpanded,
            e = a.isReactionReadOnly,
            f = a.isSecure,
            g = a.message,
            j = a.numOverflowEmojis,
            p = a.sendReaction,
            q = a.setIsReactionsRowAnimationInProgress,
            r = a.threadKey,
            s = a.threadType,
            t = a.toggleMultiReactExpanded,
            u = (k || (k = d("I64"))).to_string(r),
            v = k.to_string(g.timestampMs);
        a = n(function() {
            return d("MWChatMessageId").makeSent(u, g.messageId, v)
        }, [u, g.messageId, v]);
        s = d("MWCMThreadTypes.react").isBroadcastThread(s);
        r = d("useIsReactionsV2Enabled").useIsReactionsV2Enabled(r);
        var w = m(function() {
            t(), q(!0)
        }, [q, t]);
        return l.jsx(c("MWChatReactionsActionContainer.react"), {
            alwaysShowEmojiPicker: !0,
            closeActionsMenu: c("emptyFunction"),
            disableCustomReactions: r && s,
            hasReactionsV2: r,
            isBroadcastThread: s,
            isSecure: f,
            messageID: a,
            onVisibilityChange: c("emptyFunction"),
            sendReaction: p,
            children: function(a, f, g, k, m) {
                f = h._("__JHASH__S6Ab1Epvc_N__JHASH__");
                var n = c("intlSummarizeNumber")(j),
                    p = "+" + n;
                n = n.length;
                g = l.jsx(c("MWXPressable.react"), {
                    "aria-label": f,
                    disabled: e,
                    expanding: !0,
                    onHoverIn: g,
                    onHoverOut: k,
                    onPress: w,
                    onPressIn: m,
                    overlayRadius: "inherit",
                    ref: a,
                    role: "button",
                    testid: void 0,
                    xstyle: o.emojiRowContainer,
                    children: l.jsx("div", {
                        className: "x6s0dn4 x7daf1o xdxvlk3 x1fglp x1rp6h8o xg6i1s1 x78zum5 xl56j7k x10b6aqq xsyo7zv xurb0ha x1yrsyyn x1n2onr6 xp4054r",
                        role: "none",
                        children: l.jsx("div", {
                            className: (i || (i = c("stylex")))([].concat(b ? [o.fontStyles, o.emoji, o.additionalInlineButton] : [o.fontStyles, o.emojiNum])),
                            role: "none",
                            style: {
                                minWidth: n * d("MWMultiReactConstants").SPACING_PER_COUNT_CHARACTER
                            },
                            children: p
                        })
                    })
                });
                return e ? g : l.jsx(c("MWXTooltip.react"), {
                    align: "middle",
                    position: "above",
                    tooltip: f,
                    children: g
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWMessageReaction.react", ["BaseContextualLayer.react", "I64", "MWChatMultiReactionsTooltip.react", "MWChatReactionEmoji", "MWChatReactionsUtils", "MWMultiReactConstants", "MWXPopover.react", "MWXPressable.react", "MWXText.react", "gkx", "intlSummarizeNumber", "react", "stylex", "useCometTheme", "useFadeEffect"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = i || (i = d("react"));
    b = i;
    var l = b.useEffect,
        m = b.useRef,
        n = b.useState,
        o = {
            "--card-background": "rgba(0,0,0,0)"
        },
        p = {
            animatedEmoji: {
                animationDuration: "xdz8niu",
                animationIterationCount: "x1v7wizp",
                animationName: "x4uz0a7",
                animationTimingFunction: "xjmqbfh",
                opacity: "x1hc1fzr",
                transform: "xds7yc5",
                transformOrigin: "x1jpgh95",
                $$css: !0
            },
            emoji: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                lineHeight: "x14ju556",
                marginEnd: "x11i5rnm",
                $$css: !0
            },
            emojiEnabled: {
                cursor: "x1ypdohk",
                $$css: !0
            },
            emojiNum: {
                color: "xi81zsa",
                fontSize: "x1nxh6w3",
                fontWeight: "x1s688f",
                paddingStart: "x1k2j06m",
                paddingEnd: "x10ogl3i",
                textAlign: "x2b8uid",
                $$css: !0
            },
            emojiRow: {
                alignItems: "x6s0dn4",
                backgroundColor: "xnmxlks",
                borderTopStartRadius: "xdxvlk3",
                borderTopEndRadius: "x1fglp",
                borderBottomEndRadius: "x1rp6h8o",
                borderBottomStartRadius: "xg6i1s1",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                paddingBottom: "x10b6aqq",
                paddingEnd: "xsyo7zv",
                paddingStart: "xurb0ha",
                paddingTop: "x1yrsyyn",
                position: "x1n2onr6",
                textAlign: "xp4054r",
                $$css: !0
            },
            emojiRowContainer: {
                borderTopStartRadius: "xdxvlk3",
                borderTopEndRadius: "x1fglp",
                borderBottomEndRadius: "x1rp6h8o",
                borderBottomStartRadius: "xg6i1s1",
                marginBottom: "x12nagc",
                marginEnd: "xw3qccf",
                $$css: !0
            },
            scaleHeartEmoji: {
                transform: "xhqu4j4",
                $$css: !0
            },
            selectedColor: {
                backgroundColor: "x1y4ma1z",
                $$css: !0
            },
            selectedTextColor: {
                color: "x1f0x4kx",
                $$css: !0
            },
            tooltipContainer: {
                borderTopStartRadius: "x1r9drvm",
                borderTopEndRadius: "x16aqbuh",
                borderBottomEndRadius: "x9rzwcf",
                borderBottomStartRadius: "xjkqk3g",
                display: "x1lliihq",
                marginBottom: "xjpr12u",
                marginTop: "xr9ek0c",
                maxWidth: "x86nfjv",
                opacity: "xg01cxk",
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                position: "x1n2onr6",
                transitionDuration: "x1ebt8du",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1dhq9h",
                $$css: !0
            },
            tooltipContainerVisible: {
                opacity: "x1hc1fzr",
                transitionDuration: "xhb22t3",
                transitionTimingFunction: "xls3em1",
                $$css: !0
            },
            tootltipBackgroundComet: {
                backgroundColor: "xj5tmjb",
                boxShadow: "xms15q0",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.emoji,
            e = a.isProcessingReactions,
            f = a.isReadOnly,
            g = a.isTooltipShown,
            i = a.message,
            q = a.onFocus,
            r = a.onMouseEnter,
            s = a.onMouseLeave,
            t = a.onTooltipCTAPress,
            u = a.queueSendReactionCallback,
            v = a.reaction,
            w = a.sendReaction,
            x = a.shouldAnimate;
        a = a.threadKey;
        var y = c("useCometTheme")("invert"),
            z = y[0];
        y = y[1];
        var A = c("useCometTheme")("light");
        A[0];
        A = A[1];
        var B = d("MWChatReactionsUtils").isHeart(b[0]),
            C = m(null);
        g = c("useFadeEffect")(g);
        var D = g[0],
            E = g[1];
        g = g[2];
        var F = n(v.viewerIsReactor),
            G = F[0],
            H = F[1];
        F = n((j || (j = d("I64"))).to_int32(v.count));
        var I = F[0],
            J = F[1];
        F = n(!1);
        var K = F[0],
            L = F[1],
            M = m(null);
        l(function() {
            M.current != null && window.clearTimeout(M.current)
        }, []);
        l(function() {
            x && (L(!0), M.current != null && window.clearTimeout(M.current), M.current = window.setTimeout(function() {
                M.current = null, L(!1)
            }, 600))
        }, [x]);
        l(function() {
            e || (J((j || (j = d("I64"))).to_int32(v.count)), H(v.viewerIsReactor))
        }, [e, v.count, v.viewerIsReactor]);

        function N() {
            H(!0), J(function(a) {
                return a + 1
            })
        }

        function O() {
            H(!1), J(function(a) {
                return a > 1 ? a - 1 : a
            })
        }
        F = c("intlSummarizeNumber")(I).length;
        return k.jsxs("div", {
            className: (h || (h = c("stylex")))(G ? A : null),
            onFocus: q,
            onMouseEnter: r,
            onMouseLeave: s,
            children: [k.jsx(c("MWXPressable.react"), {
                disabled: f,
                onPress: function() {
                    G ? O() : N();
                    var a = b.join("");
                    I === 1 && G ? w(a, G) : u(a, function() {
                        w(a, G)
                    })
                },
                overlayRadius: "inherit",
                ref: C,
                xstyle: p.emojiRowContainer,
                children: k.jsxs("div", {
                    className: h([p.emojiRow, G && p.selectedColor]),
                    children: [k.jsx("div", {
                        className: h([p.emoji, f ? null : p.emojiEnabled]),
                        children: k.jsx("div", {
                            className: h(x || K ? p.animatedEmoji : !1, B ? p.scaleHeartEmoji : !1),
                            children: k.jsx(c("MWChatReactionEmoji"), {
                                emoji: b,
                                size: 16,
                                testid: void 0
                            })
                        })
                    }), k.jsx("div", {
                        className: h([p.emojiNum, G && p.selectedTextColor]),
                        "data-testid": void 0,
                        role: "none",
                        style: {
                            minWidth: F * d("MWMultiReactConstants").SPACING_PER_COUNT_CHARACTER
                        },
                        children: c("intlSummarizeNumber")(I)
                    })]
                })
            }), !f && D && k.jsx(z, {
                children: k.jsx(c("BaseContextualLayer.react"), {
                    align: "middle",
                    contextRef: C,
                    position: "above",
                    ref: g,
                    children: k.jsx("div", {
                        style: c("gkx")("23219") ? null : o,
                        children: k.jsx(c("MWXPopover.react"), {
                            withArrow: c("gkx")("23219"),
                            children: k.jsx("div", {
                                className: (h || (h = c("stylex")))(y, p.tooltipContainer, c("gkx")("23219") ? null : p.tootltipBackgroundComet, E && p.tooltipContainerVisible),
                                role: "tooltip",
                                children: k.jsx(c("MWXText.react"), {
                                    color: "primary",
                                    type: "body4",
                                    children: k.jsx(c("MWChatMultiReactionsTooltip.react"), {
                                        isProcessingReactions: e,
                                        messageId: i.messageId,
                                        onTooltipCTAPress: function() {
                                            return t(v.reactionFbid, b.join(""))
                                        },
                                        reactionFbid: v.reactionFbid,
                                        threadKey: a
                                    })
                                })
                            })
                        })
                    })
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useEmojiReactionDynamicStyleXTransition", ["differenceSets", "mapMapToArray", "mapSet", "nullthrows", "react", "setImmediate", "sortBy", "useForceUpdate", "useIsMountedRef", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useLayoutEffect,
        l = b.useRef,
        m = {
            animationBase: {
                opacity: "xg01cxk",
                transitionDuration: "xbb3pvg",
                transitionProperty: "xeq7tfg",
                width: "xnalus7",
                $$css: !0
            },
            animationEnter: {
                animationDuration: "xllfotl",
                animationName: "x127lhb5",
                opacity: "x1hc1fzr",
                $$css: !0
            },
            animationEnterWidth1: {
                width: "x1ygkb0v",
                $$css: !0
            },
            animationEnterWidth2: {
                width: "x1247r65",
                $$css: !0
            },
            animationEnterWidth3: {
                width: "xdc2ju1",
                $$css: !0
            },
            animationEnterWidth4: {
                width: "xgbm1jk",
                $$css: !0
            },
            animationEnterWidth5: {
                width: "x1rdo73f",
                $$css: !0
            },
            animationEnterWidth6: {
                width: "x13oubkp",
                $$css: !0
            },
            animationLeave: {
                animationDuration: "x773k2o",
                animationName: "xvma63k",
                opacity: "xg01cxk",
                width: "xnalus7",
                $$css: !0
            }
        };

    function n(a) {
        switch (a) {
            case 1:
                return m.animationEnterWidth1;
            case 2:
                return m.animationEnterWidth2;
            case 3:
                return m.animationEnterWidth3;
            case 4:
                return m.animationEnterWidth4;
            case 5:
                return m.animationEnterWidth5;
            case 6:
                return m.animationEnterWidth6;
            default:
                return null
        }
    }

    function o() {
        var a = l(new Map());

        function b() {
            return a.current
        }
        j(function() {
            return function() {
                return Array.from(b().values()).forEach(window.clearTimeout)
            }
        }, []);
        return b()
    }

    function p() {
        var a = c("useForceUpdate")(),
            b = c("useIsMountedRef")();
        return c("useStable")(function() {
            return function() {
                b.current && a()
            }
        })
    }

    function a(a, b, d, e) {
        var f = p(),
            g = o(),
            h = c("useStable")(function() {
                return new Map()
            }),
            j = l(!0),
            q = d.duration,
            r = q === void 0 ? 100 : q,
            s = d.durationIn,
            t = d.durationOut,
            u = d.onEnter,
            v = d.onEnterComplete,
            w = d.onLeave,
            x = d.onLeaveComplete,
            y = i(function(a, b, c) {
                return {
                    item: b,
                    key: a,
                    order: c,
                    style: {
                        transitionDuration: ((a = s) != null ? a : r) + "ms"
                    },
                    xstyle: [m.animationBase, j.current && m.animationEnter, j.current && n((c = b == null ? void 0 : b.reactionCountCharactersNum) != null ? c : 0)]
                }
            }, [s, r]),
            z = new Map(a.map(function(a, c) {
                return [b(a), {
                    item: a,
                    order: c
                }]
            })),
            A = c("differenceSets")(new Set(z.keys()), new Set(h.keys())),
            B = c("differenceSets")(new Set(h.keys()), new Set(z.keys())),
            C = new Map();
        q = Array.from(c("mapSet")(B, function(a) {
            a = c("nullthrows")(h.get(a));
            a = a.order;
            return a
        })).sort(function(a, b) {
            return a - b
        });
        q.forEach(function(b, c) {
            b = b - c;
            while (b < a.length) {
                c = (c = C.get(b)) != null ? c : 0;
                C.set(b, c + 1);
                b += 1
            }
        });
        d = c("sortBy")([].concat(c("mapMapToArray")(h, function(a) {
            var b = a.key;
            b = z.get(b);
            if (b) {
                return babelHelpers["extends"]({}, a, {
                    item: b.item,
                    order: b.order + ((b = C.get(b.order)) != null ? b : 0)
                })
            }
            return a
        }), Array.from(c("mapSet")(A, function(a) {
            var b = c("nullthrows")(z.get(a)),
                d = b.item;
            b = b.order;
            return y(a, d, b)
        }))), function(a) {
            return a.order
        });
        k(function() {
            if (e === !0) return;
            a.forEach(function(a, d) {
                var e, i = b(a),
                    j = (e = h.get(i)) != null ? e : y(i, a, d);
                A.has(i) && window.requestAnimationFrame(function() {
                    var b;
                    j.xstyle = [m.animationBase, m.animationEnter, n((b = a == null ? void 0 : a.reactionCountCharactersNum) != null ? b : 0)];
                    window.clearTimeout(g.get(i));
                    g.set(i, window.setTimeout(function() {
                        v && v(a)
                    }, (b = s) != null ? b : r));
                    c("setImmediate")(function() {
                        var b;
                        j.xstyle = [m.animationBase, m.animationEnter, n((b = a == null ? void 0 : a.reactionCountCharactersNum) != null ? b : 0)];
                        u && u(a);
                        f()
                    })
                });
                j.item = a;
                j.order = d + ((e = C.get(d)) != null ? e : 0);
                h.set(i, j)
            });
            Array.from(B.values()).forEach(function(a) {
                var b = h.get(a);
                if (b == null) return;
                var d = b.item;
                if (b.status !== "leaving") {
                    var e;
                    b.status = "leaving";
                    b.style = {
                        transitionDuration: ((e = t) != null ? e : r) + "ms"
                    };
                    window.requestAnimationFrame(function() {
                        var e;
                        b.xstyle = [m.animationBase, m.animationLeave];
                        window.clearTimeout(g.get(a));
                        g.set(a, window.setTimeout(function() {
                            h["delete"](a), x && x(d), f()
                        }, (e = t) != null ? e : r));
                        c("setImmediate")(function() {
                            w && w(d), f()
                        })
                    })
                }
            });
            j.current = !1
        });
        return d
    }
    g["default"] = a
}), 98);
__d("useSendReactionCallbackQueue", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useRef,
        j = b.useState,
        k = 1e3,
        l = 1500;

    function a() {
        var a = i(new Map()),
            b = i(null),
            c = j(!1),
            d = c[0],
            e = c[1];
        c = function(c, d) {
            e(!0), window.clearTimeout(b.current), a.current.set(c, d), b.current = window.setTimeout(function() {
                f()
            }, l)
        };
        var f = function c() {
                if (a.current.size > 0) {
                    e(!0);
                    var d = Array.from(a.current.entries())[0],
                        f = d[0];
                    d = d[1];
                    d();
                    a.current["delete"](f);
                    b.current = window.setTimeout(function() {
                        c()
                    }, l)
                } else g()
            },
            g = function() {
                window.setTimeout(function() {
                    b.current = null, e(!1)
                }, k)
            };
        return [c, d]
    }
    g["default"] = a
}), 98);
__d("MWMessageReactionsList.react", ["I64", "LSAuthorityLevel", "LSIntEnum", "MWMessageReaction.react", "MWMultiReactConstants", "intlSummarizeNumber", "react", "stylex", "useEmojiReactionDynamicStyleXTransition", "useSendReactionCallbackQueue"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = i || (i = d("react")),
        m = i.useRef;

    function a(a) {
        var b = a.emojis,
            e = a.hideTooltip,
            f = a.isMultiReactExpanded,
            g = a.isReactionReadOnly,
            i = a.message,
            n = a.onTooltipCTAPress,
            o = a.previousReactionItems,
            p = a.reactionItemsShown,
            q = a.reactionsV2,
            r = a.sendReactionThrottled,
            s = a.setIsReactionsRowAnimationInProgress,
            t = a.setShouldAnimate,
            u = a.shouldAnimate,
            v = a.showTooltip,
            w = a.threadKey,
            x = a.tooltipIndex,
            y = p.length,
            z = m(y);
        a = c("useSendReactionCallbackQueue")();
        var A = a[0],
            B = a[1];
        a = function() {
            z.current = y, s(!1), f && t(!1)
        };
        var C = function() {
                z.current = y, s(!1)
            },
            D = [];
        q != null && (D = p.map(function(a, f) {
            var h = a.emoji;
            a = a.reaction;
            return b[f] == null ? null : {
                element: l.jsx(c("MWMessageReaction.react"), {
                    emoji: h,
                    isProcessingReactions: B,
                    isReadOnly: g,
                    isTooltipShown: x === f,
                    message: i,
                    onFocus: function() {
                        return v(f)
                    },
                    onMouseEnter: function() {
                        return v(f)
                    },
                    onMouseLeave: e,
                    onTooltipCTAPress: n,
                    queueSendReactionCallback: A,
                    reaction: a,
                    sendReaction: r,
                    shouldAnimate: (o == null ? void 0 : o.find(function(a) {
                        return a.emoji.join("") === h.join("")
                    })) == null && (j || (j = d("I64"))).equal(a.authorityLevel, (k || (k = d("LSIntEnum"))).ofNumber(c("LSAuthorityLevel").OPTIMISTIC)),
                    threadKey: w
                }, h),
                key: b.toString() + f,
                reactionCountCharactersNum: c("intlSummarizeNumber")((j || (j = d("I64"))).to_int32(a.count)).length
            }
        }));
        q = c("useEmojiReactionDynamicStyleXTransition")(D, function(a) {
            return a != null ? a.key : 0
        }, {
            duration: d("MWMultiReactConstants").REACTIONS_ROW_EXPAND_COLLAPSE_ANIMATION_TOTAL_DURATION,
            onEnterComplete: a,
            onLeaveComplete: C
        });
        return u ? q.map(function(a) {
            return l.jsx("div", {
                className: (h || (h = c("stylex")))([a == null ? void 0 : a.xstyle]),
                style: babelHelpers["extends"]({}, a.style),
                children: a.item && a.item.element
            }, a.key)
        }) : D.map(function(a) {
            return a == null ? void 0 : a.element
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useGetMultiReactOrderedItems", ["I64", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    b = h || d("react");
    var j = b.useMemo,
        k = b.useRef;

    function l(a, b) {
        var c = {};
        a.forEach(function(a) {
            c[a] = !0
        });
        var d = a;
        b.forEach(function(a) {
            a = a.emoji.join("");
            if (c[a]) return;
            d.push(a)
        });
        return d
    }

    function m(a, b) {
        b = ((b = b) != null ? b : []).filter(function(a) {
            return (i || (i = d("I64"))).gt(a.count, i.zero)
        });
        return b.map(function(b, c) {
            return {
                emoji: a[c],
                reaction: b
            }
        }).filter(function(a) {
            return a.emoji != null
        })
    }

    function a(a, b) {
        var c = k(!0),
            e = k([]),
            f = j(function() {
                return m(a, b)
            }, [a, b]),
            g = j(function() {
                var a = {};
                f.forEach(function(b) {
                    a[b.emoji.join("")] = b
                });
                return a
            }, [f]);
        return j(function() {
            if (c.current) c.current = !1, e.current = f.sort(function(a, b) {
                return (i || (i = d("I64"))).compare(b.reaction.count, a.reaction.count)
            }).map(function(a) {
                return a.emoji.join("")
            });
            else {
                var a = e.current.filter(function(a) {
                    a = g[a];
                    return a == null ? !1 : (i || (i = d("I64"))).to_int32(a.reaction.count) > 0
                });
                e.current = l(a, f)
            }
            return e.current.map(function(a) {
                return g[a]
            }).filter(Boolean)
        }, [g, f])
    }
    g["default"] = a
}), 98);
__d("MWMessageReactionsContainerV2.react", ["LSMessagingThreadTypeUtil", "MAWPSendOrRemoveReaction.react", "MWAddReactionButton.react", "MWExpandReactionsButton.react", "MWLSThread", "MWMessageReactionsList.react", "MWMultiReactConstants", "ReQL", "ReQLSuspense", "emptyFunction", "justknobx", "react", "stylex", "unrecoverableViolation", "useGetMultiReactOrderedItems", "useIsMultiReactionEnabled", "useIsReactionsV2Enabled", "useOnOutsideClick", "usePrevious", "useReStore", "useThrottled"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = j || (j = d("react"));
    b = j;
    var l = b.useCallback,
        m = b.useRef,
        n = b.useState,
        o = {
            wrapper: {
                alignItems: "x1cy8zhl",
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                flexWrap: "x1a02dak",
                marginTop: "x1gslohp",
                $$css: !0
            },
            wrapperOutgoing: {
                alignItems: "xuk3077",
                justifyContent: "x13a6bvl",
                $$css: !0
            }
        };

    function a(a) {
        var b, e = a.emojis,
            g = a.isMultiReactRowExpanded,
            j = a.message,
            p = a.onOpenDialog,
            q = a.outgoing,
            r = a.reactionsV2,
            s = a.toggleMultiReactionRowExpansion;
        a = n(-1);
        var t = a[0],
            u = a[1],
            v = c("justknobx")._("2078");
        a = n({
            isReactionsRowAnimationInProgress: !1,
            shouldAnimate: v
        });
        var w = a[0],
            x = a[1],
            y = function(a) {
                v && x(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        isReactionsRowAnimationInProgress: a
                    })
                })
            },
            z = function(a) {
                v && x(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        shouldAnimate: a
                    })
                })
            };
        a = n(!1);
        var A = a[0],
            B = a[1];
        a = j.threadKey;
        var C = (h || (h = c("useReStore")))(),
            D = d("MWLSThread").useThread(a),
            E = d("ReQLSuspense").useFirst(function() {
                return (D == null ? void 0 : D.parentThreadKey) ? d("ReQL").fromTableAscending(C.tables.community_folders).getKeyRange(D == null ? void 0 : D.parentThreadKey) : d("ReQL").empty()
            }, [C, D == null ? void 0 : D.parentThreadKey], f.id + ":99");
        b = (b = D) != null ? b : {};
        b = b.threadType;
        if (b == null) throw c("unrecoverableViolation")("thread cannot be null when reacting to message", "messenger_web_messaging");
        var F = d("LSMessagingThreadTypeUtil").isArmadilloSecure(b),
            G = d("LSMessagingThreadTypeUtil").isDiscoverableChannel(b),
            H = c("useOnOutsideClick")(g ? function() {
                A || (z(!0), s && s(), y(!0))
            } : null),
            I = d("useIsMultiReactionEnabled").useIsMultiReactEnabled(a),
            J = d("MAWPSendOrRemoveReaction.react").useSendOrRemoveReaction(j, F, "instant_react"),
            K = l(function(a, b) {
                return J(j.messageId, a, b ? "remove_reaction" : "reaction")
            }, [J, j.messageId]),
            L = c("useThrottled")(function(a, b) {
                K(a, b)
            }, 750),
            M = m(null),
            N = l(function(a) {
                if (t === a) return;
                B(!0);
                M.current != null && window.clearTimeout(M.current);
                u(-1);
                M.current = window.setTimeout(function() {
                    u(a)
                }, 1500)
            }, [t]),
            O = l(function() {
                B(!1), M.current != null && window.clearTimeout(M.current), M.current = window.setTimeout(function() {
                    return u(-1)
                }, 300)
            }, []),
            P = l(function(a, b) {
                p({
                    reactionFbid: a,
                    reactionType: b
                }), O()
            }, [O, p]),
            Q = c("useGetMultiReactOrderedItems")(e, r);
        I = I ? G === !0 ? d("MWMultiReactConstants").PUBLIC_CHANNELS_MAX_REACTIONS_EMOJIS_PREVIEWED_WHEN_COLLAPSED : d("MWMultiReactConstants").CM_MAX_REACTION_EMOJIS_ALLOWED : d("MWMultiReactConstants").DEFAULT_MAX_REACTION_PREVIEWED_ALLOWED;
        var R = g ? Q : Q.slice(0, I);
        I = g ? [] : Q.slice(I);
        var S = I.length;
        I = Q.length || 0;
        Q = c("usePrevious")(Q);
        if (I < 1) return null;
        E = D == null ? !1 : d("useIsReactionsV2Enabled").isReactionsV2ReadOnly(D, E == null ? void 0 : E.communityType);
        var T = !q && w.isReactionsRowAnimationInProgress;
        G = !E && I > 0 && (G || I < d("MWMultiReactConstants").CM_MAX_REACTION_EMOJIS_ALLOWED) && !T;
        I = S > 0 && !T;
        return k.jsxs("div", {
            className: (i || (i = c("stylex")))(o.wrapper, q ? o.wrapperOutgoing : !1),
            "data-testid": void 0,
            ref: H,
            children: [k.jsx(c("MWMessageReactionsList.react"), {
                emojis: e,
                hideTooltip: O,
                isMultiReactExpanded: g,
                isReactionReadOnly: E,
                message: j,
                onTooltipCTAPress: P,
                previousReactionItems: Q,
                reactionItemsShown: R,
                reactionsV2: r,
                sendReactionThrottled: L,
                setIsReactionsRowAnimationInProgress: y,
                setShouldAnimate: z,
                shouldAnimate: w.shouldAnimate,
                showTooltip: N,
                threadKey: a,
                tooltipIndex: t
            }), I ? k.jsx(c("MWExpandReactionsButton.react"), {
                isMultiReactExpanded: g,
                isReactionReadOnly: E,
                isSecure: F,
                message: j,
                numOverflowEmojis: (T = S) != null ? T : 0,
                sendReaction: K,
                setIsReactionsRowAnimationInProgress: y,
                threadKey: a,
                threadType: b,
                toggleMultiReactExpanded: (q = s) != null ? q : c("emptyFunction")
            }) : null, G ? k.jsx(c("MWAddReactionButton.react"), {
                isSecure: F,
                message: j,
                sendReaction: function(a, b) {
                    S > 0 && (s == null ? void 0 : s()), window.setTimeout(function() {
                        K(a, b)
                    }, S * 10)
                },
                setShouldRowStayExpanded: B,
                threadKey: a,
                threadType: b
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWPEditMessageHistoryListText.react", ["MWChatTextTransform", "MWUnvaultedText", "MWXMessageTextWithEntities.react", "MWXText.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            incoming: {
                color: "x18lvrbx",
                $$css: !0
            },
            outgoing: {
                color: "xyk4ms5",
                $$css: !0
            },
            regular: {
                marginTop: "x1gslohp",
                marginEnd: "x11i5rnm",
                marginBottom: "x12nagc",
                marginStart: "x1mh8g0r",
                textAlign: "x1yc453h",
                whiteSpace: "x126k92a",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.isSecureMessage,
            e = a.maxLength,
            f = a.maxLines,
            g = a.seeLessLinkProps,
            i = a.seeMoreLinkProps,
            l = a.text,
            m = a.truncationStyle,
            n = a.outgoing,
            o = a.ranges,
            p = a.renderers,
            q = a.transforms;
        a = a.xstyleForText;
        b = d("MWUnvaultedText").useMWUnvaultedText(b, l);
        return j.jsx(c("MWXText.react"), {
            color: n ? "white" : "primary",
            type: "body3",
            children: j.jsx("div", {
                className: (h || (h = c("stylex")))(k.regular, a, n ? k.outgoing : k.incoming),
                dir: "auto",
                children: j.jsx(c("MWXMessageTextWithEntities.react"), {
                    maxLength: e,
                    maxLines: f,
                    ranges: o,
                    renderers: p,
                    seeLessLinkProps: g,
                    seeMoreLinkProps: i,
                    text: b || "",
                    transforms: (l = q) != null ? l : d("MWChatTextTransform").textTransforms,
                    truncationStyle: m,
                    truncationThreshold: 2,
                    withParagraphs: !0
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWPEditedMessageHistoryEntry.react", ["MWPEditMessageHistoryListText.react", "MWXMessageBubble.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useState,
        l = {
            border: {
                boxShadow: "x7h7r2v",
                $$css: !0
            },
            inner: {
                display: "x78zum5",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                marginBottom: "xjpr12u",
                minWidth: "xeuugli",
                opacity: "xbyyjgo",
                $$css: !0
            },
            makeSpaceForMessageActions: {
                maxWidth: "x1no2skz",
                $$css: !0
            },
            messageBubbleIncoming: {
                paddingEnd: "x1k62owy",
                $$css: !0
            },
            messageBubbleOutgoing: {
                paddingStart: "x6plb61",
                $$css: !0
            },
            outgoing: {
                flexDirection: "x15zctf7",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.isReply,
            d = a.isSecureMessage,
            e = a.messageHistoryEntry,
            f = a.outgoing,
            g = a.renderMessageActions;
        a = {
            color_DEPRECATED: f ? "white" : void 0,
            weight_DEPRECATED: "semibold"
        };
        var i = k(!1),
            m = i[0],
            n = i[1];
        return j.jsxs("div", {
            className: (h || (h = c("stylex")))(l.inner, f && l.outgoing),
            "data-testid": void 0,
            onMouseEnter: function() {
                g != null && n(!0)
            },
            onMouseLeave: function() {
                g != null && n(!1)
            },
            role: "none",
            children: [j.jsx("div", {
                className: h(g ? l.makeSpaceForMessageActions : f ? l.messageBubbleOutgoing : l.messageBubbleIncoming),
                children: j.jsx(c("MWXMessageBubble.react"), {
                    align: f ? "right" : "left",
                    color: f ? "outgoing" : "incoming",
                    connectBottom: !1,
                    connectTop: !1,
                    variant: "opaque",
                    xstyle: !f && b && l.border,
                    children: j.jsx(c("MWPEditMessageHistoryListText.react"), {
                        isSecureMessage: d,
                        maxLength: 300,
                        maxLines: 3,
                        outgoing: f,
                        ranges: [],
                        seeLessLinkProps: a,
                        seeMoreLinkProps: a,
                        text: e.messageContent || "",
                        truncationStyle: "see-more-and-less"
                    })
                })
            }), g && m ? j.jsx("div", {
                className: "xc26acl x78zum5",
                children: g(e)
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.MWPEditedMessageHistoryEntry = a
}), 98);
__d("useEditMessageHistoryLS", ["ReQL", "ReQLSuspense", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (i || d("react")).useMemo;

    function a(a, b) {
        var e = (h || (h = c("useReStore")))(),
            g = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(e.tables.edit_message_history.index("originalMsgPkEditTs")).getKeyRange(a)
            }, [e, a], f.id + ":29");
        return j(function() {
            return b ? g.slice(0, -1) : g
        }, [g, b])
    }
    g["default"] = a
}), 98);
__d("MWPEditedMessageHistoryList.react", ["I64", "MWMessageEditContext.react", "MWPEditedMessageHistoryEntry.react", "QPLUserFlow", "cr:4654", "qex", "qpl", "react", "stylex", "useEditMessageHistoryLS", "useMAWSeparateReadsSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = i || (i = d("react")),
        l = i.useEffect,
        m = {
            base: {
                backgroundColor: "x1eb86dx",
                maxWidth: "x193iq5w",
                zIndex: "x1vjfegm",
                $$css: !0
            },
            incoming: {
                display: "x1lliihq",
                paddingStart: "xd06s5i",
                $$css: !0
            },
            outgoing: {
                display: "x1lliihq",
                paddingEnd: "x1sxyh0",
                $$css: !0
            }
        };

    function a(a) {
        var e = a.editCount,
            f = a.isReply,
            g = a.isSecureMessage,
            i = a.msgId,
            o = a.outgoing,
            p = a.renderMessageActions,
            q = a.threadType;
        a = a.xstyle;
        var r = d("MWMessageEditContext.react").useMWMessageEditContext() || {
                showEdits: !1
            },
            s = r.showEdits;
        r = c("useEditMessageHistoryLS")(i, g);
        i = b("cr:4654")(i, g);
        var t = d("useMAWSeparateReadsSelector").useMAWSeparateReadsArraySelector("EditMessageHistory", i, r, g && ((i = c("qex")._("228")) != null ? i : !1), n);
        l(function() {
            s && (c("QPLUserFlow").addAnnotations(c("qpl")._(1056849214, "1777"), {
                bool: {
                    isSecureMessage: g
                },
                "int": {
                    threadType: (j || (j = d("I64"))).to_int32(q)
                }
            }), t != null && e != null && t.length === (j || (j = d("I64"))).to_int32(e) ? c("QPLUserFlow").endSuccess(c("qpl")._(1056849214, "1777")) : c("QPLUserFlow").endFailure(c("qpl")._(1056849214, "1777"), "no edits found"))
        }, [t, e, s, g, q]);
        r = k.jsx("div", {
            className: (h || (h = c("stylex")))(m.base, o ? m.outgoing : m.incoming, a),
            role: "none",
            children: t.map(function(a, b) {
                return k.jsx(d("MWPEditedMessageHistoryEntry.react").MWPEditedMessageHistoryEntry, {
                    isReply: f,
                    isSecureMessage: g,
                    messageHistoryEntry: a,
                    outgoing: o,
                    renderMessageActions: p
                }, b)
            })
        });
        return s ? r : null
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function n(a, b) {
        return (j || (j = d("I64"))).compare(a.pk, b.pk)
    }
    g["default"] = a
}), 98);
__d("getMWEBRestoreQPCautionCircleProperties", ["ix", "gkx"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = c("gkx")("23433");

    function a() {
        var a = i ? h("414274") : h("1745665");
        return a
    }
    g["default"] = a
}), 98);
__d("useEditMessageHistoryMAWNoop", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return []
    }
    f["default"] = a
}), 66); /*FB_PKG_DELIM*/
__d("CometRouteRenderType", ["CometRouterRenderTypeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        var a = i(c("CometRouterRenderTypeContext"));
        return a
    }

    function b() {
        var a = i(c("CometRouterRenderTypeContext"));
        return (a == null ? void 0 : a.renderType) === "pushView"
    }

    function e() {
        var a = i(c("CometRouterRenderTypeContext"));
        return (a == null ? void 0 : a.renderType) === "hosted"
    }

    function f() {
        var a = i(c("CometRouterRenderTypeContext"));
        return (a == null ? void 0 : a.renderType) === "main"
    }
    g.useCometRouteRenderingLocation = a;
    g.useIsPushView = b;
    g.useIsHosted = e;
    g.useIsMain = f
}), 98);
__d("VideoPlayerAudioAvailabilityInfo", ["recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.audioAvailability;
        a = a.mutedSegmentsUnsanitized;
        a = a.map(function(a) {
            return a.muteStartTimeInSec != null && a.muteEndTimeInSec != null && a.muteEndTimeInSec > a.muteStartTimeInSec ? {
                muteEndTimeInSec: a.muteEndTimeInSec,
                muteStartTimeInSec: a.muteStartTimeInSec
            } : null
        }).filter(Boolean);
        return {
            audioAvailability: b,
            mutedSegments: a
        }
    }

    function b(a, b) {
        var d = a.audioAvailability;
        a = a.mutedSegments;
        var e = b.playheadPosition,
            f;
        b = !1;
        var g = !1;
        switch (d) {
            case "AVAILABLE_BUT_MUTED":
                a.length > 0 ? (b = e != null && a.some(function(a) {
                    return a.muteStartTimeInSec <= e && e <= a.muteEndTimeInSec
                }), b ? (f = "VOLUME_COPYRIGHT_PARTIAL_SILENCED", g = !0) : f = "VOLUME_COPYRIGHT_PARTIAL_NOT_SILENCED") : (f = "VOLUME_COPYRIGHT_FULL", g = !0);
                break;
            case "AVAILABLE_BUT_SILENT":
            case "UNAVAILABLE":
                f = "VOLUME_SILENT";
                g = !0;
                break;
            case "AVAILABLE":
            case "UNKNOWN":
            case "AVAILABLE_BUT_MISSING_LOUDNESS_DATA":
            case null:
            case void 0:
                f = "VOLUME_DEFAULT";
                break;
            default:
                c("recoverableViolation")("Unhandled audio availability: " + d, "comet_video_player");
                f = "VOLUME_DEFAULT";
                break
        }
        return {
            isPlayheadWithinMutedSegment: b,
            isSilentAtPlayhead: g,
            volumeControlState: f
        }
    }
    d = a({
        audioAvailability: null,
        mutedSegmentsUnsanitized: []
    });
    g.makeVideoPlayerAudioAvailabilityInfo = a;
    g.makeVideoPlayerAudioAvailabilityAtPlayheadInfo = b;
    g.VideoPlayerAudioAvailabilityInfoDefault = d
}), 98);
__d("CoreVideoPlayerImplementationCallbacks", ["VideoPlayerAudioAvailabilityInfo", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useRef;

    function a(a) {
        var b = a.coreVideoPlayerMetaData,
            c = a.dimensions,
            e = a.instanceKey,
            f = a.isFullscreen,
            g = a.onCoreVideoStatesChanged,
            h = a.renderWithCoreVideoStates,
            l = a.videoPlayerPassiveViewabilityInfo,
            m = i(function(a) {
                var g, h = a.implementationController;
                a = a.implementationExposedState;
                g = {
                    adClientToken: b.adClientToken,
                    audioAvailabilityInfo: (g = b.audioAvailabilityInfo) != null ? g : d("VideoPlayerAudioAvailabilityInfo").VideoPlayerAudioAvailabilityInfoDefault,
                    autoplayGatingResult: b.autoplayGatingResult != null ? b.autoplayGatingResult : "unknown",
                    autoplaySetting: b.autoplaySetting,
                    broadcastStatus: b.broadcastStatus,
                    canAutoplay: b.canAutoplay != null ? b.canAutoplay : "allow",
                    controller: h,
                    dimensions: c,
                    duration: a.duration,
                    initialTracePolicy: b.initialTracePolicy,
                    instanceKey: e,
                    isDesktopPictureInPicture: a.isDesktopPictureInPicture,
                    isFullscreen: f,
                    isNCSR: Boolean(b.isNCSR),
                    isPremiumMusicVideo: Boolean(b.isPremiumMusicVideo),
                    lastMuteReason: a.lastMuteReason,
                    lastPauseReason: a.lastPauseReason,
                    lastPlayReason: a.lastPlayReason,
                    loopCount: a.loopCount,
                    loopCurrent: a.loopCurrent,
                    videoFBID: b.videoFBID,
                    videoPixelsAspectRatio: b.videoPixelsAspectRatio,
                    videoPlayerPassiveViewabilityInfo: l,
                    videoState: a,
                    volumeSetting: b.volumeSetting
                };
                return g
            }, [b, c, e, f, l]);
        a = i(function(a) {
            a = m(a);
            return h(a)
        }, [h, m]);
        var n = k(null),
            o = i(function(a) {
                n.current = a.implementationController;
                if (g) {
                    a = m(a);
                    g(a)
                }
            }, [g, m]);
        j(function() {
            var a = n.current;
            if (g && a) {
                a = m({
                    implementationController: a,
                    implementationExposedState: a.getCurrentState()
                });
                g(a)
            }
        }, [g, m]);
        return {
            onExposedStateChanged: o,
            renderWithExposedState: a
        }
    }
    g.useImplementationCallbacks = a
}), 98);
__d("VideoPlayerOnViewability.react", ["DOMRectIsEqual", "DOMRectReadOnly", "VideoPlayerViewabilityConstants", "emptyFunction", "react", "useIntersectionObserver", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useCallback,
        l = b.useMemo,
        m = b.useRef,
        n = 10,
        o = [.25, .75, .99, 1].concat(new Array(10).fill().map(function(a, b) {
            return b / 10
        }));

    function a(a) {
        var b = a.viewportMargins,
            d = m(-1),
            e = m(-1),
            f = m(c("DOMRectReadOnly").fromRect({
                height: 0,
                width: 0,
                x: 0,
                y: 0
            })),
            g = m(null),
            i = m(null);
        b = -b.top + "px " + -b.right + "px " + -b.bottom + "px " + -b.left + "px";
        var p = a.onVideoPlayerViewabilityInfoChange || c("emptyFunction"),
            q = n,
            r = k(function(a) {
                if (a.time > e.current && !c("DOMRectIsEqual")(a.boundingClientRect, f.current)) {
                    var b = a.boundingClientRect,
                        d = b.height,
                        h = b.width,
                        i = b.x;
                    b = b.y;
                    var j = g.current;
                    d = c("DOMRectReadOnly").fromRect({
                        height: d,
                        width: h,
                        x: i,
                        y: b
                    });
                    f.current = d;
                    e.current = a.time;
                    if (j === null || j <= 0) return;
                    if (j <= c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE) return;
                    p({
                        positionToViewport: d,
                        visiblePercentage: j
                    })
                }
            }, [f, g, p]),
            s = k(function(a) {
                if (a.time > d.current && (a.intersectionRatio !== g.current || !c("DOMRectIsEqual")(a.boundingClientRect, f.current))) {
                    var b = a.boundingClientRect,
                        h = b.height,
                        j = b.width,
                        k = b.x;
                    b = b.y;
                    var l = a.intersectionRatio;
                    h = c("DOMRectReadOnly").fromRect({
                        height: h,
                        width: j,
                        x: k,
                        y: b
                    });
                    j = i.current;
                    k = j;
                    b = !1;
                    var m = Math.abs((j || 0) * 100 - (l || 0) * 100);
                    (l !== null && m >= 1 || m > 0 && l < (j || 0)) && (k = l, i.current = l, b = !0);
                    g.current = l;
                    d.current = a.time;
                    m = f.current;
                    f.current = h;
                    e.current = a.time;
                    if (!b && c("DOMRectIsEqual")(m, h)) return;
                    k !== null && p({
                        positionToViewport: h,
                        visiblePercentage: k
                    })
                }
            }, [e, f, g, p, d]),
            t = l(function() {
                var b = [];
                for (var a = 1; a <= q; a++) b.push("-" + (100 - a / q * 100) + "% 0% 0% 0%");
                return b
            }, [q]),
            u = (h || (h = c("useUnsafeRef_DEPRECATED")))([]);
        u.current = [];
        for (var v = 0; v < t.length; v++) u.current.push(k(c("useIntersectionObserver")(r, {
            root: null,
            rootMargin: t[v],
            threshold: o
        }), [t[v], o, c("useIntersectionObserver")]));
        var w = u.current.length,
            x = k(function(a) {
                for (var b = 0; b < w; b++) u.current[b](a)
            }, [w, u]),
            y = k(c("useIntersectionObserver")(s, {
                root: null,
                rootMargin: b,
                threshold: o
            }), [s, b, o, c("useIntersectionObserver")]);
        v = k(function(a) {
            y(a), x(a)
        }, [y, x]);
        return j.jsx("div", {
            className: "x5yr21d x1uhb9sk xh8yej3",
            ref: v,
            children: j.Children.only(a.children)
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerViewabilityContexts", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("react")).createContext;
    b = a(null);
    c = a(!1);
    e = a(!1);
    f = a(null);
    g.VideoPlayerPassiveViewabilityInfoContext = b;
    g.VideoPlayerDesktopPictureInPictureContext = c;
    g.VideoPlayerFullscreenContext = e;
    g.VideoPlayerExtendedPassiveViewabilityInfoContext = f
}), 98);
__d("VideoPlayerContexts", ["VideoPlayerAudioAvailabilityInfo", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("react")).createContext;
    b = a(null);
    c = a(!1);
    e = a("");
    f = a(null);
    var i = a(0),
        j = a(0),
        k = a(!1),
        l = a(!1),
        m = a(!0),
        n = a(!1),
        o = a(!1),
        p = a(null),
        q = a(!1),
        r = a(!1),
        s = a(null),
        t = a(null),
        u = a(null),
        v = a(null),
        w = a([]),
        x = a("notselected"),
        y = a([]),
        z = a(null),
        A = a(null),
        B = a(null),
        C = a(""),
        D = a([]),
        E = a(null),
        F = a(!1),
        G = a(!1),
        H = a(null),
        I = a(1),
        J = a(!1),
        K = a(0),
        L = a(0),
        M = a(null),
        N = a(null),
        O = a(null),
        P = a(null),
        Q = a(!1),
        R = a(!1),
        S = a(null),
        T = a("deny"),
        U = a(null),
        V = a("unknown"),
        W = a(!1),
        X = a({
            release: function(a) {},
            reserve: function(a) {
                return a
            }
        }),
        Y = a([]),
        Z = a(!1),
        $ = a(0),
        aa = a(0),
        ba = a(null),
        ca = a(!1),
        da = a(!1);
    d = a(d("VideoPlayerAudioAvailabilityInfo").VideoPlayerAudioAvailabilityInfoDefault);
    var ea = a(1),
        fa = a(!1),
        ga = a(!1),
        ha = a(null),
        ia = a("normal");
    a = a([]);
    g.VideoFBIDContext = b;
    g.IsAbrEnabledContext = c;
    g.TargetVideoQualityContext = e;
    g.AdClientTokenContext = f;
    g.LoopCountContext = i;
    g.LoopCurrentContext = j;
    g.PlayingContext = k;
    g.StallingContext = l;
    g.PausedContext = m;
    g.EndedContext = n;
    g.InPlayStallingContext = o;
    g.ErrorContext = p;
    g.IsLiveContext = q;
    g.SeekingContext = r;
    g.ControllerContext = s;
    g.LastMuteReasonContext = t;
    g.LastPlayReasonContext = u;
    g.LastPauseReasonContext = v;
    g.AvailableVideoQualitiesContext = w;
    g.SelectedVideoQualityContext = x;
    g.AvailableAudioTracksContext = y;
    g.TargetAudioTrackContext = z;
    g.CurrentAudioTrackIDContext = A;
    g.CurrentVideoTrackIDContext = B;
    g.CurrentVideoQualityContext = C;
    g.AvailableVideoTracksContext = D;
    g.ActiveCaptionsContext = E;
    g.CaptionsVisibleContext = F;
    g.CaptionsLoadedContext = G;
    g.CaptionDisplayStyleContext = H;
    g.VolumeContext = I;
    g.MutedContext = J;
    g.DurationContext = K;
    g.BufferEndContext = L;
    g.InstanceKeyContext = M;
    g.VideoPixelsAspectRatioContext = N;
    g.DimensionsContext = O;
    g.PlayerVersionContext = P;
    g.VideoPlayerMouseHoverContext = Q;
    g.VideoPlayerMouseIdleContext = R;
    g.BroadcastStatusContext = S;
    g.CanAutoplayContext = T;
    g.VolumeSettingContext = U;
    g.AutoplayGatingResultContext = V;
    g.InbandCaptionsAutogeneratedContext = W;
    g.VideoPlayerCaptionsReservationActionsContext = X;
    g.VideoPlayerCaptionsReservationsContext = Y;
    g.StreamInterruptedContext = Z;
    g.WatchTimeContext = $;
    g.LastPlayedTimeContext = aa;
    g.SeekableRangesContext = ba;
    g.IsLiveRewindActiveContext = ca;
    g.IsLiveRewindAvailableContext = da;
    g.AudioAvailabilityInfoContext = d;
    g.PlaybackRateContext = ea;
    g.IsNCSRContext = fa;
    g.IsPremiumMusicVideoContext = ga;
    g.InitialTracePolicyContext = ha;
    g.LatencyLevelContext = ia;
    g.ActiveEmsgBoxesContext = a
}), 98);
__d("VideoPlayerVideoPixelsFitContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("react")).createContext;
    b = a(null);
    c = b;
    g["default"] = c
}), 98);
__d("VideoPlayerHooks", ["DOMRectIsEqual", "VideoPlayerContexts", "VideoPlayerVideoPixelsFitContext", "VideoPlayerViewabilityContexts", "clearTimeout", "react", "removeFromArray", "setTimeout", "unrecoverableViolation", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || d("react"),
        k = j.useContext,
        l = j.useEffect,
        m = j.useRef,
        n = j.useState;

    function a(a) {
        var b = m(a);
        l(function() {
            b.current = a
        }, [a]);
        return b
    }

    function o() {
        var a = k((i || (i = d("VideoPlayerContexts"))).ControllerContext);
        if (a == null) throw c("unrecoverableViolation")("Empty ControllerContext. Are you rendering useController outside of VideoPlayerRelay/VideoPlayerX?", "comet_video_player");
        return a
    }

    function b() {
        var a = k((i || (i = d("VideoPlayerContexts"))).InstanceKeyContext);
        if (a == null) throw c("unrecoverableViolation")("Empty InstanceKeyContext. Are you rendering useInstanceKey outside of VideoPlayerRelay/VideoPlayerX?", "comet_video_player");
        return a
    }

    function p() {
        var a = T();
        return a === "LIVE"
    }

    function e() {
        var a = T();
        return a === "LIVE" || a === "VOD_READY"
    }

    function f() {
        return k((i || (i = d("VideoPlayerContexts"))).BufferEndContext)
    }

    function q() {
        return k((i || (i = d("VideoPlayerContexts"))).DurationContext)
    }

    function r() {
        return k((i || (i = d("VideoPlayerContexts"))).SeekingContext)
    }

    function s() {
        return k((i || (i = d("VideoPlayerContexts"))).EndedContext)
    }

    function t() {
        return k((i || (i = d("VideoPlayerContexts"))).ErrorContext)
    }

    function u() {
        return k((i || (i = d("VideoPlayerContexts"))).PlayingContext)
    }

    function v() {
        var a = n(0),
            b = a[0],
            c = a[1],
            d = o();
        l(function() {
            var a = d.subscribe(function() {
                c(d.getPlayheadPosition())
            });
            c(d.getPlayheadPosition());
            return function() {
                return a.remove()
            }
        }, [d]);
        return b
    }

    function w(a, b) {
        var d = n(0),
            e = d[0],
            f = d[1],
            g = o(),
            h = m(null),
            i = m(e);
        l(function() {
            var d = g.subscribe(function() {
                i.current = b ? b(g) : g.getPlayheadPosition();
                if (h.current != null) return;
                h.current = c("setTimeout")(function() {
                    f(i.current), h.current = null
                }, a)
            });
            f(g.getPlayheadPosition());
            return d.remove
        }, [g, a]);
        l(function() {
            return function() {
                h.current !== null && (c("clearTimeout")(h.current), h.current = null)
            }
        }, []);
        return e
    }

    function x(a) {
        a === void 0 && (a = 200);
        var b = n(0),
            d = b[0],
            e = b[1],
            f = o(),
            g = p(),
            h = m(null),
            i = m(d);
        l(function() {
            if (!g) return;
            var b = f.subscribe(function() {
                if (h.current != null) return;
                h.current = c("setTimeout")(function() {
                    f.getCurrentState().paused || (i.current += a / 1e3, e(i.current)), h.current = null
                }, a)
            });
            e(0);
            return function() {
                return b.remove()
            }
        }, [f, a, g]);
        l(function() {
            return function() {
                h.current !== null && (c("clearTimeout")(h.current), h.current = null)
            }
        }, []);
        return !g ? null : d
    }

    function y() {
        var a = o(),
            b = m([]),
            d = m(a.isFrozen()),
            e = c("useStable")(function() {
                return {
                    getCurrentState: function() {
                        return a.isFrozen()
                    },
                    subscribeToChanges: function(a) {
                        var d = b.current;
                        d.push(a);
                        return {
                            remove: function() {
                                return c("removeFromArray")(d, a)
                            }
                        }
                    }
                }
            });
        l(function() {
            var c = a.subscribe(function() {
                var c = d.current,
                    e = a.isFrozen();
                d.current = e;
                if (e !== c) {
                    c = b.current;
                    c.forEach(function(a) {
                        return a(e)
                    })
                }
            });
            return function() {
                c.remove()
            }
        }, [a]);
        return e
    }

    function z() {
        return k((i || (i = d("VideoPlayerContexts"))).WatchTimeContext)
    }

    function A() {
        return k((i || (i = d("VideoPlayerContexts"))).LastPlayedTimeContext)
    }

    function B() {
        return k((i || (i = d("VideoPlayerContexts"))).PausedContext)
    }

    function C() {
        return k((i || (i = d("VideoPlayerContexts"))).StallingContext)
    }

    function D() {
        return k((i || (i = d("VideoPlayerContexts"))).InPlayStallingContext)
    }

    function E() {
        return k((i || (i = d("VideoPlayerContexts"))).LastMuteReasonContext)
    }

    function F() {
        return k((i || (i = d("VideoPlayerContexts"))).LastPauseReasonContext)
    }

    function G() {
        return k((i || (i = d("VideoPlayerContexts"))).LastPlayReasonContext)
    }

    function H() {
        return k((i || (i = d("VideoPlayerContexts"))).AvailableVideoQualitiesContext)
    }

    function I() {
        return k((i || (i = d("VideoPlayerContexts"))).AvailableAudioTracksContext)
    }

    function J() {
        return k((i || (i = d("VideoPlayerContexts"))).AvailableVideoTracksContext)
    }

    function K() {
        return k((i || (i = d("VideoPlayerContexts"))).CaptionsVisibleContext)
    }

    function L() {
        return k((i || (i = d("VideoPlayerContexts"))).CaptionDisplayStyleContext)
    }

    function M() {
        return k((i || (i = d("VideoPlayerContexts"))).ActiveCaptionsContext)
    }

    function N() {
        return k((i || (i = d("VideoPlayerContexts"))).CurrentAudioTrackIDContext)
    }

    function O() {
        return k((i || (i = d("VideoPlayerContexts"))).CurrentVideoQualityContext)
    }

    function P() {
        return k((i || (i = d("VideoPlayerContexts"))).CurrentVideoTrackIDContext)
    }

    function Q() {
        return k((i || (i = d("VideoPlayerContexts"))).SelectedVideoQualityContext)
    }

    function R() {
        return k((i || (i = d("VideoPlayerContexts"))).TargetAudioTrackContext)
    }

    function aa() {
        return k((i || (i = d("VideoPlayerContexts"))).MutedContext)
    }

    function ba() {
        return k((i || (i = d("VideoPlayerContexts"))).VolumeContext)
    }

    function ca() {
        return k(d("VideoPlayerViewabilityContexts").VideoPlayerDesktopPictureInPictureContext)
    }

    function da() {
        return k(d("VideoPlayerViewabilityContexts").VideoPlayerFullscreenContext)
    }

    function ea() {
        return k((i || (i = d("VideoPlayerContexts"))).DimensionsContext)
    }

    function fa() {
        return k((i || (i = d("VideoPlayerContexts"))).VideoPixelsAspectRatioContext)
    }

    function ga() {
        return k((i || (i = d("VideoPlayerContexts"))).PlayerVersionContext)
    }

    function ha() {
        return k((i || (i = d("VideoPlayerContexts"))).CaptionsLoadedContext)
    }

    function ia() {
        return k((i || (i = d("VideoPlayerContexts"))).IsAbrEnabledContext)
    }

    function ja() {
        return k((i || (i = d("VideoPlayerContexts"))).TargetVideoQualityContext)
    }

    function ka() {
        return k((i || (i = d("VideoPlayerContexts"))).VideoPlayerMouseHoverContext)
    }

    function la() {
        return k((i || (i = d("VideoPlayerContexts"))).VideoPlayerMouseIdleContext)
    }

    function S() {
        return k(d("VideoPlayerViewabilityContexts").VideoPlayerPassiveViewabilityInfoContext)
    }

    function ma() {
        return k(d("VideoPlayerViewabilityContexts").VideoPlayerExtendedPassiveViewabilityInfoContext)
    }

    function na() {
        var a = S(),
            b = n(null),
            d = b[0],
            e = b[1],
            f = m(d);
        l(function() {
            f.current = d
        }, [d]);
        l(function() {
            if (a) {
                var b = function() {
                        var b = a.getCurrent();
                        if (b) {
                            var d = b.positionToViewport;
                            b = b.visiblePercentage;
                            var g = f.current;
                            (g == null || b !== g.visiblePercentage || !c("DOMRectIsEqual")(d, g.positionToViewport)) && e({
                                positionToViewport: d,
                                visiblePercentage: b
                            })
                        }
                    },
                    d = a.subscribe(function() {
                        b()
                    });
                return function() {
                    return d.remove()
                }
            }
        }, [e, a]);
        return d
    }

    function T() {
        return k((i || (i = d("VideoPlayerContexts"))).BroadcastStatusContext)
    }

    function oa() {
        return k((i || (i = d("VideoPlayerContexts"))).CanAutoplayContext)
    }

    function pa() {
        return k((i || (i = d("VideoPlayerContexts"))).VolumeSettingContext)
    }

    function qa() {
        return k((i || (i = d("VideoPlayerContexts"))).AutoplayGatingResultContext)
    }

    function ra() {
        return k((i || (i = d("VideoPlayerContexts"))).VideoFBIDContext)
    }

    function U() {
        return k((i || (i = d("VideoPlayerContexts"))).AdClientTokenContext)
    }

    function V() {
        return k((i || (i = d("VideoPlayerContexts"))).LoopCurrentContext)
    }

    function W() {
        return k((i || (i = d("VideoPlayerContexts"))).LoopCountContext)
    }

    function sa() {
        return k((i || (i = d("VideoPlayerContexts"))).InbandCaptionsAutogeneratedContext)
    }

    function ta() {
        return k((i || (i = d("VideoPlayerContexts"))).VideoPlayerCaptionsReservationsContext)
    }

    function ua() {
        return k((i || (i = d("VideoPlayerContexts"))).VideoPlayerCaptionsReservationActionsContext)
    }

    function va() {
        return k((i || (i = d("VideoPlayerContexts"))).StreamInterruptedContext)
    }

    function wa() {
        return k((i || (i = d("VideoPlayerContexts"))).SeekableRangesContext)
    }

    function X() {
        return k((i || (i = d("VideoPlayerContexts"))).IsLiveRewindActiveContext)
    }

    function Y() {
        var a = s(),
            b = V(),
            c = W();
        a = a && (c === -1 || c > 0 && b < c);
        return a
    }

    function xa() {
        var a = s(),
            b = Y();
        return a && !b
    }

    function ya() {
        return k((i || (i = d("VideoPlayerContexts"))).PlaybackRateContext)
    }

    function za() {
        return k((i || (i = d("VideoPlayerContexts"))).IsNCSRContext)
    }

    function Z() {
        return k((i || (i = d("VideoPlayerContexts"))).IsPremiumMusicVideoContext)
    }

    function Aa() {
        var a = U() != null,
            b = p(),
            c = Z(),
            d = X();
        if (a || c) return !1;
        if (b) return d;
        else return !0
    }

    function Ba() {
        return k((i || (i = d("VideoPlayerContexts"))).InitialTracePolicyContext)
    }

    function Ca() {
        return k((i || (i = d("VideoPlayerContexts"))).LatencyLevelContext)
    }

    function Da() {
        return k((i || (i = d("VideoPlayerContexts"))).AudioAvailabilityInfoContext)
    }

    function Ea() {
        var a = U() != null,
            b = p(),
            c = Z();
        return a || c || b ? !1 : !0
    }

    function $(a) {
        a === void 0 && (a = !0);
        var b = o();
        l(function() {
            if (a) {
                var c = b.registerEmsgObserver();
                return function() {
                    b.unregisterEmsgObserver(c)
                }
            }
        }, [b, a])
    }

    function Fa() {
        $();
        return k((i || (i = d("VideoPlayerContexts"))).ActiveEmsgBoxesContext)
    }

    function Ga() {
        return k(c("VideoPlayerVideoPixelsFitContext"))
    }
    g.useLatestValueRef = a;
    g.useController = o;
    g.useInstanceKey = b;
    g.useIsLive = p;
    g.useIsVideoBroadcast = e;
    g.useBufferEnd = f;
    g.useDuration = q;
    g.useSeeking = r;
    g.useEnded = s;
    g.useError = t;
    g.usePlaying = u;
    g.useCurrentTime_DO_NOT_USE = v;
    g.useCurrentTimeThrottled = w;
    g.useLiveTimeElapsedThrottled = x;
    g.useIsFrozenPassive = y;
    g.useWatchTime = z;
    g.useLastPlayedTime = A;
    g.usePaused = B;
    g.useStalling = C;
    g.useInPlayStalling = D;
    g.useLastMuteReason = E;
    g.useLastPauseReason = F;
    g.useLastPlayReason = G;
    g.useAvailableVideoQualities = H;
    g.useAvailableAudioTracks = I;
    g.useAvailableVideoTracks = J;
    g.useCaptionsVisible = K;
    g.useCaptionDisplayStyle = L;
    g.useActiveCaptions = M;
    g.useCurrentAudioTrackID = N;
    g.useCurrentVideoQuality = O;
    g.useCurrentVideoTrackID = P;
    g.useSelectedVideoQuality = Q;
    g.useTargetAudioTrack = R;
    g.useMuted = aa;
    g.useVolume = ba;
    g.useIsDesktopPictureInPicture = ca;
    g.useIsFullscreen = da;
    g.useDimensions = ea;
    g.useVideoPixelsAspectRatio = fa;
    g.usePlayerVersion = ga;
    g.useCaptionsLoaded = ha;
    g.useIsAbrEnabled = ia;
    g.useTargetVideoQuality = ja;
    g.useIsHovering = ka;
    g.useIsMouseIdle = la;
    g.useVideoPlayerPassiveViewabilityInfo = S;
    g.useVideoPlayerExtendedPassiveViewabilityInfo = ma;
    g.useVideoPlayerViewabilityInfo = na;
    g.useBroadcastStatus = T;
    g.useCanAutoplay = oa;
    g.useVolumeSetting = pa;
    g.useAutoplayGatingResult = qa;
    g.useVideoFbid = ra;
    g.useAdClientToken = U;
    g.useVideoPlayerCurrentLoop = V;
    g.useVideoPlayerTotalLoops = W;
    g.useInbandCaptionsAutogenerated = sa;
    g.useVideoPlayerCaptionsReservations = ta;
    g.useVideoPlayerCaptionsReservationActions = ua;
    g.useStreamInterrupted = va;
    g.useSeekableRanges_DO_NOT_USE = wa;
    g.useIsLiveRewindActive = X;
    g.useIsTransitioningToNextLoop = Y;
    g.useVideoPlaybackEnded = xa;
    g.usePlaybackRate = ya;
    g.useIsNCSR = za;
    g.useIsPremiumMusicVideo = Z;
    g.useShouldShowPlaybackRateControl = Aa;
    g.useVideoPlayerInitialTracePolicy = Ba;
    g.useLatencyLevel = Ca;
    g.useAudioAvailabilityInfo = Da;
    g.useShouldPersistPlaybackRate = Ea;
    g.useEmsgObserver = $;
    g.useActiveEmsgBoxes = Fa;
    g.useVideoPlayerVideoPixelsFit = Ga
}), 98);
__d("createVideoStateHook", ["VideoPlayerHooks", "emptyFunction", "gkx", "react", "unrecoverableViolation", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    b = h || d("react");
    var j = b.useEffect,
        k = b.useMemo,
        l = b.useRef,
        m = b.useState,
        n = b.useSyncExternalStore,
        o = new Set();
    e = function(a) {
        var b = new Map();
        o.add(b);

        function e() {
            var a = (i || (i = d("VideoPlayerHooks"))).useInstanceKey();
            b.has(a) || b.set(a, {
                consumers: new Set(),
                key: a,
                lastValue: void 0
            });
            var e = b.get(a);
            if (e == null) throw c("unrecoverableViolation")('createVideoStateHook useInstance missing instance by key "' + a + '"', "comet_video_player");
            return e
        }

        function f(a, b) {
            a.consumers.add(b)
        }

        function g(a, b) {
            a.consumers["delete"](b)
        }

        function h(a, b, c) {
            a.lastValue = b, a.consumers.forEach(function(a) {
                c !== a && a(b)
            })
        }

        function k(a) {
            var b = e(),
                c = l(b);
            c.current = b;
            a = b.lastValue != null ? b.lastValue : a;
            var d = l(a);
            d.current = a;
            a = m(a);
            var i = a[0],
                k = a[1];
            j(function() {
                k(d.current);
                f(b, k);
                return function() {
                    g(b, k)
                }
            }, [b]);
            j(function() {
                h(c.current, i, k)
            }, [i]);
            return [i, k]
        }

        function a(a) {
            a = k(a);
            a[0];
            a = a[1];
            return a
        }

        function n(a) {
            a = k(a);
            var b = a[0];
            a[1];
            return b
        }
        return {
            setterHook: a,
            stateHook: k,
            valueHook: n
        }
    };
    f = function(a) {
        var b = new Map();
        o.add(b);
        var e = c("emptyFunction");

        function f(a, c) {
            var d = b.get(a);
            d || (d = {
                consumers: new Set(),
                key: a,
                lastValue: c
            }, b.set(a, d));
            return d
        }

        function g(a, c) {
            return {
                getSnapshot: function() {
                    var d = b.get(a);
                    return d == null ? c : d.lastValue
                },
                setValue: function(b) {
                    var d = f(a, c),
                        e;
                    typeof b === "function" ? e = b(d.lastValue) : e = b;
                    d.lastValue = e;
                    d.consumers.forEach(function(a) {
                        a(e)
                    })
                },
                subscribe: function(b) {
                    var d = f(a, c);
                    d.consumers.add(b);
                    return function() {
                        d.consumers["delete"](b)
                    }
                }
            }
        }

        function a(a) {
            var b = c("useStable")(function() {
                    return a
                }),
                e = (i || (i = d("VideoPlayerHooks"))).useInstanceKey(),
                f = k(function() {
                    return g(e, b)
                }, [b, e]),
                h = f.getSnapshot,
                j = f.setValue;
            f = f.subscribe;
            f = n(f, h);
            return [f, j]
        }

        function h(a) {
            var b = c("useStable")(function() {
                    return a
                }),
                e = (i || (i = d("VideoPlayerHooks"))).useInstanceKey(),
                f = k(function() {
                    return g(e, b)
                }, [b, e]);
            f = f.setValue;
            return f
        }

        function j(a) {
            var b = c("useStable")(function() {
                    return a
                }),
                e = (i || (i = d("VideoPlayerHooks"))).useInstanceKey(),
                f = k(function() {
                    return g(e, b)
                }, [b, e]),
                h = f.getSnapshot;
            f = f.subscribe;
            return n(f, h)
        }
        return {
            setterHook: h,
            stateHook: a,
            valueHook: j
        }
    };

    function a(a) {
        j(function() {
            return function() {
                o.forEach(function(b) {
                    b["delete"](a)
                })
            }
        }, [a])
    }
    b = c("gkx")("24343") ? f : e;
    a = a;
    g.createVideoStateHookImpl_UnsafeForConcurrentRendering = e;
    g.createVideoStateHookImpl_SafeForConcurrentRendering = f;
    g.createVideoStateHook = b;
    g.useCleanupVideoStateHooks_INTERNAL = a
}), 98);
__d("getVideoShareDownstreamSignalTracking", ["VideoShareDownstreamSignalTrackingTypes", "WebStorage", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = 1e3 * 60 * 60 * 4;

    function j() {
        var a;
        if (!c("gkx")("24")) return null;
        a = (a = (h || (h = c("WebStorage"))).getSessionStorage()) == null ? void 0 : a.getItem(d("VideoShareDownstreamSignalTrackingTypes").DOWNSTREAM_VIDEO_SHARE_SESSION_STORAGE_KEY);
        if (a == null) return null;
        a = JSON.parse(a);
        return !a || a.downstream_share_session_start_time + i < Date.now() ? null : a
    }

    function a() {
        var a = j();
        return !a ? null : {
            downstream_share_session_id: a == null ? void 0 : a.downstream_share_session_id,
            downstream_share_session_origin_uri: a == null ? void 0 : a.downstream_share_session_origin_uri,
            downstream_share_session_start_time: a == null ? void 0 : a.downstream_share_session_start_time.toString()
        }
    }
    g.getVideoShareDownstreamSignalTrackingWithNumberStartTime = j;
    g.getVideoShareDownstreamSignalTracking = a
}), 98);
__d("renderVideoPlayerImplementation", ["react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a, b) {
        if (a.typename === "VideoPlayerEmptyImplementation") return i.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else if (a.typename === "VideoPlayerOzImplementation") return i.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else if (a.typename === "VideoPlayerProgressiveImplementation") return i.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else if (a.typename === "VideoPlayerNextgendashImplementation") return i.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else {
            a.typename;
            throw c("unrecoverableViolation")('CoreVideoPlayer: Unrecognized implementation typename "' + a.typename + '".', "comet_video_player")
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometSize_DO_NOT_USE", ["CometThrottle", "ExecutionEnvironment", "FBLogger", "HiddenSubtreePassiveContext", "react", "useResizeObserver", "useStable", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;
    b = j || d("react");
    var k = b.useContext,
        l = b.useEffect,
        m = b.useLayoutEffect,
        n = b.useRef,
        o = b.useState;

    function p(a) {
        var b = a.setBoxStateStable,
            d = null,
            e = function(a) {
                var c;
                if (((c = d) == null ? void 0 : c.height) === a.height && ((c = d) == null ? void 0 : c.width) === a.width) return;
                d = a;
                b(a)
            };
        a = function(a) {
            a = a.getBoundingClientRect();
            var b = a.height;
            a = a.width;
            e({
                height: b,
                width: a
            })
        };
        var f = c("CometThrottle")(function(a) {
            var b = a.height;
            a = a.width;
            if (b === 0 && a === 0) return;
            e({
                height: b,
                width: a
            })
        }, 200, {
            leading: !0,
            trailing: !0
        });
        return {
            measure: a,
            onResizeThrottled: f
        }
    }

    function a(a) {
        a === void 0 && (a = !1);
        if (!(h || (h = c("ExecutionEnvironment"))).canUseDOM && !a) throw c("FBLogger")("comet_ssr").blameToPreviousFile().mustfixThrow("useCometSize is not compatible with Server Rendering. This will break SSR! See https://fburl.com/wiki/xrzohrqb");
        var b = n(null);
        a = o(null);
        var d = a[0],
            e = a[1],
            f = k(c("HiddenSubtreePassiveContext")),
            g = c("useStable")(function() {
                return p({
                    setBoxStateStable: e
                })
            }),
            j = c("useResizeObserver")(g.onResizeThrottled),
            q = n(j);
        m(function() {
            q.current = j
        }, [j]);
        a = (i || (i = c("useUnsafeRef_DEPRECATED")))(function(a) {
            a !== b.current && (b.current = a, a != null && g.measure(a)), q.current(b.current)
        });
        l(function() {
            if (!f.getCurrentState().hidden) return;
            var a = f.subscribeToChanges(function(c) {
                !c.hidden && b.current != null && (g.measure(b.current), a.remove())
            });
            return function() {
                return a.remove()
            }
        }, [f, g]);
        l(function() {
            return function() {
                g.onResizeThrottled.cancel()
            }
        }, [g]);
        return [a.current, d]
    }
    g["default"] = a
}), 98);
__d("useCreateVideoPlayerPassiveViewabilityInfo", ["removeFromArray", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("useStable")(function() {
            var a = [],
                b = null;
            return {
                setVideoPlayerPassiveViewabilityInfo: function(c) {
                    b = c, a.forEach(function(a) {
                        return a()
                    })
                },
                videoPlayerPassiveViewabilityInfo: {
                    getCurrent: function() {
                        return b
                    },
                    subscribe: function(b) {
                        a.push(b);
                        return {
                            remove: function() {
                                c("removeFromArray")(a, b)
                            }
                        }
                    }
                }
            }
        })
    }
    g["default"] = a
}), 98);
__d("videoPlayerUniqueID", ["guid"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return "id-vpuid-" + ((a = a) != null ? a : c("guid")())
    }
    g["default"] = a
}), 98);
__d("CoreVideoPlayer.react", ["CometObjectFitContainer.react", "CoreVideoPlayerImplementationCallbacks", "ErrorMetadata", "FBLogger", "VideoPlayerOnViewability.react", "VideoPlayerViewabilityContexts", "createVideoStateHook", "err", "getVideoShareDownstreamSignalTracking", "react", "renderVideoPlayerImplementation", "useCometSize_DO_NOT_USE", "useCreateVideoPlayerPassiveViewabilityInfo", "useStable", "videoPlayerUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useRef,
        l = 584;

    function m(a) {
        return a != null && isFinite(a) && a > 0 ? a : 0
    }

    function n(a) {
        if (a === "video_home_inline" || a === "inline") return {
            height: l,
            width: l
        };
        else return {
            height: 1080,
            width: 1920
        }
    }

    function o(a, b) {
        b = c("useCometSize_DO_NOT_USE")((b = b) != null ? b : !1);
        var d = b[0];
        b = b[1];
        b = (b = b) != null ? b : n(a);
        return [b, function(a) {
            return i.jsx(c("CometObjectFitContainer.react"), {
                debugRole: null,
                objectFitMode: "CONTAINER_SIZE",
                ref: d,
                children: a
            })
        }]
    }

    function p(a) {
        var b = a.implementation,
            e = a.accessToken,
            f = a.expiredVideoUrlRefreshHandler,
            g = a.fullscreenController,
            h = a.isFullscreen,
            l = a.onCoreVideoStatesChanged,
            n = a.productAttribution,
            p = a.renderWithCoreVideoStates,
            q = a.trackingDataEncrypted,
            r = a.trackingNodes,
            s = a.videoPlayerUniqueIDOverride,
            t = a.viewportMarginsForViewability;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["implementation", "accessToken", "expiredVideoUrlRefreshHandler", "fullscreenController", "isFullscreen", "onCoreVideoStatesChanged", "productAttribution", "renderWithCoreVideoStates", "trackingDataEncrypted", "trackingNodes", "videoPlayerUniqueIDOverride", "viewportMarginsForViewability"]);
        var u = c("useStable")(function() {
            return c("videoPlayerUniqueID")(s)
        });
        d("createVideoStateHook").useCleanupVideoStateHooks_INTERNAL(u);
        var v = k(0),
            w = c("useCreateVideoPlayerPassiveViewabilityInfo")(),
            x = w.setVideoPlayerPassiveViewabilityInfo;
        w = w.videoPlayerPassiveViewabilityInfo;
        var y = o(a.subOrigin, a.bypassUseCometSizeError),
            z = y[0];
        y = y[1];
        var A = j(function(a) {
            x(a)
        }, [x]);
        l = d("CoreVideoPlayerImplementationCallbacks").useImplementationCallbacks({
            coreVideoPlayerMetaData: a,
            dimensions: z,
            instanceKey: u,
            isFullscreen: h,
            onCoreVideoStatesChanged: l,
            renderWithCoreVideoStates: p,
            videoPlayerPassiveViewabilityInfo: w
        });
        p = l.onExposedStateChanged;
        l = l.renderWithExposedState;
        var B = d("getVideoShareDownstreamSignalTracking").getVideoShareDownstreamSignalTrackingWithNumberStartTime();
        e = {
            accessToken: e,
            coreVideoPlayerMetaData: a,
            dimensions: z,
            downstreamShareSignalTracking: B,
            instanceKey: u,
            playerImplementationInstanceCountRef: v,
            productAttribution: n,
            trackingDataEncrypted: q,
            trackingNodes: r
        };
        B = a.sideLoadCaptionsExpected === !0 || a.sideLoadCaptionsUrl != null;
        u = a.isLiveStreaming === !0;
        q = {
            VideoPlayerShakaPerformanceLoggerClass: a.VideoPlayerShakaPerformanceLoggerClass,
            alt: a.alt,
            alwaysShowCaptions: a.alwaysShowCaptions,
            areCaptionsAutogenerated: a.areCaptionsAutogenerated,
            audioOnly: a.audioOnly,
            broadcastLatencySensitivity: a.broadcastLatencySensitivity,
            bufferEndLimit: a.bufferEndLimit,
            captionDisplayStyle: a.captionDisplayStyle,
            createSNAPLMetadataProvider: a.createSNAPLMetadataProvider,
            crossOrigin_DO_NOT_USE_UNLESS_YOU_KNOW_WHAT_YOURE_DOING: a.crossOrigin_DO_NOT_USE_UNLESS_YOU_KNOW_WHAT_YOURE_DOING,
            dimensions: z,
            disableLogging: a.disableLogging === !0,
            disableVPLLogging: a.disableVPLLogging === !0,
            enableSNAPL: a.enableSNAPL === !0,
            expiredVideoUrlRefreshHandler: f,
            fullscreenController: g,
            graphQLVideoDRMInfo: (v = a.graphQLVideoDRMInfo) != null ? v : null,
            graphQLVideoP2PSettings: (n = a.graphQLVideoP2PSettings) != null ? n : null,
            inbandCaptionsExpected: u,
            initialDesiredLatencyMs: a.desiredLatencyMs,
            initialLatencyToleranceMs: a.latencyToleranceMs,
            initialRepresentationIds: a.initialRepresentationIds,
            isClientTriggeredTraceEnabled: a.isClientTriggeredTraceEnabled,
            loadSequence: a.loadSequence,
            loggingMetaData: e,
            loopCount: a.loopCount,
            onExposedStateChanged: p,
            poster: a.poster,
            preloadForProgressiveDisabled: a.preloadForProgressiveDisabled,
            renderVideoPixelsFit: a.renderVideoPixelsFit,
            renderWithExposedState: l,
            seoWebCrawlerLookasideUrl: a.seoWebCrawlerLookasideUrl,
            seoWebCrawlerVideoTracks: a.seoWebCrawlerVideoTracks,
            sideLoadCaptionsExpected: B,
            sideLoadCaptionsUrl: a.sideLoadCaptionsUrl,
            startTimestamp: m(a.startTimestamp),
            videoFBID: a.videoFBID,
            videoPlayerPassiveViewabilityInfo: w,
            videoPlayerShakaPerformanceLoggerBuilder: a.videoPlayerShakaPerformanceLoggerBuilder,
            wrapVideoPixels_EXPERIMENTAL: a.wrapVideoPixels_EXPERIMENTAL
        };
        return y(i.jsx(d("VideoPlayerViewabilityContexts").VideoPlayerFullscreenContext.Provider, {
            value: h,
            children: i.jsx(c("VideoPlayerOnViewability.react"), {
                onVideoPlayerViewabilityInfoChange: A,
                viewportMargins: t,
                children: c("renderVideoPlayerImplementation")(b, q)
            })
        }))
    }
    p.displayName = p.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.implementations;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["implementations"]);
        if (b.length === 0) {
            var d, e = c("err")("No implementations given to CoreVideoPlayer");
            e.name = "VideoPlayerNoImplementations";
            e.project = "comet_video_player";
            d = (d = e.metadata) != null ? d : new(c("ErrorMetadata"))();
            e.metadata = d;
            var f = a.videoFBID;
            f != null && d.addEntry("COMET_VIDEO", "VIDEO_ID", f);
            throw (d = c("FBLogger")("comet_video_player").catching(e)).mustfixThrow.apply(d, [(f = e.messageFormat) != null ? f : e.message].concat(e.messageFormat != null ? (d = e.messageParams) != null ? d : [] : []))
        }
        return i.jsx(p, babelHelpers["extends"]({}, a, {
            implementation: b[0]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("DOMContainer.react", ["invariant", "isNode", "react"], (function(a, b, c, d, e, f, g, h) {
    var i, j = i || d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.containerNode = null, c.setContainerNode = function(a) {
                c.containerNode = a;
                var b = c.props.containerRef;
                typeof b === "function" && b(a)
            }, b) || babelHelpers.assertThisInitialized(c)
        }
        var d = b.prototype;
        d.getDOMChild = function() {
            var a = this.props.children;
            c("isNode")(a) || h(0, 1533);
            return a
        };
        d.shouldComponentUpdate = function(a) {
            return a.children !== this.props.children
        };
        d.componentDidMount = function() {
            var a = this.containerNode;
            a != null && a.appendChild(this.getDOMChild())
        };
        d.componentDidUpdate = function(a) {
            a = this.containerNode;
            if (a == null) return;
            while (a.lastChild) a.removeChild(a.lastChild);
            a.appendChild(this.getDOMChild())
        };
        d.render = function() {
            var a = this.props,
                b = a.display;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["display"]);
            b = b === "block" ? "div" : "span";
            return j.jsx(b, babelHelpers["extends"]({}, a, {
                ref: this.setContainerNode,
                children: void 0
            }))
        };
        return b
    }(j.Component);
    a.defaultProps = {
        display: "inline"
    };
    g["default"] = a
}), 98);
__d("CoreVideoPlayerFitParentContainer.react", ["DOMContainer.react", "cr:964538", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(function(a, b) {
        var c = a.children,
            d = a.debugRole;
        d = a.testid;
        return i.jsx("div", babelHelpers["extends"]({}, null, {
            className: "x1lliihq x5yr21d x1n2onr6 xh8yej3 x1ja2u2z",
            "data-testid": void 0,
            ref: b,
            children: c
        }))
    });
    e = i.forwardRef(function(a, b) {
        var d = a.debugRole;
        d = a.domElement;
        return i.jsx(c("DOMContainer.react"), babelHelpers["extends"]({}, null, {
            className: "x1lliihq x5yr21d x1n2onr6 xh8yej3 x1ja2u2z",
            display: "block",
            ref: b,
            children: d
        }))
    });

    function a(a) {
        a = a.debugRole;
        a = document.createElement("div");
        a.className = "x1lliihq x5yr21d x1n2onr6 xh8yej3 x1ja2u2z";
        return a
    }
    g.CoreVideoPlayerFitParentContainer = b;
    g.CoreVideoPlayerFitParentDOMContainer = e;
    g.createFitParentContainerDiv = a
}), 98);
__d("VideoPlayerPortalingPlaceInfoProvider.react", ["react", "recoverableViolation", "useEmptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    e = h;
    d = e.createContext;
    var j = e.useContext,
        k = e.useEffect,
        l = e.useMemo,
        m = d(null);

    function a(a) {
        var b = a.children,
            c = a.currentPlaceID,
            d = a.currentVideoID,
            e = a.portalingEnabled,
            f = a.previousPlaceMetaData,
            g = a.thisPlaceID;
        a = l(function() {
            return {
                currentPlaceID: c,
                currentVideoID: d,
                portalingEnabled: e,
                previousPlaceMetaData: f,
                thisPlaceID: g
            }
        }, [c, d, e, f, g]);
        return i.jsx(m.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var n = c("useEmptyFunction");

    function b() {
        var a = j(m);
        n(a);
        return a == null ? {
            currentPlaceID: null,
            currentVideoID: null,
            portalingEnabled: !1,
            previousPlaceMetaData: null,
            thisPlaceID: null
        } : a
    }
    g.VideoPlayerPortalingPlaceInfoProvider = a;
    g.useVideoPlayerPortalingPlaceInfo = b
}), 98);
__d("GlobalVideoPortsRenderers.react", ["CoreVideoPlayer.react", "VideoPlayerContexts", "VideoPlayerPortalingPlaceInfoProvider.react", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react")),
        k = h,
        l = k.useEffect,
        m = k.useState,
        n = c("emptyFunction").thatReturns(null);

    function a(a) {
        var b = a.coreVideoPlayerMetaData,
            e = a.currentPlaceID,
            f = a.currentVideoID,
            g = a.fullscreenController,
            h = a.implementations,
            i = a.isFullscreen,
            k = a.onCoreVideoStatesChanged,
            l = a.previousPlaceMetaData,
            m = a.trackingDataEncrypted,
            o = a.trackingNodes;
        a = a.viewportMarginsForViewability;
        var p = n;
        return j.jsx(d("VideoPlayerPortalingPlaceInfoProvider.react").VideoPlayerPortalingPlaceInfoProvider, {
            currentPlaceID: e,
            currentVideoID: f,
            portalingEnabled: !0,
            previousPlaceMetaData: l,
            thisPlaceID: e,
            children: j.jsx(c("CoreVideoPlayer.react"), babelHelpers["extends"]({}, b, {
                fullscreenController: g,
                implementations: h,
                isFullscreen: i,
                onCoreVideoStatesChanged: k,
                renderWithCoreVideoStates: p,
                trackingDataEncrypted: m,
                trackingNodes: o,
                viewportMarginsForViewability: a
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = a.currentPlaceID,
            c = a.currentVideoID,
            e = a.previousPlaceMetaData,
            f = a.renderPlaceholder,
            g = a.thisPlaceID;
        a = a.videoPixelsAspectRatio;
        return j.jsx(d("VideoPlayerPortalingPlaceInfoProvider.react").VideoPlayerPortalingPlaceInfoProvider, {
            currentPlaceID: b,
            currentVideoID: c,
            portalingEnabled: !0,
            previousPlaceMetaData: e,
            thisPlaceID: g,
            children: j.jsx((i || (i = d("VideoPlayerContexts"))).VideoPixelsAspectRatioContext.Provider, {
                value: a,
                children: f != null ? f() : null
            })
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";

    function e(a) {
        var b = a.currentPlaceID,
            c = a.currentVideoID,
            e = a.injectCoreVideoStatesRef,
            f = a.previousPlaceMetaData,
            g = a.renderComponents;
        a = a.thisPlaceID;
        var h = m(null),
            i = h[0],
            k = h[1];
        h = m(null);
        var n = h[0],
            o = h[1];
        l(function() {
            e.current = function(a, b) {
                a != null && o(function() {
                    return a
                }), k(b)
            };
            return function() {
                e.current = null
            }
        }, [e]);
        if (a === b && i != null) {
            if (n != null) throw n;
            return j.jsx(d("VideoPlayerPortalingPlaceInfoProvider.react").VideoPlayerPortalingPlaceInfoProvider, {
                currentPlaceID: b,
                currentVideoID: c,
                portalingEnabled: !0,
                previousPlaceMetaData: f,
                thisPlaceID: a,
                children: g(i)
            })
        } else return null
    }
    e.displayName = e.name + " [from " + f.id + "]";
    g.GlobalVideoPortsPlayerRenderer = a;
    g.GlobalVideoPortsPlaceholderRenderer = b;
    g.GlobalVideoPortsVideoComponentsRenderer = e
}), 98);
__d("MWChatDeleteMessageEventEmitter", ["BaseEventEmitter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "deleteMessage",
        i = new(c("BaseEventEmitter"))();

    function a(a) {
        i.emit(h, a)
    }

    function b(a) {
        var b = i.addListener(h, a);
        return function() {
            return b.remove()
        }
    }
    g.emit = a;
    g.subscribe = b
}), 98);
__d("WebSessionExtender", ["WebSession", "clearInterval", "cr:913", "setInterval"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 2e4,
        i = new Set(),
        j = null;

    function a(a, e) {
        e === void 0 && (e = "extender"), i.add(a), j == null && (d("WebSession").extend(Date.now() + h + 2e3), j = c("setInterval")(function() {
            d("WebSession").extend(Date.now() + h + 2e3), b("cr:913") && new(b("cr:913"))().setClientTime(Date.now()).setWebsessionID(d("WebSession").getId()).setReason(e).log()
        }, h))
    }

    function e(a) {
        i["delete"](a);
        a = i.size;
        a === 0 && j != null && (c("clearInterval")(j), j = null)
    }
    g.subscribe = a;
    g.unsubscribe = e
}), 98); /*FB_PKG_DELIM*/
__d("BaseCalloutImpl.react", ["BaseContextualLayer.react", "BaseContextualLayerAnchorRootContext", "LayoutAnimationBoundaryContext", "react", "useCometDisplayTimingTrackerForInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useEffect;

    function a(a) {
        var b = a.anchorRef,
            d = a.anchorRootRefContext,
            e = a.animationContext,
            f = a.children,
            g = a.contextualLayerProps,
            h = a.imperativeRef,
            k = a.scrollableAreaContext;
        a = c("useCometDisplayTimingTrackerForInteraction")("FDSCalloutManager");
        j(function() {
            var a = k.map(function(a) {
                    return a.getDOMNode()
                }).filter(Boolean),
                b = function() {
                    var a;
                    return (a = h.current) == null ? void 0 : a.reposition()
                };
            if (a.length > 0) {
                a.forEach(function(a) {
                    return a.addEventListener("scroll", b, {
                        passive: !0
                    })
                });
                return function() {
                    a.forEach(function(a) {
                        return a.removeEventListener("scroll", b, {
                            passive: !0
                        })
                    })
                }
            }
        }, [h, k]);
        return g == null || b == null ? null : i.jsx(c("LayoutAnimationBoundaryContext").Provider, {
            value: e,
            children: i.jsx(c("BaseContextualLayerAnchorRootContext").Provider, {
                value: d,
                children: g != null ? i.jsx(c("BaseContextualLayer.react"), {
                    align: g.align,
                    contextRef: b,
                    disableAutoAlign: g.disableAutoAlign,
                    disableAutoFlip: g.disableAutoFlip,
                    imperativeRef: h,
                    position: g.position,
                    ref: a,
                    children: f
                }) : null
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometRouterUIComponentsDefaultErrorRoot.react", ["cr:12338", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");
    g["default"] = b("cr:12338")
}), 98);
__d("FDSCalloutEdgeArrow.svg.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react");

    function a(a) {
        var b = a.children,
            d = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "xstyle"]);
        return j.jsxs("svg", babelHelpers["extends"]({
            "aria-hidden": !0,
            className: (h || (h = c("stylex")))(d),
            height: "12px",
            viewBox: "0 0 21 12",
            width: "21px"
        }, a, {
            children: [a.title != null && j.jsx("title", {
                children: a.title
            }), b != null && j.jsx("defs", {
                children: b
            }), j.jsx("path", {
                d: "M20.685.12c-2.229.424-4.278 1.914-6.181 3.403L5.4 10.94c-2.026 2.291-5.434.62-5.4-2.648V.12h20.684z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    g["default"] = a
}), 98);
__d("FDSCalloutEdge.react", ["BaseContextualLayerContextSizeContext", "BaseContextualLayerLayerAdjustmentContext", "BaseContextualLayerOrientationContext", "BaseRow.react", "BaseView.react", "CometHideLayerOnEscape.react", "FDSCalloutEdgeArrow.svg.react", "FocusRegionStrictMode.react", "Locale", "focusScopeQueries", "react", "useOnOutsideClick"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            arrow: {
                position: "x10l6tqk",
                $$css: !0
            },
            container: {
                display: "x78zum5",
                $$css: !0
            },
            content: {
                backgroundColor: "x1h0vfkc",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                borderTopWidth: "x178xt8z",
                borderEndWidth: "xm81vs4",
                borderBottomWidth: "xso031l",
                borderStartWidth: "xy80clv",
                boxShadow: "xofhs1l",
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v",
                paddingStart: "x1ye3gou",
                paddingEnd: "xn6708d",
                paddingLeft: null,
                paddingRight: null,
                $$css: !0
            }
        },
        l = {
            accent: {
                backgroundColor: "xdk9wry",
                $$css: !0
            },
            "default": {
                backgroundColor: "x9bbmet",
                $$css: !0
            }
        },
        m = {
            end: {
                borderBottomEndRadius: "x5pf9jr",
                marginBottom: "xieb3on",
                $$css: !0
            },
            middle: {
                marginBottom: "x12nagc",
                $$css: !0
            },
            start: {
                borderBottomStartRadius: "xo71vjh",
                marginBottom: "xieb3on",
                $$css: !0
            }
        },
        n = {
            end: {
                borderTopEndRadius: "x13lgxp2",
                marginTop: "x1sy10c2",
                $$css: !0
            },
            middle: {
                marginTop: "x1gslohp",
                $$css: !0
            },
            start: {
                borderTopStartRadius: "x168nmei",
                marginTop: "x1sy10c2",
                $$css: !0
            }
        },
        o = {
            end: {
                bottom: "x7ofzsv",
                end: "xds687c",
                left: null,
                right: null,
                transform: "xpk2tj9",
                $$css: !0
            },
            middle: {
                bottom: "x7ofzsv",
                end: "xds687c",
                left: null,
                right: null,
                $$css: !0
            },
            start: {
                bottom: "x7ofzsv",
                start: "x17qophe",
                left: null,
                right: null,
                $$css: !0
            }
        },
        p = {
            end: {
                $$css: !0
            },
            middle: {
                $$css: !0
            },
            start: {
                $$css: !0
            }
        },
        q = {
            end: {
                bottom: "x7ofzsv",
                end: "xds687c",
                left: null,
                right: null,
                transform: "xpk2tj9",
                $$css: !0
            },
            middle: {
                bottom: "x7ofzsv",
                end: "xds687c",
                left: null,
                right: null,
                $$css: !0
            },
            start: {
                bottom: "x7ofzsv",
                start: "x17qophe",
                left: null,
                right: null,
                $$css: !0
            }
        },
        r = {
            end: {
                $$css: !0
            },
            middle: {
                $$css: !0
            },
            start: {
                $$css: !0
            }
        },
        s = {
            end: {
                end: "xds687c",
                left: null,
                right: null,
                top: "x1nl0pjx",
                transform: "x19jd1h0",
                $$css: !0
            },
            middle: {
                end: "xds687c",
                left: null,
                right: null,
                top: "x1nl0pjx",
                transform: "x1oihik5",
                $$css: !0
            },
            start: {
                start: "x17qophe",
                left: null,
                right: null,
                top: "x1nl0pjx",
                transform: "x1oihik5",
                $$css: !0
            }
        },
        t = {
            end: {
                transform: "x19jd1h0",
                $$css: !0
            },
            middle: {
                transform: "x1oihik5",
                $$css: !0
            },
            start: {
                transform: "x1oihik5",
                $$css: !0
            }
        },
        u = {
            end: {
                end: "xds687c",
                left: null,
                right: null,
                top: "x1nl0pjx",
                transform: "x19jd1h0",
                $$css: !0
            },
            middle: {
                end: "xds687c",
                left: null,
                right: null,
                top: "x1nl0pjx",
                transform: "x1oihik5",
                $$css: !0
            },
            start: {
                start: "x17qophe",
                left: null,
                right: null,
                top: "x1nl0pjx",
                transform: "x1oihik5",
                $$css: !0
            }
        },
        v = {
            end: {
                transform: "x19jd1h0",
                $$css: !0
            },
            middle: {
                transform: "x1oihik5",
                $$css: !0
            },
            start: {
                transform: "x1oihik5",
                $$css: !0
            }
        };

    function w(a) {
        if (a === "start") return "end";
        return a === "end" ? "start" : a
    }

    function a(a) {
        var b, e = a.children,
            f = a.disableAutoFocus;
        f = f === void 0 ? !1 : f;
        var g = a.id,
            h = a.onClose,
            o = a.onOutsideClick,
            p = a.type;
        p = p === void 0 ? "default" : p;
        var q = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "disableAutoFocus", "id", "onClose", "onOutsideClick", "type", "xstyle"]);
        var r = j(c("BaseContextualLayerOrientationContext")),
            s = r.align;
        r = r.position;
        s = s === "stretch" ? "start" : s;
        r = r === "start" ? "above" : r === "end" ? "below" : r;
        var t = j(c("BaseContextualLayerContextSizeContext"));
        b = (b = j(c("BaseContextualLayerLayerAdjustmentContext"))) != null ? b : 0;
        s = b !== 0 ? w(s) : s;
        t = z(s, (t = t == null ? void 0 : t.width) != null ? t : 0, b);
        b = c("useOnOutsideClick")(o);
        return i.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            id: (o = g) != null ? o : void 0,
            role: "dialog",
            style: t,
            xstyle: k.container,
            children: i.jsx(d("FocusRegionStrictMode.react").FocusRegion, {
                autoFocusQuery: f ? void 0 : d("focusScopeQueries").tabbableScopeQuery,
                children: i.jsxs(c("CometHideLayerOnEscape.react"), {
                    onHide: h,
                    children: [i.jsx(c("BaseRow.react"), {
                        ref: b,
                        xstyle: [k.content, l[p], r === "above" && m[s], r === "below" && n[s], q],
                        children: e
                    }), i.jsx(y, {
                        align: s,
                        position: r,
                        type: p
                    })]
                })
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var x = c("Locale").isRTL();

    function y(a) {
        var b = a.align,
            d = a.position;
        a = a.type;
        return i.jsx(c("FDSCalloutEdgeArrow.svg.react"), {
            fill: a === "default" ? "var(--popover-background)" : "var(--callout-background-color-accent, var(--accent))",
            xstyle: [k.arrow, d === "above" && a === "default" && (x ? p[b] : o[b]), d === "above" && a === "accent" && (x ? r[b] : q[b]), d === "below" && a === "default" && (x ? t[b] : s[b]), d === "below" && a === "accent" && (x ? v[b] : u[b])]
        })
    }
    y.displayName = y.name + " [from " + f.id + "]";

    function z(a, b, c) {
        c = c === 0 ? b / 2 : 0;
        if (c === 0) return void 0;
        if (a === "start") return {
            transform: "translateX(" + (x ? -1 * c : c) + "px)"
        };
        return a === "end" ? {
            transform: "translateX(" + (x ? c : -1 * c) + "px)"
        } : void 0
    }
    g["default"] = a
}), 98);
__d("FDSCalloutInsetArrow.svg.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react");

    function a(a) {
        var b = a.children,
            d = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "xstyle"]);
        return j.jsxs("svg", babelHelpers["extends"]({
            "aria-hidden": !0,
            className: (h || (h = c("stylex")))(d),
            height: "12px",
            viewBox: "0 0 21 12",
            width: "21px"
        }, a, {
            children: [a.title != null && j.jsx("title", {
                children: a.title
            }), b != null && j.jsx("defs", {
                children: b
            }), j.jsx("path", {
                d: "M20.685.12c-2.229.424-4.278 1.914-6.181 3.403L5.4 10.94c-2.026 2.291-5.434.62-5.4-2.648V.12h20.684z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    g["default"] = a
}), 98);
__d("FDSCalloutInset.react", ["BaseContextualLayerContextSizeContext", "BaseContextualLayerLayerAdjustmentContext", "BaseContextualLayerOrientationContext", "BaseRow.react", "BaseView.react", "CometHideLayerOnEscape.react", "FDSCalloutInsetArrow.svg.react", "FocusRegionStrictMode.react", "Locale", "focusScopeQueries", "react", "useOnOutsideClick"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            arrow: {
                position: "x10l6tqk",
                $$css: !0
            },
            container: {
                display: "x78zum5",
                $$css: !0
            },
            content: {
                backgroundColor: "x1h0vfkc",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                borderTopWidth: "x178xt8z",
                borderEndWidth: "xm81vs4",
                borderBottomWidth: "xso031l",
                borderStartWidth: "xy80clv",
                boxShadow: "xofhs1l",
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v",
                paddingStart: "x1ye3gou",
                paddingEnd: "xn6708d",
                paddingLeft: null,
                paddingRight: null,
                $$css: !0
            }
        },
        l = {
            accent: {
                backgroundColor: "xdk9wry",
                $$css: !0
            },
            "default": {
                backgroundColor: "x9bbmet",
                $$css: !0
            }
        },
        m = {
            above: {
                marginBottom: "x1yztbdb",
                $$css: !0
            },
            below: {
                marginTop: "xw7yly9",
                $$css: !0
            },
            end: {
                marginStart: "x1d52u69",
                $$css: !0
            }
        },
        n = {
            above: {
                bottom: "x1wa3icf",
                $$css: !0
            },
            below: {
                top: "x1jzctok",
                transform: "x1oihik5",
                $$css: !0
            },
            end: {
                $$css: !0
            }
        },
        o = {
            above: {
                bottom: "x1wa3icf",
                $$css: !0
            },
            below: {
                top: "x1jzctok",
                transform: "x1oihik5",
                $$css: !0
            },
            end: {
                $$css: !0
            }
        };

    function a(a) {
        var b, e = a.children,
            f = a.disableAutoFocus;
        f = f === void 0 ? !1 : f;
        var g = a.id,
            h = a.onClose,
            n = a.onOutsideClick,
            o = a.type;
        o = o === void 0 ? "default" : o;
        var q = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "disableAutoFocus", "id", "onClose", "onOutsideClick", "type", "xstyle"]);
        var s = j(c("BaseContextualLayerOrientationContext")),
            t = s.align;
        s = s.position;
        t = t === "stretch" ? "start" : t;
        s = s === "start" ? "above" : s === "end" ? "below" : s;
        var u = j(c("BaseContextualLayerContextSizeContext"));
        b = (b = j(c("BaseContextualLayerLayerAdjustmentContext"))) != null ? b : 0;
        u = r(t, s, (t = u == null ? void 0 : u.width) != null ? t : 0, b);
        t = u[0];
        b = u[1];
        u = c("useOnOutsideClick")(n);
        return i.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            id: (n = g) != null ? n : void 0,
            role: "dialog",
            style: t,
            xstyle: k.container,
            children: i.jsx(d("FocusRegionStrictMode.react").FocusRegion, {
                autoFocusQuery: f ? void 0 : d("focusScopeQueries").tabbableScopeQuery,
                children: i.jsxs(c("CometHideLayerOnEscape.react"), {
                    onHide: h,
                    children: [i.jsx(c("BaseRow.react"), {
                        ref: u,
                        xstyle: [k.content, l[o], m[s], q],
                        children: e
                    }), i.jsx(p, {
                        arrowStyles: b,
                        position: s,
                        type: o
                    })]
                })
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function p(a) {
        var b = a.arrowStyles,
            d = a.position;
        a = a.type;
        return i.jsx(c("FDSCalloutInsetArrow.svg.react"), {
            fill: a === "default" ? "var(--popover-background)" : "var(--callout-background-color-accent, var(--accent))",
            style: b,
            xstyle: [k.arrow, n[d], a === "accent" && o[d]]
        })
    }
    p.displayName = p.name + " [from " + f.id + "]";
    var q = c("Locale").isRTL();

    function r(a, b, c, d) {
        var e = Math.max(c / 2 - 8, 16) + Math.abs(d),
            f = c / 2 - 8 < 16;
        c = 24 - c / 2;
        if (b === "above")
            if (a === "start") {
                var g;
                b = q ? "right" : "left";
                return [f ? {
                    transform: "translateX(" + (q ? c : -c) + "px)"
                } : void 0, (g = {}, g[b] = "min(calc(100% - 32px), " + e + "px)", g)]
            } else if (a === "end") {
            b = q ? "left" : "right";
            return [f ? {
                transform: "translateX(" + (q ? -c : c) + "px)"
            } : void 0, (g = {}, g[b] = "min(calc(100% - 32px), " + e + "px)", g)]
        } else {
            var h;
            b = q ? "left" : "right";
            g = (q ? -d : d) - 8;
            return [void 0, (h = {}, h[b] = "calc(50% + " + g + "px)", h)]
        } else if (a === "start") {
            b = q ? "right" : "left";
            return [f ? {
                transform: "translateX(" + (q ? c : -c) + "px)"
            } : void 0, (g = {}, g[b] = "min(calc(100% - 32px), " + e + "px)", g)]
        } else if (a === "end") {
            h = q ? "left" : "right";
            return [f ? {
                transform: "translateX(" + (q ? -c : c) + "px)"
            } : void 0, (b = {}, b[h] = "min(calc(100% - 32px), " + e + "px)", b)]
        } else {
            g = q ? "left" : "right";
            a = (q ? -d : d) - 8;
            return [void 0, (f = {}, f[g] = "calc(50% + " + a + "px)", f)]
        }
    }
    g["default"] = a
}), 98);
__d("FDSCallout.react", ["fbt", "ix", "BaseContextualLayerOrientationContext", "BaseRow.react", "BaseRowItem.react", "BaseView.react", "CometColumn.react", "CometColumnItem.react", "CometErrorBoundary.react", "CometHideLayerOnEscape.react", "FDSCalloutEdge.react", "FDSCalloutInset.react", "FDSIcon.react", "FDSTextPairing.react", "FocusRegionStrictMode.react", "fbicon", "focusScopeQueries", "react", "unrecoverableViolation", "useOnOutsideClick", "useVisibilityObserver"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = j || (j = d("react"));
    b = j;
    var l = b.useContext,
        m = b.useMemo,
        n = {
            container: {
                display: "x78zum5",
                $$css: !0
            },
            content: {
                backgroundColor: "x1h0vfkc",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                borderTopWidth: "x178xt8z",
                borderEndWidth: "xm81vs4",
                borderBottomWidth: "xso031l",
                borderStartWidth: "xy80clv",
                boxShadow: "xofhs1l",
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v",
                paddingStart: "x1ye3gou",
                paddingEnd: "xn6708d",
                paddingLeft: null,
                paddingRight: null,
                $$css: !0
            },
            crossoutButton: {
                marginEnd: "xcud41i",
                marginTop: "x9otpla",
                $$css: !0
            },
            item: {
                paddingTop: "x1yrsyyn",
                paddingBottom: "x10b6aqq",
                paddingStart: "x16hj40l",
                paddingEnd: "xsyo7zv",
                paddingLeft: null,
                paddingRight: null,
                $$css: !0
            }
        },
        o = {
            accent: {
                backgroundColor: "xdk9wry",
                $$css: !0
            },
            "default": {
                backgroundColor: "x9bbmet",
                $$css: !0
            }
        },
        p = {
            above: {
                marginBottom: "x12nagc",
                $$css: !0
            },
            below: {
                marginTop: "x1gslohp",
                $$css: !0
            },
            end: {
                marginStart: "xsgj6o6",
                $$css: !0
            },
            start: {
                $$css: !0
            }
        };

    function a(a) {
        var b = a.arrowStyle;
        b = b === void 0 ? "none" : b;
        var e = a.calloutID,
            f = a.content,
            g = a.contentID,
            j = a.disableAutoFocus;
        j = j === void 0 ? !1 : j;
        var q = a.onClose,
            r = a.onHide,
            s = a.onOutsideClick,
            t = a.onShow,
            u = a.titleID,
            v = a.type;
        v = v === void 0 ? "default" : v;
        var w = a.xstyle,
            x = a.addOn,
            y = a["aria-label"],
            z = a.hasCloseButton;
        z = z === void 0 ? !0 : z;
        var A = a.title;
        a = l(c("BaseContextualLayerOrientationContext"));
        a = a.position;
        var B = c("useOnOutsideClick")(s);
        r = c("useVisibilityObserver")({
            onHidden: r,
            onVisible: t
        });
        t = v === "default" ? "primary" : "white";
        if (a === "end" && (b === "inset" || b === "edge")) throw c("unrecoverableViolation")('"end" position with arrow is not supported yet', "comet_ui");
        var C = m(function() {
            return A != null ? {
                "aria-describedby": g,
                "aria-labelledby": u
            } : {
                "aria-describedby": g,
                "aria-label": y
            }
        }, [y, g, A, u]);
        r = k.jsxs(c("CometColumn.react"), {
            children: [k.jsx(c("CometColumnItem.react"), {
                children: k.jsxs(c("BaseRow.react"), {
                    children: [k.jsx(c("BaseRowItem.react"), {
                        expanding: !0,
                        ref: r,
                        verticalAlign: "center",
                        xstyle: n.item,
                        children: k.jsx(c("FDSTextPairing.react"), {
                            body: f,
                            bodyColor: t,
                            bodyId: g,
                            headline: A,
                            headlineColor: t,
                            headlineId: u,
                            isSemanticHeading: !0,
                            level: 3
                        })
                    }), z && k.jsx(c("BaseRowItem.react"), {
                        xstyle: [n.crossoutButton, n.item],
                        children: k.jsx(c("FDSIcon.react"), {
                            "aria-label": h._("__JHASH__cCrSTii9yXy__JHASH__"),
                            color: v === "default" ? "secondary" : "white",
                            focusable: !0,
                            icon: d("fbicon")._(i("478232"), 16),
                            onPress: q,
                            size: 16
                        })
                    })]
                })
            }), x != null && k.jsx(c("CometColumnItem.react"), {
                paddingTop: 12,
                children: k.jsx(c("BaseRow.react"), {
                    children: k.jsx(c("BaseRowItem.react"), {
                        expanding: !0,
                        verticalAlign: "center",
                        xstyle: n.item,
                        children: x
                    })
                })
            })]
        });
        if (b === "inset") return k.jsx(c("FDSCalloutInset.react"), babelHelpers["extends"]({}, C, {
            disableAutoFocus: j,
            id: e,
            onClose: q,
            onOutsideClick: s,
            type: v,
            xstyle: w,
            children: r
        }));
        return b === "edge" ? k.jsx(c("FDSCalloutEdge.react"), babelHelpers["extends"]({}, C, {
            disableAutoFocus: j,
            id: e,
            onClose: q,
            onOutsideClick: s,
            type: v,
            xstyle: w,
            children: r
        })) : k.jsx(c("CometErrorBoundary.react"), {
            fallback: function() {
                return k.jsx("div", {})
            },
            children: k.jsx(c("BaseView.react"), babelHelpers["extends"]({}, C, {
                id: (f = e) != null ? f : void 0,
                role: "dialog",
                xstyle: n.container,
                children: k.jsx(d("FocusRegionStrictMode.react").FocusRegion, {
                    autoFocusQuery: j ? void 0 : d("focusScopeQueries").tabbableScopeQuery,
                    children: k.jsx(c("CometHideLayerOnEscape.react"), {
                        onHide: q,
                        children: k.jsx(c("BaseRow.react"), {
                            ref: B,
                            xstyle: [n.content, o[v], b === "none" && p[a], w],
                            children: r
                        })
                    })
                })
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("FDSCalloutImpl.react", ["BaseCalloutImpl.react", "FDSCallout.react", "FDSCalloutContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext;

    function a(a) {
        var b = a.calloutID,
            d = a.calloutProps,
            e = a.contentID,
            f = a.titleID,
            g = j(c("FDSCalloutContext"));
        if (g == null || d == null) return null;
        var h = d.disableOutsideClick,
            k = d.onClose;
        d = babelHelpers.objectWithoutPropertiesLoose(d, ["disableOutsideClick", "onClose"]);
        return i.jsx(c("BaseCalloutImpl.react"), babelHelpers["extends"]({}, a, {
            children: i.jsx(c("FDSCallout.react"), babelHelpers["extends"]({}, d, {
                calloutID: b,
                contentID: e,
                onClose: function() {
                    g.removeCallout(b), k == null ? void 0 : k()
                },
                onOutsideClick: function() {
                    h !== !0 && (g.removeCallout(b), k == null ? void 0 : k())
                },
                titleID: f
            }))
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("addToMap", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        if (a.get(b) === c) return a;
        a = new Map(a);
        a.set(b, c);
        return a
    }
    f["default"] = a
}), 66);
__d("removeFromMap", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        if (a.has(b)) {
            var c = new Map(a);
            c["delete"](b);
            return c
        }
        return a
    }
    f["default"] = a
}), 66);
__d("GlobalVideoPortsManager", ["addToMap", "emptyFunction", "gkx", "removeFromMap"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        var d = a.get(b);
        d != null && (d.portablePlaceContainer = null);
        return c("removeFromMap")(a, b)
    }
    a = c("emptyFunction");

    function i(a) {
        return a.unlinkedAtTimestampMs !== null
    }
    var j = 1e4;
    b = function() {
        function a(a) {
            var b = this;
            this.$1 = function(c) {
                var d = function(a) {
                    return c(b.$2(a))
                };
                a(d)
            }
        }
        var b = a.prototype;
        b.addOrUpdatePlace = function(a) {
            var b = this,
                d = a.coreVideoPlayerMetaData,
                e = a.fullscreenController,
                f = a.implementations,
                g = a.injectCoreVideoStatesRef,
                j = a.isFullscreen,
                k = a.portablePlaceContainer,
                l = a.portablePlaceID,
                m = a.portablePlaceMetaData,
                n = a.portableVideoID,
                o = a.renderComponents,
                p = a.renderPlaceholder,
                q = a.trackingDataEncrypted,
                r = a.trackingNodes,
                s = a.viewportMarginsForViewability;
            this.$1(function(a) {
                var t, u = b.getPortableVideoState(a, n),
                    v = (t = a.places.get(l)) != null ? t : null;
                t = v != null && !i(v) ? v.sequenceNumber : a.placesSequenceNumberNext;
                var w = t === a.placesSequenceNumberNext ? a.placesSequenceNumberNext + 1 : a.placesSequenceNumberNext,
                    x = m || {},
                    y = a.places;
                if (n != null) {
                    var z = b.getPlacesBorrowingThisVideo(y, n);
                    z.forEach(function(a) {
                        i(a) && a.portablePlaceID !== (v == null ? void 0 : v.portablePlaceID) && (y = h(y, a.portablePlaceID))
                    })
                }
                y = c("addToMap")(y, l, babelHelpers["extends"]({}, v, {
                    coreVideoPlayerMetaData: d,
                    currentVideoID: n,
                    fullscreenController: e,
                    implementations: f,
                    injectCoreVideoStatesRef: g,
                    isFullscreen: j,
                    portablePlaceContainer: k,
                    portablePlaceID: l,
                    portablePlaceMetaData: x,
                    renderComponents: o,
                    renderPlaceholder: (z = p) != null ? z : null,
                    sequenceNumber: t,
                    trackingDataEncrypted: q,
                    trackingNodes: r,
                    unlinkedAtTimestampMs: null,
                    viewportMarginsForViewability: s
                }));
                x = v !== null && n === null ? v.currentVideoID : null;
                z = a.videos;
                if (x !== null) {
                    t = b.getPlacesBorrowingThisVideo(y, x);
                    t = 0 === t.length;
                    t && (z = c("removeFromMap")(a.videos, x))
                }
                if (n !== null) {
                    t = b.updatePreviousPlaceMetaDataInfoForVideo({
                        existingVideoState: u,
                        places: a.places,
                        setPreferredPlaceForVideo: !1,
                        updatedPlaces: y,
                        videoID: n
                    });
                    x = t.nextPreviousPlaceMetaData;
                    z = c("addToMap")(z, n, u ? babelHelpers["extends"]({}, u, {
                        portableVideoID: n,
                        previousPlaceMetaData: x
                    }) : {
                        portableVideoID: n,
                        preferredPlaceID: null,
                        previousPlaceMetaData: x
                    })
                }
                return y === a.places && w === a.placesSequenceNumberNext && z === a.videos ? a : babelHelpers["extends"]({}, a, {
                    places: y,
                    placesSequenceNumberNext: w,
                    videos: z
                })
            })
        };
        b.removePlace = function(a) {
            var b = this,
                d = a.portablePlaceID,
                e = Date.now();
            this.$1(function(a) {
                var f;
                f = (f = a.places.get(d)) != null ? f : null;
                var g = f !== null ? f.currentVideoID : null;
                if (f === null) return a;
                var i = a.places,
                    j = g !== null ? b.skipUnlinkedPlaces(b.getPlacesBorrowingThisVideo(i, g)).filter(function(a) {
                        return a.portablePlaceID !== d
                    }) : [];
                g !== null && j.length === 0 ? i = c("addToMap")(i, d, babelHelpers["extends"]({}, f, {
                    unlinkedAtTimestampMs: e
                })) : i = h(i, d);
                j = a.videos;
                if (g !== null) {
                    f = b.getPlacesBorrowingThisVideo(i, g);
                    f = 0 === f.length;
                    if (f) j = c("removeFromMap")(j, g);
                    else {
                        f = b.getPortableVideoState(a, g);
                        var k = b.updatePreviousPlaceMetaDataInfoForVideo({
                                existingVideoState: f,
                                places: a.places,
                                setPreferredPlaceForVideo: !1,
                                updatedPlaces: i,
                                videoID: g
                            }),
                            l = k.nextPreviousPlaceMetaData;
                        k = k.shouldUpdatePreviousPlaceMetaDataForVideo;
                        f != null && k && (j = c("addToMap")(j, g, babelHelpers["extends"]({}, f, {
                            portableVideoID: g,
                            previousPlaceMetaData: l
                        })))
                    }
                }
                return i === a.places && j === a.videos ? a : babelHelpers["extends"]({}, a, {
                    places: i,
                    videos: j
                })
            })
        };
        b.setPreferredPlaceForVideo = function(a) {
            var b = this,
                d = a.portablePlaceID,
                e = a.portableVideoID;
            this.$1(function(a) {
                var f = b.getPortableVideoState(a, e),
                    g = d != null ? a.places.get(d) : null,
                    h = b.updatePreviousPlaceMetaDataInfoForVideo({
                        existingPlaceStateForSetPreferredPlaceForVideo: g,
                        existingVideoState: f,
                        places: a.places,
                        preferredPlaceID: d,
                        setPreferredPlaceForVideo: !0,
                        updatedPlaces: a.places,
                        videoID: e
                    });
                h = h.nextPreviousPlaceMetaData;
                f = f != null ? c("addToMap")(a.videos, e, babelHelpers["extends"]({}, f, {
                    preferredPlaceID: g != null && d != null ? d : null,
                    previousPlaceMetaData: h
                })) : a.videos;
                return f === a.videos ? a : babelHelpers["extends"]({}, a, {
                    videos: f
                })
            })
        };
        b.getPlacesBorrowingThisVideo = function(a, b) {
            var c = [];
            a.forEach(function(a) {
                a.currentVideoID === b && c.push(a)
            });
            return c
        };
        b.skipUnlinkedPlaces = function(a) {
            return a.filter(function(a) {
                return !i(a)
            })
        };
        b.selectCurrentPlaceFromThesePlaces = function(a, b) {
            var c;
            a = a.slice().sort(function(a, b) {
                return a.sequenceNumber - b.sequenceNumber
            });
            c = (c = a.find(function(a) {
                return a.portablePlaceID === b
            })) != null ? c : null;
            a = a.length > 0 ? a[a.length - 1] : null;
            return (c = (c = c) != null ? c : a) != null ? c : null
        };
        b.getCurrentPlaceStateForVideo = function(a, b) {
            var c = this.getPortableVideoState(a, b);
            if (c != null && b != null) {
                a = this.selectCurrentPlaceFromThesePlaces(this.skipUnlinkedPlaces(this.getPlacesBorrowingThisVideo(a.places, b)), c.preferredPlaceID);
                return (b = a) != null ? b : null
            } else return null
        };
        b.getPortableVideoState = function(a, b) {
            if (b != null) {
                a = a.videos.get(b);
                return (b = a) != null ? b : null
            }
            return null
        };
        b.updatePreviousPlaceMetaDataInfoForVideo = function(a) {
            var b = this,
                c = a.existingPlaceStateForSetPreferredPlaceForVideo,
                d = a.existingVideoState,
                e = a.places,
                f = a.preferredPlaceID,
                g = a.setPreferredPlaceForVideo,
                h = a.updatedPlaces,
                i = a.videoID;
            a = function(a, c) {
                return b.selectCurrentPlaceFromThesePlaces(b.skipUnlinkedPlaces(b.getPlacesBorrowingThisVideo(a, i)), (a = c) != null ? a : null)
            };
            var j = a(e, d == null ? void 0 : d.preferredPlaceID);
            g ? g = c != null ? a(e, f) : null : g = a(h, d == null ? void 0 : d.preferredPlaceID);
            e = j != null && (j == null ? void 0 : j.portablePlaceID) !== ((c = g) == null ? void 0 : c.portablePlaceID);
            return {
                nextPreviousPlaceMetaData: e && j != null ? j.portablePlaceMetaData : (f = d == null ? void 0 : d.previousPlaceMetaData) != null ? f : null,
                shouldUpdatePreviousPlaceMetaDataForVideo: e
            }
        };
        b.collectGarbage = function() {
            this.$1(function(a) {
                return a
            })
        };
        b.$2 = function(a) {
            var b = Date.now(),
                d = new Set(),
                e = a.places;
            a.places.forEach(function(a) {
                a.unlinkedAtTimestampMs !== null && b - a.unlinkedAtTimestampMs >= j ? e = h(e, a.portablePlaceID) : a.currentVideoID !== null && d.add(a.currentVideoID)
            });
            var f = a.videos;
            a.videos.forEach(function(a) {
                d.has(a.portableVideoID) || (f = c("removeFromMap")(f, a.portableVideoID))
            });
            return e === a.places && f === a.videos ? a : babelHelpers["extends"]({}, a, {
                places: e,
                videos: f
            })
        };
        return a
    }();
    g.isUnlinkedGlobalVideoPortsPlace = i;
    g.UNLINKED_PLACE_TIMEOUT_MS = j;
    g.GlobalVideoPortsManager = b
}), 98);
__d("GlobalVideoPortsPortalerErrorBoundary.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.state = {
                errorRaw: null
            }, c.suppressReactDefaultErrorLoggingIUnderstandThisWillMakeBugsHarderToFindAndFix = !0, b) || babelHelpers.assertThisInitialized(c)
        }
        b.getDerivedStateFromError = function(a) {
            return {
                errorRaw: a
            }
        };
        var c = b.prototype;
        c.componentDidCatch = function(a, b) {
            b = this.props.onError;
            b != null && b(a)
        };
        c.render = function() {
            var a = this.props,
                b = a.children;
            a = a.fallback;
            var c = this.state.errorRaw;
            return c != null ? typeof a === "function" ? a(b) : a : b
        };
        return b
    }(a.PureComponent);
    g["default"] = b
}), 98);
__d("everySet", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        var d = a.entries(),
            e = d.next();
        while (!e.done) {
            var f = e.value;
            if (!b.call(c, f[1], f[0], a)) return !1;
            e = d.next()
        }
        return !0
    }
    f["default"] = a
}), 66);
__d("equalsSet", ["everySet"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return a.size !== b.size ? !1 : c("everySet")(a, function(a) {
            return b.has(a)
        })
    }
    g["default"] = a
}), 98);
__d("GlobalVideoPortsPortaler.react", ["CoreVideoPlayerFitParentContainer.react", "GlobalVideoPortsPortalerErrorBoundary.react", "GlobalVideoPortsRenderers.react", "ReactDOM", "equalsSet", "react", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useEffect,
        l = b.useRef,
        m = b.useState;

    function n(a, b, d, e, f) {
        var g = l(null);
        k(function() {
            var h, i = g.current;
            h = new Set((h = a.map(function(a) {
                return a.portablePlaceID
            })) != null ? h : []);
            if (i == null || !c("equalsSet")(i, h)) {
                g.current = h;
                i = b.current;
                h = d.current;
                i != null && e(i);
                h != null && f(h)
            }
        })
    }

    function a(a) {
        var b = a.globalVideoPortsManager,
            e = a.globalVideoPortsState,
            f = a.thisVideoID;
        a = m(function() {
            return d("CoreVideoPlayerFitParentContainer.react").createFitParentContainerDiv({
                debugRole: null
            })
        });
        var g = a[0],
            i = l(null),
            k = (h || (h = c("useUnsafeRef_DEPRECATED")))(null),
            o = (a = e.videos.get(f)) != null ? a : null,
            p = b.getPlacesBorrowingThisVideo(e.places, f);
        a = p.length <= 0;
        e = a ? null : b.selectCurrentPlaceFromThesePlaces(p, o ? o.preferredPlaceID : null);
        var q = a ? null : b.selectCurrentPlaceFromThesePlaces(b.skipUnlinkedPlaces(p), o ? o.preferredPlaceID : null);
        b = function(a) {
            k.current = a, p.forEach(function(b) {
                b = b.injectCoreVideoStatesRef.current;
                b && b(i.current, a)
            })
        };
        var r = function() {
                return null
            },
            s = function(a) {
                i.current = a, p.forEach(function(a) {
                    a = a.injectCoreVideoStatesRef.current;
                    a && a(i.current, k.current)
                })
            };
        n(p, k, i, b, s);
        return a ? null : j.jsxs(j.Fragment, {
            children: [d("ReactDOM").createPortal(e ? j.jsx(c("GlobalVideoPortsPortalerErrorBoundary.react"), {
                description: "GlobalVideoPortsPortaler",
                fallback: r,
                onError: s,
                children: j.jsx(d("GlobalVideoPortsRenderers.react").GlobalVideoPortsPlayerRenderer, {
                    coreVideoPlayerMetaData: e.coreVideoPlayerMetaData,
                    currentPlaceID: e.portablePlaceID,
                    currentVideoID: f,
                    fullscreenController: e.fullscreenController,
                    implementations: e.implementations,
                    isFullscreen: e.isFullscreen,
                    onCoreVideoStatesChanged: b,
                    previousPlaceMetaData: (a = o == null ? void 0 : o.previousPlaceMetaData) != null ? a : null,
                    trackingDataEncrypted: e.trackingDataEncrypted,
                    trackingNodes: e.trackingNodes,
                    viewportMarginsForViewability: e.viewportMarginsForViewability
                })
            }) : null, g), p.map(function(a) {
                var b;
                return d("ReactDOM").createPortal(a.portablePlaceID === (q == null ? void 0 : q.portablePlaceID) ? j.jsx(d("CoreVideoPlayerFitParentContainer.react").CoreVideoPlayerFitParentDOMContainer, {
                    debugRole: null,
                    domElement: g
                }) : j.jsx(d("GlobalVideoPortsRenderers.react").GlobalVideoPortsPlaceholderRenderer, {
                    currentPlaceID: (b = q == null ? void 0 : q.portablePlaceID) != null ? b : null,
                    currentVideoID: f,
                    previousPlaceMetaData: (b = o == null ? void 0 : o.previousPlaceMetaData) != null ? b : null,
                    renderPlaceholder: a.renderPlaceholder,
                    thisPlaceID: a.portablePlaceID,
                    videoPixelsAspectRatio: (b = a.coreVideoPlayerMetaData.videoPixelsAspectRatio) != null ? b : null
                }), a.portablePlaceContainer)
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("GlobalVideoPortsImpl.react", ["CometErrorBoundary.react", "GlobalVideoPortsContexts", "GlobalVideoPortsManager", "GlobalVideoPortsPortaler.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useEffect;

    function a(a) {
        var b = a.setGlobalVideoPortsManager;
        j(function() {
            var a = function(a) {
                return new(d("GlobalVideoPortsManager").GlobalVideoPortsManager)(a)
            };
            b(a)
        }, [b]);
        var e = [],
            f = d("GlobalVideoPortsContexts").useGlobalVideoPortsManager(),
            g = d("GlobalVideoPortsContexts").useGlobalVideoPortsState();
        f && g && g.videos.forEach(function(a, b) {
            e.push(i.jsx(c("CometErrorBoundary.react"), {
                children: i.jsx(c("GlobalVideoPortsPortaler.react"), {
                    globalVideoPortsManager: f,
                    globalVideoPortsState: g,
                    thisVideoID: b
                })
            }, b))
        });
        return i.jsx(i.Fragment, {
            children: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("FalcoAppUniverse", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        FACEBOOK: 1,
        INSTAGRAM: 2,
        OCULUS: 3
    });
    c = a;
    f["default"] = c
}), 66);
__d("Queue", [], (function(a, b, c, d, e, f) {
    var g = {};
    a = function() {
        function a(a) {
            this._timeout = null, this._interval = (a == null ? void 0 : a.interval) || 0, this._processor = a == null ? void 0 : a.processor, this._queue = [], this._stopped = !0
        }
        var b = a.prototype;
        b._dispatch = function(a) {
            var b = this;
            a === void 0;
            if (this._stopped || this._queue.length === 0) return;
            a = this._processor;
            if (a == null) {
                this._stopped = !0;
                throw new Error("No processor available")
            }
            var c = this._interval;
            if (c != null) a.call(this, this._queue.shift()), this._timeout = setTimeout(function() {
                return b._dispatch()
            }, c);
            else
                while (this._queue.length) a.call(this, this._queue.shift())
        };
        b.enqueue = function(a) {
            this._processor && !this._stopped ? this._processor(a) : this._queue.push(a);
            return this
        };
        b.start = function(a) {
            a && (this._processor = a);
            this._stopped = !1;
            this._dispatch();
            return this
        };
        b.isStarted = function() {
            return !this._stopped
        };
        b.dispatch = function() {
            this._dispatch(!0)
        };
        b.stop = function(a) {
            this._stopped = !0;
            a && this._timeout != null && clearTimeout(this._timeout);
            return this
        };
        b.merge = function(a, b) {
            if (b) {
                (b = this._queue).unshift.apply(b, a._queue)
            } else {
                (b = this._queue).push.apply(b, a._queue)
            }
            a._queue = [];
            this._dispatch();
            return this
        };
        b.getLength = function() {
            return this._queue.length
        };
        a.get = function(b, c) {
            var d;
            b in g ? d = g[b] : d = g[b] = new a(c);
            return d
        };
        a.exists = function(a) {
            return a in g
        };
        a.remove = function(a) {
            return delete g[a]
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("FalcoLoggerTransports", ["AnalyticsCoreData", "Banzai", "ExecutionEnvironment", "FalcoAppUniverse", "FalcoUtils", "ODS", "PersistedQueue", "Queue", "WebSession", "performanceAbsoluteNow", "promiseDone", "requireDeferredForDisplay", "uuidv4"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = c("requireDeferredForDisplay")("TransportSelectingClientSingletonConditional").__setRef("FalcoLoggerTransports"),
        m = 5 * 1024,
        n = (b = (i || (i = c("AnalyticsCoreData"))).max_delay_br_queue) != null ? b : 60 * 1e3,
        o = (e = (i || (i = c("AnalyticsCoreData"))).max_delay_br_queue_immediate) != null ? e : 1e3;
    b = (f = (i || (i = c("AnalyticsCoreData"))).max_delay_br_init_not_complete) != null ? f : 1e3;
    var p = "falco:",
        q = new(c("Queue"))(),
        r = 5e3,
        s = 6e4,
        aa = c("uuidv4")(),
        ba = "ods_web_batch",
        t = new Map(),
        u = new Set(),
        v = new Set(),
        w = d("FalcoUtils").getTaggedBitmap(38),
        x = (e = c("FalcoAppUniverse").cast((i || (i = c("AnalyticsCoreData"))).app_universe)) != null ? e : 1,
        y = [],
        z = 0,
        A = null,
        B = !1,
        C = !1,
        D = !1,
        E = !0,
        F = !1,
        G = Date.now() - s,
        H = 1,
        I = b > n ? b : n,
        J = b;
    Y();
    for (e = (f = (i || (i = c("AnalyticsCoreData"))).stateful_events_list_for_br) != null ? f : [], b = Array.isArray(e), f = 0, e = b ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
        var K;
        if (b) {
            if (f >= e.length) break;
            K = e[f++]
        } else {
            f = e.next();
            if (f.done) break;
            K = f.value
        }
        K = K;
        u.add(K)
    }
    for (f = (K = (i || (i = c("AnalyticsCoreData"))).stateless_non_fb_events_for_br) != null ? K : [], b = Array.isArray(f), e = 0, f = b ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
        if (b) {
            if (e >= f.length) break;
            K = f[e++]
        } else {
            e = f.next();
            if (e.done) break;
            K = e.value
        }
        K = K;
        v.add(K)
    }

    function L() {
        return (i || (i = c("AnalyticsCoreData"))).enable_bladerunner && !(k || (k = c("ExecutionEnvironment"))).isInWorker
    }

    function M(a, b) {
        d("FalcoUtils").bumpODSMetrics(b.item.name, "event.info.streaming.batched", 1);
        var c = b.item.extra.length;
        z + c > m && (clearTimeout(A), N());
        y.push([a, b]);
        z += c
    }

    function N() {
        A = null;
        B = !1;
        var a = y;
        S("event.info.streaming.batch_processing", a.map(function(a) {
            return a[1].item
        }));
        !F ? O(a, "event.non_critical_failure.streaming_init_not_complete") : q.enqueue(function(b) {
            return b.log(a.map(function(a) {
                return a[1].item
            }), function(b) {
                if (!b) {
                    O(a, "event.info.banzai_fallback");
                    return
                }
                P(a, b, "event.info.streaming.enqueued")
            })
        });
        y = [];
        z = 0
    }

    function O(a, b) {
        var c = function() {
            var c, f = a[e],
                g = f[0],
                h = f[1];
            f = h.item;
            d("FalcoUtils").bumpODSMetrics(f.name, b, 1);
            if ((c = f.logCritical) != null ? c : !1) U.logCritical([f], function(a) {
                return g.markItem(h, a)
            });
            else {
                ((c = f.logImmediate) != null ? c : !1) ? U.logImmediately([f], function(a) {
                    return g.markItem(h, a)
                }): U.log([f], function(a) {
                    return g.markItem(h, a)
                })
            }
        };
        for (var e = 0; e < a.length; e++) c();
        return
    }

    function P(a, b, c) {
        for (var e = 0; e < a.length; e++) {
            var f = a[e],
                g = f[0];
            f = f[1];
            d("FalcoUtils").bumpODSMetrics(f.item.name, c, 1);
            g.markItem(f, b)
        }
    }

    function ca(a) {
        return {
            events: a.map(function(a) {
                return {
                    name: a.name,
                    extra: a.extra,
                    rate: a.policy.r,
                    time: a.time / 1e3,
                    tag: 0,
                    tags: a.tags,
                    shouldAddState: a.shouldAddState,
                    identity: Q(a.identity),
                    expTags: a.exptTags,
                    sessionID: a.sessionId,
                    deviceID: a.deviceId
                }
            })
        }
    }

    function da(a) {
        var b;
        a = {
            deviceId: (i || (i = c("AnalyticsCoreData"))).device_id,
            familyDeviceId: null,
            osBuildNumber: null,
            sessionId: a,
            appId: i.app_id,
            appVersion: (a = (i || (i = c("AnalyticsCoreData"))).app_version) != null ? a : null,
            bundleId: null,
            consentState: null,
            identity: null,
            pushPhase: i.push_phase
        };
        ((b = (b = (i || (i = c("AnalyticsCoreData"))).stateful_events_list_for_br) == null ? void 0 : b.length) != null ? b : 0) > 0 && (a.ambientState = (i || (i = c("AnalyticsCoreData"))).state_for_br);
        a.identity = Q(i.identity);
        return Object.freeze(a)
    }

    function Q(a) {
        if (x === 2 || x === 3) {
            var b = a == null ? void 0 : a.appScopedIdentity;
            if (b !== void 0) return {
                appScopedIdentity: {
                    uid: b,
                    identifier: b,
                    claims: []
                }
            }
        } else {
            b = a == null ? void 0 : a.fbIdentity;
            if (b !== void 0) return {
                facebookIdentity: {
                    actorId: b.actorId,
                    accountId: b.accountId,
                    claims: []
                }
            }
        }
        return null
    }

    function R(a, b) {
        for (var e = 0; e < a.length; e++) {
            var f, g, h = a[e];
            f = (g = {}, g.e = h.extra, g.r = h.policy.r, g.d = (f = h.deviceId) != null ? f : (i || (i = c("AnalyticsCoreData"))).device_id, g.s = (f = h.sessionId) != null ? f : d("WebSession").getId(), g.t = h.time, g);
            h.privacyContext && (f.p = h.privacyContext);
            h.tags != null && (f.b = h.tags);
            g = h.identity;
            g && (f.id = g);
            c("Banzai").post(p + h.name, f, b)
        }
        S("event.uploaded", a)
    }

    function S(a, b) {
        for (var c = 0; c < b.length; c++) {
            var e = b[c];
            e.name !== ba && d("FalcoUtils").bumpODSMetrics(e.name, a, 1)
        }
    }

    function T(a, b) {
        var e = "falco.fabric.www." + (i || (i = c("AnalyticsCoreData"))).push_phase;
        (h || (h = d("ODS"))).bumpEntityKey(1344, e, a, b)
    }
    var U = {
        log: function(a, b) {
            S("event.info.banzai.log.upload_processing", a), R(a, c("Banzai").BASIC), b(!0)
        },
        logImmediately: function(a, b) {
            S("event.info.banzai.log_immediately.upload_processing", a), R(a, c("Banzai").VITAL), b(!0)
        },
        logCritical: function(a, b) {
            S("event.info.banzai.log_critical.upload_processing", a), R(a, {
                signal: !0,
                retry: !0
            }), b(!0)
        }
    };

    function ea(a) {
        Y();
        var b = V(a, "banzai_data_loss", "log"),
            d = V(a, "banzai_data_loss", "logImmediately"),
            e = V(a, "banzai_data_loss", "logCritical"),
            f = V(a, "bladerunner_data_loss", ""),
            g = V(a, "bladerunner_data_loss", "logCritical");
        T("js.br_data_loss.posted." + a, 1);
        if (F && E) try {
            q.enqueue(function(b) {
                return b.log([f], function(b) {
                    if (!b) {
                        T("js.br.transport_failure." + a, 1);
                        U.logCritical([g], function(b) {
                            T("js.br.failure_fallback_success_callback." + a, 1)
                        });
                        return
                    }
                    T("js.br.success_callback." + a, 1)
                })
            })
        } catch (b) {
            T("js.br.error_enqueueing." + a, 1), U.logCritical([g], function(b) {
                T("js.br.enqueuing_fallback_success_callback." + a, 1)
            })
        } else E || T("js.br.failed." + a, 1), F || T("js.br.init_not_complete." + a, 1), U.logCritical([g], function(b) {
            T("js.br.init_fallback_success_callback." + a, 1)
        });
        R([b], c("Banzai").BASIC);
        R([d], c("Banzai").VITAL);
        R([e], {
            signal: !0,
            retry: !0
        })
    }

    function V(a, b, d) {
        return {
            name: b,
            time: (j || (j = c("performanceAbsoluteNow")))(),
            policy: {
                r: 1
            },
            extra: JSON.stringify({
                event_index: a,
                falco_js_connection_id: aa,
                logging_mode: d,
                logging_flow_flag: "original_flow"
            })
        }
    }

    function W() {
        G + r < Date.now() && (ea(H), G = Date.now(), H++)
    }

    function X() {
        window.setTimeout(function() {
            W(), H <= 40 && X()
        }, s)
    }

    function fa(a) {
        q.start(function(b) {
            return b({
                log: function(d, b) {
                    S("event.info.streaming.queue_processing", d);
                    var e = JSON.stringify(ca(d));
                    a ? (i || (i = c("AnalyticsCoreData"))).enable_ack ? c("promiseDone")(a.amendWithAck(e), function(a) {
                        a ? (S("event.streamed.with_ack", d), S("event.uploaded", d)) : S("event.non_critical_failure.streaming.ack_failed", d), b(a)
                    }, function() {
                        S("event.non_critical_failure.streaming.ack_rejected", d), b(!1)
                    }) : (a.amendWithoutAck(e), S("event.streamed.without_ack", d), S("event.uploaded", d)) : (S("event.non_critical_error.streaming.stream_not_available", d), b(!1))
                },
                logImmediately: function(b, a) {
                    this.log(b, a)
                },
                logCritical: function(b, a) {
                    this.log(b, a)
                }
            })
        })
    }

    function Y() {
        if (C) return;
        F = !1;
        if (!L()) return;
        l.onReady(function(a) {
            if (!a) {
                E = !1;
                q.start(function(a) {
                    return a(U)
                });
                return
            }
            a = a;
            var b = {
                onTermination: function(a) {
                    a.message === "Stream closed" ? (q.stop(!0), C = !1) : (d("FalcoUtils").bumpODSMetrics("", "streaming.non_critical_failure.rejected", 1), E = !1, q.start(function(a) {
                        return a(U)
                    }))
                },
                onFlowStatus: function() {}
            };
            c("promiseDone")(a.requestStream({
                method: "Falco"
            }, JSON.stringify(da(d("WebSession").getId())), b, {
                requestId: ""
            }).then(function(b) {
                a = b, fa(a), F = !0, I = n, J = o
            })["catch"](function(a) {
                d("FalcoUtils").bumpODSMetrics("", "streaming.non_critical_failure.failed", 1), q.stop(!0), C = !1
            }))
        });
        C = !0
    }

    function Z(a) {
        var b, e = a.name;
        if (!L() || !E) return !1;
        if (u.has(e) || a.policy.s !== 1 && ((b = (i || (i = c("AnalyticsCoreData"))).br_stateful_migration_on) != null ? b : !1)) {
            a.shouldAddState = !0;
            a.tags = d("FalcoUtils").xorBitmap((b = a.tags) != null ? b : [0, 0], w);
            return !0
        }
        if (x !== 1 && (i || (i = c("AnalyticsCoreData"))).enable_non_fb_br_stateless_by_default !== !0 && !v.has(e)) return !1;
        if (a.policy.s === 1) {
            a.tags = d("FalcoUtils").xorBitmap((b = a.tags) != null ? b : [0, 0], w);
            return !0
        }
        return !1
    }

    function $(a) {
        if (a === "") return null;
        if (t.has(a)) return t.get(a);
        else {
            var b = {
                    claim: ""
                },
                c = a.split("^#");
            if (c.length >= 4) {
                var d = c[0],
                    e = c[1],
                    f = c[2];
                c = c[3];
                f !== "" ? b = {
                    appScopedIdentity: f,
                    claim: c
                } : d !== "" && (b = {
                    fbIdentity: {
                        accountId: d,
                        actorId: e
                    },
                    claim: c
                });
                t.set(a, b)
            }
            return b
        }
    }

    function a() {
        if (D) return;
        D = !0;
        c("PersistedQueue").setHandler("falco_queue_log", function(b) {
            var c, e = b.getQueueNameSuffix(),
                f = $(e);
            while (c = b.dequeueItem())(function(c) {
                Z(c.item) ? (d("FalcoUtils").bumpODSMetrics(c.item.name, "event.info.upload_method.streaming.log", 1), Y(), A == null && (A = setTimeout(N, I)), f && !a(e) && (c.item.identity = f), M(b, c)) : (f && (c.item.identity = f), U.log([c.item], function(a) {
                    return b.markItem(c, a)
                }))
            })(c)
        });
        c("PersistedQueue").setHandler("falco_queue_immediately", function(b) {
            var e, f = b.getQueueNameSuffix(),
                g = $(f);
            while (e = b.dequeueItem())(function(e) {
                Z(e.item) ? (d("FalcoUtils").bumpODSMetrics(e.item.name, "event.info.upload_method.streaming.log_immediately", 1), Y(), (A == null || !B) && (clearTimeout(A), A = setTimeout(N, J), B = !0), e.item.logImmediate = !0, g && !a(f) && (e.item.identity = g), M(b, e), c("PersistedQueue").isPersistenceAllowed() || (d("FalcoUtils").bumpODSMetrics(e.item.name, "event.info.streaming_no_persistence.log_immediately", 1), N())) : (d("FalcoUtils").bumpODSMetrics(e.item.name, "event.info.upload_method.banzai.log_immediately", 1), g && (e.item.identity = g), U.logImmediately([e.item], function(a) {
                    return b.markItem(e, a)
                }))
            })(e)
        });
        c("PersistedQueue").setHandler("falco_queue_critical", function(b) {
            var c, e = b.getQueueNameSuffix(),
                f = $(e);
            while (c = b.dequeueItem())(function(c) {
                var g = c.item;
                Z(g) ? (d("FalcoUtils").bumpODSMetrics(c.item.name, "event.info.upload_method.streaming.log_critical", 1), Y(), g.logCritical = !0, !F ? (f && (g.identity = f), O([
                    [b, c]
                ], "event.non_critical_failure.streaming_init_not_complete.log_critical")) : (f && !a(e) && (g.identity = f), q.enqueue(function(a) {
                    return a.logCritical([g], function(a) {
                        if (!a) {
                            !g.identity && f && (g.identity = f);
                            O([
                                [b, c]
                            ], "event.info.banzai_fallback.log_critical");
                            return
                        }
                        P([
                            [b, c]
                        ], a, "event.uploaded")
                    })
                }))) : (f && (g.identity = f), d("FalcoUtils").bumpODSMetrics(c.item.name, "event.info.upload_method.banzai.log_critical", 1), U.logCritical([g], function(a) {
                    return b.markItem(c, a)
                }))
            })(c)
        });
        (i || (i = c("AnalyticsCoreData"))).enable_dataloss_timer && (Y(), W(), X());

        function a(a) {
            try {
                var b = d("FalcoUtils").identityToString((i || (i = c("AnalyticsCoreData"))).identity);
                return a === b
            } catch (a) {
                (h || (h = d("ODS"))).bumpEntityKey(1344, "js.br.identity.check", "exception.when.comparing.with.current.user.identity", 1);
                return !0
            }
        }
    }
    g.attach = a
}), 98);
__d("MAWBridgeTraceEvent", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["ReceivedReceipt", "ReceivedSent", "FlowEndForFailure", "FlowEndForSuccess"]);
    c = a;
    f["default"] = c
}), 66);
__d("TransportSelectingClientSingletonConditional", ["cr:710"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:710")
}), 98); /*FB_PKG_DELIM*/
__d("MAWGalleryItemStateHandlerContentWrapper.react", ["CometHeroHoldTrigger.react", "FBLogger", "MAWMediaDownloadStatusUIStateType", "MWV2AttachmentLoadingPlaceholder.react", "react", "useMAWMaybeAutoTriggerDownload", "useMAWMediaDownloadManualRetry", "useMAWMediaStatusUIState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || c("react"),
        k = (h || (h = d("react"))).useEffect,
        l = {
            loadingPlaceholder: {
                borderTopStartRadius: "x168nmei",
                borderTopEndRadius: "x13lgxp2",
                borderBottomEndRadius: "x5pf9jr",
                borderBottomStartRadius: "xo71vjh",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.dbAttachment,
            e = a.descriptionForLogging,
            f = a.errorComponentRenderer,
            g = a.errorWithBlurComponentRenderer,
            h = a.mediaRenderQpl,
            i = a.placeholderHeight,
            m = a.placeholderWidth;
        a = a.successfulComponentRenderer;
        var n = c("useMAWMediaDownloadManualRetry")(b, h),
            o = c("useMAWMediaStatusUIState")(b, h),
            p = o.downloadStatus;
        c("useMAWMaybeAutoTriggerDownload")(b, h, "gallery");
        k(function() {
            var a, b = {
                string: {
                    call_site: e,
                    download_status_ui_state: p
                }
            };
            h == null ? void 0 : h.addPoint("render-gallery-item-state-handler-content-wrapper-" + ((a = p) != null ? a : "null"), b);
            switch (p) {
                case "non_retryable_error":
                case "retryable_error":
                case "non_retryable_error_with_preview":
                case "retryable_error_with_preview":
                    h == null ? void 0 : h.endFail(p, b);
                    break;
                case null:
                case "downloaded":
                case "loading":
                    break;
                default:
                    h == null ? void 0 : h.endFail("unknown_state", {
                        string: {
                            unknown_state_value: p
                        }
                    });
                    break
            }
        }, [p, h]);
        o = function(a, b) {
            return j.jsxs(j.Fragment, {
                children: [j.jsx(c("MWV2AttachmentLoadingPlaceholder.react"), {
                    descriptionForLogging: a,
                    height: i,
                    mediaRenderQpl: h,
                    width: m,
                    xstyle: l.loadingPlaceholder
                }), !b && j.jsx(c("CometHeroHoldTrigger.react"), {
                    description: a,
                    hold: !0
                })]
            })
        };
        b = d("MAWMediaDownloadStatusUIStateType").isRetryableErrorState(p);
        switch (p) {
            case null:
            case "loading":
                return o(e + ".MAWGalleryItemStateHandlerContentWrapper.NoMedia", !1);
            case "non_retryable_error":
            case "retryable_error":
                return f(b, n);
            case "non_retryable_error_with_preview":
            case "retryable_error_with_preview":
                return g == null ? f(b, n) : g(b, n);
            case "downloaded":
                return a(o);
            default:
                c("FBLogger")("messenger_web_media").mustfix("[MAW Attachment Content] Unknown MediaDownloadStatusUIState %s", p);
                return o(e + ".MAWGalleryItemStateHandlerContentWrapper.UnknownState", !1)
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWInboxInfoPhotoGalleryItem.react", ["fbt", "CometPlaceholder.react", "I64", "JSResourceForInteraction", "LSIntEnum", "LSMessagingThreadTypeUtil", "MAWGalleryItemStateHandlerContentWrapper.react", "MAWSecureVideoInvalidAttachment.react", "MAWSecureVideoUnsupportedCodecAttachment.react", "MWInboxInfoPhotoGalleryItemThumbnailContent.react", "MWMediaGalleryRenderQpl", "MWMediaRenderQplUtils", "MWMessageListMediaPressableContainer.react", "MWV2AttachmentErrorPlaceholderV2.react", "MWV2AttachmentErrorPlaceholderWithBlurImage.react", "MWV2AttachmentRetriableErrorPlaceholderWithBlurImage.react", "MediaDownloadStatusIconSize", "MessagingAttachmentType", "MessengerWebUXLogger", "gkx", "react", "useMAWMediaStatusUIState", "useMWMediaViewerOpenQPLLogger", "useMWV2MediaViewerURL", "useMWXLazyDialog", "useShouldShowPlaybackErrorFallback", "useShouldShowUnsupportedCodecFallback"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = i || d("react"),
        m = 512,
        n = 512,
        o = {
            attachmentContainer: {
                height: "x5yr21d",
                $$css: !0
            },
            errorPlaceholder: {
                borderTopStartRadius: "x168nmei",
                borderTopEndRadius: "x13lgxp2",
                borderBottomEndRadius: "x5pf9jr",
                borderBottomStartRadius: "xo71vjh",
                $$css: !0
            }
        };

    function a(a) {
        var b, e = a.attachment,
            f = a.getPlayableUrl,
            g = a.getPreviewUrl,
            h = a.navigateToRouteForMediaViewer,
            i = a.onPress,
            j = a.threadType,
            k = d("MWMediaGalleryRenderQpl").useMediaGalleryRenderQpl(e, j);
        a = c("useMAWMediaStatusUIState")(e, k);
        a = a.downloadStatus;
        k.addAnnotations({
            string: {
                downloadStatus: a
            }
        });
        a = (a = c("useShouldShowPlaybackErrorFallback")(e, k)) != null ? a : !1;
        b = (b = c("useShouldShowUnsupportedCodecFallback")(e, k)) != null ? b : !1;
        if (a) return l.jsx(c("MAWSecureVideoInvalidAttachment.react"), {
            attachment: e,
            connectBottom: !1,
            connectTop: !1,
            height: m,
            iconSize: c("MediaDownloadStatusIconSize").Small,
            mediaRenderQpl: k,
            outgoing: !1,
            width: n,
            withTooltip: !0,
            xstyle: o.errorPlaceholder
        });
        if (b) {
            return l.jsx(c("MAWSecureVideoUnsupportedCodecAttachment.react"), {
                connectBottom: !1,
                connectTop: !1,
                dbAttachment: e,
                getPreviewUrl: (a = g) != null ? a : f,
                height: m,
                iconSize: c("MediaDownloadStatusIconSize").Small,
                message: void 0,
                outgoing: !1,
                width: n,
                withTooltip: !0,
                xstyle: o.errorPlaceholder
            })
        }
        var q = function(a, b) {
            return l.jsx(c("MWV2AttachmentErrorPlaceholderV2.react"), {
                attachment: e,
                connectBottom: !1,
                connectTop: !1,
                hasAppAttribution: e.attributionAppName != null,
                height: m,
                iconSize: c("MediaDownloadStatusIconSize").Small,
                isRetryableError: a,
                mediaRenderQpl: k,
                onRetry: b,
                outgoing: !1,
                width: n,
                withTooltip: !0,
                xstyle: o.errorPlaceholder
            })
        };
        b = function(a, b) {
            return a ? l.jsx(c("MWV2AttachmentRetriableErrorPlaceholderWithBlurImage.react"), {
                connectBottom: !1,
                connectTop: !1,
                dbAttachment: e,
                getPreviewUrl: g,
                height: m,
                iconSize: c("MediaDownloadStatusIconSize").Small,
                isGroupedImage: !1,
                mediaRenderQpl: k,
                message: void 0,
                onRetry: b,
                outgoing: !1,
                width: n,
                withTooltip: !0,
                xstyle: o.errorPlaceholder
            }) : l.jsx(c("MWV2AttachmentErrorPlaceholderWithBlurImage.react"), {
                connectBottom: !1,
                connectTop: !1,
                dbAttachment: e,
                getPreviewUrl: g,
                height: m,
                iconSize: c("MediaDownloadStatusIconSize").Small,
                isGroupedImage: !1,
                mediaRenderQpl: k,
                message: void 0,
                outgoing: !1,
                width: n,
                withTooltip: !0,
                xstyle: o.errorPlaceholder
            })
        };
        a = function(a) {
            return l.jsx(c("CometPlaceholder.react"), {
                fallback: a("MAWInboxInfoPhotoGalleryItem.Suspense", !0),
                name: "MAWInboxInfoPhotoGalleryItem.Suspense",
                children: l.jsx(p, {
                    attachment: e,
                    getPlayableUrl: f,
                    getPreviewUrl: g,
                    mediaRenderQpl: k,
                    navigateToRouteForMediaViewer: h,
                    onPress: i,
                    renderUnsupportedAttachment: function() {
                        return q(!1)
                    },
                    threadType: j
                })
            })
        };
        return l.jsx(c("MAWGalleryItemStateHandlerContentWrapper.react"), {
            dbAttachment: e,
            descriptionForLogging: "MAWInboxInfoPhotoGalleryItem",
            errorComponentRenderer: q,
            errorWithBlurComponentRenderer: b,
            mediaRenderQpl: k,
            placeholderHeight: m,
            placeholderWidth: n,
            successfulComponentRenderer: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function p(a) {
        var b = a.attachment,
            e = a.getPlayableUrl,
            f = a.getPreviewUrl,
            g = a.mediaRenderQpl,
            i = a.navigateToRouteForMediaViewer,
            m = a.onPress,
            n = a.renderUnsupportedAttachment,
            p = a.threadType;
        f = (a = f(b, "MWInboxInfoPhotoGalleryItem", g)) != null ? a : "";
        a = Boolean(f) ? void 0 : e(b, "MWInboxInfoPhotoGalleryItem", g);
        e = c("useMWV2MediaViewerURL")(b);
        var q = c("useMWXLazyDialog")(c("JSResourceForInteraction")("MWV2MediaViewer.react").__setRef("MAWInboxInfoPhotoGalleryItem.react")),
            r = q[0],
            s = q[1];
        q = (j || (j = d("I64"))).equal(b.attachmentType, (k || (k = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").VIDEO));
        var t = d("useMWMediaViewerOpenQPLLogger").useMWMediaViewerOpenQPLLogger(),
            u = c("MessengerWebUXLogger").useInteractionLogger();
        if (f == null || f.length === 0) {
            if (!q || !c("gkx")("3368")) {
                g == null ? void 0 : g.endFail("empty_preview_url");
                return (q = n == null ? void 0 : n(b)) != null ? q : null
            }
            if (a == null || a.length === 0) {
                g == null ? void 0 : g.endFail("empty_video_preview_and_playable_url");
                return (q = n == null ? void 0 : n(b)) != null ? q : null
            }
        }
        n = i ? {
            passthroughProps: {
                origSrc: f
            },
            url: e
        } : void 0;
        return l.jsx(c("MWMessageListMediaPressableContainer.react"), {
            ariaLabel: h._("__JHASH__mrw3CpFXi7r__JHASH__"),
            attachment: b,
            linkProps_: n,
            mediaRenderQpl: g,
            onHoverIn: function() {
                if (!i) return s()
            },
            onPress: function() {
                t.startFlow({
                    attachmentType: d("MWMediaRenderQplUtils").getAttachmentTypeStringFromEnum(b.attachmentType),
                    entryPoint: "media_gallery",
                    isSecure: d("LSMessagingThreadTypeUtil").isArmadilloSecure(p)
                });
                u == null ? void 0 : u({
                    eventName: "open_media_viewer_from_gallery",
                    extraData: {
                        attachmentType: d("MWMediaRenderQplUtils").getAttachmentTypeStringFromEnum(b.attachmentType)
                    },
                    threadType: p
                });
                m != null && m(b);
                if (!i) return r({
                    attachment: b
                }, function() {})
            },
            overlayDisabled: !0,
            testid: void 0,
            xstyle: o.attachmentContainer,
            children: l.jsx(c("MWInboxInfoPhotoGalleryItemThumbnailContent.react"), {
                attachment: b,
                fallbackVideoUrl: a,
                mediaRenderQpl: g,
                previewUrl: f
            })
        })
    }
    p.displayName = p.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWV2SecureFileAttachmentErrorGalleryPlaceholder.react", ["fbt", "BaseMiddot.react", "MWFileUtils", "MWInboxInfoSharedContentFilePreview.react", "MWXLink.react", "MWXRow.react", "MWXRowItem.react", "MWXText.react", "MWXTextPairing.react", "MWXTooltip.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useEffect,
        l = {
            contentRowItem: {
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            fileRow: {
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                $$css: !0
            },
            iconRowItem: {
                backgroundColor: "xlhe6ec",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                height: "xdd8jsf",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "x889kno",
                paddingEnd: "x1iji9kk",
                paddingBottom: "x1a8lsjc",
                paddingStart: "x1sln4lm",
                width: "xvni27",
                $$css: !0
            }
        };

    function a(a) {
        var b, e = a.file,
            f = a.isRetryableError,
            g = a.mediaRenderQpl;
        a = a.onRetry;
        b = ((b = e.filename) != null ? b : d("MWFileUtils").PLACEHOLDER_FILENAME).toString();
        e = d("MWFileUtils").getFileSize(e);
        k(function() {
            g == null ? void 0 : g.addPoint("render-file-error-placeholder", {
                bool: {
                    is_retryable_error: f
                }
            })
        }, [g, f]);
        return j.jsx(c("MWXTooltip.react"), {
            label: h._("__JHASH__jCbL2nmLvOs__JHASH__"),
            tooltip: j.jsxs(c("MWXText.react"), {
                color: "tooltip",
                type: "meta4",
                children: [h._("__JHASH__jCbL2nmLvOs__JHASH__"), f && j.jsxs(j.Fragment, {
                    children: [j.jsx(c("BaseMiddot.react"), {}), j.jsx(c("MWXLink.react"), {
                        onClick: a,
                        weight_DEPRECATED: "medium",
                        children: h._("__JHASH__BGxC_0TtXwE__JHASH__")
                    })]
                })]
            }),
            children: j.jsx("div", {
                className: "x6s0dn4 x78zum5 x87ps6o",
                children: j.jsxs(c("MWXRow.react"), {
                    expanding: !0,
                    verticalAlign: "center",
                    xstyle: l.fileRow,
                    children: [j.jsx(c("MWXRowItem.react"), {
                        verticalAlign: "center",
                        xstyle: l.iconRowItem,
                        children: j.jsx(c("MWInboxInfoSharedContentFilePreview.react"), {
                            isError: !0,
                            isRetryableError: f,
                            onRetry: a
                        })
                    }), j.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        xstyle: l.contentRowItem,
                        children: j.jsx(c("MWXTextPairing.react"), {
                            body: e,
                            bodyColor: "disabled",
                            bodyLineLimit: 1,
                            headline: b,
                            headlineColor: "disabled",
                            headlineLineLimit: 3,
                            level: 4
                        })
                    })]
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MAWSecureInboxInfoSharedContentFileV2.react", ["CometPlaceholder.react", "MAWFilePressable.react", "MAWGalleryItemStateHandlerContentWrapper.react", "MWInboxInfoSharedContentFilePreview.react", "MWMediaGalleryRenderQpl", "MWV2AttachmentErrorPlaceholderV2.react", "MWV2SecureFileAttachmentErrorGalleryPlaceholder.react", "MWXRow.react", "MWXRowItem.react", "MWXTextPairing.react", "MediaDownloadStatusIconSize", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = 72,
        k = 350,
        l = {
            contentRowItem: {
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            errorPlaceholder: {
                borderTopStartRadius: "xhw592a",
                borderTopEndRadius: "xwihvcr",
                borderBottomEndRadius: "x7wuybg",
                borderBottomStartRadius: "xb9tvrk",
                $$css: !0
            },
            fileRow: {
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                $$css: !0
            },
            iconRowItem: {
                backgroundColor: "xlhe6ec",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                height: "xdd8jsf",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "xyinxu5",
                paddingEnd: "xmns6w2",
                paddingBottom: "x1g2khh7",
                paddingStart: "xpkgp8e",
                width: "xvni27",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.file,
            e = a.onPress;
        a = a.threadType;
        var f = d("MWMediaGalleryRenderQpl").useMediaGalleryRenderQpl(b, a);
        a = function(a, d) {
            return i.jsx(c("MWV2SecureFileAttachmentErrorGalleryPlaceholder.react"), {
                file: b,
                isRetryableError: a,
                mediaRenderQpl: f,
                onRetry: d
            })
        };
        var g = function(a) {
            return i.jsx(c("CometPlaceholder.react"), {
                fallback: a("MAWSecureInboxInfoSharedContentFileV2.Suspense", !0),
                name: "MAWSecureInboxInfoSharedContentFileV2.Suspense",
                children: i.jsx(m, {
                    file: b,
                    mediaRenderQpl: f,
                    onPress: e
                })
            })
        };
        return i.jsx(c("MAWGalleryItemStateHandlerContentWrapper.react"), {
            dbAttachment: b,
            descriptionForLogging: "MAWSecureInboxInfoSharedContentFileV2",
            errorComponentRenderer: a,
            mediaRenderQpl: f,
            placeholderHeight: j,
            placeholderWidth: k,
            successfulComponentRenderer: g
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function m(a) {
        var b = a.file,
            d = a.mediaRenderQpl;
        a = a.onPress;
        return i.jsx(c("MAWFilePressable.react"), {
            entrypoint: "inbox_info_v1",
            file: b,
            mediaRenderQpl: d,
            onPress: a,
            renderUnsupportedAttachment: function() {
                return i.jsx(c("MWV2AttachmentErrorPlaceholderV2.react"), {
                    attachment: b,
                    height: j,
                    iconSize: c("MediaDownloadStatusIconSize").Large,
                    isRetryableError: !1,
                    mediaRenderQpl: d,
                    width: k,
                    xstyle: l.errorPlaceholder
                })
            },
            children: function(a) {
                var b = a.filename,
                    d = a.messageID;
                a = a.size;
                return i.jsxs(c("MWXRow.react"), {
                    expanding: !0,
                    paddingTop: 0,
                    verticalAlign: "center",
                    xstyle: l.fileRow,
                    children: [i.jsx(c("MWXRowItem.react"), {
                        xstyle: l.iconRowItem,
                        children: i.jsx(c("MWInboxInfoSharedContentFilePreview.react"), {
                            messageID: d
                        })
                    }), i.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        xstyle: l.contentRowItem,
                        children: i.jsx(c("MWXTextPairing.react"), {
                            body: a,
                            bodyColor: "secondary",
                            headline: b,
                            headlineLineLimit: 1,
                            level: 4
                        })
                    })]
                })
            }
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("BaseMiddotSeparator.react", ["BaseMiddot.react", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.children,
            e = a["aria-label"],
            f = a["aria-labelledby"];
        a = a.asList;
        var g = a === void 0 ? !1 : a;
        a = i.Children.toArray(b).filter(Boolean).map(function(a, b) {
            return i.jsxs(j, {
                asList: g,
                children: [b !== 0 ? i.jsx(c("BaseMiddot.react"), {}) : null, a]
            }, b)
        });
        return g ? i.jsx(d("react-strict-dom").html.span, {
            "aria-label": (b = e) != null ? b : void 0,
            "aria-labelledby": (e = f) != null ? e : void 0,
            role: "list",
            children: a
        }) : a
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function j(a) {
        var b = a.asList;
        a = a.children;
        return b ? i.jsx(d("react-strict-dom").html.span, {
            role: "listitem",
            children: a
        }) : a
    }
    j.displayName = j.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("GroupsCometChatsChannelInviteLinkQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5354048408027065"
}), null);
__d("GroupsCometChatsChannelInviteLinkQuery$Parameters", ["GroupsCometChatsChannelInviteLinkQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("GroupsCometChatsChannelInviteLinkQuery_facebookRelayOperation"),
            metadata: {},
            name: "GroupsCometChatsChannelInviteLinkQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("GroupsCometChatsChannelInviteLink.entrypoint", ["GroupsCometChatsChannelInviteLinkQuery$Parameters", "JSResourceForInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            a = a.threadID;
            return {
                queries: {
                    queryReference: {
                        parameters: c("GroupsCometChatsChannelInviteLinkQuery$Parameters"),
                        variables: {
                            threadID: a
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("GroupsCometChatsChannelInviteLink.react").__setRef("GroupsCometChatsChannelInviteLink.entrypoint")
    };
    g["default"] = a
}), 98);
__d("MDSSegmentedControl.react", ["CometFocusGroupContext", "MDSPressable.react", "MDSText.react", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            pill: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "xnwf7zb",
                borderTopEndRadius: "x40j3uw",
                borderBottomEndRadius: "x1s7lred",
                borderBottomStartRadius: "x15gyhx8",
                display: "x78zum5",
                flexBasis: "x1tuynyk",
                flexGrow: "x1iyjqo2",
                height: "xc9qbxq",
                justifyContent: "xl56j7k",
                minWidth: "x13qp9f6",
                paddingStart: "x1ye3gou",
                paddingEnd: "xn6708d",
                paddingLeft: null,
                paddingRight: null,
                $$css: !0
            },
            selected: {
                backgroundColor: "x1iutvsz",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.label,
            d = a.onPress;
        d = d === void 0 ? c("emptyFunction") : d;
        var e = a.selected;
        e = e === void 0 ? !1 : e;
        a = a.testid;
        a = j(c("CometFocusGroupContext"));
        a = a.FocusItem;
        a = (a = a) != null ? a : i.Fragment;
        return i.jsx(a, {
            children: i.jsx(c("MDSPressable.react"), {
                "aria-label": b,
                "aria-selected": e,
                focusable: !0,
                onPress: d,
                role: "tab",
                testid: void 0,
                xstyle: [k.pill, e && k.selected],
                children: i.jsx(c("MDSText.react"), {
                    color: e ? "primary" : "secondary",
                    numberOfLines: 1,
                    type: "bodyLink3",
                    children: b
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MDSSegmentedControls.react", ["CometFocusGroup.react", "MDSSegmentedControl.react", "XPlatReactEnvironment", "focusScopeQueries", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            pillContainer: {
                borderTopColor: "x1d4wt55",
                borderEndColor: "x1ffyrng",
                borderBottomColor: "x1n79urc",
                borderStartColor: "xt4m4oe",
                borderTopStartRadius: "xnwf7zb",
                borderTopEndRadius: "x40j3uw",
                borderBottomEndRadius: "x1s7lred",
                borderBottomStartRadius: "x15gyhx8",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "x178xt8z",
                borderEndWidth: "xm81vs4",
                borderBottomWidth: "xso031l",
                borderStartWidth: "xy80clv",
                boxSizing: "x9f619",
                display: "x78zum5",
                $$css: !0
            },
            pillContainerWeb: {
                minWidth: "x13qp9f6",
                $$css: !0
            },
            root: {
                boxSizing: "x1afcbsf",
                width: "xh8yej3",
                $$css: !0
            },
            rootWeb: {
                marginTop: "x1rdy4ex",
                marginEnd: "xcud41i",
                marginBottom: "x4vbgl9",
                marginStart: "x139jcc6",
                overflowX: "xw2csxc",
                overflowY: "x1odjw0f",
                paddingTop: "x1iorvi4",
                paddingEnd: "x150jy0e",
                paddingBottom: "xjkvuk6",
                paddingStart: "x1e558r4",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.tabs,
            e = d("XPlatReactEnvironment").isWeb();
        return i.jsx(d("react-strict-dom").html.div, {
            style: [j.root, e && j.rootWeb],
            children: i.jsx(c("CometFocusGroup.react"), {
                hideArrowSignifiers: !0,
                orientation: "horizontal",
                role: "tablist",
                tabScopeQuery: d("focusScopeQueries").tabbableScopeQuery,
                children: function(a) {
                    return i.jsx(d("react-strict-dom").html.div, {
                        role: "tablist",
                        style: [j.pillContainer, e && j.pillContainerWeb, a],
                        children: b.map(function(a, b) {
                            return i.createElement(c("MDSSegmentedControl.react"), babelHelpers["extends"]({}, a, {
                                key: b
                            }))
                        })
                    })
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWCMChannelLinkShareTrigger.react", ["GroupsCometChatsChannelInviteLink.entrypoint", "I64", "react", "useMWXEntryPointDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    h || d("react");

    function a(a) {
        var b = a.children;
        a = a.threadKey;
        a = c("useMWXEntryPointDialog")(c("GroupsCometChatsChannelInviteLink.entrypoint"), {
            threadID: (i || (i = d("I64"))).to_string(a)
        });
        var e = a[0];
        return b(function() {
            return e({})
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWDialogContentTypeValues", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("gkx")("23219") ? 4 : 3;
    b = c("gkx")("23219") ? "headlineEmphasized4" : "headlineEmphasized2";
    d = c("gkx")("23219") ? "body4" : "body3";
    e = c("gkx")("23219") ? "bodyLink4" : "bodyLink3";
    f = c("gkx")("23219") ? "meta4" : "meta3";
    g.textPairingLevel = a;
    g.textHeadlineType = b;
    g.textBodyType = d;
    g.textBodyLinkType = e;
    g.textMetaType = f
}), 98);
__d("MWDialogTextPairing.react", ["MWDialogContentTypeValues", "MWXTextPairing.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsx(c("MWXTextPairing.react"), babelHelpers["extends"]({}, a, {
            level: d("MWDialogContentTypeValues").textPairingLevel
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWGroupMembershipListItem", ["I64", "MessagingSpecialThreadRole", "MessagingSpecialThreadRoleBitOffset"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = {
        BroadcastChannelParticipant: "broadcastChannelParticipantType",
        CommunityMember: "communityMemberType",
        ParticipantAndContact: "participantAndContactType",
        ServerSearchResult: "serverSearchResultType"
    };

    function a(a) {
        if (a.type === i.ParticipantAndContact) return a.participant.isAdmin;
        if (a.type === i.CommunityMember) return a.communityMember.isAdmin;
        return a.type === i.BroadcastChannelParticipant ? a.participant.isAdmin : !1
    }

    function b(a) {
        if (a.type === i.ParticipantAndContact) return a.participant.isModerator;
        return a.type === i.CommunityMember ? a.communityMember.isModerator : !1
    }

    function e(a) {
        return a.type === i.CommunityMember ? d("MessagingSpecialThreadRoleBitOffset").has(c("MessagingSpecialThreadRole").CHAT_HOST, a.communityMember) : !1
    }

    function f(a) {
        if (a.type === i.ParticipantAndContact) return a.contact.id;
        if (a.type === i.CommunityMember) return a.communityMember.contactId;
        return a.type === i.BroadcastChannelParticipant ? a.participant.contactId : (h || (h = d("I64"))).of_string(a.serverSearchResult.resultId)
    }
    g.MWGroupMembershipMemberTypes = i;
    g.isAdmin = a;
    g.isModerator = b;
    g.isHost = e;
    g.contactId = f
}), 98);
__d("MWXIconMenuItemLink", ["MWXSvgIcon", "SVGIcon", "cr:9529", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgMenuItemIcon(d("SVGIcon").svgIcon(b("cr:9529")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWXTabs.react", ["cr:4220", "cr:4354", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        if (b("cr:4220") != null) return i.jsx(b("cr:4220"), babelHelpers["extends"]({}, a));
        return b("cr:4354") != null ? i.jsx(b("cr:4354"), babelHelpers["extends"]({}, a)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MessengerCalendarFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M11 7.5a1.5 1.5 0 0 1 3 0V8a.5.5 0 0 0 .5.5h7A.5.5 0 0 0 22 8v-.5a1.5 1.5 0 0 1 3 0V8c0 .276.225.497.499.53A4 4 0 0 1 29 12.5a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1 4 4 0 0 1 3.501-3.97c.274-.033.499-.254.499-.53v-.5zM8 15.5a1 1 0 0 0-1 1v8a4 4 0 0 0 4 4h14a4 4 0 0 0 4-4v-8a1 1 0 0 0-1-1H8z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("XCometEventCreateControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/events/create/", Object.freeze({
        default_is_online: !1,
        default_is_paid_online_event: !1,
        dialog_entry_point: "others",
        should_skip_format_step: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("useMWLSGroupMembershipMenuQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "24535998679380437"
}), null);
__d("useMWNavigateToThreadFromGroupMembership", ["FBLogger", "LSIntEnum", "MAWVerifyThreadCutover", "MWPBumpEntityKey", "Promise", "ReQL", "cr:874", "promiseDone", "useMWNavigation", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;

    function a() {
        var a = (j || (j = c("useReStore")))(),
            e = c("useMWNavigation")(),
            f = b("cr:874")();
        return function(g, j) {
            d("MWPBumpEntityKey").bumpEntityKeyWithAppId("mw.infobar", "chat_members_overflow_message"), c("promiseDone")(d("MAWVerifyThreadCutover").verifyThreadCutover((i || (i = b("Promise"))).resolve(a), g), function(b) {
                b = b || j;
                if (b) c("promiseDone")(d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.tables.contacts).getKeyRange(g)).then(function(a) {
                    if (a != null && f != null) return f([a], []);
                    else {
                        c("FBLogger")("Unable to fetch contact", "maw_threads");
                        return
                    }
                }));
                else return e.openInbox({
                    clientThreadKey: void 0,
                    threadKey: g,
                    threadType: (h || (h = d("LSIntEnum"))).ofNumber(1)
                }, "groupMembers")
            })
        }
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("AddOnStartOverride.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react");
    b = j.forwardRef(a);

    function a(a, b) {
        var d = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["xstyle"]);
        return j.jsx("div", babelHelpers["extends"]({}, a, {
            ref: b
        }, (h || (h = c("stylex"))).props(d)))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("DmaMessengerOptOutFilled24.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs("svg", babelHelpers["extends"]({
            viewBox: "0 0 24 24",
            width: "1em",
            height: "1em",
            fill: "currentColor"
        }, a, {
            children: [a.title != null && i.jsx("title", {
                children: a.title
            }), a.children != null && i.jsx("defs", {
                children: a.children
            }), i.jsx("g", {
                stroke: "none",
                strokeWidth: 1,
                fillRule: "evenodd",
                children: i.jsx("path", {
                    d: "M109.675 0H94.329a3.761 3.761 0 0 0-3.533 2.365 3.761 3.761 0 0 0 .838 4.166l3.791 3.769 6.222-2.71a.749.749 0 0 1 .746 1.29l-5.453 4.042 1.372 5.173a3.763 3.763 0 0 0 3.191 2.809c.179.023.355.035.53.035 1.358 0 2.585-.704 3.283-1.914l7.67-13.294a3.783 3.783 0 0 0-.002-3.821A3.782 3.782 0 0 0 109.675 0",
                    transform: "translate(-444 -156) translate(354 158.5)"
                })
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("LSEncryptedBackupsOpStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        SUCCESS: 0,
        FAILURE: 1,
        UNKNOWN: 2
    });
    f["default"] = a
}), 66);
__d("MessengerCrossIcon", ["MessengerCross.svg.react", "SVGIcon"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("SVGIcon").svgIcon(c("MessengerCross.svg.react"));
    g["default"] = a
}), 98);
__d("MDSQuickPromotionCard.react", ["fbt", "MDSButton.react", "MDSCircleButton.react", "MDSColumn.react", "MDSColumnItem.react", "MDSRow.react", "MDSRowItem.react", "MDSText.react", "MessengerCrossIcon", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react"),
        k = {
            callToActionSection: {
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                marginTop: "xhrpt6u",
                $$css: !0
            },
            callToActionSpacer: {
                flexShrink: "x2lah0s",
                width: "x1xc55vz",
                $$css: !0
            },
            card: {
                boxShadow: "xe4pinz",
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            withRoundedCorners: {
                borderTopStartRadius: "xhk9q7s",
                borderTopEndRadius: "x1otrzb0",
                borderBottomEndRadius: "x1i1ezom",
                borderBottomStartRadius: "x1o6z2jb",
                $$css: !0
            }
        },
        l = {
            primary: {
                backgroundColor: "x1jx94hy",
                $$css: !0
            },
            secondary: {
                backgroundColor: "xlhe6ec",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.body,
            e = a.headline,
            f = a.headlineNumberOfLines;
        f = f === void 0 ? 1 : f;
        var g = a.icon,
            i = a.onClose,
            m = a.primaryCallToAction,
            n = a.secondaryCallToAction,
            o = a.type;
        o = o === void 0 ? "primary" : o;
        a = a.withRoundedCorners;
        a = a === void 0 ? !0 : a;
        var p = m != null || n != null;
        return j.jsx(d("react-strict-dom").html.div, {
            style: [k.card, a && k.withRoundedCorners, l[o]],
            children: j.jsxs(c("MDSColumn.react"), {
                children: [j.jsx(c("MDSColumnItem.react"), {
                    children: j.jsxs(c("MDSRow.react"), {
                        paddingHorizontal: 0,
                        paddingVertical: 0,
                        spacing: 12,
                        children: [g && j.jsx(c("MDSRowItem.react"), {
                            children: g
                        }), j.jsx(c("MDSRowItem.react"), {
                            expanding: !0,
                            children: j.jsxs(c("MDSColumn.react"), {
                                spacing: 12,
                                children: [j.jsx(c("MDSColumnItem.react"), {
                                    children: j.jsx(c("MDSText.react"), {
                                        align: "start",
                                        numberOfLines: f,
                                        type: "headlineEmphasized4",
                                        children: e
                                    })
                                }), j.jsx(c("MDSColumnItem.react"), {
                                    children: j.jsx(c("MDSText.react"), {
                                        align: "start",
                                        color: "secondary",
                                        numberOfLines: 6,
                                        type: "body4",
                                        children: b
                                    })
                                })]
                            })
                        }), i != null ? j.jsx(c("MDSRowItem.react"), {
                            children: j.jsx(c("MDSCircleButton.react"), {
                                color: "primary",
                                icon: c("MessengerCrossIcon"),
                                label: h._("__JHASH__tnRfHlva-bL__JHASH__"),
                                onPress: i,
                                size: 24,
                                testid: void 0
                            })
                        }) : null]
                    })
                }), j.jsx(c("MDSColumnItem.react"), {
                    children: p && j.jsxs(d("react-strict-dom").html.div, {
                        style: k.callToActionSection,
                        children: [n != null && j.jsx(c("MDSButton.react"), {
                            label: n.label,
                            linkProps: n.linkProps,
                            onPress: n.onPress,
                            size: 32,
                            type: "secondary"
                        }), m != null && j.jsxs(j.Fragment, {
                            children: [n != null && j.jsx(d("react-strict-dom").html.div, {
                                style: k.callToActionSpacer
                            }), j.jsx(c("MDSButton.react"), {
                                label: m.label,
                                linkProps: m.linkProps,
                                onPress: m.onPress,
                                size: 32,
                                type: m.reduceEmphasis === !0 ? "secondary" : "primary"
                            })]
                        })]
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWChatEncryptedBackupsSettingsDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7823915347737198"
}), null);
__d("MWDialogText.react", ["MWDialogContentTypeValues", "MWXText.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.children,
            e = a.type;
        e = e === void 0 ? "body" : e;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "type"]);
        switch (e) {
            case "bodyLink":
                return i.jsx(c("MWXText.react"), babelHelpers["extends"]({
                    type: d("MWDialogContentTypeValues").textBodyLinkType
                }, a, {
                    children: b
                }));
            case "headlineEmphasized":
                return i.jsx(c("MWXText.react"), babelHelpers["extends"]({
                    type: d("MWDialogContentTypeValues").textHeadlineType
                }, a, {
                    children: b
                }));
            case "meta":
                return i.jsx(c("MWXText.react"), babelHelpers["extends"]({
                    type: d("MWDialogContentTypeValues").textMetaType
                }, a, {
                    children: b
                }))
        }
        return i.jsx(c("MWXText.react"), babelHelpers["extends"]({
            type: d("MWDialogContentTypeValues").textBodyType
        }, a, {
            children: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEBFlowSourceContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        source: null
    });
    g["default"] = b
}), 98);
__d("MWXDialogPage.react", ["cr:2384", "cr:6810", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            cometPageContent: {
                paddingTop: "xyamay9",
                paddingEnd: "x1pi30zi",
                paddingBottom: "x1l90r2v",
                paddingStart: "x1swvt13",
                $$css: !0
            }
        };

    function a(a) {
        var c = a.children,
            e = a.hasTextOnlyContent;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "hasTextOnlyContent"]);
        if (b("cr:6810") != null) return i.jsx(b("cr:6810"), babelHelpers["extends"]({}, a, {
            children: i.jsx(d("react-strict-dom").html.div, {
                style: [j.cometPageContent],
                children: c
            })
        }));
        return b("cr:2384") != null ? i.jsx(b("cr:2384"), babelHelpers["extends"]({
            hasTextOnlyContent: e
        }, a, {
            children: c
        })) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXDialogPageLegacy.react", ["cr:6308", "cr:6309", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    c = i.forwardRef(a);

    function a(a, c) {
        var d = a.callToActionGroupDirection;
        d = d === void 0 ? "backward" : d;
        var e = a.callToActionGroupLayout,
            f = a.children,
            g = a.includeFDSContentPadding_REMOVE_THIS_AFTER_CONTENT_PADDING_MIGRATION;
        g = g === void 0 ? !0 : g;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["callToActionGroupDirection", "callToActionGroupLayout", "children", "includeFDSContentPadding_REMOVE_THIS_AFTER_CONTENT_PADDING_MIGRATION"]);
        if (b("cr:6308")) return i.jsx(b("cr:6308"), babelHelpers["extends"]({
            callToActionGroupDirection: d,
            callToActionGroupLayout: e,
            includeFDSContentPadding_REMOVE_THIS_AFTER_CONTENT_PADDING_MIGRATION: g
        }, a, {
            ref: c,
            children: f
        }));
        return b("cr:6309") ? i.jsx(b("cr:6309"), babelHelpers["extends"]({
            callToActionGroupDirection: d,
            ref: c
        }, a, {
            children: f
        })) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = c;
    g["default"] = e
}), 98);
__d("MWXMultiStepDialogHeader.react", ["cr:73", "cr:8246", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var c = a.buttonType,
            d = a.iconCssSelectorId,
            e = a.withoutBackButton,
            f = a.withoutHeaderBottomBorder;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["buttonType", "iconCssSelectorId", "withoutBackButton", "withoutHeaderBottomBorder"]);
        if (b("cr:8246")) return i.jsx(b("cr:8246"), babelHelpers["extends"]({
            buttonType: c,
            iconCssSelectorId: d,
            withoutBackButton: e,
            withoutHeaderBottomBorder: f
        }, a));
        return b("cr:73") ? i.jsx(b("cr:73"), babelHelpers["extends"]({
            backButtonType: c,
            closeButtonType: c,
            withBackButton: !e
        }, a)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXQPCard.react", ["MWXIconStrict.react", "MWXImage.react", "cr:2831", "cr:2832", "cr:6676", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            fdsRoot: {
                boxShadow: "xnw9j1v",
                $$css: !0
            },
            fdsRootMargin: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                marginTop: "x14vqqas",
                marginEnd: "xq8finb",
                marginBottom: "xod5an3",
                marginStart: "x16n37ib",
                $$css: !0
            },
            mdsRootMargin: {
                marginTop: "xw7yly9",
                marginEnd: "xktsk01",
                marginBottom: "x1yztbdb",
                marginStart: "x1d52u69",
                $$css: !0
            }
        };
    e = j.forwardRef(a);

    function a(a, d) {
        var e = a.addOnPrimary,
            f = a.addOnSecondary,
            g = a.hasNoMargin,
            i = a.icon;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnPrimary", "addOnSecondary", "hasNoMargin", "icon"]);
        var l;
        if (i != null) switch (i.type) {
            case "image":
                l = j.jsx(c("MWXImage.react"), babelHelpers["extends"]({}, i.props));
                break;
            case "icon":
                l = j.jsx(c("MWXIconStrict.react"), babelHelpers["extends"]({}, i.props));
                break;
            default:
                i.type
        }
        if (b("cr:2832") != null) return j.jsx("div", {
            className: (h || (h = c("stylex")))(g !== !0 && k.mdsRootMargin),
            ref: d,
            children: j.jsx(b("cr:2832"), babelHelpers["extends"]({}, a, {
                headlineNumberOfLines: 2,
                icon: l,
                primaryCallToAction: e && {
                    disabled: e.disabled,
                    label: e.label,
                    linkProps: e.linkProps,
                    onPress: e.onPress,
                    reduceEmphasis: e.reduceEmphasis
                },
                secondaryCallToAction: f && {
                    disabled: f.disabled,
                    label: f.label,
                    linkProps: f.linkProps,
                    onPress: f.onPress,
                    reduceEmphasis: f.reduceEmphasis
                }
            }))
        });
        else if (b("cr:2831") != null && b("cr:6676") != null) return j.jsx("div", {
            className: (h || (h = c("stylex")))(k.fdsRoot, g !== !0 && k.fdsRootMargin),
            ref: d,
            children: j.jsx(b("cr:2831"), babelHelpers["extends"]({}, a, {
                addOnPrimary: e && j.jsx(b("cr:6676"), {
                    align: "justify",
                    expanding: !0,
                    paddingHorizontal: 12,
                    primary: e,
                    secondary: f
                }),
                icon: l,
                level: 4,
                type: "primary"
            }))
        });
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = e;
    g["default"] = d
}), 98);
__d("MessengerCheckmark.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs("svg", babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            width: "1em",
            height: "1em",
            fill: "currentColor"
        }, a, {
            children: [a.title != null && i.jsx("title", {
                children: a.title
            }), a.children != null && i.jsx("defs", {
                children: a.children
            }), i.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M26.378 9.169c.597.347.8 1.112.453 1.709l-9 15.5a1.25 1.25 0 0 1-1.965.256l-6.5-6.5a1.25 1.25 0 1 1 1.768-1.768l5.121 5.121a.25.25 0 0 0 .393-.05L24.67 9.621a1.25 1.25 0 0 1 1.709-.453z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("useEncryptedBackupsQplImpressionRef", ["QPLUserFlow", "useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d, e) {
        return c("useVisibilityObserver")({
            onVisible: function() {
                c("QPLUserFlow").addPoint(a, b, {
                    instanceKey: d
                }), e == null ? void 0 : e()
            }
        })
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LSClearPinnedMessages", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.db.table(205).fetch([
                [
                    [a[0]]
                ]
            ]), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxClearPinnedMessagesStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteExistingMessageRanges", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.db.table(13).fetch([
                [
                    [a[0]]
                ]
            ]), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxDeleteExistingMessageRangesStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueCheckBackupStateOnInitSyncTask", ["LSArrayGetObjectAt", "LSIsEncryptionVersionSecure", "LSIssueNewEbTaskAndGetTaskIDV2"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(a) {
            return c.islc(c.filter(c.db.table(168).fetch(), function(a) {
                return c.i64.eq(a.authorityLevel, c.i64.cast([0, 80])) || !1
            }), 0, c.i64.to_float(c.i64.cast([0, 1]))).next().then(function(a, e) {
                var f = a.done;
                a = a.value;
                return f ? (function(a) {
                    c.logger(a).info(a)
                }("[EncryptedBackups][LSEncryptedBackupsIssueCheckBackupStateOnInitSyncTaskStoredProcedure] No client state in checkBackupStateOnInitSyncTask with reason: 1"), d[0] = !1) : (e = a.item, c.sequence([function(a) {
                    return d[9] = e.deviceId, d[8] = e.backupTenancy, d[7] = e.encryptionVersion, d[2] = void 0, c.i64.neq(d[2], void 0) ? c.resolve(d[3] = d[2]) : c.sequence([function(a) {
                        return d[10] = c.createArray(), c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 0])).then(function(a) {
                            return a = a, d[11] = a[0], a
                        })
                    }, function(a) {
                        return d[11] ? d[20] = (d[10].push(c.i64.cast([0, 0])), d[10]) : 0, c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 2])).then(function(a) {
                            return a = a, d[12] = a[0], a
                        })
                    }, function(a) {
                        return d[12] ? d[20] = (d[10].push(c.i64.cast([0, 2])), d[10]) : 0, c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 3])).then(function(a) {
                            return a = a, d[13] = a[0], a
                        })
                    }, function(a) {
                        return d[13] ? d[20] = (d[10].push(c.i64.cast([0, 3])), d[10]) : 0, c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 4])).then(function(a) {
                            return a = a, d[14] = a[0], a
                        })
                    }, function(a) {
                        return d[14] ? d[20] = (d[10].push(c.i64.cast([0, 4])), d[10]) : 0, d[15] = c.createArray(), d[16] = c.i64.of_int32(d[10].length), c.i64.gt(d[16], c.i64.cast([0, 0])) ? c.loopAsync(d[16], function(a) {
                            return d[20] = a, c.sequence([function(a) {
                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[10], d[20]).then(function(a) {
                                    return a = a, d[21] = a[0], d[22] = a[1], a
                                })
                            }, function(a) {
                                return d[23] = (d[15].push(d[21]), d[15])
                            }])
                        }) : c.resolve()
                    }, function(a) {
                        return c.sequence([function(a) {
                            return d[20] = c.createArray(), d[21] = c.i64.of_int32(d[15].length), c.i64.gt(d[21], c.i64.cast([0, 0])) ? c.loopAsync(d[21], function(a) {
                                return d[23] = a, c.sequence([function(a) {
                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[15], d[23]).then(function(a) {
                                        return a = a, d[24] = a[0], d[25] = a[1], a
                                    })
                                }, function(a) {
                                    return d[26] = (d[20].push(c.i64.to_string(d[24])), d[20])
                                }])
                            }) : c.resolve()
                        }, function(a) {
                            return d[22] = d[20].join(","), d[17] = d[22]
                        }])
                    }, function(a) {
                        return d[15].some(function(a) {
                            return c.i64.eq(d[7], a)
                        }) ? d[18] = d[7] : d[18] = void 0, c.i64.neq(d[18], void 0) ? d[19] = d[18] : d[19] = void 0, d[3] = d[19]
                    }])
                }, function(a) {
                    return c.i64.neq(d[3], void 0) ? d[4] = d[3] : d[4] = c.i64.cast([0, 0]), c.i64.neq(d[8], void 0) ? d[5] = d[8] : d[5] = c.i64.cast([0, 1]), c.i64.neq(d[9], void 0) ? c.sequence([function(a) {
                        return d[10] = new c.Map(), d[10].set("backup_id", e.backupId), d[10].set("device_id", d[9]), d[11] = c.toJSON(d[10]), c.storedProcedure(b("LSIssueNewEbTaskAndGetTaskIDV2"), "encrypted_backups_setup", c.i64.cast([0, 50054]), d[11], c.i64.cast([0, 0]), c.i64.cast([0, 93]), c.i64.cast([0, 0]), void 0, c.i64.cast([0, 0])).then(function(a) {
                            return a = a, d[12] = a[0], a
                        })
                    }, function(a) {
                        return d[6] = !0
                    }]) : c.resolve((function(a) {
                        c.logger(a).info(a)
                    }("[EncryptedBackups][LSEncryptedBackupsIssueCheckBackupStateOnInitSyncTaskStoredProcedure] No client state in checkBackupStateOnInitSyncTask with reason: 24"), d[6] = !1))
                }, function(a) {
                    return d[0] = d[6]
                }]))
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSEncryptedBackupsIssueCheckBackupStateOnInitSyncTaskStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueThreadCapabilitySyncTask", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.resolve(c)
    }
    a.__sproc_name__ = "LSMailboxIssueThreadCapabilitySyncTaskStoredProcedure";
    e.exports = a
}), null);
__d("LSSetForwardScore", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(12).fetch([
                [
                    [a[0], a[2], a[1]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(c.timestampMs, a[2]) && c.messageId === a[1]
            }), function(b) {
                var c = b.update;
                b.item;
                return c({
                    forwardScore: a[3]
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxSetForwardScoreStoredProcedure";
    e.exports = a
}), null);
__d("LSSetHMPSStatus", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.resolve(c)
    }
    a.__sproc_name__ = "LSMailboxSetHMPSStatusStoredProcedure";
    e.exports = a
}), null);
__d("LSTruncateMetadataThreads.nop", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;
    a = function(a, c) {
        return (g || (g = b("Promise"))).resolve()
    };
    f["default"] = a
}), 66);
__d("LSTruncateMetadataThreads", ["LSTruncateMetadataThreads.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(a) {
            return c.nativeOperation(b("LSTruncateMetadataThreads.nop"))
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxTruncateMetadataThreadsStoredProcedure";
    e.exports = a
}), null);
__d("LSTruncateThreadRangeTablesForSyncGroup", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.sequence([function(c) {
                return b.i64.eq(a[0], b.i64.cast([0, 1])) ? b.forEach(b.filter(b.db.table(10).fetch(), function(a) {
                    return b.i64.eq(b.i64.cast([0, 1]) == null ? b.i64.cast([0, 1]) : b.i64.cast([0, 1]), b.i64.cast([0, 1]))
                }), function(a) {
                    return a["delete"]()
                }) : b.i64.eq(a[0], b.i64.cast([0, 95])) ? b.forEach(b.filter(b.db.table(10).fetch([
                    [
                        [b.i64.cast([0, 0])],
                        [b.i64.cast([-1, 4294967295])]
                    ]
                ]), function(a) {
                    return b.i64.eq(b.i64.cast([0, 1]) == null ? b.i64.cast([0, 1]) : b.i64.cast([0, 1]), b.i64.cast([0, 1])) && (b.i64.eq(a.parentThreadKey, b.i64.cast([0, 0])) || b.i64.eq(a.parentThreadKey, b.i64.cast([-1, 4294967295])))
                }), function(a) {
                    return a["delete"]()
                }) : b.resolve(0)
            }, function(c) {
                return b.i64.eq(a[0], b.i64.cast([0, 1])) ? b.forEach(b.filter(b.db.table(247).fetch(), function(a) {
                    return b.i64.eq(a.syncGroup == null ? b.i64.cast([0, 1]) : a.syncGroup, b.i64.cast([0, 1]))
                }), function(a) {
                    return a["delete"]()
                }) : b.resolve()
            }, function(c) {
                return b.forEach(b.db.table(198).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(a) {
                    return a["delete"]()
                })
            }, function(c) {
                return b.forEach(b.db.table(220).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(a) {
                    return a["delete"]()
                })
            }])
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxTruncateThreadRangeTablesForSyncGroupStoredProcedure";
    e.exports = a
}), null);
__d("LSTruncateTablesForSyncGroup", ["LSTruncateThreadRangeTablesForSyncGroup"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.sequence([function(b) {
                return c.forEach(c.filter(c.db.table(9).fetch(), function(b) {
                    return (c.i64.eq(b.syncGroup, a[0]) || c.i64.eq(b.syncGroup, void 0) && c.i64.eq(c.i64.cast([0, 1]), a[0])) && ![c.i64.cast([0, 17]), c.i64.cast([0, 18]), c.i64.cast([0, 19]), c.i64.cast([0, 20]), c.i64.cast([0, 21]), c.i64.cast([0, 22]), c.i64.cast([0, 23]), c.i64.cast([0, 24]), c.i64.cast([0, 25]), c.i64.cast([0, 26])].some(function(a) {
                        return c.i64.eq(b.threadType, a)
                    })
                }), function(a) {
                    return a["delete"]()
                })
            }, function(d) {
                return c.storedProcedure(b("LSTruncateThreadRangeTablesForSyncGroup"), a[0])
            }])
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxTruncateTablesForSyncGroupStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateReadReceipt", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(14).fetch([
                [
                    [a[1], a[2]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[1]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(c.contactId, a[2]) && b.i64.lt(c.readWatermarkTimestampMs, a[0])
            }), function(c) {
                var d = c.update;
                c = c.item;
                return d({
                    readWatermarkTimestampMs: a[0],
                    readActionTimestampMs: b.i64.gt(a[3], b.i64.cast([0, 0])) ? a[3] : c.readActionTimestampMs
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateReadReceiptStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateThreadsRangesV2", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return b.sequence([function(c) {
                return b.forEach(b.db.table(10).fetch([
                    [
                        [a[1]]
                    ]
                ]), function(a) {
                    return a["delete"]()
                })
            }, function(d) {
                return c[8] = b.i64.gt(a[2], b.i64.cast([0, 1])) && b.i64.gt(a[3], b.i64.cast([-2147483648, 0])), a[0] === "inbox" && b.i64.eq(a[1], b.i64.cast([0, 0])) && b.i64.eq(a[4], b.i64.cast([0, 1])) ? b.sequence([function(d) {
                    return c[9] = a[2], c[10] = a[3], c[11] = !1, c[12] = c[8], b.forEach(b.db.table(198).fetch(), function(a) {
                        a = a.item;
                        return c[13] = a.minLastActivityTimestampMs, c[15] = a.minThreadKey, c[14] = b.i64.lt(c[9] == null ? c[13] : c[9], c[13]), c[9] = c[14] ? c[13] : c[9], c[10] = c[14] ? c[15] : c[10], c[11] = c[11] || a.isLoadingBefore, c[12] = c[12] || b.i64.gt(c[13], b.i64.cast([0, 1])) && b.i64.gt(c[15], b.i64.cast([-2147483648, 0]))
                    })
                }, function(a) {
                    return a = [c[9], c[10], c[11], c[12]], c[0] = a[0], c[1] = a[1], c[2] = a[2], c[3] = a[3], a
                }]) : b.resolve((d = [a[2], a[3], !1, c[8]], c[0] = d[0], c[1] = d[1], c[2] = d[2], c[3] = d[3], d))
            }, function(d) {
                return b.i64.eq(a[4], b.i64.cast([0, 1])) ? b.sequence([function(d) {
                    return c[9] = c[0], c[10] = c[1], c[11] = c[2], c[12] = c[3], b.forEach(b.filter(b.db.table(220).fetch(), function(c) {
                        return b.i64.eq(c.parentThreadKey, a[1])
                    }), function(a) {
                        a = a.item;
                        return c[13] = a.minLastActivityTimestampMs, c[15] = a.minThreadKey, c[14] = b.i64.lt(c[9] == null ? c[13] : c[9], c[13]), c[9] = c[14] ? c[13] : c[9], c[10] = c[14] ? c[15] : c[10], c[11] = c[11] || a.isLoadingBefore, c[12] = c[12] || b.i64.gt(c[13], b.i64.cast([0, 1])) && b.i64.gt(c[15], b.i64.cast([-2147483648, 0]))
                    })
                }, function(a) {
                    return a = [c[9], c[10], c[11], c[12]], c[4] = a[0], c[5] = a[1], c[6] = a[2], c[7] = a[3], a
                }]) : b.resolve((d = [c[0], c[1], c[2], c[3]], c[4] = d[0], c[5] = d[1], c[6] = d[2], c[7] = d[3], d))
            }, function(d) {
                return b.db.table(10).add({
                    parentThreadKey: a[1],
                    minThreadKey: c[5] == null ? b.i64.cast([-2147483648, 0]) : c[5],
                    minLastActivityTimestampMs: c[4] == null ? b.i64.cast([0, 1]) : c[4],
                    maxLastActivityTimestampMs: b.i64.cast([0, 1]),
                    maxThreadKey: b.i64.cast([-2147483648, 0]),
                    isLoadingBefore: c[6],
                    isLoadingAfter: !1,
                    hasMoreBefore: c[7],
                    hasMoreAfter: !1
                })
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateThreadsRangesV2StoredProcedure";
    e.exports = a
}), null);
__d("LSUpsertFolderSeenTimestamp", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.i64.gt(a[1], b.i64.cast([0, 0])) ? b.db.table(35).fetch([
                [
                    [a[0]]
                ]
            ]).next().then(function(c, d) {
                var e = c.done;
                c = c.value;
                return e ? b.db.table(35).add({
                    parentThreadKey: a[0],
                    lastSeenRequestTimestampMs: a[1]
                }) : (d = c.item, b.i64.lt(d.lastSeenRequestTimestampMs, a[1]) ? b.forEach(b.db.table(35).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(b) {
                    var c = b.update;
                    b.item;
                    return c({
                        lastSeenRequestTimestampMs: a[1]
                    })
                }) : b.resolve())
            }) : b.resolve()
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpsertFolderSeenTimestampStoredProcedure";
    e.exports = a
}), null);
__d("LSUpsertMessage", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(12).fetch([
                [
                    [a[9]]
                ], "optimistic"
            ]).next().then(function(c, d) {
                var e = c.done;
                c = c.value;
                return e ? b.db.table(12).add({
                    threadKey: a[3],
                    timestampMs: a[5],
                    messageId: a[8],
                    offlineThreadingId: a[9],
                    authorityLevel: a[2],
                    primarySortKey: a[6],
                    senderId: a[10],
                    isAdminMessage: a[12],
                    sendStatus: a[15],
                    sendStatusV2: a[16],
                    text: a[0],
                    subscriptErrorMessage: a[1],
                    secondarySortKey: a[7],
                    stickerId: a[11],
                    messageRenderingType: a[13],
                    isUnsent: a[17],
                    unsentTimestampMs: a[18],
                    mentionOffsets: a[19],
                    mentionLengths: a[20],
                    mentionIds: a[21],
                    mentionTypes: a[22],
                    replySourceId: a[23],
                    replySourceType: a[24],
                    replySourceTypeV2: a[25],
                    replyStatus: a[26],
                    replySnippet: a[27],
                    replyMessageText: a[28],
                    replyToUserId: a[29],
                    replyMediaExpirationTimestampMs: a[30],
                    replyMediaUrl: a[31],
                    replyMediaPreviewWidth: a[33],
                    replyMediaPreviewHeight: a[34],
                    replyMediaUrlMimeType: a[35],
                    replyMediaUrlFallback: a[36],
                    replyCtaId: a[37],
                    replyCtaTitle: a[38],
                    replyAttachmentType: a[39],
                    replyAttachmentId: a[40],
                    replyAttachmentExtra: a[41],
                    replyType: a[42],
                    isForwarded: a[43],
                    forwardScore: a[44],
                    hasQuickReplies: a[45],
                    adminMsgCtaId: a[46],
                    adminMsgCtaTitle: a[47],
                    adminMsgCtaType: a[48],
                    cannotUnsendReason: a[49],
                    textHasLinks: a[50],
                    viewFlags: a[51],
                    displayedContentTypes: a[52],
                    viewedPluginKey: a[53],
                    viewedPluginContext: a[54],
                    quickReplyType: a[55],
                    hotEmojiSize: a[56],
                    platformXmdEncoded: a[57],
                    replySourceTimestampMs: a[58],
                    ephemeralDurationInSec: a[59],
                    msUntilExpirationTs: a[60],
                    ephemeralExpirationTs: a[61],
                    takedownState: a[62],
                    isCollapsed: a[63],
                    subthreadKey: a[64],
                    botResponseId: a[65],
                    metadataDataclass: a[66],
                    editCount: a[67],
                    isPaidPartnership: a[68],
                    adminSignatureName: a[69],
                    adminSignatureProfileUrl: a[70],
                    adminSignatureCreatorType: a[71],
                    scheduledTimestamp: a[72]
                }) : (d = c.item, b.i64.le(d.authorityLevel, a[2]) ? b.db.table(12).put({
                    threadKey: a[3],
                    timestampMs: a[5],
                    messageId: a[8],
                    offlineThreadingId: a[9],
                    authorityLevel: a[2],
                    primarySortKey: d.primarySortKey,
                    senderId: a[10],
                    isAdminMessage: a[12],
                    sendStatus: a[15],
                    sendStatusV2: a[16],
                    text: a[0],
                    subscriptErrorMessage: a[1],
                    secondarySortKey: d.secondarySortKey,
                    stickerId: a[11],
                    messageRenderingType: a[13],
                    isUnsent: a[17],
                    unsentTimestampMs: a[18],
                    mentionOffsets: a[19],
                    mentionLengths: a[20],
                    mentionIds: a[21],
                    mentionTypes: a[22],
                    replySourceId: a[23],
                    replySourceType: a[24],
                    replySourceTypeV2: a[25],
                    replyStatus: a[26],
                    replySnippet: a[27],
                    replyMessageText: a[28],
                    replyToUserId: a[29],
                    replyMediaExpirationTimestampMs: a[30],
                    replyMediaUrl: a[31],
                    replyMediaPreviewWidth: a[33],
                    replyMediaPreviewHeight: a[34],
                    replyMediaUrlMimeType: a[35],
                    replyMediaUrlFallback: a[36],
                    replyCtaId: a[37],
                    replyCtaTitle: a[38],
                    replyAttachmentType: a[39],
                    replyAttachmentId: a[40],
                    replyAttachmentExtra: a[41],
                    replyType: a[42],
                    isForwarded: a[43],
                    forwardScore: a[44],
                    hasQuickReplies: a[45],
                    adminMsgCtaId: a[46],
                    adminMsgCtaTitle: a[47],
                    adminMsgCtaType: a[48],
                    cannotUnsendReason: a[49],
                    textHasLinks: a[50],
                    viewFlags: a[51],
                    displayedContentTypes: a[52],
                    viewedPluginKey: a[53],
                    viewedPluginContext: a[54],
                    quickReplyType: a[55],
                    hotEmojiSize: a[56],
                    platformXmdEncoded: a[57],
                    replySourceTimestampMs: a[58],
                    ephemeralDurationInSec: a[59],
                    msUntilExpirationTs: a[60],
                    ephemeralExpirationTs: a[61],
                    takedownState: a[62],
                    isCollapsed: a[63],
                    subthreadKey: a[64],
                    botResponseId: a[65],
                    metadataDataclass: a[66],
                    editCount: a[67],
                    isPaidPartnership: a[68],
                    adminSignatureName: a[69],
                    adminSignatureProfileUrl: a[70],
                    adminSignatureCreatorType: a[71],
                    scheduledTimestamp: a[72]
                }) : b.resolve())
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpsertMessageStoredProcedure";
    e.exports = a
}), null);
__d("LSWriteThreadCapabilities", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return c[0] = b.i64.of_float(Date.now()), b.forEach(b.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    capabilities: a[1],
                    capabilities2: a[2],
                    capabilities3: a[3],
                    capabilities4: a[4]
                })
            })
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxWriteThreadCapabilitiesStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("useFDSProgressRingSvg.react", ["FDSProgressRingUtils", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useMemo,
        k = b.useRef,
        l = 2;

    function a(a) {
        var b = a.color,
            c = a.isHidden,
            e = a.size,
            f = k(null),
            g = k(null),
            h = k(null);
        a = d("FDSProgressRingUtils").getRingColor(b);
        var m = a.backgroundColor,
            n = a.foregroundColor,
            o = (e - l) * Math.PI;
        b = j(function() {
            return i.jsxs(i.Fragment, {
                children: [i.jsx("svg", {
                    className: "x1ey2m1c x9f619 xds687c x17qophe x10l6tqk x13vifvy",
                    height: e,
                    ref: f,
                    viewBox: "0 0 " + e + " " + e,
                    width: e,
                    children: i.jsx("circle", {
                        cx: e / 2,
                        cy: e / 2,
                        fill: "none",
                        "non-scaling-stroke": "non-scaling-stroke",
                        r: (e - l) / 2,
                        stroke: m,
                        strokeLinecap: "round",
                        strokeWidth: l
                    })
                }), i.jsx("div", {
                    className: "x1ey2m1c xds687c xtzzx4i x6ikm8r x10wlt62 x10l6tqk x13vifvy",
                    children: i.jsx("svg", {
                        className: "x1ey2m1c x9f619 xds687c x1ytbgms x10l6tqk x13vifvy x1jpgh95",
                        height: e,
                        ref: g,
                        viewBox: "0 0 " + e + " " + e,
                        width: e,
                        children: i.jsx("circle", {
                            cx: e / 2,
                            cy: e / 2,
                            fill: "none",
                            "non-scaling-stroke": "non-scaling-stroke",
                            r: (e - l) / 2,
                            stroke: n,
                            strokeDasharray: o / 2,
                            strokeDashoffset: 3 * o / 4,
                            strokeWidth: l,
                            style: {
                                visibility: c ? "hidden" : void 0
                            }
                        })
                    })
                }), i.jsx("div", {
                    className: "x1ey2m1c x8cgc45 x17qophe x6ikm8r x10wlt62 x10l6tqk x13vifvy",
                    children: i.jsx("svg", {
                        className: "x1ey2m1c x9f619 x14l5gr7 x17qophe x10l6tqk x13vifvy x1jpgh95",
                        height: e,
                        ref: h,
                        viewBox: "0 0 " + e + " " + e,
                        width: e,
                        children: i.jsx("circle", {
                            cx: e / 2,
                            cy: e / 2,
                            fill: "none",
                            "non-scaling-stroke": "non-scaling-stroke",
                            r: (e - l) / 2,
                            stroke: n,
                            strokeDasharray: o / 2,
                            strokeDashoffset: o / 4,
                            strokeWidth: l,
                            style: {
                                visibility: c ? "hidden" : void 0
                            }
                        })
                    })
                })]
            })
        }, [e, m, n, o, c]);
        return {
            backgroundRef: f,
            leftCircleRef: h,
            progressRing: b,
            rightCircleRef: g
        }
    }
    g["default"] = a
}), 98);
__d("CometProgressRingDeterminate.react", ["BaseLoadingStateElement.react", "react", "useFDSProgressRingSvg.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useEffect,
        k = {
            rootDiv: {
                position: "x1n2onr6",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.color,
            d = a.percentage,
            e = a.size,
            f = a["aria-label"];
        a = a["aria-labelledby"];
        b = c("useFDSProgressRingSvg.react")({
            color: b,
            isHidden: !1,
            size: e
        });
        var g = b.leftCircleRef,
            h = b.progressRing,
            l = b.rightCircleRef;
        j(function() {
            var a = l.current,
                b = g.current;
            if (a == null || b == null) return;
            if (!(a instanceof SVGSVGElement) || !(b instanceof SVGSVGElement)) return;
            var c = Math.max(0, Math.min(100, d)) / 100 * 360;
            a.style.transform = "rotate(" + Math.min(c, 180) + "deg)";
            b.style.transform = "rotate(" + Math.max(c - 180, 0) + "deg)"
        }, [g, d, l]);
        return i.jsx(c("BaseLoadingStateElement.react"), {
            "aria-label": f,
            "aria-labelledby": a,
            progress: d,
            style: {
                height: e,
                width: e
            },
            xstyle: k.rootDiv,
            children: h
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MDSProgressRing.react", ["ARIA_LABEL_PLACEHOLDER_FIXME", "CometProgressRingDeterminate.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.color;
        b = b === void 0 ? "light" : b;
        var d = a.percentage;
        d = d === void 0 ? 0 : d;
        a = a.size;
        a = a === void 0 ? 16 : a;
        return i.jsx("div", {
            className: "x6s0dn4 x1qhmfi1 x14yjl9h xudhj91 x18nykt9 xww2gxu x78zum5 xl56j7k x1y1aw1k x1sxyh0 xwib8y2 xurb0ha",
            children: i.jsx(c("CometProgressRingDeterminate.react"), {
                "aria-label": c("ARIA_LABEL_PLACEHOLDER_FIXME"),
                color: b,
                percentage: d,
                size: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LSIssueParticipantPointQuery", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("table", "14"), d[0].set("type", c.i64.cast([0, 1])), d[0].set("1", a[0]), d[0].set("2", a[1]), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTask"), "ppq", c.i64.cast([0, 17]), d[1], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), c.i64.cast([0, 1]), void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxIssueParticipantPointQueryStoredProcedure";
    e.exports = a
}), null);
__d("LSSetMessageTextHasLinks", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(12).fetch([
                [
                    [a[0], a[2], a[1]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(c.timestampMs, a[2]) && c.messageId === a[1]
            }), function(a) {
                var b = a.update;
                a.item;
                return b({
                    textHasLinks: !0
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxSetMessageTextHasLinksStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateCommunityThreadStaleState", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.filter(b.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[0]) && ([b.i64.cast([0, 23]), b.i64.cast([0, 21]), b.i64.cast([0, 18]), b.i64.cast([0, 26])].some(function(a) {
                    return b.i64.eq(c.threadType, a)
                }) || b.i64.eq(c.threadType, b.i64.cast([0, 152])))
            }).next().then(function(c, d) {
                d = c.done;
                c = c.value;
                return d ? 0 : (c.item, b.db.table(294).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(c, d) {
                    d = c.done;
                    c = c.value;
                    return d ? b.db.table(294).add({
                        threadKey: a[0],
                        threadQueueSequenceId: b.i64.cast([0, 0]),
                        isStale: a[1]
                    }) : (c.item, b.forEach(b.db.table(294).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        var c = b.update;
                        b.item;
                        return c({
                            isStale: a[1]
                        })
                    }))
                }))
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateCommunityThreadStaleStateStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateOrInsertCommunitySurfaceRange", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(253).put({
                surfaceType: a[0],
                communityKey: a[1],
                isLoadingAfter: !1,
                hasMoreAfter: a[2],
                nextPageCursor: a[4]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateOrInsertCommunitySurfaceRangeStoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyContactParticipantExist", ["LSIssueNewTask", "LSIssueParticipantPointQuery"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return c.db.table(7).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(e, f) {
                    f = e.done;
                    e = e.value;
                    return f ? c.sequence([function(e) {
                        return d[2] = new c.Map(), d[2].set("contact_id", a[0]), d[3] = c.toJSON(d[2]), c.storedProcedure(b("LSIssueNewTask"), "cpq_v2", c.i64.cast([0, 207]), d[3], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
                    }, function(b) {
                        return c.forEach(c.filter(c.db.table(7).fetch([
                            [
                                [a[0]]
                            ]
                        ]), function(b) {
                            return c.i64.eq(b.id, a[0]) && c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1])) && c.i64.lt(b.authorityLevel, c.i64.cast([0, 60]))
                        }), function(a) {
                            return a["delete"]()
                        })
                    }, function(b) {
                        return c.db.table(7).add({
                            id: a[0],
                            rank: 0,
                            profilePictureUrl: "",
                            name: a[2],
                            isMessengerUser: !1,
                            isMemorialized: !1,
                            contactType: c.i64.cast([0, 1]),
                            contactTypeExact: c.i64.cast([0, 1]),
                            blockedByViewerStatus: c.i64.cast([0, 0]),
                            authorityLevel: c.i64.cast([0, 60]),
                            workForeignEntityType: c.i64.cast([0, 0]),
                            contactViewerRelationship: c.i64.cast([0, 0])
                        })
                    }]) : (e.item, 0)
                })
            }, function(d) {
                return c.filter(c.db.table(14).fetch([
                    [
                        [a[1], a[0]]
                    ]
                ]), function(b) {
                    return c.i64.eq(b.threadKey, a[1]) && c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 0])) && c.i64.eq(b.contactId, a[0])
                }).next().then(function(d, e) {
                    e = d.done;
                    d = d.value;
                    return e ? c.storedProcedure(b("LSIssueParticipantPointQuery"), a[1], a[0]) : (d.item, 0)
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxVerifyContactParticipantExistStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("CometProgressIndicator.react", ["BaseLoadingStateElement.react", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            animateDot: {
                animationDuration: "x1c74tu6",
                animationIterationCount: "xa4qsjk",
                animationName: "xwp40e0",
                animationTimingFunction: "x147wac7",
                opacity: "xllgmg",
                transform: "x13kylt9",
                $$css: !0
            },
            animationDelay300: {
                animationDelay: "x1x1c4bx",
                $$css: !0
            },
            animationDelay600: {
                animationDelay: "x1nrwgbl",
                $$css: !0
            },
            root: {
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                $$css: !0
            }
        },
        k = {
            "default": {
                borderTopStartRadius: "x1lcm9me",
                borderTopEndRadius: "x1yr5g0i",
                borderBottomEndRadius: "xrt01vj",
                borderBottomStartRadius: "x10y3i5r",
                height: "xdk7pt",
                marginEnd: "xfs2ol5",
                marginStart: "x12mruv9",
                width: "x1xc55vz",
                $$css: !0
            },
            small: {
                borderTopStartRadius: "xm3z3ea",
                borderTopEndRadius: "x1x8b98j",
                borderBottomEndRadius: "x131883w",
                borderBottomStartRadius: "x16mih1h",
                height: "xqu0tyb",
                marginEnd: "xhhsvwb",
                marginStart: "xgzva0m",
                width: "x51ohtg",
                $$css: !0
            }
        },
        l = {
            media: {
                backgroundColor: "x14hiurz",
                $$css: !0
            },
            primary: {
                backgroundColor: "xn25soc",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.disableLoadingStateTracker,
            e = a.overrideBGColorContext;
        e = e === void 0 ? "primary" : e;
        var f = a.size;
        f = f === void 0 ? "default" : f;
        var g = a["aria-label"];
        a = a["aria-labelledby"];
        f = [j.animateDot, k[f], l[e]];
        return i.jsxs(c("BaseLoadingStateElement.react"), {
            "aria-label": g,
            "aria-labelledby": a,
            disableLoadingStateTracker: b,
            xstyle: j.root,
            children: [i.jsx(d("react-strict-dom").html.div, {
                style: f
            }), i.jsx(d("react-strict-dom").html.div, {
                style: [f, j.animationDelay300]
            }), i.jsx(d("react-strict-dom").html.div, {
                style: [f, j.animationDelay600]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useThrottled", ["cr:6101"], (function(a, b, c, d, e, f, g) {
    "use strict";
    f.exports = b("cr:6101")
}), 34);
__d("useThrottledComet", ["CometThrottle", "react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useLayoutEffect,
        k = b.useRef;

    function a(a, b) {
        b === void 0 && (b = 100);
        var d = k(a);
        j(function() {
            d.current = a
        }, [a]);
        var e = c("useStable")(function() {
            return c("CometThrottle")(function() {
                var a = arguments;
                return d.current == null ? void 0 : d.current.apply(d, a)
            }, b)
        });
        i(function() {
            return function() {
                e.cancel()
            }
        }, []);
        return e
    }
    g["default"] = a
}), 98);
__d("useThrottledImpl", ["cr:1708227"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1708227")
}), 98); /*FB_PKG_DELIM*/
__d("MWInboxInfoMemberRequests.react", ["fbt", "Int64Hooks", "MWInboxInfoButton.react", "MWInboxInfoMemberRequestsPushPage.react", "MWXIconForListCell.react", "MWXIconFriendGenericCheckmark", "ReQL", "ReQLSuspense", "react", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || d("react");

    function a(a) {
        var b = a.pushPage,
            e = a.thread,
            g = (i || (i = c("useReStore")))();
        a = d("ReQLSuspense").useArray(function() {
            return d("ReQL").fromTableAscending(g.tables.group_membership_approval_requests, []).getKeyRange(e.threadKey)
        }, [g, e.threadKey], f.id + ":37");
        a = a.length;
        var j = d("Int64Hooks").useCallbackInt64(function(a) {
            if (b != null) return b(function(b) {
                return k.jsx(c("MWInboxInfoMemberRequestsPushPage.react"), {
                    onReturn: b.onReturn,
                    parentSurface: a,
                    threadKey: e.threadKey
                })
            })
        }, [b, e.threadKey]);
        return k.jsx(c("MWInboxInfoButton.react"), {
            addOnStart: k.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconFriendGenericCheckmark")
            }),
            label: h._("__JHASH__4FAWQwvEk9h__JHASH__"),
            onPress: function() {
                return j()
            },
            subLabel: a > 0 ? h._("__JHASH__8y8AMiPf1gZ__JHASH__", [h._plural(a, "number")]) : void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226); /*FB_PKG_DELIM*/
__d("MWEBFlowSourceContextProvider.react", ["MWEBFlowSourceContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;

    function a(a) {
        var b = a.children,
            d = a.source;
        a = j(function() {
            return {
                source: d
            }
        }, [d]);
        return i.jsx(c("MWEBFlowSourceContext").Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);