; /*FB_PKG_DELIM*/

__d("MDSCard.react", ["BaseView.react", "react", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);
    var j = {
            "base-wash": {
                backgroundColor: "x1vtvx1t",
                $$css: !0
            },
            "card-flat": {
                backgroundColor: "xlhe6ec",
                $$css: !0
            },
            "light-wash": {
                backgroundColor: "x443n21",
                $$css: !0
            },
            transparent: {
                backgroundColor: "xjbqb8w",
                $$css: !0
            },
            white: {
                backgroundColor: "x2bj2ny",
                $$css: !0
            }
        },
        k = {
            borderOnWash: {
                borderTopColor: "x8cjs6t",
                borderEndColor: "x1ch86jh",
                borderBottomColor: "x80vd3b",
                borderStartColor: "xckqwgs",
                $$css: !0
            },
            borderOnWhite: {
                borderTopColor: "x8cjs6t",
                borderEndColor: "x1ch86jh",
                borderBottomColor: "x80vd3b",
                borderStartColor: "xckqwgs",
                $$css: !0
            },
            borderSolid: {
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "x178xt8z",
                borderEndWidth: "xm81vs4",
                borderBottomWidth: "xso031l",
                borderStartWidth: "xy80clv",
                $$css: !0
            },
            overflowHidden: {
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                $$css: !0
            },
            root: {
                borderTopStartRadius: "xyi19xy",
                borderTopEndRadius: "x1ccrb07",
                borderBottomEndRadius: "xtf3nb5",
                borderBottomStartRadius: "x1pc53ja",
                width: "xh8yej3",
                $$css: !0
            }
        },
        l = {
            1: {
                boxShadow: "x1xmxkk1",
                $$css: !0
            },
            2: {
                boxShadow: "x12tb6hj",
                $$css: !0
            }
        };

    function a(a, b) {
        var d = a.background;
        d = d === void 0 ? "transparent" : d;
        var e = a.border;
        e = e === void 0 ? "none" : e;
        var f = a.children,
            g = a.dropShadow;
        g = g === void 0 ? 0 : g;
        var h = a.testid;
        a = a.xstyle;
        return i.jsx("div", babelHelpers["extends"]({
            className: "x78zum5 x1n2onr6 xh8yej3"
        }, c("testID")(h), {
            children: i.jsx(c("BaseView.react"), {
                ref: b,
                style: {
                    borderRadius: "max(0px, min(8px, calc((100vw - 4px - 100%) * 9999))) / 8px"
                },
                xstyle: [j[d], e === "solid" && d !== "white" && k.borderOnWash, e === "solid" && d === "white" && k.borderOnWhite, e === "solid" && k.borderSolid, k.root, k.overflowHidden, l[g], a],
                children: f
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("MWMessageListScrollContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    c = h;
    e = c.createContext;
    var j = c.useCallback,
        k = c.useContext,
        l = c.useMemo,
        m = c.useState;
    d = null;
    var n = e(d);

    function a() {
        var a;
        a = (a = k(n)) != null ? a : {};
        var b = a.setIsThreadAtBottom,
            c = a.unsetIsThreadAtBottom;
        return l(function() {
            return b == null || c == null ? null : {
                setIsThreadAtBottom: b,
                unsetIsThreadAtBottom: c
            }
        }, [b, c])
    }

    function b(a) {
        a = a.children;
        var b = m(new Map()),
            c = b[0],
            d = b[1],
            e = j(function(a) {
                a = c.get(a);
                if (a != null) return a;
                else return !1
            }, [c]),
            f = j(function(a, b) {
                d(function(c) {
                    c = new Map(c);
                    c.set(a, b);
                    return c
                })
            }, []),
            g = j(function(a) {
                d(function(b) {
                    b = new Map(b);
                    b["delete"](a);
                    return b
                })
            }, []);
        b = l(function() {
            return {
                checkIsThreadAtBottom: e,
                setIsThreadAtBottom: f,
                unsetIsThreadAtBottom: g
            }
        }, [e, f, g]);
        return i.jsx(n.Provider, {
            value: b,
            children: a
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g.MWMessageListScrollContext = n;
    g.useMWMessageListScrollContextSetters = a;
    g.MWMessageListScrollContextProvider = b
}), 98);
__d("MessengerThreadTakedownState", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        TAKEN_DOWN: 1,
        RESTORED: 2,
        GEO_BLOCKED: 3
    });
    f["default"] = a
}), 66);
__d("mwIsThreadDisabled", ["I64", "LSIntEnum", "MessengerThreadTakedownState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a, b) {
        return b != null && (h || (h = d("I64"))).equal(b, (i || (i = d("LSIntEnum"))).ofNumber(1)) ? !0 : a != null && ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessengerThreadTakedownState").TAKEN_DOWN)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessengerThreadTakedownState").GEO_BLOCKED)))
    }
    g["default"] = a
}), 98);
__d("getGroupThreadViewParams", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        b = b == null ? void 0 : b.main.route.params;
        a = (a == null ? void 0 : a.entity_type) === "group" && (a == null ? void 0 : a.section) === "CHATS";
        if (!a) return null;
        a = b == null ? void 0 : b.thread_id;
        b = b == null ? void 0 : b.idorvanity;
        if (a == null || b == null) return null;
        return typeof a === "string" && typeof b === "string" ? {
            groupId: b,
            threadKey: a
        } : null
    }
    f["default"] = a
}), 66);
__d("getTopMostRouteCometEntityKey", ["getCometEntityKey", "getTopMostRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a == null) return null;
        a = c("getTopMostRoute")(a);
        return c("getCometEntityKey")(a)
    }
    g["default"] = a
}), 98);
__d("useTopMostRouteCometEntityKey", ["getTopMostRouteCometEntityKey", "useCometRouterState"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("useCometRouterState")();
        return c("getTopMostRouteCometEntityKey")(a)
    }
    g["default"] = a
}), 98);
__d("useGroupThreadViewParams", ["getGroupThreadViewParams", "useCometRouterState", "useTopMostRouteCometEntityKey"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("useTopMostRouteCometEntityKey")(),
            b = c("useCometRouterState")();
        return c("getGroupThreadViewParams")(a, b)
    }
    g["default"] = a
}), 98);
__d("useMWInboxURIState", ["CometRouteParams", "CometRouteURL", "ConstUriUtils", "CurrentEnvironment", "Env", "FBLogger", "I64", "LSMessagingThreadTypeUtil", "MessengerURIConstants", "ReQL", "ReQLSuspense", "gkx", "isArmadillo", "mwCMIsAnyCMThread", "useCurrentRoute", "useGroupThreadViewParams", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;
    e = "Compose";
    var k = "PayFriendPicker",
        l = "PayThread",
        m = "SecureThread",
        n = "Thread",
        o = "/";
    e = {
        Compose: e
    };
    k = {
        PayFriendPicker: k,
        PayThread: l
    };
    l = {
        SecureThread: m,
        Thread: n
    };
    var p = babelHelpers["extends"]({}, e, k, l);
    m = "Null";
    n = "Payment";
    e = "People";
    k = "Search";
    l = "SearchMessages";
    var q = "SeeAllGroups",
        r = "SeeAllPages",
        s = "SeeAllPeople",
        t = "SeeAllUnread",
        u = "TeamworkSeeAllAnnouncementGroups",
        v = "Recent",
        w = "UnsupportedThread";
    m = {
        Null: m,
        Payment: n,
        People: e,
        Search: k,
        SearchMessages: l,
        SeeAllGroups: q,
        SeeAllPages: r,
        SeeAllPeople: s,
        SeeAllUnread: t,
        TeamworkSeeAllAnnouncementGroups: u
    };
    n = {
        Recent: v
    };
    e = {
        UnsupportedThread: w
    };
    var x = babelHelpers["extends"]({}, m, n, e),
        y = {
            type: x.Null
        },
        z = "/?$";

    function A(a) {
        a = a.match(new RegExp(c("MessengerURIConstants").THREAD_PREFIX + "([^/]+)/?$"));
        if (a != null) return decodeURIComponent(a[1])
    }
    var B = c("CurrentEnvironment").instagramdotcom ? c("MessengerURIConstants").INSTAGRAM_DIRECT_PATH : c("CurrentEnvironment").facebookdotcom ? c("MessengerURIConstants").FACEBOOK_PREFIX : "";

    function C(a) {
        a = new URL(a.url, window.location.origin);
        var b = a.pathname;
        a = a.searchParams;
        var e = new RegExp("^" + (B + "(/|$)"));
        if (c("CurrentEnvironment").facebookdotcom && !e.test(b)) throw c("FBLogger")("messenger_web_ia").mustfixThrow("MWInboxURIState.NonMessengerState wrong CurrentEnvironment pattern for %s", B);
        b = b.replace(e, "/");
        e = a == null ? void 0 : a.get("fbid");
        a = a == null ? void 0 : a.get("id");
        if (b.match(new RegExp("^" + c("MessengerURIConstants").PEOPLE_PATH)) != null) return {
            type: x.People
        };
        if (b.match(new RegExp("^" + c("MessengerURIConstants").PAYMENT_PATH)) != null) return {
            type: x.Payment
        };
        if (b.match(new RegExp("^" + c("MessengerURIConstants").SEARCH_PATH)) != null) return {
            type: x.Search
        };
        if (b.match(new RegExp("^" + c("MessengerURIConstants").TEAMWORK_GROUP_VIEW)) != null) return {
            type: x.SeeAllGroups
        };
        if (b.match(new RegExp("^" + c("MessengerURIConstants").TEAMWORK_CHAT_VIEW)) != null) return {
            type: x.SeeAllPeople
        };
        if (b.match(new RegExp("^" + c("MessengerURIConstants").TEAMWORK_UNREAD_VIEW)) != null) return {
            type: x.SeeAllUnread
        };
        if (b.match(new RegExp("^" + c("MessengerURIConstants").TEAMWORK_ANNOUNCEMENT_GROUP_VIEW)) != null) return {
            type: x.TeamworkSeeAllAnnouncementGroups
        };
        if (b === "/read/" && e != null) return {
            type: x.Recent,
            uriStateDetails: {
                fbid: (j || (j = d("I64"))).of_string(e),
                type: p.Thread
            }
        };
        if (b.match(new RegExp("^" + (c("MessengerURIConstants").COMPOSE_SUBPATH + z))) != null) return {
            type: x.Recent,
            uriStateDetails: {
                initialTogglePosition: "E2EEToggleOff",
                type: p.Compose
            }
        };
        if (b.match(new RegExp("^" + (c("MessengerURIConstants").PAYMENT_PATH + c("MessengerURIConstants").PAYMENT_PAY_PATH))) != null) return {
            type: x.Recent,
            uriStateDetails: {
                fbid: void 0,
                type: a != null ? p.PayThread : p.PayFriendPicker
            }
        };
        e = F(A(b));
        return e != null ? {
            type: x.Recent,
            uriStateDetails: {
                fbid: e,
                type: p.Thread
            }
        } : y
    }
    var D = c("gkx")("23433") || c("gkx")("22839"),
        E = c("gkx")("5080");

    function a(a) {
        return new URL(a, window.location.origin).pathname.split("/")
    }

    function F(a) {
        try {
            return a != null ? (j || (j = d("I64"))).of_string_opt(a) : void 0
        } catch (a) {
            return void 0
        }
    }

    function b(a) {
        var b, e = (h || (h = c("useReStore")))(),
            g = c("useCurrentRoute")(),
            k = d("CometRouteURL").useRouteURLPath(),
            l = c("useGroupThreadViewParams")();
        a = F(a);
        var m = d("CometRouteParams").useRouteParams();
        b = a != null ? (b = d("ReQLSuspense").first(d("ReQL").fromTableAscending(e.tables.threads).getKeyRange(a), f.id + ":322")) == null ? void 0 : b.threadType : null;
        var n = b != null ? c("mwCMIsAnyCMThread")(b) : !1,
            q = b != null ? d("LSMessagingThreadTypeUtil").isDiscoverablePublicBroadcastChannelWithNoAccessibility(b) : !1;
        if (E && (i || (i = c("Env"))).lastReadMessengerThreadKey !== null && (i || (i = c("Env"))).lastReadMessengerThreadKey !== void 0 && (i || (i = c("Env"))).isLastReadMessengerThreade2ee !== null) {
            var r = (j || (j = d("I64"))).of_float((i || (i = c("Env"))).lastReadMessengerThreadKey),
                s = (i || (i = c("Env"))).isLastReadMessengerThreade2ee === !0 ? p.SecureThread : p.Thread;
            if (k === o && r != null) return {
                type: x.Recent,
                uriStateDetails: {
                    fbid: r,
                    type: s
                }
            }
        }
        if (l != null) return {
            type: x.Recent,
            uriStateDetails: {
                fbid: (j || (j = d("I64"))).of_string(l.threadKey),
                type: p.Thread
            }
        };
        if (g == null) return y;
        if (!k.startsWith(B) && !k.startsWith(c("MessengerURIConstants").GROUPS_PATH)) throw c("FBLogger")("messenger_web_ia").mustfixThrow("MWInboxURIState.NonMessengerState wrong groups path %s", k);
        r = m.initial_e2ee_toggle_position === "1" || m.initial_e2ee_toggle_position === 1 || m.initial_e2ee_toggle_position === !0 ? "E2EEToggleOn" : "E2EEToggleOff";
        s = g.url.substring(B.length);
        k = (l = d("ConstUriUtils").getUriOrThrow(s)) == null ? void 0 : l.getPath().split("/");
        if (a != null) {
            if (k.length === 4 && k[0] === "" && k[1] === "e2ee" && k[2] === "t" && c("isArmadillo")()) return {
                type: x.Recent,
                uriStateDetails: {
                    fbid: a,
                    type: p.SecureThread
                }
            };
            if (b != null && d("LSMessagingThreadTypeUtil").isArmadilloSecure(b)) return C(g);
            if (n && !D) return y;
            return q ? {
                fbid: a,
                type: x.UnsupportedThread
            } : {
                type: x.Recent,
                uriStateDetails: {
                    fbid: a,
                    type: p.Thread
                }
            }
        }
        if (k == null) return C(g);
        switch (k.length) {
            case 2:
                return k[1] === "new" ? {
                    type: x.Recent,
                    uriStateDetails: {
                        initialTogglePosition: r,
                        type: p.Compose
                    }
                } : C(g);
            case 3:
                if (k[1] !== "t") return C(g);
                if (k[2] === "") return C(g);
                m = F(k[2]);
                s = m != null ? d("ReQLSuspense").first(d("ReQL").fromTableAscending(e.tables.threads).getKeyRange(m), f.id + ":456") : null;
                return m != null && s != null && !d("LSMessagingThreadTypeUtil").isArmadilloSecure(s == null ? void 0 : s.threadType) ? {
                    type: x.Recent,
                    uriStateDetails: {
                        fbid: m,
                        type: p.Thread
                    }
                } : y;
            case 0:
            case 1:
            default:
                return C(g)
        }
    }
    g.MWInboxURIStateDetailsType = p;
    g.MWInboxURIStateTag = x;
    g.getRouteTokens = a;
    g.useMWInboxURIState = b
}), 98);
__d("MWInboxProvider.react", ["react", "useMWInboxURIState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h.createContext;
    var j = b();

    function a(a) {
        var b = a.children;
        a = a.threadKey;
        a = d("useMWInboxURIState").useMWInboxURIState(a);
        return i.jsx(j.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.MWInboxProviderContext = j;
    g.MWInboxProvider = a
}), 98);
__d("useMWInboxSelectedThread", ["MWInboxProvider.react", "react", "useMWInboxURIState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        var a = i(d("MWInboxProvider.react").MWInboxProviderContext);
        if (a == null || a.type !== d("useMWInboxURIState").MWInboxURIStateTag.Recent) return;
        a = a.uriStateDetails;
        if (a == null) return;
        switch (a.type) {
            case d("useMWInboxURIState").MWInboxURIStateDetailsType.Thread:
            case d("useMWInboxURIState").MWInboxURIStateDetailsType.SecureThread:
                return a.fbid;
            default:
                return
        }
    }
    g["default"] = a
}), 98);
__d("MWPIsThreadUnread", ["I64", "MWMessageListScrollContext.react", "ReQL", "ReQLSuspense", "gkx", "mwCMIsCMSubthread", "mwIsThreadDisabled", "react", "useMWInboxSelectedThread", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = (i || d("react")).useContext;

    function l(a, b) {
        if (c("mwIsThreadDisabled")(a.takedownState)) return !1;
        if (c("mwCMIsCMSubthread")(a.threadType) && (j || (j = d("I64"))).equal(a.lastReadWatermarkTimestampMs, (j || (j = d("I64"))).zero)) return !1;
        return c("gkx")("7117") && (b != null && document.hasFocus() && (j || (j = d("I64"))).equal(a.threadKey, b)) ? !1 : (j || (j = d("I64"))).compare(a.lastActivityTimestampMs, a.lastReadWatermarkTimestampMs) > 0
    }

    function a(a) {
        var b, e = (h || (h = c("useReStore")))(),
            g = m();
        return (b = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(e.tables.threads, ["takedownState", "threadType", "lastReadWatermarkTimestampMs", "lastActivityTimestampMs", "threadKey"]).getKeyRange(a).map(function(a) {
                return l(a, g)
            })
        }, [e.tables.threads, g, a], f.id + ":74")) != null ? b : !1
    }

    function m() {
        var a, b = c("useMWInboxSelectedThread")();
        a = (a = k(d("MWMessageListScrollContext.react").MWMessageListScrollContext)) != null ? a : {};
        a = a.checkIsThreadAtBottom;
        return b != null && a != null && a((j || (j = d("I64"))).to_string(b)) ? b : null
    }
    g.isThreadUnread = l;
    g.useIsThreadUnread = a
}), 98);
__d("isArmadilloUI", ["qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("qex")._("564") === !0
    }
    g["default"] = a
}), 98);
__d("MWThreadListSupportedThreadTypes", ["LSIntEnum", "MetaConfig", "isArmadilloUI", "isCommunityContainersEnabled"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = [(h || (h = d("LSIntEnum"))).ofNumber(1), h.ofNumber(201), h.ofNumber(2), h.ofNumber(5), h.ofNumber(6), h.ofNumber(3), h.ofNumber(23), h.ofNumber(18), h.ofNumber(19)].concat(c("isArmadilloUI")() ? [(h || (h = d("LSIntEnum"))).ofNumber(15), (h || (h = d("LSIntEnum"))).ofNumber(16)] : [], c("MetaConfig")._("42") ? [(h || (h = d("LSIntEnum"))).ofNumber(150)] : [], c("MetaConfig")._("36") ? [(h || (h = d("LSIntEnum"))).ofNumber(154)] : [], c("MetaConfig")._("32") ? [(h || (h = d("LSIntEnum"))).ofNumber(152)] : [], c("isCommunityContainersEnabled")() ? [(h || (h = d("LSIntEnum"))).ofNumber(17)] : []);
    b = a;
    g["default"] = b
}), 98);
__d("MWCMUnreadThreadCountHooks", ["I64", "LSIntEnum", "LSMessagingThreadTypeUtil", "MWCMThreadTypes.react", "MWPIsThreadUnread", "MWThreadListSupportedThreadTypes", "MWXacGating", "ReQL", "ReQLSuspense", "ServerTime", "isCommunityContainersEnabled", "isMWXacGroupThread", "justknobx", "mwIsThreadDisabled", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = 20;

    function a(a) {
        var b = (j || (j = c("useReStore")))();
        return d("ReQLSuspense").useFirst(function() {
            return o(a, b)
        }, [b, a], f.id + ":42") != null
    }

    function b(a) {
        var b = (j || (j = c("useReStore")))(),
            e = d("ReQLSuspense").useFirst(function() {
                return d("ReQL").fromTableAscending(b.tables.threads.index("parentThreadKeyLastActivityTimestampMs")).getKeyRange(a)
            }, [b, a], f.id + ":54") != null,
            g = d("MWPIsThreadUnread").useIsThreadUnread(a);
        return [g, e]
    }

    function e(a) {
        var b = (j || (j = c("useReStore")))();
        return d("ReQLSuspense").useArray(function() {
            return o(a, b)
        }, [b, a], f.id + ":67").length
    }

    function l(a) {
        a = (h || (h = d("I64"))).to_float(a.muteExpireTimeMs);
        return a === -1 || a > d("ServerTime").getMillis()
    }

    function m(a) {
        var b = d("MWCMThreadTypes.react").isUnjoinedCMThread(a.threadType) && a.hasPendingInvitation === !0;
        if (b) return !0;
        return l(a) ? !1 : d("MWPIsThreadUnread").isThreadUnread(a)
    }

    function n(a) {
        var b = c("MWThreadListSupportedThreadTypes").some(function(b) {
                return (h || (h = d("I64"))).equal(a.threadType, b)
            }),
            e = d("MWCMThreadTypes.react").isUnjoinedCMThread(a.threadType) && a.hasPendingInvitation === !0,
            f = d("LSMessagingThreadTypeUtil").isArmadilloSecure(a.threadType);
        if (c("isCommunityContainersEnabled")() && (h || (h = d("I64"))).equal(a.threadType, (i || (i = d("LSIntEnum"))).ofNumber(18))) return !1;
        if (e) return !0;
        if (c("mwIsThreadDisabled")(a.takedownState) || !b) return !1;
        if ((h || (h = d("I64"))).equal(a.threadKey, (i || (i = d("LSIntEnum"))).ofNumber(-12)) || (h || (h = d("I64"))).equal(a.threadKey, (i || (i = d("LSIntEnum"))).ofNumber(-18))) return !1;
        if (a.isHidden === !0 && !f) return !1;
        if (d("MWCMThreadTypes.react").isUnjoinedCMThread(a.threadType)) return !1;
        return !d("MWXacGating").isGroupsEnabled() && c("isMWXacGroupThread")(a) ? !1 : !0
    }
    var o = c("justknobx")._("3215") ? q : p;

    function p(a, b) {
        var c = d("ReQL").fromTableAscending(b.tables.threads.index("parentThreadKeyLastActivityTimestampMs")).getKeyRange(a);
        b = d("ReQL").fromTableAscending(b.tables.threads.index("secondaryParentThreadKeyLastActivityTimestampMs")).getKeyRange(a);
        a = d("ReQL").union(c, b);
        return a.filter(n).filter(m)
    }

    function q(a, b) {
        var c = d("ReQL").fromTableDescending(b.tables.threads.index("parentThreadKeyLastActivityTimestampMs")).getKeyRange(a).filter(n).take(k);
        b = d("ReQL").fromTableDescending(b.tables.threads.index("secondaryParentThreadKeyLastActivityTimestampMs")).getKeyRange(a).filter(n).take(k);
        a = d("ReQL").union(c, b).take(k);
        return a.filter(m)
    }
    q = {
        isThreadUnreadFilter: m,
        threadListFilter: n,
        useHasUnreadThread: a,
        useMaybeReadUnreadThreadsFromCommunity: b,
        useUnreadThreadCount: e
    };
    p = q;
    g["default"] = p
}), 98);
__d("MWXCard.react", ["cr:8789", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsx(b("cr:8789"), babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXIconBellCross", ["MWXSvgIcon", "SVGIcon", "cr:12320", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12320")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWXIconDocument", ["MWXSvgIcon", "SVGIcon", "cr:12395", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12395")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWXPopover.react", ["cr:2457", "cr:4720", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    c = i.forwardRef(a);

    function a(a, c) {
        a = babelHelpers["extends"]({}, a);
        if (b("cr:4720") != null) return i.jsx(b("cr:4720"), babelHelpers["extends"]({}, a, {
            ref: c
        }));
        return b("cr:2457") != null ? i.jsx(b("cr:2457"), babelHelpers["extends"]({}, a, {
            ref: c
        })) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = c;
    g["default"] = e
}), 98);
__d("MessengerBellCrossFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M9.244 24.99h-.001L26.867 7.366a1.25 1.25 0 1 1 1.768 1.768l-3.296 3.295a2 2 0 0 0-.554 1.766l1.05 5.877a3 3 0 0 0 .831 1.594l.92.92a1.414 1.414 0 0 1-1 2.414H13.597a2 2 0 0 0-1.414.586l-3.05 3.049a1.25 1.25 0 1 1-1.767-1.768l1.878-1.877z"
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M15.041 27.498c-.045-.273.183-.498.459-.498h5c.276 0 .504.226.459.498a3 3 0 0 1-5.918 0zM21.522 8.024a6.57 6.57 0 0 0-9.99 4.39L10.537 18l-.056.27c-.152.729.738 1.209 1.264.682l9.862-9.86c.312-.314.29-.83-.084-1.068z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("RTWebPreCallContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("react")).createContext;
    b = a(null);
    g["default"] = b
}), 98);
__d("killswitch", ["KSConfig"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return b("KSConfig").killed.has(a)
    }
    e.exports = a
}), null);
__d("mwCMIsThreadBumped", ["I64", "mwCMIsAnyCMThread"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var b = a.secondaryParentThreadKey;
        a = a.threadType;
        return c("mwCMIsAnyCMThread")(a) && b != null && (h || (h = d("I64"))).equal(b, (h || (h = d("I64"))).of_int32(0))
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("ARIA_LABEL_PLACEHOLDER_FIXME", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = null;
    f["default"] = a
}), 66);
__d("dangerouslyCoerceAriaLabelPlaceholder", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f["default"] = a
}), 66);
__d("BasePopover.react", ["dangerouslyCoerceAriaLabelPlaceholder", "react", "react-strict-dom", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            root: {
                position: "x1n2onr6",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        var e = a["aria-describedby"],
            f = a["aria-label"],
            g = a["aria-labelledby"],
            h = a.arrowAlignment;
        h = h === void 0 ? "center" : h;
        var k = a.arrowImpl,
            l = a.id,
            m = a.role;
        m = m === void 0 ? "dialog" : m;
        var n = a.testid,
            o = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["aria-describedby", "aria-label", "aria-labelledby", "arrowAlignment", "arrowImpl", "id", "role", "testid", "xstyle"]);
        return k ? i.jsx(k, babelHelpers["extends"]({
            "aria-describedby": e,
            "aria-label": f,
            "aria-labelledby": g,
            arrowAlignment: h,
            id: l,
            ref: b,
            role: m,
            testid: void 0,
            xstyle: o
        }, a)) : i.jsx(d("react-strict-dom").html.div, babelHelpers["extends"]({
            "aria-label": c("dangerouslyCoerceAriaLabelPlaceholder")(f),
            "aria-labelledby": g,
            id: l,
            ref: b,
            role: m,
            style: [j.root, o]
        }, c("testID")(n), a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("CometInteractionSourceContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(10);
    g["default"] = b
}), 98);
__d("useFeedImageErrorEventLoggerCbs", ["Banzai", "CometInteractionSourceContext", "Random", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useRef,
        l = 1e3,
        m = function(a) {
            var b = a.result,
                e = a.src;
            a = a.surface;
            d("Random").coinflip(l) && c("Banzai").post("logger:WWWImageLoadSrcEventLoggerConfig", {
                result: b,
                src: e,
                surface: a
            })
        };

    function a(a) {
        var b = a.onError,
            d = a.onLoad,
            e = a.src,
            f = k(null);
        a = j(c("CometInteractionSourceContext"));
        var g = a === 3 ? "profile" : a === 0 ? "feed" : null;
        a = i(function(a) {
            d != null && d(a);
            if (f.current === e) return;
            typeof e === "string" && (m({
                result: "success",
                src: e,
                surface: g
            }), f.current = e)
        }, [d, e, g]);
        var h = i(function(a) {
            b != null && b(a);
            if (f.current === e) return;
            typeof e === "string" && (m({
                result: "error",
                src: e,
                surface: g
            }), f.current = e)
        }, [b, e, g]);
        return g == null || typeof e !== "string" ? {
            _onError: b,
            _onLoad: d
        } : {
            _onError: h,
            _onLoad: a
        }
    }
    g["default"] = a
}), 98);
__d("CometImage.react", ["BaseImage.react", "CometImageFromIXValue.react", "cr:2010754", "gkx", "mergeRefs", "react", "useFeedImageErrorEventLoggerCbs", "xplatToDOMRef"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    e = h;
    var j = e.useMemo,
        k = e.useRef,
        l = "1";
    e = i.forwardRef(a);

    function a(a, e) {
        var f = a.alt,
            g = a.objectFit,
            h = a.onError,
            m = a.onLoad,
            n = a.sizes,
            o = a.src,
            p = a.srcSet,
            q = a.testid;
        q = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["alt", "objectFit", "onError", "onLoad", "sizes", "src", "srcSet", "testid", "xstyle"]);
        var r = k(null),
            s = j(function() {
                return c("mergeRefs")(r, e)
            }, [r, e]);
        h = c("useFeedImageErrorEventLoggerCbs")({
            onError: h,
            onLoad: m,
            src: o
        });
        m = h._onError;
        h = h._onLoad;
        var t = c("gkx")("22879") ? l : void 0;

        function u(a, c, d, e, f, g) {
            b("cr:2010754") && c === "mount" && r.current != null && typeof o === "string" && b("cr:2010754").trackImagePerf(r.current, g, o, {
                mutationType: "reactCommit"
            })
        }
        if (typeof o === "string") {
            a = i.jsx(c("BaseImage.react"), babelHelpers["extends"]({}, a, {
                alt: f,
                elementtiming: t,
                objectFit: g,
                onError: m,
                onLoad: h,
                ref: d("xplatToDOMRef").xplatToDOMRef(s),
                sizes: n,
                src: o,
                srcSet: p,
                testid: void 0,
                xstyle: q
            }));
            return c("gkx")("22879") ? i.jsx(i.Profiler, {
                id: l,
                onRender: u,
                children: a
            }) : a
        }
        return i.jsx(c("CometImageFromIXValue.react"), {
            alt: f,
            objectFit: g,
            ref: s,
            source: o,
            testid: void 0,
            xstyle: q
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a = e;
    g["default"] = a
}), 98);
__d("CometLinkUtils.react", ["CometTextTypography"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            blueLink: {
                color: "x1fey0fg",
                $$css: !0
            },
            disabled: {
                color: "x1dntmbh",
                $$css: !0
            },
            highlight: {
                color: "x1qq9wsj",
                $$css: !0
            },
            inheritColor: {
                color: "x1heor9g",
                $$css: !0
            },
            negative: {
                color: "x1a1m0xk",
                $$css: !0
            },
            positive: {
                color: "x6u5lvz",
                $$css: !0
            },
            primary: {
                color: "xzsf02u",
                $$css: !0
            },
            secondary: {
                color: "xi81zsa",
                $$css: !0
            },
            tertiary: {
                color: "x12scifz",
                $$css: !0
            },
            white: {
                color: "x14ctfv",
                $$css: !0
            }
        },
        i = {
            bold: {
                fontWeight: "x1xlr1w8",
                $$css: !0
            },
            inheritFontWeight: {
                fontWeight: "x1pd3egz",
                $$css: !0
            },
            medium: {
                fontWeight: "xk50ysn",
                $$css: !0
            },
            normal: {
                fontWeight: "xo1l8bm",
                $$css: !0
            },
            semibold: {
                fontWeight: "x1s688f",
                $$css: !0
            }
        };

    function a(a, b, c) {
        a = (a = a) != null ? a : b != null ? l(b, c) : "inherit";
        return a !== "inherit" && h[a]
    }

    function b(a, b) {
        b = m(b);
        a = n(a);
        return b || a ? h.inheritColor : h.blueLink
    }

    function d(a, b, c) {
        a = (a = a) != null ? a : b != null ? j(b, c) : "inherit";
        return a !== "inherit" && i[a]
    }

    function e(a) {
        a = m(a);
        return a ? i.inheritFontWeight : i.semibold
    }

    function j(a, b) {
        if (!b) {
            b = k(a);
            return c("CometTextTypography")[b].fontWeight
        }
        return "inherit"
    }

    function k(a) {
        switch (a) {
            case "headline3":
                return "headlineEmphasized3";
            case "headline4":
                return "headlineEmphasized4";
            case "body1":
                return "bodyLink1";
            case "body2":
                return "bodyLink2";
            case "body3":
                return "bodyLink3";
            case "body4":
                return "bodyLink4";
            default:
                return a
        }
    }

    function l(a, b) {
        switch (a) {
            case "headline3":
            case "headline4":
            case "body1":
            case "body2":
            case "body3":
            case "body4":
                return b ? "blueLink" : "primary";
            case "meta1":
            case "meta2":
            case "meta3":
            case "meta4":
                return b ? "blueLink" : "inherit";
            default:
                return "inherit"
        }
    }

    function m(a) {
        return a != null && (a === "headlineDeemphasized3" || a === "headlineDeemphasized4" || a === "headlineEmphasized1" || a === "headlineEmphasized2" || a === "headlineEmphasized3" || a === "headlineEmphasized4" || a === "headline3" || a === "headline4" || a === "entityHeaderHeadline1" || a === "entityHeaderHeadline2")
    }

    function n(a) {
        return a != null && (a === "negative" || a === "positive")
    }
    g.getLinkColorStyle = a;
    g.getLinkColorStyle__new = b;
    g.getLinkWeightStyle = d;
    g.getLinkWeightStyle__new = e
}), 98);
__d("CometLinkOldImpl.react", ["BaseLink.react", "CometDangerouslySuppressInteractiveElementsContext", "CometLinkUtils.react", "FDSTextContext", "isCometRouterUrl", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            disabled: {
                color: "x1dntmbh",
                textDecorationLine: "x1ubmc1d xkrqix3",
                $$css: !0
            },
            root: {
                color: "x1heor9g",
                textDecorationLine: "x1sur9pj xkrqix3",
                $$css: !0
            }
        },
        l = {
            block: {
                display: "x1lliihq",
                $$css: !0
            },
            "inline-block": {
                display: "x1rg5ohu",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var e = a.color_DEPRECATED,
            f = a.disabled;
        f = f === void 0 ? !1 : f;
        var g = a.display_DEPRECATED;
        g = g === void 0 ? "inline" : g;
        var h = a.fbclid,
            m = a.href,
            n = a.lynxMode,
            o = a.role,
            p = a.target,
            q = a.weight_DEPRECATED,
            r = a.xstyle_DEPRECATED,
            s = babelHelpers.objectWithoutPropertiesLoose(a, ["color_DEPRECATED", "disabled", "display_DEPRECATED", "fbclid", "href", "lynxMode", "role", "target", "weight_DEPRECATED", "xstyle_DEPRECATED"]),
            t = d("FDSTextContext").useFDSTextContext(),
            u = j(c("CometDangerouslySuppressInteractiveElementsContext")),
            v = p === "_blank" || p == null && m != null && m !== "#" && !c("isCometRouterUrl")(m);
        o = o == null && (m == null || m === "#") ? "button" : o;
        e = d("CometLinkUtils.react").getLinkColorStyle(e, t == null ? void 0 : t.type, v);
        q = d("CometLinkUtils.react").getLinkWeightStyle(q, t == null ? void 0 : t.type, v);
        return u ? i.jsx(d("react-strict-dom").html.span, {
            ref: b,
            style: [e, q, f && k.disabled, g !== "inline" && l[g]],
            children: a.children
        }) : i.jsx(c("BaseLink.react"), babelHelpers["extends"]({}, s, {
            disabled: f,
            display: "inline",
            fbclid: h,
            href: m,
            lynxMode: n,
            ref: b,
            role: o,
            target: v ? "_blank" : p,
            xstyle: [k.root, e, q, f && k.disabled, g !== "inline" && l[g], r]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("cssVar", [], (function(a, b, c, d, e, f) {
    function a(a) {
        throw new Error('cssVar("' + a + '"): Unexpected class transformation.')
    }
    f["default"] = a
}), 66);
__d("CometLoadingAnimation.react", ["cssVar", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || d("react"),
        l = 38,
        m = 62,
        n = 42,
        o = 2,
        p = 3,
        q = 4,
        r = l / 2,
        s = m / 2,
        t = n / 2,
        u = r - 2,
        v = s - 2,
        w = t - 2,
        x = {
            animationCircleWrapper: {
                animationDuration: "xeaay5l",
                animationIterationCount: "xa4qsjk",
                animationName: "xnjvcao",
                animationTimingFunction: "x1esw782",
                transformOrigin: "x1bndym7",
                $$css: !0
            },
            animationPaused: {
                animationPlayState: "xorstpt",
                $$css: !0
            },
            animationRoot: {
                position: "x10l6tqk",
                $$css: !0
            },
            animationRootSize36: {
                start: "x1150agl",
                top: "x1e0gzzx",
                $$css: !0
            },
            animationRootSize40: {
                start: "x1150agl",
                top: "x1e0gzzx",
                $$css: !0
            },
            animationRootSize60: {
                start: "x1150agl",
                top: "x1e0gzzx",
                $$css: !0
            },
            animationUploadingCircle: {
                animationDirection: "xeo85xg",
                animationDuration: "x7s8090",
                animationIterationCount: "xa4qsjk",
                animationTimingFunction: "x1esw782",
                transformOrigin: "x1bndym7",
                $$css: !0
            },
            animationUploadingCircleSize36: {
                animationDirection: "xeo85xg",
                animationDuration: "xeaay5l",
                animationIterationCount: "xa4qsjk",
                animationName: "xq0anyh",
                animationTimingFunction: "x1esw782",
                strokeWidth: "xvlca1e",
                $$css: !0
            },
            animationUploadingCircleSize40: {
                animationDirection: "xeo85xg",
                animationDuration: "xeaay5l",
                animationIterationCount: "xa4qsjk",
                animationName: "x62hu5v",
                animationTimingFunction: "x1esw782",
                strokeWidth: "xqjr0vm",
                $$css: !0
            },
            animationUploadingCircleSize60: {
                animationDirection: "xeo85xg",
                animationDuration: "xeaay5l",
                animationIterationCount: "xa4qsjk",
                animationName: "xm4p48w",
                animationTimingFunction: "x1esw782",
                strokeWidth: "x17ld789",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.animationPaused;
        b = b === void 0 ? !1 : b;
        a = a.size;
        var d, e, f;
        switch (a) {
            case 36:
                d = l;
                e = r;
                f = u;
                break;
            case 40:
                d = n;
                e = t;
                f = w;
                break;
            case 60:
            default:
                d = m;
                e = s;
                f = v;
                break
        }
        return k.jsx("svg", {
            className: (i || (i = c("stylex")))(x.animationRoot, a === 36 && x.animationRootSize36, a === 60 && x.animationRootSize60, a === 40 && x.animationRootSize40),
            height: d,
            width: d,
            children: k.jsx("g", {
                className: i(x.animationCircleWrapper, b && x.animationPaused),
                children: k.jsx("circle", {
                    className: i(x.animationUploadingCircle, a === 36 && x.animationUploadingCircleSize36, a === 40 && x.animationUploadingCircleSize40, a === 60 && x.animationUploadingCircleSize60, b && x.animationPaused),
                    cx: e,
                    cy: e,
                    fill: "none",
                    r: f,
                    stroke: "#1877F2",
                    strokeWidth: a === 36 ? o : a === 40 ? p : q
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometRouteParams", ["CometRouteURL", "useCurrentRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = c("useCurrentRoute")();
        if (a != null) return a.params;
        else {
            return (a = d("CometRouteURL").getWindowURLParams()) != null ? a : {}
        }
    }

    function a(a) {
        return a(h())
    }
    g.useRouteParams = h;
    g.useCometRefinedRouteParams = a
}), 98);
__d("CometRouteProductAttributionContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometSSRRenderingStateHooks", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useSyncExternalStore,
        j = function() {
            return function() {}
        };

    function k() {
        return i(j, function() {
            return !0
        }, function() {
            return !1
        })
    }

    function a() {
        return !k()
    }
    g.useIsClientRendering = k;
    g.useIsServerRenderingOrHydrating = a
}), 98);
__d("CometSSRSuspendOnServer.react", ["CometSSRClientRender", "CometSSRRenderingStateHooks", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");

    function a(a) {
        a = a.children;
        var b = d("CometSSRRenderingStateHooks").useIsServerRenderingOrHydrating();
        if (b) throw d("CometSSRClientRender").CometSSRClientRender("CometSSRSuspendOnServer: This component is marked to be client rendered");
        return a
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometScreenReaderText.react", ["BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            visuallyHidden: {
                clip: "xzpqnlu",
                clipPath: "x1hyvwdk",
                fontSize: "x14bfe9o",
                height: "xjm9jq1",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x10l6tqk",
                width: "x1i1rx1s",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.text;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["text"]);
        return i.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            xstyle: j.visuallyHidden,
            children: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometScrollableAreaImpl.react", ["BaseScrollableArea.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = a.horizontal;
        d = d === void 0 ? !0 : d;
        var e = a.id,
            f = a.vertical;
        f = f === void 0 ? !0 : f;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["horizontal", "id", "vertical"]);
        return i.jsx(c("BaseScrollableArea.react"), babelHelpers["extends"]({}, a, {
            horizontal: d,
            id: e,
            ref: b,
            vertical: f
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("CometScrollableArea.react", ["CometScrollableAreaImpl.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("CometScrollableAreaImpl.react")
}), 98);
__d("CometTriggerAccessibilityAlertContext", ["FBLogger", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(function() {
        c("FBLogger")("comet_ax").blameToPreviousFrame().mustfix("CometTriggerAccessibilityAlertContext was not provided.");
        return c("emptyFunction")
    });
    g["default"] = b
}), 98);
__d("MAWStateContext.react", ["EncryptedBackupsDYITypes", "MAWSharedProtocolQueueConst", "err", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    f = h || d("react");
    var i = f.createContext,
        j = f.useCallback,
        k = f.useContext,
        l = f.useEffect,
        m = f.useRef,
        n = f.useState;
    f = {
        ebDYIState: d("EncryptedBackupsDYITypes").EncryptedBackupsDYIState.NotStarted,
        ephemeralSettings: {},
        isDbMigrating: !1,
        mediaDownloadRetryCount: {},
        mediaDownloadStatus: {},
        messageLatencies: {},
        offlineQueueCount: 0,
        offlineQueueProgressDownloaded: 0,
        offlineQueueProgressProcessed: 0,
        offlineQueueSyncState: d("MAWSharedProtocolQueueConst").OfflineConsumerStatus.Initializing,
        offlineQueueThreadStatus: {},
        unArchivedSelfDeviceChangeAlerts: 0
    };

    function a() {
        var a = k(q);
        return j(function(b, c) {
            c === void 0 && (c = Date.now()), a({
                optimisticMsgId: b,
                tag: "OptimisticSendMessage",
                timestamp: c
            })
        }, [a])
    }

    function b() {
        var a = k(q);
        return j(function() {
            a({
                tag: "ClearEphemeralSettings"
            })
        }, [a])
    }
    var o = {
            state: f,
            subscriptions: new Set()
        },
        p = i(function() {
            return o
        });
    d = i(o);
    var q = i(function(a) {
        throw c("err")("MAW Dispatch not implemented")
    });

    function e(a) {
        var b = k(p)(),
            c = b.state,
            d = b.subscriptions;
        b = n(function() {
            return a(c)
        });
        var e = b[0],
            f = b[1],
            g = m(e);
        l(function() {
            var b = function(b) {
                b = a(b);
                b !== g.current && (g.current = b, f(b))
            };
            d.add(b);
            return function() {
                d["delete"](b)
            }
        }, [d, a]);
        return e
    }
    g.initialState = f;
    g.useDispatchOptimisticSendMessage = a;
    g.useDispatchClearEphemeralSettings = b;
    g.MAWNonRerenderingStateContext = p;
    g.MAWStateContext = d;
    g.MAWDispatchContext = q;
    g.useMAWSelector = e
}), 98);
__d("useBaseCallout", ["BaseContextualLayerAnchorRootContext", "BaseScrollableAreaContext", "LayoutAnimationBoundaryContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useContext,
        j = b.useEffect,
        k = b.useId,
        l = b.useRef;

    function a(a, b, d, e) {
        var f = i(c("BaseContextualLayerAnchorRootContext")),
            g = l(null),
            h = k(),
            m = k(),
            n = k(),
            o = i(c("BaseScrollableAreaContext")),
            p = i(c("LayoutAnimationBoundaryContext"));
        j(function() {
            if (d == null || g.current == null) return;
            if (a != null && b === !0) {
                d.addCallout({
                    anchorRef: g,
                    anchorRootRefContext: f,
                    animationContext: p,
                    calloutID: h,
                    calloutProps: a,
                    contentID: m,
                    contextualLayerProps: e,
                    scrollableAreaContext: o,
                    titleID: n
                });
                return function() {
                    return d.removeCallout(h)
                }
            }
        }, [p, f, d, h, m, n, a, b, o, e]);
        return {
            anchorRef: g,
            contentID: b ? m : void 0,
            titleID: b ? n : void 0
        }
    }
    g["default"] = a
}), 98);
__d("useCometLazyDialog", ["FDSDialogLoadingState.react", "react", "tracePolicyFromResource", "useBaseLazyDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = function(a) {
            return i.jsx(c("FDSDialogLoadingState.react"), {
                onClose: a
            })
        };

    function a(a, b) {
        var d = c("tracePolicyFromResource")("comet.dialog", a);
        return c("useBaseLazyDialog")(a, (a = b) != null ? a : j, d)
    }
    g["default"] = a
}), 98);
__d("useFDSCallout", ["FDSCalloutContext", "react", "useBaseCallout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a(a, b) {
        a = (a = a) != null ? a : {};
        var d = a.align,
            e = a.disableAutoAlign,
            f = a.disableAutoFlip,
            g = a.position;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["align", "disableAutoAlign", "disableAutoFlip", "position"]);
        var h = i(c("FDSCalloutContext"));
        b = c("useBaseCallout")(a, b, h, {
            align: d,
            disableAutoAlign: e,
            disableAutoFlip: f,
            position: g
        });
        h = b.anchorRef;
        d = b.contentID;
        e = b.titleID;
        return {
            anchorRef: h,
            contentID: d,
            titleID: a.title == null ? void 0 : e
        }
    }
    g["default"] = a
}), 98);
__d("useRouteProductAttribution", ["CometRouteProductAttributionContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        return i(c("CometRouteProductAttributionContext"))
    }
    g["default"] = a
}), 98);
__d("useMinifiedProductAttribution", ["CometProductAttribution", "useRouteProductAttribution"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("useRouteProductAttribution")();
        return a != null ? d("CometProductAttribution").minifyProductAttributionV2(a) : null
    }
    g["default"] = a
}), 98);
__d("useServerTime", ["JSScheduler", "ServerTime", "clearInterval", "react", "setInterval"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    b = i || d("react");
    var j = b.useEffect,
        k = b.useState,
        l = 6e4,
        m = new Set(),
        n = null,
        o = !1;

    function p() {
        m.forEach(function(a) {
            return a()
        }), o = !1
    }

    function q(a) {
        a === void 0 && (a = l), n = c("setInterval")(function() {
            o || (o = !0, (h || (h = c("JSScheduler"))).scheduleSpeculativeCallback(p))
        }, a)
    }

    function r() {
        m.size === 0 && (c("clearInterval")(n), n = null)
    }

    function s(a, b) {
        b === void 0 && (b = l);
        m.add(a);
        n == null && q(b);
        return function() {
            m["delete"](a), r()
        }
    }

    function t() {
        return new Date(d("ServerTime").getMillis())
    }

    function a(a) {
        a === void 0 && (a = l);
        var b = k(function() {
                return t()
            }),
            c = b[0],
            d = b[1],
            e = function() {
                return d(t())
            };
        j(function() {
            return s(e, a)
        }, [a]);
        return c
    }
    g["default"] = a
}), 98);
__d("useSetAttributeRef", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useCallback;

    function a(a, b) {
        return i(function(c) {
            c != null && c.setAttribute(a, b)
        }, [a, b])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("WAGetUserMedia", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        var a = navigator.mediaDevices;
        return a == null ? null : function(b) {
            return a.getUserMedia(b)
        }
    }
    b = a();
    f.getUserMedia = b
}), 66);
__d("WAOpusRecorderWorkerClient", ["WAWebOpusRecorderWorkerResource", "WorkerBundleResource"], (function(a, b, c, d, e, f, g) {
    var h = function() {
        function a(a) {
            this.$1 = d("WorkerBundleResource").createDedicatedWebWorker(c("WAWebOpusRecorderWorkerResource"));
            this.$1.onmessage = (a = a) != null ? a : null
        }
        var b = a.prototype;
        b.getWorker = function() {
            return this.$1
        };
        b.postMessage = function(a, b) {
            a = {
                type: "message",
                message: a
            };
            this.$1.postMessage(a, b)
        };
        b.addEventListener = function(a, b) {
            this.$1.addEventListener(a, b)
        };
        b.removeEventListener = function(a, b) {
            this.$1.addEventListener(a, b)
        };
        return a
    }();

    function a() {
        return new h()
    }

    function b(a) {
        return new h(a)
    }
    g.WAOpusRecorderWorkerClient = h;
    g.getOpusEncoderWorker = a;
    g.getOpusDecoderWorker = b
}), 98);
__d("WAPttComposerOpusRecorder", ["$InternalEnum", "Promise", "WAGetUserMedia", "WANullthrows", "WAOpusRecorderWorkerClient", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    var h, i = {
            bitRate: 16e3,
            bufferLength: 4096,
            numberOfChannels: 1,
            encoderSampleRate: 16e3,
            maxBuffersPerPage: 40,
            encoderApplication: 2048,
            encoderFrameSize: 20,
            streamOptions: {
                optional: [],
                mandatory: {
                    googEchoCancellation: !1,
                    googAutoGainControl: !1,
                    googNoiseSuppression: !1,
                    googHighpassFilter: !1
                }
            }
        },
        j = b("$InternalEnum").Mirrored(["INACTIVE", "RECORDING", "PAUSED", "STOPPED"]);
    a = function() {
        function a(a) {
            var d = this;
            this._duration = 0;
            this._recordedPages = [];
            this._state = j.INACTIVE;
            this._isFirstBuffer = !1;
            this._requestCount = 0;
            this._pendingFlushResolvers = new Map();
            this._handleEncoderMessage = function(a) {
                a = a.data;
                switch (a.message) {
                    case "page":
                        d._storePage(a.page);
                        break;
                    case "flushed":
                        d._handleFlushed(a.requestId);
                        break;
                    default:
                        throw c("err")("Invalid message event type: " + a.message)
                }
            };
            if (!l()) throw c("err")("Recording is not supported in this browser");
            this._createStream = a.createStream;
            this._onDuration = a.onDuration;
            this._onPause = a.onPause;
            this._onResume = a.onResume;
            this._onStart = a.onStart;
            this._onStop = a.onStop;
            this._handlePage = a.onPage;
            this._completeRecordingPromise = new(h || (h = b("Promise")))(function(a) {
                d._resolveCompleteRecordingPromise = a
            });
            this._audioContext = new AudioContext();
            this._encoderNode = this._audioContext.createScriptProcessor(i.bufferLength, i.numberOfChannels, i.numberOfChannels);
            this._encoderNode.onaudioprocess = function(a) {
                d._encodeBuffers(a.inputBuffer)
            };
            this._monitorNode = this._audioContext.createGain()
        }
        var e = a.prototype;
        e.getState = function() {
            return this._state
        };
        e.start = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                switch (this._state) {
                    case j.RECORDING:
                        return !0;
                    case j.STOPPED:
                        return !1;
                    case j.PAUSED:
                        return this.resume();
                    case j.INACTIVE:
                        break
                }
                this._recordedPages = [];
                this._isFirstBuffer = !0;
                this._duration = 0;
                var a = d("WAOpusRecorderWorkerClient").getOpusEncoderWorker();
                this._encoder = a;
                a.addEventListener("message", this._handleEncoderMessage);
                var b = (yield this._startRecording());
                if (!b) return !1;
                this._onStart == null ? void 0 : this._onStart();
                this._onDuration == null ? void 0 : this._onDuration(this._duration);
                a.postMessage({
                    command: "encode-init",
                    config: babelHelpers["extends"]({}, i, {
                        originalSampleRate: this._audioContext.sampleRate
                    })
                });
                this._encoderNode.connect(this._audioContext.destination);
                return !0
            });

            function c() {
                return a.apply(this, arguments)
            }
            return c
        }();
        e.stop = function() {
            var a;
            if (this._state === j.STOPPED) return;
            this._state = j.STOPPED;
            (a = this._recordingAbortController) == null ? void 0 : a.abort();
            this._audioContext.close && this._audioContext.close();
            this._monitorNode.disconnect();
            this._encoderNode.disconnect();
            (a = this._encoder) == null ? void 0 : a.postMessage({
                command: "encode-done"
            })
        };
        e.pause = function() {
            var a;
            if (this._state !== j.RECORDING) return;
            this._state = j.PAUSED;
            (a = this._recordingAbortController) == null ? void 0 : a.abort();
            this._onPause == null ? void 0 : this._onPause()
        };
        e.resume = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                switch (this._state) {
                    case j.RECORDING:
                        return !0;
                    case j.STOPPED:
                        return !1;
                    case j.INACTIVE:
                        throw c("err")("Attempting to resume recording that hasn't started");
                    case j.PAUSED:
                        break
                }
                var a = (yield this._startRecording());
                if (!a) return !1;
                this._onResume == null ? void 0 : this._onResume();
                return !0
            });

            function d() {
                return a.apply(this, arguments)
            }
            return d
        }();
        e.getDuration = function() {
            return this._duration
        };
        e.getMonitorNode = function() {
            return this._monitorNode
        };
        e._encodeBuffers = function(a) {
            if (this._isFirstBuffer) {
                this._isFirstBuffer = !1;
                return
            }
            if (this._state !== j.RECORDING) return;
            var b = [];
            for (var d = 0; d < a.numberOfChannels; d++) b[d] = a.getChannelData(d);
            d = c("WANullthrows")(this._encoder);
            d.postMessage({
                command: "encode",
                buffers: b
            });
            this._duration += a.duration;
            this._onDuration == null ? void 0 : this._onDuration(this._duration)
        };
        e._getNextRequestId = function() {
            this._requestCount++;
            return this._requestCount
        };
        e._startRecording = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                this._state = j.RECORDING;
                this._recordingAbortController = new AbortController();
                var a = (yield m(this._createStream, this._audioContext, [this._encoderNode, this._monitorNode], this._recordingAbortController.signal));
                if (!a) {
                    this.stop();
                    return !1
                }
                return !0
            });

            function a() {
                return a.apply(this, arguments)
            }
            return a
        }();
        e._storePage = function(a) {
            this._recordedPages.push(a);
            if (a[5] & 4) {
                this._handlePage == null ? void 0 : this._handlePage(a, !0);
                var b = c("WANullthrows")(this._encoder);
                b.removeEventListener("message", this._handleEncoderMessage);
                this._resolveCompleteRecordingPromise(k(this._recordedPages));
                this._recordedPages = [];
                this._onStop == null ? void 0 : this._onStop();
                return
            }
            this._handlePage == null ? void 0 : this._handlePage(a, !1)
        };
        e._handleFlushed = function(a) {
            var b = c("WANullthrows")(this._pendingFlushResolvers.get(a));
            this._pendingFlushResolvers["delete"](a);
            b(k(this._recordedPages))
        };
        e.getPartialRecording = function() {
            var a = this,
                d = this._getNextRequestId(),
                e = new(h || (h = b("Promise")))(function(b) {
                    a._pendingFlushResolvers.set(d, b)
                }),
                f = c("WANullthrows")(this._encoder);
            f.postMessage({
                command: "flush",
                requestId: d
            });
            return e
        };
        e.getCompleteRecording = function() {
            return this._completeRecordingPromise
        };
        return a
    }();

    function k(a) {
        var b = a.reduce(function(a, b) {
            return a + b.length
        }, 0);
        b = new Uint8Array(b);
        var c = 0;
        for (a of a) b.set(a, c), c += a.length;
        return new Blob([b], {
            type: "audio/ogg; codecs=opus"
        })
    }

    function l() {
        return Boolean(window.AudioContext && d("WAGetUserMedia").getUserMedia)
    }

    function m(a, b, c, d) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, d) {
            var e = (yield a(d));
            if (d.aborted || e == null) return !1;
            var f = b.createMediaStreamSource(e);
            c.forEach(function(a) {
                f.connect(a)
            });
            d.addEventListener("abort", function() {
                e.getTracks().forEach(function(a) {
                    a.stop()
                }), f.disconnect()
            }, {
                once: !0
            });
            return !0
        });
        return n.apply(this, arguments)
    }
    g.OpusRecorderState = j;
    g.OpusRecorder = a
}), 98);
__d("WAPttComposerRecorderPollableTimer", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a() {}
        var b = a.prototype;
        b.start = function() {
            this.$1 = Date.now()
        };
        b.stop = function() {
            this.$2 = Date.now()
        };
        b.pause = function() {
            this.stop()
        };
        b.resume = function() {
            this.$1 = Date.now() - this.getTime(), this.$2 = null
        };
        b.getTime = function() {
            var a, b = this.$1;
            if (b == null) return 0;
            a = (a = this.$2) != null ? a : Date.now();
            return a - b
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("WAPttComposerScaleWaveform", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    function a(a, b) {
        if (b === a.length) return a;
        if (b === 0) return [];
        if (a.length === 0) return new Array(b).fill(0);
        return b > a.length ? i(a, b) : j(a, b)
    }

    function i(a, b) {
        b > a.length || h(0, 75746, b, a.length);
        var c;
        if (a.length === 1) c = 0;
        else {
            var d = (b - a.length) / (a.length - 1);
            c = 1 / (1 + d)
        }
        d = [];
        b >= 1 && d.push(a[0]);
        for (var e = 1; e < b - 1; e++) {
            var f = e * c,
                g = Math.floor(f),
                i = f - g;
            d.push(k(a[g], a[Math.ceil(f)], i))
        }
        b >= 2 && d.push(a[a.length - 1]);
        return d
    }

    function j(a, b) {
        b < a.length || h(0, 75747, b, a.length);
        var c = [];
        b = b / a.length;
        var d = 0,
            e = 0,
            f = 0;
        for (var a = a, g = Array.isArray(a), i = 0, a = g ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var j;
            if (g) {
                if (i >= a.length) break;
                j = a[i++]
            } else {
                i = a.next();
                if (i.done) break;
                j = i.value
            }
            j = j;
            d += j;
            f += 1;
            e += b;
            e >= 1 && (c.push(d / f), f = 0, d = 0, e -= 1)
        }
        f > 0 && c.push(d / f);
        return c
    }

    function k(a, b, c) {
        return a + (b - a) * c
    }
    g["default"] = a
}), 98);
__d("WAStartAnimationLoop", [], (function(a, b, c, d, e, f) {
    function a(a, b) {
        b = (b = b) != null ? b : {};
        b = b.delay;
        var c = b === void 0 ? 0 : b,
            d, e, f;
        b = function() {
            e = !0, window.cancelAnimationFrame(d)
        };
        var g = function b(g) {
            (f == null || g - f >= c) && (a(g), f = g);
            if (e) return;
            d = window.requestAnimationFrame(b)
        };
        d = window.requestAnimationFrame(g);
        return b
    }
    f.startAnimationLoop = a
}), 66);
__d("WAPttComposerWaveformRecorder", ["WANullthrows", "WAPttComposerRecorderPollableTimer", "WAPttComposerScaleWaveform", "WAStartAnimationLoop"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a, b) {
            var d = this;
            this.$2 = new(c("WAPttComposerRecorderPollableTimer"))();
            this.$3 = [];
            this.$4 = [];
            this.$5 = 0;
            this.$10 = function() {
                d.$5 = Math.max(d.$5, d.$11());
                var a = d.$3.length / d.$1;
                a = Math.floor((d.getDuration() - a) * d.$1);
                if (a === 0) return;
                for (var b = 0; b < a; b++) d.$3.push(d.$5);
                d.$5 = 0
            };
            this.$12 = 0;
            this.$7 = h(a);
            a.connect(this.$7);
            this.$1 = b
        }
        var b = a.prototype;
        b.start = function() {
            this.$2.start(), this.$9()
        };
        b.stop = function() {
            this.$2.stop(), this.$6 == null ? void 0 : this.$6()
        };
        b.pause = function() {
            this.$2.pause(), this.$6 == null ? void 0 : this.$6()
        };
        b.resume = function() {
            this.$2.resume(), this.$9()
        };
        b.$9 = function() {
            this.$6 = d("WAStartAnimationLoop").startAnimationLoop(this.$10)
        };
        b.$11 = function() {
            var a, b = c("WANullthrows")(this.$7);
            this.$8 = (a = this.$8) != null ? a : new Uint8Array(b.frequencyBinCount);
            a = this.$8;
            b.getByteFrequencyData(a);
            return Math.max.apply(Math, Array.from(a)) / 255
        };
        b.commitSamples = function(a) {
            a = Math.floor(a * this.$1);
            a = a - this.$4.length;
            var b = this.$3.length - this.$12;
            if (a === 0 || b === 0) return;
            b = this.$3.slice(this.$12, this.$3.length);
            b = c("WAPttComposerScaleWaveform")(b, a);
            for (var a = b, b = Array.isArray(a), d = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (b) {
                    if (d >= a.length) break;
                    e = a[d++]
                } else {
                    d = a.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                this.$4.push(e)
            }
            this.$12 = this.$3.length
        };
        b.getSamples = function() {
            return this.$3
        };
        b.getDuration = function() {
            var a;
            a = (a = this.$2.getTime()) != null ? a : 0;
            return a / 1e3
        };
        b.getCorrectedSamples = function() {
            return this.$4
        };
        return a
    }();

    function h(a) {
        a = a.context.createAnalyser();
        a.fftSize = 32;
        a.smoothingTimeConstant = 0;
        a.minDecibels = -60;
        a.maxDecibels = -10;
        return a
    }
    g["default"] = a
}), 98);
__d("WAPttComposerRecorder", ["WAPttComposerOpusRecorder", "WAPttComposerWaveformRecorder", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            var b = this;
            this._handleOpusRecorderDuration = function() {
                b._waveformRecorder.commitSamples(b.getDuration()), b._onDuration == null ? void 0 : b._onDuration(b.getDuration())
            };
            this._onDuration = a.onDuration;
            this._opusRecorder = new(d("WAPttComposerOpusRecorder").OpusRecorder)({
                createStream: a.createStream,
                onDuration: this._handleOpusRecorderDuration,
                onPage: function(b, c) {
                    a.onPage == null ? void 0 : a.onPage(b, c)
                }
            });
            this._waveformRecorder = new(c("WAPttComposerWaveformRecorder"))(this._opusRecorder.getMonitorNode(), a.waveformSampleRate)
        }
        var e = a.prototype;
        e.start = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                var a = (yield this._opusRecorder.start());
                if (!a) return !1;
                this._waveformRecorder.start();
                return !0
            });

            function c() {
                return a.apply(this, arguments)
            }
            return c
        }();
        e.stop = function() {
            this._opusRecorder.stop(), this._waveformRecorder.stop()
        };
        e.pause = function() {
            this._opusRecorder.pause(), this._waveformRecorder.pause()
        };
        e.resume = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                var a = (yield this._opusRecorder.resume());
                if (!a) return !1;
                this._waveformRecorder.resume();
                return !0
            });

            function c() {
                return a.apply(this, arguments)
            }
            return c
        }();
        e.getDuration = function() {
            return this._opusRecorder.getDuration()
        };
        e.getPreciseDuration = function() {
            var a;
            return (a = this._waveformRecorder.getDuration()) != null ? a : 0
        };
        e.getLiveWaveformSamples = function() {
            return this._waveformRecorder.getSamples()
        };
        e.getCorrectedWaveformSamples = function() {
            return this._waveformRecorder.getCorrectedSamples()
        };
        e.getPartialRecording = function() {
            return this._opusRecorder.getPartialRecording()
        };
        e.getCompleteRecording = function() {
            return this._opusRecorder.getCompleteRecording()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MWPUseVoiceRecorderV2", ["MWPAudioPlayerLabels", "Promise", "WAPttComposerRecorder", "WATagsLogger", "clearTimeout", "emptyFunction", "err", "react", "setTimeout", "useIsMountedRef", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["PTT recording stop Error ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["PTT recording start Error ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["PTT recording start successfully"]);
        l = function() {
            return a
        };
        return a
    }
    var m = i || d("react"),
        n = m.useCallback,
        o = m.useEffect,
        p = m.useReducer,
        q = m.useRef,
        r = d("WATagsLogger").TAGS(["MWPUseVoiceRecorderV2"]),
        s = 8.5;

    function a(a) {
        switch (a.stage) {
            case "Unopen":
            case "Recording":
                return !1;
            case "Recorded":
            case "Playing":
                return !0
        }
    }

    function e(a) {
        switch (a.stage) {
            case "Unopen":
            case "Recording":
                return !1;
            case "Recorded":
            case "Playing":
                return !0
        }
    }

    function f(a) {
        switch (a.stage) {
            case "Unopen":
                return 0;
            case "Recording":
                return a.duration;
            case "Recorded":
            case "Playing":
                return Math.max(a.duration - a.currentTime, 0)
        }
    }

    function t(a) {
        switch (a.stage) {
            case "Unopen":
                return 0;
            case "Recording":
                return a.recordingTimeout;
            case "Recorded":
            case "Playing":
                return a.duration
        }
    }

    function u(a) {
        switch (a.stage) {
            case "Unopen":
            case "Recording":
                return;
            case "Recorded":
            case "Playing":
                return a.currentTime
        }
    }

    function v(a) {
        switch (a.stage) {
            case "Unopen":
            case "Recorded":
                return !1;
            case "Recording":
            case "Playing":
                return !0
        }
    }

    function w(a) {
        if (a.stage === "Recorded") return a.currentTime === 0;
        else return !1
    }

    function x(a) {
        switch (a.stage) {
            case "Recording":
                return d("MWPAudioPlayerLabels").stopLabel;
            case "Unopen":
            case "Recorded":
                return d("MWPAudioPlayerLabels").playLabel;
            case "Playing":
                return d("MWPAudioPlayerLabels").pauseLabel
        }
    }

    function y(a, b) {
        switch (b.type) {
            case "Start":
                return {
                    duration: 0,
                    mediaStream: b.mediaStream,
                    recordingTimeout: b.recordingTimeout,
                    stage: "Recording"
                };
            case "Toggle":
                switch (a.stage) {
                    case "Unopen":
                        return a;
                    case "Recording":
                        return {
                            currentTime: 0,
                            duration: a.duration,
                            stage: "Recorded"
                        };
                    case "Recorded":
                        return {
                            currentTime: a.currentTime,
                            duration: a.duration,
                            stage: "Playing"
                        };
                    case "Playing":
                        return {
                            currentTime: a.currentTime,
                            duration: a.duration,
                            stage: "Recorded"
                        }
                }
                break;
            case "UpdateDuration":
                var c = b.duration;
                switch (a.stage) {
                    case "Unopen":
                        return a;
                    case "Recording":
                        return {
                            duration: c,
                            mediaStream: a.mediaStream,
                            recordingTimeout: a.recordingTimeout,
                            stage: "Recording"
                        };
                    case "Recorded":
                        return {
                            currentTime: a.currentTime,
                            duration: c,
                            stage: "Recorded"
                        };
                    case "Playing":
                        return {
                            currentTime: a.currentTime,
                            duration: c,
                            stage: "Playing"
                        }
                }
                break;
            case "UpdateTime":
                c = b.currentTime;
                switch (a.stage) {
                    case "Unopen":
                    case "Recording":
                        return a;
                    case "Recorded":
                        var d = a.duration;
                        return c === d ? {
                            currentTime: 0,
                            duration: d,
                            stage: "Recorded"
                        } : {
                            currentTime: c,
                            duration: d,
                            stage: "Recorded"
                        };
                    case "Playing":
                        d = a.duration;
                        return c === d ? {
                            currentTime: 0,
                            duration: d,
                            stage: "Recorded"
                        } : {
                            currentTime: c,
                            duration: d,
                            stage: "Playing"
                        }
                }
                break;
            case "RecordingTimeout":
                return {
                    currentTime: 0,
                    duration: b.recordingTimeout,
                    stage: "Recorded"
                };
            case "Reset":
                return {
                    stage: "Unopen"
                }
        }
    }
    var z = {
        stage: "Unopen"
    };

    function A(a, d, e) {
        a === void 0 && (a = 60);
        d === void 0 && (d = c("emptyFunction"));
        e === void 0 && (e = c("emptyFunction"));
        var f = p(y, z),
            g = f[0],
            i = f[1],
            m = c("useIsMountedRef")(),
            t = q(),
            u = q(),
            v = q(),
            w = q(),
            x = q(c("emptyFunction")),
            A = n(function(a) {
                var b = a[0],
                    c = a[1];
                if (!m.current) return;
                var d = new File([b], "voice-clip.ogg", {
                    type: "audio/ogg"
                });
                a = URL.createObjectURL(d);
                v.current = a;
                var e = new Audio(a);
                e.addEventListener("canplay", function() {
                    u.current = e;
                    var a = e.duration;
                    i({
                        duration: a,
                        type: "UpdateDuration"
                    });
                    var b = {
                        amplitudes: c,
                        sampling_freq: s
                    };
                    a = {
                        duration: a,
                        file: d,
                        waveformData: b
                    };
                    w.current = a;
                    x.current(a)
                });
                e.addEventListener("timeupdate", function() {
                    var a;
                    a = (a = u.current) == null ? void 0 : a.currentTime;
                    a != null && i({
                        currentTime: a,
                        type: "UpdateTime"
                    })
                });
                e.addEventListener("durationchange", function() {
                    var a;
                    a = (a = u.current) == null ? void 0 : a.duration;
                    a != null && !Number.isNaN(a) && i({
                        duration: a,
                        type: "UpdateDuration"
                    })
                })
            }, [m]);
        o(function() {
            if (g.stage !== "Recording") return;
            d();
            var a = g.mediaStream;
            void(h || (h = b("Promise"))).resolve().then(function() {
                var d = new(c("WAPttComposerRecorder"))({
                    createStream: function() {
                        return (h || (h = b("Promise"))).resolve(a)
                    },
                    waveformSampleRate: s
                });
                t.current = d;
                return d.start()
            }).then(function(a) {
                if (a) {
                    r.LOG(l());
                    return
                }
                return (h || (h = b("Promise"))).reject(c("err")("PTT recording start failed"))
            })["catch"](function(a) {
                r.ERROR(k(), a)
            });
            return function() {
                var a;
                (a = t.current) == null ? void 0 : a.stop()
            }
        }, [d, g.mediaStream, g.stage]);
        var B = c("usePrevious")(g);
        o(function() {
            if ((B == null ? void 0 : B.stage) === "Recording" && g.stage === "Recorded") {
                var a = t.current;
                if (a == null) return;
                a.stop();
                void(h || (h = b("Promise"))).all([a.getCompleteRecording(), a.getCorrectedWaveformSamples()]).then(function(a) {
                    var b = a[0];
                    a = a[1];
                    A([b, a])
                })["catch"](function(a) {
                    r.ERROR(j(), a)
                })
            }
        }, [A, B == null ? void 0 : B.stage, g.stage]);
        o(function() {
            if (g.stage !== "Recording") return;
            var b = Date.now(),
                d, e = function e() {
                    var f = (Date.now() - b) / 1e3;
                    if (f >= a) {
                        i({
                            recordingTimeout: a,
                            type: "RecordingTimeout"
                        });
                        return
                    }
                    i({
                        duration: f,
                        type: "UpdateDuration"
                    });
                    d = c("setTimeout")(e, 1e3)
                };
            d = c("setTimeout")(e, 1e3);
            return function() {
                d != null && c("clearTimeout")(d)
            }
        }, [a, g.stage]);
        f = n(function(b) {
            i({
                mediaStream: b,
                recordingTimeout: a,
                type: "Start"
            })
        }, [a]);
        var C = n(function() {
                var a;
                i({
                    type: "Reset"
                });
                (a = u.current) == null ? void 0 : a.pause();
                u.current = void 0;
                w.current = void 0;
                a = v.current;
                a != null && (URL.revokeObjectURL(a), v.current = void 0)
            }, []),
            D = n(function() {
                var a = function() {
                        i({
                            type: "Toggle"
                        })
                    },
                    b = u.current;
                if (b == null) {
                    a();
                    return
                }
                switch (g.stage) {
                    case "Unopen":
                    case "Recording":
                        a();
                        break;
                    case "Recorded":
                        b.play().then(a)["catch"](e);
                        break;
                    case "Playing":
                        b.pause();
                        a();
                        break
                }
            }, [e, g.stage]),
            E = n(function() {
                return new(h || (h = b("Promise")))(function(a) {
                    var b = w.current;
                    if (b != null) return a(b);
                    x.current = a;
                    if (g.stage === "Recording") return D()
                })
            }, [g, D]);
        return {
            audioEl: u,
            getVoiceClip: E,
            reset: C,
            start: f,
            state: g,
            toggle: D
        }
    }
    g.showScreenReaderLabel = a;
    g.hasScrubber = e;
    g.getTimerTime = f;
    g.getDuration = t;
    g.getCurrentTime = u;
    g.isProgressing = v;
    g.isCompleted = w;
    g.getPlaybackLabel = x;
    g.useVoiceRecorder = A
}), 98);
__d("useSecureMessageSendTime", ["MAWStateContext.react", "err", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useDebugValue;

    function a(a) {
        if (!c("gkx")("24000")) throw c("err")("Attempted to show debug UI to external user.");
        var b = i(function(b) {
            return b.messageLatencies[a]
        }, [a]);
        b = (b = d("MAWStateContext.react").useMAWSelector(b)) != null ? b : {};
        var e = b.acked;
        b = b.sent;
        e = e != null ? e - b : void 0;
        j(e);
        return e
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("MAWMediaDownloadStatusUIStateType", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a == null) return !1;
        switch (a) {
            case "non_retryable_error":
            case "non_retryable_error_with_preview":
            case "retryable_error":
            case "retryable_error_with_preview":
                return !0;
            default:
                return !1
        }
    }

    function b(a) {
        if (a == null) return !1;
        switch (a) {
            case "retryable_error":
            case "retryable_error_with_preview":
                return !0;
            default:
                return !1
        }
    }
    f.isErrorState = a;
    f.isRetryableErrorState = b
}), 66);
__d("MWPColorUtils", ["I64", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = function(a) {
        return "#" + a.map(function(a) {
            return a.toString(16).padStart(2, "0")
        }).join("")
    };

    function j(a) {
        a = (h || (h = d("I64"))).to_int32(a);
        var b = (a & 16711680) >>> 16,
            c = (a & 65280) >>> 8;
        a = a & 255;
        return [b, c, a]
    }

    function k(a) {
        var b = a[0],
            c = a[1];
        a = a[2];
        return (h || (h = d("I64"))).of_int32((b << 16) + (c << 8) + a)
    }

    function l(a, b, c) {
        return [Math.round(a[0] * c + b[0] * (1 - c)), Math.round(a[1] * c + b[1] * (1 - c)), Math.round(a[2] * c + b[2] * (1 - c))]
    }

    function a(a) {
        a = Number("0x" + a.slice(2));
        return k([a >> 16 & 255, a >> 8 & 255, a & 255])
    }

    function b(a, b, c) {
        a = j(a);
        b = j(b);
        return i(l(a, b, c))
    }

    function e(a, b, c) {
        a = j(a);
        b = j(b);
        a = l(a, b, c);
        return k(a)
    }

    function m(a) {
        return i(j(a))
    }

    function f(a, b) {
        var c = j(a),
            d = c[0],
            e = c[1];
        c = c[2];
        return b != null ? "rgba(" + d + ", " + e + ", " + c + ", " + b + ")" : m(a)
    }

    function n(a, b) {
        a = [].concat(a).sort(function(a, b) {
            return (h || (h = d("I64"))).to_int32(a.gradientIndex) - h.to_int32(b.gradientIndex) | 0
        }).map(function(a) {
            return m(a.color)
        });
        var e = a.length;
        if (e !== 1) {
            if (e !== 0) {
                e = b != null;
                var f = [];
                b != null && f.push(a[0] + " calc(100vh - " + String(b.totalHeight) + "px + " + String(b.headerHeight) + "px)");
                for (var g = e ? 1 : 0, e = a.length - (e ? 2 : 1) | 0; g <= e; ++g) f.push(a[g]);
                b != null && (f.push(a[a.length - 1 | 0] + " calc(100% - " + String(b.footerHeight) + "px)"), f.push(a[a.length - 1 | 0]));
                g = f.join(", ");
                return "linear-gradient(" + g + ")"
            }
            c("recoverableViolation")("Not enough colors for a gradient", "messenger_comet");
            return ""
        }
        c("recoverableViolation")("Not enough colors for a gradient", "messenger_comet");
        return ""
    }
    g.i64toRgb = j;
    g.hexToI64 = a;
    g.combineColors = b;
    g.combineColorsAsI64 = e;
    g.int64ToHex = m;
    g.int64ToRGBA = f;
    g.gradient = n
}), 98);
__d("MWPThreadThemeGradientUtils", ["MWPColorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = a.outgoingGradientColors;
        a = a.threadTheme;
        b = b[0];
        return (b = b == null ? void 0 : b.color) != null ? b : a.fallbackColor
    }

    function a(a) {
        return d("MWPColorUtils").int64ToHex(h(a))
    }

    function i(a) {
        var b = a.outgoingGradientColors;
        a = a.threadTheme;
        b = b[b.length - 1];
        return (b = b == null ? void 0 : b.color) != null ? b : a.fallbackColor
    }

    function b(a) {
        return d("MWPColorUtils").int64ToHex(i(a))
    }

    function c(a) {
        return a.outgoingGradientColors.length > 1
    }
    g.getTopGradientColorI64 = h;
    g.getTopGradientColor = a;
    g.getBottomGradientColorI64 = i;
    g.getBottomGradientColor = b;
    g.isGradient = c
}), 98);
__d("MWV2IsTabFocusedContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    c = h;
    e = c.createContext;
    var j = c.useContext,
        k = e(!1);

    function a(a) {
        var b = a.children;
        a = a.isFocused;
        return i.jsx(k.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return j(k)
    }
    g.MWV2IsTabFocusedContextProvider = a;
    g.useIsTabFocused = b
}), 98);
__d("MessengerAppColorMode", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        NORMAL: 1,
        DARK: 2,
        NONE: 3
    });
    f["default"] = a
}), 66);
__d("useMWIsBroadcastChannelViewer", ["LSMessagingThreadTypeUtil", "MWLSThread", "MWPActor.react", "ReQL", "ReQLSuspense", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var b, e = (h || (h = c("useReStore")))(),
            g = d("MWPActor.react").useActor(),
            i = (b = d("MWLSThread").useThread(a, function(a) {
                return d("LSMessagingThreadTypeUtil").isDiscoverablePublicBroadcastChannel(a.threadType)
            })) != null ? b : !1;
        b = (b = d("ReQLSuspense").useFirst(function() {
            return a != null && i ? d("ReQL").fromTableAscending(e.tables.participants).getKeyRange(a, g).map(function(a) {
                return a.isAdmin !== !0 && a.isSuperAdmin !== !0 && a.isModerator !== !0
            }) : d("ReQL").empty()
        }, [e, a, g, i], f.id + ":31")) != null ? b : !1;
        return i && b
    }
    g["default"] = a
}), 98);
__d("MWPThemeCSSProvider.react", ["BaseTheme.react", "I64", "LSIntEnum", "MWLSThread", "MWLSThreadDisplayContext", "MWPColorUtils", "MWPThreadThemeGradientUtils", "MWThreadKey.react", "MWV2IsTabFocusedContext.react", "MessengerAppColorMode", "gkx", "react", "useMWIsBroadcastChannelViewer", "useMWPThreadTheme"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = h || (h = d("react")),
        l = h.useMemo,
        m = {
            expand: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                maxWidth: "x193iq5w",
                $$css: !0
            }
        };

    function n(a, b) {
        b = (b = d("MWLSThread").useThread(b, function(a) {
            return (i || (i = d("I64"))).lt(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs)
        })) != null ? b : !1;
        return b && !a
    }

    function o() {
        var a = d("MWLSThreadDisplayContext").useMWLSThreadDisplayContext(),
            b = a === "ChatTab";
        a = a === "Inbox";
        return !b && !a ? !1 : (b || c("gkx")("24031")) && c("gkx")("7826")
    }

    function p() {
        var a = d("MWThreadKey.react").useMWThreadKeyMemoized(),
            b = d("MWLSThreadDisplayContext").useMWLSThreadDisplayContext() === "ChatTab",
            e = d("MWV2IsTabFocusedContext.react").useIsTabFocused(),
            f = n(e, a),
            g = c("useMWIsBroadcastChannelViewer")(a),
            h = c("useMWPThreadTheme")(),
            k = o();
        return l(function() {
            var a, l = c("gkx")("24057"),
                m = h.backgroundGradientColors,
                n = h.incomingGradientColors,
                o = h.outgoingGradientColors,
                p = h.threadTheme,
                q = p.appColorMode,
                r = p.backgroundUrl,
                s = p.composerBackgroundColor,
                t = p.composerInputBackgroundColor,
                u = p.composerInputBorderColor,
                v = p.composerInputBorderWidth,
                w = p.composerInputTextPlaceholderColor,
                x = p.composerPlaceholderTextColor,
                y = p.composerTintColor,
                z = p.deliveryReceiptColor,
                A = p.fallbackColor,
                B = p.incomingMessageBorderColor,
                C = p.incomingMessageBorderWidth,
                D = p.incomingMessageTextColor,
                E = p.messageBorderColor,
                F = p.messageBorderWidth,
                G = p.messageTextColor,
                H = p.primaryButtonBackgroundColor,
                I = p.quotedIncomingMessageBubbleColor,
                J = p.reactionPillBackgroundColor,
                K = p.secondaryTextColor,
                L = p.tertiaryTextColor,
                M = p.titlebarAttributionTextColor,
                N = p.titlebarBackgroundColor,
                O = p.titlebarButtonTintColor;
            p = p.titlebarTextColor;
            q = (i || (i = d("I64"))).equal(q, (j || (j = d("LSIntEnum"))).ofNumber(c("MessengerAppColorMode").DARK));
            r = Boolean(r == null ? void 0 : r.length);
            var P = o.length > 1,
                Q = m.length > 0;
            r = k && (r || Q);
            Q = r && "4px" || "0px";
            l = l ? "96px" : g ? "28px" : "84px";
            O = k && O || d("MWPThreadThemeGradientUtils").getTopGradientColorI64(h);
            var R = k && y || d("MWPThreadThemeGradientUtils").getBottomGradientColorI64(h);
            m = m == null ? void 0 : (m = m[(m == null ? void 0 : m.length) - 1]) == null ? void 0 : m.color;
            n = n == null ? void 0 : (n = n[0]) == null ? void 0 : n.color;
            a = (a = o == null ? void 0 : (a = o[o.length - 1]) == null ? void 0 : a.color) != null ? a : A;
            o = o && o.length > 1 && d("MWPColorUtils").gradient(o, b ? {
                footerHeight: 56,
                headerHeight: 48,
                totalHeight: 455
            } : void 0);
            L = {
                "chat-admin-text-color": k && (K || L),
                "chat-composer-background-color": k && s,
                "chat-composer-button-color": R,
                "chat-composer-caret-color": k && R,
                "chat-composer-input-background-color": k && t || "var(--comment-background)",
                "chat-composer-input-border-color": k && u,
                "chat-composer-input-border-width": k && v,
                "chat-composer-input-text-placeholder-color": k && w,
                "chat-composer-placeholder-text-color": k && x,
                "chat-delivery-receipt-color": k && z,
                "chat-edit-message-overlay-color": (K = m) != null ? K : "var(--surface-background)",
                "chat-incoming-message-border-color": k && B,
                "chat-incoming-message-border-width": k && C,
                "chat-incoming-message-bubble-background-color": k && n,
                "chat-incoming-message-text-color": k && D,
                "chat-message-border-color": k && E,
                "chat-message-border-width": k && F,
                "chat-message-text-color": k && G,
                "chat-outgoing-message-background-gradient": !r && o ? o : "initial",
                "chat-outgoing-message-bubble-background-color": P && !r ? "transparent" : a,
                "chat-primary-button-background-color": k && H,
                "chat-quoted-incoming-message-bubble-color": k && I,
                "chat-replied-message-background-color": k && m && n && d("MWPColorUtils").combineColors(m, n, .4),
                "chat-scrollbar-thumb-color": r && m && d("MWPColorUtils").int64ToRGBA(d("MWPColorUtils").combineColorsAsI64(d("MWPColorUtils").combineColorsAsI64(a, m, .6), q ? (i || (i = d("I64"))).of_int32(16777215) : (i || (i = d("I64"))).of_int32(0), .6), .7),
                "chat-scrollbar-track-color": r && "transparent",
                "mwp-header-background-color": k && N,
                "mwp-header-button-color": O,
                "mwp-header-text-color": k && p,
                "mwp-message-list-actions-gap": Q,
                "mwp-message-list-actions-width": "calc(" + l + " + 3*" + Q + ")",
                "mwp-message-row-background": r ? "transparent" : "var(--messenger-card-background)",
                "mwp-primary-theme-color": A,
                "mwp-subheader-text-color": k && M,
                "reaction-pill-background-color": k ? J : "var(--wash)",
                "reaction-pill-multireact-selected-color": d("MWPColorUtils").combineColorsAsI64(A, i.of_int32(16777215), .22),
                "text-highlight": k && y && d("MWPColorUtils").int64ToRGBA(y, q ? .5 : .2)
            };
            e || (k ? (L["chat-composer-button-color"] = d("MWPColorUtils").int64ToRGBA(R, .6), L["mwp-header-button-color"] = d("MWPColorUtils").int64ToRGBA(O, .6)) : (L["chat-composer-button-color"] = "var(--disabled-icon)", L["mwp-header-button-color"] = "var(--disabled-icon)"));
            f && (L["mwp-header-button-color"] = "var(--always-white)", L["mwp-header-text-color"] = "var(--always-white)", L["mwp-header-background-color"] = O);
            (L["mwp-subheader-text-color"] == null || typeof L["mwp-subheader-text-color"] === "boolean") && (L["mwp-subheader-text-color"] = L["mwp-header-text-color"]);
            s = {};
            for (t in L) {
                u = L[t];
                if (u == null || typeof u === "boolean") continue;
                else typeof u === "string" ? s[t] = u : s[t] = d("MWPColorUtils").int64ToHex(u)
            }
            return s
        }, [g, b, f, e, h])
    }

    function a(a) {
        var b = p();
        return k.jsx(c("BaseTheme.react"), babelHelpers["extends"]({}, a, {
            config: {
                dark: b,
                light: b,
                type: "VARIABLES"
            },
            xstyle: [m.expand, a.xstyle]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.useIsThemeV2 = o;
    g.MWPThemeCSSProvider = a
}), 98);
__d("MWPThreadThemeContext", ["defaultMWPThreadTheme", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("react")).createContext;
    b = babelHelpers["extends"]({}, d("defaultMWPThreadTheme").defaultThemeWithColorsV1, {
        previewId: void 0,
        setPreviewId: c("emptyFunction")
    });
    e = a(b);
    g.defaultContextValue = b;
    g.MWPThreadThemeContext = e
}), 98);
__d("defaultMWPThreadTheme", ["I64", "MWPThemeCSSProvider.react", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        var a = d("MWPThemeCSSProvider.react").useIsThemeV2();
        return a ? i : j
    }
    var i = {
            backgroundGradientColors: [],
            incomingGradientColors: [],
            outgoingGradientColors: [{
                color: (h || (h = d("I64"))).of_string("-5635841"),
                gradientIndex: h.of_string("0"),
                themeFbid: h.of_string("3259963564026002"),
                type_: h.of_string("0")
            }, {
                color: h.of_string("-16744193"),
                gradientIndex: h.of_string("1"),
                themeFbid: h.of_string("3259963564026002"),
                type_: h.of_string("0")
            }],
            threadTheme: {
                accessibilityLabel: "Default",
                appColorMode: h.of_string("1"),
                fallbackColor: h.of_string("-11645963"),
                fbid: h.of_string("3259963564026002"),
                isDeprecated: !1,
                normalThemeId: h.of_string("3259963564026002"),
                reverseGradiantsForRadial: !1,
                themeIdx: h.of_string("275")
            }
        },
        j = {
            backgroundGradientColors: [],
            incomingGradientColors: [],
            outgoingGradientColors: [],
            threadTheme: {
                accessibilityLabel: "Default Blue",
                appColorMode: h.zero,
                fallbackColor: c("gkx")("23219") ? (h || (h = d("I64"))).of_string("687359") : (h || (h = d("I64"))).of_string("-16743169"),
                fbid: h.of_string("196241301102133"),
                isDeprecated: !1,
                normalThemeId: h.zero,
                reverseGradiantsForRadial: !1,
                themeIdx: h.of_string("94")
            }
        };
    g.useDefaultThemeWithColors = a;
    g.defaultThemeWithColorsV2 = i;
    g.defaultThemeWithColorsV1 = j
}), 98);
__d("useMWPThreadTheme", ["MWPThreadThemeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        return i(d("MWPThreadThemeContext").MWPThreadThemeContext)
    }
    g["default"] = a
}), 98);
__d("shouldUseImageGrouping", ["I64", "LSIntEnum", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a, b) {
        var e, f = a.displayedContentTypes,
            g = a.groupId;
        e = (h || (h = d("I64"))).to_int32((e = a.groupSize) != null ? e : (h || (h = d("I64"))).zero);
        return b && c("gkx")("5318") === !0 && (h || (h = d("I64"))).equal(f, (i || (i = d("LSIntEnum"))).ofNumber(2)) && g != null && a.groupIndex != null && a.groupSize != null && e > 1
    }
    g["default"] = a
}), 98);
__d("useMAWBulkMediaUIState", ["FBLogger", "cr:11029", "react", "useEmptyFunction", "useMAWBulkMediaDownloadStatusUIState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useMemo,
        j = (e = b("cr:11029")) != null ? e : c("useEmptyFunction");

    function a(a) {
        var b = c("useMAWBulkMediaDownloadStatusUIState")(a),
            d = j(a);
        a = i(function() {
            var a;
            return {
                buldValidationResult: (a = d) != null ? a : [],
                bulkDownloadStatus: b
            }
        }, [b, d]);
        d != null && b.length !== d.length && c("FBLogger")("messenger_web_e2ee").warn("Length of attachments download status should match validation result");
        return a
    }
    g["default"] = a
}), 98);
__d("useGetMediaGroupInformation", ["I64", "MAWGetIsMediaDownloadStatusEnabled", "MAWMediaDownloadStatusUIStateType", "ReQL", "ReQLSuspense", "react", "shouldUseImageGrouping", "useMAWBulkMediaUIState", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = (j || d("react")).useMemo;

    function a(a, b, e) {
        var g, j, m, n = (h || (h = c("useReStore")))(),
            o = a.groupId,
            p = a.threadKey;
        g = (i || (i = d("I64"))).to_int32((g = a.groupIndex) != null ? g : (i || (i = d("I64"))).zero);
        j = i.to_int32((j = a.groupSize) != null ? j : (i || (i = d("I64"))).zero);
        var q = c("shouldUseImageGrouping")(a, b);
        a = q ? 4 : 0;
        q && j < 4 && (a = j);
        var r = d("ReQLSuspense").useArray(function() {
                return q && o != null ? d("ReQL").fromTableDescending(n.tables.messages.index("messageGroupId")).getKeyRange(o).map(function(a) {
                    var b;
                    b = (b = d("ReQLSuspense").first(d("ReQL").fromTableDescending(n.tables.attachments).getKeyRange(p, a.messageId), f.id + ":101")) != null ? b : null;
                    return {
                        attachment: b,
                        message: a
                    }
                }) : d("ReQL").empty()
            }, [n, o, p, q], f.id + ":93"),
            s = k(function() {
                return r.sort(function(a, b) {
                    return (i || (i = d("I64"))).to_int32((a = a.message.groupIndex) != null ? a : (i || (i = d("I64"))).zero) - i.to_int32((a = b.message.groupIndex) != null ? a : (i || (i = d("I64"))).zero)
                })
            }, [r]),
            t = q && s.length >= 1 ? (b = s[0]) == null ? void 0 : b.message : null;
        b = d("ReQLSuspense").useFirst(function() {
            return q && t != null ? d("ReQL").fromTableAscending(n.tables.messages.index("messageDisplayOrder")).getKeyRange(t.threadKey).bounds({
                gte: d("ReQL").key(t.primarySortKey)
            }).filter(function(a) {
                return a.groupId !== t.groupId
            }).filter(function(a) {
                return !a.isAdminMessage
            }) : d("ReQL").empty()
        }, [n, t, q], f.id + ":131");
        e = l(s, q, e);
        var u = e.attachmentsToRetryDownload,
            v = e.mediaDownloadErrorsCount;
        e = e.mediaDownloadStatuses;
        if (q !== !0) return null;
        m = s.length >= 1 ? (i || (i = d("I64"))).to_int32((m = (m = s[0]) == null ? void 0 : (m = m.message) == null ? void 0 : m.groupIndex) != null ? m : (i || (i = d("I64"))).zero) : 0;
        m = g === m;
        var w = new Array(a),
            x = function(a) {
                var b = s.findIndex(function(b) {
                    return b.message.groupIndex != null && (i || (i = d("I64"))).to_int32(b.message.groupIndex) === a
                });
                b === -1 ? w[a] = {
                    attachment: null,
                    message: null
                } : w[a] = {
                    attachment: s[b].attachment,
                    message: s[b].message
                }
            };
        for (var y = 0; y < a && y < a; ++y) x(y);
        return {
            attachmentsToRetryDownload: u,
            groupId: o,
            groupIndex: g,
            groupSize: j,
            groupsLastMessage: s != null && s.length > 0 ? s[s.length - 1].message : null,
            groupsNextMessage: (x = b) != null ? x : null,
            hasAllMessagesSent: s.every(function(a) {
                return (i || (i = d("I64"))).equal(a.message.sendStatusV2, i.of_int32(2))
            }),
            hasMissingMedia: s.some(function(a) {
                return a.attachment == null
            }),
            hasMissingMessages: s.length !== j,
            isFirstMediaMessageInGroup: m,
            isMediaGroupLastMessage: b == null,
            mediaDownloadErrorsCount: v,
            mediaDownloadStatuses: e,
            messagesAndAttachments: s,
            messagesAndAttachmentsShownInGroup: w,
            tileSize: a
        }
    }

    function l(a, b, e) {
        var f = k(function() {
                return !b || d("MAWGetIsMediaDownloadStatusEnabled").getIsMediaDownloadStatusEnabled() !== !0 ? [] : a.map(function(a) {
                    a = a.attachment;
                    return a
                }).filter(Boolean).map(function(a) {
                    return {
                        attachment: a,
                        mediaRenderQpl: e,
                        statusKey: a.attachmentFbid
                    }
                })
            }, [a, b, e]),
            g = c("useMAWBulkMediaUIState")(f),
            h = g.bulkDownloadStatus,
            i = k(function() {
                return h != null ? h : []
            }, [h]);
        g = k(function() {
            return i.filter(function(a) {
                return d("MAWMediaDownloadStatusUIStateType").isErrorState(a)
            })
        }, [i]);
        var j = k(function() {
            return f.filter(function(a, b) {
                return d("MAWMediaDownloadStatusUIStateType").isRetryableErrorState(i[b])
            }).map(function(a) {
                a = a.attachment;
                return a
            })
        }, [f, i]);
        g = g.length;
        return {
            attachmentsToRetryDownload: j,
            mediaDownloadErrorsCount: g,
            mediaDownloadStatuses: i
        }
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("ConstUriUtils", ["CometLruCache", "ExecutionEnvironment", "FBLogger", "PHPQuerySerializer", "PHPQuerySerializerNoEncoding", "URIRFC3986", "URISchemes", "UriNeedRawQuerySVConfig", "isSameOrigin", "nullthrows", "recoverableViolation", "structuredClone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = d("CometLruCache").create(5e3),
        m = new RegExp("(^|\\.)facebook\\.com$", "i"),
        n = new RegExp("(^|\\.)messenger\\.com$", "i"),
        o = new RegExp("^(?:[^/]*:|[\\x00-\\x1f]*/[\\x00-\\x1f]*/)"),
        p = new RegExp("[\\x00-\\x2c\\x2f\\x3b-\\x40\\x5c\\x5e\\x60\\x7b-\\x7f\\uFDD0-\\uFDEF\\uFFF0-\\uFFFF\\u2047\\u2048\\uFE56\\uFE5F\\uFF03\\uFF0F\\uFF1F]"),
        q = c("UriNeedRawQuerySVConfig").uris.map(function(a) {
            return {
                domain: a,
                valid: x(a)
            }
        }),
        r = [],
        s = [];

    function t(a, b) {
        var d = {};
        if (a != null)
            for (var a = a.entries(), e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= a.length) break;
                    g = a[f++]
                } else {
                    f = a.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                d[g[0]] = g[1]
            } else c("FBLogger")("ConstUriUtils").warn("Passed a null query map in, this means poor client side flow coverage or client/server boundary type issue.");
        return b.serialize(d)
    }

    function u(a, b, d) {
        var e = k || (k = c("PHPQuerySerializer"));
        if (["http", "https"].includes(b) && v(a)) {
            if (a.includes("doubleclick.net") && d != null && !d.startsWith("http")) return e;
            e = c("PHPQuerySerializerNoEncoding")
        }
        return e
    }

    function v(a) {
        return a != null && q.some(function(b) {
            return b.valid && w(a, b.domain)
        })
    }

    function w(a, b) {
        if (b === "" || a === "") return !1;
        if (a.endsWith(b)) {
            b = a.length - b.length - 1;
            if (b === -1 || a[b] === ".") return !0
        }
        return !1
    }

    function x(a) {
        return !p.test(a)
    }

    function y(a, b) {
        var c = b.protocol != null && b.protocol !== "" ? b.protocol : a.getProtocol();
        c = b.domain != null ? u(b.domain, c) : a.getSerializer();
        c = {
            domain: a.getDomain(),
            fragment: a.getFragment(),
            fragmentSeparator: a.hasFragmentSeparator(),
            isGeneric: a.isGeneric(),
            originalRawQuery: a.getOriginalRawQuery(),
            path: a.getPath(),
            port: a.getPort(),
            protocol: a.getProtocol(),
            queryParams: a.getQueryParams(),
            serializer: c,
            subdomain: a.getSubdomain()
        };
        a = babelHelpers["extends"]({}, c, b);
        c = b.queryParams != null && b.queryParams.size !== 0;
        return D.getUribyObject(a, c)
    }

    function z(a, b, c, d) {
        c === void 0 && (c = !1);
        var e = a.protocol !== "" ? a.protocol + ":" + (a.isGeneric ? "" : "//") : "",
            f = a.domain !== "" ? a.domain : "",
            g = a.port !== "" ? ":" + a.port : "",
            h = a.path !== "" ? a.path : e !== "" && e !== "mailto:" || f !== "" || g !== "" ? "/" : "";
        c = A(f, a.originalRawQuery, a.queryParams, b, c, (b = d) != null ? b : a.serializer);
        d = c.length > 0 ? "?" : "";
        b = a.fragment !== "" ? "#" + a.fragment : "";
        a = a.fragment === "" && a.fragmentSeparator ? "#" : "";
        return "" + e + f + g + h + d + c + a + b
    }

    function A(a, b, c, d, e, f) {
        e === void 0 && (e = !1);
        if (!d && (e || v(a))) {
            return (d = b) != null ? d : ""
        }
        return t(c, f)
    }

    function B(a) {
        var b = a.trim();
        b = (h || (h = d("URIRFC3986"))).parse(b) || {
            fragment: null,
            host: null,
            isGenericURI: !1,
            query: null,
            scheme: null,
            userinfo: null
        };
        var c = b.host || "",
            e = c.split(".");
        e = e.length >= 3 ? e[0] : "";
        var f = u(c, b.scheme || "", b.query),
            g = f.deserialize(b.query || "") || {};
        g = new Map(Object.entries(g));
        g = C({
            domain: c,
            fragment: b.fragment || "",
            fragmentSeparator: b.fragment === "",
            isGeneric: b.isGenericURI,
            originalRawQuery: b.query,
            path: b.path || "",
            port: b.port != null ? String(b.port) : "",
            protocol: (b.scheme || "").toLowerCase(),
            queryParams: g,
            serializer: f,
            subdomain: e,
            userInfo: (c = b == null ? void 0 : b.userinfo) != null ? c : ""
        }, a);
        return g
    }

    function C(a, b, c, e) {
        c === void 0 && (c = (j || (j = d("URISchemes"))).Options.INCLUDE_DEFAULTS);
        var f = {
                components: babelHelpers["extends"]({}, a),
                error: "",
                valid: !0
            },
            g = f.components;
        if (!(j || (j = d("URISchemes"))).isAllowed(a.protocol, c, e)) {
            f.valid = !1;
            f.error = 'The URI protocol "' + String(a.protocol) + '" is not allowed.';
            return f
        }
        if (!x(a.domain || "")) {
            f.valid = !1;
            f.error = "This is an unsafe domain " + String(a.domain);
            return f
        }
        g.port = a.port != null && String(a.port) || "";
        if (Boolean(a.userInfo)) {
            f.valid = !1;
            f.error = "Invalid URI: (userinfo is not allowed in a URI " + String(a.userInfo) + ")";
            return f
        }
        c = b != null && b !== "" ? b : z(g, !1);
        if (g.domain === "" && g.path.indexOf("\\") !== -1) {
            f.valid = !1;
            f.error = "Invalid URI: (no domain but multiple back-slashes " + c + ")";
            return f
        }
        if (!g.protocol && o.test(c)) {
            f.valid = !1;
            f.error = "Invalid URI: (unsafe protocol-relative URI " + c + ")";
            return f
        }
        if (g.domain !== "" && g.path !== "" && !g.path.startsWith("/")) {
            f.valid = !1;
            f.error = "Invalid URI: (domain and pathwhere path lacks leading slash " + c + ")";
            return f
        }
        return f
    }
    var D = function() {
        function a(a) {
            this.queryParams = new Map(), this.domain = a.domain, this.fragment = a.fragment, this.fragmentSeparator = Boolean(a.fragmentSeparator), this.isGenericProtocol = Boolean(a.isGeneric), this.path = a.path, this.originalRawQuery = a.originalRawQuery, this.port = a.port, this.protocol = a.protocol, this.queryParams = a.queryParams, this.serializer = a.serializer, this.subdomain = a.subdomain
        }
        var b = a.prototype;
        b.addQueryParam = function(a, b) {
            if (Boolean(a)) {
                var c = this.getQueryParams();
                c.set(a, b);
                return y(this, {
                    queryParams: c
                })
            }
            return this
        };
        b.addQueryParams = function(a) {
            if (a.size > 0) {
                var b = this.getQueryParams();
                a.forEach(function(a, c) {
                    b.set(c, a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.addQueryParamString = function(a) {
            if (Boolean(a)) {
                a = a.startsWith("?") ? a.slice(1) : a;
                var b = this.getQueryParams();
                a.split("&").map(function(a) {
                    a = a.split("=");
                    var c = a[0];
                    a = a[1];
                    b.set(c, a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.addTrailingSlash = function() {
            var a = this.getPath();
            return a.length > 0 && a[a.length - 1] !== "/" ? this.setPath(a + "/") : this
        };
        b.getDomain = function() {
            return this.domain
        };
        b.getFragment = function() {
            return this.fragment
        };
        b.getOrigin = function() {
            var a = this.getPort();
            return this.getProtocol() + "://" + this.getDomain() + (a ? ":" + a : "")
        };
        b.getOriginalRawQuery = function() {
            return this.originalRawQuery
        };
        b.getPath = function() {
            return this.path
        };
        b.getPort = function() {
            return this.port
        };
        b.getProtocol = function() {
            return this.protocol.toLowerCase()
        };
        b.getQualifiedUri = function() {
            if (!this.getDomain()) {
                var b;
                b = (b = typeof window !== "undefined" ? window : self) == null ? void 0 : (b = b.location) == null ? void 0 : b.href;
                if (b == null) {
                    c("FBLogger")("ConstUriUtils").blameToPreviousFile().warn("Cannot get qualified URI for current URI as there is no current location");
                    return null
                }(i || (i = c("ExecutionEnvironment"))).isInWorker && b.startsWith("blob:") && (b = b.substring(5, b.length));
                b = b.slice(0, b.indexOf("/", b.indexOf(":") + 3));
                return a.getUri(b + this.toString())
            }
            return this
        };
        b.getQueryParam = function(a) {
            a = this.queryParams.get(a);
            if (typeof a === "string") return a;
            else {
                a = JSON.stringify(a);
                return a == null ? a : JSON.parse(a)
            }
        };
        b.getQueryData = function() {
            return Object.fromEntries(this.getQueryParams())
        };
        b.getQueryParams = function() {
            if (c("structuredClone") != null) return c("structuredClone")(this.queryParams);
            var a = JSON.stringify(Array.from(this.queryParams), function(a, b) {
                return Array.isArray(b) ? {
                    __CUUArr: !0,
                    value: babelHelpers["extends"]({}, b)
                } : b
            });
            a = JSON.parse(a, function(a, b) {
                return b != null && typeof b === "object" && b.__CUUArr ? Object.keys(b.value).reduce(function(a, c) {
                    a[c] = b.value[c];
                    return a
                }, []) : b
            });
            return new Map(a)
        };
        b.getQueryString = function(a) {
            a === void 0 && (a = !1);
            return A(this.domain, this.originalRawQuery, this.queryParams, !1, a, this.serializer)
        };
        b.getRegisteredDomain = function() {
            if (!this.getDomain()) return "";
            if (!this.isFacebookUri()) return null;
            var a = this.getDomain().split("."),
                b = a.indexOf("facebook");
            b === -1 && (b = a.indexOf("workplace"));
            return a.slice(b).join(".")
        };
        b.getSerializer = function() {
            return this.serializer
        };
        b.getSubdomain = function() {
            return this.subdomain
        };
        b.getUnqualifiedUri = function() {
            if (this.getDomain()) {
                var b = this.toString();
                return a.getUri(b.slice(b.indexOf("/", b.indexOf(":") + 3)))
            }
            return this
        };
        a.getUri = function(b) {
            b = b.trim();
            var d = l.get(b);
            if (d == null) {
                var e = B(b);
                if (e.valid) d = new a(e.components), l.set(b, d);
                else {
                    c("FBLogger")("ConstUriUtils").blameToPreviousFrame().warn(e.error);
                    return null
                }
            }
            return d
        };
        a.getUriOrThrow = function(b) {
            return c("nullthrows")(a.getUri(b))
        };
        a.getUribyObject = function(b, d) {
            var e = z(b, d),
                f = l.get(e);
            if (f == null) {
                d && (b.originalRawQuery = t(b.queryParams, b.serializer));
                d = C(b);
                if (d.valid) f = new a(d.components), l.set(e, f);
                else {
                    c("recoverableViolation")(d.error, "ConstUri");
                    return null
                }
            }
            return f
        };
        b.hasFragmentSeparator = function() {
            return this.fragmentSeparator
        };
        b.isEmpty = function() {
            return !(this.getPath() || this.getProtocol() || this.getDomain() || this.getPort() || this.queryParams.size > 0 || this.getFragment())
        };
        b.isFacebookUri = function() {
            var a = this.toString();
            if (a === "") return !1;
            return !this.getDomain() && !this.getProtocol() ? !0 : ["https", "http"].indexOf(this.getProtocol()) !== -1 && (m.test(this.getDomain()) || n.test(this.getDomain()))
        };
        b.isGeneric = function() {
            return this.isGenericProtocol
        };
        b.isSameOrigin = function(a) {
            return c("isSameOrigin")(this, a)
        };
        b.isSubdomainOfDomain = function(b) {
            var c = a.getUri(b);
            return c != null && w(this.domain, b)
        };
        b.isSecure = function() {
            return this.getProtocol() === "https"
        };
        b.removeQueryParams = function(a) {
            if (Array.isArray(a) && a.length > 0) {
                var b = this.getQueryParams();
                a.map(function(a) {
                    return b["delete"](a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.removeQueryParam = function(a) {
            if (Boolean(a)) {
                var b = this.getQueryParams();
                b["delete"](a);
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.removeSubdomain = function() {
            var a = this.getQualifiedUri();
            if (a == null) return null;
            var b = a.getDomain();
            b = b.split(".");
            b.length >= 3 && (b = b.slice(-2));
            return y(a, {
                domain: b.join("."),
                subdomain: ""
            })
        };
        b.replaceQueryParam = function(a, b) {
            if (Boolean(a)) {
                var c = this.getQueryParams();
                c.set(a, b);
                return y(this, {
                    queryParams: c
                })
            }
            return this
        };
        b.replaceQueryParams = function(a) {
            return y(this, {
                queryParams: a
            })
        };
        b.replaceQueryParamString = function(a) {
            if (a != null) {
                a = a.startsWith("?") ? a.slice(1) : a;
                var b = this.getQueryParams();
                a.split("&").map(function(a) {
                    a = a.split("=");
                    var c = a[0];
                    a = a[1];
                    b.set(c, a)
                });
                return y(this, {
                    queryParams: b
                })
            }
            return this
        };
        b.setDomain = function(a) {
            if (Boolean(a)) {
                var b = a.split(".");
                b = b.length >= 3 ? b[0] : "";
                return y(this, {
                    domain: a,
                    subdomain: b
                })
            }
            return this
        };
        b.setFragment = function(a) {
            return a === "#" ? y(this, {
                fragment: "",
                fragmentSeparator: !0
            }) : y(this, {
                fragment: a,
                fragmentSeparator: a !== ""
            })
        };
        b.setPath = function(a) {
            return a != null ? y(this, {
                path: a
            }) : this
        };
        b.setPort = function(a) {
            return Boolean(a) ? y(this, {
                port: a
            }) : this
        };
        b.setProtocol = function(a) {
            return Boolean(a) ? y(this, {
                protocol: a
            }) : this
        };
        b.setSecure = function(a) {
            return this.setProtocol(a ? "https" : "http")
        };
        b.setSubDomain = function(a) {
            if (Boolean(a)) {
                var b = this.getQualifiedUri();
                if (b == null) return null;
                var c = b.getDomain();
                c = c.split(".");
                c.length >= 3 ? c[0] = a : c.unshift(a);
                return y(b, {
                    domain: c.join("."),
                    subdomain: a
                })
            }
            return this
        };
        b.stripTrailingSlash = function() {
            return this.setPath(this.getPath().replace(/\/$/, ""))
        };
        a.$1 = function(a) {
            a = a;
            for (var b = 0; b < r.length; b++) {
                var c = r[b];
                a = c(a)
            }
            return a
        };
        a.$2 = function(a, b) {
            b = b;
            for (var c = 0; c < s.length; c++) {
                var d = s[c];
                b = d(a, b)
            }
            return b
        };
        b.$3 = function(b, c) {
            c === void 0 && (c = !1);
            return z({
                domain: a.$1(this.domain),
                fragment: this.fragment,
                fragmentSeparator: this.fragmentSeparator,
                isGeneric: this.isGenericProtocol,
                originalRawQuery: this.originalRawQuery,
                path: this.path,
                port: this.port,
                protocol: this.protocol,
                queryParams: a.$2(this.domain, this.queryParams),
                serializer: b,
                subdomain: this.subdomain,
                userInfo: ""
            }, !1, c)
        };
        b.toStringRawQuery = function() {
            this.rawStringValue == null && (this.rawStringValue = this.$3(c("PHPQuerySerializerNoEncoding")));
            return this.rawStringValue
        };
        b.toString = function() {
            this.stringValue == null && (this.stringValue = this.$3(this.serializer));
            return this.stringValue
        };
        b.toStringPreserveQuery = function() {
            return this.$3(this.serializer, !0)
        };
        a.isValidUri = function(b) {
            var c = l.get(b);
            if (c != null) return !0;
            c = B(b);
            if (c.valid) {
                l.set(b, new a(c.components));
                return !0
            }
            return !1
        };
        return a
    }();

    function a(a) {
        if (a instanceof D) return a;
        else return null
    }

    function b(a) {
        r.push(a)
    }

    function e(a) {
        s.push(a)
    }
    f = D.getUri;
    var E = D.getUriOrThrow,
        F = D.isValidUri;
    g.isSubdomainOfDomain = w;
    g.isConstUri = a;
    g.registerDomainFilter = b;
    g.registerQueryParamsFilter = e;
    g.getUri = f;
    g.getUriOrThrow = E;
    g.isValidUri = F
}), 98);
__d("WebStorageCleanupReason", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = null;

    function a() {
        return g
    }

    function b(a) {
        g = a
    }
    f.getLastCleanupReason = a;
    f.setLastCleanupReason = b
}), 66);
__d("checkForIndexedDbSupported", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return !window.indexedDB ? !1 : !0
    }
    f["default"] = a
}), 66);
__d("cometAsyncFetchShared", ["cr:1396"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1396")
}), 98);
__d("isMessengerPWA", ["Env", "ExecutionEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function b() {
        var b;
        return (h || (h = c("ExecutionEnvironment"))).canUseDOM && a.matchMedia !== void 0 && a.matchMedia("(display-mode: standalone)").matches && ((b = (i || (i = c("Env"))).isMessengerDotComOnComet) != null ? b : !1)
    }
    g["default"] = b
}), 98);
__d("isRelativeURL", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /^(#|\/\w)/;

    function a(a) {
        return g.test(a)
    }
    f["default"] = a
}), 66);
__d("routeBuilderUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.split("/");
        return a.filter(function(a) {
            return a !== ""
        }).map(function(a) {
            var b = a.split(/{|}/);
            if (b.length < 3) return {
                isToken: !1,
                part: a
            };
            else {
                a = b[0];
                var c = b[1];
                b = b[2];
                var d = c[0] === "?",
                    e = c[d ? 1 : 0] === "*";
                c = c.substring((d ? 1 : 0) + (e ? 1 : 0));
                return {
                    isToken: !0,
                    optional: d,
                    catchAll: e,
                    prefix: a,
                    suffix: b,
                    token: c
                }
            }
        })
    }
    f.getPathParts = a
}), 66);
__d("jsRouteBuilder", ["ConstUriUtils", "FBLogger", "routeBuilderUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "#";

    function a(a, b, e, f, g) {
        g === void 0 && (g = !1);
        var i = d("routeBuilderUtils").getPathParts(a);

        function j(j) {
            try {
                var k = f != null ? babelHelpers["extends"]({}, f, j) : (j = j) != null ? j : {},
                    l = {};
                j = "";
                var m = !1;
                j = i.reduce(function(a, c) {
                    if (!c.isToken) return a + "/" + c.part;
                    else {
                        var d, e = c.optional,
                            f = c.prefix,
                            g = c.suffix;
                        c = c.token;
                        if (e && m) return a;
                        d = (d = k[c]) != null ? d : b[c];
                        if (d == null && e) {
                            m = !0;
                            return a
                        }
                        if (d == null) throw new Error("Missing required template parameter: " + c);
                        if (d === "") throw new Error("Required template parameter is an empty string: " + c);
                        l[c] = !0;
                        return a + "/" + f + d + g
                    }
                }, "");
                a.slice(-1) === "/" && (j += "/");
                j === "" && (j = "/");
                var n = d("ConstUriUtils").getUri(j);
                for (var o in k) {
                    var p = k[o];
                    !l[o] && p != null && n != null && (e != null && e.has(o) ? p !== !1 && (n = n.addQueryParam(o, null)) : n = n.addQueryParam(o, p))
                }
                return [n, j]
            } catch (b) {
                p = b == null ? void 0 : b.message;
                o = c("FBLogger")("JSRouteBuilder").blameToPreviousFrame().blameToPreviousFrame();
                g && (o = o.blameToPreviousFrame());
                o.mustfix("Failed building URI for base path: %s message: %s", a, p);
                return [null, h]
            }
        }
        return {
            buildUri: function(a) {
                a = (a = j(a)[0]) != null ? a : d("ConstUriUtils").getUri(h);
                if (a == null) throw new Error("Not even the fallback URL parsed validly!");
                return a
            },
            buildUriNullable: function(a) {
                return j(a)[0]
            },
            buildURL: function(a) {
                a = j(a);
                var b = a[0];
                a = a[1];
                return (b = b == null ? void 0 : b.toString()) != null ? b : a
            },
            buildURLStringDEPRECATED: function(a) {
                a = j(a);
                var b = a[0];
                a = a[1];
                return (b = b == null ? void 0 : b.toString()) != null ? b : a
            },
            getPath: function() {
                return a
            }
        }
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LSAddMessengerContact", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("contact_id", a[0]), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTask"), "add_messenger_contact", c.i64.cast([0, 308]), d[1], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSContactAddMessengerContactStoredProcedure";
    e.exports = a
}), null);
__d("LSAddMessengerContactStoredProcedure", ["LSAddMessengerContact", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSAddMessengerContact")(b.contactId, a)
    }
    g["default"] = a
}), 98);
__d("LSContactUserBlockAction", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        MN_UNBLOCK: 0,
        MN_BLOCK: 1,
        FB_UNBLOCK: 2,
        FB_BLOCK: 3
    });
    f["default"] = a
}), 66);
__d("LSOptimisticAcceptMessageRequest", ["LSIssueNewTaskWithExtraOperations"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]).next().then(function(e, f) {
                f = e.done;
                e = e.value;
                return f ? 0 : (e.item, c.sequence([function(b) {
                    return c.forEach(c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        var d = b.update;
                        b.item;
                        return d({
                            folderName: "inbox",
                            parentThreadKey: c.i64.cast([0, 0]),
                            igFolder: a[1]
                        })
                    })
                }, function(b) {
                    return c.db.table(173).fetch([
                        [
                            [a[0]]
                        ]
                    ]).next().then(function(a, b) {
                        var e = a.done;
                        a = a.value;
                        return e ? 0 : (b = a.item, d[4] = b.clientThreadPk, c.db.table(276).fetch([
                            [
                                [d[4]]
                            ]
                        ]).next().then(function(a, b) {
                            b = a.done;
                            a = a.value;
                            return b ? 0 : (a.item, c.forEach(c.db.table(276).fetch([
                                [
                                    [d[4]]
                                ]
                            ]), function(a) {
                                var b = a.update;
                                a.item;
                                return b({
                                    folderType: c.i64.cast([0, 0])
                                })
                            }))
                        }))
                    })
                }, function(b) {
                    return c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]).next().then(function(a, b) {
                        var e = a.done;
                        a = a.value;
                        return e ? d[0] = c.i64.cast([0, 1]) : (b = a.item, d[5] = b.syncGroup, c.i64.neq(d[5], void 0) ? d[4] = d[5] : d[4] = c.i64.cast([0, 1]), d[0] = d[4])
                    })
                }, function(e) {
                    return d[2] = new c.Map(), d[2].set("thread_key", a[0]), d[2].set("sync_group", d[0]), d[2].set("ig_folder", a[1]), d[3] = c.toJSON(d[2]), c.storedProcedure(b("LSIssueNewTaskWithExtraOperations"), "message_request", c.i64.cast([0, 66]), d[3], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), void 0, c.i64.cast([0, 0]))
                }]))
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxOptimisticAcceptMessageRequestStoredProcedure";
    e.exports = a
}), null);
__d("LSOptimisticAcceptMessageRequestStoredProcedure", ["LSOptimisticAcceptMessageRequest", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSOptimisticAcceptMessageRequest")(b.threadKey, b.igFolder, a)
    }
    g["default"] = a
}), 98);
__d("MAWBlockUtils", ["I64", "LSContactUserBlockAction", "LSIntEnum", "LSThreadBitOffset", "ReQL", "asyncToGeneratorRuntime", "promiseDone", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = (k || d("react")).useCallback,
        m = [0, 31, 35, 55, 56, 58, 24, 25, 19, 85],
        n = [0, 31, 35, 55, 56, 58, 24, 25, 19, 85, 8, 22],
        o = [35, 19, 85, 56, 24, 25];

    function a() {
        var a = (h || (h = c("useReStore")))();
        return l(function(e, g) {
            c("promiseDone")(b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                var b = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.tables.participants).getKeyRange(e)));
                if (b == null) return;
                var h = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.tables.threads).getKeyRange(b.threadKey).filter(function(a) {
                    return (i || (i = d("I64"))).equal(a.threadType, (j || (j = d("LSIntEnum"))).ofNumber(15))
                })));
                if (h == null) return;
                b = (i || (i = d("I64"))).equal(g, (j || (j = d("LSIntEnum"))).ofNumber(c("LSContactUserBlockAction").MN_BLOCK)) ? d("LSThreadBitOffset").clear(m, h.capabilities, h.capabilities2, h.capabilities3, h.capabilities4) : (i || (i = d("I64"))).equal(g, (j || (j = d("LSIntEnum"))).ofNumber(c("LSContactUserBlockAction").FB_BLOCK)) ? d("LSThreadBitOffset").clear(n, h.capabilities, h.capabilities2, h.capabilities3, h.capabilities4) : d("LSThreadBitOffset").set(o, h.capabilities, h.capabilities2, h.capabilities3, h.capabilities4);
                var k = b[0],
                    l = b[1];
                yield a.runInTransaction(function(a) {
                    var b = babelHelpers["extends"]({}, h, {
                        capabilities: k,
                        capabilities2: l
                    });
                    return a.threads.put(b)
                }, "readwrite", void 0, void 0, f.id + ":134")
            })())
        }, [a])
    }
    g.clearedMnBlockCapabilities = m;
    g.clearedFbBlockCapabilities = n;
    g.useChangeThreadBlockCapabilities = a
}), 98);
__d("MAWFTSRestoreSyncDeferred", ["JSResourceForInteraction", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("JSResourceForInteraction")("MAWFTSRestoreSync").__setRef("MAWFTSRestoreSyncDeferred");

    function a() {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            var a = (yield h.load());
            a = a.getFTSRestoreSync;
            return a()
        });
        return i.apply(this, arguments)
    }
    g.getInstance = a
}), 98);
__d("MAWGetEphemeralSettings", ["I64", "MAWBridgeSendAndReceive", "MAWChatJid", "ReQL", "WAJids", "WALogger", "WATimeUtils", "asyncToGeneratorRuntime", "promiseDone", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[ephemeral settings in memory]: MAWGetEphemeralSettings api call for chatJid ", " returns ", ""]);
        i = function() {
            return a
        };
        return a
    }
    var j = c("requireDeferred")("LSDatabaseSingletonLazyWrapper").__setRef("MAWGetEphemeralSettings"),
        k = c("requireDeferred")("MAWEphemeralSettingsUpdate").__setRef("MAWGetEphemeralSettings");

    function a(a, b) {
        return l.apply(this, arguments)
    }

    function l() {
        l = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            if (d("WAJids").switchOnMsgrChatJidType(a, {
                    group: function() {
                        return !1
                    },
                    user: function() {
                        return !0
                    }
                })) {
                var e = (yield j.load());
                e = (yield e());
                b = (b = b) != null ? b : yield d("MAWChatJid").toThreadKeyMaybe(e.tables, a);
                if (b != null) {
                    e = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(e.tables.threads).getKeyRange(b)));
                    if (e != null && e.disappearingSettingTtl != null) {
                        b = {
                            ephemeralExpirationInSec: (h || (h = d("I64"))).to_int32(e.disappearingSettingTtl),
                            ephemeralLastUpdatedOrSetTimestamp: e.disappearingSettingUpdatedBy != null ? d("WATimeUtils").castMilliSecondsToUnixTime((h || (h = d("I64"))).to_float(e.disappearingSettingUpdatedBy)) : d("WATimeUtils").unixTime()
                        };
                        return b
                    }
                    return
                }
                return d("MAWBridgeSendAndReceive").sendAndReceive("backend", "getEphemeralSettings", {
                    threadId: a
                }).then(function(b) {
                    d("WALogger").LOG(i(), a, b);
                    if (b != null) {
                        c("promiseDone")(k.load().then(function(c) {
                            return c.updateEphemeralSettingsByChatJid(b.ephemeralExpirationInSec, b.ephemeralLastUpdatedOrSetTimestamp, !1, a, !0)
                        }));
                        return b
                    }
                    return void 0
                })
            }
        });
        return l.apply(this, arguments)
    }
    g.getEphemeralSetting = a
}), 98);
__d("MAWMessageRequestUtil", ["I64", "LSContactBitOffset", "LSContactViewerRelationship", "LSIntEnum", "LSMessagingThreadTypeUtil"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j(a, b, e) {
        if (a === "pending" || a === "other") return !0;
        var f = d("LSContactBitOffset").hasWithDefault(64, e, !0);
        return a === "inbox" && (h || (h = d("I64"))).equal(e.contactViewerRelationship, (i || (i = d("LSIntEnum"))).ofNumber(c("LSContactViewerRelationship").NOT_CONTACT)) && !f ? b : !1
    }

    function k(a) {
        return a === "pending" || a === "other"
    }

    function a(a) {
        return d("LSMessagingThreadTypeUtil").isOneToOne(a.threadType) ? k(a.folderName) : !1
    }

    function l(a, b) {
        return b != null ? j(a.folderName, !(h || (h = d("I64"))).equal(a.lastActivityTimestampMs, h.zero), b[1]) : !1
    }

    function b(a, b) {
        return d("LSMessagingThreadTypeUtil").isOneToOne(a.threadType) ? l(a, b) : !1
    }
    e = [8, 18, 19, 34, 24, 25, 122];
    f = [21, 48];
    g.isMessageRequestV2 = j;
    g.isOneOnOneMessageRequest = a;
    g.isOneOnOneMessageRequestV2 = b;
    g.disabledThreadCapabilitiesForIncomingRequest = e;
    g.enabledThreadCapabilitiesForIncomingRequest = f
}), 98);
__d("MAWMiActOnActThreadReadyDeferred", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("MAWMiActOnActThreadReady").__setRef("MAWMiActOnActThreadReadyDeferred");

    function a(a, b, c, d) {
        return h.load().then(function(e) {
            e = e.onActThreadReady;
            return e(a.tables, b, c, d)
        })
    }
    g["default"] = a
}), 98);
__d("clearedMAWMnRestrictCapabilities", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = [0, 31, 35, 55, 56, 58, 24, 25, 35, 19];
    b = a;
    f["default"] = b
}), 66);
__d("MAWUpdateLSThreadCapabilities", ["fbt", "I64", "LSBitOffset", "LSContactBitOffset", "LSContactBlockedByViewerStatus", "LSIntEnum", "LSMessagingThreadTypeUtil", "LSThreadBitOffset", "MAWBlockUtils", "MAWCurrentUser", "MAWMessageRequestUtil", "Promise", "ReQL", "asyncToGeneratorRuntime", "clearedMAWMnRestrictCapabilities", "emptyFunction"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = d("MAWCurrentUser").getID(),
        m = (k || (k = d("I64"))).of_string(l);

    function a(a, e) {
        return d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.threads).getKeyRange(e)).then(function(c) {
            if (c == null) return (i || (i = b("Promise"))).resolve();
            var e = d("LSBitOffset").set((j || (j = d("LSIntEnum"))).ofNumber(27), c.capabilities);
            c = babelHelpers["extends"]({}, c, {
                capabilities: e
            });
            return a.threads.put(c)
        }).then(c("emptyFunction"))
    }

    function e(a, e) {
        return d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.threads).getKeyRange(e)).then(function(c) {
            if (c == null) return (i || (i = b("Promise"))).resolve();
            var e = d("LSBitOffset").clear((j || (j = d("LSIntEnum"))).ofNumber(27), c.capabilities);
            c = babelHelpers["extends"]({}, c, {
                capabilities: e
            });
            return a.threads.put(c)
        }).then(c("emptyFunction"))
    }

    function f(a, e) {
        return d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.threads).getKeyRange(e)).then(function(c) {
            if (c == null) return (i || (i = b("Promise"))).resolve([void 0, void 0]);
            var f = d("ReQL").firstAsync(d("LSMessagingThreadTypeUtil").isOneToOne(c.threadType) ? d("ReQL").mergeJoin(d("ReQL").fromTableAscending(a.participants).getKeyRange(e), d("ReQL").fromTableAscending(a.contacts)).filter(function(a) {
                a = a[1];
                return !(k || (k = d("I64"))).equal(a.id, m)
            }).map(function(a) {
                a = a[1];
                return a
            }) : d("ReQL").empty());
            return (i || (i = b("Promise"))).all([i.resolve(c), f])
        }).then(function(e) {
            var f = e[0];
            if (f == null) return (i || (i = b("Promise"))).resolve();
            e = e[1];
            if (e == null) return (i || (i = b("Promise"))).resolve();
            var g = (k || (k = d("I64"))).equal(e.blockedByViewerStatus, (j || (j = d("LSIntEnum"))).ofNumber(c("LSContactBlockedByViewerStatus").MESSAGE_BLOCKED)),
                h = k.equal(e.blockedByViewerStatus, j.ofNumber(c("LSContactBlockedByViewerStatus").FULLY_BLOCKED));
            e = d("LSContactBitOffset").has(66, e);
            h = h ? d("LSThreadBitOffset").clear(d("MAWBlockUtils").clearedFbBlockCapabilities, f.capabilities, f.capabilities2, f.capabilities3, f.capabilities4) : g ? d("LSThreadBitOffset").clear(d("MAWBlockUtils").clearedMnBlockCapabilities, f.capabilities, f.capabilities2, f.capabilities3, f.capabilities4) : e ? d("LSThreadBitOffset").clear(c("clearedMAWMnRestrictCapabilities"), f.capabilities, f.capabilities2, f.capabilities3, f.capabilities4) : [f.capabilities, f.capabilities2, f.capabilities3, f.capabilities4];
            g = h[0];
            e = h[1];
            var l = h[2];
            h = h[3];
            return a.threads.put(babelHelpers["extends"]({}, f, {
                capabilities: g,
                capabilities2: e,
                capabilities3: l,
                capabilities4: h
            })).then(c("emptyFunction"))
        })
    }

    function n(a, b) {
        return o.apply(this, arguments)
    }

    function o() {
        o = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            a = a.threads;
            c = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a).getKeyRange(c)));
            if (c == null) return (i || (i = b("Promise"))).resolve();
            var e = d("LSThreadBitOffset").set.apply(d("LSThreadBitOffset"), [d("MAWMessageRequestUtil").disabledThreadCapabilitiesForIncomingRequest].concat(d("LSThreadBitOffset").clear(d("MAWMessageRequestUtil").enabledThreadCapabilitiesForIncomingRequest, c.capabilities, c.capabilities2, c.capabilities3, c.capabilities4))),
                f = e[0],
                g = e[1],
                h = e[2];
            e = e[3];
            yield a.put(babelHelpers["extends"]({}, c, {
                additionalThreadContext: void 0,
                capabilities: f,
                capabilities2: g,
                capabilities3: h,
                capabilities4: e
            }))
        });
        return o.apply(this, arguments)
    }

    function p(a, b, c) {
        return q.apply(this, arguments)
    }

    function q() {
        q = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            b = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.threads).getKeyRange(b)));
            if (b == null) return;
            c = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.contacts, ["name"]).getKeyRange(c)));
            if (c == null) return;
            c = h._("__JHASH__uQTwTbCP0iW__JHASH__", [h._param("Inviter Name", c.name)]).toString();
            var e = d("LSThreadBitOffset").set([105], b.capabilities, b.capabilities2, b.capabilities3, b.capabilities4),
                f = e[0],
                g = e[1],
                i = e[2];
            e = e[3];
            yield a.threads.put(babelHelpers["extends"]({}, b, {
                capabilities: f,
                capabilities2: g,
                capabilities3: i,
                capabilities4: e,
                snippet: c
            }))
        });
        return q.apply(this, arguments)
    }

    function r(a, b) {
        return s.apply(this, arguments)
    }

    function s() {
        s = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            var e = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.threads).getKeyRange(c)));
            if (e == null) return;
            c = (yield d("ReQL").toArrayAsync(d("ReQL").fromTableAscending(a.group_invites).getKeyRange(c)));
            var f = d("LSThreadBitOffset").clear([105], e.capabilities, e.capabilities2, e.capabilities3, e.capabilities4),
                g = f[0],
                h = f[1],
                i = f[2];
            f = f[3];
            yield a.threads.put(babelHelpers["extends"]({}, e, {
                capabilities: g,
                capabilities2: h,
                capabilities3: i,
                capabilities4: f,
                snippet: void 0
            }));
            yield c.map(function() {
                var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                    yield a.group_invites["delete"](b.threadKey, b.inviterId, b.inviteeId)
                });
                return function(a) {
                    return c.apply(this, arguments)
                }
            }())
        });
        return s.apply(this, arguments)
    }
    g.enableAddMembersTxn = a;
    g.disableAddMembersTxn = e;
    g.disableBlockerCapabilitiesTxn = f;
    g.updateNonMessageRequestThreadTxn = n;
    g.setGroupInviteTxn = p;
    g.clearGroupInviteTxn = r
}), 226);
__d("MWEBEntrypointsKillswitch.enum", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        JEWEL_THREADLIST: "jewel_threadlist",
        IN_THREAD_GAP_UI: "in_thread_gap_ui",
        IN_THREAD_SCROLL_BANNER: "in_thread_scroll_banner",
        IN_THREAD_SEARCH: "in_thread_search",
        INBOX_INTERSTITIAL: "inbox_interstitial",
        INBOX_THREADLIST: "inbox_threadlist",
        INBOX_THREADLIST_UNIVERSAL_SEARCH: "inbox_threadlist_universal_search",
        MEDIA_GALLERY_RESTORE: "media_gallery_restore",
        EB_SETTINGS: "eb_settings",
        AUTO_RESTORE: "auto_restore",
        DYI: "dyi",
        IGD_NO_KILLSWITCH_APPLICABLE: "igd_no_killswitch_applicable",
        NOT_AN_ENTRYPOINT_NO_KILLSWITCH_APPLICABLE: "not_an_entrypoint_no_killswitch_applicable",
        IN_DEVELOPMENT_ADD_A_TODO_COMMENT_WITH_A_TASK_ABOVE_THIS_TO_ADD_A_KILLSWITCH: "in_development_add_a_todo_comment_with_a_task_above_this_to_add_a_killswitch",
        PINNED_MESSAGES: "pinned_messages"
    });
    c = a;
    f["default"] = c
}), 66);
__d("MWInboxMessageSearchStatusTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["IN_PROGRESS", "COMPLETE", "NOT_RUNNING", "NOT_REQUIRED"]);
    c = b("$InternalEnum").Mirrored(["IN_PROGRESS", "COMPLETE", "NOT_STARTED"]);
    d = b("$InternalEnum").Mirrored(["NOT_STARTED", "IN_PROGRESS", "COMPLETE", "FAILED"]);
    f.RestoreStatus = a;
    f.OverallStatus = c;
    f.PrimarySearchStatus = d
}), 66);
__d("isMWEBEntrypointEnabled", ["MWEBEntrypointsKillswitch.enum", "justknobx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = c("qex")._("988");
        switch (a) {
            case c("MWEBEntrypointsKillswitch.enum").INBOX_INTERSTITIAL:
                return c("justknobx")._("2598") && !b;
            case c("MWEBEntrypointsKillswitch.enum").JEWEL_THREADLIST:
                return c("justknobx")._("2599");
            case c("MWEBEntrypointsKillswitch.enum").INBOX_THREADLIST:
                return c("justknobx")._("2600");
            case c("MWEBEntrypointsKillswitch.enum").IN_THREAD_GAP_UI:
                return c("justknobx")._("2601") && !b;
            case c("MWEBEntrypointsKillswitch.enum").IN_THREAD_SCROLL_BANNER:
                return c("justknobx")._("2602") && !b;
            case c("MWEBEntrypointsKillswitch.enum").AUTO_RESTORE:
                return c("justknobx")._("2603");
            case c("MWEBEntrypointsKillswitch.enum").IN_THREAD_SEARCH:
                return c("justknobx")._("2604") && !b;
            case c("MWEBEntrypointsKillswitch.enum").INBOX_THREADLIST_UNIVERSAL_SEARCH:
                return c("justknobx")._("2768") && !b;
            case c("MWEBEntrypointsKillswitch.enum").MEDIA_GALLERY_RESTORE:
                return c("justknobx")._("2841") && !b;
            case c("MWEBEntrypointsKillswitch.enum").PINNED_MESSAGES:
                return c("justknobx")._("2937") && !b;
            case c("MWEBEntrypointsKillswitch.enum").DYI:
            case c("MWEBEntrypointsKillswitch.enum").EB_SETTINGS:
            case c("MWEBEntrypointsKillswitch.enum").IGD_NO_KILLSWITCH_APPLICABLE:
            case c("MWEBEntrypointsKillswitch.enum").NOT_AN_ENTRYPOINT_NO_KILLSWITCH_APPLICABLE:
            case c("MWEBEntrypointsKillswitch.enum").IN_DEVELOPMENT_ADD_A_TODO_COMMENT_WITH_A_TASK_ABOVE_THIS_TO_ADD_A_KILLSWITCH:
                return !0
        }
    }
    g["default"] = a
}), 98);
__d("isMWNewSearchUXEnabled", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("gkx")("4801")
    }
    g["default"] = a
}), 98);
__d("useMWEBBackupStateQuery.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
            alias: null,
            args: null,
            concreteType: "Viewer",
            kind: "LinkedField",
            name: "viewer",
            plural: !1,
            selections: [{
                kind: "ClientExtension",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "backup_state",
                    storageKey: null
                }]
            }],
            storageKey: null
        };
        return {
            fragment: {
                argumentDefinitions: [],
                kind: "Fragment",
                metadata: null,
                name: "useMWEBBackupStateQuery",
                selections: [{
                    kind: "RequiredField",
                    field: a,
                    action: "LOG",
                    path: "viewer"
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [],
                kind: "Operation",
                name: "useMWEBBackupStateQuery",
                selections: [a]
            },
            params: {
                cacheID: "780695c71d771c39c4d001bd676844c7",
                id: null,
                metadata: {},
                name: "useMWEBBackupStateQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useMWEBBackupState", ["CometRelay", "isMWEBEntrypointEnabled", "useMWEBBackupStateQuery.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        a = a.entrypoint;
        var e = d("CometRelay").useClientQuery(h !== void 0 ? h : h = b("useMWEBBackupStateQuery.graphql"), {});
        return !c("isMWEBEntrypointEnabled")(a) || (e == null ? void 0 : e.viewer) == null ? 0 : (a = e.viewer.backup_state) != null ? a : 1
    }
    g["default"] = a
}), 98);
__d("useMWInboxMessageSearchRestoreLoopLoadedUntilDate", ["MAWBridgeSendAndReceive", "asyncToGeneratorRuntime", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    c = h || d("react");
    var i = c.useEffect,
        j = c.useState;

    function a(a) {
        var c = j(null),
            e = c[0],
            f = c[1];
        i(function() {
            f(null);
            var c = window.setInterval(b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                var b = a == null ? null : yield d("MAWBridgeSendAndReceive").sendAndReceive("backend", "searchGetFTSNextTimestamp", {
                    threadId: a
                }, {
                    isLoggingDisabled: !0
                });
                b = b != null ? parseInt(b, 10) : -1;
                f(b);
                b === 0 && window.clearInterval(c)
            }), 300);
            return function() {
                window.clearInterval(c)
            }
        }, [a]);
        return e
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("C4gEngagementFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1922200");
    b = d("FalcoLoggerInternal").create("c4g_engagement", a);
    e = b;
    g["default"] = e
}), 98);
__d("CometFocusGroupContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        FocusContainer: null,
        FocusItem: null
    });
    g["default"] = b
}), 98);
__d("CometHeroHoldTrigger.react", ["hero-tracing-placeholder"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("hero-tracing-placeholder").HeroHoldTrigger
}), 98);
__d("FDSTextWebUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a == null ? void 0 : a === "tertiary" ? "tertiary" : a
    }

    function b(a) {
        return a == null ? void 0 : a === "tertiary" ? "tertiary" : a
    }

    function c(a) {
        return a == null ? void 0 : a === "tertiary" ? "tertiary" : a
    }
    f.getFDSBodyColor = a;
    f.getFDSHeadlineColor = b;
    f.getFDSMetaColor = c
}), 66);
__d("focusKeyboardEventPropagation", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a._stopFocusKeyboardPropagation === !0
    }

    function b(a) {
        a._stopFocusKeyboardPropagation = !0
    }
    f.hasFocusKeyboardEventPropagationStopped = a;
    f.stopFocusKeyboardEventPropagation = b
}), 66);
__d("FocusGroup.react", ["FocusManager", "Locale", "ReactFocusEvent.react", "ReactKeyboardEvent.react", "focusKeyboardEventPropagation", "gkx", "react", "setElementCanTab"], (function(a, b, c, d, e, f, g) {
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useContext,
        k = b.useMemo,
        l = b.useRef,
        m = 5;

    function n(a) {
        return a.length === 1
    }

    function o(a, b, c, e) {
        d("focusKeyboardEventPropagation").stopFocusKeyboardEventPropagation(c);
        b = b.DO_NOT_USE_queryFirstNode(a);
        b !== null && (document.activeElement != null && d("setElementCanTab").setElementCanTab(document.activeElement, !1), d("setElementCanTab").setElementCanTab(b, !0), d("FocusManager").focusElement(b, {
            preventScroll: e
        }), c.preventDefault())
    }

    function p(a, b, c, d, e, f) {
        b = b.onNavigate;
        if (b && d) {
            var g = !1,
                h = q(d, e);
            e = {
                currentIndex: h,
                event: c,
                focusItem: function(a, b) {
                    a = a.scopeRef.current;
                    a && o(b || f, a, c)
                },
                getItem: function(a) {
                    return u(d, a)
                },
                getItemByTag: function(a) {
                    var b = d.length,
                        c = h + 1;
                    while (!0) {
                        if (c === h) return null;
                        if (c > b - 1) {
                            c = 0;
                            continue
                        }
                        var e = d[c];
                        if (e) {
                            var f = e.disabled,
                                g = e.scopeRef,
                                i = e.tag;
                            g = g.current;
                            if (g && f !== !0 && i === a) return e
                        }
                        c++
                    }
                    return null
                },
                preventDefault: function() {
                    g = !0
                },
                type: a
            };
            b(e);
            if (g) return !0
        }
        return !1
    }

    function q(a, b) {
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            if (d && d.scopeRef.current === b) return c
        }
        return -1
    }

    function r(a, b, c) {
        var d = a.scopeRef.current;
        if (d === null) return null;
        if (c !== null) {
            d = q(c, b);
            b = a.wrap;
            a = v(c, d - 1);
            return !a && b === !0 ? v(c, c.length - 1) : a
        }
        return null
    }

    function s(a, b, c) {
        var d = a.scopeRef.current;
        if (d === null) return null;
        if (c.length > 0) {
            d = q(c, b);
            b = a.wrap;
            a = t(c, d + 1);
            return !a && b === !0 ? t(c, 0) : a
        }
        return null
    }

    function t(a, b) {
        var d = a.length;
        if (b > d) return null;
        b = b;
        while (b < d) {
            var e = a[b];
            if (c("gkx")("21059")) {
                if (e !== null) return e.scopeRef.current
            } else if (e !== null && e.disabled !== !0) return e.scopeRef.current;
            b++
        }
        return null
    }

    function u(a, b) {
        b = b;
        while (b >= 0) {
            var d = a[b];
            if (c("gkx")("21059")) {
                if (d !== null) return d
            } else if (d !== null && d.disabled !== !0) return d;
            b--
        }
        return null
    }

    function v(a, b) {
        a = u(a, b);
        return a ? a.scopeRef.current : null
    }

    function w(a) {
        var b = a.altKey,
            c = a.ctrlKey,
            d = a.metaKey;
        a = a.shiftKey;
        return b === !0 || c === !0 || d === !0 || a === !0
    }

    function a(a) {
        var b = i.unstable_Scope,
            c = i.createContext(null),
            e = i.createContext(null);

        function g(e) {
            var f = e.children,
                g = e.orientation,
                j = e.wrap,
                n = e.tabScopeQuery,
                o = e.allowModifiers,
                p = e.preventScrollOnFocus,
                q = p === void 0 ? !1 : p;
            p = e.pageJumpSize;
            var r = p === void 0 ? m : p,
                s = e.onNavigate,
                t = l(null);
            p = k(function() {
                return {
                    scopeRef: t,
                    orientation: g,
                    wrap: j,
                    tabScopeQuery: n,
                    allowModifiers: o,
                    pageJumpSize: r,
                    preventScrollOnFocus: q,
                    onNavigate: s
                }
            }, [g, j, n, o, r, q, s]);
            var u = l(!1);
            e = d("ReactFocusEvent.react").useFocusWithin(t, k(function() {
                return {
                    onFocusWithin: function(b) {
                        u.current || (u.current = !0, t.current && a && (h(t.current, a), d("setElementCanTab").setElementCanTab(b.target, !0)))
                    }
                }
            }, [u]));
            return i.jsx(c.Provider, {
                value: p,
                children: i.jsx(b, {
                    ref: e,
                    children: f
                })
            })
        }
        g.displayName = g.name + " [from " + f.id + "]";

        function h(a, b) {
            var c = document.activeElement;
            a = a.DO_NOT_USE_queryAllNodes(b);
            if (a !== null)
                for (b = 0; b < a.length; b++) {
                    var e = a[b];
                    e !== c ? d("setElementCanTab").setElementCanTab(e, !1) : d("setElementCanTab").setElementCanTab(e, !0)
                }
        }

        function u(f) {
            var g = f.children,
                m = f.disabled;
            f = f.tag;
            var u = l(null),
                x = j(c);
            d("ReactKeyboardEvent.react").useKeyboard(u, k(function() {
                return {
                    onKeyDown: function(b) {
                        if (d("focusKeyboardEventPropagation").hasFocusKeyboardEventPropagationStopped(b)) return;
                        var c = u.current;
                        if (c !== null && x !== null) {
                            var f = x.orientation === "vertical" || x.orientation === "both",
                                g = x.orientation === "horizontal" || x.orientation === "both",
                                i = x.scopeRef.current,
                                j = b.key,
                                k = x.preventScrollOnFocus;
                            if (j === "Tab" && i !== null) {
                                var l = x.tabScopeQuery;
                                if (l) {
                                    if (x.onNavigate) {
                                        var m = i.getChildContextValues(e);
                                        if (p("TAB", x, b, m, c, l)) return
                                    }
                                    h(i, l)
                                }
                                return
                            }
                            if (w(b)) {
                                m = x.allowModifiers;
                                if (m !== !0) return
                            }
                            if (i === null) return;
                            l = j;
                            d("Locale").isRTL() && (j === "ArrowRight" ? l = "ArrowLeft" : j === "ArrowLeft" && (l = "ArrowRight"));
                            switch (l) {
                                case "Home":
                                    m = i.getChildContextValues(e);
                                    if (p("HOME", x, b, m, c, a)) return;
                                    l = t(m, 0);
                                    if (l) {
                                        o(a, l, b, k);
                                        return
                                    }
                                    break;
                                case "End":
                                    m = i.getChildContextValues(e);
                                    if (p("END", x, b, m, c, a)) return;
                                    l = v(m, m.length - 1);
                                    if (l) {
                                        o(a, l, b, k);
                                        return
                                    }
                                    break;
                                case "PageUp":
                                    m = i.getChildContextValues(e);
                                    if (p("PAGE_UP", x, b, m, c, a)) return;
                                    l = x.pageJumpSize;
                                    var y = q(m, c);
                                    m = t(m, Math.max(0, y - l));
                                    if (m) {
                                        o(a, m, b, k);
                                        return
                                    }
                                    break;
                                case "PageDown":
                                    y = i.getChildContextValues(e);
                                    if (p("PAGE_DOWN", x, b, y, c, a)) return;
                                    l = x.pageJumpSize;
                                    m = q(y, c);
                                    y = v(y, Math.min(y.length - 1, m + l));
                                    if (y) {
                                        o(a, y, b, k);
                                        return
                                    }
                                    break;
                                case "ArrowUp":
                                    if (f) {
                                        m = i.getChildContextValues(e);
                                        if (p("PREV_ITEM", x, b, m, c, a)) return;
                                        l = b.metaKey || b.ctrlKey ? t(m, 0) : r(x, c, m);
                                        if (l) {
                                            o(a, l, b, k);
                                            return
                                        }
                                    }
                                    break;
                                case "ArrowDown":
                                    if (f) {
                                        y = i.getChildContextValues(e);
                                        if (p("NEXT_ITEM", x, b, y, c, a)) return;
                                        m = b.metaKey || b.ctrlKey ? v(y, y.length - 1) : s(x, c, y);
                                        if (m) {
                                            o(a, m, b, k);
                                            return
                                        }
                                    }
                                    break;
                                case "ArrowLeft":
                                    if (g) {
                                        l = i.getChildContextValues(e);
                                        if (p("PREV_ITEM", x, b, l, c, a)) return;
                                        f = b.metaKey || b.ctrlKey ? t(l, 0) : r(x, c, l);
                                        if (f) {
                                            o(a, f, b, k);
                                            return
                                        }
                                    }
                                    break;
                                case "ArrowRight":
                                    if (g) {
                                        y = i.getChildContextValues(e);
                                        if (p("NEXT_ITEM", x, b, y, c, a)) return;
                                        m = b.metaKey || b.ctrlKey ? v(y, y.length - 1) : s(x, c, y);
                                        m && o(a, m, b, k)
                                    }
                                    break;
                                default:
                                    if (n(j) && x.onNavigate) {
                                        l = i.getChildContextValues(e);
                                        p("PRINT_CHAR", x, b, l, c, a)
                                    }
                            }
                        }
                    }
                }
            }, [x]));
            var y = d("ReactFocusEvent.react").useFocusWithin(u, k(function() {
                return {
                    onFocusWithin: function(b) {
                        if (a != null) {
                            var c;
                            c = (c = u.current) == null ? void 0 : c.DO_NOT_USE_queryFirstNode(a);
                            b = b.target === c;
                            if (b && (c && !d("setElementCanTab").canElementTab(c))) {
                                b = x == null ? void 0 : x.scopeRef.current;
                                b && h(b, a)
                            }
                        }
                    }
                }
            }, [x == null ? void 0 : x.scopeRef]));
            m = {
                scopeRef: u,
                disabled: m,
                tag: f
            };
            return i.jsx(e.Provider, {
                value: m,
                children: i.jsx(b, {
                    ref: y,
                    children: g
                })
            })
        }
        u.displayName = u.name + " [from " + f.id + "]";
        return [g, u]
    }
    g.createFocusGroup = a
}), 98);
__d("MWXButton.react", ["cr:1329", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    c = i.forwardRef(a);

    function a(a, c) {
        a = babelHelpers["extends"]({}, a);
        return i.jsx(b("cr:1329"), babelHelpers["extends"]({
            ref: c
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = c;
    g["default"] = e
}), 98);
__d("MWXGlimmer.react", ["cr:4067", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsx(b("cr:4067"), babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXIconForListCell.react", ["MWXIconStrict.react", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("gkx")("23219") ? 16 : 20,
        k = c("gkx")("23219") ? 28 : 36;

    function a(a) {
        var b = a.color,
            d = a.hasBackground;
        d = d === void 0 ? !0 : d;
        var e = a.icon;
        a = a.size;
        a = a === void 0 ? "medium" : a;
        var f;
        a === "medium" ? f = d ? k : j : (a, f = d ? 36 : 20);
        return i.jsx(c("MWXIconStrict.react"), {
            backgroundEnabled: d,
            color: b,
            icon: e,
            size: f
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXLazyPopoverTrigger.react", ["cr:7121", "cr:8610", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        if (b("cr:8610") != null) return i.jsx(b("cr:8610"), babelHelpers["extends"]({}, a));
        return b("cr:7121") != null ? i.jsx(b("cr:7121"), babelHelpers["extends"]({}, a)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXPopoverLoadingState.react", ["cr:8235", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");
    g["default"] = b("cr:8235")
}), 98);
__d("MWXScrollableArea.react", ["MDSScrollableArea.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("MDSScrollableArea.react")
}), 98);
__d("MWXTextPairing.react", ["FDSTextWebUtils", "cr:4853", "cr:6725", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function j(a) {
        return function(b) {
            a != null && (typeof a === "function" ? a(b) : a.current = b)
        }
    }

    function a(a) {
        if (b("cr:6725") != null) {
            var c = a.bodyColor,
                e = a.bodyRef,
                f = a.headlineColor,
                g = a.headlineRef,
                h = a.metaColor,
                k = a.metaRef,
                l = babelHelpers.objectWithoutPropertiesLoose(a, ["bodyColor", "bodyRef", "headlineColor", "headlineRef", "metaColor", "metaRef"]);
            return i.jsx("div", {
                className: "x9f619 x2lwn1j xeuugli x1n2onr6 x1ja2u2z",
                children: i.jsx(b("cr:6725"), babelHelpers["extends"]({
                    bodyColor: d("FDSTextWebUtils").getFDSBodyColor(c),
                    bodyRef: j(e),
                    headlineColor: d("FDSTextWebUtils").getFDSHeadlineColor(f),
                    headlineRef: j(g),
                    metaColor: d("FDSTextWebUtils").getFDSMetaColor(h),
                    metaRef: j(k)
                }, l))
            })
        }
        return b("cr:4853") != null ? i.jsx(b("cr:4853"), babelHelpers["extends"]({}, a)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXToast.react", ["cr:1339", "cr:3542", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var c, d = a.actions,
            e = a.assertive;
        e = e === void 0 ? !1 : e;
        var f = a.body,
            g = a.icon,
            h = a.impressionLoggingRef,
            j = a.onDismiss,
            k = a.startAddOn;
        k = k === void 0 ? null : k;
        var l = a.supressCloseButton;
        l = l === void 0 ? !1 : l;
        var m = a.testid;
        m = m === void 0 ? "mw-toast" : m;
        a = a.title;
        var n = (g == null ? void 0 : g.mds) != null ? {
            source: g == null ? void 0 : g.mds,
            type: "icon"
        } : void 0;
        g = (g = g == null ? void 0 : g.comet) != null ? g : void 0;
        c = a != null && f != null ? i.jsxs(i.Fragment, {
            children: [a, i.jsx("br", {}), f]
        }) : (c = (c = a) != null ? c : f) != null ? c : "";
        g = {
            icon: g,
            impressionLoggingRef: h,
            message: c,
            onDismiss: j,
            supressCloseButton: l,
            testid: m
        };
        return b("cr:3542") != null ? i.jsx(b("cr:3542"), {
            actions: d,
            assertive: e,
            body: f,
            impressionLoggingRef: h,
            onDismiss: j,
            startAddOn: k !== null ? k : n,
            testid: void 0,
            title: a,
            withCloseButton: !l
        }) : b("cr:1339") != null ? d != null ? i.jsx(b("cr:1339"), babelHelpers["extends"]({}, g, {
            action: babelHelpers["extends"]({}, d.primaryCallToAction)
        })) : i.jsx(b("cr:1339"), babelHelpers["extends"]({}, g)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getItemRoleFromCompositeRole", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case "grid":
                return "row";
            case "listbox":
                return "option";
            case "list":
                return "listitem";
            case "menu":
                return "menuitem";
            case "radiogroup":
                return "radio";
            case "row":
                return "gridcell";
            case "tablist":
                return "tab"
        }
        return null
    }
    f["default"] = a
}), 66);
__d("getLSMediaContactProfilePictureUrl", ["LSMediaUrlUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.profilePictureUrlExpirationTimestampMs;
        if (b != null && d("LSMediaUrlUtils").isTimestampExpired(b) || a.profilePictureUrl === "") {
            return (b = a.profilePictureFallbackUrl) != null ? b : a.profilePictureUrl
        } else return a.profilePictureUrl
    }
    g["default"] = a
}), 98);
__d("intlSummarizeNumber", ["FbtNumberType", "IntlCompactDecimalNumberFormatConfig", "IntlVariations", "intlNumUtils"], (function(a, b, c, d, e, f, g) {
    var h = 3,
        i = 14,
        j = {
            ROUND: "ROUND",
            TRUNCATE: "TRUNCATE",
            NONE: "NONE"
        },
        k = {
            SHORT: "SHORT",
            LONG: "LONG",
            NONE: "NONE"
        },
        l = {
            ALWAYS_SHOW: "ALWAYS_SHOW",
            HIDE_IF_ZERO: "HIDE_IF_ZERO"
        };

    function a(a, b, d, e, f) {
        d === void 0 && (d = k.SHORT);
        e === void 0 && (e = j.ROUND);
        f === void 0 && (f = l.ALWAYS_SHOW);
        var g = c("IntlCompactDecimalNumberFormatConfig")[d === k.SHORT ? "short_patterns" : "long_patterns"],
            n = a === 0 ? 0 : Math.floor(Math.log10(Math.abs(a)));
        n > i && (n = i);
        var o = e === j.NONE ? [a, b, !1] : m(a, n, b, e, g),
            p = o[0],
            q = o[1];
        o = o[2];
        if (o && e === j.ROUND) {
            n += 1;
            o = m(a, n, b, e, g);
            p = o[0];
            q = o[1];
            o[2]
        }
        e = c("FbtNumberType").getVariation(p) || c("IntlVariations").NUMBER_OTHER;
        o = n.toString();
        o = g == null ? void 0 : (g = g[o]) == null ? void 0 : g[e.toString()];
        if (!o || n < h || o.positive_prefix_pattern === "" && o.positive_suffix_pattern === "") {
            g = b === void 0 ? 0 : b;
            return c("intlNumUtils").formatNumberWithThousandDelimiters(a, g)
        }
        if (f === l.HIDE_IF_ZERO) {
            e = p;
            for (n = q != null ? q : 0; n > 0; n--) e % 1 === 0 && q != null && q--, e *= 10
        }
        if (d === k.NONE) return c("intlNumUtils").formatNumberWithThousandDelimiters(p, q);
        return o && o.min_integer_digits === 0 && p === 1 ? o.positive_prefix_pattern + o.positive_suffix_pattern : (o && o.positive_prefix_pattern || "") + c("intlNumUtils").formatNumberWithThousandDelimiters(p, q) + (o && o.positive_suffix_pattern || "")
    }

    function m(a, b, d, e, f) {
        var g = b.toString();
        g = f == null ? void 0 : (f = f[g]) == null ? void 0 : f[c("IntlVariations").NUMBER_OTHER.toString()];
        f = g && g.min_integer_digits || b + 1;
        var h = b - f + 1;
        h = Math.abs(a) / Math.pow(10, h);
        var k = d != null;
        d = k ? d : g && g.min_fraction_digits;
        d == null && (d = b > 2 ? 1 : 0);
        g = e === j.TRUNCATE ? c("intlNumUtils").truncateLongNumber(h.toString(), d) : h.toFixed(d);
        e = parseFloat(g) * (a < 0 ? -1 : 1);
        return [e, e % 1 === 0 && !k ? 0 : d, g.length > f + (d > 0 ? d + 1 : 0) + (h >= 0 ? 0 : 1) && b < i]
    }
    g["default"] = a
}), 98);
__d("mwPushToast", ["ix", "BaseToasterStateManager", "MWXToast.react", "cr:4379", "cr:6570", "fbicon", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react"),
        k = c("BaseToasterStateManager").getInstance();

    function l(a, b) {
        var d = a.assertive,
            e = a.body,
            f = a.icon,
            g = a.impressionLoggingRef,
            h = a.onDismiss,
            i = a.startAddOn;
        i = i === void 0 ? null : i;
        var l = a.supressCloseButton;
        l = l === void 0 ? !1 : l;
        var m = a.testid;
        m = a.title;
        b === void 0 && (b = 2750);
        var n = k.push(j.jsx(c("MWXToast.react"), {
            assertive: d,
            body: e,
            icon: f,
            impressionLoggingRef: g,
            onDismiss: function() {
                k.expire(n), h == null ? void 0 : h()
            },
            startAddOn: i,
            supressCloseButton: l,
            testid: void 0,
            title: m
        }), b);
        return n
    }

    function a(a, c) {
        var e, f = a.body,
            g = a.onDismiss;
        a = a.title;
        c === void 0 && (c = 2750);
        var i = b("cr:6570") !== null ? j.jsx(b("cr:6570"), {
            color: "warning",
            icon: d("fbicon")._(h("502062"), 20)
        }) : void 0;
        e = (e = b("cr:4379")) != null ? e : void 0;
        return l({
            assertive: !0,
            body: f,
            icon: {
                comet: i,
                mds: e
            },
            onDismiss: g,
            title: a
        }, c)
    }
    g.mwPushToast = l;
    g.mwPushErrorToast = a
}), 98);
__d("useMWXPushToast", ["MWXIcon.react", "mwPushToast", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || c("react"),
        k = (h || (h = d("react"))).useCallback;

    function a() {
        return k(function(a) {
            var b = a._isWarning_DO_NOT_USE;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["_isWarning_DO_NOT_USE"]);
            d("mwPushToast").mwPushToast(babelHelpers["extends"]({}, a, {
                icon: a.icon ? {
                    comet: j.jsx(c("MWXIcon.react"), {
                        color: b === !0 ? "warning" : void 0,
                        icon: a.icon.component,
                        size: 20
                    }),
                    mds: a.icon.component
                } : void 0
            }))
        }, [])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("XPlatReactTextEncoder", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = self.TextEncoder;
    f.TextEncoder = a
}), 66);
__d("base64Binary", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a) {
        var b = "";
        for (var c = 0; c < a.byteLength; c += 3) {
            var d = a.subarray(c, c + 3);
            b += k(d)
        }
        d = (a.byteLength + 2) % 3;
        return b.slice(0, b.length + d - 2) + "==".slice(d)
    }

    function b(a) {
        var b;
        a.length % 4 === 0 || h(0, 51156);
        var c = a.length / 4;
        b = (b = (b = a.match(/={0,2}$/)) == null ? void 0 : b[0].length) != null ? b : 0;
        b = new Uint8Array(c * 3 - b);
        for (var d = 0; d < c; d++) {
            var e = l(a.slice(d * 4, d * 4 + 4));
            b.set(e.subarray(0, b.byteLength - d * 3), d * 3)
        }
        return b
    }
    var i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        j = ">___?456789:;<=___\0___\0\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19______\x1a\x1b\x1c\x1d\x1e\x1f !\"#$%&'()*+,-./0123";

    function k(a) {
        var b;
        a = a[0] << 16 | ((b = a[1]) != null ? b : 0) << 8 | ((b = a[2]) != null ? b : 0);
        return String.fromCharCode(i.charCodeAt(a >>> 18), i.charCodeAt(a >>> 12 & 63), i.charCodeAt(a >>> 6 & 63), i.charCodeAt(a & 63))
    }

    function l(a) {
        a = j.charCodeAt(a.charCodeAt(0) - 43) << 18 | j.charCodeAt(a.charCodeAt(1) - 43) << 12 | j.charCodeAt(a.charCodeAt(2) - 43) << 6 | j.charCodeAt(a.charCodeAt(3) - 43);
        return new Uint8Array([a >>> 16, a >>> 8 & 255, a & 255])
    }
    g.encode = a;
    g.decode = b
}), 98);
__d("Base64Utils", ["XPlatReactTextEncoder", "base64Binary"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return d("base64Binary").encode(new(d("XPlatReactTextEncoder").TextEncoder)().encode(a))
    }

    function b(a) {
        return d("base64Binary").encode(new Uint8Array(a))
    }

    function c(a) {
        return d("base64Binary").decode(a).buffer
    }
    g.encodeUnicode = a;
    g.fromArrayBuffer = b;
    g.toArrayBuffer = c
}), 98);
__d("CryptoLogger", ["FBLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("FBLogger")("labyrinth_web", "crypto." + a)
    }

    function b(a, b) {
        return b instanceof Error ? a.catching(b) : a
    }
    g.CryptoLogger = a;
    g.captureError = b
}), 98);
__d("LSClearThreadLimits", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(a) {
            return b.forEach(b.db.table(287).fetch(), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsClearThreadLimitsStoredProcedure";
    e.exports = a
}), null);
__d("LSJson", ["FBLogger", "I64", "LSDict", "LSVec", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = 512,
        j = {
            useLSTypes: !1
        };

    function a(a, b) {
        b = b === void 0 ? j : b;
        var e = b.useLSTypes;

        function f(a, b) {
            return function() {
                return function(c) {
                    c = a()(c);
                    if (c != null) {
                        var d = c[0];
                        c = c[1];
                        return [b(d), c]
                    }
                }
            }
        }

        function g(a) {
            return JSON.parse('"' + a + '"')
        }

        function i(a) {
            return function() {
                return function(b) {
                    var c = g(a);
                    if (b.startsWith(c)) return [c, b.substr(c.length)];
                    else return void 0
                }
            }
        }

        function k() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return function() {
                return function(a) {
                    var c = [];
                    a = a;
                    for (var d = 0; d < b.length; d++) {
                        var e = b[d];
                        e = e()(a);
                        if (e == null) return void 0;
                        a = e[1];
                        c.push(e[0])
                    }
                    return [c, a]
                }
            }
        }

        function l(a) {
            return function() {
                return function(b) {
                    var c = a.exec(b);
                    return c != null ? [c, b.substr(c[0].length)] : void 0
                }
            }
        }

        function m() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return function() {
                return function(a) {
                    for (var c = 0; c < b.length; c++) {
                        var d = b[c];
                        d = d()(a);
                        if (d != null) return d
                    }
                }
            }
        }

        function n(a) {
            return function() {
                return function(b) {
                    var c = a()(b);
                    return c != null ? c : [void 0, b]
                }
            }
        }

        function o(a) {
            return function() {
                return function(b) {
                    var c = a()(b),
                        d = [];
                    b = b;
                    while (c != null) b = c[1], d.push(c[0]), c = a()(b);
                    return [d, b]
                }
            }
        }
        b = l(/^[\n\r\s]*/);
        var p = f(l(/^\"((?:[^\"\\]|\\.)*)\"/), function(a) {
                a = a[1];
                return g(a)
            }),
            q = f(l(/^-?\d+(?:(?:\.\d+)?[eE][-\+]?\d+|\.\d+)/), function(a) {
                a = a[0];
                return Number(a)
            });
        l = f(l(/^-?\d+/), function(a) {
            a = a[0];
            return (h || (h = d("I64"))).of_string(a)
        });
        var r = f(i("null"), function(a) {
                return null
            }),
            s = f(i("true"), function(a) {
                return !0
            }),
            t = f(i("false"), function(a) {
                return !1
            }),
            u = f(k(b, p, b, i(":"), function() {
                return v()
            }), function(a) {
                var b = a[1];
                a = a[4];
                return [b, a]
            });
        u = f(k(u, o(k(b, i(","), u))), function(a) {
            var b = a[0];
            a = a[1];
            return [b].concat(a.map(function(a) {
                a = a[2];
                return a
            }))
        });
        u = f(k(i("{"), n(u), b, i("}")), function(a) {
            a = a[1];
            a = a === void 0 ? [] : a;
            return e ? new(c("LSDict"))(a) : Object.fromEntries(a)
        });
        o = f(k(function() {
            return v()
        }, o(k(b, i(","), function() {
            return v()
        }))), function(a) {
            var b = a[0];
            a = a[1];
            return [b].concat(a.map(function(a) {
                a = a[2];
                return a
            }))
        });
        n = f(k(i("["), b, n(o), b, i("]")), function(a) {
            a = a[2];
            a = a === void 0 ? [] : a;
            return e ? c("LSVec").ofArray(a) : a
        });
        var v = f(k(b, m(u, p, q, l, n, r, s, t), b), function(a) {
            a = a[1];
            return a
        });
        o = v()(a);
        if (o == null) throw c("unrecoverableViolation")("error parsing string", "messenger_web_product");
        if (o[1] !== "") throw c("unrecoverableViolation")("unexpected " + o[1], "messenger_web_product");
        return o[0]
    }

    function k(a, b, e) {
        b === void 0 && (b = 0);
        e === void 0 && (e = "");
        if (b > i) throw c("unrecoverableViolation")("recursion limit exceeded", "messenger_comet");
        if (typeof a === "string" || typeof a === "number") return JSON.stringify(a);
        else if (typeof a === "boolean") return a ? "1" : "0";
        else if (a == null) return "null";
        else if (typeof a === "object")
            if (Array.isArray(a)) {
                if (a.tag === "ls-array") return "[" + a.map(function(a, c) {
                    return k(a, b + 1, e + "/" + c.toString())
                }).join(",") + "]";
                a._tag !== "i64" && c("FBLogger")("messenger_web_product").warn("LSJson payload contains untagged i64: %s", e);
                return (h || (h = d("I64"))).to_string(a)
            } else if (a instanceof c("LSDict")) return "{" + Array.from(a.entries()).map(function(a) {
            var d = a[0];
            a = a[1];
            if (typeof d === "string") return JSON.stringify(d) + ":" + k(a, b + 1, e + "/" + d);
            else throw c("unrecoverableViolation")("key must be a string", "messenger_comet")
        }).join(",") + "}";
        throw c("unrecoverableViolation")("type not supported: " + (a === null ? "null" : typeof a) + ", path: " + e, "messenger_comet")
    }
    g.parse = a;
    g.stringify = k
}), 98);
__d("LSDeserializeFromJsonIntoDictionaryV2.nop", ["LSDict", "LSJson", "Promise", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a, e, f) {
        a = d("LSJson").parse(f, {
            useLSTypes: !0
        });
        if (a instanceof c("LSDict")) return (h || (h = b("Promise"))).resolve([a]);
        throw c("unrecoverableViolation")("unexpected Dictionary type", "messenger_web_product")
    };
    g["default"] = a
}), 98);
__d("LSEncryptedBackupsStatusTriggerUpsert", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(a) {
            return b.sequence([function(a) {
                return b.forEach(b.filter(b.db.table(195).fetch(), function(a) {
                    return !0
                }), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return b.db.table(195).add({
                    pk: void 0
                })
            }])
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsEncryptedBackupsStatusTriggerUpsertStoredProcedure";
    e.exports = a
}), null);
__d("LSGetViewerFBID", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(a) {
            return b.sequence([function(a) {
                return b.db.table(4).fetch([
                    [
                        [b.i64.cast([0, 1])]
                    ]
                ]).next().then(function(a, d) {
                    var e = a.done;
                    a = a.value;
                    return e ? c[0] = b.i64.cast([-1, 4294967295]) : (d = a.item, c[0] = d.facebookUserId)
                })
            }, function(a) {
                return d[0] = c[0]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSCoreGetViewerFBIDStoredProcedure";
    e.exports = a
}), null);
__d("LSEpdCookieSettingsUpsert", ["LSGetViewerFBID"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(a) {
                return c.storedProcedure(b("LSGetViewerFBID")).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(b) {
                return c.db.table(163).put({
                    fbTrackersOnOtherCompanies: a[0],
                    otherCompanyTrackersOnFoa: a[1]
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsEpdCookieSettingsUpsertStoredProcedure";
    e.exports = a
}), null);
__d("LSResult", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return [a]
    }
    f["default"] = a
}), 66);
__d("LSGetBlobFromString.nop", ["CryptoLogger", "LSResult", "Promise", "XPlatReactTextEncoder"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a, e, f) {
        a = new(d("XPlatReactTextEncoder").TextEncoder)();
        try {
            e = a.encode(f).buffer;
            return (h || (h = b("Promise"))).resolve(c("LSResult")(e))
        } catch (g) {
            e = d("CryptoLogger").CryptoLogger("get_blob_from_string");
            e.catching(g).mustfix(g.message ? g.message : "Error in get blob from string.");
            e = a.encode(f).buffer;
            return (h || (h = b("Promise"))).resolve(c("LSResult")(e))
        }
    };
    g["default"] = a
}), 98);
__d("LSGetIfViewerIsWorkplaceUser", ["gkx"], (function(a, b, c, d, e, f, g) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            d = [];
        return d[0] = c("gkx")("26374"), b.resolve(d)
    }
    a.__sproc_name__ = "LSCoreGetIfViewerIsWorkplaceUserStoredProcedure";
    b = a;
    g["default"] = b
}), 98);
__d("LSGetThreadParticipantDisplayName", ["LSGetIfViewerIsWorkplaceUser"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(f) {
            return c.sequence([function(a) {
                return c.storedProcedure(b("LSGetIfViewerIsWorkplaceUser")).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(b) {
                return d[0] ? c.sequence([function(b) {
                    return c.filter(c.db.table(7).fetch([
                        [
                            [a[1]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.id, a[1]) && c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1]))
                    }).next().then(function(a, b) {
                        var e = a.done;
                        a = a.value;
                        return e ? c.sequence([function(a) {
                            return c.localizeV2Async(c.i64.cast([0, 2352696798]), void 0).then(function(a) {
                                return d[4] = a
                            })
                        }, function(a) {
                            return d[2] = d[4]
                        }]) : (b = a.item, d[2] = b.name)
                    })
                }, function(a) {
                    return d[1] = d[2]
                }]) : c.sequence([function(b) {
                    return c.filter(c.db.table(14).fetch([
                        [
                            [a[0], a[1]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.threadKey, a[0]) && c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 0])) && c.i64.eq(b.contactId, a[1])
                    }).next().then(function(a, b) {
                        var c = a.done;
                        a = a.value;
                        return c ? d[2] = void 0 : (b = a.item, d[2] = b.nickname)
                    })
                }, function(b) {
                    return c.filter(c.db.table(7).fetch([
                        [
                            [a[1]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.id, a[1]) && c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1]))
                    }).next().then(function(a, b) {
                        var e = a.done;
                        a = a.value;
                        return e ? c.sequence([function(a) {
                            return d[6] = c.i64.cast([-1, 4294967295]), c.localizeV2Async(c.i64.cast([0, 14617150]), void 0).then(function(a) {
                                return d[7] = a
                            })
                        }, function(a) {
                            return d[4] = d[7]
                        }]) : (b = a.item, d[4] = b.firstName == null ? b.name : b.firstName)
                    })
                }, function(a) {
                    return d[1] = d[2] == null ? d[4] : d[2]
                }])
            }, function(a) {
                return e[0] = d[1]
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxGetThreadParticipantDisplayNameStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueNewFireAndForgetTask", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return c[0] = b.i64.of_float(Date.now()), b.db.table(5).add({
                taskId: void 0,
                queueName: a[0],
                context: b.i64.to_string(a[1]),
                taskValue: a[2],
                enqueueTimestampMs: c[0]
            })
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSCoreIssueNewFireAndForgetTaskStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueNewTask", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return b.sequence([function(d) {
                return c[0] = b.i64.cast([0, 0]), c[1] = b.i64.of_float(Date.now()), b.db.table(2).add({
                    taskId: void 0,
                    queueName: a[0],
                    context: b.i64.to_string(a[1]),
                    taskValue: a[2],
                    enqueueTimestampMs: c[1],
                    httpUrlOverride: a[3],
                    timeoutTimestampMs: a[4],
                    pluginType: a[5],
                    priority: a[6],
                    syncGroupId: a[7],
                    transportKey: a[8],
                    minTimeToSyncTimestampMs: a[9],
                    taskDispatchPriority: c[0]
                })
            }, function(d) {
                return b.filter(b.db.table(2).fetchDesc([
                    [
                        [a[0]]
                    ], "queueNameTaskId"
                ]), function(c) {
                    return c.queueName === a[0] && c.context === b.i64.to_string(a[1]) && c.taskValue === a[2]
                }).next().then(function(a, d) {
                    var e = a.done;
                    a = a.value;
                    return e ? c[2] = b.i64.cast([-1, 4294967295]) : (d = a.item, c[2] = d.taskId)
                })
            }, function(a) {
                return function(a) {
                    b.logger(a).info(a)
                }(["LightSpeed NewTask", " ", b.i64.to_string(c[2])].join(""))
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSCoreIssueNewTaskStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueNewTaskAndGetTaskID", ["LSIssueNewTask", "LSLogEventAnnotate.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(f) {
            return c.sequence([function(d) {
                return c.storedProcedure(b("LSIssueNewTask"), a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10])
            }, function(b) {
                return d[3] = c.i64.to_string(a[1]), c.filter(c.db.table(2).fetchDesc([
                    [
                        [a[0]]
                    ], "queueNameTaskId"
                ]), function(b) {
                    return b.queueName === a[0] && b.context === d[3] && b.taskValue === a[2]
                }).next().then(function(a, b) {
                    var e = a.done;
                    a = a.value;
                    return e ? d[0] = c.i64.cast([-1, 4294967295]) : (b = a.item, d[0] = b.taskId)
                })
            }, function(e) {
                return d[2] = new c.Map(), d[2].set("task_id", d[0]), d[2].set("task_queue_name", a[0]), d[2].set("task_label", d[3]), c.nativeOperation(b("LSLogEventAnnotate.nop"), c.i64.cast([0, 16]), c.i64.cast([0, 23]), c.i64.cast([0, 0]), d[2])
            }, function(a) {
                return e[0] = d[0]
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSCoreIssueNewTaskAndGetTaskIDStoredProcedure";
    e.exports = a
}), null);
__d("LSShape", ["LSDict"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("LSDict").fromObject(a)
    }

    function b(a) {
        return c("LSDict").shapeToRecord(a)
    }
    g.ofRecord = a;
    g.toRecord = b
}), 98);
__d("LSVerifyContactRowExists", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.filter(c.db.table(7).fetch([
                [
                    [a[0]]
                ]
            ]), function(b) {
                return c.i64.eq(b.id, a[0]) && c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1]))
            }).next().then(function(e) {
                var f = e.done;
                e.value;
                return f ? c.sequence([function(b) {
                    return d[0] = a[3] == null ? "" : a[3], c.forEach(c.filter(c.db.table(7).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.id, a[0]) && c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1])) && c.i64.lt(b.authorityLevel, a[14])
                    }), function(a) {
                        return a["delete"]()
                    })
                }, function(b) {
                    return c.db.table(7).add({
                        id: a[0],
                        profilePictureUrl: a[2] == null ? "" : a[2],
                        profilePictureFallbackUrl: a[5],
                        name: d[0],
                        secondaryName: a[20],
                        normalizedNameForSearch: d[0],
                        isMemorialized: a[9],
                        blockedByViewerStatus: a[11],
                        canViewerMessage: a[12],
                        profilePictureLargeUrl: "",
                        isMessengerUser: !0,
                        rank: 0,
                        contactType: a[4],
                        contactTypeExact: c.i64.cast([0, 0]),
                        requiresMultiway: !1,
                        authorityLevel: a[14],
                        workForeignEntityType: c.i64.cast([0, 0]),
                        capabilities: a[15],
                        capabilities2: a[16],
                        contactViewerRelationship: a[19],
                        gender: a[18],
                        firstName: a[21]
                    })
                }, function(e) {
                    return d[1] = new c.Map(), d[1].set("contact_id", a[0]), d[2] = c.toJSON(d[1]), c.storedProcedure(b("LSIssueNewTask"), "cpq_v2", c.i64.cast([0, 207]), d[2], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
                }]) : 0
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSContactVerifyContactRowExistsStoredProcedure";
    e.exports = a
}), null);
__d("XPlatReactCrypto", ["err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h = self.crypto) == null ? void 0 : h.subtle;

    function a(a) {
        var b;
        if (typeof((b = self.crypto) == null ? void 0 : b.getRandomValues) !== "function") throw c("err")("crypto.getRandomValues: Not implemented");
        self.crypto.getRandomValues(a);
        return a
    }

    function b() {
        var a;
        if (typeof((a = self.crypto) == null ? void 0 : a.randomUUID) !== "function") return null;
        a = self.crypto.randomUUID();
        return typeof a === "string" ? a : null
    }

    function d(a, b, d, e, f) {
        if (i == null) throw c("err")("crypto.subtle.importKey: Not implemented");
        return i.importKey(a, b, d, e, f)
    }

    function e(a, b) {
        if (i == null) throw c("err")("crypto.subtle.exportKey: Not implemented");
        return i.exportKey(a, b)
    }

    function f(a, b, d) {
        if (i == null) throw c("err")("crypto.subtle.generateKey: Not implemented");
        return i.generateKey(a, b, d)
    }

    function j(a, b, d) {
        if (i == null) throw c("err")("crypto.subtle.encrypt: Not implemented");
        return i.encrypt(a, b, d)
    }

    function k(a, b, d) {
        if (i == null) throw c("err")("crypto.subtle.decrypt: Not implemented");
        return i.decrypt(a, b, d)
    }

    function l(a, b, d) {
        if (i == null) throw c("err")("crypto.subtle.sign: Not implemented");
        return i.sign(a, b, d)
    }

    function m(a, b) {
        if (i == null) throw c("err")("crypto.subtle.digest: Not implemented");
        return i.digest(a, b)
    }

    function n(a, b, d) {
        if (i == null) throw c("err")("crypto.subtle.deriveBits: Not implemented");
        return i.deriveBits(a, b, d)
    }

    function o(a, b, d, e, f) {
        if (i == null) throw c("err")("crypto.subtle.deriveKey: Not implemented");
        return i.deriveKey(a, b, d, e, f)
    }
    g.getRandomValues = a;
    g.randomUUID = b;
    g.subtleImportKey = d;
    g.subtleExportKey = e;
    g.subtleGenerateKey = f;
    g.subtleEncrypt = j;
    g.subtleDecrypt = k;
    g.subtleSign = l;
    g.subtleDigest = m;
    g.subtleDeriveBits = n;
    g.subtleDeriveKey = o
}), 98); /*FB_PKG_DELIM*/
__d("IGDRouteProvider.react", ["I64", "react", "useCurrentRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react"));
    e = h;
    var k = e.createContext,
        l = e.useContext;

    function m(a) {
        try {
            return (i || (i = d("I64"))).of_string(a)
        } catch (a) {
            return
        }
    }

    function n(a) {
        if (a == null) return;
        a = a.params.thread_key;
        if (a != null && typeof a === "string") return m(a)
    }
    var o = k();

    function a(a) {
        a = a.children;
        var b = c("useCurrentRoute")();
        b = n(b);
        return j.jsx(o.Provider, {
            value: b,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return l(o)
    }
    g.IGDRouteContextProvider = a;
    g.useThreadKeyFromCurrentRoute = b
}), 98);
__d("IGDInteractionTraceAnnotations", ["I64", "IGDInstamadilloUtils", "IGDRouteProvider.react", "IGDThreadTTLCUtils", "Int64Hooks", "InteractionTracing", "LSIntEnum", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = (h || d("react")).useEffect;

    function a(a) {
        return babelHelpers["extends"]({}, d("IGDThreadTTLCUtils").getTTLCBooleanAnnotations(a), {
            is_dm: d("IGDInstamadilloUtils").isIGDDisappearingModeEnabled(a),
            is_instamadillo: d("IGDInstamadilloUtils").isInstamadilloTransportEnabled(a),
            is_instamadillo_tlc: d("IGDInstamadilloUtils").isInstamadilloCutover(a)
        })
    }

    function l(a, b) {
        var c = d("IGDInstamadilloUtils").isInstamadilloCutover(a),
            e = d("IGDInstamadilloUtils").isInstamadilloTransportEnabled(a),
            f = d("IGDInstamadilloUtils").isIGDDisappearingModeEnabled(a);
        b.addAnnotationBoolean("is_instamadillo", e);
        b.addAnnotationBoolean("is_instamadillo_tlc", c);
        b.addAnnotationBoolean("is_dm", f);
        b.addAnnotationBoolean("is_instamadillo_ttlc", (e = d("IGDThreadTTLCUtils")).isIGDTTLCEnabledForThread(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_audio", e.isInstamadilloTTLCAudioEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_clip", e.isInstamadilloTTLCClipEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_generic_xma", e.isInstamadilloTTLCGenericXmaEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_image", e.isInstamadilloTTLCImageEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_link", e.isInstamadilloTTLCLinkEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_media_share", e.isInstamadilloTTLCMediaShareEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_profile", e.isInstamadilloTTLCProfileEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_reel_share", e.isInstamadilloTTLCReelShareEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_story_share", e.isInstamadilloTTLCStoryShareEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_text", e.isInstamadilloTTLCTextEnabled(a));
        b.addAnnotationBoolean("is_instamadillo_ttlc_video", e.isInstamadilloTTLCVideoEnabled(a))
    }

    function b(a) {
        d("Int64Hooks").useEffectInt64(function() {
            c("InteractionTracing").getPendingInteractions().forEach(function(b) {
                l(a, b)
            })
        }, [a])
    }
    var m = new Set();

    function e(a) {
        d("Int64Hooks").useEffectInt64(function() {
            var b = (i || (i = d("I64"))).to_string(a.threadKey);
            c("InteractionTracing").getPendingInteractions().forEach(function(c) {
                var e = m.has(b);
                c.addAnnotationBoolean("is_thread_visited", e);
                c.addAnnotation("thread_key", (i || (i = d("I64"))).to_string(a.threadKey));
                a.consistentThreadFbid != null && c.addAnnotation("consistent_thread_fbid", (i || (i = d("I64"))).to_string(a.consistentThreadFbid));
                c.addAnnotationInt("thread_type", (j || (j = d("LSIntEnum"))).toNumber(a.threadType));
                a.threadSubtype != null && c.addAnnotation("thread_subtype", (i || (i = d("I64"))).to_string(a.threadSubtype))
            });
            return function() {
                m.add(b)
            }
        }, [a])
    }

    function f() {
        var a = d("IGDRouteProvider.react").useThreadKeyFromCurrentRoute(),
            b = a != null ? (i || (i = d("I64"))).to_string(a) : null;
        k(function() {
            c("InteractionTracing").getPendingInteractions().forEach(function(a) {
                if (b == null) {
                    a.addAnnotationInt("rendered_direct_null_state", 1);
                    a.addAnnotationInt("has_thread_key", 0);
                    return
                }
                a.addAnnotationInt("has_thread_key", 1);
                a.addAnnotationInt("rendered_direct_null_state", 0)
            })
        }, [b])
    }
    g.getInstamadilloBooleanAnnotations = a;
    g.addInstamadilloAnnotationsToInteractionTrace = l;
    g.useAddInstamadilloAnnotationsToInteractionTraces = b;
    g.useAddThreadAnnotationToInteractionTraces = e;
    g.useAddThreadRouteAnnotations = f
}), 98);
__d("MWGetOriginalEntrypoint", ["I64", "InteractionTracingMetrics", "MWChatInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var b, e = d("MWChatInteraction").get((h || (h = d("I64"))).to_string(a));
        e = e != null ? c("InteractionTracingMetrics").get(e) : null;
        e = (b = e == null ? void 0 : (b = e.annotations.string) == null ? void 0 : b.inboxEntrypoint) != null ? b : e == null ? void 0 : (b = e.annotations.string) == null ? void 0 : b.entrypoint;
        if (e != null && e !== "unknown") return e;
        b = d("MWChatInteraction").get("inbox_init");
        if (b != null && (h || (h = d("I64"))).equal(a, (h || (h = d("I64"))).of_string(b))) return "initInbox";
        e = d("MWChatInteraction").get(d("MWChatInteraction").MW_AUTO_CHAT_TAB_OPEN);
        b = e != null ? (b = c("InteractionTracingMetrics").get(e)) == null ? void 0 : (e = b.annotations.string) == null ? void 0 : e.thread_id : null;
        return b === (h || (h = d("I64"))).to_string(a) ? "auto_open" : "unknown"
    }
    g["default"] = a
}), 98);
__d("MWHasLinksUtil", ["URLMatcher", "isStringNullOrEmpty"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("isStringNullOrEmpty")(a) ? !1 : c("URLMatcher").match(a) != null
    }
    g.getHasLinks = a
}), 98);
__d("MWMsgMediaTypeLogUtils", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("$InternalEnum")({
        Application: "application",
        Audio: "audio",
        Avatar: "avatar",
        HotEmoji: "hot_emoji",
        File: "file",
        Gif: "gif",
        Image: "image",
        Link: "link",
        None: "none",
        Poll: "poll",
        Reaction: "reaction",
        Sticker: "sticker",
        Video: "video",
        Share: "share"
    });

    function a(a) {
        var b = a.hasFile;
        b = b === void 0 ? !1 : b;
        var c = a.hasGif;
        c = c === void 0 ? !1 : c;
        var d = a.hasHotEmoji;
        d = d === void 0 ? !1 : d;
        var e = a.hasImage;
        e = e === void 0 ? !1 : e;
        var f = a.hasLinks;
        f = f === void 0 ? !1 : f;
        var h = a.hasShare;
        h = h === void 0 ? !1 : h;
        var i = a.hasSticker;
        i = i === void 0 ? !1 : i;
        var j = a.hasVideo;
        j = j === void 0 ? !1 : j;
        a = a.hasVoiceClip;
        a = a === void 0 ? !1 : a;
        var k = g.None;
        e ? k = g.Image : j ? k = g.Video : d ? k = g.HotEmoji : i ? k = g.Sticker : c ? k = g.Gif : a ? k = g.Audio : f ? k = g.Link : b ? k = g.File : h && (k = g.Share);
        return k
    }
    f.AttachmentType = g;
    f.getAttachmentType = a
}), 66);
__d("MWVersion", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("I64")).of_string("2");
    g.v2 = a
}), 98);
__d("MWSharedMsgLogUtils", ["$InternalEnum", "I64", "IGDInteractionTraceAnnotations", "LSIntEnum", "LSMessagingThreadAttributionType", "LSMessagingThreadTypeUtil", "MAWEBSwitch", "MWGetOriginalEntrypoint", "MWHasLinksUtil", "MWMsgMediaTypeLogUtils", "MWVersion", "MultipleTabsLogger", "asyncToGeneratorRuntime", "cr:6985", "gkx", "isArmadillo", "isStringNullOrEmpty", "promiseDone", "shouldUseMAWSharedWorker"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = b("$InternalEnum")({
            Send: "send",
            Reaction: "reaction",
            Reply: "reply",
            Forward: "forward",
            Share: "share",
            StoryReply: "story-reply",
            Unsend: "unsend",
            GroupInvite: "group-invite",
            SenderKeyDistribution: "sender-key-distribution",
            EphemeralSetting: "ephemeral-setting"
        }),
        k = b("$InternalEnum")({
            Text: "text",
            NonText: "non-text"
        });

    function l(a, b, c) {
        return m.apply(this, arguments)
    }

    function m() {
        m = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e) {
            var f = a.hasAttachment,
                g = a.hasEphemeralSetting,
                i = a.hasGroupInvite,
                l = a.hasReaction,
                m = a.hasReply,
                n = a.hasSenderKeyDistribution,
                p = a.hasStoryReply,
                q = a.hasText,
                r = a.isUnsend;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["hasAttachment", "hasEphemeralSetting", "hasGroupInvite", "hasReaction", "hasReply", "hasSenderKeyDistribution", "hasStoryReply", "hasText", "isUnsend"]);
            var s = j.Send;
            m ? s = j.Reply : p ? s = j.StoryReply : r ? s = j.Unsend : l ? s = j.Reaction : i ? s = j.GroupInvite : g ? s = j.EphemeralSetting : n && (s = j.SenderKeyDistribution);
            m = d("MWMsgMediaTypeLogUtils").getAttachmentType(a);
            p = q && (!m || m === d("MWMsgMediaTypeLogUtils").AttachmentType.None) ? k.Text : k.NonText;
            return {
                bool: {
                    has_attachment: f,
                    has_sticker: a.hasSticker,
                    is_attachments_grouped: a.isAttachmentsGrouped,
                    is_eb_enabled: c("MAWEBSwitch").isEnabled(),
                    is_pdb: Boolean(c("gkx")("24032")),
                    is_tlc_public_user: c("gkx")("24028"),
                    use_maw_shared_worker: d("shouldUseMAWSharedWorker").shouldUseMAWSharedWorker()
                },
                "int": {
                    number_of_attachments: a.numberOfAttachments,
                    number_of_grouped_attachments: a.numberOfGroupedAttachments
                },
                string: {
                    action_type: s,
                    attachment_type: m,
                    entrypoint: o(b),
                    message_type: p,
                    multipleTabs: yield d("MultipleTabsLogger").getMultipleTabsAnnotation(), mw_version: (h || (h = d("I64"))).to_string(d("MWVersion").v2), root_component: e
                }
            }
        });
        return m.apply(this, arguments)
    }

    function a(a, b, c, d) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f, g) {
            var i = b("cr:6985") != null ? yield b("cr:6985").isCutoverThreadKey(a.threadKey): !1;
            e = (yield l(e, f, g));
            return {
                bool: babelHelpers["extends"]({}, e.bool, d("IGDInteractionTraceAnnotations").getInstamadilloBooleanAnnotations(a), {
                    is_community_event: a.eventStartTimestampMs != null,
                    is_cutover: c("isArmadillo")() && i,
                    is_message_request: d("LSMessagingThreadTypeUtil").isMessageRequest(a),
                    is_secure: d("LSMessagingThreadTypeUtil").isArmadilloSecure(a.threadType)
                }),
                "int": babelHelpers["extends"]({}, e["int"]),
                string: babelHelpers["extends"]({}, e.string, {
                    consistent_thread_fbid: a.consistentThreadFbid != null ? (h || (h = d("I64"))).to_string(a.consistentThreadFbid) : null,
                    original_entrypoint: c("MWGetOriginalEntrypoint")(a.threadKey),
                    thread_id: (h || (h = d("I64"))).to_string(a.threadKey),
                    thread_subtype: a.threadSubtype != null ? (h || (h = d("I64"))).to_string(a.threadSubtype) : null,
                    thread_type: h.to_string(a.threadType)
                })
            }
        });
        return n.apply(this, arguments)
    }

    function e(a, e, f, g) {
        var i = e.hasFile;
        i = i === void 0 ? !1 : i;
        var l = e.hasGif;
        l = l === void 0 ? !1 : l;
        var m = e.hasHotEmoji;
        m = m === void 0 ? !1 : m;
        var n = e.hasImage;
        n = n === void 0 ? !1 : n;
        var o = e.hasLinks;
        o = o === void 0 ? !1 : o;
        var p = e.hasReply;
        p = p === void 0 ? !1 : p;
        var q = e.hasShare;
        q = q === void 0 ? !1 : q;
        var r = e.hasSticker;
        r = r === void 0 ? !1 : r;
        var s = e.hasStoryReply;
        s = s === void 0 ? !1 : s;
        var t = e.hasText;
        t = t === void 0 ? !1 : t;
        var u = e.hasVideo;
        u = u === void 0 ? !1 : u;
        var v = e.hasVoiceClip;
        v = v === void 0 ? !1 : v;
        var w = e.isAttachmentsGrouped,
            x = e.numberOfAttachments;
        x = x === void 0 ? 0 : x;
        e = e.numberOfGroupedAttachments;
        e = e === void 0 ? 0 : e;
        var y = j.Send;
        p ? y = j.Reply : s && (y = j.StoryReply);
        p = d("MWMsgMediaTypeLogUtils").getAttachmentType({
            hasFile: i,
            hasGif: l,
            hasHotEmoji: m,
            hasImage: n,
            hasLinks: o,
            hasShare: q,
            hasSticker: r,
            hasVideo: u,
            hasVoiceClip: v,
            numberOfAttachments: x,
            numberOfGroupedAttachments: e
        });
        s = t && (!p || p === d("MWMsgMediaTypeLogUtils").AttachmentType.None) ? k.Text : k.NonText;
        d("MultipleTabsLogger").addAnnotationWithInteractionUuid(a.getTraceId());
        a.addAnnotation("attachment_type", p);
        a.addAnnotation("action_type", y);
        a.addAnnotation("message_type", s);
        a.addAnnotation("original_entrypoint", c("MWGetOriginalEntrypoint")(f.threadKey));
        g != null && a.addAnnotation("root_component", g);
        a.addAnnotationInt("number_of_attachments", x);
        w != null && a.addAnnotationBoolean("is_attachments_grouped", w);
        a.addAnnotation("thread_id", (h || (h = d("I64"))).to_string(f.threadKey));
        f.consistentThreadFbid != null && a.addAnnotation("consistent_thread_fbid", (h || (h = d("I64"))).to_string(f.consistentThreadFbid));
        a.addAnnotation("thread_type", h.to_string(f.threadType));
        f.threadSubtype != null && a.addAnnotation("thread_subtype", (h || (h = d("I64"))).to_string(f.threadSubtype));
        b("cr:6985") != null && c("promiseDone")(b("cr:6985").isCutoverThreadKey(f.threadKey), function(b) {
            a.addAnnotationBoolean("is_cutover", b)
        });
        d("IGDInteractionTraceAnnotations").addInstamadilloAnnotationsToInteractionTrace(f, a);
        a.addAnnotationBoolean("is_secure", d("LSMessagingThreadTypeUtil").isArmadilloSecure(f.threadType));
        a.addAnnotationBoolean("is_eb_enabled", c("MAWEBSwitch").isEnabled());
        a.addAnnotationBoolean("use_maw_shared_worker", d("shouldUseMAWSharedWorker").shouldUseMAWSharedWorker());
        a.addAnnotationBoolean("is_pdb", Boolean(c("gkx")("24032")))
    }

    function f(a) {
        var b = a.externalAttachmentUrl,
            e = a.hotEmojiSize,
            f = a.isEphemeralSetting,
            g = a.isGroupInvite,
            h = a.isReaction,
            i = a.isSenderKeyDistribution,
            j = a.isUnsend,
            k = a.mediaGroupInfo,
            l = a.mediaStagings,
            m = a.messageText,
            n = a.reply,
            o = a.sentFromShareSheet,
            p = a.stickerId,
            q = a.threadType;
        a = a.voiceClip;
        var r = !c("isStringNullOrEmpty")(m);
        m = d("MWHasLinksUtil").getHasLinks(m);
        var s = !1;
        a = a != null;
        a ? s = !0 : b != null && (s = !0);
        var t = !1,
            u = !1,
            v = !1,
            w = 0,
            x = 0,
            y;
        if (l != null && l.length > 0) {
            s = !0;
            for (var z of l) {
                var A = z.mimeType;
                A.indexOf("image") !== -1 && (t = !0);
                A.indexOf("video") !== -1 && (u = !0);
                A.indexOf("application") !== -1 && (v = !0)
            }
            if (t && q != null) {
                A = d("LSMessagingThreadTypeUtil").isArmadilloSecure(q);
                y = !A || c("gkx")("5318") === !0
            }
            w = l.length
        }
        k != null && (y = !0, x = k.messagesAndAttachments.length);
        z = e != null;
        q = n != null;
        A = n != null;
        l = p != null && !z;
        k = !l && b != null;
        e = o === !0;
        n = h === !0;
        p = g === !0;
        b = f === !0;
        o = i === !0;
        return {
            hasAttachment: s,
            hasEphemeralSetting: b,
            hasFile: v,
            hasGif: k,
            hasGroupInvite: p,
            hasHotEmoji: z,
            hasImage: t,
            hasLinks: m,
            hasReaction: n,
            hasReply: q,
            hasSenderKeyDistribution: o,
            hasShare: e,
            hasSticker: l,
            hasStoryReply: A,
            hasText: r,
            hasVideo: u,
            hasVoiceClip: a,
            isAttachmentsGrouped: y,
            isUnsend: (h = j) != null ? h : !1,
            numberOfAttachments: w,
            numberOfGroupedAttachments: x
        }
    }

    function o(a) {
        var b;
        return (b = Object.keys(c("LSMessagingThreadAttributionType")).find(function(b) {
            return c("LSMessagingThreadAttributionType")[b] === a
        })) != null ? b : "UNKNOWN"
    }

    function p(a) {
        if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(2))) return "media";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(4))) return "audio";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(4096)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(134217728))) return "sticker";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(16384))) return "gif";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(64))) return "file";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1))) return "text";
        else if ((h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1024)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(536870912))) return "XMA";
        else return "unknown"
    }
    g.ActionType = j;
    g.MsgType = k;
    g.getSendToSentBaseAnnotations = l;
    g.getSendToSentAnnotations = a;
    g.addSendMessageMetadataForInteractionTrace = e;
    g.getMessageTypeParams = f;
    g.getEntrypointAnnotation = o;
    g.getMessageTypeFromDisplayedContentType = p
}), 98);
__d("MessengerChevronLeftFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M21.884 8.866a1.25 1.25 0 0 1 0 1.768l-7.19 7.19a.25.25 0 0 0 0 .353l7.19 7.19a1.25 1.25 0 0 1-1.768 1.767l-8.25-8.25a1.25 1.25 0 0 1 0-1.768l8.25-8.25a1.25 1.25 0 0 1 1.768 0z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("MessengerChevronRightFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M14.116 27.134a1.25 1.25 0 0 1 0-1.768l7.19-7.19a.25.25 0 0 0 0-.353l-7.19-7.19a1.25 1.25 0 0 1 1.768-1.767l8.25 8.25a1.25 1.25 0 0 1 0 1.768l-8.25 8.25a1.25 1.25 0 0 1-1.768 0z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("CometInfiniteScrollTrigger.react", ["react", "stylex", "useAfterPaint", "useMergeRefs", "useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.startTransition,
        l = b.useCallback,
        m = b.useRef;

    function a(a) {
        var b = a.children,
            d = a.hasMore,
            e = a.isLoading,
            f = a.onLoadMore,
            g = a.root,
            i = a.rootMargin,
            n = a.scrollMargin;
        a = a.xstyle;
        var o = m(!1),
            p = m(null),
            q = l(function() {
                k(function() {
                    f(p)
                })
            }, [f, p]),
            r = l(function() {
                d && !e && o.current && q()
            }, [q, e, d]);
        c("useAfterPaint")(r);
        r = l(function() {
            var a = o.current;
            o.current = !0;
            !a && d && !e && q()
        }, [d, e, q]);
        var s = l(function() {
            o.current = !1
        }, []);
        g = c("useVisibilityObserver")({
            onHidden: s,
            onVisible: r,
            options: {
                root: g,
                rootMargin: (s = i) != null ? s : 0,
                scrollMargin: (r = n) != null ? r : 0
            }
        });
        i = c("useMergeRefs")(g, p);
        return d || e ? j.jsx("div", {
            className: (h || (h = c("stylex")))(a),
            ref: i,
            children: b
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MDSImageFromIXValue.react", ["CometImageFromIXValue.react", "mergeRefs", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useMemo,
        k = b.useRef;
    e = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = k(null),
            e = j(function() {
                return c("mergeRefs")(d, b)
            }, [d, b]),
            f = a.alt,
            g = a.src,
            h = a.testid;
        h = a.xstyle;
        return i.jsx(c("CometImageFromIXValue.react"), {
            alt: f,
            ref: e,
            source: g,
            testid: void 0,
            xstyle: h
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = e;
    g["default"] = d
}), 98);
__d("MDSLazyPopoverTrigger.react", ["BaseLazyPopoverTrigger.react", "MDSPopoverLoadingState.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.fallback,
            d = a.popoverResource,
            e = a.preloadTrigger;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback", "popoverResource", "preloadTrigger"]);
        return i.jsx(c("BaseLazyPopoverTrigger.react"), babelHelpers["extends"]({
            fallback: (b = b) != null ? b : i.jsx(c("MDSPopoverLoadingState.react"), {
                withArrow: !0
            }),
            popoverResource: d,
            preloadTrigger: e
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MDSListCell.react", ["BaseListCell.react", "Box.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            addOnEndContainer: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                flexShrink: "xs83m0k",
                justifyContent: "xl56j7k",
                minWidth: "x15kz4h8",
                $$css: !0
            },
            addOnStartContainer: {
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                flexShrink: "xs83m0k",
                $$css: !0
            }
        },
        k = {
            large: {
                paddingStart: "x1rcwl9y",
                $$css: !0
            },
            medium: {
                paddingTop: "xlufg6w",
                paddingBottom: "xf7dwv7",
                paddingStart: "x1tlcw85",
                $$css: !0
            }
        },
        l = {
            large: {
                paddingEnd: "xn45owk",
                $$css: !0
            },
            medium: {
                paddingTop: "xlufg6w",
                paddingBottom: "xf7dwv7",
                paddingEnd: "xnt01y7",
                $$css: !0
            }
        },
        m = {
            large: {
                $$css: !0
            },
            medium: {
                paddingTop: "x1es9f29",
                paddingBottom: "x1vu7fv8",
                $$css: !0
            }
        },
        n = {
            container: {
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                $$css: !0
            },
            large: {
                paddingTop: "x1es9f29",
                paddingEnd: "xn45owk",
                paddingBottom: "x1vu7fv8",
                paddingStart: "x1rcwl9y",
                $$css: !0
            },
            medium: {
                borderTopStartRadius: "xhk9q7s",
                borderTopEndRadius: "x1otrzb0",
                borderBottomEndRadius: "x1i1ezom",
                borderBottomStartRadius: "x1o6z2jb",
                paddingStart: "x1tlcw85",
                paddingEnd: "xnt01y7",
                paddingLeft: null,
                paddingRight: null,
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = a.addOnEnd,
            e = a.addOnEndVerticalAlign,
            f = a.addOnStart,
            g = a.addOnStartVerticalAlign,
            h = a.content,
            o = a.role,
            p = a.size,
            q = a.testid;
        q = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnEnd", "addOnEndVerticalAlign", "addOnStart", "addOnStartVerticalAlign", "content", "role", "size", "testid"]);
        return i.jsx(c("Box.react"), {
            xstyle: [n[p], n.container],
            children: i.jsx(c("BaseListCell.react"), babelHelpers["extends"]({
                addOnEnd: d != null ? i.jsx(c("Box.react"), {
                    xstyle: k[p],
                    children: i.jsx(c("Box.react"), {
                        xstyle: j.addOnEndContainer,
                        children: d
                    })
                }) : void 0,
                addOnEndVerticalAlign: e,
                addOnStart: f != null ? i.jsx(c("Box.react"), {
                    xstyle: [j.addOnStartContainer, l[p]],
                    children: f
                }) : void 0,
                addOnStartVerticalAlign: g,
                content: i.jsx(c("Box.react"), {
                    "data-testid": void 0,
                    xstyle: m[p],
                    children: h
                }),
                ref: b,
                role: o
            }, q))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("MDSListCellPressable.react", ["CometFocusGroupContext", "MDSListCell.react", "MDSPressable.react", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = c("gkx")("26349") ? {
            container: {
                display: "x78zum5",
                $$css: !0
            }
        } : {
            container: {
                display: "x1lliihq",
                $$css: !0
            }
        },
        l = {
            container: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                $$css: !0
            },
            pressableSelected: {
                backgroundColor: "x1ry3o7a",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = a.addOnEnd,
            e = a.addOnEndVerticalAlign,
            f = a.addOnStart,
            g = a.addOnStartVerticalAlign,
            h = a["aria-checked"],
            m = a["aria-controls"],
            n = a["aria-current"],
            o = a["aria-expanded"],
            p = a["aria-label"],
            q = a.content,
            r = a.contentTestId;
        r = a.contentXStyle;
        var s = a.disabled,
            t = a.focusable,
            u = a.id,
            v = a.linkProps;
        a.nestedSpacing;
        var w = a.onFocusChange,
            x = a.onHoverIn,
            y = a.onHoverOut,
            z = a.onPress,
            A = a.onPressIn,
            B = a.overlayDisabled,
            C = a.role,
            D = a.selected,
            E = a.size,
            F = a.testid;
        F = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnEnd", "addOnEndVerticalAlign", "addOnStart", "addOnStartVerticalAlign", "aria-checked", "aria-controls", "aria-current", "aria-expanded", "aria-label", "content", "contentTestId", "contentXStyle", "disabled", "focusable", "id", "linkProps", "nestedSpacing", "onFocusChange", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "overlayDisabled", "role", "selected", "size", "testid"]);
        a = j(c("CometFocusGroupContext"));
        a = a.FocusItem;
        a = (a = a) != null ? a : i.Fragment;
        return i.jsx(a, {
            children: i.jsx(c("MDSPressable.react"), {
                "aria-checked": h,
                "aria-controls": m,
                "aria-current": n,
                "aria-expanded": o,
                "aria-label": p,
                disabled: s,
                focusable: t,
                id: u,
                linkProps: v,
                onFocusChange: w,
                onHoverIn: x,
                onHoverOut: y,
                onPress: z,
                onPressIn: A,
                overlayDisabled: D === !0 || B,
                overlayRadius: "normal",
                ref: b,
                role: C,
                testid: void 0,
                xstyle: [r, D === !0 && l.pressableSelected, l.container, k.container],
                children: i.jsx(c("MDSListCell.react"), babelHelpers["extends"]({
                    addOnEnd: d,
                    addOnEndVerticalAlign: e,
                    addOnStart: f,
                    addOnStartVerticalAlign: g,
                    content: q,
                    role: C,
                    size: E,
                    testid: void 0
                }, F))
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("MWAddOnCircleContainer.react", ["react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            container: {
                alignItems: "x6s0dn4",
                backgroundColor: "x1qhmfi1",
                borderTopStartRadius: "xzolkzo",
                borderTopEndRadius: "x12go9s9",
                borderBottomEndRadius: "x1rnf11y",
                borderBottomStartRadius: "xprq8jg",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                $$css: !0
            },
            disabled: {
                backgroundColor: "x1281ex9",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.children,
            c = a.disabled;
        c = c === void 0 ? !1 : c;
        a = a.size;
        return i.jsx(d("react-strict-dom").html.div, {
            style: [j.container, c && j.disabled, [{
                height: a,
                width: a
            }]],
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEBUpsellDismissedEnum.facebook", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        NOT_DISMISSED: 0,
        UPSELLS_DISMISSED: 1,
        ALL_DISMISSED: 2
    });
    f.MWEBUpsellDismissedStateEnum = a
}), 66);
__d("MWVerticalRhythm", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        a = a.height;
        a = a;
        return i.jsx("div", {
            style: {
                height: String(a) + "px"
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXImage.react", ["cr:1261", "cr:2838", "cr:6682", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var c = a.objectFit,
            d = a.src;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["objectFit", "src"]);
        if (b("cr:6682") != null) return i.jsx(b("cr:6682"), babelHelpers["extends"]({
            objectFit: c,
            src: d
        }, a));
        if (typeof d === "string") return b("cr:2838") != null ? i.jsx(b("cr:2838"), babelHelpers["extends"]({
            src: d
        }, a)) : null;
        else return b("cr:1261") != null ? i.jsx(b("cr:1261"), babelHelpers["extends"]({
            src: d
        }, a)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXListCellPressable.react", ["MessengerWebUXLogger", "cr:321", "cr:8697", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useCallback;
    e = i.forwardRef(a);

    function a(a, d) {
        a = babelHelpers["extends"]({}, a);
        var e = a.addOnBottom,
            f = a.addOnEnd,
            g = a.addOnStart,
            h = a.content,
            k = a.loggingEvent,
            l = a.onPress,
            m = a.size;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnBottom", "addOnEnd", "addOnStart", "content", "loggingEvent", "onPress", "size"]);
        var n = c("MessengerWebUXLogger").useInteractionLogger(),
            o = j(function(a) {
                l == null ? void 0 : l(a), k && (n == null ? void 0 : n(k))
            }, [n, k, l]);
        if (b("cr:8697") != null) return i.jsx(b("cr:8697"), babelHelpers["extends"]({
            addOnBottom: e,
            addOnEnd: f,
            addOnStart: g,
            addOnStartMarginTop: 0,
            content: h,
            onPress: o,
            overlayRadius: 8,
            paddingVertical: 8,
            verticalAlign: "center"
        }, a, {
            ref: d
        }));
        if (b("cr:321") != null) {
            return i.jsx(b("cr:321"), babelHelpers["extends"]({
                addOnBottom: e,
                addOnEnd: f,
                addOnStart: g,
                content: h,
                onPress: o,
                size: (e = m) != null ? e : "medium"
            }, a, {
                ref: d
            }))
        }
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = e;
    g["default"] = d
}), 98);
__d("MWXProfilePhoto.react", ["CometProfilePhoto.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        return i.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("MessengerWebUXEventType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        BACKEND: "backend",
        IMPRESSION: "impression",
        INTERACTION: "interaction"
    });
    f["default"] = a
}), 66);
__d("MessengerWebUxEventFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("4662");
    b = d("FalcoLoggerInternal").create("messenger_web_ux_event", a);
    e = b;
    g["default"] = e
}), 98);
__d("WebUXLoggingEntryPointContextProvider", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h.createContext;
    var j = b("unknown");

    function a(a) {
        var b = a.children;
        a = a.value;
        return i.jsx(j.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.WebUXEntryPointLoggingContext = j;
    g.WebUXLoggingEntryPointContextProvider = a
}), 98);
__d("MessengerWebUXLoggerImpl", ["CurrentUser", "I64", "LSIntEnum", "MWThreadKey.react", "MessagingThreadType", "MessengerWebUxEventFalcoEvent", "ODS", "WebUXLoggingEntryPointContextProvider", "WebUXLoggingSurfaceContextProvider", "cr:6873", "gkx", "isMessengerPWA", "react", "useSinglePartialViewImpression"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = h || d("react"),
        m = l.useCallback,
        n = l.useContext,
        o = l.useInsertionEffect,
        p = l.useRef;

    function q() {
        var a = s();
        return m(function(b) {
            a(typeof b === "string" ? {
                eventName: b,
                eventType: "interaction"
            } : babelHelpers["extends"]({}, b, {
                eventType: (b = b.eventType) != null ? b : "interaction"
            }))
        }, [a])
    }

    function a() {
        var a = q();
        return m(function(b, c) {
            return b != null && c != null ? function(d) {
                b(d), a(c)
            } : b
        }, [a])
    }

    function e() {
        var a = s();
        return m(function(b) {
            a(babelHelpers["extends"]({}, b, {
                eventType: "impression"
            }))
        }, [a])
    }

    function f(a, b) {
        var d = s();
        return c("useSinglePartialViewImpression")({
            onImpressionStart: function() {
                d(babelHelpers["extends"]({}, a, {
                    eventType: "impression"
                })), b == null ? void 0 : b()
            }
        })
    }

    function r(a) {
        var b = (i || (i = d("LSIntEnum"))).toNumber(a);
        a = (a = Object.entries(c("MessagingThreadType")).find(function(a) {
            a[0];
            a = a[1];
            return a === b
        })) != null ? a : ["unknown"];
        a = a[0];
        return a
    }

    function s() {
        var a = n(d("WebUXLoggingEntryPointContextProvider").WebUXEntryPointLoggingContext),
            e = p(a),
            f = n(d("WebUXLoggingSurfaceContextProvider").WebUXSurfaceLoggingContext),
            g = p(f),
            h = d("MWThreadKey.react").useMWThreadKeyMemoized(),
            l = p(h);
        o(function() {
            e.current = a, l.current = h, g.current = f
        });
        return m(function(a) {
            var f = a.ctaType,
                h = a.entryPoint,
                m = a.eventName,
                n = a.eventType,
                o = a.extraData,
                p = a.flowInstanceId,
                q = a.surface,
                s = a.threadKey,
                u = a.threadType;
            s = (s = s) != null ? s : l.current;
            h = h != null ? h : e.current;
            var v = u ? r(u) : "unknown",
                w = {
                    cta_type: f,
                    entry_point: h,
                    event_type: (f = n) != null ? f : "interaction",
                    extra_data: c("gkx")("1709") && c("isMessengerPWA")() ? babelHelpers["extends"]({}, o, {
                        is_pwa: "1"
                    }) : o,
                    flow_instance_id: p,
                    surface: (f = q) != null ? f : g.current,
                    thread_fbid: s != null ? (j || (j = d("I64"))).to_string(s) : void 0,
                    thread_type: u != null ? (i || (i = d("LSIntEnum"))).unwrapIntEnum(u) : void 0
                };
            c("MessengerWebUxEventFalcoEvent").log(function() {
                return babelHelpers["extends"]({
                    client_timestamp_ms: Date.now().toString(),
                    event_name: m
                }, w)
            });
            (k || (k = d("ODS"))).bumpEntityKey(t(), a.eventName + "_" + v, h);
            if (b("cr:6873") != null && n === "interaction") {
                o = b("cr:6873").getInstance("user_experience");
                o.debug(JSON.stringify(w), m)
            }
        }, [])
    }

    function t() {
        var a = c("CurrentUser").getAppID();
        switch (a) {
            case 1217981644879628:
            case 936619743392459:
            case 1035956773910536:
            case 487152425211411:
                return 938;
            case 2220391788200892:
                return 3185;
            case 772021112871879:
                return 3297;
            default:
                return 3185
        }
    }
    g.useInteractionLogger = q;
    g.useLogOnPressInteraction = a;
    g.useImpressionLogger = e;
    g.useImpressionLoggerRef = f
}), 98);
__d("getLSMediaThreadPictureUrl", ["LSMediaUrlUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.threadPictureUrl,
            c = a.threadPictureUrlExpirationTimestampMs;
        a = a.threadPictureUrlFallback;
        c = c;
        return c != null && d("LSMediaUrlUtils").isTimestampExpired(c) ? a : b
    }
    g["default"] = a
}), 98);
__d("isFacebookMessengerInboxURI", ["isFacebookURI"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return c("isFacebookURI")(a) && a.getPath().startsWith("/messages")
    }
    g["default"] = a
}), 98);
__d("useMWCMShouldGoToFullScreenChatHook", ["getRequestConstUri", "isFacebookMessengerInboxURI", "isMessengerDotComURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("getRequestConstUri")();
        return c("isMessengerDotComURI")(a) || c("isFacebookMessengerInboxURI")(a)
    }
    g["default"] = a
}), 98);
__d("withCometPlaceholder", ["CometPlaceholder.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    a = function(a, b, d) {
        b === void 0 && (b = null);
        return function(e) {
            return i.jsx(c("CometPlaceholder.react"), {
                fallback: b,
                name: d,
                children: i.jsx(a, babelHelpers["extends"]({}, e))
            })
        }
    };
    g.withCometPlaceholder = a
}), 98); /*FB_PKG_DELIM*/
__d("BaseEntryPointPopoverContainer.react", ["CometRelay", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useLayoutEffect,
        k = b.useMemo;

    function a(a) {
        a.entryPointParams;
        var b = a.entryPointReference,
            c = a.load,
            e = a.otherProps,
            f = babelHelpers.objectWithoutPropertiesLoose(a, ["entryPointParams", "entryPointReference", "load", "otherProps"]);
        a = k(function() {
            return babelHelpers["extends"]({}, e, f)
        }, [e, f]);
        j(function() {
            b == null && c()
        }, [b, c]);
        return b == null ? null : i.jsx(d("CometRelay").EntryPointContainer, {
            entryPointReference: b,
            props: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseMenuContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("BasePopoverLayerVisibility.react", ["HiddenSubtreePassiveContext", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || (h = d("react"));
    b = h;
    var i = b.useContext,
        j = b.useEffect,
        k = b.useRef;

    function a(a) {
        var b = a.children;
        a = a.onLayerDetached;
        var d = a === void 0 ? c("emptyFunction") : a;
        a = i(c("HiddenSubtreePassiveContext"));
        var e = a.getCurrentState,
            f = a.subscribeToChanges,
            g = k(!e().hiddenOrBackgrounded);
        j(function() {
            var a = f(function(a) {
                a = a.hiddenOrBackgrounded;
                a = !a;
                g.current !== a && !a && d();
                g.current = a
            });
            return function() {
                a.remove()
            }
        }, [d, f]);
        var h = k(d);
        j(function() {
            h.current = d
        }, [d]);
        var l = k(null);
        j(function() {
            l.current != null && (window.clearTimeout(l.current), l.current = null);
            return function() {
                var a = h.current;
                l.current = window.setTimeout(a, 1)
            }
        }, []);
        return b
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BasePopoverReflowSheet.react", ["BaseContextualLayerAnchorRoot.react", "BasePopoverReflowSheetContext", "BasePortal.react", "HiddenSubtreeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useContext,
        k = b.useMemo;

    function a(a) {
        a = a.children;
        var b = j(c("HiddenSubtreeContext"));
        b = b.hidden;
        var d = k(function() {
            return {
                isReflowSheet: !0
            }
        }, []);
        return i.jsx(c("BasePopoverReflowSheetContext").Provider, {
            value: d,
            children: i.jsx(c("BasePortal.react"), {
                hidden: b,
                children: i.jsx(c("BaseContextualLayerAnchorRoot.react"), {
                    children: a
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometInteractionVC", ["InteractionTracingMetrics"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        a = c("InteractionTracingMetrics").get(a);
        a = a && a.vcTracker;
        a && a.addMutationRoot(b)
    }
    g.addMutationRootForTraceId = a
}), 98);
__d("CometPrerenderer.react", ["HiddenSubtreeContextProvider.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.children;
        a = a.prerenderingProps;
        a = a === void 0 ? {} : a;
        var d = a.isVisible;
        d = d === void 0 ? !0 : d;
        a = a.shouldPrerender;
        a = a === void 0 ? !1 : a;
        return d || a ? i.jsx(c("HiddenSubtreeContextProvider.react"), {
            isHidden: !d && a,
            children: b({
                hidden: !d && a
            })
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useOnOutsideClick", ["HiddenSubtreePassiveContext", "pointerEventDistance", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useContext,
        j = b.useEffect,
        k = b.useRef;

    function a(a, b) {
        var e = k(null),
            f = i(c("HiddenSubtreePassiveContext")),
            g = k(null);
        j(function() {
            var h = e.current;
            if (a === null || h == null) return;
            var i = b || {},
                j = i.isTargetEligible;
            i = i.triggerOutsideClickOnDrag;
            var k = i === void 0 ? !1 : i;

            function l(a) {
                return a instanceof Node && h instanceof Node && !(h == null ? void 0 : h.contains(a)) && (j == null || j(a))
            }

            function m(a) {
                if (a.isPrimary) {
                    var b = l(a.target);
                    b && (g.current = a)
                }
            }

            function n(b) {
                var c = l(b.target);
                if (g.current != null && c && b.isPrimary) {
                    c = d("pointerEventDistance").isWithinThreshold(g.current, b);
                    (c || k) && (a == null ? void 0 : a(b))
                }
                g.current = null
            }

            function o(b) {
                l(b.target) && (a == null ? void 0 : a(b))
            }
            var p = "PointerEvent" in window,
                q = !1;

            function r() {
                q || (p ? (document.addEventListener("pointerup", n), document.addEventListener("pointerdown", m)) : document.addEventListener("click", o)), q = !0
            }

            function s() {
                q && (p ? (document.removeEventListener("pointerup", n), document.removeEventListener("pointerdown", m)) : document.removeEventListener("click", o)), q = !1
            }
            i = f.getCurrentState();
            i.hiddenOrBackgrounded || r();
            var t = f.subscribeToChanges(function(a) {
                a.hiddenOrBackgrounded ? c("setTimeout")(function() {
                    s()
                }, 0) : r()
            });
            return function() {
                t.remove(), s()
            }
        }, [a, f, b]);
        return e
    }
    g["default"] = a
}), 98);
__d("BasePopoverTrigger.react", ["BaseButtonPopoverContext", "BaseContextualLayer.react", "BaseContextualLayerDefaultContainer.react", "BaseMenuContext", "BasePopoverLayerVisibility.react", "BasePopoverReflowSheet.react", "BaseScrollableAreaContext", "CometErrorBoundary.react", "CometEventTimings", "CometHeroInteractionContextPassthrough.react", "CometHeroInteractionWithDiv.react", "CometHeroLogging", "CometHideLayerOnEscape.react", "CometInteractionVC", "CometPlaceholder.react", "CometPrerenderer.react", "gkx", "react", "useCometPrerenderer", "useMatchViewport", "useMergeRefs", "useOnOutsideClick", "useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useContext,
        l = b.useImperativeHandle,
        m = b.useLayoutEffect,
        n = b.useMemo,
        o = b.useRef,
        p = b.useState,
        q = c("gkx")("22878");

    function r(a) {
        var b = a.content;
        a = a.fallback;
        return i.jsx(c("CometPlaceholder.react"), {
            fallback: (a = a) != null ? a : null,
            children: b
        })
    }
    r.displayName = r.name + " [from " + f.id + "]";

    function s(a) {
        var b = a.contextualLayerRef;
        m(function() {
            var a = b.current;
            a && a.reposition({
                autoflip: !0
            })
        }, [b]);
        return null
    }
    s.displayName = s.name + " [from " + f.id + "]";

    function a(a) {
        a.allowNativePointerEventsOnPreviousLayer;
        var b = a.children,
            e = a.doNotCloseOnOutsideClick,
            f = e === void 0 ? !1 : e,
            g = a.fallback;
        e = a.imperativeRef;
        var h = a.interactionTracker,
            t = a.onHighIntentPreload,
            u = a.onLayerDetached,
            v = a.onOutsideClick,
            w = a.onVisibilityChange,
            x = a.popover,
            y = a.reflowToPosition;
        y = y === void 0 ? !1 : y;
        var z = a.popoverRenderer,
            A = z === void 0 ? r : z,
            B = a.popoverPreloadResource,
            C = a.popoverProps;
        z = a.popoverType;
        var D = z === void 0 ? "dialog" : z;
        z = a.preloadTrigger;
        a.tracePolicy;
        var E = a.visibleOnLoad,
            F = E === void 0 ? !1 : E,
            G = a.triggerOutsideClickOnDrag;
        a.isAnimationEnabled;
        a.onPopoverReady;
        var H = babelHelpers.objectWithoutPropertiesLoose(a, ["allowNativePointerEventsOnPreviousLayer", "children", "doNotCloseOnOutsideClick", "fallback", "imperativeRef", "interactionTracker", "onHighIntentPreload", "onLayerDetached", "onOutsideClick", "onVisibilityChange", "popover", "reflowToPosition", "popoverRenderer", "popoverPreloadResource", "popoverProps", "popoverType", "preloadTrigger", "tracePolicy", "visibleOnLoad", "triggerOutsideClickOnDrag", "isAnimationEnabled", "onPopoverReady"]);
        E = c("useMatchViewport")("max", "width", 600);
        var I = y || E && c("gkx")("1984") === !0,
            J = o(!1);
        a = p(!1);
        var K = a[0],
            L = a[1];
        y = p(null);
        var M = y[0],
            N = y[1],
            O = o(null),
            P = o(null),
            Q = j(function(a) {
                L(a), w && w(a)
            }, [w]),
            R = j(function() {
                Q(!1), N(null), P.current = null
            }, [Q]),
            S = j(function(a) {
                if (!K)
                    if (h == null) Q(!0);
                    else {
                        a = d("CometEventTimings").getCurrentQueueTime(a == null ? void 0 : a.timeStamp);
                        var b = a[0];
                        a = a[1];
                        h(function(a) {
                            P.current = a, Q(!0), N(c("CometHeroLogging").genHeroInteractionUUIDAndMarkStart(a.getTraceId()))
                        }, b, a)
                    }
            }, [K, h, Q]);
        l(e, function() {
            return {
                hide: function() {
                    R()
                },
                show: function() {
                    S()
                }
            }
        }, [S, R]);
        E = j(function(a) {
            a != null && M != null && d("CometInteractionVC").addMutationRootForTraceId(M, a)
        }, [M]);
        var T = o(null);
        a = c("useCometPrerenderer")(z, K, B, t);
        y = a[0];
        e = a[1];
        z = a[2];
        t = a[3];
        a = a[4];
        m(function() {
            F === !0 && J.current === !1 && (J.current = !0, S())
        }, [S, F]);
        var U = k(c("BaseScrollableAreaContext")),
            V = c("useVisibilityObserver")({
                onHidden: j(function(a) {
                    a = a.hiddenReason;
                    if (a === "COMPONENT_UNMOUNTED") return;
                    a = U[U.length - 1];
                    a != null && R()
                }, [R, U])
            }),
            W = n(function() {
                switch (D) {
                    case "menu":
                        return {
                            expanded: K,
                            haspopup: "menu"
                        };
                    case "dialog":
                    default:
                        return null
                }
            }, [K, D]),
            X = j(function(a) {
                O.current = a != null ? a : null, V(a)
            }, [V]),
            Y = function() {
                var a = P.current,
                    b = a == null ? void 0 : a.getTrace();
                if (a == null || b == null) return;
                b = b.traceStatus;
                if (b != null && b !== "START") return;
                b = !0;
                a.cancelTrace("close_popover", b)
            },
            Z = j(function() {
                f || (q && Y(), v == null ? void 0 : v(), R())
            }, [f, R, v]);
        Z = c("useOnOutsideClick")(K ? Z : null, n(function() {
            return {
                isTargetEligible: function(a) {
                    var b = O.current;
                    return b != null ? !b.contains(a) : !0
                },
                triggerOutsideClickOnDrag: G
            }
        }, [G]));
        var aa = j(function(a) {
                K ? R() : S(a)
            }, [K, R, S]),
            ba = c("useMergeRefs")(Z, E),
            ca = n(function() {
                return {
                    onClose: R
                }
            }, [R]),
            da = D === "menu",
            $ = function(a) {
                return i.createElement(c("BaseContextualLayer.react"), babelHelpers["extends"]({}, a, H, {
                    containFocus: !0,
                    contextRef: O,
                    customContainer: c("BaseContextualLayerDefaultContainer.react"),
                    imperativeRef: T,
                    key: "popover",
                    onEscapeFocusRegion: da ? R : void 0,
                    ref: ba,
                    reflowToPosition: I
                }), i.jsx(c("CometHideLayerOnEscape.react"), {
                    onHide: R,
                    children: i.jsx(c("BaseMenuContext").Provider, {
                        value: ca,
                        children: i.jsx(c("CometHeroInteractionContextPassthrough.react"), {
                            clear: !0,
                            children: i.jsx(c("CometHeroInteractionWithDiv.react"), {
                                interactionDesc: "popover_" + (B != null ? B.getModuleId() : "Unknown"),
                                interactionUUID: M,
                                children: i.jsx(c("BasePopoverLayerVisibility.react"), {
                                    onLayerDetached: u,
                                    children: A({
                                        content: i.jsxs(i.Fragment, {
                                            children: [i.jsx(s, {
                                                contextualLayerRef: T
                                            }), i.jsx(x, babelHelpers["extends"]({}, C, {
                                                onClose: R
                                            }))]
                                        }),
                                        fallback: i.jsxs(i.Fragment, {
                                            children: [i.jsx(s, {
                                                contextualLayerRef: T
                                            }), g]
                                        })
                                    })
                                })
                            })
                        })
                    })
                }))
            };
        return i.jsxs(i.Fragment, {
            children: [i.jsx(c("BaseButtonPopoverContext").Provider, {
                value: W,
                children: b(X, aa, R, e, z, t, a, K)
            }), i.jsx(c("CometErrorBoundary.react"), {
                children: i.jsx(c("CometPrerenderer.react"), {
                    prerenderingProps: y,
                    children: function(a) {
                        return I ? i.jsx(c("BasePopoverReflowSheet.react"), {
                            children: $(a)
                        }) : $(a)
                    }
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometPopoverInteractionTracing", ["CometCurrentInitialLoadVC", "CometInteractionTracingQPLConfigContext", "MAWMICSafe", "promiseDone", "react", "useCometInteractionTracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useCallback;

    function a(a, b, f) {
        var g = d("CometInteractionTracingQPLConfigContext").usePopoverTraceQPLEvent(),
            h = c("useCometInteractionTracing")(g, "fluid", "INTERACTION", a, babelHelpers["extends"]({
                interaction_type: "popover",
                load_type: b
            }, f != null ? {
                preload_trigger: f
            } : null));
        return i(function(b) {
            h(function(f) {
                var g = d("MAWMICSafe").duringMIC();
                g && f.addAnnotationInt("startedDuringMIC", 1);
                f.onComplete(function(a) {
                    var b = d("CometCurrentInitialLoadVC").getInitialLoadVC();
                    b != null && f.addAnnotationInt("sinceInitialLoadVC", Math.round(a.start - b))
                });
                a === "comet.jewel.messenger" && e(["MultipleTabsLogger"], function(a) {
                    c("promiseDone")(a.getMultipleTabsAnnotation(), function(a) {
                        f.addMetadata("multipleTabs", a)
                    })
                });
                b(f)
            })
        }, [h])
    }
    g["default"] = a
}), 98);
__d("BaseEntryPointPopoverTrigger.react", ["BaseEntryPointPopoverContainer.react", "BasePopoverTrigger.react", "CometRelay", "deepEquals", "emptyFunction", "react", "tracePolicyFromResource", "useCometPopoverInteractionTracing", "useCometRelayEntrypointContextualEnvironmentProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useMemo,
        l = b.useRef;

    function a(a) {
        var b = a.doNotCloseOnOutsideClick,
            e = a.entryPointParams,
            f = a.fallback,
            g = a.onVisibilityChange,
            h = a.otherProps,
            m = a.popoverEntryPoint,
            n = a.preloadTrigger,
            o = a.reflowToPosition,
            p = a.tracePolicy;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["doNotCloseOnOutsideClick", "entryPointParams", "fallback", "onVisibilityChange", "otherProps", "popoverEntryPoint", "preloadTrigger", "reflowToPosition", "tracePolicy"]);
        p = c("useCometPopoverInteractionTracing")((p = p) != null ? p : c("tracePolicyFromResource")("comet.popover", m.root), "entrypoint", n);
        var q = c("useCometRelayEntrypointContextualEnvironmentProvider")();
        q = d("CometRelay").useEntryPointLoader(q, m);
        var r = q[0],
            s = q[1];
        q = q[2];
        var t = l(null),
            u = j(function() {
                if (e == null) return;
                if (r !== null && c("deepEquals")(t.current, e)) return;
                t.current = e;
                s(e)
            }, [e, r, s]),
            v = k(function() {
                return {
                    entryPointParams: e,
                    entryPointReference: r,
                    load: u,
                    onClose: c("emptyFunction"),
                    otherProps: h
                }
            }, [e, r, u, h]),
            w = j(function(a) {
                a && u(), g && g(a)
            }, [u, g]);
        return i.jsx(c("BasePopoverTrigger.react"), babelHelpers["extends"]({
            doNotCloseOnOutsideClick: b,
            fallback: f,
            interactionTracker: p,
            onHighIntentPreload: u,
            onLayerDetached: q,
            onVisibilityChange: w,
            popover: c("BaseEntryPointPopoverContainer.react"),
            popoverPreloadResource: m.root,
            popoverProps: v,
            preloadTrigger: n,
            reflowToPosition: o
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNUXTourInProgressConsumerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useBaseDeferredDialog", ["CometDialogContext", "CometSuspendedDialogImpl.react", "deferredLoadComponent", "react", "tracePolicyFromResource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useContext;

    function a(a, b) {
        var d = j(c("CometDialogContext"));
        return i(function(e, f, g) {
            var h = c("deferredLoadComponent")(a);
            d(c("CometSuspendedDialogImpl.react"), {
                dialog: h,
                dialogProps: babelHelpers["extends"]({}, e, {
                    loadImmediately: !0
                }),
                fallback: b
            }, {
                loadType: "deferred",
                tracePolicy: c("tracePolicyFromResource")("comet.dialog", a)
            }, f, {
                replaceCurrentDialog: g
            })
        }, [d, a, b])
    }
    g["default"] = a
}), 98);
__d("useCometDeferredDialog", ["FDSDialogLoadingState.react", "react", "useBaseDeferredDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || c("react"),
        j = function(a) {
            return i.jsx(c("FDSDialogLoadingState.react"), {
                onClose: a
            })
        };

    function a(a, b) {
        return c("useBaseDeferredDialog")(a, (a = b) != null ? a : j)
    }
    g["default"] = a
}), 98);
__d("useIsLoggedOut", ["Actor"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = d("Actor").useActor();
        a = a[0];
        return a == null || a === "" || a === "0" || a === 0
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometCompositeFocusIndicator.react", ["fbt", "BaseFocusRing.react", "CometComponentWithKeyCommands.react", "CometCompositeStructureContext", "CometKeys", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useMemo;

    function a(a) {
        var b = a.children,
            d = a.compositeInfo,
            e = a.elementType;
        a = a.suppressFocusRing;
        var f = k(function() {
            var a = [];
            d.horizontal === !0 && a.push({
                command: {
                    key: c("CometKeys").RIGHT
                },
                description: h._("__JHASH__1VqMgLPpraa__JHASH__"),
                handler: function() {}
            }, {
                command: {
                    key: c("CometKeys").LEFT
                },
                description: h._("__JHASH__7zajSsSIBFZ__JHASH__"),
                handler: function() {}
            });
            d.vertical === !0 && a.push({
                command: {
                    key: c("CometKeys").UP
                },
                description: h._("__JHASH__1VqMgLPpraa__JHASH__"),
                handler: function() {}
            }, {
                command: {
                    key: c("CometKeys").DOWN
                },
                description: h._("__JHASH__7zajSsSIBFZ__JHASH__"),
                handler: function() {}
            });
            return a
        }, [d]);
        return j.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: f,
            debugName: "composite-role_" + (d.role || ""),
            elementType: e,
            children: j.jsx(c("CometCompositeStructureContext").Provider, {
                value: d,
                children: j.jsx(c("BaseFocusRing.react"), {
                    suppressFocusRing: a,
                    children: function(a) {
                        return b(a)
                    }
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("CometFocusGroup.react", ["CometCompositeFocusIndicator.react", "CometFocusGroupContext", "FocusGroup.react", "focusScopeQueries", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;
    b = d("FocusGroup.react").createFocusGroup(d("focusScopeQueries").tabbableScopeQuery);
    var k = b[0],
        l = b[1];

    function a(a) {
        var b = a.children,
            d = a.hideArrowSignifiers,
            e = a.role,
            f = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "hideArrowSignifiers", "role"]),
            g = j(function() {
                return {
                    FocusContainer: k,
                    FocusItem: l
                }
            }, []),
            h = j(function() {
                return {
                    hideArrowSignifiers: d === !0,
                    horizontal: a.orientation !== "vertical",
                    role: e,
                    vertical: a.orientation !== "horizontal"
                }
            }, [d, a.orientation, e]);
        return i.jsx(c("CometCompositeFocusIndicator.react"), {
            compositeInfo: h,
            children: function(a) {
                return i.jsx(c("CometFocusGroupContext").Provider, {
                    value: g,
                    children: i.jsx(k, babelHelpers["extends"]({}, f, {
                        children: b(a)
                    }))
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometLiveResolverStore", ["relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.Store = d("relay-runtime").Store, g.RecordSource = d("relay-runtime").RecordSource
}), 98);
__d("CometRelayEnvironmentProvider", ["CometRelay", "CometRelayEnvironment", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.children;
        a = a.environment;
        return i.jsx(d("CometRelay").RelayEnvironmentProvider, {
            environment: a || c("CometRelayEnvironment"),
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometRelayEnvironmentWWW", ["CometRelayEnvironmentFactory"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("CometRelayEnvironmentFactory").CometRelayEnvironmentFactory.defaultEnvironment
}), 98);
__d("CometRelayScheduler", ["gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).startTransition;
    a = c("gkx")("2442") ? {
        cancel: function() {},
        schedule: function(a, b) {
            b === "low" ? i(a) : a();
            return ""
        }
    } : {
        cancel: function() {},
        schedule: function(a) {
            i(a);
            return ""
        }
    };
    g["default"] = a
}), 98);
__d("ErrorSetup", ["fb-error"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("fb-error").ErrorSetup
}), 98);
__d("JavascriptWebErrorFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1828905");
    b = d("FalcoLoggerInternal").create("javascript_web_error", a);
    e = b;
    g["default"] = e
}), 98);
__d("ErrorTransport", ["JavascriptWebErrorFalcoEvent"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        c("JavascriptWebErrorFalcoEvent").log(function() {
            return a
        })
    }
    g.log = a
}), 98);
__d("IntlCLDRNumberType05", ["IntlVariations"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getVariation: function(a) {
            if (a === 1) return c("IntlVariations").NUMBER_ONE;
            else return c("IntlVariations").NUMBER_OTHER
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("SecuredActionBlockDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6108889802569432"
}), null);
__d("SecuredActionBlockDialogQuery$Parameters", ["SecuredActionBlockDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionBlockDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionBlockDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionBlockDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionBlockDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionBlockDialogQuery$Parameters"),
                        variables: {
                            accountType: "FACEBOOK"
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionBlockDialog.react").__setRef("SecuredActionBlockDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionChallengeCDSPasswordDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8355842131166910"
}), null);
__d("SecuredActionChallengeCDSPasswordDialogQuery$Parameters", ["SecuredActionChallengeCDSPasswordDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionChallengeCDSPasswordDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionChallengeCDSPasswordDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionChallengeCDSPasswordDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionChallengeCDSPasswordDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionChallengeCDSPasswordDialogQuery$Parameters"),
                        variables: {
                            account_id: a.account_id,
                            category_name: a.category_name
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionChallengeCDSPasswordDialog.react").__setRef("SecuredActionChallengeCDSPasswordDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionChallengePasswordDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8171723236271662"
}), null);
__d("SecuredActionChallengePasswordDialogQuery$Parameters", ["SecuredActionChallengePasswordDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionChallengePasswordDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionChallengePasswordDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionChallengePasswordDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionChallengePasswordDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionChallengePasswordDialogQuery$Parameters"),
                        variables: {
                            height: 60,
                            scale: 1,
                            width: 60
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionChallengePasswordDialog.react").__setRef("SecuredActionChallengePasswordDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("TwoStepVerificationFlow", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        LOGIN_CHALLENGES: "login_challenges",
        SECURED_ACTION: "secured_action",
        TWO_FACTOR_LOGIN: "two_factor_login",
        PRE_AUTHENTICATION: "pre_authentication"
    });
    c = a;
    f["default"] = c
}), 66);
__d("TwoStepVerificationRootQuery$Parameters", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: "7956533077718689",
            metadata: {},
            name: "TwoStepVerificationRootQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionDialogRoot.entrypoint", ["JSResourceForInteraction", "TwoStepVerificationRootQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            return {
                queries: {
                    query: {
                        parameters: c("TwoStepVerificationRootQuery$Parameters"),
                        variables: {
                            encryptedContext: a.encryptedContext,
                            isLoginChallenges: a.flow === "login_challenges",
                            isPreAuthentication: a.flow === "pre_authentication"
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("TwoStepVerificationRoot.react").__setRef("SecuredActionDialogRoot.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionNoChallengeAvailableCDSDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7620111951371116"
}), null);
__d("SecuredActionNoChallengeAvailableCDSDialogQuery$Parameters", ["SecuredActionNoChallengeAvailableCDSDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionNoChallengeAvailableCDSDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionNoChallengeAvailableCDSDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionNoChallengeAvailableCDSDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionNoChallengeAvailableCDSDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionNoChallengeAvailableCDSDialogQuery$Parameters"),
                        variables: {}
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionNoChallengeAvailableCDSDialog.react").__setRef("SecuredActionNoChallengeAvailableCDSDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionReauthDialog.entrypoint", ["JSResourceForInteraction", "TwoStepVerificationRootQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            a = a.encryptedContext;
            return {
                queries: {
                    query: {
                        parameters: c("TwoStepVerificationRootQuery$Parameters"),
                        variables: {
                            encryptedContext: a,
                            isLoginChallenges: !1,
                            isPreAuthentication: !1
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("TwoStepVerificationRoot.react").__setRef("SecuredActionReauthDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "Re-authentication canceled.";

    function a(a) {
        return (a == null ? void 0 : a.message) === g
    }
    f.SECURED_ACTION_REAUTH_CANCELED_ERROR = g;
    f.isSecuredActionError = a
}), 66);
__d("securedActionChallengeToEntrypoints", ["SecuredActionBlockDialog.entrypoint", "SecuredActionChallengeCDSPasswordDialog.entrypoint", "SecuredActionChallengePasswordDialog.entrypoint", "SecuredActionNoChallengeAvailableCDSDialog.entrypoint", "SecuredActionReauthDialog.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a) {
            case "block":
                return {
                    CDS: c("SecuredActionBlockDialog.entrypoint"),
                    "default": c("SecuredActionBlockDialog.entrypoint")
                };
            case "no_challenge_available":
                return {
                    CDS: c("SecuredActionNoChallengeAvailableCDSDialog.entrypoint"),
                    "default": c("SecuredActionNoChallengeAvailableCDSDialog.entrypoint")
                };
            case "password":
                return {
                    CDS: c("SecuredActionChallengeCDSPasswordDialog.entrypoint"),
                    "default": c("SecuredActionChallengePasswordDialog.entrypoint")
                };
            case "captcha_cardnumber":
            case "captcha_comment":
            case "captcha_email":
            case "captcha_security_key":
            case "captcha_sms":
            case "captcha_smsscarce":
            case "captcha_templar":
            case "captcha_whatsapp":
            case "captcha_work_email":
            case "established_device":
            case "fido":
            case "first_factor":
            case "mfs_totp":
            case "mwa_business":
            case "password_continue_only":
            case "password_redirect":
            case "post_login_delta":
            case "reauth":
            case "step_up":
            case "test":
            case "two_fac_with_password_fallback":
            case "2fac":
            case "2fac_for_biz":
            case "2fac_setup":
            case "work_sso":
            case "work_sso_embedded":
                return null
        }
    }

    function b(a) {
        switch (a) {
            case "reauth":
                return {
                    CDS: c("SecuredActionReauthDialog.entrypoint"),
                    "default": c("SecuredActionReauthDialog.entrypoint")
                };
            case "block":
            case "captcha_cardnumber":
            case "captcha_comment":
            case "captcha_email":
            case "captcha_security_key":
            case "captcha_sms":
            case "captcha_smsscarce":
            case "captcha_templar":
            case "captcha_whatsapp":
            case "captcha_work_email":
            case "established_device":
            case "fido":
            case "first_factor":
            case "mfs_totp":
            case "mwa_business":
            case "no_challenge_available":
            case "password":
            case "password_continue_only":
            case "password_redirect":
            case "post_login_delta":
            case "step_up":
            case "test":
            case "two_fac_with_password_fallback":
            case "2fac":
            case "2fac_for_biz":
            case "2fac_setup":
            case "work_sso":
            case "work_sso_embedded":
                return null
        }
    }
    g.securedActionChallengeToEntrypointsWithAccountID = a;
    g.securedActionChallengeToEntrypointsWithEncryptedContext = b
}), 98);
__d("securedActionTriggerChallenge", ["CometErrorOverlay", "CometRelayEnvironmentProvider", "CometTransientDialogProvider.react", "FBLogger", "OutsideExceptionKeyCommandListener.react", "SecuredActionDialogRoot.entrypoint", "deferredLoadComponent", "react", "requireDeferredForDisplay", "securedActionChallengeToEntrypoints"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferredForDisplay")("SecuredActionTriggerWithEncryptedContext.react").__setRef("securedActionTriggerChallenge")),
        k = c("deferredLoadComponent")(c("requireDeferredForDisplay")("SecuredActionTriggerWithAccountID.react").__setRef("securedActionTriggerChallenge"));

    function l() {
        var a;
        return (a = document.location.href) == null ? void 0 : a.includes("accountscenter")
    }

    function m(a) {
        return l() ? a.CDS || a["default"] : a["default"]
    }

    function n(a) {
        return l() ? a.CDS || a["default"] : a["default"]
    }

    function a(a, b) {
        a.challenge_type === "2fac" ? r(b, a) : o(b, a)
    }

    function o(a, b) {
        return s(a, function(a) {
            var c = a.onCancel,
                d = a.onExit,
                e = a.onFailure;
            a = a.onSuccess;
            var f = b.challenge_type;
            switch (f) {
                case "reauth":
                    return p(f, b, d, a);
                default:
                    return q(f, b, d, a, c, e)
            }
        })
    }

    function p(a, b, e, f) {
        var g = d("securedActionChallengeToEntrypoints").securedActionChallengeToEntrypointsWithEncryptedContext(a);
        if (g === null) {
            e();
            throw c("FBLogger")("secured_action").mustfixThrow('unsuported challenge type "%s"', a)
        }
        return i.jsx(j, {
            encryptedContext: (a = b.encrypted_context) != null ? a : "",
            entrypoint: n(g),
            flow: "secured_action",
            onExit: e,
            onSuccess: f
        })
    }
    p.displayName = p.name + " [from " + f.id + "]";

    function q(a, b, e, f, g, h) {
        var j = d("securedActionChallengeToEntrypoints").securedActionChallengeToEntrypointsWithAccountID(a);
        if (j === null) {
            e();
            throw c("FBLogger")("secured_action").mustfixThrow('unsuported challenge type "%s"', a)
        }
        return i.jsx(k, {
            accountID: b.account_id,
            categoryName: b.category_name,
            entrypoint: m(j),
            onCancel: g,
            onExit: e,
            onFailure: h,
            onSuccess: f
        })
    }
    q.displayName = q.name + " [from " + f.id + "]";

    function r(a, b) {
        return s(a, function(a) {
            var d = a.onExit;
            a = a.onSuccess;
            var e = b.encrypted_context;
            if (e === void 0) {
                d();
                throw c("FBLogger")("secured_action").mustfixThrow("two_factor challenge was thrown without a context")
            }
            return i.jsx(j, {
                encryptedContext: e,
                entrypoint: c("SecuredActionDialogRoot.entrypoint"),
                flow: "secured_action",
                onExit: d,
                onSuccess: a
            })
        })
    }

    function s(a, b) {
        var e = a.onCancel,
            f = a.onExit,
            g = a.onFailure,
            h = a.onSuccess;
        return d("CometErrorOverlay").injectComponent(function(a) {
            return i.jsx(c("CometRelayEnvironmentProvider"), {
                children: i.jsx(c("OutsideExceptionKeyCommandListener.react"), {
                    children: i.jsx(c("CometTransientDialogProvider.react"), {
                        children: b({
                            onCancel: function() {
                                e == null ? void 0 : e()
                            },
                            onExit: function() {
                                f(), a()
                            },
                            onFailure: function() {
                                g == null ? void 0 : g()
                            },
                            onSuccess: function() {
                                h(), a()
                            }
                        })
                    })
                })
            })
        })
    }
    g["default"] = a
}), 98);
__d("handleCometReauthenticationSideEffects", ["errorCode", "FBLogger", "SecuredActionUtils", "cr:5888", "err", "securedActionTriggerChallenge"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = new Set(),
        j = new Set();

    function k() {
        var a = c("err")(d("SecuredActionUtils").SECURED_ACTION_REAUTH_CANCELED_ERROR);
        a.type = "info";
        for (var b = j, e = Array.isArray(b), f = 0, b = e ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g;
            if (e) {
                if (f >= b.length) break;
                g = b[f++]
            } else {
                f = b.next();
                if (f.done) break;
                g = f.value
            }
            g = g;
            g = g.onError;
            g(a)
        }
    }

    function l() {
        for (var a = j, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var d;
            if (b) {
                if (c >= a.length) break;
                d = a[c++]
            } else {
                c = a.next();
                if (c.done) break;
                d = c.value
            }
            d = d;
            d = d.onSuccess;
            d()
        }
    }

    function m(a) {
        try {
            return JSON.parse(a)
        } catch (a) {
            a instanceof Error && c("FBLogger")("secured_action").catching(a)
        }
        return {
            account_id: "",
            challenge_type: "password"
        }
    }

    function a(a, d, e) {
        var f, g = a == null ? void 0 : a.source,
            h = (f = (f = g == null ? void 0 : g.errorCode) != null ? f : g == null ? void 0 : g.code) != null ? f : g == null ? void 0 : g.error;
        if (h !== 2136001 && h !== 3490037) return !1;
        j.add({
            onError: e,
            onSuccess: d
        });
        if (i.has(h)) return !0;
        i.add(h);
        var n = function() {
            i["delete"](h), j.clear()
        };
        f = b("cr:5888") == null ? void 0 : b("cr:5888")({
            error: a,
            onCleanup: n,
            onError: k,
            onSuccess: l
        });
        if (f === !0) return !0;
        try {
            d = m((e = g == null ? void 0 : g.description) != null ? e : "");
            c("securedActionTriggerChallenge")(d, {
                onExit: function() {
                    k(), n()
                },
                onSuccess: function() {
                    l(), n()
                }
            })
        } catch (a) {
            i["delete"](h);
            if (a instanceof Error) throw c("FBLogger")("secured_action").mustfixThrow("Something when wrong while triggering the dialog: %s", a.message);
            return !1
        }
        return !0
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LSArrayRemoveObjectAt", ["I64", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a, c, e, f) {
        return (i || (i = b("Promise"))).resolve([e.splice((h || (h = d("I64"))).to_int32(f), 1)])
    }
    g.call = a
}), 98);
__d("LSCollapseAttachments", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return b.islc(b.sortBy(b.db.table(16).fetch([
                [
                    [a[0], a[1]]
                ], "idx_attachments_collapsible_id"
            ]), [
                ["timestampMs", "DESC"]
            ]), 0, b.i64.to_float(b.i64.cast([0, 1]))).next().then(function(d, e) {
                var f = d.done;
                d = d.value;
                return f ? 0 : (e = d.item, b.sequence([function(d) {
                    return c[0] = e.messageId, b.forEach(b.db.table(16).fetch([
                        [
                            [a[0], a[1], {
                                lt: c[0]
                            }],
                            [a[0], a[1], {
                                gt: c[0]
                            }]
                        ], "idx_attachments_collapsible_id"
                    ]), function(a) {
                        var c = a.item;
                        return b.forEach(b.filter(b.db.table(12).fetch([
                            [
                                [c.threadKey, c.timestampMs, c.messageId]
                            ]
                        ]), function(a) {
                            return b.i64.eq(a.threadKey, c.threadKey) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(a.timestampMs, c.timestampMs) && a.messageId === c.messageId
                        }), function(a) {
                            var b = a.update;
                            a.item;
                            return b({
                                isCollapsed: !0
                            })
                        })
                    })
                }, function(a) {
                    return b.forEach(b.filter(b.db.table(12).fetch([
                        [
                            [e.threadKey, e.timestampMs, c[0]]
                        ]
                    ]), function(a) {
                        return b.i64.eq(a.threadKey, e.threadKey) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(a.timestampMs, e.timestampMs) && a.messageId === c[0]
                    }), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            isCollapsed: !1
                        })
                    })
                }]))
            })
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxCollapseAttachmentsStoredProcedure";
    e.exports = a
}), null);
__d("LSGetFirstAvailableAttachmentCTAID", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(a) {
            return b.sequence([function(a) {
                return b.db.table(19).fetchDesc().next().then(function(a, d) {
                    var e = a.done;
                    a = a.value;
                    return e ? c[0] = b.i64.cast([0, 1]) : (d = a.item, c[0] = b.i64.add(d.ctaId, b.i64.cast([0, 1])))
                })
            }, function(a) {
                return d[0] = c[0]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxGetFirstAvailableAttachmentCTAIDStoredProcedure";
    e.exports = a
}), null);
__d("LSInsertAttachmentItem", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(18).add({
                attachmentFbid: a[0],
                attachmentIndex: a[1],
                threadKey: a[2],
                messageId: a[4],
                defaultActionEnableExtensions: a[31],
                originalPageSenderId: a[7],
                titleText: a[8],
                subtitleText: a[9],
                bodyText: a[12],
                playableUrl: a[13],
                playableUrlFallback: a[14],
                playableUrlExpirationTimestampMs: a[15],
                playableUrlMimeType: a[16],
                dashManifest: a[17],
                previewUrl: a[18],
                previewUrlFallback: a[19],
                previewUrlExpirationTimestampMs: a[20],
                previewUrlMimeType: a[21],
                previewWidth: a[22],
                previewHeight: a[23],
                imageUrl: a[24],
                defaultCtaId: a[25],
                defaultCtaTitle: a[26],
                defaultCtaType: a[27],
                defaultButtonType: a[29],
                defaultActionUrl: a[30],
                defaultWebviewHeightRatio: a[33],
                attachmentCta1Id: a[35],
                cta1Title: a[36],
                cta1IconType: a[37],
                cta1Type: a[38],
                attachmentCta2Id: a[40],
                cta2Title: a[41],
                cta2IconType: a[42],
                cta2Type: a[43],
                attachmentCta3Id: a[45],
                cta3Title: a[46],
                cta3IconType: a[47],
                cta3Type: a[48],
                faviconUrl: a[49],
                faviconUrlFallback: a[50],
                faviconUrlExpirationTimestampMs: a[51],
                previewUrlLarge: a[52]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxInsertAttachmentItemStoredProcedure";
    e.exports = a
}), null);
__d("LSWriteCTAIdToThreadsTable", ["LSGetFirstAvailableAttachmentCTAID"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return a[1] === void 0 ? c.forEach(c.filter(c.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]), function(b) {
                return c.i64.eq(b.threadKey, a[0]) && (c.i64.neq(b.lastMessageCtaId, void 0) || b.lastMessageCtaType !== void 0)
            }), function(b) {
                var c = b.update;
                b.item;
                return c({
                    lastMessageCtaId: void 0,
                    lastMessageCtaType: void 0,
                    lastMessageCtaTimestampMs: a[2]
                })
            }) : c.i64.neq(a[2], void 0) ? c.sequence([function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var e = a.done;
                    a = a.value;
                    return e ? d[0] = c.i64.cast([0, 0]) : (b = a.item, d[0] = b.lastActivityTimestampMs)
                })
            }, function(e) {
                return c.i64.ge(a[2], d[0]) ? c.sequence([function(a) {
                    return c.storedProcedure(b("LSGetFirstAvailableAttachmentCTAID")).then(function(a) {
                        return a = a, d[2] = a[0], a
                    })
                }, function(b) {
                    return c.forEach(c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        var c = b.update;
                        b.item;
                        return c({
                            lastMessageCtaId: d[2],
                            lastMessageCtaType: a[1],
                            lastMessageCtaTimestampMs: a[2]
                        })
                    })
                }]) : c.resolve(0)
            }]) : c.resolve()
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxWriteCTAIdToThreadsTableStoredProcedure";
    e.exports = a
}), null);
__d("MDSButtonImpl.react", ["BaseStyledButton.react", "BaseTheme.react", "CometContainerPressableContext", "FDSIcon.react", "MDSText.react", "emptyFunction", "mergeRefs", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useContext,
        k = b.useEffect,
        l = b.useRef,
        m = {
            destructive: {
                backgroundColor: "xb4tp27",
                $$css: !0
            },
            disabled: {
                backgroundColor: "xwcfey6",
                $$css: !0
            },
            primary: {
                backgroundColor: "xtvsq51",
                $$css: !0
            },
            primaryDeemphasized: {
                backgroundColor: "x1hr4nm9",
                $$css: !0
            },
            secondary: {
                backgroundColor: "x1qhmfi1",
                $$css: !0
            },
            secondaryDeemphasized: {
                backgroundColor: "xjbqb8w",
                $$css: !0
            },
            sizeLarge: {
                height: "xc9qbxq",
                $$css: !0
            },
            sizeMedium: {
                height: "x10w6t97",
                $$css: !0
            },
            sizeSmall: {
                borderTopStartRadius: "xfh8nwu",
                borderTopEndRadius: "xoqspk4",
                borderBottomEndRadius: "x12v9rci",
                borderBottomStartRadius: "x138vmkv",
                height: "x1fgtraw",
                $$css: !0
            }
        },
        n = {
            dark: {
                "destructive-button-background": "rgba(235, 52, 52, 100)",
                "disabled-button-background": "var(--secondary-button-background)",
                "disabled-button-text": "rgba(155, 160, 168, 0.5)",
                "primary-button-background": "#429AFF",
                "secondary-button-background": "rgba(255, 255, 255, 0.19)"
            },
            light: {
                "destructive-button-background": "rgba(255, 41, 41, 100)",
                "disabled-button-background": "var(--secondary-button-background)",
                "disabled-button-text": "rgba(134, 142, 153, 0.5)",
                "primary-button-background": "#0A7CFF",
                "secondary-button-background": "rgba(0, 0, 0, 0.04)"
            },
            type: "VARIABLES"
        },
        o = {
            ":deemphasized": {
                iconColor: "highlight",
                textColor: "highlight"
            },
            ":disabled": {
                iconColor: "disabled",
                textColor: "disabled"
            },
            iconColor: "white",
            textColor: "white"
        },
        p = {
            ":deemphasized": {
                iconColor: "highlight",
                textColor: "highlight"
            },
            ":disabled": {
                iconColor: "disabled",
                textColor: "disabled"
            },
            iconColor: "primary",
            textColor: "secondary"
        };

    function q(a) {
        switch (a) {
            case "secondary":
                return p;
            case "destructive":
            case "primary":
            default:
                return o
        }
    }

    function r(a, b) {
        var c = b.disabled;
        b = b.reduceEmphasis;
        a = q(a);
        return (c ? a[":disabled"] : null) || (b ? a[":deemphasized"] : null) || a
    }
    e = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = a.addOnStart,
            e = a.disabled;
        e = e === void 0 ? !1 : e;
        var f = a.icon,
            g = a.isContainerTarget,
            h = g === void 0 ? !1 : g;
        g = a.label;
        var o = a.labelIsHidden;
        o = o === void 0 ? !1 : o;
        var p = a.linkProps,
            q = a.onFocusIn,
            s = a.onFocusOut,
            t = a.onHoverIn,
            u = a.onHoverOut,
            v = a.onPress,
            w = a.onPressIn,
            x = a.onPressOut,
            y = a.padding;
        y = y === void 0 ? "normal" : y;
        var z = a.reduceEmphasis;
        z = z === void 0 ? !1 : z;
        var A = a.size;
        A = A === void 0 ? 32 : A;
        var B = a.suppressHydrationWarning;
        B = B === void 0 ? !1 : B;
        var C = a.testid;
        C = a.type;
        C = C === void 0 ? "primary" : C;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnStart", "disabled", "icon", "isContainerTarget", "label", "labelIsHidden", "linkProps", "onFocusIn", "onFocusOut", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "onPressOut", "padding", "reduceEmphasis", "size", "suppressHydrationWarning", "testid", "type"]);
        var D = r(C, {
                disabled: e,
                reduceEmphasis: z
            }),
            E = D.iconColor;
        D = D.textColor;
        var F = l(null),
            G = l(null),
            H = j(c("CometContainerPressableContext"));
        k(function() {
            h && H && H.onMount({
                onContextMenu: c("emptyFunction"),
                onPress: function(a) {
                    a = F.current;
                    a && a.click()
                },
                target: p == null ? void 0 : p.target,
                url: p == null ? void 0 : p.url
            }, G)
        }, [H, h, p == null ? void 0 : p.url, p == null ? void 0 : p.target]);
        return i.jsx(c("BaseTheme.react"), {
            config: n,
            style: {
                width: "100%"
            },
            children: i.jsx(c("BaseStyledButton.react"), babelHelpers["extends"]({}, a, {
                addOnStart: d,
                "aria-label": (d = a["aria-label"]) != null ? d : g,
                content: o ? null : i.jsx(c("MDSText.react"), {
                    color: D,
                    numberOfLines: 1,
                    type: "button2",
                    children: g
                }),
                contentXstyle: [A === 28 && m.sizeSmall, A === 32 && m.sizeMedium, A === 36 && m.sizeLarge],
                disabled: e,
                icon: f == null ? null : i.jsx(c("FDSIcon.react"), {
                    color: E,
                    icon: f,
                    size: 24
                }),
                linkProps: p,
                onFocusIn: q,
                onFocusOut: s,
                onHoverIn: t,
                onHoverOut: u,
                onPress: v,
                onPressIn: w,
                onPressOut: x,
                padding: y,
                ref: c("mergeRefs")(F, b),
                suppressHydrationWarning: B,
                testid: void 0,
                xstyle: [C === "primary" && m.primary, C === "secondary" && m.secondary, C === "destructive" && m.destructive, C === "secondary" && z && m.secondaryDeemphasized, C === "primary" && z && m.primaryDeemphasized, e && m.disabled]
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = e;
    g["default"] = d
}), 98);
__d("MWXButtonImpl.react", ["cr:10054", "cr:2625", "cr:5023", "cr:5028", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    c = i.forwardRef(a);

    function a(a, c) {
        var d = a.icon,
            e = a.isContainerTarget,
            f = a.loading,
            g = a.size,
            h = a.type;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["icon", "isContainerTarget", "loading", "size", "type"]);
        if (b("cr:10054")) {
            var j = g === 36;
            return i.jsx(b("cr:10054"), babelHelpers["extends"]({
                addOnPrimary: f === !0 && b("cr:5023") ? i.jsx(b("cr:5023"), {
                    color: "disabled_DEPRECATED",
                    size: j ? 20 : 16
                }) : void 0,
                icon: d == null ? void 0 : d.component,
                ref: c,
                size: j ? "large" : "medium",
                type: h === "destructive" ? "fdsOverride_negative" : h
            }, a))
        }
        return b("cr:2625") ? i.jsx(b("cr:2625"), babelHelpers["extends"]({
            addOnStart: f === !0 && b("cr:5028") ? i.jsx(b("cr:5028"), {
                color: "grey",
                size: 24
            }) : void 0,
            icon: d == null ? void 0 : d.originalComponent,
            isContainerTarget: e,
            ref: c,
            size: g,
            type: h
        }, a)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = c;
    g["default"] = e
}), 98);
__d("MWXDialog.react", ["MWXColumn.react", "MWXColumnItem.react", "cr:3020", "cr:6827", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var d = a.children,
            e = a.hasTextOnlyContent;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "hasTextOnlyContent"]);
        if (b("cr:3020") != null) return i.jsx(b("cr:3020"), babelHelpers["extends"]({}, a, {
            children: i.jsx(c("MWXColumn.react"), {
                expanding: !0,
                paddingHorizontal: 16,
                paddingVertical: 16,
                children: i.jsx(c("MWXColumnItem.react"), {
                    expanding: !0,
                    children: d
                })
            })
        }));
        return b("cr:6827") != null ? i.jsx(b("cr:6827"), babelHelpers["extends"]({
            hasTextOnlyContent: e
        }, a, {
            children: d
        })) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MessengerEnvironment", ["CurrentEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = babelHelpers["extends"]({}, c("CurrentEnvironment"), {
        messengerui: !1,
        roomschatui: !1,
        setMessengerUI: function(a) {
            h.messengerui = a
        },
        setRoomsChatUI: function(a) {
            h.roomschatui = a
        }
    });
    a = h;
    g["default"] = a
}), 98);
__d("compactArray", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = [];
        for (var c = 0; c < a.length; ++c) {
            var d = a[c];
            d != null && b.push(d)
        }
        return b
    }
    f["default"] = a
}), 66);
__d("fbs", ["fbt", "invariant", "FbtHooks", "FbtPureStringResult"], (function(a, b, c, d, e, f, g, h) {
    var i;
    a = {};
    c = babelHelpers["extends"]({}, g, {
        _param: function(a, c, d) {
            typeof c === "string" || c instanceof b("FbtPureStringResult") || h(0, 11709, c, typeof c);
            return g._param(a, c, d)
        },
        _plural: function(a, c, d) {
            d == null || typeof d === "string" || d instanceof b("FbtPureStringResult") || h(0, 47119, d, typeof d);
            return g._plural(a, c, d)
        },
        _wrapContent: function(a, c, d, e) {
            a = typeof a === "string" ? [a] : a;
            var f = (i || (i = b("FbtHooks"))).getErrorListener({
                hash: d,
                translation: c
            });
            return i.getFbsResult({
                contents: a,
                errorListener: f,
                extraOptions: e,
                patternHash: d,
                patternString: c
            })
        },
        cachedResults: a
    });
    d = c;
    e.exports = d
}), null);
__d("useTriggerAccessibilityAlert", ["fbt", "CometTriggerAccessibilityAlertContext", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    b = i || d("react");
    var j = b.useCallback,
        k = b.useContext;

    function a() {
        var a = k(c("CometTriggerAccessibilityAlertContext"));
        return j(function(b) {
            (typeof b === "string" || h.isFbtInstance(b)) && a(b)
        }, [a])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
/**
 * License: https://www.facebook.com/legal/license/V9vdYColc4k/
 */
__d("react-0.0.0", ["React"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a && typeof a === "object" && "default" in a ? a["default"] : a
    }
    var g = a(b("React"));
    d = {};
    var h = {
        exports: d
    };

    function i() {
        h.exports = g
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }

    function c(a) {
        switch (a) {
            case void 0:
                return k()
        }
    }
    e.exports = c
}), null);
__d("react", ["react-0.0.0"], (function(a, b, c, d, e, f) {
    e.exports = b("react-0.0.0")()
}), null);
/**
 * License: https://www.facebook.com/legal/license/t3hOLs8wlXy/
 */
__d("resize-observer-polyfill-1.5.1", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {},
        h = {
            exports: g
        };

    function i() {
        (function(b, c) {
            typeof g === "object" && typeof h !== "undefined" ? h.exports = c() : b.ResizeObserver = c()
        })(this, function() {
            var b = function() {
                    if (typeof Map !== "undefined") return Map;

                    function a(a, b) {
                        var c = -1;
                        a.some(function(d, a) {
                            if (d[0] === b) {
                                c = a;
                                return !0
                            }
                            return !1
                        });
                        return c
                    }
                    return function() {
                        function b() {
                            this.__entries__ = []
                        }
                        Object.defineProperty(b.prototype, "size", {
                            get: function() {
                                return this.__entries__.length
                            },
                            enumerable: !0,
                            configurable: !0
                        });
                        b.prototype.get = function(b) {
                            b = a(this.__entries__, b);
                            b = this.__entries__[b];
                            return b && b[1]
                        };
                        b.prototype.set = function(c, d) {
                            var b = a(this.__entries__, c);
                            ~b ? this.__entries__[b][1] = d : this.__entries__.push([c, d])
                        };
                        b.prototype["delete"] = function(b) {
                            var c = this.__entries__;
                            b = a(c, b);
                            ~b && c.splice(b, 1)
                        };
                        b.prototype.has = function(b) {
                            return !!~a(this.__entries__, b)
                        };
                        b.prototype.clear = function() {
                            this.__entries__.splice(0)
                        };
                        b.prototype.forEach = function(a, b) {
                            b === void 0 && (b = null);
                            for (var c = 0, d = this.__entries__; c < d.length; c++) {
                                var e = d[c];
                                a.call(b, e[1], e[0])
                            }
                        };
                        return b
                    }()
                }(),
                c = typeof window !== "undefined" && typeof document !== "undefined" && window.document === document,
                d = function() {
                    if (typeof a !== "undefined" && a.Math === Math) return a;
                    if (typeof self !== "undefined" && self.Math === Math) return self;
                    return typeof window !== "undefined" && window.Math === Math ? window : Function("return this")()
                }(),
                e = function() {
                    return typeof requestAnimationFrame === "function" ? requestAnimationFrame.bind(d) : function(a) {
                        return setTimeout(function() {
                            return a(Date.now())
                        }, 1e3 / 60)
                    }
                }(),
                f = 2;

            function g(a, b) {
                var c = !1,
                    d = !1,
                    g = 0;

                function h() {
                    c && (c = !1, a()), d && j()
                }

                function i() {
                    e(h)
                }

                function j() {
                    var a = Date.now();
                    if (c) {
                        if (a - g < f) return;
                        d = !0
                    } else c = !0, d = !1, setTimeout(i, b);
                    g = a
                }
                return j
            }
            var h = 20,
                i = ["top", "right", "bottom", "left", "width", "height", "size", "weight"],
                j = typeof MutationObserver !== "undefined",
                k = function() {
                    function a() {
                        this.connected_ = !1, this.mutationEventsAdded_ = !1, this.mutationsObserver_ = null, this.observers_ = [], this.onTransitionEnd_ = this.onTransitionEnd_.bind(this), this.refresh = g(this.refresh.bind(this), h)
                    }
                    a.prototype.addObserver = function(a) {
                        ~this.observers_.indexOf(a) || this.observers_.push(a), this.connected_ || this.connect_()
                    };
                    a.prototype.removeObserver = function(b) {
                        var a = this.observers_;
                        b = a.indexOf(b);
                        ~b && a.splice(b, 1);
                        !a.length && this.connected_ && this.disconnect_()
                    };
                    a.prototype.refresh = function() {
                        var a = this.updateObservers_();
                        a && this.refresh()
                    };
                    a.prototype.updateObservers_ = function() {
                        var a = this.observers_.filter(function(a) {
                            return a.gatherActive(), a.hasActive()
                        });
                        a.forEach(function(a) {
                            return a.broadcastActive()
                        });
                        return a.length > 0
                    };
                    a.prototype.connect_ = function() {
                        if (!c || this.connected_) return;
                        document.addEventListener("transitionend", this.onTransitionEnd_);
                        window.addEventListener("resize", this.refresh);
                        j ? (this.mutationsObserver_ = new MutationObserver(this.refresh), this.mutationsObserver_.observe(document, {
                            attributes: !0,
                            childList: !0,
                            characterData: !0,
                            subtree: !0
                        })) : (document.addEventListener("DOMSubtreeModified", this.refresh), this.mutationEventsAdded_ = !0);
                        this.connected_ = !0
                    };
                    a.prototype.disconnect_ = function() {
                        if (!c || !this.connected_) return;
                        document.removeEventListener("transitionend", this.onTransitionEnd_);
                        window.removeEventListener("resize", this.refresh);
                        this.mutationsObserver_ && this.mutationsObserver_.disconnect();
                        this.mutationEventsAdded_ && document.removeEventListener("DOMSubtreeModified", this.refresh);
                        this.mutationsObserver_ = null;
                        this.mutationEventsAdded_ = !1;
                        this.connected_ = !1
                    };
                    a.prototype.onTransitionEnd_ = function(a) {
                        a = a.propertyName;
                        var b = a === void 0 ? "" : a;
                        a = i.some(function(a) {
                            return !!~b.indexOf(a)
                        });
                        a && this.refresh()
                    };
                    a.getInstance = function() {
                        this.instance_ || (this.instance_ = new a());
                        return this.instance_
                    };
                    a.instance_ = null;
                    return a
                }(),
                l = function(a, b) {
                    for (var c = 0, d = Object.keys(b); c < d.length; c++) {
                        var e = d[c];
                        Object.defineProperty(a, e, {
                            value: b[e],
                            enumerable: !1,
                            writable: !1,
                            configurable: !0
                        })
                    }
                    return a
                },
                m = function(a) {
                    a = a && a.ownerDocument && a.ownerDocument.defaultView;
                    return a || d
                },
                n = x(0, 0, 0, 0);

            function o(a) {
                return parseFloat(a) || 0
            }

            function p(a) {
                var b = [];
                for (var c = 1; c < arguments.length; c++) b[c - 1] = arguments[c];
                return b.reduce(function(b, c) {
                    c = a["border-" + c + "-width"];
                    return b + o(c)
                }, 0)
            }

            function q(a) {
                var b = ["top", "right", "bottom", "left"],
                    c = {};
                for (var d = 0, b = b; d < b.length; d++) {
                    var e = b[d],
                        f = a["padding-" + e];
                    c[e] = o(f)
                }
                return c
            }

            function r(a) {
                a = a.getBBox();
                return x(0, 0, a.width, a.height)
            }

            function s(a) {
                var b = a.clientWidth,
                    c = a.clientHeight;
                if (!b && !c) return n;
                var d = m(a).getComputedStyle(a),
                    e = q(d),
                    f = e.left + e.right,
                    g = e.top + e.bottom,
                    h = o(d.width),
                    i = o(d.height);
                d.boxSizing === "border-box" && (Math.round(h + f) !== b && (h -= p(d, "left", "right") + f), Math.round(i + g) !== c && (i -= p(d, "top", "bottom") + g));
                if (!u(a)) {
                    d = Math.round(h + f) - b;
                    a = Math.round(i + g) - c;
                    Math.abs(d) !== 1 && (h -= d);
                    Math.abs(a) !== 1 && (i -= a)
                }
                return x(e.left, e.top, h, i)
            }
            var t = function() {
                return typeof SVGGraphicsElement !== "undefined" ? function(a) {
                    return a instanceof m(a).SVGGraphicsElement
                } : function(a) {
                    return a instanceof m(a).SVGElement && typeof a.getBBox === "function"
                }
            }();

            function u(a) {
                return a === m(a).document.documentElement
            }

            function v(a) {
                if (!c) return n;
                return t(a) ? r(a) : s(a)
            }

            function w(a) {
                var b = a.x,
                    c = a.y,
                    d = a.width;
                a = a.height;
                var e = typeof DOMRectReadOnly !== "undefined" ? DOMRectReadOnly : Object;
                e = Object.create(e.prototype);
                l(e, {
                    x: b,
                    y: c,
                    width: d,
                    height: a,
                    top: c,
                    right: b + d,
                    bottom: a + c,
                    left: b
                });
                return e
            }

            function x(a, b, c, d) {
                return {
                    x: a,
                    y: b,
                    width: c,
                    height: d
                }
            }
            var y = function() {
                    function a(a) {
                        this.broadcastWidth = 0, this.broadcastHeight = 0, this.contentRect_ = x(0, 0, 0, 0), this.target = a
                    }
                    a.prototype.isActive = function() {
                        var a = v(this.target);
                        this.contentRect_ = a;
                        return a.width !== this.broadcastWidth || a.height !== this.broadcastHeight
                    };
                    a.prototype.broadcastRect = function() {
                        var a = this.contentRect_;
                        this.broadcastWidth = a.width;
                        this.broadcastHeight = a.height;
                        return a
                    };
                    return a
                }(),
                z = function() {
                    function a(a, b) {
                        b = w(b);
                        l(this, {
                            target: a,
                            contentRect: b
                        })
                    }
                    return a
                }(),
                A = function() {
                    function a(a, c, d) {
                        this.activeObservations_ = [];
                        this.observations_ = new b();
                        if (typeof a !== "function") throw new TypeError("The callback provided as parameter 1 is not a function.");
                        this.callback_ = a;
                        this.controller_ = c;
                        this.callbackCtx_ = d
                    }
                    a.prototype.observe = function(a) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if (typeof Element === "undefined" || !(Element instanceof Object)) return;
                        if (!(a instanceof m(a).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                        var b = this.observations_;
                        if (b.has(a)) return;
                        b.set(a, new y(a));
                        this.controller_.addObserver(this);
                        this.controller_.refresh()
                    };
                    a.prototype.unobserve = function(a) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if (typeof Element === "undefined" || !(Element instanceof Object)) return;
                        if (!(a instanceof m(a).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                        var b = this.observations_;
                        if (!b.has(a)) return;
                        b["delete"](a);
                        b.size || this.controller_.removeObserver(this)
                    };
                    a.prototype.disconnect = function() {
                        this.clearActive(), this.observations_.clear(), this.controller_.removeObserver(this)
                    };
                    a.prototype.gatherActive = function() {
                        var a = this;
                        this.clearActive();
                        this.observations_.forEach(function(b) {
                            b.isActive() && a.activeObservations_.push(b)
                        })
                    };
                    a.prototype.broadcastActive = function() {
                        if (!this.hasActive()) return;
                        var a = this.callbackCtx_,
                            b = this.activeObservations_.map(function(a) {
                                return new z(a.target, a.broadcastRect())
                            });
                        this.callback_.call(a, b, a);
                        this.clearActive()
                    };
                    a.prototype.clearActive = function() {
                        this.activeObservations_.splice(0)
                    };
                    a.prototype.hasActive = function() {
                        return this.activeObservations_.length > 0
                    };
                    return a
                }(),
                B = typeof WeakMap !== "undefined" ? new WeakMap() : new b(),
                C = function() {
                    function a(b) {
                        if (!(this instanceof a)) throw new TypeError("Cannot call a class as a function.");
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        var c = k.getInstance(),
                            d = new A(b, c, this);
                        B.set(this, d)
                    }
                    return a
                }();
            ["observe", "unobserve", "disconnect"].forEach(function(a) {
                C.prototype[a] = function() {
                    var b;
                    return (b = B.get(this))[a].apply(b, arguments)
                }
            });
            var D = function() {
                return typeof d.ResizeObserver !== "undefined" ? d.ResizeObserver : C
            }();
            return D
        })
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }

    function b(a) {
        switch (a) {
            case void 0:
                return k()
        }
    }
    e.exports = b
}), null);
/**
 * License: https://www.facebook.com/legal/license/t3hOLs8wlXy/
 */
__d("styleq-0.1.3", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {},
        h = {
            exports: g
        };

    function i() {
        Object.defineProperty(g, "__esModule", {
            value: !0
        });
        g.styleq = void 0;
        var a = new WeakMap(),
            b = "$$css";

        function c(c) {
            var d, e, f;
            c != null && (d = c.disableCache === !0, e = c.disableMix === !0, f = c.transform);
            return function() {
                var c = [],
                    g = "",
                    h = null,
                    i = d ? null : a,
                    j = new Array(arguments.length);
                for (var k = 0; k < arguments.length; k++) j[k] = arguments[k];
                while (j.length > 0) {
                    var l = j.pop();
                    if (l == null || l === !1) continue;
                    if (Array.isArray(l)) {
                        for (var m = 0; m < l.length; m++) j.push(l[m]);
                        continue
                    }
                    var n = f != null ? f(l) : l;
                    if (n.$$css) {
                        var o = "";
                        if (i != null && i.has(n)) {
                            var p = i.get(n);
                            p != null && (o = p[0], c.push.apply(c, p[1]), i = p[2])
                        } else {
                            var q = [];
                            for (var r in n) {
                                var s = n[r];
                                if (r === b) continue;
                                (typeof s === "string" || s === null) && (c.includes(r) || (c.push(r), i != null && q.push(r), typeof s === "string" && (o += o ? " " + s : s)))
                            }
                            if (i != null) {
                                var t = new WeakMap();
                                i.set(n, [o, q, t]);
                                i = t
                            }
                        }
                        o && (g = g ? o + " " + g : o)
                    } else if (e) h == null && (h = {}), h = Object.assign({}, n, h);
                    else {
                        var u = null;
                        for (var v in n) {
                            var w = n[v];
                            w !== void 0 && (c.includes(v) || (w != null && (h == null && (h = {}), u == null && (u = {}), u[v] = w), c.push(v), i = null))
                        }
                        u != null && (h = Object.assign(u, h))
                    }
                }
                var x = [g, h];
                return x
            }
        }
        var d = c();
        g.styleq = d;
        d.factory = c
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }
    b = {};
    var l = {
        exports: b
    };

    function m() {
        l.exports = k()
    }
    var n = !1;

    function o() {
        n || (n = !0, m());
        return l.exports
    }

    function a(a) {
        switch (a) {
            case void 0:
                return o()
        }
    }
    e.exports = a
}), null);
__d("styleq", ["styleq-0.1.3"], (function(a, b, c, d, e, f) {
    e.exports = b("styleq-0.1.3")()
}), null);
/**
 * License: https://www.facebook.com/legal/license/CCT5pM3qiNk/
 */
__d("tweetnacl-auth-1.0.1", ["tweetnacl-1.0.3"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("tweetnacl-1.0.3");
    c = {};
    var h = {
        exports: c
    };

    function i() {
        (function(a, b) {
            typeof h !== "undefined" && h.exports ? h.exports = b(g()) : a.nacl.auth = b(a.nacl)
        })(this, function(a) {
            if (!a) throw new Error("tweetnacl not loaded");
            var b = 128,
                c = 64;

            function d(d, e) {
                var f = new Uint8Array(b + Math.max(c, d.length)),
                    g;
                e.length > b && (e = a.hash(e));
                for (g = 0; g < b; g++) f[g] = 54;
                for (g = 0; g < e.length; g++) f[g] ^= e[g];
                f.set(d, b);
                d = a.hash(f.subarray(0, b + d.length));
                for (g = 0; g < b; g++) f[g] = 92;
                for (g = 0; g < e.length; g++) f[g] ^= e[g];
                f.set(d, b);
                return a.hash(f.subarray(0, b + d.length))
            }

            function e(a, b) {
                var c = new Uint8Array(32);
                c.set(d(a, b).subarray(0, 32));
                return c
            }
            e.full = function(a, b) {
                return d(a, b)
            };
            e.authLength = 32;
            e.authFullLength = 64;
            e.keyLength = 32;
            return e
        })
    }
    var j = !1;

    function k() {
        j || (j = !0, i());
        return h.exports
    }

    function a(a) {
        switch (a) {
            case void 0:
                return k()
        }
    }
    e.exports = a
}), null);
__d("tweetnacl-auth", ["tweetnacl-auth-1.0.1"], (function(a, b, c, d, e, f) {
    e.exports = b("tweetnacl-auth-1.0.1")()
}), null); /*FB_PKG_DELIM*/
__d("MAWCreateOptimisticSecureThread", ["I64", "LSAuthorityLevel", "LSFactory", "LSGroupParticipantJoinState", "LSIntEnum", "LSVerifyE2EEMetadataThreadExistsV2StoredProcedure", "Promise", "ReQLTable", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;

    function k(a, b) {
        return c("LSVerifyE2EEMetadataThreadExistsV2StoredProcedure")(c("LSFactory")(a), {
            authorityLevel: (j || (j = d("LSIntEnum"))).ofNumber(c("LSAuthorityLevel").OPTIMISTIC),
            threadType: b
        }).then(function(b) {
            var e = b[0];
            return d("ReQLTable").update(a.threads, [e], function(a) {
                if (a == null) throw c("unrecoverableViolation")("Optimistic thread is missing", "messenger_web_messaging");
                return babelHelpers["extends"]({}, a, {
                    clientThreadKey: e
                })
            }).then(function() {
                return e
            })
        })
    }

    function a(a, e, f) {
        return k(a, f).then(function(f) {
            return (h || (h = b("Promise"))).all(e.map(function(b) {
                return a.participants.add({
                    authorityLevel: (j || (j = d("LSIntEnum"))).ofNumber(c("LSAuthorityLevel").OPTIMISTIC),
                    contactId: b.id,
                    deliveredWatermarkTimestampMs: (i || (i = d("I64"))).zero,
                    groupParticipantJoinState: j.ofNumber(c("LSGroupParticipantJoinState").MEMBER),
                    isAdmin: void 0,
                    isModerator: !1,
                    isSuperAdmin: void 0,
                    nickname: void 0,
                    normalizedSearchTerms: void 0,
                    participantCapabilities: void 0,
                    readActionTimestampMs: i.zero,
                    readWatermarkTimestampMs: i.zero,
                    subscribeSource: void 0,
                    threadKey: f
                })
            })).then(function() {
                return f
            })
        })
    }
    g.call = a
}), 98);
__d("MessengerSurfaceType", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = "MESSENGER";
    b = "WORK_QUIKCHAT";
    c = "WORK_CHAT";
    d = "WORKROOMS";
    e = "WORKROOMS_IN_CALL";
    var g = "WORK_MEETINGS_IN_CALL",
        h = "OTHER";
    f.messenger = a;
    f.workQuickchat = b;
    f.workChat = c;
    f.workrooms = d;
    f.workroomsInCall = e;
    f.workMeetingsInCall = g;
    f.other = h
}), 66);
__d("MWCMLogMuteDuration.react", ["C4gEngagementFalcoEvent", "I64", "MWCMGetValidId", "MessengerSurfaceType"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a) {
        var b;
        return {
            "1_hour": (b = a.oneHour) != null ? b : "0",
            "15_min": (b = a.fifteenMin) != null ? b : "0",
            "24_hour": (b = a.twentyFourHour) != null ? b : "0",
            "8_hour": (b = a.eightHour) != null ? b : "0",
            until_i_turn_it_back_on: (b = a.always) != null ? b : "0"
        }
    }

    function j(a) {
        switch (a) {
            case 9e5:
                return i({
                    fifteenMin: "1"
                });
            case 36e5:
                return i({
                    oneHour: "1"
                });
            case 288e5:
                return i({
                    eightHour: "1"
                });
            case 864e5:
                return i({
                    twentyFourHour: "1"
                });
            case -1:
                return i({
                    always: "1"
                });
            default:
                return i({})
        }
    }

    function a(a) {
        var b = a.groupId,
            e = a.threadKey,
            f = a.communityId,
            g = a.eventType,
            i = a.surface,
            k = i === void 0 ? String(d("MessengerSurfaceType").messenger) : i,
            l = a.source;
        i = a.duration;
        a = a.clientExtras;
        a = a === void 0 ? {} : a;
        var m = i === 0 || i == null ? a : babelHelpers["extends"]({}, a, j(i));
        return c("C4gEngagementFalcoEvent").log(function() {
            return {
                action: "tap",
                client_extras: m,
                community_id: f == null ? null : (h || (h = d("I64"))).to_string(f),
                event: g,
                group_id: d("MWCMGetValidId").MWCMHasValidFbGroupId(b) ? (h || (h = d("I64"))).to_string(b) : null,
                source: l,
                surface: k,
                thread_id: e == null ? null : (h || (h = d("I64"))).to_string(e)
            }
        })
    }
    g.log = a
}), 98);
__d("PresenceCommonPresenceCommonTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        Active: 2,
        Inactive: 0
    });
    c = b("$InternalEnum")({
        Facebook: 1,
        Messenger: 2,
        Instagram: 3
    });
    d = b("$InternalEnum")({
        StreamControllerConnectionIds: "streamControllerConnectionIds"
    });
    e.exports = {
        AppFamily: c,
        PresenceStatus: a,
        StreamControllerSessionId$Types: d
    }
}), null);
__d("usePresenceUnifiedClientContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    c = b.createContext;
    var i = b.useContext,
        j = c(null);

    function a() {
        return i(j)
    }
    g.PresenceUnifiedClientContext = j;
    g.usePresenceUnifiedClientContext = a
}), 98);
__d("usePresenceUnifiedMapContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    c = b.createContext;
    var i = b.useContext,
        j = c(new Map());

    function a() {
        return i(j)
    }
    g.PresenceUnifiedMapContext = j;
    g.usePresenceUnifiedMapContext = a
}), 98);
__d("usePresenceUnifiedStatusText", ["fbt", "FDSRelativeTimestamp.react", "I64", "LSMessagingThreadTypeUtil", "MWPActor.react", "PresenceCommonPresenceCommonTypes", "ReQL", "ReQLSuspense", "react", "usePresenceUnifiedClientContext", "usePresenceUnifiedMapContext", "useReStore", "useServerTime"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = (k || d("react")).useEffect;

    function a(a, b) {
        var e = (i || (i = c("useReStore")))(),
            g = d("MWPActor.react").useActor(),
            k = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(e.tables.participants, ["contactId"]).getKeyRange(a).filter(function(a) {
                    a = a.contactId;
                    return !(j || (j = d("I64"))).equal(a, g)
                }).map(function(a) {
                    a = a.contactId;
                    return (j || (j = d("I64"))).to_string(a)
                })
            }, [g, e.tables.participants, a], f.id + ":41"),
            m = c("useServerTime")(),
            n = d("usePresenceUnifiedMapContext").usePresenceUnifiedMapContext(),
            o = d("usePresenceUnifiedClientContext").usePresenceUnifiedClientContext();
        l(function() {
            o == null ? void 0 : o.addAdditionalContacts(k)
        }, []);
        if (k.length <= 0) return null;
        var p = h._("__JHASH__KJ9BpmLEozf__JHASH__"),
            q = k.some(function(a) {
                return ((a = n.get(a)) == null ? void 0 : a.presenceStatus) === d("PresenceCommonPresenceCommonTypes").PresenceStatus.Active
            });
        if (q) return p;
        q = b != null ? d("LSMessagingThreadTypeUtil").isOneToOne(b) : !1;
        if (q) {
            p = k[0];
            q = Number((b = n.get(p)) == null ? void 0 : b.lastActiveTimeSeconds);
            if (q > 0) return h._("__JHASH___H_8HkZmS8j__JHASH__", [h._param("time", c("FDSRelativeTimestamp.react").getRelativeTimestamp(m, new Date(q * 1e3), "minimized"))])
        }
    }
    g["default"] = a
}), 226);
__d("MWInboxHeaderDetailsUnifiedPresenceStatusText.react", ["BaseMiddot.react", "MWChatHeaderDetailsSubtitleMutedIcon.react", "MWSeparatorContainer.react", "MWVerticalRhythm", "MWXText.react", "react", "usePresenceUnifiedStatusText"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || c("react"),
        j = {
            item: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                maxWidth: "x193iq5w",
                $$css: !0
            }
        };

    function k(a) {
        a = a.children;
        return i.jsx(c("MWXText.react"), {
            align: "start",
            numberOfLines: 1,
            type: "meta3",
            children: a
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.igHandle,
            d = a.isMuted,
            e = a.threadKey;
        a = a.threadType;
        e = c("usePresenceUnifiedStatusText")(e, a);
        return i.jsxs(c("MWSeparatorContainer.react"), {
            beforeContent: i.jsx(c("MWVerticalRhythm"), {
                height: 6
            }),
            separator: i.jsx(c("BaseMiddot.react"), {
                className: "x1e558r4 x150jy0e"
            }),
            xstyle: j.item,
            children: [b !== null ? i.jsx(k, {
                children: b
            }) : null, e != null ? i.jsx(k, {
                children: e
            }) : null, d ? i.jsx(c("MWChatHeaderDetailsSubtitleMutedIcon.react"), {
                forceInlineDisplay: !0
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWV2ChatTabThreadLinkHashContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    c = h;
    e = c.createContext;
    var j = c.useContext,
        k = e(null);

    function a(a) {
        var b = a.children;
        a = a.threadLinkHash;
        return i.jsx(k.Provider, {
            value: (a = a) != null ? a : null,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return j(k)
    }
    g.MWV2ChatTabThreadLinkHashContextProvider = a;
    g.useGetChatTabThreadLinkHash = b
}), 98);
__d("MWXIconPlusCircle", ["MWXSvgIcon", "SVGIcon", "cr:12533", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12533")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MessengerMinusFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M25.75 16.75a1.25 1.25 0 1 1 0 2.5h-15.5a1.25 1.25 0 1 1 0-2.5h15.5z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("react-relay/relay-hooks/NestedRelayEntryPointBuilderUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f.NestedRelayEntryPoint = a
}), 66);
__d("NestedRelayEntryPointBuilderUtils", ["react-relay/relay-hooks/NestedRelayEntryPointBuilderUtils"], (function(a, b, c, d, e, f) {
    "use strict";
    Object.keys(importNamespace("react-relay/relay-hooks/NestedRelayEntryPointBuilderUtils")).forEach(function(a) {
        if (a === "default" || a === "__esModule") return;
        f[a] = importNamespace("react-relay/relay-hooks/NestedRelayEntryPointBuilderUtils")[a]
    })
}), null);
__d("useCometConfirmationDialog", ["FDSDialogLoadingState.react", "react", "requireDeferred", "useCometDeferredDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useCallback,
        k = c("requireDeferred")("CometConfirmationDialogImpl.react").__setRef("useCometConfirmationDialog");

    function l() {
        return i.jsx(c("FDSDialogLoadingState.react"), {})
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function a() {
        var a = c("useCometDeferredDialog")(k, l);
        return j(function(b, c, d) {
            d === void 0 && (d = function() {}), a(b, function(a) {
                a ? c() : d()
            })
        }, [a])
    }
    g["default"] = a
}), 98);
__d("usePageEntryPointPrerenderer", ["FBLogger", "react", "useCometEntryPointPrerendererWithQueryTimeoutPrivate"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useState;

    function a(a, b, d) {
        var e = j(),
            f = e[0],
            g = e[1];
        e = c("useCometEntryPointPrerendererWithQueryTimeoutPrivate")(a, b, d);
        var h = e[0];
        a = e[1];
        b = i(function(a) {
            var b = h();
            g(b);
            if (b == null) {
                c("FBLogger")("comet_ui").blameToPreviousFrame().mustfix("Unable to present comet page EntryPoint component, preloadParams not set");
                return
            }
            b != null && a(b)
        }, [h]);
        return [b, a, f]
    }
    g["default"] = a
}), 98);
__d("usePresenceUnifiedIsThreadActive", ["I64", "MWPActor.react", "PresenceCommonPresenceCommonTypes", "ReQL", "ReQLSuspense", "react", "usePresenceUnifiedClientContext", "usePresenceUnifiedMapContext", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = (j || d("react")).useEffect;

    function a(a) {
        var b = (h || (h = c("useReStore")))(),
            e = d("MWPActor.react").useActor(),
            g = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(b.tables.participants, ["contactId"]).getKeyRange(a).filter(function(a) {
                    a = a.contactId;
                    return !(i || (i = d("I64"))).equal(a, e)
                }).map(function(a) {
                    a = a.contactId;
                    return (i || (i = d("I64"))).to_string(a)
                })
            }, [e, b.tables.participants, a], f.id + ":34"),
            j = d("usePresenceUnifiedMapContext").usePresenceUnifiedMapContext(),
            l = d("usePresenceUnifiedClientContext").usePresenceUnifiedClientContext();
        k(function() {
            l == null ? void 0 : l.addAdditionalContacts(g)
        }, []);
        return g.some(function(a) {
            return ((a = j.get(a)) == null ? void 0 : a.presenceStatus) === d("PresenceCommonPresenceCommonTypes").PresenceStatus.Active
        })
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("IWAAPI", ["WABridge"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = 1;

    function a(a) {
        return function() {
            for (var b = arguments.length, c = new Array(b), e = 0; e < b; e++) c[e] = arguments[e];
            return d("WABridge").getBridge().sendAndReceive("backend", "waapi", {
                type: a,
                args: c
            })
        }
    }
    g.version = b;
    g.makeBridgedApi = a
}), 98);
__d("LSCreateOfflineThreadingID", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return c[0] = b.i64.random(), d[0] = b.i64.and_(b.i64.or_(b.i64.lsl_(a[0], b.i64.to_int32(b.i64.cast([0, 22]))), b.i64.and_(c[0], b.i64.cast([0, 4194303]))), b.i64.cast([2147483647, 4294967295])), b.resolve(d)
    }
    a.__sproc_name__ = "LSMailboxCreateOfflineThreadingIDStoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyE2EEMetadataThreadExistsV2", ["LSCreateOfflineThreadingID", "LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(f) {
            return c.sequence([function(b) {
                return c.i64.neq(a[1], void 0) ? c.sequence([function(b) {
                    return c.db.table(9).fetch([
                        [
                            [a[1]]
                        ]
                    ]).next().then(function(b, c) {
                        var e = b.done;
                        b = b.value;
                        return e ? (e = [void 0, void 0], d[3] = e[0], d[4] = e[1], e) : (c = b.item, e = [a[1], c.authorityLevel], d[3] = e[0], d[4] = e[1], e)
                    })
                }, function(a) {
                    return a = [d[3], d[4]], d[0] = a[0], d[1] = a[1], a
                }]) : c.resolve((b = [void 0, void 0], d[0] = b[0], d[1] = b[1], b))
            }, function(e) {
                return c.i64.neq(d[0], void 0) ? c.sequence([function(e) {
                    return c.i64.neq(d[1], void 0) ? c.i64.gt(a[2], d[1]) ? c.sequence([function(b) {
                        return c.forEach(c.db.table(9).fetch([
                            [
                                [d[0]]
                            ]
                        ]), function(b) {
                            var c = b.update;
                            b.item;
                            return c({
                                authorityLevel: a[2]
                            })
                        })
                    }, function(a) {
                        return d[3] = new c.Map(), d[3].set("thread_fbid", d[0]), d[3].set("force_upsert", !1), d[3].set("use_open_messenger_transport", !1), d[3].set("sync_group", c.i64.cast([0, 95])), d[3].set("metadata_only", !1), d[3].set("preview_only", !1), d[4] = d[3].get("thread_fbid"), d[3], d[5] = c.toJSON(d[3]), c.storedProcedure(b("LSIssueNewTask"), c.i64.to_string(d[4]), c.i64.cast([0, 209]), d[5], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
                    }]) : c.resolve() : c.resolve()
                }, function(a) {
                    return d[2] = d[0]
                }]) : c.sequence([function(e) {
                    return c.i64.neq(a[1], void 0) ? c.sequence([function(e) {
                        return c.i64.neq(a[2], c.i64.cast([0, 20])) ? (d[10] = new c.Map(), d[10].set("thread_fbid", a[1]), d[10].set("force_upsert", !1), d[10].set("use_open_messenger_transport", !1), d[10].set("sync_group", c.i64.cast([0, 95])), d[10].set("metadata_only", !1), d[10].set("preview_only", !1), d[11] = d[10].get("thread_fbid"), d[10], d[12] = c.toJSON(d[10]), c.storedProcedure(b("LSIssueNewTask"), c.i64.to_string(d[11]), c.i64.cast([0, 209]), d[12], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))) : c.resolve()
                    }, function(b) {
                        return d[3] = a[1]
                    }]) : c.sequence([function(a) {
                        return d[10] = c.i64.of_float(Date.now()), c.storedProcedure(b("LSCreateOfflineThreadingID"), d[10]).then(function(a) {
                            return a = a, d[11] = a[0], a
                        })
                    }, function(a) {
                        return d[3] = d[11]
                    }])
                }, function(b) {
                    return c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 0])) ? (b = ["inbox", c.i64.cast([0, 0])], d[4] = b[0], d[5] = b[1], b) : (c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 1])) ? (b = ["pending", c.i64.cast([-1, 4294967295])], d[10] = b[0], d[11] = b[1], b) : (c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 2])) ? (b = ["other", c.i64.cast([-1, 4294967294])], d[12] = b[0], d[13] = b[1], b) : (c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 3])) ? (b = ["spam", c.i64.cast([-1, 4294967293])], d[14] = b[0], d[15] = b[1], b) : (c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 5])) ? (b = ["hidden", c.i64.cast([-1, 4294967292])], d[16] = b[0], d[17] = b[1], b) : (c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 4])) ? (b = ["archived", c.i64.cast([-1, 4294967286])], d[18] = b[0], d[19] = b[1], b) : (c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 15])) ? (b = ["restricted", c.i64.cast([-1, 4294967281])], d[20] = b[0], d[21] = b[1], b) : (b = ["inbox", c.i64.cast([0, 0])], d[20] = b[0], d[21] = b[1], b), b = [d[20], d[21]], d[18] = b[0], d[19] = b[1], b), b = [d[18], d[19]], d[16] = b[0], d[17] = b[1], b), b = [d[16], d[17]], d[14] = b[0], d[15] = b[1], b), b = [d[14], d[15]], d[12] = b[0], d[13] = b[1], b), b = [d[12], d[13]], d[10] = b[0], d[11] = b[1], b), b = [d[10], d[11]], d[4] = b[0], d[5] = b[1], b), d[6] = c.i64.cast([0, 1083495711]), d[7] = c.i64.cast([0, 1024]), d[8] = c.i64.cast([0, 0]), d[9] = c.i64.cast([0, 0]), c.forEach(c.filter(c.db.table(9).fetch([
                        [
                            [d[3]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.threadKey, d[3]) && c.i64.lt(b.authorityLevel, a[2])
                    }), function(a) {
                        return a["delete"]()
                    })
                }, function(b) {
                    return c.db.table(9).add({
                        threadKey: d[3],
                        mailboxType: c.i64.cast([0, 4096]),
                        threadType: a[0],
                        folderName: d[4],
                        lastActivityTimestampMs: c.i64.cast([-1, 4294967295]),
                        lastReadWatermarkTimestampMs: c.i64.cast([-1, 4294967295]),
                        removeWatermarkTimestampMs: c.i64.cast([-1, 4294967295]),
                        ongoingCallState: c.i64.cast([0, 0]),
                        parentThreadKey: d[5],
                        authorityLevel: a[2],
                        capabilities: d[6],
                        capabilities2: d[7],
                        capabilities3: d[8],
                        capabilities4: d[9],
                        unsendLimitMs: c.i64.cast([-1, 4294967295]),
                        syncGroup: c.i64.cast([0, 95]),
                        isHidden: !0,
                        clientThreadKey: d[3]
                    })
                }, function(a) {
                    return d[2] = d[3]
                }])
            }, function(a) {
                return e[0] = d[2]
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxVerifyE2EEMetadataThreadExistsV2StoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyThreadExistsV2", ["LSGetViewerFBID", "LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(b) {
                return [c.i64.cast([0, 7]), c.i64.cast([0, 8]), c.i64.cast([0, 13]), c.i64.cast([0, 10]), c.i64.cast([0, 11]), c.i64.cast([0, 16])].some(function(b) {
                    return c.i64.eq(a[1], b)
                }) ? c.resolve((b = [!1, !1, !1], d[0] = b[0], d[1] = b[1], d[2] = b[2], b)) : c.sequence([function(b) {
                    return c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]).next().then(function(b, e) {
                        var f = b.done;
                        b = b.value;
                        return f ? (f = [!0, !0, !1], d[3] = f[0], d[4] = f[1], d[5] = f[2], f) : (e = b.item, d[12] = e.threadName, d[11] = e.authorityLevel, d[10] = e.threadType, e.folderName === "other" ? (f = [!0, !1, !1], d[7] = f[0], d[8] = f[1], d[9] = f[2], f) : (c.i64.eq(d[10], c.i64.cast([0, 0])) && c.i64.eq(d[11], c.i64.cast([0, 40])) || [c.i64.cast([0, 23]), c.i64.cast([0, 21]), c.i64.cast([0, 18]), c.i64.cast([0, 26])].some(function(a) {
                            return c.i64.eq(d[10], a)
                        }) && c.i64.neq(d[11], c.i64.cast([0, 20])) && ((d[12] === "" ? void 0 : d[12]) === void 0 || c.i64.lt(d[11], c.i64.cast([0, 80]))) || [c.i64.cast([0, 151]), c.i64.cast([0, 155]), c.i64.cast([0, 153])].some(function(a) {
                            return c.i64.eq(d[10], a)
                        }) || [c.i64.cast([0, 24]), c.i64.cast([0, 22]), c.i64.cast([0, 19]), c.i64.cast([0, 25])].some(function(a) {
                            return c.i64.eq(d[10], a)
                        }) || [c.i64.cast([0, 150]), c.i64.cast([0, 154]), c.i64.cast([0, 152])].some(function(b) {
                            return c.i64.eq(a[1], b)
                        }) && c.i64.lt(d[11], c.i64.cast([0, 80])) || [c.i64.cast([0, 150]), c.i64.cast([0, 154]), c.i64.cast([0, 152])].some(function(b) {
                            return c.i64.eq(a[1], b)
                        }) && c.i64.eq(a[6], c.i64.cast([0, 205])) && (c.i64.eq(e.syncGroup, void 0) || !1) ? (b = [!0, !0, !1], d[13] = b[0], d[14] = b[1], d[15] = b[2], b) : (c.i64.ge(d[11], a[4]) || c.i64.eq(d[11], c.i64.cast([0, 20])) && (c.i64.eq(a[1], c.i64.cast([0, 2])) || [c.i64.cast([0, 23]), c.i64.cast([0, 21]), c.i64.cast([0, 18]), c.i64.cast([0, 26])].some(function(b) {
                            return c.i64.eq(a[1], b)
                        })) ? (f = [!1, !1, !1], d[16] = f[0], d[17] = f[1], d[18] = f[2], f) : (e = [!0, !1, !0], d[16] = e[0], d[17] = e[1], d[18] = e[2], e), b = [d[16], d[17], d[18]], d[13] = b[0], d[14] = b[1], d[15] = b[2], b), f = [d[13], d[14], d[15]], d[7] = f[0], d[8] = f[1], d[9] = f[2], f), e = [d[7], d[8], d[9]], d[3] = e[0], d[4] = e[1], d[5] = e[2], e)
                    })
                }, function(a) {
                    return a = [d[3], d[4], d[5]], d[0] = a[0], d[1] = a[1], d[2] = a[2], a
                }])
            }, function(e) {
                return d[0] ? (d[3] = new c.Map(), d[3].set("thread_fbid", a[0]), d[3].set("force_upsert", a[5]), d[3].set("use_open_messenger_transport", !1), d[3].set("sync_group", a[6]), d[3].set("metadata_only", a[7]), d[3].set("preview_only", !1), d[4] = d[3].get("thread_fbid"), d[3], d[5] = c.toJSON(d[3]), c.storedProcedure(b("LSIssueNewTask"), c.i64.to_string(d[4]), c.i64.cast([0, 209]), d[5], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))) : c.resolve()
            }, function(e) {
                return d[1] ? c.sequence([function(b) {
                    return c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]).next().then(function(b, e) {
                        var f = b.done;
                        b = b.value;
                        return f ? c.sequence([function(b) {
                            return c.filter(c.db.table(7).fetch([
                                [
                                    [a[0]]
                                ]
                            ]), function(b) {
                                return c.i64.eq(b.id, a[0]) && c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1]))
                            }).next().then(function(b, e) {
                                var a = b.done;
                                b = b.value;
                                return a ? d[19] = !1 : (e = b.item, d[19] = c.i64.eq(e.contactTypeExact, c.i64.cast([0, 16])) ? !0 : !1)
                            })
                        }, function(a) {
                            return d[3] = d[19]
                        }]) : (e = b.item, d[3] = c.i64.eq(e.threadType, c.i64.cast([0, 201])) ? !0 : !1)
                    })
                }, function(b) {
                    return d[5] = c.i64.cast([0, 1083495711]), d[6] = c.i64.cast([0, 1024]), d[7] = c.i64.cast([0, 0]), d[8] = c.i64.cast([0, 0]), c.filter(c.db.table(7).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.id, a[0]) && c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1]))
                    }).next().then(function(a, b) {
                        var e = a.done;
                        a = a.value;
                        return e ? d[9] = !1 : (b = a.item, d[9] = c.i64.eq(b.contactReachabilityStatusType, c.i64.cast([0, 12])) ? !0 : !1)
                    })
                }, function(b) {
                    return d[11] = c.i64.cast([0, 1083495711]), d[12] = c.i64.cast([0, 1024]), d[13] = c.i64.cast([0, 0]), d[14] = c.i64.cast([0, 134217728]), d[15] = c.i64.cast([0, 8650752]), d[16] = c.i64.cast([0, 1024]), d[17] = c.i64.cast([0, 0]), d[18] = c.i64.cast([0, 0]), c.forEach(c.filter(c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.threadKey, a[0]) && c.i64.lt(b.authorityLevel, a[4])
                    }), function(a) {
                        return a["delete"]()
                    })
                }, function(b) {
                    return c.db.table(9).add({
                        threadKey: a[0],
                        mailboxType: c.i64.cast([0, 0]),
                        threadType: a[1],
                        syncGroup: a[6],
                        folderName: a[2],
                        lastReadWatermarkTimestampMs: c.i64.cast([0, 0]),
                        removeWatermarkTimestampMs: c.i64.cast([-1, 4294967295]),
                        ongoingCallState: c.i64.cast([0, 0]),
                        parentThreadKey: a[3],
                        authorityLevel: a[4],
                        capabilities: d[3] ? d[15] : d[11],
                        capabilities2: d[3] ? d[16] : d[12],
                        capabilities3: d[3] ? d[17] : d[13],
                        capabilities4: d[3] ? d[18] : d[14],
                        unsendLimitMs: c.i64.cast([-1, 4294967295])
                    })
                }, function(e) {
                    return [c.i64.cast([0, 1]), c.i64.cast([0, 201])].some(function(b) {
                        return c.i64.eq(a[1], b)
                    }) ? c.sequence([function(b) {
                        return c.forEach(c.filter(c.db.table(14).fetch([
                            [
                                [a[0], a[0]]
                            ]
                        ]), function(b) {
                            return c.i64.eq(b.threadKey, a[0]) && c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 0])) && c.i64.eq(b.contactId, a[0]) && c.i64.lt(b.authorityLevel, a[4])
                        }), function(a) {
                            return a["delete"]()
                        })
                    }, function(b) {
                        return c.db.table(14).add({
                            threadKey: a[0],
                            contactId: a[0],
                            readWatermarkTimestampMs: c.i64.cast([0, 0]),
                            deliveredWatermarkTimestampMs: c.i64.cast([0, 0]),
                            authorityLevel: a[4],
                            isModerator: !1
                        })
                    }, function(a) {
                        return c.storedProcedure(b("LSGetViewerFBID")).then(function(a) {
                            return a = a, d[19] = a[0], a
                        })
                    }, function(b) {
                        return c.forEach(c.filter(c.db.table(14).fetch([
                            [
                                [a[0], d[19]]
                            ]
                        ]), function(b) {
                            return c.i64.eq(b.threadKey, a[0]) && c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 0])) && c.i64.eq(b.contactId, d[19]) && c.i64.lt(b.authorityLevel, a[4])
                        }), function(a) {
                            return a["delete"]()
                        })
                    }, function(b) {
                        return c.db.table(14).add({
                            threadKey: a[0],
                            contactId: d[19],
                            readWatermarkTimestampMs: c.i64.cast([0, 0]),
                            deliveredWatermarkTimestampMs: c.i64.cast([0, 0]),
                            authorityLevel: a[4],
                            isModerator: !1
                        })
                    }]) : c.resolve()
                }]) : c.resolve()
            }, function(b) {
                return d[2] ? c.forEach(c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(b) {
                    var c = b.update;
                    b.item;
                    return c({
                        authorityLevel: a[4]
                    })
                }) : c.resolve()
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxVerifyThreadExistsV2StoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyThreadExists", ["LSVerifyThreadExistsV2"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.storedProcedure(b("LSVerifyThreadExistsV2"), a[0], a[1], a[2], a[3], a[4], !1, a[5], !1, !1)
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxVerifyThreadExistsStoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyThreadRowExists", ["LSVerifyThreadExists"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.storedProcedure(b("LSVerifyThreadExists"), a[0], a[1] == null ? c.i64.cast([0, 1]) : a[1], "inbox", c.i64.cast([0, 0]), c.i64.cast([0, 40]) == null ? c.i64.cast([0, 40]) : c.i64.cast([0, 40]), a[2])
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxVerifyThreadRowExistsStoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyThreadRowExistsStoredProcedure", ["LSVerifyThreadRowExists", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSVerifyThreadRowExists")(b.threadKey, b.threadType, b.syncGroup, a)
    }
    g["default"] = a
}), 98);
__d("WABridgedAPI", ["IWAAPI"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = {
        queryGroups: (a = d("IWAAPI")).makeBridgedApi("queryGroups"),
        preEstablishSession: a.makeBridgedApi("preEstablishSession"),
        getDevices: a.makeBridgedApi("getDevices"),
        removeCurrentDevice: a.makeBridgedApi("removeCurrentDevice"),
        removeDevice: a.makeBridgedApi("removeDevice"),
        getCurrentUserDeviceList: a.makeBridgedApi("getCurrentUserDeviceList")
    };
    c = b;
    g["default"] = c
}), 98);
__d("WorkerBanzaiLazyQueueChannelClient", ["BanzaiLazyQueue", "WorkerFuncChannel"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        d("WorkerFuncChannel").exportChannel(c("BanzaiLazyQueue"), a, "banzai_lazyqueue_channel")
    }
    g.init = a
}), 98);
__d("XCometFBMultiSiteWebWorkerInitScriptControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/static_resources/webworker_v1/init_script/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("WorkerBundleResource", ["TrustedTypesWebWorkerScriptURLPolicy", "XCometFBMultiSiteWebWorkerInitScriptControllerRouteBuilder", "getWorkerInitScriptSPINParams", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var d, e, f;
        for (var g = arguments.length, h = new Array(g > 2 ? g - 2 : 0), i = 2; i < g; i++) h[i - 2] = arguments[i];
        var j = (d = b == null ? void 0 : b.logImportScriptsErrors) != null ? d : !1,
            k = (e = b == null ? void 0 : b.name) != null ? e : a.name,
            l = new window.URL(a.url, window.location.href).href;
        if (l == null) {
            var m = new Error("Can't start up worker without a resource url.");
            m.stack;
            throw m
        }
        var n = c("nullthrows")((f = c("XCometFBMultiSiteWebWorkerInitScriptControllerRouteBuilder").buildUri({}).addQueryParams(c("getWorkerInitScriptSPINParams")())) == null ? void 0 : f.toString()),
            o = new Worker(c("TrustedTypesWebWorkerScriptURLPolicy").createScriptURL(n), {
                name: k
            });
        o.postMessage({
            bundleUrl: l,
            initArgs: h,
            isDev: !1,
            resource: a,
            logImportScriptsErrors: j,
            type: "sr-init"
        });
        return o
    }
    g.createDedicatedWebWorker = a
}), 98);
__d("WorkerClient", ["WorkerBanzaiLazyQueueChannelClient", "WorkerFuncChannel", "WorkerQPLChannel"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        d("WorkerFuncChannel").activateChannels(a, "client", "worker"), d("WorkerBanzaiLazyQueueChannelClient").init(a), d("WorkerQPLChannel").setMessagePort(a), e(["QuickPerformanceLogger"], function(a) {
            return d("WorkerQPLChannel").initQPL(a)
        })
    }
    g.init = a
}), 98); /*FB_PKG_DELIM*/
__d("MAWBridgeInitOfflineQueueSyncCompleteHandler", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("MessengerLogHistory").__setRef("MAWBridgeInitOfflineQueueSyncCompleteHandler");

    function a() {
        h.onReady(function(a) {
            a = a.getInstance("maw_setup");
            a.debug("Init Offline Queue Sync Complete")
        })
    }
    g.call = a
}), 98);
__d("MAWBridgeInitOfflineQueueSyncStartHandler", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("MessengerLogHistory").__setRef("MAWBridgeInitOfflineQueueSyncStartHandler");

    function a() {
        h.onReady(function(a) {
            a = a.getInstance("maw_setup");
            a.debug("Init Offline Queue Sync Start")
        })
    }
    g.call = a
}), 98);
__d("MAWMediaDownloadStatusReducersUtils", ["FBLogger", "MAWGetIsMediaDownloadStatusEnabled", "MAWMediaDownloadStatus", "isEmpty", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b) {
        if (!d("MAWGetIsMediaDownloadStatusEnabled").getIsMediaDownloadStatusEnabled()) return a;
        b = b.reduce(function(b, d) {
            if (d.plaintextHash == null) {
                c("FBLogger")("messenger_web_media").mustfix("[NewMedia] No valid media plaintextHash found in reducer %s", d.mediaId);
                return b
            }
            var e = c("nullthrows")(d.plaintextHash).toString();
            if (a.mediaDownloadStatus[e] != null && a.mediaDownloadStatus[e].mainMediaStatus !== c("MAWMediaDownloadStatus").MISSING_FILE) return b;
            var f = d.hasPreviewMedia != null;
            b[e] = {
                mainMediaStatus: d.hasMedia ? c("MAWMediaDownloadStatus").SUCCESS : c("MAWMediaDownloadStatus").MISSING_FILE,
                mainMediaStatusDetails: "initial_media_download",
                previewMediaStatus: f ? d.hasPreviewMedia === !0 ? c("MAWMediaDownloadStatus").SUCCESS : c("MAWMediaDownloadStatus").MISSING_FILE : void 0,
                previewMediaStatusDetails: f ? "initial_media_download" : void 0
            };
            return b
        }, {});
        return (h || (h = c("isEmpty")))(b) ? a : babelHelpers["extends"]({}, a, {
            mediaDownloadStatus: babelHelpers["extends"]({}, a.mediaDownloadStatus, b)
        })
    }

    function b(a, b) {
        if (!d("MAWGetIsMediaDownloadStatusEnabled").getIsMediaDownloadStatusForXMAsEnabled()) return a;
        b = b.reduce(function(b, d) {
            d.faviconPlaintextHash != null && (b[d.faviconPlaintextHash] = babelHelpers["extends"]({}, a.mediaDownloadStatus[d.faviconPlaintextHash], {
                mainMediaStatus: c("MAWMediaDownloadStatus").MISSING_FILE,
                mainMediaStatusDetails: "initial_xma_favicon_status"
            }));
            d.headerMediaPlaintextHash != null && (b[d.headerMediaPlaintextHash] = babelHelpers["extends"]({}, a.mediaDownloadStatus[d.headerMediaPlaintextHash], {
                mainMediaStatus: c("MAWMediaDownloadStatus").MISSING_FILE,
                mainMediaStatusDetails: "initial_xma_header_status"
            }));
            if (d.defaultPreviewMediaPlaintextHash == null) return b;
            var e = c("nullthrows")(d.defaultPreviewMediaPlaintextHash).toString();
            if (a.mediaDownloadStatus[e] != null && a.mediaDownloadStatus[e].mainMediaStatus !== c("MAWMediaDownloadStatus").MISSING_FILE) return b;
            b[e] = babelHelpers["extends"]({}, a.mediaDownloadStatus[e], {
                mainMediaStatus: d.hasMedia === !0 ? c("MAWMediaDownloadStatus").SUCCESS : c("MAWMediaDownloadStatus").MISSING_FILE,
                mainMediaStatusDetails: "initial_media_download"
            });
            return b
        }, {});
        return (h || (h = c("isEmpty")))(b) ? a : babelHelpers["extends"]({}, a, {
            mediaDownloadStatus: babelHelpers["extends"]({}, a.mediaDownloadStatus, b)
        })
    }
    g.handleNewMedias = a;
    g.handleNewXMAs = b
}), 98);
__d("MAWStateContextProvider.react", ["MAWBridgeInitOfflineQueueSyncCompleteHandler", "MAWBridgeInitOfflineQueueSyncStartHandler", "MAWMediaDownloadStatus", "MAWMediaDownloadStatusReducersUtils", "MAWSharedProtocolQueueConst", "MAWStateContext.react", "gkx", "react", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useCallback,
        l = b.useEffect,
        m = b.useMemo,
        n = b.useReducer,
        o = b.useTransition,
        p = function(a, b) {
            return Object.entries(a).filter(function(a) {
                var c, d = a[0];
                a = a[1];
                return ((c = b[d]) == null ? void 0 : c.chatStatus) !== a.chatStatus || ((c = b[d]) == null ? void 0 : c.snippetStatus) !== a.snippetStatus
            })
        },
        q = function(a, b) {
            return a.reduce(function(a, b) {
                var c = b[0];
                b = b[1];
                a[c] = {
                    chatStatus: b.chatStatus,
                    snippetStatus: b.snippetStatus
                };
                return a
            }, b)
        },
        r = function(a, b) {
            switch (b.tag) {
                case "OptimisticSendMessage":
                    var e;
                    return babelHelpers["extends"]({}, a, {
                        messageLatencies: babelHelpers["extends"]({}, a.messageLatencies, (e = {}, e[b.optimisticMsgId] = {
                            sent: b.timestamp
                        }, e))
                    });
                case "NewMsg":
                case "MsgUpdated":
                    var f, g;
                    e = b.value.ack;
                    var h = b.value.msgId;
                    f = (f = b.value.offlineMsg) == null ? void 0 : f.msgId;
                    f != null && a.messageLatencies[f] != null && (a.messageLatencies[h] = a.messageLatencies[f], delete a.messageLatencies[f]);
                    f = a.messageLatencies[h];
                    if ((f == null ? void 0 : f.sent) != null && (f == null ? void 0 : f.acked) != null) return a;
                    f = (f == null ? void 0 : f.sent) || Date.now();
                    e = e !== 0 ? Date.now() : void 0;
                    return babelHelpers["extends"]({}, a, {
                        messageLatencies: babelHelpers["extends"]({}, a.messageLatencies, (g = {}, g[h] = {
                            acked: e,
                            sent: f
                        }, g))
                    });
                case "InitOfflineQueueSyncProgress":
                    h = b.value;
                    return babelHelpers["extends"]({}, a, {
                        offlineQueueProgressDownloaded: h
                    });
                case "InitOfflineQueueConsumerSyncProgress":
                    e = b.value;
                    f = e.chatJidStatus;
                    g = e.processed;
                    h = a.offlineQueueThreadStatus || {};
                    e = p(f, h);
                    return babelHelpers["extends"]({}, a, {
                        offlineQueueProgressProcessed: g,
                        offlineQueueThreadStatus: e.length === 0 ? h : q(e, babelHelpers["extends"]({}, h))
                    });
                case "InitOfflineQueueSyncStart":
                    d("MAWBridgeInitOfflineQueueSyncStartHandler").call();
                    f = b.value;
                    return babelHelpers["extends"]({}, a, {
                        offlineQueueCount: f
                    });
                case "InitOfflineQueueSyncComplete":
                    d("MAWBridgeInitOfflineQueueSyncCompleteHandler").call();
                    g = b.value;
                    e = a.offlineQueueThreadStatus || {};
                    h = g != null ? p(g, e) : null;
                    return babelHelpers["extends"]({}, a, {
                        offlineQueueSyncState: d("MAWSharedProtocolQueueConst").OfflineConsumerStatus.Complete,
                        offlineQueueThreadStatus: h == null || h.length === 0 ? e : q(h, babelHelpers["extends"]({}, e))
                    });
                case "IsDbMigrating":
                    return babelHelpers["extends"]({}, a, {
                        isDbMigrating: b.value
                    });
                case "UnArchivedSelfDeviceChangeAlerts":
                    f = b.value;
                    return babelHelpers["extends"]({}, a, {
                        unArchivedSelfDeviceChangeAlerts: f
                    });
                case "EphemeralSettingsUpdatedForUI":
                    g = b.value;
                    h = g.chatJid;
                    e = g.ephemeralSettingArgs;
                    f = e.ephemeralExpirationInSec;
                    g = e.ephemeralLastUpdatedOrSetTimestamp;
                    e = h;
                    return babelHelpers["extends"]({}, a, {
                        ephemeralSettings: babelHelpers["extends"]({}, a.ephemeralSettings, (h = {}, h[e] = {
                            ephemeralExpirationInSec: f,
                            ephemeralLastUpdatedOrSetTimestamp: g
                        }, h))
                    });
                case "ClearEphemeralSettings":
                    return babelHelpers["extends"]({}, a, {
                        ephemeralSettings: {}
                    });
                case "UpdateMediaStatus":
                    var i, j, k, l, m;
                    e = b.value;
                    f = e.details;
                    g = e.key;
                    h = e.status;
                    var n = e.type;
                    e = e.validationResult;
                    g = g.toString();
                    i = (i = a.mediaDownloadStatus[g]) == null ? void 0 : i.mainMediaStatus;
                    j = (j = a.mediaDownloadStatus[g]) == null ? void 0 : j.mainMediaStatusDetails;
                    k = (k = a.mediaDownloadStatus[g]) == null ? void 0 : k.previewMediaStatus;
                    l = (l = a.mediaDownloadStatus[g]) == null ? void 0 : l.previewMediaStatusDetails;
                    m = (m = a.mediaDownloadStatus[g]) == null ? void 0 : m.validationResult;
                    var o = n === "main" ? i === c("MAWMediaDownloadStatus").SUCCESS : k === c("MAWMediaDownloadStatus").SUCCESS;
                    return h === c("MAWMediaDownloadStatus").DOWNLOADING && o ? a : babelHelpers["extends"]({}, a, {
                        mediaDownloadStatus: babelHelpers["extends"]({}, a.mediaDownloadStatus, (o = {}, o[g] = {
                            mainMediaStatus: n === "main" ? h : i,
                            mainMediaStatusDetails: n === "main" ? f : j,
                            previewMediaStatus: n === "preview" ? h : k,
                            previewMediaStatusDetails: n === "preview" ? f : l,
                            validationResult: (g = e) != null ? g : m
                        }, o))
                    });
                case "SetMediaDownloadStatusState":
                    i = b.value;
                    j = i.key;
                    h = i.newMediaDownloadState;
                    k = j.toString();
                    return (h == null ? void 0 : h.mainMediaStatus) === c("MAWMediaDownloadStatus").MISSING_FILE && ((n = a.mediaDownloadStatus[k]) == null ? void 0 : n.mainMediaStatus) != null ? a : babelHelpers["extends"]({}, a, {
                        mediaDownloadStatus: babelHelpers["extends"]({}, a.mediaDownloadStatus, (f = {}, f[k] = h, f))
                    });
                case "IncreaseMediaDownloadRetryCount":
                    l = b.value.key;
                    e = l.toString();
                    return babelHelpers["extends"]({}, a, {
                        mediaDownloadRetryCount: babelHelpers["extends"]({}, a.mediaDownloadRetryCount, (g = {}, g[e] = ((m = a.mediaDownloadRetryCount[e]) != null ? m : 0) + 1, g))
                    });
                case "NewMedia":
                    return d("MAWMediaDownloadStatusReducersUtils").handleNewMedias(a, [b.value]);
                case "NewMedias":
                    return d("MAWMediaDownloadStatusReducersUtils").handleNewMedias(a, b.value);
                case "SetMediaValidatedResult":
                    o = b.value;
                    i = o.key;
                    j = o.validatedResult;
                    n = i.toString();
                    k = babelHelpers["extends"]({}, a.mediaDownloadStatus[n], {
                        validationResult: j
                    });
                    return babelHelpers["extends"]({}, a, {
                        mediaDownloadStatus: babelHelpers["extends"]({}, a.mediaDownloadStatus, (h = {}, h[n] = k, h))
                    });
                case "NewXMA":
                    return d("MAWMediaDownloadStatusReducersUtils").handleNewXMAs(a, [b.value]);
                case "NewXMAs":
                    return d("MAWMediaDownloadStatusReducersUtils").handleNewXMAs(a, b.value);
                case "UpdateMediaStatus_FOR_DEBUG_ONLY":
                    f = b.value;
                    l = f.details;
                    e = f.key;
                    m = f.status;
                    g = e.toString();
                    return babelHelpers["extends"]({}, a, {
                        mediaDownloadStatus: babelHelpers["extends"]({}, a.mediaDownloadStatus, (o = {}, o[g] = {
                            mainMediaStatus: m,
                            mainMediaStatusDetails: l,
                            previewMediaStatus: m,
                            previewMediaStatusDetails: l
                        }, o))
                    })
            }
            return a
        };

    function a(a) {
        var b;
        a = a.children;
        var e = n(r, (b = d("MAWStateContext.react")).initialState),
            f = e[0],
            g = e[1];
        e = o();
        e[0];
        var h = e[1];
        e = k(function() {
            for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
            c("gkx")("5541") ? h(function() {
                return g.apply(void 0, b)
            }) : g.apply(void 0, b)
        }, [h, g]);
        var i = m(function() {
                return new Set()
            }, []),
            p = m(function() {
                return {
                    state: f,
                    subscriptions: i
                }
            }, [f, i]),
            q = s(p),
            t = k(function() {
                return q.current
            }, [q]);
        l(function() {
            i == null ? void 0 : i.forEach(function(a) {
                return a(f)
            })
        }, [f, i]);
        return j.jsx(b.MAWDispatchContext.Provider, {
            value: e,
            children: j.jsx(b.MAWStateContext.Provider, {
                value: p,
                children: j.jsx(b.MAWNonRerenderingStateContext.Provider, {
                    value: t,
                    children: a
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function s(a) {
        var b = (h || (h = c("useUnsafeRef_DEPRECATED")))(a);
        b.current = a;
        return b
    }
    g["default"] = a
}), 98);
__d("MWChatStateActions", ["MWChatStateV2.react", "MWChatStateV2IsClosed", "MWChatStateV2IsMinimized", "MWChatStateV2Types"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return [{
            state: function(b) {
                var c = b.tabs.get(a);
                return c != null && b.focusedTabId !== a ? {
                    focusedTabId: a,
                    mediaViewerOpenWatermark: b.mediaViewerOpenWatermark,
                    nextTabId: b.nextTabId,
                    tabs: b.tabs
                } : b
            },
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateState
        }]
    }

    function b(a) {
        return [{
            state: function(b) {
                var c = d("MWChatStateV2.react").getTabIdFromThreadKey(b, a);
                if (c == null) return b;
                var e = b.tabs.get(c);
                return e != null && b.focusedTabId !== c ? {
                    focusedTabId: c,
                    mediaViewerOpenWatermark: b.mediaViewerOpenWatermark,
                    nextTabId: b.nextTabId,
                    tabs: b.tabs
                } : b
            },
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateState
        }]
    }

    function c() {
        return [{
            state: function(a) {
                var b = a.focusedTabId;
                return b != null ? {
                    focusedTabId: void 0,
                    mediaViewerOpenWatermark: a.mediaViewerOpenWatermark,
                    nextTabId: a.nextTabId,
                    tabs: a.tabs
                } : a
            },
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateState
        }]
    }

    function e(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !1
            },
            tabId: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTab,
            updater: function(b) {
                return a <= b.closeWatermark ? b : {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: a,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: b.tabType
                }
            }
        }]
    }

    function f(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !1
            },
            threadKey: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTabByThreadKey,
            updater: function(b) {
                return a <= b.closeWatermark ? b : {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: a,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: b.tabType
                }
            }
        }]
    }

    function h(a, b, c) {
        var e = function(b) {
            return a <= b.openWatermark ? b : {
                clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                closeWatermark: b.closeWatermark,
                minimizeWatermark: b.minimizeWatermark,
                openFlyoutWatermark: b.openFlyoutWatermark,
                openWatermark: a,
                tabId: b.tabId,
                tabType: c
            }
        };
        return [{
            inserter: e,
            tabConfig: b,
            tabType: c,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpsertTab,
            updater: e
        }]
    }

    function i(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !0
            },
            tabId: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTab,
            updater: function(b) {
                return a <= b.openWatermark ? b : {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: a,
                    tabId: b.tabId,
                    tabType: b.tabType
                }
            }
        }]
    }

    function j(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !1
            },
            tabId: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTab,
            updater: function(b) {
                return a <= b.minimizeWatermark || d("MWChatStateV2IsClosed").isClosed(b) ? b : {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: a,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: b.tabType
                }
            }
        }]
    }

    function k(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !1
            },
            threadKey: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTabByThreadKey,
            updater: function(b) {
                return a <= b.minimizeWatermark || d("MWChatStateV2IsClosed").isClosed(b) ? b : {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: a,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: b.tabType
                }
            }
        }]
    }

    function l(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !1
            },
            tabId: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTab,
            updater: function(b) {
                return a <= b.clientForcedMinimizeWatermark ? b : {
                    clientForcedMinimizeWatermark: a,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: b.tabType
                }
            }
        }]
    }

    function m(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !1
            },
            threadKey: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTabByThreadKey,
            updater: function(b) {
                return a <= b.minimizeWatermark ? b : {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: a,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: b.tabType
                }
            }
        }]
    }

    function n(a, b) {
        return [{
            tabConfig: {
                shouldClearOldHiddenTab: !1,
                shouldFocus: !0
            },
            tabId: a,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTab,
            updater: function(a) {
                return babelHelpers["extends"]({}, a, {
                    tabType: {
                        threadKeyDescriptor: b,
                        type: d("MWChatStateV2Types").MWChatStateTabType.ChatTab
                    }
                })
            }
        }]
    }

    function o(a, b, c, e, f) {
        f === void 0 && (f = {
            shouldClearOldHiddenTab: !1
        });
        return [{
            tabConfig: {
                shouldClearOldHiddenTab: f.shouldClearOldHiddenTab,
                shouldFocus: !1
            },
            tabId: a,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTab,
            updater: function(a) {
                var f = a.tabType;
                return f.type === d("MWChatStateV2Types").MWChatStateTabType.ComposeTab ? a : babelHelpers["extends"]({}, a, {
                    tabType: {
                        threadKeyDescriptor: {
                            clientThreadKey: c,
                            threadKey: b,
                            threadType: (a = e) != null ? a : f.threadKeyDescriptor.threadType
                        },
                        type: d("MWChatStateV2Types").MWChatStateTabType.ChatTab
                    }
                })
            }
        }]
    }

    function p(a, b, c) {
        var e = function(b) {
                if (d("MWChatStateV2IsClosed").isClosed(b)) return {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: a,
                    tabId: b.tabId,
                    tabType: c
                };
                return d("MWChatStateV2IsMinimized").isMinimized(void 0, b) ? {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: a,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: c
                } : b
            },
            f = function(b) {
                return a <= b.openWatermark ? b : {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: b.openFlyoutWatermark,
                    openWatermark: a,
                    tabId: b.tabId,
                    tabType: c
                }
            };
        return [{
            inserter: f,
            tabConfig: b,
            tabType: c,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpsertTab,
            updater: e
        }]
    }

    function q(a, b) {
        return [{
            tabConfig: {
                shouldFocus: !1
            },
            threadKey: b,
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateTabByThreadKey,
            updater: function(b) {
                return a === b.openFlyoutWatermark ? {
                    clientForcedMinimizeWatermark: b.clientForcedMinimizeWatermark,
                    closeWatermark: b.closeWatermark,
                    minimizeWatermark: b.minimizeWatermark,
                    openFlyoutWatermark: 0,
                    openWatermark: b.openWatermark,
                    tabId: b.tabId,
                    tabType: b.tabType
                } : b
            }
        }]
    }

    function r(a) {
        return [{
            state: function(b) {
                return {
                    focusedTabId: b.focusedTabId,
                    mediaViewerOpenWatermark: a,
                    nextTabId: b.nextTabId,
                    tabs: b.tabs
                }
            },
            type: d("MWChatStateV2Types").MWChatStateActionsType.UpdateState
        }]
    }
    g.focusTab = a;
    g.focusTabByThreadKey = b;
    g.blurTab = c;
    g.closeTab = e;
    g.closeTabByThreadKey = f;
    g.openTab = h;
    g.maximizeTab = i;
    g.minimizeTab = j;
    g.minimizeTabByThreadKey = k;
    g.forceMinimizeTab = l;
    g.notificationBringHeadToTop = m;
    g.lockInTab = n;
    g.updateThreadKeyDescriptor = o;
    g.openTabOrFlyout = p;
    g.closeFlyout = q;
    g.updateMediaViewerOpenWatermark = r
}), 98); /*FB_PKG_DELIM*/
__d("BasePopoverDownEdgeArrow.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            "aria-hidden": !0,
            height: 12,
            viewBox: "0 0 21 12",
            width: 21
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M21 0c-2.229.424-4.593 2.034-6.496 3.523L5.4 10.94c-2.026 2.291-5.434.62-5.4-2.648V0h21Z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BasePopoverDownInsetArrow.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            "aria-hidden": !0,
            height: 12,
            viewBox: "0 0 25 12",
            width: 25
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M24.453.001c-2.791.32-5.922 1.53-7.78 3.455l-9.62 7.023c-2.45 2.54-5.78 1.645-5.78-2.487V1.983C1.273 1.089.746.32 0 0h24.453v.001Z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BasePopoverRightEdgeArrow.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            "aria-hidden": !0,
            height: 21,
            viewBox: "0 0 12 21",
            width: 12
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M20.685.12c-2.229.424-4.278 1.914-6.181 3.403L5.4 10.94c-2.026 2.291-5.434.62-5.4-2.648V.12Z",
                transform: "rotate(-90 10.498 10.488)"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BasePopoverRightInsetArrow.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            "aria-hidden": !0,
            height: 25,
            viewBox: "0 0 12 25",
            width: 12
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M24.553.103c-2.791.32-5.922 1.53-7.78 3.455l-9.62 7.023c-2.45 2.54-5.78 1.645-5.78-2.487V2.085C1.373 1.19.846.422.1.102z",
                transform: "rotate(-90 12.5 12.48)"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BasePopoverSVGArrowContainer.react", ["BaseContextualLayerContextSizeContext", "BaseContextualLayerLayerAdjustmentContext", "BaseContextualLayerOrientationContext", "BasePopoverDownEdgeArrow.svg.react", "BasePopoverDownInsetArrow.svg.react", "BasePopoverReflowSheetContext", "BasePopoverRightEdgeArrow.svg.react", "BasePopoverRightInsetArrow.svg.react", "Locale", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useContext,
        l = b.useMemo,
        m = 3,
        n = c("Locale").isRTL(),
        o = 25,
        p = {
            arrow: {
                filter: "xem7dle",
                position: "x10l6tqk",
                $$css: !0
            },
            container: {
                position: "x1n2onr6",
                $$css: !0
            }
        },
        q = {
            above: {
                marginBottom: "x1fqp7bg",
                $$css: !0
            },
            below: {
                marginTop: "xcxhlts",
                $$css: !0
            },
            end: {
                marginStart: "x13ibhcj",
                $$css: !0
            },
            start: {
                marginEnd: "x1jqylkn",
                $$css: !0
            }
        },
        r = {
            above: {
                top: "x11k2h6o",
                $$css: !0
            },
            below: {
                bottom: "xng853d",
                $$css: !0
            },
            end: {
                end: "x1gozi89",
                left: null,
                right: null,
                $$css: !0
            },
            start: {
                start: "x1ke83zm",
                left: null,
                right: null,
                $$css: !0
            }
        },
        s = {
            end: {
                end: "xdlq8gc",
                left: null,
                right: null,
                $$css: !0
            },
            middle: {
                start: "xu8u0ou",
                left: null,
                right: null,
                $$css: !0
            },
            start: {
                start: "xncvr77",
                left: null,
                right: null,
                $$css: !0
            },
            stretch: {
                $$css: !0
            }
        },
        t = {
            end: {
                bottom: "x1ey2m1c",
                $$css: !0
            },
            middle: {
                top: "x18g6o9x",
                $$css: !0
            },
            start: {
                top: "x13vifvy",
                $$css: !0
            },
            stretch: {
                $$css: !0
            }
        };

    function u(a, b, c) {
        c = c - m;
        if (!a) return b === "end" || b === "middle" ? c * -1 : c;
        return n && b === "start" || !n && b === "end" ? c * -1 : c
    }

    function v(a) {
        var b = a.arrowAlignment,
            c = a.contextSize,
            d = a.layerAdjustment,
            e = a.popoverAlign;
        a = a.popoverPosition;
        d = d !== 0 && e !== "middle" ? -d : 0;
        a = a === "below" || a === "above";
        if (b !== "edge" && c != null) {
            b = a ? c.width : c.height;
            c = b > 0 ? b / 2 : 0;
            c !== 0 && (d += u(a, e, e === "middle" ? o / 2 : c))
        }
        return d === 0 ? {} : {
            transform: a ? "translateX(" + d + "px)" : "translateY(" + d + "px)"
        }
    }

    function w(a, b, c, d, e, f) {
        return a === "above" || a === "below" ? b === "middle" ? e : f : b === "middle" ? c : d
    }
    e = j.forwardRef(a);

    function a(a, b) {
        var d = a.arrowPositionOffset;
        d === void 0 ? -1 : d;
        d = a.downEdgeArrowSvg;
        d = d === void 0 ? c("BasePopoverDownEdgeArrow.svg.react") : d;
        var e = a.downInsetArrowSvg;
        e = e === void 0 ? c("BasePopoverDownInsetArrow.svg.react") : e;
        var f = a.rightEdgeArrowSvg;
        f = f === void 0 ? c("BasePopoverRightEdgeArrow.svg.react") : f;
        var g = a.rightInsetArrowSvg;
        g = g === void 0 ? c("BasePopoverRightInsetArrow.svg.react") : g;
        var i = a.arrowAlignment,
            m = i === void 0 ? "center" : i;
        i = a.children;
        var o = a.testid,
            u = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["arrowPositionOffset", "downEdgeArrowSvg", "downInsetArrowSvg", "rightEdgeArrowSvg", "rightInsetArrowSvg", "arrowAlignment", "children", "testid", "xstyle"]);
        var x = k(c("BaseContextualLayerOrientationContext")),
            y = x.align,
            z = x.position,
            A = k(c("BaseContextualLayerContextSizeContext"));
        x = w(z, y, g, f, e, d);
        var B = (g = k(c("BaseContextualLayerLayerAdjustmentContext"))) != null ? g : 0;
        f = l(function() {
            var a = n ? "start" : "end",
                b = n ? "end" : "start",
                c = y === "end" && !n || y === "start" && n,
                d = y === "middle" ? -B : 0,
                e = 1,
                f = 1,
                g = 0,
                h = 0;
            switch (z) {
                case "above":
                    g += d;
                    c && (e = -1);
                    break;
                case "below":
                    g += d;
                    f = -1;
                    c && (e = -1);
                    break;
                case b:
                    h += d;
                    y === "start" && (f = -1);
                    break;
                case a:
                    h += d;
                    e = -1;
                    y === "start" && (f = -1);
                    break
            }
            return {
                arrowStyle: {
                    transform: "scale(" + e + ", " + f + ") translate(" + g + "px, " + h + "px)"
                },
                containerStyle: v({
                    arrowAlignment: m,
                    contextSize: A,
                    layerAdjustment: B,
                    popoverAlign: y,
                    popoverPosition: z
                })
            }
        }, [y, m, A, B, z]);
        e = f.arrowStyle;
        d = f.containerStyle;
        g = k(c("BasePopoverReflowSheetContext"));
        f = g.isReflowSheet;
        return j.jsxs("div", babelHelpers["extends"]({}, a, {
            className: (h || (h = c("stylex")))(p.container, q[z], u),
            ref: b,
            style: f ? null : d
        }, c("testID")(o), {
            children: [i, j.jsx(x, {
                className: h(p.arrow, r[z], (z === "start" || z === "end") && t[y], (z === "above" || z === "below") && s[y]),
                fill: "var(--card-background)",
                style: e
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = e;
    g["default"] = d
}), 98);
__d("CDSTextStyleContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext("body");
    g["default"] = b
}), 98);
__d("FDSPopoverContainerPaddingContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(!0);
    g["default"] = b
}), 98);
__d("FDSPopoverContainer.react", ["BaseContextualLayerOrientationContext", "FDSPopoverContainerPaddingContext", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useContext,
        l = {
            padding: {
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v",
                paddingStart: "x1swvt13",
                paddingEnd: "x1pi30zi",
                $$css: !0
            },
            root: {
                backgroundColor: "xezm23g",
                borderTopColor: "xwtykhg",
                borderEndColor: "xl6askr",
                borderBottomColor: "x1sa2p9j",
                borderStartColor: "x8s7dd",
                borderTopStartRadius: "x1qpq9i9",
                borderTopEndRadius: "xdney7k",
                borderBottomEndRadius: "xu5ydu1",
                borderBottomStartRadius: "xt3gfkd",
                borderTopStyle: "x18runqf",
                borderEndStyle: "x1cur4ig",
                borderBottomStyle: "xgfcmlh",
                borderStartStyle: "x1rjs6j1",
                borderTopWidth: "x4ruge8",
                borderEndWidth: "x9h15zd",
                borderBottomWidth: "x8ro2h5",
                borderStartWidth: "x1x16y7e",
                boxShadow: "x8ii3r7",
                boxSizing: "x9f619",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                $$css: !0
            }
        },
        m = {
            end: {
                borderBottomEndRadius: "x5pf9jr",
                $$css: !0
            },
            middle: {
                $$css: !0
            },
            start: {
                borderBottomStartRadius: "xo71vjh",
                $$css: !0
            },
            stretch: {
                $$css: !0
            }
        },
        n = {
            end: {
                borderTopEndRadius: "x13lgxp2",
                $$css: !0
            },
            middle: {
                $$css: !0
            },
            start: {
                borderTopStartRadius: "x168nmei",
                $$css: !0
            },
            stretch: {
                $$css: !0
            }
        },
        o = {
            end: {
                borderBottomEndRadius: "x5pf9jr",
                $$css: !0
            },
            middle: {
                $$css: !0
            },
            start: {
                borderTopEndRadius: "x13lgxp2",
                $$css: !0
            },
            stretch: {
                $$css: !0
            }
        },
        p = {
            end: {
                borderBottomStartRadius: "xo71vjh",
                $$css: !0
            },
            middle: {
                $$css: !0
            },
            start: {
                borderTopStartRadius: "x168nmei",
                $$css: !0
            },
            stretch: {
                $$css: !0
            }
        };

    function q(a, b) {
        switch (a) {
            case "above":
                return m[b];
            case "below":
                return n[b];
            case "end":
                return p[b];
            case "start":
                return o[b]
        }
    }
    b = j.forwardRef(a);

    function a(a, b) {
        var d = a.children,
            e = a.withArrow;
        a = a.xstyle;
        var f = k(c("BaseContextualLayerOrientationContext")),
            g = f.align;
        f = f.position;
        var i = k(c("FDSPopoverContainerPaddingContext"));
        return j.jsx("div", babelHelpers["extends"]({}, (h || (h = c("stylex"))).props(l.root, i && l.padding, e === !0 && q(f, g), a), {
            ref: b,
            children: d
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("FDSPopover.react", ["BasePopover.react", "BasePopoverSVGArrowContainer.react", "FDSPopoverContainer.react", "FDSPopoverContainerPaddingContext", "cr:1941981", "cr:1941982", "react", "useCometDisplayTimingTrackerForInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            card: {
                boxSizing: "x9f619",
                $$css: !0
            },
            cardBackground: {
                backgroundColor: "x1jx94hy",
                $$css: !0
            },
            cardShadow: {
                boxShadow: "x8ii3r7",
                $$css: !0
            },
            popoverWithArrow: {
                filter: "xe5xk9h",
                $$css: !0
            }
        };
    e = i.forwardRef(a);

    function a(a, d) {
        var e = a.animatedPopover;
        e = e === void 0 ? !1 : e;
        var f = a["aria-describedby"],
            g = a["aria-label"],
            h = a["aria-labelledby"],
            k = a.children,
            l = a.popoverName,
            m = a.withArrow;
        m = m === void 0 ? !1 : m;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["animatedPopover", "aria-describedby", "aria-label", "aria-labelledby", "children", "popoverName", "withArrow"]);
        l = c("useCometDisplayTimingTrackerForInteraction")(l);
        return i.jsx(c("BasePopover.react"), babelHelpers["extends"]({}, a, {
            "aria-describedby": f,
            "aria-label": (a = g) != null ? a : void 0,
            "aria-labelledby": h,
            arrowImpl: m ? c("BasePopoverSVGArrowContainer.react") : void 0,
            ref: d,
            xstyle: m && j.popoverWithArrow,
            children: e && b("cr:1941981") != null && b("cr:1941982") != null ? i.jsx(b("cr:1941982"), {
                children: i.jsx(b("cr:1941981"), {
                    backgroundColorXStyle: j.cardBackground,
                    borderRadius: 8,
                    boxShadowXStyle: j.cardShadow,
                    ref: l,
                    springConfig: {
                        bounciness: 4,
                        speed: 40
                    },
                    xstyle: j.card,
                    children: k
                })
            }) : i.jsx(c("FDSPopoverContainerPaddingContext").Provider, {
                value: !1,
                children: i.jsx(c("FDSPopoverContainer.react"), {
                    ref: l,
                    withArrow: m,
                    children: k
                })
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = e;
    g["default"] = d
}), 98);
__d("FDSPopoverLoadingStateContent.react", ["CometProgressRingIndeterminate.react", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            root: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                height: "xnnlda6",
                justifyContent: "xl56j7k",
                minWidth: "x18ip3f8",
                width: "xh8yej3",
                $$css: !0
            }
        };

    function a(a) {
        a = a.xstyle;
        return i.jsx(d("react-strict-dom").html.div, {
            style: [j.root, a],
            children: i.jsx(c("CometProgressRingIndeterminate.react"), {
                color: "disabled_DEPRECATED",
                size: 24
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("FDSPopoverLoadingState.react", ["fbt", "BasePopoverReflowSheetContext", "FDSPopover.react", "FDSPopoverLoadingStateContent.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useContext;

    function a(a) {
        var b = a.withArrow,
            d = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["withArrow", "xstyle"]);
        var e = k(c("BasePopoverReflowSheetContext"));
        e = e.isReflowSheet;
        return j.jsx(c("FDSPopover.react"), babelHelpers["extends"]({
            "aria-label": h._("__JHASH__6lD-XyRyuHe__JHASH__"),
            withArrow: e ? !1 : b
        }, a, {
            children: j.jsx(c("FDSPopoverLoadingStateContent.react"), {
                xstyle: d
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("CometEntryPointPopoverTrigger.react", ["BaseEntryPointPopoverTrigger.react", "FDSPopoverLoadingState.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.fallback;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback"]);
        return i.jsx(c("BaseEntryPointPopoverTrigger.react"), babelHelpers["extends"]({
            fallback: (b = b) != null ? b : i.jsx(c("FDSPopoverLoadingState.react"), {
                withArrow: !0
            })
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometPopover_DEPRECATED.react", ["FDSPopover.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        return i.jsx(c("FDSPopover.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98); /*FB_PKG_DELIM*/
__d("BaseAspectRatioContainer.react", ["react", "react-strict-dom", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.aspectRatio,
            e = a.children,
            f = a.contentStyle,
            g = a.testid;
        g = a.xstyle;
        if (b <= 0) throw c("unrecoverableViolation")("Aspect ratio must be a non-zero, positive number: " + b, "comet_ui");
        return i.jsx(d("react-strict-dom").html.div, {
            "data-testid": void 0,
            style: [j.container, g, j.dynamicTop(b)],
            children: e != null && i.jsx(d("react-strict-dom").html.div, {
                style: [j.content, f],
                children: e
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var j = {
        container: {
            height: "xqtp20y",
            position: "x1n2onr6",
            width: "xh8yej3",
            $$css: !0
        },
        content: {
            alignItems: "x1qjc9v5",
            borderBottomStyle: "x1q0q8m5",
            borderBottomWidth: "x1qhh985",
            borderEndStyle: "xu3j5b3",
            borderEndWidth: "xcfux6l",
            borderStartStyle: "x26u7qi",
            borderStartWidth: "xm0m39n",
            borderTopStyle: "x13fuv20",
            borderTopWidth: "x972fbf",
            bottom: "x1ey2m1c",
            boxSizing: "x9f619",
            display: "x78zum5",
            flexDirection: "xdt5ytf",
            flexGrow: "x1iyjqo2",
            flexShrink: "xs83m0k",
            end: "xds687c",
            start: "x17qophe",
            left: null,
            right: null,
            justifyContent: "x1qughib",
            marginBottom: "xat24cr",
            marginEnd: "x11i5rnm",
            marginStart: "x1mh8g0r",
            marginTop: "xdj266r",
            minHeight: "x2lwn1j",
            minWidth: "xeuugli",
            paddingBottom: "x18d9i69",
            paddingEnd: "x4uap5",
            paddingStart: "xkhd6sd",
            paddingTop: "xexx8yu",
            position: "x10l6tqk",
            top: "x13vifvy",
            zIndex: "x1ja2u2z",
            $$css: !0
        },
        dynamicTop: function(a) {
            return [{
                paddingTop: 100 / a + "%" == null ? null : "xmyip4h",
                $$css: !0
            }, {
                "--paddingTop": function(a) {
                    return typeof a === "number" ? a + "px" : a != null ? a : void 0
                }(100 / a + "%")
            }]
        }
    };
    g["default"] = a
}), 98);
__d("BaseHovercardTriggerWrapper.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            displayInlineBlock: {
                display: "x1rg5ohu",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.display;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["display"]);
        return b === "inline" ? j.jsx("span", babelHelpers["extends"]({}, a, {
            className: "xt0psk2"
        })) : j.jsx("div", babelHelpers["extends"]({}, a, {
            className: (h || (h = c("stylex")))(b === "inline-block" && k.displayInlineBlock)
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseNestedHovercardContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(!1);
    c = b;
    g["default"] = c
}), 98);
__d("BaseSuppressHovercards", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = i.createContext(!1);

    function a(a) {
        a = a.children;
        return i.jsx(k.Provider, {
            value: !0,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return j(k)
    }
    g.BaseSuppressHovercardsContext = k;
    g.BaseSuppressHovercardsProvider = a;
    g.useIsHovercardSuppressed = b
}), 98);
__d("HovercardInteractionPreference", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        DISABLED: 1,
        ENABLED_ON_HOVER: 2,
        ENABLED_ON_CLICK: 3
    });
    c = a;
    f["default"] = c
}), 66);
__d("CometHovercardSettingsContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        hovercardInteractionPreference: 2,
        setHovercardInteractionPreference: c("emptyFunction"),
        shouldShowHovercardNUX: !1
    });
    g["default"] = b
}), 98);
__d("useBaseHovercardTrigger", ["BaseContextualLayer.react", "BaseHovercardTriggerWrapper.react", "CometErrorBoundary.react", "CometHeroInteractionContextPassthrough.react", "CometPlaceholder.react", "FocusInertRegion.react", "FocusWithinHandler.react", "HiddenSubtreeContextProvider.react", "clearTimeout", "focusScopeQueries", "react", "setTimeout", "stylex", "useCometDisplayTimingTrackerForInteraction", "useCometPrerenderer", "useDelayedState", "useFadeEffect"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useCallback,
        l = b.useEffect,
        m = b.useRef,
        n = b.useState,
        o = 300,
        p = 100,
        q = {
            disablePointerEvents: {
                pointerEvents: "x47corl",
                $$css: !0
            },
            hovercard: {
                opacity: "xg01cxk",
                transitionDuration: "x1ebt8du",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1dhq9h",
                $$css: !0
            },
            hovercardVisible: {
                opacity: "x1hc1fzr",
                transitionDuration: "xhb22t3",
                transitionTimingFunction: "xls3em1",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.children,
            e = a.display,
            f = a.fallback,
            g = a.onLoadEntryPoint,
            i = a.onVisibilityChange,
            r = a.showDelay,
            s = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "display", "fallback", "onLoadEntryPoint", "onVisibilityChange", "showDelay"]);
        a = c("useDelayedState")(!1);
        var t = a[0],
            u = a[1];
        a = n(!1);
        var v = a[0],
            w = a[1];
        a = n(!1);
        var x = a[0],
            y = a[1];
        a = n(!1);
        var z = a[0],
            A = a[1];
        a = n(!1);
        var B = a[0],
            C = a[1],
            D = z && B && !x,
            E = m(null),
            F = m(null),
            G = m(null),
            H = c("useCometDisplayTimingTrackerForInteraction")("HoverCard"),
            I = k(function() {
                u(!1), w(!1), y(!0)
            }, [u]),
            J = k(function(a) {
                a.key === "Escape" && I()
            }, [I]),
            K = t || v || D,
            L = m(K);
        l(function() {
            L.current !== K && (i && i(K)), L.current = K
        }, [K, i]);
        a = c("useFadeEffect")(K);
        var M = a[0],
            N = a[1],
            O = a[2];
        z = c("useCometPrerenderer")("tooltip", K);
        B = z[0].shouldPrerender;
        var P = B === void 0 ? !1 : B,
            Q = z[1],
            R = z[2],
            S = k(function() {
                g && g()
            }, [g]),
            T = function(a) {
                if (t) c("clearTimeout")(E.current);
                else {
                    var b;
                    u(!0, (b = r) != null ? b : o);
                    S()
                }!D && !v && Q(a)
            },
            U = function() {
                E.current = c("setTimeout")(function() {
                    u(!1)
                }, p), R()
            },
            V = function() {
                w(!1)
            },
            W = function() {
                w(!1)
            },
            X = function() {
                v || (w(!0), S())
            },
            Y = function() {
                y(!1), S()
            };
        x = function(a) {
            return j.jsxs(c("BaseHovercardTriggerWrapper.react"), {
                display: e,
                onKeyDown: J,
                onMouseEnter: T,
                onMouseLeave: U,
                onTouchCancel: V,
                onTouchEnd: W,
                onTouchStart: X,
                children: [j.jsx(c("FocusWithinHandler.react"), {
                    onFocusChange: A,
                    onFocusVisibleChange: C,
                    onFocusWithin: Y,
                    children: b(F)
                }), (D || v || P || M) && j.jsx(c("CometHeroInteractionContextPassthrough.react"), {
                    clear: !0,
                    children: j.jsx(c("CometErrorBoundary.react"), {
                        children: j.jsx(c("CometPlaceholder.react"), {
                            fallback: null,
                            name: "HovercardTriggerPopover",
                            children: j.jsx(c("BaseContextualLayer.react"), babelHelpers["extends"]({
                                align: "middle",
                                contextRef: F,
                                hidden: !K && P,
                                imperativeRef: G,
                                ref: H,
                                xstyle: !K && M ? q.disablePointerEvents : void 0
                            }, s, {
                                children: j.jsx(c("HiddenSubtreeContextProvider.react"), {
                                    isHidden: !K && P,
                                    children: j.jsx("div", {
                                        className: (h || (h = c("stylex")))(q.hovercard, N && q.hovercardVisible),
                                        ref: O,
                                        children: j.jsx(c("FocusInertRegion.react"), {
                                            focusQuery: d("focusScopeQueries").tabbableScopeQuery,
                                            children: f != null ? j.jsx(c("CometPlaceholder.react"), {
                                                fallback: f,
                                                children: a
                                            }) : a
                                        })
                                    })
                                })
                            }))
                        })
                    })
                })]
            })
        };
        return [x, I]
    }
    g["default"] = a
}), 98);
__d("BaseHovercardTrigger.react", ["BaseHovercardTriggerWrapper.react", "BaseNestedHovercardContext.react", "BaseSuppressHovercards", "CometHovercardSettingsContext", "CometRelay", "react", "useBaseHovercardTrigger", "useCometRelayEntrypointContextualEnvironmentProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useContext,
        l = b.useRef,
        m = {};

    function n(a) {
        var b = a.popoverEntryPoint,
            e = a.popoverOtherProps;
        e = e === void 0 ? m : e;
        var f = a.popoverProps;
        a.preventNested;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["popoverEntryPoint", "popoverOtherProps", "popoverProps", "preventNested"]);
        var g = c("useCometRelayEntrypointContextualEnvironmentProvider")();
        g = d("CometRelay").useEntryPointLoader(g, b);
        b = g[0];
        var h = g[1];
        g = j(function() {
            h(f)
        }, [h, f]);
        a = c("useBaseHovercardTrigger")(babelHelpers["extends"]({}, a, {
            onLoadEntryPoint: g
        }));
        g = a[0];
        return g(i.jsx(i.Fragment, {
            children: b != null && i.jsx(d("CometRelay").EntryPointContainer, {
                entryPointReference: b,
                props: e
            })
        }))
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.preventNested;
        b = b === void 0 ? !1 : b;
        var e = babelHelpers.objectWithoutPropertiesLoose(a, ["preventNested"]),
            f = k(c("CometHovercardSettingsContext"));
        f = f.hovercardInteractionPreference;
        var g = k(c("BaseNestedHovercardContext.react"));
        g = d("BaseSuppressHovercards").useIsHovercardSuppressed() || g || f === 1;
        f = l(null);
        return g ? i.jsx(c("BaseHovercardTriggerWrapper.react"), {
            display: a.display,
            children: a.children(f)
        }) : i.jsx(c("BaseNestedHovercardContext.react").Provider, {
            value: b,
            children: i.jsx(n, babelHelpers["extends"]({}, e))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("Dots3HorizontalFilled24.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs("svg", babelHelpers["extends"]({
            viewBox: "0 0 24 24",
            width: "1em",
            height: "1em",
            fill: "currentColor"
        }, a, {
            children: [a.title != null && i.jsx("title", {
                children: a.title
            }), a.children != null && i.jsx("defs", {
                children: a.children
            }), i.jsx("circle", {
                cx: 12,
                cy: 12,
                r: 2.5
            }), i.jsx("circle", {
                cx: 19.5,
                cy: 12,
                r: 2.5
            }), i.jsx("circle", {
                cx: 4.5,
                cy: 12,
                r: 2.5
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("FDSAspectRatioContainer.react", ["BaseAspectRatioContainer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");
    g["default"] = c("BaseAspectRatioContainer.react")
}), 98);
__d("RecoverableViolation.react", ["react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useRef;

    function a(a) {
        var b = a.errorMessage,
            d = a.errorObject,
            e = a.projectName,
            f = j(!1);
        i(function() {
            f.current || (c("recoverableViolation")(b, e, d), f.current = !0)
        });
        return null
    }
    g["default"] = a
}), 98);
__d("XCometStoriesControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/stories/{?bucket_id}/{?card_id}/", Object.freeze({
        view_single: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("translatedServerString", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f["default"] = a
}), 66); /*FB_PKG_DELIM*/
__d("ActorURI", ["ActorURIConfig", "URI"], (function(a, b, c, d, e, f, g) {
    var h;

    function a(a, b) {
        return new(h || (h = c("URI")))(a).addQueryData(c("ActorURIConfig").PARAMETER_ACTOR, b)
    }
    g.create = a;
    g.PARAMETER_ACTOR = c("ActorURIConfig").PARAMETER_ACTOR
}), 98);
__d("MercuryIDs", ["gkx"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {
        isValid: function(a) {
            return a == null || a === "" || typeof a !== "string" ? !1 : /^\w{3,12}:.+/.test(a)
        },
        isValidThreadID: function(a) {
            if (!g.isValid(a)) return !1;
            a = g.tokenize(a);
            switch (a.type) {
                case "user":
                case "support":
                case "thread":
                case "root":
                    return !0;
                default:
                    return (a.type === "pending" || a.type === "group") && !b("gkx")("21040") ? !0 : !1
            }
        },
        tokenize: function(a) {
            if (a == null || a === "" || !g.isValid(a)) throw new Error("bad_id_format " + String(a));
            var b = a.indexOf(":");
            return {
                type: a.substr(0, b),
                value: a.substr(b + 1)
            }
        },
        getUserIDFromParticipantID: function(a) {
            if (!g.isValid(a)) throw new Error("bad_id_format " + a);
            a = g.tokenize(a);
            var b = a.type;
            a = a.value;
            return b === "fbid" ? a : null
        },
        getParticipantIDFromUserID: function(a) {
            if (isNaN(a)) throw new Error("Not a user ID: " + a);
            return "fbid:" + a
        },
        getUserIDFromThreadID: function(a) {
            return !this.isCanonical(a) ? null : this.tokenize(a).value
        },
        getThreadIDFromUserID: function(a) {
            return "user:" + a
        },
        getThreadIDFromThreadFBID: function(a) {
            return "thread:" + a
        },
        getThreadIDFromSupportInboxItemID: function(a) {
            return "support:" + a
        },
        getThreadFBIDFromThreadID: function(a) {
            return this.tokenize(a).value
        },
        getThreadKeyfromThreadIDUserID: function(a, b) {
            if (a == null || a === "" || !g.isValid(a)) throw new Error("bad_id_format " + String(a));
            var c = this.tokenize(a).type;
            a = this.tokenize(a).value;
            if (c !== "user") return "g" + a;
            c = "";
            var d = "";
            if (a.length !== b.length) a.length > b.length ? (c = a, d = b) : (c = b, d = a);
            else if (b === a) return b + "u" + a;
            else {
                var e = 0;
                while (e < a.length && e < b.length)
                    if (a[e] === b[e]) e++;
                    else {
                        a[e] > b[e] ? (c = a, d = b) : (c = b, d = a);
                        break
                    }
            }
            return d + "u" + c
        },
        getThreadIDFromParticipantID: function(a) {
            a = this.getUserIDFromParticipantID(a);
            return a ? this.getThreadIDFromUserID(a) : null
        },
        getParticipantIDFromFromThreadID: function(a) {
            a = this.getUserIDFromThreadID(a);
            return a ? this.getParticipantIDFromUserID(a) : null
        },
        getSupportInboxItemIDFromThreadID: function(a) {
            return this.tokenize(a).value
        },
        isCanonical: function(a) {
            return this.isValid(a) && this.tokenize(a).type === "user"
        },
        isGroupChat: function(a) {
            return this.isValid(a) && this.tokenize(a).type !== "user"
        },
        isLocalThread: function(a) {
            return this.isValid(a) && this.tokenize(a).type === "root"
        }
    };
    e.exports = g
}), null);
__d("SecurePostMessage", ["invariant"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "*";
    a = {
        sendMessageToSpecificOrigin: function(a, b, c, d) {
            c !== h || g(0, 21157), a.postMessage(b, c, d)
        },
        sendMessageForCurrentOrigin: function(a, b) {
            a.postMessage(b)
        },
        sendMessageAllowAnyOrigin_UNSAFE: function(a, b, c) {
            a.postMessage(b, h, c)
        }
    };
    e.exports = a
}), null);
__d("ZenonPeerID", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = "MW_PEER_ID";

    function a(a) {
        a.length > 0 || h(0, 33504);
        if (a === "MW_PEER_ID") return i;
        isNaN(a) === !1 || h(0, 33551, a);
        return a
    }

    function b(a) {
        return isNaN(a) || a === i ? null : a
    }
    g.ZenonMWPeerID = i;
    g.convertStringToPeerID = a;
    g.convertPeerIDForLogging = b
}), 98);
__d("bs_caml_array", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(b, c, a) {
        var d = new Array(a),
            e = 0;
        c = c;
        while (e < a) d[e] = b[c], e = e + 1 | 0, c = c + 1 | 0;
        return d
    }

    function g(a, b) {
        while (!0) {
            var c = b,
                d = a;
            if (!c) return d;
            b = c.tl;
            a = c.hd.length + d | 0;
            continue
        }
    }

    function h(a, b, c) {
        while (!0) {
            var d = c,
                e = b;
            if (!d) return;
            var f = d.hd,
                g = f.length;
            e = e;
            var h = 0;
            while (h < g) a[e] = f[h], e = e + 1 | 0, h = h + 1 | 0;
            c = d.tl;
            b = e;
            continue
        }
    }

    function b(a) {
        var b = g(0, a);
        b = new Array(b);
        h(b, 0, a);
        return b
    }

    function c(a, b, c) {
        if (b < 0 || b >= a.length) throw {
            RE_EXN_ID: "Invalid_argument",
            _1: "index out of bounds",
            Error: new Error()
        };
        a[b] = c
    }

    function d(a, b) {
        if (b < 0 || b >= a.length) throw {
            RE_EXN_ID: "Invalid_argument",
            _1: "index out of bounds",
            Error: new Error()
        };
        return a[b]
    }

    function e(a, b) {
        var c = new Array(a);
        for (var d = 0; d < a; ++d) c[d] = b;
        return c
    }

    function i(a) {
        var b = new Array(a);
        for (var c = 0; c < a; ++c) b[c] = 0;
        return b
    }

    function j(b, c, d, e, a) {
        if (e <= c) {
            for (var f = 0; f < a; ++f) d[f + e | 0] = b[f + c | 0];
            return
        }
        for (f = a - 1 | 0; f >= 0; --f) d[f + e | 0] = b[f + c | 0]
    }

    function k(a) {
        return a.slice(0)
    }
    f.dup = k;
    f.sub = a;
    f.concat = b;
    f.make = e;
    f.make_float = i;
    f.blit = j;
    f.get = d;
    f.set = c
}), null);
__d("bs_curry", ["bs_caml_array"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, c) {
        while (!0) {
            var d = c,
                e = a,
                f = e.length;
            f = f === 0 ? 1 : f;
            var h = d.length;
            h = f - h | 0;
            if (h === 0) return e.apply(null, d);
            if (h >= 0) return function(b, a) {
                return function(c) {
                    return g(b, a.concat([c]))
                }
            }(e, d);
            c = b("bs_caml_array").sub(d, f, -h | 0);
            a = e.apply(null, b("bs_caml_array").sub(d, 0, f));
            continue
        }
    }

    function h(a, b) {
        var c = a.length;
        if (c === 1) return a(b);
        else switch (c) {
            case 1:
                return a(b);
            case 2:
                return function(c) {
                    return a(b, c)
                };
            case 3:
                return function(c, d) {
                    return a(b, c, d)
                };
            case 4:
                return function(c, d, e) {
                    return a(b, c, d, e)
                };
            case 5:
                return function(c, d, e, f) {
                    return a(b, c, d, e, f)
                };
            case 6:
                return function(c, d, e, f, g) {
                    return a(b, c, d, e, f, g)
                };
            case 7:
                return function(c, d, e, f, g, h) {
                    return a(b, c, d, e, f, g, h)
                };
            default:
                return g(a, [b])
        }
    }

    function a(a) {
        var b = a.length;
        if (b === 1) return a;
        else return function(b) {
            return h(a, b)
        }
    }

    function i(a, b, c) {
        var d = a.length;
        if (d === 2) return a(b, c);
        else switch (d) {
            case 1:
                return g(a(b), [c]);
            case 2:
                return a(b, c);
            case 3:
                return function(d) {
                    return a(b, c, d)
                };
            case 4:
                return function(d, e) {
                    return a(b, c, d, e)
                };
            case 5:
                return function(d, e, f) {
                    return a(b, c, d, e, f)
                };
            case 6:
                return function(d, e, f, g) {
                    return a(b, c, d, e, f, g)
                };
            case 7:
                return function(d, e, f, g, h) {
                    return a(b, c, d, e, f, g, h)
                };
            default:
                return g(a, [b, c])
        }
    }

    function c(a) {
        var b = a.length;
        if (b === 2) return a;
        else return function(b, c) {
            return i(a, b, c)
        }
    }

    function j(a, b, c, d) {
        var e = a.length;
        if (e === 3) return a(b, c, d);
        else switch (e) {
            case 1:
                return g(a(b), [c, d]);
            case 2:
                return g(a(b, c), [d]);
            case 3:
                return a(b, c, d);
            case 4:
                return function(e) {
                    return a(b, c, d, e)
                };
            case 5:
                return function(e, f) {
                    return a(b, c, d, e, f)
                };
            case 6:
                return function(e, f, g) {
                    return a(b, c, d, e, f, g)
                };
            case 7:
                return function(e, f, g, h) {
                    return a(b, c, d, e, f, g, h)
                };
            default:
                return g(a, [b, c, d])
        }
    }

    function d(a) {
        var b = a.length;
        if (b === 3) return a;
        else return function(b, c, d) {
            return j(a, b, c, d)
        }
    }

    function k(a, b, c, d, e) {
        var f = a.length;
        if (f === 4) return a(b, c, d, e);
        else switch (f) {
            case 1:
                return g(a(b), [c, d, e]);
            case 2:
                return g(a(b, c), [d, e]);
            case 3:
                return g(a(b, c, d), [e]);
            case 4:
                return a(b, c, d, e);
            case 5:
                return function(f) {
                    return a(b, c, d, e, f)
                };
            case 6:
                return function(f, g) {
                    return a(b, c, d, e, f, g)
                };
            case 7:
                return function(f, g, h) {
                    return a(b, c, d, e, f, g, h)
                };
            default:
                return g(a, [b, c, d, e])
        }
    }

    function e(a) {
        var b = a.length;
        if (b === 4) return a;
        else return function(b, c, d, e) {
            return k(a, b, c, d, e)
        }
    }

    function l(a, b, c, d, e, f) {
        var h = a.length;
        if (h === 5) return a(b, c, d, e, f);
        else switch (h) {
            case 1:
                return g(a(b), [c, d, e, f]);
            case 2:
                return g(a(b, c), [d, e, f]);
            case 3:
                return g(a(b, c, d), [e, f]);
            case 4:
                return g(a(b, c, d, e), [f]);
            case 5:
                return a(b, c, d, e, f);
            case 6:
                return function(g) {
                    return a(b, c, d, e, f, g)
                };
            case 7:
                return function(g, h) {
                    return a(b, c, d, e, f, g, h)
                };
            default:
                return g(a, [b, c, d, e, f])
        }
    }

    function m(a) {
        var b = a.length;
        if (b === 5) return a;
        else return function(b, c, d, e, f) {
            return l(a, b, c, d, e, f)
        }
    }

    function n(a, b, c, d, e, f, h) {
        var i = a.length;
        if (i === 6) return a(b, c, d, e, f, h);
        else switch (i) {
            case 1:
                return g(a(b), [c, d, e, f, h]);
            case 2:
                return g(a(b, c), [d, e, f, h]);
            case 3:
                return g(a(b, c, d), [e, f, h]);
            case 4:
                return g(a(b, c, d, e), [f, h]);
            case 5:
                return g(a(b, c, d, e, f), [h]);
            case 6:
                return a(b, c, d, e, f, h);
            case 7:
                return function(g) {
                    return a(b, c, d, e, f, h, g)
                };
            default:
                return g(a, [b, c, d, e, f, h])
        }
    }

    function o(a) {
        var b = a.length;
        if (b === 6) return a;
        else return function(b, c, d, e, f, g) {
            return n(a, b, c, d, e, f, g)
        }
    }

    function p(a, b, c, d, e, f, h, i) {
        var j = a.length;
        if (j === 7) return a(b, c, d, e, f, h, i);
        else switch (j) {
            case 1:
                return g(a(b), [c, d, e, f, h, i]);
            case 2:
                return g(a(b, c), [d, e, f, h, i]);
            case 3:
                return g(a(b, c, d), [e, f, h, i]);
            case 4:
                return g(a(b, c, d, e), [f, h, i]);
            case 5:
                return g(a(b, c, d, e, f), [h, i]);
            case 6:
                return g(a(b, c, d, e, f, h), [i]);
            case 7:
                return a(b, c, d, e, f, h, i);
            default:
                return g(a, [b, c, d, e, f, h, i])
        }
    }

    function q(a) {
        var b = a.length;
        if (b === 7) return a;
        else return function(b, c, d, e, f, g, h) {
            return p(a, b, c, d, e, f, g, h)
        }
    }

    function r(a, b, c, d, e, f, h, i, j) {
        var k = a.length;
        if (k === 8) return a(b, c, d, e, f, h, i, j);
        else switch (k) {
            case 1:
                return g(a(b), [c, d, e, f, h, i, j]);
            case 2:
                return g(a(b, c), [d, e, f, h, i, j]);
            case 3:
                return g(a(b, c, d), [e, f, h, i, j]);
            case 4:
                return g(a(b, c, d, e), [f, h, i, j]);
            case 5:
                return g(a(b, c, d, e, f), [h, i, j]);
            case 6:
                return g(a(b, c, d, e, f, h), [i, j]);
            case 7:
                return g(a(b, c, d, e, f, h, i), [j]);
            default:
                return g(a, [b, c, d, e, f, h, i, j])
        }
    }

    function s(a) {
        var b = a.length;
        if (b === 8) return a;
        else return function(b, c, d, e, f, g, h, i) {
            return r(a, b, c, d, e, f, g, h, i)
        }
    }
    f.app = g;
    f._1 = h;
    f.__1 = a;
    f._2 = i;
    f.__2 = c;
    f._3 = j;
    f.__3 = d;
    f._4 = k;
    f.__4 = e;
    f._5 = l;
    f.__5 = m;
    f._6 = n;
    f.__6 = o;
    f._7 = p;
    f.__7 = q;
    f._8 = r;
    f.__8 = s
}), null);
__d("bs_belt_Option", ["bs_caml_option", "bs_curry"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, c) {
        if (a !== void 0 && c(b("bs_caml_option").valFromOption(a))) return a
    }

    function a(a, c) {
        return g(a, b("bs_curry").__1(c))
    }

    function h(a, c) {
        if (a !== void 0) return c(b("bs_caml_option").valFromOption(a))
    }

    function c(a, c) {
        return h(a, b("bs_curry").__1(c))
    }

    function d(a) {
        if (a !== void 0) return b("bs_caml_option").valFromOption(a);
        throw {
            RE_EXN_ID: "Not_found",
            Error: new Error()
        }
    }

    function i(a, c, d) {
        if (a !== void 0) return d(b("bs_caml_option").valFromOption(a));
        else return c
    }

    function e(a, c, d) {
        return i(a, c, b("bs_curry").__1(d))
    }

    function j(a, c) {
        if (a !== void 0) return b("bs_caml_option").some(c(b("bs_caml_option").valFromOption(a)))
    }

    function k(a, c) {
        return j(a, b("bs_curry").__1(c))
    }

    function l(a, c) {
        if (a !== void 0) return c(b("bs_caml_option").valFromOption(a))
    }

    function m(a, c) {
        return l(a, b("bs_curry").__1(c))
    }

    function n(a, c) {
        if (a !== void 0) return b("bs_caml_option").valFromOption(a);
        else return c
    }

    function o(a) {
        return a !== void 0
    }

    function p(a) {
        return a === void 0
    }

    function q(a, c, d) {
        if (a !== void 0)
            if (c !== void 0) return d(b("bs_caml_option").valFromOption(a), b("bs_caml_option").valFromOption(c));
            else return !1;
        else return c === void 0
    }

    function r(a, c, d) {
        return q(a, c, b("bs_curry").__2(d))
    }

    function s(a, c, d) {
        if (a !== void 0)
            if (c !== void 0) return d(b("bs_caml_option").valFromOption(a), b("bs_caml_option").valFromOption(c));
            else return 1;
        else if (c !== void 0) return -1;
        else return 0
    }

    function t(a, c, d) {
        return s(a, c, b("bs_curry").__2(d))
    }
    f.keepU = g;
    f.keep = a;
    f.forEachU = h;
    f.forEach = c;
    f.getExn = d;
    f.mapWithDefaultU = i;
    f.mapWithDefault = e;
    f.mapU = j;
    f.map = k;
    f.flatMapU = l;
    f.flatMap = m;
    f.getWithDefault = n;
    f.isSome = o;
    f.isNone = p;
    f.eqU = q;
    f.eq = r;
    f.cmpU = s;
    f.cmp = t
}), null);
__d("differenceSets", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = new Set();
        for (var c = arguments.length, d = new Array(c > 1 ? c - 1 : 0), e = 1; e < c; e++) d[e - 1] = arguments[e];
        FIRST: for (var f = a, g = Array.isArray(f), h = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var i;
            if (g) {
                if (h >= f.length) break;
                i = f[h++]
            } else {
                h = f.next();
                if (h.done) break;
                i = h.value
            }
            var j = i;
            for (var k = 0; k < d.length; k++) {
                var l = d[k];
                if (l.has(j)) continue FIRST
            }
            b.add(j)
        }
        return b
    }
    f["default"] = a
}), 66);
__d("mapMapToArray", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        var c = [],
            d = 0;
        for (var e = a, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var h;
            if (f) {
                if (g >= e.length) break;
                h = e[g++]
            } else {
                g = e.next();
                if (g.done) break;
                h = g.value
            }
            h = h;
            var i = h[0];
            h = h[1];
            c.push(b(h, i, d, a));
            d++
        }
        return c
    }
    f["default"] = a
}), 66);
__d("mapSet", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        var c = new Set();
        for (var a = a, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= a.length) break;
                f = a[e++]
            } else {
                e = a.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            c.add(b(f))
        }
        return c
    }
    f["default"] = a
}), 66);
__d("useEffectOnce", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useEffect;

    function a(a) {
        return i(a, [])
    }
    g["default"] = a
}), 98);
__d("useForceUpdate", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useReducer;

    function a() {
        var a = i(function(a) {
            return a + 1
        }, 0);
        a[0];
        a = a[1];
        return a
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("Int64Hooks", ["I64", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    f = h || d("react");
    var j = f.useCallback,
        k = f.useEffect,
        l = f.useMemo;

    function m(a) {
        var b = [];
        for (var a = a, c = Array.isArray(a), d = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var e;
            if (c) {
                if (d >= a.length) break;
                e = a[d++]
            } else {
                d = a.next();
                if (d.done) break;
                e = d.value
            }
            e = e;
            Array.isArray(e) && e.length === 2 && Number.isInteger(e[0]) && Number.isInteger(e[1]) ? b.push(e[0], e[1]) : b.push(e, void 0)
        }
        return b
    }

    function a(a, b) {
        return k(a, b == null ? null : m(b))
    }

    function b(a, b) {
        return j(a, b == null ? null : m(b))
    }

    function n(a, b) {
        return l(a, b == null ? null : m(b))
    }

    function c(a, b) {
        return n(function() {
            return a
        }, [a == null].concat(b.map(function(b) {
            return a == null ? void 0 : a[b]
        })))
    }

    function o(a, b) {
        if (a === b) return a !== 0 || b !== 0 || 1 / a === 1 / b;
        else {
            var c = (i || (i = d("I64"))).cast(a);
            if (c != null) {
                var e = (i || (i = d("I64"))).cast(b);
                if (e != null) return (i || (i = d("I64"))).equal(c, e)
            }
            return a !== a && b !== b
        }
    }
    var p = Object.prototype.hasOwnProperty;

    function e(a, b) {
        if (o(a, b)) return !0;
        if (typeof a !== "object" || a === null || typeof b !== "object" || b === null) return !1;
        var c = Object.keys(a),
            d = Object.keys(b);
        if (c.length !== d.length) return !1;
        for (d = 0; d < c.length; d++)
            if (!p.call(b, c[d]) || !o(a[c[d]], b[c[d]])) return !1;
        return !0
    }
    g.useEffectInt64 = a;
    g.useCallbackInt64 = b;
    g.useMemoInt64 = n;
    g.usePickInt64 = c;
    g.mostlyShallowEqual = e
}), 98);
__d("LSFeatureLimitsType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        READ_ONLY: 1,
        GENERIC_READ_ONLY_BLOCK: 2,
        MESSAGE_SEND: 4,
        MESSENGER_ONLY_ACCOUNTS_READ_ONLY_BLOCK: 8,
        MESSAGE_SEND_PRIVATE: 16,
        MESSAGE_SEND_PUBLIC: 32,
        MESSAGE_SEND_FROM_PAGE: 64,
        COMMERCE_MESSAGE_SEND: 128,
        PAGE_MESSAGING: 256
    });
    f["default"] = a
}), 66);
__d("LSMarkThreadRead", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(9).fetch([
                [
                    [a[1]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[1]) && b.i64.gt(a[0], c.lastReadWatermarkTimestampMs)
            }), function(b) {
                var c = b.update;
                b.item;
                return c({
                    lastReadWatermarkTimestampMs: a[0]
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxMarkThreadReadStoredProcedure";
    e.exports = a
}), null);
__d("LSOptimisticMarkThreadReadV2", ["LSIssueNewTask", "LSMarkThreadRead"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(d) {
                return c.storedProcedure(b("LSMarkThreadRead"), a[1], a[0])
            }, function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var e = a.done;
                    a = a.value;
                    return e ? d[0] = c.i64.cast([0, 1]) : (b = a.item, d[6] = b.syncGroup, c.i64.neq(d[6], void 0) ? d[5] = d[6] : d[5] = c.i64.cast([0, 1]), d[0] = d[5])
                })
            }, function(e) {
                return d[2] = new c.Map(), d[2].set("thread_id", a[0]), d[2].set("last_read_watermark_ts", a[1]), d[2].set("sync_group", d[0]), d[3] = d[2].get("thread_id"), d[2], d[4] = c.toJSON(d[2]), c.storedProcedure(b("LSIssueNewTask"), c.i64.to_string(d[3]), c.i64.cast([0, 21]), d[4], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxOptimisticMarkThreadReadV2StoredProcedure";
    e.exports = a
}), null);
__d("MWChatMessageId", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        if (a.type === "sent") return a.value.messageId
    }

    function b(a) {
        if (a.type === "sent") return a.value.threadId
    }

    function c(a) {
        if (a.type === "sent") return a.value.timestamp
    }

    function e(a, b, c) {
        return {
            type: "sent",
            value: {
                messageId: b,
                threadId: (h || (h = d("I64"))).of_string(a),
                timestamp: h.of_string(c)
            }
        }
    }

    function f(a) {
        return {
            type: "sent",
            value: {
                messageId: a,
                threadId: (h || (h = d("I64"))).zero,
                timestamp: h.zero
            }
        }
    }
    var i = {
        type: "sent",
        value: {
            messageId: "",
            threadId: (h || (h = d("I64"))).zero,
            timestamp: h.zero
        }
    };
    g.getMessageId = a;
    g.getThreadId = b;
    g.getTimestamp = c;
    g.makeSent = e;
    g.emptyForExamplesWithId = f;
    g.emptyForExamples = i
}), 98);
__d("MWLSThread", ["FBLogger", "Promise", "ReQL", "ReQLSuspense", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = function(a) {
        return a
    };

    function a(a, b) {
        b === void 0 && (b = j);
        var e = (i || (i = c("useReStore")))();
        return d("ReQLSuspense").useFirst(function() {
            return a != null ? d("ReQL").fromTableAscending(e.tables.threads).getKeyRange(a).map(function(a) {
                return b(a)
            }) : d("ReQL").empty()
        }, [e, a], f.id + ":29")
    }

    function e(a, b) {
        b === void 0 && (b = j);
        var e = (i || (i = c("useReStore")))();
        return d("ReQLSuspense").useFirstExn(function() {
            return d("ReQL").fromTableAscending(e.tables.threads).getKeyRange(a).map(function(a) {
                var c;
                return (c = b == null ? void 0 : b(a)) != null ? c : a
            })
        }, [e, a], f.id + ":48")
    }

    function k(a, b, e) {
        e === void 0 && (e = j);
        a = d("ReQLSuspense").first(d("ReQL").fromTableAscending(a.tables.threads).getKeyRange(b), f.id + ":65");
        if (!a) throw c("FBLogger")("messenger_web").mustfixThrow("thread is null/undefined");
        return e(a)
    }

    function l(a, c, e) {
        e === void 0 && (e = j);
        return c != null ? d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.tables.threads).getKeyRange(c)).then(function(a) {
            return a ? e(a) : void 0
        }) : (h || (h = b("Promise"))).resolve(void 0)
    }
    g.useThread = a;
    g.useThreadExn = e;
    g.getThreadExn = k;
    g.getThreadAsync = l
}), 98);
__d("MWPFeatureLimitedData", ["I64", "Int64Hooks", "LSFeatureLimitsType", "LSIntEnum", "LSMessagingThreadTypeUtil", "ReQL", "ReQLSuspense", "ServerTime", "gkx", "useReStore", "useServerTime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = [(i || (i = d("LSIntEnum"))).ofNumber(c("LSFeatureLimitsType").READ_ONLY), i.ofNumber(c("LSFeatureLimitsType").GENERIC_READ_ONLY_BLOCK), i.ofNumber(c("LSFeatureLimitsType").MESSAGE_SEND)];

    function l(a) {
        for (var b = 0; b < k.length; b++) {
            var c = k[b];
            if ((j || (j = d("I64"))).equal(c, a.type_)) return !0
        }
        return !1
    }

    function m(a, b) {
        return (j || (j = d("I64"))).equal((i || (i = d("LSIntEnum"))).ofNumber(c("LSFeatureLimitsType").MESSAGE_SEND_PUBLIC), a.type_) && d("LSMessagingThreadTypeUtil").isPublicCMThread(b) && c("gkx")("26351")
    }

    function n(a, b) {
        return (j || (j = d("I64"))).equal((i || (i = d("LSIntEnum"))).ofNumber(c("LSFeatureLimitsType").MESSAGE_SEND_PRIVATE), a.type_) && d("LSMessagingThreadTypeUtil").isPrivateThread(b) && c("gkx")("26352")
    }
    var o = function(a) {
        var b = (j || (j = d("I64"))).of_float(d("ServerTime").getMillis() / 1e3);
        return d("ReQL").fromTableAscending(a.tables.feature_limits).filter(function(a) {
            return l(a) && (j || (j = d("I64"))).gt(a.expirationTimestampSeconds, b)
        })
    };

    function p(a, b) {
        var e = (j || (j = d("I64"))).of_float(c("useServerTime")().valueOf() / 1e3);
        return d("Int64Hooks").useMemoInt64(function() {
            return d("ReQL").fromTableAscending(a.tables.feature_limits).filter(function(a) {
                return (b != null ? l(a) || m(a, b) || n(a, b) : l(a)) && (j || (j = d("I64"))).gt(a.expirationTimestampSeconds, e)
            })
        }, [e, a, b])
    }

    function a() {
        var a = (h || (h = c("useReStore")))();
        return d("ReQLSuspense").useFirst(function() {
            return o(a)
        }, [a], f.id + ":129")
    }

    function b(a) {
        var b = (h || (h = c("useReStore")))(),
            e = p(b, a);
        return d("ReQLSuspense").useFirst(function() {
            return e
        }, [e], f.id + ":138")
    }
    g.readonlyFeatureLimitQuery = o;
    g.useReadOnlyFeatureLimitData = a;
    g.useReadOnlyFeatureLimitDataWithThreadType = b
}), 98);
__d("MWThreadKey.react", ["I64", "Int64Hooks", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react")),
        k = h,
        l = k.createContext,
        m = k.useContext,
        n = l(void 0);

    function o(a) {
        var b = a.children,
            e = a.id;
        a = a.isSubthread;
        a = a === void 0 ? !1 : a;
        var f = m(n),
            g = d("Int64Hooks").useMemoInt64(function() {
                return e
            }, [e]);
        if (f != null && !a) throw c("unrecoverableViolation")("You can't nest MWThreadKey in another MWThreadKey. This will cause SEVs as things might think they're in the wrong thread", "messenger_web_messaging");
        return j.jsx(n.Provider, {
            value: g,
            children: b
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.children,
            c = a.id;
        a = a.isSubthread;
        a = a === void 0 ? !1 : a;
        return c != null ? j.jsx(o, {
            id: (i || (i = d("I64"))).of_string(c),
            isSubthread: a,
            children: b
        }) : j.jsx(j.Fragment, {
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return m(n)
    }

    function e() {
        var a = m(n);
        if (a != null) return a;
        throw c("unrecoverableViolation")("Tried to get a thread key when there was none", "messenger_web_ia")
    }
    g.MWThreadKeyProvider = o;
    g.XPlatThreadKeyProvider = a;
    g.useMWThreadKeyMemoized = b;
    g.useMWThreadKeyMemoizedExn = e
}), 98);
__d("ThreadStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        DEFAULT: 0,
        PAUSED: 1,
        PAUSED_AND_UPGRADED_TO_COMMUNITY: 2,
        UPGRADED_TO_COMMUNITY_AND_TO_BE_PAUSED: 3
    });
    f["default"] = a
}), 66);
__d("VirtualizationContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useIsReadOnlyFeatureLimitedWithThreadType", ["MWPFeatureLimitedData", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = d("MWPFeatureLimitedData").useReadOnlyFeatureLimitDataWithThreadType(a);
        if (a != null) return c("gkx")("24070");
        else return !1
    }
    g["default"] = a
}), 98);
__d("useIsSecureMessage", ["LSMessagingThreadTypeUtil", "ReQL", "ReQLSuspense"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c) {
        var e;
        e = (e = d("ReQLSuspense").useFirst(function() {
            return b == null ? d("ReQL").empty() : d("ReQL").fromTableAscending(a.tables.threads, ["threadType"]).getKeyRange(b.threadKey).map(function(a) {
                a = a.threadType;
                return a
            })
        }, [a, b], f.id + ":37")) != null ? e : c.fallbackThreadType;
        if (e == null) {
            return (c = c.fallbackIsSecure) != null ? c : !1
        }
        return d("LSMessagingThreadTypeUtil").isArmadilloSecure(e)
    }
    g["default"] = a
}), 98);
__d("useMWXEntryPointDialog", ["cr:5835", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");

    function a(a, c, d, e, f) {
        d === void 0 && (d = "button");
        return b("cr:5835")(a, c, d, e, f)
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometBlurredBackgroundImage.react", ["CometBackgroundImage.react", "XPlatReactEnvironment", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            imageContainer: {
                filter: "xtea3wc",
                height: "xu1mrb",
                $$css: !0
            },
            imageContainerVR: {
                transform: "x15f76sd",
                $$css: !0
            },
            imageContainerWeb: {
                transform: "x1yyh9jt",
                width: "x1jx8tsq",
                $$css: !0
            },
            root: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                height: "x5yr21d",
                justifyContent: "xl56j7k",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                width: "xh8yej3",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["xstyle"]);
        return i.jsx(d("react-strict-dom").html.div, {
            style: [j.root, b],
            children: i.jsx(d("react-strict-dom").html.div, {
                style: [j.imageContainer, d("XPlatReactEnvironment").isWeb() ? j.imageContainerWeb : j.imageContainerVR],
                children: i.jsx(c("CometBackgroundImage.react"), babelHelpers["extends"]({}, a))
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("FDSImageCover.react", ["BaseImage_DEPRECATED.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    e = h;
    var j = e.useCallback,
        k = e.useRef,
        l = e.useState;
    d = function() {
        var a = document.documentElement;
        return a == null ? !0 : Boolean("objectFit" in a.style)
    }();

    function a(a) {
        a.alt;
        var b = a.loading,
            d = a.onError,
            e = a.onLoad,
            f = a.src,
            g = a.style;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["alt", "loading", "onError", "onLoad", "src", "style"]);
        var h = l(null),
            m = h[0],
            n = h[1],
            o = k();
        h = j(function() {
            var a = o.current;
            if (a == null || !(a instanceof HTMLImageElement) || typeof a.src !== "string") return;
            n(a.src);
            e != null && e()
        }, [e]);
        return m != null ? i.jsx("div", {
            className: "x1rg5ohu x5yr21d xl1xv1r xh8yej3",
            style: babelHelpers["extends"]({
                backgroundImage: "url(" + m + ")",
                backgroundPosition: "center center",
                backgroundSize: "cover"
            }, g)
        }) : i.jsx(c("BaseImage_DEPRECATED.react"), babelHelpers["extends"]({}, a, {
            className: "xqtp20y xnalus7",
            loading: b || void 0,
            onError: d,
            onLoad: h,
            ref: o,
            src: f,
            style: g
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        return i.jsx(c("BaseImage_DEPRECATED.react"), babelHelpers["extends"]({
            className: "x1rg5ohu x5yr21d xl1xv1r xh8yej3"
        }, a))
    }
    b.displayName = b.name + " [from " + f.id + "]";
    e = d ? b : a;
    g["default"] = e
}), 98);
__d("MWVideoPlayerControllerContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        ref: {
            current: null
        }
    });
    g["default"] = b
}), 98);
__d("MWXIconChevronLeft", ["MWXSvgIcon", "SVGIcon", "cr:12366", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12366")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("getErrorNameFromMediaErrorCode", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case 1:
                return "MEDIA_ERR_ABORTED";
            case 2:
                return "MEDIA_ERR_NETWORK";
            case 3:
                return "MEDIA_ERR_DECODE";
            case 4:
                return "MEDIA_ERR_SRC_NOT_SUPPORTED";
            default:
                return "MEDIA_ERR_UNKNOWN_" + ((a = a) != null ? a : "UNDEFINED")
        }
    }
    f["default"] = a
}), 66);
__d("MWXVideoStatusListener.react", ["getErrorNameFromMediaErrorCode", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useEffect;

    function a(a) {
        var b = a.onError,
            d = a.onLoad,
            e = a.videoRef;
        i(function() {
            var a = e == null ? void 0 : e.current;

            function f() {
                d == null ? void 0 : d()
            }

            function g(a) {
                a = a.currentTarget;
                a = a.error;
                a = c("getErrorNameFromMediaErrorCode")(a == null ? void 0 : a.code);
                b == null ? void 0 : b(a)
            }
            if ((a == null ? void 0 : a.readyState) != null && a.readyState >= 2) {
                f();
                return
            }
            a == null ? void 0 : a.addEventListener("canplay", f);
            a == null ? void 0 : a.addEventListener("error", g);
            return function() {
                a == null ? void 0 : a.removeEventListener("canplay", f), a == null ? void 0 : a.removeEventListener("error", g)
            }
        }, [b, d, e]);
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MessengerBlurpleLogoSvg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.cloneElement,
        k = b.useId,
        l = b.useMemo;

    function a(a) {
        var b = a.height;
        a = a.width;
        a = (a = a) != null ? a : "80";
        b = (b = b) != null ? b : "80";
        var c = k(),
            d = l(function() {
                return j(i.jsx("path", {}), {
                    clipRule: "evenodd",
                    d: "M40 .914C17.995.914.937 17.033.937 38.804c0 11.389 4.668 21.23 12.268 28.026a3.12 3.12 0 011.05 2.227l.212 6.95c.068 2.215 2.358 3.658 4.386 2.763l7.753-3.423a3.115 3.115 0 012.087-.153A42.602 42.602 0 0040 76.695c22.005 0 39.063-16.118 39.063-37.89C79.063 17.033 62.005.915 40 .915z",
                    fill: "url(#" + (c + ")"),
                    fillRule: "evenodd",
                    suppressHydrationWarning: !0
                })
            }, [c]),
            e = l(function() {
                return j(i.jsx("radialGradient", {}), {
                    children: i.jsxs(i.Fragment, {
                        children: [i.jsx("stop", {
                            stopColor: "#09F"
                        }), i.jsx("stop", {
                            offset: "0.61",
                            stopColor: "#A033FF"
                        }), i.jsx("stop", {
                            offset: "0.935",
                            stopColor: "#FF5280"
                        }), i.jsx("stop", {
                            offset: "1",
                            stopColor: "#FF7061"
                        })]
                    }),
                    cx: "0",
                    cy: "0",
                    gradientTransform: "rotate(-57.092 80.25 24.628) scale(85.1246)",
                    gradientUnits: "userSpaceOnUse",
                    id: c,
                    r: "1",
                    suppressHydrationWarning: !0
                })
            }, [c]);
        return i.jsxs("svg", {
            fill: "none",
            height: b,
            viewBox: " 0 0 80 80",
            width: a,
            children: [d, i.jsx("path", {
                clipRule: "evenodd",
                d: "M16.543 49.886L28.018 31.68a5.86 5.86 0 018.472-1.563l9.127 6.844a2.343 2.343 0 002.823-.008L60.765 27.6c1.645-1.248 3.793.72 2.692 2.467L51.982 48.272a5.86 5.86 0 01-8.472 1.563l-9.127-6.845a2.344 2.344 0 00-2.823.01l-12.325 9.354c-1.646 1.248-3.793-.72-2.692-2.467z",
                fill: "#fff",
                fillRule: "evenodd"
            }), i.jsx("defs", {
                children: e
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getVideoPlayerUserFacingErrorMessageFromError", ["fbt", "gkx"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function i(a) {
        return c("gkx")("24345") && a.message.toLowerCase().indexOf("audio_renderer_error") >= 0
    }

    function j(a) {
        return a.message.indexOf("DEVICE_CERTIFICATE_REVOKED") >= 0
    }

    function k(a) {
        return a.name.indexOf("VideoImplementationsDashManifestUnsupportedCodecs") >= 0 || a.name.indexOf("VideoImplementationsMediaSourceUnsupported") >= 0
    }

    function l(a) {
        return a.name === "OZ_NETWORK" && a.message.includes("CDN URL expired")
    }

    function a(a) {
        var b = null;
        i(a) ? b = h._("__JHASH__32piJ10frlX__JHASH__") : j(a) ? b = h._("__JHASH__6MAWOMXczk1__JHASH__") : k(a) ? b = h._("__JHASH__EuR8fzpxUQU__JHASH__") : l(a) && (b = h._("__JHASH__NrJkVWZ6st1__JHASH__"));
        return b
    }
    g["default"] = a
}), 226);
__d("useMWMediaViewerOpenQPLLogger", ["qpl", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useCallback,
        j = c("requireDeferred")("QPLUserFlow").__setRef("useMWMediaViewerOpenQPLLogger"),
        k = c("qpl")._(25298743, "1403"),
        l = 6e3 * 10;

    function a() {
        var a = i(function(a) {
                var b = a.attachmentType,
                    c = a.entryPoint;
                a = a.isSecure;
                var d = {
                    attachmentType: b,
                    entryPoint: c,
                    isSecure: ((b = a) != null ? b : !1).toString()
                };
                j.onReadyImmediately(function(a) {
                    a.start(k, {
                        annotations: {
                            string: babelHelpers["extends"]({}, d)
                        },
                        cancelOnUnload: !0,
                        timeoutInMs: l
                    })
                })
            }, []),
            b = i(function(a) {
                j.onReadyImmediately(function(b) {
                    b.endSuccess(k, {
                        annotations: a
                    })
                })
            }, []),
            c = i(function(a) {
                j.onReadyImmediately(function(b) {
                    b.endCancel(k, {
                        cancelReason: a
                    })
                })
            }, []);
        return {
            endCancel: c,
            endSuccess: b,
            startFlow: a
        }
    }
    g.useMWMediaViewerOpenQPLLogger = a
}), 98); /*FB_PKG_DELIM*/
__d("CometTypeaheadInternalLayoutContextualStrategy.react", ["CometContextualLayer.react", "CometTypeaheadInputStrategyEventListener.react", "CometTypeaheadViewStrategyEventListener.react", "cometHandleHighlightDropOnMouseLeave", "react", "stylex", "useCometInternalTypeaheadState", "xplatToDOMRef"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useRef;

    function a(a) {
        var b = a.contextualProps;
        b = b === void 0 ? {} : b;
        var e = b.align;
        e = e === void 0 ? "stretch" : e;
        var f = b.position;
        f = f === void 0 ? "below" : f;
        b = babelHelpers.objectWithoutPropertiesLoose(b, ["align", "position"]);
        var g = a.description,
            i = a.errorMessage,
            l = a.extraLayoutProps,
            m = l.ariaProps,
            n = m.ariaDescribedByProps,
            o = m.ariaInputProps,
            p = m.ariaViewProps;
        m = l.helperTextComponent;
        var q = l.isAlwaysOpened,
            r = l.isLoading;
        l = l.isOpened;
        var s = a.inputStrategyRenderer,
            t = a.label,
            u = a.onBackspace,
            v = a.onBlur,
            w = a.onFocus,
            x = a.onClick,
            y = a.onDownArrow,
            z = a.onLeftArrow,
            A = a.onRightArrow,
            B = a.onEnter,
            C = a.onEscape,
            D = a.onShiftTab,
            E = a.onTab,
            F = a.onUpArrow,
            G = a.queryString,
            H = a.inputRef,
            I = a.viewStrategyRenderer,
            J = a.xstyles,
            K = babelHelpers.objectWithoutPropertiesLoose(a, ["contextualProps", "description", "errorMessage", "extraLayoutProps", "inputStrategyRenderer", "label", "onBackspace", "onBlur", "onFocus", "onClick", "onDownArrow", "onLeftArrow", "onRightArrow", "onEnter", "onEscape", "onShiftTab", "onTab", "onUpArrow", "queryString", "inputRef", "viewStrategyRenderer", "xstyles"]);
        a = k(null);
        var L = k(null),
            M = c("useCometInternalTypeaheadState")(),
            N = M.activeEntries,
            O = M.highlightedEntry,
            P = c("cometHandleHighlightDropOnMouseLeave")(K.onHighlightEntry);
        return j.jsxs(j.Fragment, {
            children: [j.jsx("div", {
                className: (h || (h = c("stylex")))(J == null ? void 0 : J.layoutXStyle),
                ref: L,
                children: j.jsx("div", {
                    className: h(J == null ? void 0 : J.inputXStyle),
                    children: j.jsx(c("CometTypeaheadInputStrategyEventListener.react"), {
                        omitEscape: l === !1 && G === "",
                        onBackspace: u,
                        onBlur: v,
                        onChange: K.onChange,
                        onClick: x,
                        onDownArrow: y,
                        onEnter: B,
                        onEscape: C,
                        onFocus: w,
                        onLeftArrow: z,
                        onRightArrow: A,
                        onShiftTab: D,
                        onTab: E,
                        onUpArrow: F,
                        ref: H,
                        children: function(a, b) {
                            return j.jsx(s, babelHelpers["extends"]({}, b, {
                                ariaProps: o,
                                autoFocus: K.autoFocus,
                                description: g,
                                errorMessage: i,
                                id: K.id,
                                inputEndContent: K.inputEndContent,
                                inputExtraProps: K.inputExtraProps,
                                inputStartContent: K.inputStartContent,
                                isDisabled: K.isDisabled,
                                label: t,
                                placeholder: K.placeholder,
                                queryString: G,
                                ref: d("xplatToDOMRef").xplatToInputRef(a),
                                testid: void 0
                            }))
                        }
                    })
                })
            }), m != null && j.jsx("div", babelHelpers["extends"]({
                className: "x1xmf6yo"
            }, n, {
                children: m
            })), (l === !0 || q === !0) && j.jsx(c("CometContextualLayer.react"), babelHelpers["extends"]({}, b, {
                align: e,
                contextRef: L,
                position: f,
                ref: a,
                children: j.jsx(c("CometTypeaheadViewStrategyEventListener.react"), {
                    onOutsideClick: K.onOutsideClick,
                    children: function(a) {
                        return j.jsx("div", {
                            className: (h || (h = c("stylex")))(J == null ? void 0 : J.viewXStyle_DO_NOT_USE),
                            onMouseLeave: P,
                            ref: a,
                            children: j.jsx(I, {
                                ariaProps: p,
                                entries: N,
                                highlightedEntry: O,
                                isLoading: r,
                                onAbandonTypeahead_DO_NOT_USE: K.onAbandonTypeahead_DO_NOT_USE,
                                onHighlightEntry: K.onHighlightEntry,
                                onPressEntry: K.onPressEntry,
                                queryString: G
                            })
                        })
                    }
                })
            }))]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometTypeaheadInternalLayoutContextualStrategyHandlers", ["react", "useBaseTypeaheadLayoutContextualStrategyStateContext", "useCometInternalTypeaheadState", "useCometTypeaheadInternalLayoutInlineStrategyHandlers"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useMemo;

    function a(a) {
        var b = a.handlers,
            d = b.onAbandonTypeahead_DO_NOT_USE,
            e = b.onClick,
            f = b.onOutsideClick,
            g = b.onShiftTab,
            h = b.onTab,
            k = babelHelpers.objectWithoutPropertiesLoose(b, ["onAbandonTypeahead_DO_NOT_USE", "onClick", "onOutsideClick", "onShiftTab", "onTab"]);
        b = a.inputRef;
        var l = a.shouldCloseOnEnter,
            m = l === void 0 ? !0 : l;
        l = a.shouldHandleCloseAfterHandlePressEntry;
        var n = l === void 0 ? !1 : l;
        a = c("useBaseTypeaheadLayoutContextualStrategyStateContext")();
        var o = a.dispatchIsOpened,
            p = a.isOpened;
        l = c("useCometInternalTypeaheadState")();
        var q = l.highlightedEntry,
            r = l.secondaryActionHighlighted;
        a = i(function() {
            o(!1), f && f()
        }, [o, f]);
        l = c("useCometTypeaheadInternalLayoutInlineStrategyHandlers")(babelHelpers["extends"]({
            inputRef: b,
            onOutsideClick: a
        }, k));
        b = l.onBlur;
        var s = l.onChange,
            t = l.onDownArrow,
            u = l.onEnter,
            v = l.onEscape;
        a = l.onHighlightEntry;
        var w = l.onLeftArrow,
            x = l.onOutsideClick,
            y = l.onPressEntry,
            z = l.onRightArrow,
            A = l.onUpArrow;
        l = i(function() {
            o(!1), d && d()
        }, [o, d]);
        var B = i(function() {
                o(!0), e && e()
            }, [o, e]),
            C = i(function(a, b) {
                o(!0), s && s(a, b)
            }, [o, s]),
            D = i(function() {
                p ? t && t() : o(!0)
            }, [o, p, t]),
            E = j(function() {
                return w != null ? function() {
                    w != null && (p ? w() : o(!0))
                } : void 0
            }, [o, p, w]),
            F = j(function() {
                return z != null ? function() {
                    z != null && (p ? z() : o(!0))
                } : void 0
            }, [o, p, z]),
            G = i(function() {
                r !== !0 && ((m || q != null && !m) && o(!1)), u && u()
            }, [q, o, u, r, m]),
            H = i(function() {
                p ? (o(!1), k.onEscape && k.onEscape()) : v && v()
            }, [o, k, p, v]),
            I = i(function(a, b) {
                n || o(!1), y && y(a, b), n && o(!1)
            }, [o, y, n]),
            J = i(function() {
                o(!1), g && g()
            }, [o, g]),
            K = i(function() {
                o(!1), h && h()
            }, [o, h]),
            L = i(function() {
                !p ? o(!0) : A && A()
            }, [o, p, A]);
        return {
            onAbandonTypeahead_DO_NOT_USE: l,
            onBlur: b,
            onChange: C,
            onClick: B,
            onDownArrow: D,
            onEnter: G,
            onEscape: H,
            onHighlightEntry: a,
            onLeftArrow: E,
            onOutsideClick: x,
            onPressEntry: I,
            onRightArrow: F,
            onShiftTab: J,
            onTab: K,
            onUpArrow: L
        }
    }
    g["default"] = a
}), 98);
__d("CometTypeaheadLayoutContextualStrategy.react", ["CometTypeaheadHelperText.react", "CometTypeaheadInternalLayoutContextualStrategy.react", "react", "useBaseTypeaheadLayoutContextualStrategyStateContext", "useCometInternalTypeaheadFetch", "useCometInternalTypeaheadState", "useCometTypeaheadInputRefs", "useCometTypeaheadInternalLayoutContextualStrategyHandlers", "useCometTypeaheadLayoutContextualStrategyARIAProps", "useCometTypeaheadLayoutStrategyStyles"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            view: {
                backgroundColor: "x1jx94hy",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                boxShadow: "xbsqzb3",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                marginTop: "xr9ek0c",
                width: "xh8yej3",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.extraLayoutProps;
        b = b === void 0 ? {} : b;
        var d = b.afterViewContent;
        b = b.beforeViewContent;
        var e = a.helperText,
            f = a.label,
            g = a.onAbandonTypeahead_DO_NOT_USE,
            h = a.onBlur,
            k = a.onChange,
            l = a.onClick,
            m = a.onDownArrow,
            n = a.onEnter,
            o = a.onEscape,
            p = a.onHighlightEntry,
            q = a.onOutsideClick,
            r = a.onPressEntry,
            s = a.onShiftTab,
            t = a.onTab,
            u = a.onUpArrow,
            v = a.viewRole,
            w = a.inputRef,
            x = a.shouldHandleCloseAfterHandlePressEntry;
        x = x === void 0 ? !1 : x;
        var y = a.shouldCloseOnEnter;
        y = y === void 0 ? !0 : y;
        var z = a.xstyles;
        z = z === void 0 ? {} : z;
        var A = z.viewXStyle_DO_NOT_USE;
        z = babelHelpers.objectWithoutPropertiesLoose(z, ["viewXStyle_DO_NOT_USE"]);
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["extraLayoutProps", "helperText", "label", "onAbandonTypeahead_DO_NOT_USE", "onBlur", "onChange", "onClick", "onDownArrow", "onEnter", "onEscape", "onHighlightEntry", "onOutsideClick", "onPressEntry", "onShiftTab", "onTab", "onUpArrow", "viewRole", "inputRef", "shouldHandleCloseAfterHandlePressEntry", "shouldCloseOnEnter", "xstyles"]);
        var B = c("useCometInternalTypeaheadFetch")();
        B = B.isLoading;
        var C = c("useBaseTypeaheadLayoutContextualStrategyStateContext")();
        C = C.isOpened;
        var D = c("useCometInternalTypeaheadState")(),
            E = D.activeEntries;
        D = D.highlightedEntry;
        w = c("useCometTypeaheadInputRefs")(w);
        var F = w.composedRef;
        w = w.inputRef;
        g = c("useCometTypeaheadInternalLayoutContextualStrategyHandlers")({
            handlers: {
                onAbandonTypeahead_DO_NOT_USE: g,
                onBlur: h,
                onChange: k,
                onClick: l,
                onDownArrow: m,
                onEnter: n,
                onEscape: o,
                onHighlightEntry: p,
                onOutsideClick: q,
                onPressEntry: r,
                onShiftTab: s,
                onTab: t,
                onUpArrow: u
            },
            inputRef: w,
            shouldCloseOnEnter: y,
            shouldHandleCloseAfterHandlePressEntry: x
        });
        h = c("useCometTypeaheadLayoutContextualStrategyARIAProps")({
            activeEntries: E,
            helperText: e,
            highlightedEntry: D,
            inputLabel: f,
            isOpened: C,
            viewRole: v
        });
        k = c("useCometTypeaheadLayoutStrategyStyles")({
            isOpened: C,
            xstyles: babelHelpers["extends"]({
                viewXStyle_DO_NOT_USE: [j.view, A]
            }, z)
        });
        return i.jsx(c("CometTypeaheadInternalLayoutContextualStrategy.react"), babelHelpers["extends"]({}, a, g, {
            extraLayoutProps: {
                afterViewContent: d,
                ariaProps: h,
                beforeViewContent: b,
                helperTextComponent: e != null ? i.jsx(c("CometTypeaheadHelperText.react"), {
                    text: e
                }) : null,
                isLoading: B,
                isOpened: C
            },
            helperText: e,
            inputRef: F,
            label: f,
            viewRole: v,
            xstyles: k
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometInternalTypeaheadFetchContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        fetch: c("emptyFunction"),
        isLoading: !1,
        refetch: c("emptyFunction"),
        source: "all"
    });
    g["default"] = b
}), 98);
__d("CometInternalTypeaheadStateContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        activeEntries: [],
        highlightedEntry: null,
        highlightedEntrySource: null,
        secondaryActionHighlighted: null
    });
    g["default"] = b
}), 98);
__d("CometTypeaheadProgressGlimmer.react", ["CometProgressRingIndeterminate.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a() {
        return i.jsx("div", {
            className: "x6s0dn4 x78zum5 x1iyjqo2 xdd8jsf xl56j7k",
            children: i.jsx(c("CometProgressRingIndeterminate.react"), {
                color: "disabled_DEPRECATED",
                size: 24
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometInternalTypeaheadState", ["CometInternalTypeaheadStateContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        return i(c("CometInternalTypeaheadStateContext"))
    }
    g["default"] = a
}), 98);
__d("CometTypeaheadViewItem.react", ["CometPressable.react", "CometRow.react", "CometRowItem.react", "emptyFunction", "react", "react-strict-dom", "useCometInternalTypeaheadState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useCallback,
        k = {
            root: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                marginTop: "xdj266r",
                marginBottom: "xat24cr",
                paddingTop: "x1y1aw1k",
                paddingEnd: "x1sxyh0",
                paddingBottom: "xwib8y2",
                paddingStart: "xurb0ha",
                $$css: !0
            }
        },
        l = {
            contentRoot: {
                alignItems: "x6s0dn4",
                cursor: "x1ypdohk",
                display: "x78zum5",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x1n2onr6",
                $$css: !0
            },
            contentRootDisabled: {
                bottom: "x1ey2m1c",
                cursor: "x1h6gzvc",
                left: "xu96u03",
                position: "x10l6tqk",
                right: "x3m8u43",
                start: null,
                end: null,
                top: "x13vifvy",
                $$css: !0
            },
            contentRootEmphasized: {
                backgroundColor: "xlhe6ec",
                $$css: !0
            },
            contentRootFocused: {
                boxShadow: "xpud6h4",
                outline: "xvetz19 x1a2a7pz",
                $$css: !0
            },
            contentRootHighlighted: {
                backgroundColor: "xugaqoy x1wpzbip",
                $$css: !0
            },
            itemIcon: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                $$css: !0
            },
            pressable: {
                flexDirection: "x1q0g3np",
                width: "xh8yej3",
                $$css: !0
            },
            pressableWithAdditionalEndContent: {
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                $$css: !0
            },
            root: {
                display: "x78zum5",
                width: "xh8yej3",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.additionalEndContentOutsideOfPressable,
            e = a.children,
            f = a.cursorDisabled_SEARCH_ONLY;
        f = f === void 0 ? !1 : f;
        var g = a.entry,
            h = a.isActive,
            m = a.isEmphasized;
        m = m === void 0 ? !1 : m;
        var n = a.isDisabled;
        n = n === void 0 ? !1 : n;
        var o = a.itemEndContent,
            p = a.itemStartContent,
            q = a.linkProps;
        a.onHighlightEntry;
        var r = a.onPressEntry,
            s = a.onPressEntryIn,
            t = a.overlayDisabled_SEARCH_ONLY;
        t = t === void 0 ? !1 : t;
        var u = a.role,
            v = a.testid;
        v = a.xstyle;
        v = v === void 0 ? k.root : v;
        var w = a.debugElement,
            x = a.focusable;
        x = x === void 0 ? !1 : x;
        a = a.itemEndContentKeyboardFocusable;
        a = a === void 0 ? !1 : a;
        var y = c("useCometInternalTypeaheadState")();
        y = y.secondaryActionHighlighted;
        var z = j(function(a) {
                r && r(g, a)
            }, [g, r]),
            A = j(function(a) {
                s && s(g, a)
            }, [g, s]),
            B = u === "row" ? "gridcell" : "none";
        return i.jsxs(d("react-strict-dom").html.li, {
            "aria-selected": h,
            "data-testid": void 0,
            id: a === !0 && B === "gridcell" ? void 0 : g.key,
            role: u,
            style: l.root,
            children: [w, i.jsxs(c("CometPressable.react"), {
                cursorDisabled: f,
                disabled: n,
                display: "block",
                expanding: !0,
                focusable: x,
                label: g.label,
                linkProps: q,
                onPress: n ? c("emptyFunction") : z,
                onPressIn: n ? c("emptyFunction") : A,
                overlayDisabled: t,
                overlayFocusRingPosition: "inset",
                role: a !== !0 ? B : "none",
                xstyle: [l.contentRoot, h && l.contentRootHighlighted, h && y !== !0 && l.contentRootFocused, m && l.contentRootEmphasized, v, b == null ? l.pressable : l.pressableWithAdditionalEndContent],
                children: [i.jsxs(c("CometRow.react"), {
                    expanding: !0,
                    paddingHorizontal: 0,
                    paddingVertical: 0,
                    verticalAlign: "center",
                    children: [p != null ? i.jsx(c("CometRowItem.react"), {
                        children: i.jsx(d("react-strict-dom").html.div, {
                            style: l.itemIcon,
                            children: p
                        })
                    }) : null, i.jsx(c("CometRowItem.react"), {
                        expanding: !0,
                        children: a === !0 && B === "gridcell" ? i.jsx(d("react-strict-dom").html.div, {
                            id: g.key,
                            role: B,
                            children: e
                        }) : e
                    }), o != null ? i.jsx(c("CometRowItem.react"), {
                        children: a === !0 && B === "gridcell" ? i.jsx(d("react-strict-dom").html.div, {
                            id: g.key + "-secondary-action",
                            role: B,
                            children: o
                        }) : o
                    }) : null]
                }), b, i.jsx(d("react-strict-dom").html.div, {
                    style: n && l.contentRootDisabled
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("baseTypeaheadFlattenEntries", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.flatMap(function(a) {
            return a.type === "section" ? a.entries : a
        })
    }
    f["default"] = a
}), 66);
__d("cometTypeaheadKeyboardNavigationUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, b, c, d) {
        var e;
        if (a.length === 0) {
            c(null, null);
            return
        }
        var f = b != null ? a.findIndex(function(a) {
            return a.key === b
        }) + 1 : 0;
        f === a.length && (f = 0);
        e = (e = (e = a[f]) == null ? void 0 : e.hasSecondaryAction) != null ? e : !1;
        c(a[f], e ? d : null)
    }

    function h(a, b, c, d) {
        var e;
        if (a.length === 0) {
            c(null, null);
            return
        }
        var f = b != null ? a.findIndex(function(a) {
            return a.key === b
        }) - 1 : a.length - 1;
        f === -1 && (f = a.length - 1);
        e = (e = (e = a[f]) == null ? void 0 : e.hasSecondaryAction) != null ? e : !1;
        c(a[f], e ? d : null)
    }

    function a(a, b, c, d) {
        if (a.length === 0) {
            c(null, !1);
            return
        }
        if (d === !0) {
            d = a.findIndex(function(a) {
                return a.key === b
            });
            c(a[d], !1)
        } else h(a, b, c, !0)
    }

    function b(a, b, c, d) {
        if (a.length === 0) {
            c(null, !1);
            return
        }
        if (d === !0) g(a, b, c, !1);
        else {
            d = a.findIndex(function(a) {
                return a.key === b
            });
            c(a[d], !0)
        }
    }
    f.moveDown = g;
    f.moveUp = h;
    f.moveLeft = a;
    f.moveRight = b
}), 66);
__d("cometTypeaheadODSLogFetchNetworkEvent", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("ODS").__setRef("cometTypeaheadODSLogFetchNetworkEvent");

    function a(a, b, c) {
        b === void 0 && (b = !0);
        c === void 0 && (c = 1);
        if (!b) return;
        h.onReady(function(b) {
            b.bumpEntityKey(354, a, "fetched-network", c)
        })
    }
    g["default"] = a
}), 98);
__d("useCometInternalTypeaheadFetch", ["CometInternalTypeaheadFetchContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        return i(c("CometInternalTypeaheadFetchContext"))
    }
    g["default"] = a
}), 98);
__d("useCometTypeaheadViewLabel", ["fbt", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = (i || d("react")).useMemo;

    function a(a) {
        var b = a.activeEntries;
        return j(function() {
            var a = b.length;
            return a === 0 ? h._("__JHASH__n-kQyB08R28__JHASH__") : h._("__JHASH__71Zs7ul5B_o__JHASH__", [h._plural(a, "number")])
        }, [b])
    }
    g["default"] = a
}), 226);
__d("useCometTypeaheadLayoutContextualStrategyARIAProps", ["react", "useCometInternalTypeaheadFetch", "useCometTypeaheadViewLabel"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useId,
        j = b.useMemo;

    function a(a) {
        var b = a.activeEntries,
            d = a.helperText,
            e = a.highlightedEntry,
            f = a.inputLabel,
            g = f === void 0 ? "" : f,
            h = a.isOpened,
            k = a.secondaryActionHighlighted,
            l = a.viewRole,
            m = i();
        f = c("useCometInternalTypeaheadFetch")();
        var n = f.isLoading,
            o = i(),
            p = c("useCometTypeaheadViewLabel")({
                activeEntries: b
            });
        return j(function() {
            var a = e != null ? {
                    "aria-activedescendant": k === !0 ? e.key + "-secondary-action" : e.key
                } : {},
                c = h && b.length > 0 ? {
                    "aria-controls": m
                } : null,
                f = d != null && String(d).length > 0 ? {
                    "aria-describedby": o
                } : null,
                i = {
                    "aria-busy": n,
                    "aria-label": p,
                    id: m,
                    role: l
                };
            return {
                ariaDescribedByProps: {
                    id: o
                },
                ariaInputProps: babelHelpers["extends"]({}, a, c, f, {
                    "aria-autocomplete": "list",
                    "aria-expanded": b.length > 0 && h,
                    "aria-label": g,
                    role: "combobox"
                }),
                ariaViewProps: i
            }
        }, [b.length, o, d, e, g, n, h, m, k, p, l])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LazyLoadInstance", ["asyncToGeneratorRuntime", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        LOADING: 1,
        NOT_READY: 0,
        READY: 2
    };
    a = function() {
        function a(a, b) {
            this.$1 = {
                instantiate: b,
                moduleReference: a,
                stage: h.NOT_READY
            }
        }
        var d = a.prototype;
        d.get = function(a) {
            switch (this.$1.stage) {
                case h.NOT_READY:
                    c("promiseDone")(this.$2(this.$1), a);
                    break;
                case h.LOADING:
                    c("promiseDone")(this.$1.instancePromise, a);
                    break;
                case h.READY:
                    a(this.$1.instance);
                    break
            }
        };
        d.getNow = function() {
            return this.$1.stage === h.READY ? this.$1.instance : null
        };
        d.preload = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                this.$1.stage === h.NOT_READY && (yield this.$2(this.$1))
            });

            function c() {
                return a.apply(this, arguments)
            }
            return c
        }();
        d.$2 = function(a) {
            var b = this,
                c = a.instantiate;
            a = a.moduleReference;
            a = a.load().then(function(a) {
                a = c(a);
                b.$1 = {
                    instance: a,
                    stage: h.READY
                };
                return a
            });
            this.$1 = {
                instancePromise: a,
                stage: h.LOADING
            };
            return a
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MAWWebWorkerSingletonMaybeDeferred", ["cr:8594"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        return b("cr:8594")().then(function(a) {
            return a.createWorkerIfNone("t2Init")
        })
    };
    g.createWorkerIfNone = a
}), 98);
__d("RTWebCallWindowControllerLoader", ["FBLogger", "JSResourceForInteraction", "Promise", "asyncToGeneratorRuntime", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = c("requireDeferred")("RTWebCallWindowOpener").__setRef("RTWebCallWindowControllerLoader"),
        j = c("requireDeferred")("ZenonCallWindowController").__setRef("RTWebCallWindowControllerLoader"),
        k = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a() {
                return b.apply(this, arguments) || this
            }
            return a
        }(babelHelpers.wrapNativeSuper(Error));
    a = function() {
        function a(a, b) {
            this.$1 = null, this.$2 = a, this.$3 = b
        }
        var d = a.prototype;
        d.init = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                try {
                    var a = (yield(h || (h = b("Promise"))).all([j.load(), i.load()])),
                        d = a[0];
                    a = a[1];
                    this.$1 = new d(this.$2, {
                        callWindowInitializerResource: this.$3,
                        callWindowOpener: new a(),
                        uriBuilderResource: c("JSResourceForInteraction")("ZenonUriBuilder").__setRef("RTWebCallWindowControllerLoader")
                    })
                } catch (a) {
                    c("FBLogger")("rtc_www").catching(a).warn("Failed to initialize call window controller")
                }
            });

            function d() {
                return a.apply(this, arguments)
            }
            return d
        }();
        d.initCall = function(a) {
            if (this.$1) return this.$1.initCall(a);
            else throw new k()
        };
        return a
    }();
    a.ResourceNotReadyError = k;
    g["default"] = a
}), 98);
__d("RTWebCometCallInviteControllerDeferred.react", ["deferredLoadComponent", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");
    a = c("deferredLoadComponent")(c("requireDeferred")("RTWebCometCallInviteController.react").__setRef("RTWebCometCallInviteControllerDeferred.react"));
    b = a;
    g["default"] = b
}), 98);
__d("ZenonCallInviteModelLoader", ["BaseEventEmitter", "Promise", "asyncToGeneratorRuntime", "emptyFunction", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = c("requireDeferred")("ZenonCallInviteModel").__setRef("ZenonCallInviteModelLoader"),
        j = c("requireDeferred")("delegateZenonCallInviteModel").__setRef("ZenonCallInviteModelLoader");
    a = function(a) {
        babelHelpers.inheritsLoose(d, a);

        function d(b) {
            var d;
            d = a.call(this) || this;
            d.$ZenonCallInviteModelLoader$p_1 = null;
            d.getCurrentInvite = function() {
                return null
            };
            d.startListening = function(a) {
                this.$ZenonCallInviteModelLoader$p_1 = a
            };
            d.stopListening = function() {
                this.$ZenonCallInviteModelLoader$p_1 = null
            };
            d.dismiss = c("emptyFunction");
            d.accept = c("emptyFunction");
            d.decline = c("emptyFunction");
            d.$ZenonCallInviteModelLoader$p_2 = b;
            return d
        }
        var e = d.prototype;
        e.init = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                var a = (yield(h || (h = b("Promise"))).all([i.load(), j.load()])),
                    c = a[0];
                a = a[1];
                c = new c(this.$ZenonCallInviteModelLoader$p_2);
                a(this, c);
                this.$ZenonCallInviteModelLoader$p_1 !== null && c.startListening(this.$ZenonCallInviteModelLoader$p_1)
            });

            function c() {
                return a.apply(this, arguments)
            }
            return c
        }();
        return d
    }(c("BaseEventEmitter"));
    g["default"] = a
}), 98);
__d("ZenonIncomingRingSDK", ["BaseEventEmitter", "RTWebIncomingRingConfiguration", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("ZenonParentCallsManager").__setRef("ZenonIncomingRingSDK"),
        i = [1, 2, 15, 16];
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.$ZenonIncomingRingSDK$p_1 = [], c.$ZenonIncomingRingSDK$p_2 = [], b) || babelHelpers.assertThisInitialized(c)
        }
        var c = b.prototype;
        c.init = function(a) {
            var b = this;
            this.$ZenonIncomingRingSDK$p_3 = a;
            h.onReady(function(c) {
                b.callsManager == null && (b.callsManager = new c(a));
                c = b.callsManager;
                c.addListener("unsupportedRing", function(a) {
                    return b.emit("unsupportedRing", a)
                });
                c.addListener("incomingRing", function(a) {
                    var c;
                    if (a.actorID != null && !((c = b.$ZenonIncomingRingSDK$p_3) == null ? void 0 : c.enableIncomingActorCalls)) return;
                    b.emit("incomingRing", a)
                });
                c.addListener("ringCancel", function(a) {
                    return b.emit("ringCancel", a)
                });
                c.initListeners(b.$ZenonIncomingRingSDK$p_1);
                while (b.$ZenonIncomingRingSDK$p_2.length > 0) {
                    var d = b.$ZenonIncomingRingSDK$p_2.shift();
                    c.startOutgoingCallIntent(d.nonce, d.callParams)
                }
            })
        };
        c.initListeners = function(a) {
            var b = this.callsManager;
            if (b != null) b.initListeners(a);
            else {
                (b = this.$ZenonIncomingRingSDK$p_1).push.apply(b, a)
            }
        };
        c.removeListeners = function(a) {
            var b = this;
            if (this.callsManager != null) this.callsManager.removeListeners(a);
            else {
                var c = function() {
                    if (e) {
                        if (f >= d.length) return "break";
                        g = d[f++]
                    } else {
                        f = d.next();
                        if (f.done) return "break";
                        g = f.value
                    }
                    var a = g;
                    b.$ZenonIncomingRingSDK$p_1 = b.$ZenonIncomingRingSDK$p_1.filter(function(b) {
                        return b !== a
                    })
                };
                for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var g;
                    a = c();
                    if (a === "break") break
                }
            }
        };
        c.isCallSupported = function(a) {
            switch (a.type) {
                case "thread":
                    if (this.$ZenonIncomingRingSDK$p_3 && i.includes(a.threadType)) {
                        return (a = d("RTWebIncomingRingConfiguration").isSupportedClient()) != null ? a : !1
                    }
                    break;
                default:
                    return !1
            }
            return !1
        };
        c.startCallIntent = function(a, b) {
            this.callsManager ? this.callsManager.startOutgoingCallIntent(a, b) : this.$ZenonIncomingRingSDK$p_2.push({
                callParams: b,
                nonce: a
            })
        };
        return b
    }(c("BaseEventEmitter"));
    g["default"] = a
}), 98);
__d("RTWebPreCallContextSingleton", ["FBLogger", "JSResource", "LazyLoadInstance", "RTWebCallWindowControllerLoader", "ZenonCallInviteModelLoader", "ZenonIncomingRingSDK", "gkx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = !1,
        i;

    function a(a) {
        if (!c("gkx")("24231")) return null;
        if (i != null) return i;
        try {
            var b = new(c("ZenonIncomingRingSDK"))();
            i = {
                callInviteModel: new(c("ZenonCallInviteModelLoader"))(b),
                callWindowController: new(c("RTWebCallWindowControllerLoader"))(a, c("JSResource")("RTWebMercuryCallWindowInitializer").__setRef("RTWebPreCallContextSingleton")),
                incomingRingSDK: b
            };
            return i
        } catch (a) {
            c("FBLogger")("rtc_www").catching(a).mustfix("Pre-call context initialization failed! This breaks all calling!");
            return null
        }
    }

    function b(a, b) {
        b === void 0 && (b = !1);
        if (!c("gkx")("24231")) return null;
        if (h) return i;
        h = !0;
        c("promiseDone")(i.callInviteModel.init());
        c("promiseDone")(i.callWindowController.init());
        i.incomingRingSDK.init({
            enableIncomingActorCalls: b,
            relayEnvironment: a
        });
        b = new(c("LazyLoadInstance"))(c("JSResource")("RTWebSignalingListener").__setRef("RTWebPreCallContextSingleton"), function(a) {
            return new a()
        });
        b.get(function(a) {
            i.incomingRingSDK.initListeners([a])
        });
        return i
    }

    function d() {
        return i
    }
    g.create = a;
    g.init = b;
    g.get = d
}), 98);
__d("RTWebPreCallProvider.react", ["CometRelay", "RTWebPreCallContext", "RTWebPreCallContextSingleton", "react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useEffect;

    function a(a) {
        var b = a.children;
        a = a.enableIncomingActorCalls;
        var e = a === void 0 ? !1 : a,
            f = d("CometRelay").useRelayEnvironment(),
            g = c("useStable")(function() {
                return d("RTWebPreCallContextSingleton").create({
                    relayEnvironment: f
                })
            });
        j(function() {
            g && d("RTWebPreCallContextSingleton").init(f, e)
        }, [g, e, f]);
        return i.jsx(c("RTWebPreCallContext").Provider, {
            value: g,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useMessengerMetaManagerBadgedFavIcon", ["useCometRouterState"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = c("useCometRouterState")();
        return (b == null ? void 0 : b.main.route.tabKey) === "messenger" && a > 0
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("cometUniqueID", ["ExecutionEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = 0,
        j;
    (h || c("ExecutionEnvironment")).canUseDOM ? j = "c" : j = "s";

    function a() {
        return "jsc_" + j + "_" + (i++).toString(36)
    }
    g["default"] = a
}), 98);
__d("CometAudioManagerContexts", ["cometUniqueID", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = (h || d("react")).createContext;

    function a() {
        return c("cometUniqueID")()
    }
    e = b({
        muted: !0,
        setMuted: function() {},
        setVolume: function() {},
        volume: 1
    });
    f = b(null);
    d = b(null);
    g.makeAudioGroupID = a;
    g.CometAudioLocalScopeContext = e;
    g.CometAudioGroupContext = f;
    g.AudioApiContext = d
}), 98);
__d("CometBackgroundImage.react", ["CometImage.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            block: {
                display: "x1lliihq",
                $$css: !0
            },
            root: {
                height: "x5yr21d",
                objectFit: "xl1xv1r",
                width: "xh8yej3",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.alt,
            d = a.displayBlock,
            e = a.draggable,
            f = a.height,
            g = a.loading,
            h = a.onError,
            k = a.onLoad;
        a = a.src;
        return i.jsx(c("CometImage.react"), {
            alt: b,
            draggable: e,
            height: f,
            loading: g || void 0,
            objectFit: "cover",
            onError: h,
            onLoad: k,
            src: a,
            xstyle: [j.root, d && j.block]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CoreVideoPlayerAutoplayClientUtils", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {}

    function b(a, b, c, d) {
        return a === "PAUSE" && b === "PAUSE" && !c && d
    }
    g.log = a;
    g.componentShouldPause = b
}), 98);
__d("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        function b(b) {
            return b.bandwidthEstimate < a ? "IGNORE" : "SKIP"
        }
        b.displayName = "evaluateVideoAutoplayIgnoreOnLowBandwidthRule";
        return b
    }
    f["default"] = a
}), 66);
__d("createEvaluateVideoAutoplayPauseOnInvisibleRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        function b(b) {
            b = b.videoPlayerPassiveViewabilityInfo;
            b = b && b.getCurrent();
            b = b ? b.visiblePercentage : null;
            b = b === null || b >= a;
            return b ? "SKIP" : "PAUSE"
        }
        b.displayName = "evaluateVideoAutoplayPauseOnInvisibleRule:" + a + "%";
        return b
    }
    f["default"] = a
}), 66);
__d("createEvaluateVideoAutoplayPauseOnMutedInvisibleRule", ["createEvaluateVideoAutoplayPauseOnInvisibleRule"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(a);

        function d(a) {
            return a.muted ? b(a) : "SKIP"
        }
        d.displayName = "evaluateVideoAutoplayPauseOnMutedInvisibleRule:" + a + "%";
        return d
    }
    g["default"] = a
}), 98);
__d("evaluateVideoAutoplayDefaultIgnoreRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return "IGNORE"
    }
    a.displayName = "evaluateVideoAutoplayDefaultIgnoreRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnBroadcastEndedRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.ended;
        a = a.broadcastStatus != null;
        return a && b ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnBroadcastEndedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnEndedRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.ended;
        return a ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnEndedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnFrozenRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.isFrozenPassive;
        a = a.getCurrentState();
        return a ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnFrozenRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnUnmuteRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.muted;
        a = a.paused;
        return !b && !a ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnUnmuteRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnUserPausedRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.paused;
        a = a.lastPauseReason;
        return b && (a === "user_initiated" || a === "other_user_initiated") ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnUserPausedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnUserPlayRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.paused,
            c = a.muted;
        a = a.lastPlayReason;
        return !c && !b && (a === "user_initiated" || a === "other_user_initiated") ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnUserPlayRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnAdInvisibleRule", ["VideoPlayerViewabilityConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.adClientToken;
        a = a.videoPlayerPassiveViewabilityInfo;
        a = a && a.getCurrent();
        a = a ? a.visiblePercentage : null;
        a = a === null || a >= c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE;
        return b != null && !a ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnAdInvisibleRule";
    g["default"] = a
}), 98);
__d("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule", [], (function(a, b, c, d, e, f) {
    "use strict";
    b = !1;

    function a(a) {
        var b = a.adClientToken,
            c = a.hiddenSubtreePassive,
            d = a.muted;
        a = a.isDocumentHiddenOrBlurred || c.getCurrentState().backgrounded;
        c = b != null;
        return !a || !d ? "SKIP" : a && d && c ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnBackgroundedRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.hiddenSubtreePassive;
        a = a.isDocumentHiddenOrBlurred || b.getCurrentState().backgrounded;
        return a ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnBackgroundedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.hiddenSubtreePassive;
        return a.getCurrentState().backgrounded ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnHiddenSubtreeRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.hiddenSubtreePassive;
        return a.getCurrentState().hidden ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnHiddenSubtreeRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnMutedBackgroundedRule", [], (function(a, b, c, d, e, f) {
    "use strict";
    b = !1;

    function a(a) {
        var b = a.hiddenSubtreePassive,
            c = a.muted;
        a = a.isDocumentHiddenOrBlurred || b.getCurrentState().backgrounded;
        return a ? a && c ? "PAUSE" : "SKIP" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnMutedBackgroundedRule";
    f["default"] = a
}), 66);
__d("VideoPlayerAutoplayRulesProvider", ["VideoPlayerViewabilityConstants", "createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule", "createEvaluateVideoAutoplayPauseOnInvisibleRule", "createEvaluateVideoAutoplayPauseOnMutedInvisibleRule", "evaluateVideoAutoplayDefaultIgnoreRule", "evaluateVideoAutoplayIgnoreOnBroadcastEndedRule", "evaluateVideoAutoplayIgnoreOnEndedRule", "evaluateVideoAutoplayIgnoreOnFrozenRule", "evaluateVideoAutoplayIgnoreOnUnmuteRule", "evaluateVideoAutoplayIgnoreOnUserPausedRule", "evaluateVideoAutoplayIgnoreOnUserPlayRule", "evaluateVideoAutoplayPauseOnAdInvisibleRule", "evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule", "evaluateVideoAutoplayPauseOnBackgroundedRule", "evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule", "evaluateVideoAutoplayPauseOnHiddenSubtreeRule", "evaluateVideoAutoplayPauseOnMutedBackgroundedRule", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l, m, n, o;
    b = 25e4;
    var p = [d = c("evaluateVideoAutoplayIgnoreOnFrozenRule"), e = c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), (f = c("createEvaluateVideoAutoplayPauseOnInvisibleRule"))((h = c("VideoPlayerViewabilityConstants")).DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), i = c("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule"), j = c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), k = c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), l = c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), m = c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), n = c("evaluateVideoAutoplayIgnoreOnEndedRule")],
        q = [d, e, f(h.DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), c("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule")(b), o = c("evaluateVideoAutoplayPauseOnMutedBackgroundedRule"), j, k, l, m, n],
        r = [d, c("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule")(b), o, k, l, m, n],
        s = [d, f(h.DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), j, l, m, n];
    b = [d, e, i, j, c("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule")(b), l];
    b.push(f(h.DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE));
    b.push(c("evaluateVideoAutoplayIgnoreOnBroadcastEndedRule"));
    b = b.slice();
    var t = [d, e, c("createEvaluateVideoAutoplayPauseOnMutedInvisibleRule")(.01), i, j, k, l, m, n].filter(Boolean),
        u = [d, f(h.DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), j, k, l, m, n],
        v = [d, f(h.DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), j, k, l, m, n],
        w = [d, e, i, j, k, l, m, n],
        x = [d, e, j, l, m, n],
        y = [d, j, k, l, m, n],
        z = [d, j, k, l, m, n];
    e = [d, e, f(h.DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), i, k, l, m, n];
    i = [c("evaluateVideoAutoplayDefaultIgnoreRule")];
    var A = [f(0)],
        B = [f(0)],
        C = [d, f(.25), c("evaluateVideoAutoplayPauseOnBackgroundedRule"), j, l, c("evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule")],
        D = [f(.25)],
        E = [d, o, j, k, l, m, n, f(0)],
        F = [o, j, k];
    d = [d, f(h.DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), o, c("evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule"), j, k, l, m, n];
    f = [];
    var G = {
        always_disable: i,
        barcelona_carousel: F,
        barcelona_feed: d,
        basic: p,
        bulletin: A,
        creator_studio: e,
        creator_studio_sliding_tray_rules: B,
        default_feed: q,
        dolly: E,
        focused_story_view: r,
        gif: s,
        live_producer: u,
        live_studio: v,
        polaris_feed: C,
        polaris_grid: D,
        polaris_notes: f,
        stages: z,
        tournament_hero: w,
        watch_feed: b,
        watch_live_tab: t,
        wns: x,
        work_knowledge: y
    };
    h = function(a) {
        a = G[a];
        if (!a) throw c("unrecoverableViolation")("Unknown VideoPlayerAutoplayRulesType passed to VideoPlayerAutoplayRulesProvider", "comet_video_player");
        return a
    };

    function a(a) {
        return a
    }
    g.provideAutoplayRules = h;
    g.makeVideoPlayerAutoplayRules = a
}), 98);
__d("VideoPlayerAutoplayContexts", ["VideoPlayerAutoplayRulesProvider", "cometUniqueID", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = (h || d("react")).createContext;
    e = b({
        autoplayLocalRules: d("VideoPlayerAutoplayRulesProvider").provideAutoplayRules("basic"),
        autoplayScopeID: "null"
    });
    f = b(null);

    function a() {
        return "id-vpas-" + c("cometUniqueID")()
    }
    g.VideoAutoplayLocalScopeContext = e;
    g.AutoplayApiContext = f;
    g.makeAutoplayScopeID = a
}), 98);
__d("WwwCometVideoAutoplayFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1744552");
    b = d("FalcoLoggerInternal").create("www_comet_video_autoplay", a);
    e = b;
    g["default"] = e
}), 98);
__d("useInterval", ["clearInterval", "react", "setIntervalAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useRef;

    function a(a, b, d) {
        d === void 0 && (d = []);
        var e = j(a);
        i(function() {
            e.current = a
        }, [a]);
        var f = a != null;
        i(function() {
            if (!f || b <= 0) return;
            var a = c("setIntervalAcrossTransitions")(function() {
                var a = e.current;
                if (a == null) return;
                a()
            }, b);
            return function() {
                return c("clearInterval")(a)
            }
        }, [f, b].concat(d))
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometTimeSpentUtils", ["forEachObject"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a, b, d) {
        a = (a = a.timeSpentConfig) == null ? void 0 : a.session_ids;
        if (d == null || a == null) return b;
        c("forEachObject")(a, function(a, c) {
            a = a.extradata_key;
            if (a != null) {
                b[a] = (a = d[c]) != null ? a : void 0
            }
        });
        return b
    };
    a = function(a, b, c) {
        if (c == null) return b;
        c = c || Object.freeze({});
        var d = c.session_ids;
        c = babelHelpers.objectWithoutPropertiesLoose(c, ["session_ids"]);
        return h(a, babelHelpers["extends"]({}, b, c), d)
    };
    g.addSessionIDsInfo = h;
    g.addTimeSpentMetaData = a
}), 98);
__d("SearchCometGlobalResultPageTracePolicy", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        CHAT_TAB: "comet.search_results.chat_tab",
        DEFAULT_TAB: "comet.search_results.default_tab",
        HASHTAG: "comet.search_results.hashtag",
        PHOTOS_TAB: "comet.search_results.photos_tab",
        TOP_TAB: "comet.search_results.top_tab"
    });
    f["default"] = a
}), 66);
__d("isSearchCometGlobalResultPageTracePolicy", ["SearchCometGlobalResultPageTracePolicy"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return Object.values(c("SearchCometGlobalResultPageTracePolicy")).includes(a)
    }
    g["default"] = a
}), 98);
__d("CometVisitationManager", ["FBLogger", "isSearchCometGlobalResultPageTracePolicy", "pageID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            "comet.marketplace.category": "comet.marketplace.home",
            "comet.marketplace.home.hoisted_pdp": "comet.marketplace.home"
        },
        i = {},
        j = null,
        k = null,
        l = !1;

    function m(a) {
        return a.tracePolicy + ":" + a.instanceId + ":" + a.subsessionCount + ":" + a.timeStampMs / 1e3
    }

    function n(a) {
        if (a == null) return;
        a = h[a] ? h[a] : a;
        if (j === a) return;
        var b = i[a];
        b ? (b.subsessionCount++, b.timeStampMs = Date.now()) : i[a] = {
            instanceId: c("pageID"),
            subsessionCount: 1,
            timeStampMs: Date.now(),
            tracePolicy: a
        };
        k = j;
        j = a
    }

    function a() {
        if (!l) {
            c("FBLogger")("CometVisitationManager").mustfix("Attempting to get the current visitation id without initialization.");
            return null
        }
        if (!l || j == null || !i[j]) return null;
        var a = m(i[j]);
        if (c("isSearchCometGlobalResultPageTracePolicy")(j) && k != null && i[k]) {
            var b = m(i[k]);
            return a + "|" + b
        }
        return a
    }

    function b(a) {
        if (l) return;
        n(a);
        l = !0
    }

    function o(a) {
        if (!l) {
            c("FBLogger")("CometVisitationManager").mustfix("Updating the visitation manager without initialization");
            return
        }
        n(a)
    }

    function d(a) {
        o(a.main.route.tracePolicy)
    }
    g.getCurrentVisitationId = a;
    g.init = b;
    g.update = o;
    g.updateFromRouterState = d
}), 98);
__d("ProfileCometSessionConfig", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = "ps";
    b = 3e4;
    f.PREFIX = a;
    f.TIMEOUT_MS = b
}), 66);
__d("ProfileCometRoutingUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a != null && a.startsWith("comet.profile.")
    }
    f.isProfilePolicy = a
}), 66);
__d("ProfileCometSessionUtil", ["ProfileCometRoutingUtils", "ProfileCometSessionConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = a.tracePolicy;
        if (d("ProfileCometRoutingUtils").isProfilePolicy(b)) {
            b = a.params;
            a = b.profile_idorvanity;
            b = b.vanity;
            if (typeof b === "string") return b;
            return typeof a === "string" ? a : null
        }
        return null
    }

    function i(a) {
        var b = a.tracePolicy;
        if (d("ProfileCometRoutingUtils").isProfilePolicy(b)) {
            b = a.params;
            a = b.id;
            b = b.profile_idorvanity;
            if (typeof a === "string") return a;
            if (typeof b === "string") return b
        }
        return null
    }

    function a(a, b) {
        if (b == null) return !1;
        var c = b.tracePolicy;
        if (!d("ProfileCometRoutingUtils").isProfilePolicy(c)) return !1;
        if (a == null) return !0;
        c = a.tracePolicy;
        if (!d("ProfileCometRoutingUtils").isProfilePolicy(c)) return !1;
        c = h(b);
        var e = h(a);
        b = i(b);
        a = i(a);
        return c != null && c === e || b != null && b === a
    }

    function b(a) {
        var b = [];
        for (var c = 0; c < a.length; c++) {
            var e = a.key(c);
            e != null && e.startsWith(d("ProfileCometSessionConfig").PREFIX) && b.push(e)
        }
        return b
    }
    g.isSameProfileSession = a;
    g.getStorageKeys = b
}), 98);
__d("ProfileEngagementFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1744234");
    b = d("FalcoLoggerInternal").create("profile_engagement", a);
    e = b;
    g["default"] = e
}), 98);
__d("ProfileCometSession", ["ProfileCometSessionConfig", "ProfileCometSessionUtil", "ProfileEngagementFalcoEvent", "WebStorage", "uuidv4"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a) {
        var b = j();
        return b === null ? null : d("ProfileCometSessionConfig").PREFIX + ":" + a + ":" + b
    }

    function j() {
        var a = (h || (h = c("WebStorage"))).getSessionStorageForRead();
        if (!a) return null;
        var b = d("ProfileCometSessionConfig").PREFIX + ":tabID";
        a = a.getItem(b);
        if (a == null) {
            a = c("uuidv4")();
            var e = (h || (h = c("WebStorage"))).getSessionStorage();
            if (!e) return null;
            e.setItem(b, a)
        }
        return a
    }

    function k(a) {
        if (a == null) return "timeline";
        if (a === "comet.profile.timeline.grid") return "timeline_overview";
        if (a.startsWith("comet.profile.collection.friend")) return "friends_page";
        return a.startsWith("comet.profile.collection") ? "about_page" : "timeline"
    }

    function l(a, b, d) {
        c("ProfileEngagementFalcoEvent").log(function() {
            return {
                content_id: null,
                profile_event_type: "profile_session_impression",
                profile_id: a,
                profile_product_bucket: "profile_core",
                profile_session_id: b,
                profile_surface: k(d)
            }
        })
    }

    function m(a, b) {
        var d = (h || (h = c("WebStorage"))).getLocalStorage();
        if (!d) return null;
        d = c("uuidv4")();
        q(a, d);
        l(a, d, b == null ? void 0 : b.tracePolicy);
        return d
    }

    function n(a, b) {
        var c = p(a);
        return c === null ? m(a, b) : c
    }

    function o(a) {
        a = i(a);
        var b = (h || (h = c("WebStorage"))).getLocalStorageForRead();
        if (a === null || !b) return null;
        b = b.getItem(a);
        if (b == null) return null;
        a = b.split(":");
        b = a[0];
        a = a[1];
        a = parseInt(a, 10);
        return [b, a]
    }

    function p(a) {
        a = o(a);
        if (a !== null) {
            var b = a[0];
            a = a[1];
            if (Date.now() - a < d("ProfileCometSessionConfig").TIMEOUT_MS) return b
        }
        return null
    }

    function q(a, b) {
        var d = Date.now();
        a = i(a);
        var e = (h || (h = c("WebStorage"))).getLocalStorage();
        if (e && a !== null) {
            (h || (h = c("WebStorage"))).setItemGuarded(e, a, b + ":" + d);
            return b
        }
        return null
    }

    function r(a, b) {
        b = n(a, b);
        if (b == null) return null;
        q(a, b);
        return b
    }

    function a(a, b) {
        return n(a, b)
    }

    function b(a, b, c) {
        if (b != null) {
            var d = p(a);
            if (d === null) {
                l(a, b, c);
                return q(a, b)
            }
        }
        return r(a)
    }

    function e(a, b, c, e) {
        return d("ProfileCometSessionUtil").isSameProfileSession(b, c) || e === "popstate" || e === "initial" ? r(a, c) : m(a, c)
    }
    g.extend = r;
    g.get = a;
    g.initOrExtend = b;
    g.navigate = e
}), 98);
__d("CometTimeSpentNavigation", ["CometProductAttribution", "CometTimeSpentUtils", "CometVisitationManager", "ProfileCometSession"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = null,
        j = new Set();

    function k() {
        j.forEach(function(a) {
            return a({
                destPathInfo: i,
                sourcePathInfo: h
            })
        })
    }
    a = {
        changePath: function(a, b, c) {
            c === void 0 && (c = null);
            h = i;
            var e = a.entityID,
                f = a.parentContainerId,
                g = a.timeSpentConfig,
                j = a.tracePolicy,
                l = a.url;
            if (c && c.profile_session_id != null && e != null) {
                var m;
                c.profile_session_id = (m = d("ProfileCometSession").initOrExtend(e, (m = c) == null ? void 0 : m.profile_session_id, j)) != null ? m : (m = c) == null ? void 0 : m.profile_session_id
            }
            m = babelHelpers["extends"]({}, b);
            delete m.v2;
            b = d("CometProductAttribution").minifyProductAttributionV2(b);
            m = {
                pa: JSON.stringify(m),
                pav2: b,
                uri: l
            };
            m = d("CometTimeSpentUtils").addTimeSpentMetaData(a, m, c);
            b = d("CometVisitationManager").getCurrentVisitationId();
            b != null && (m.visitation_id = b);
            m.container_id == null && (e != null && (m.container_id = e));
            m.parent_container_id == null && f != null && (m.parent_container_id = f);
            i = {
                extraData: m,
                name: j,
                should_remove_navigation: (l = g == null ? void 0 : g.should_remove_navigation) != null ? l : !1
            };
            k()
        },
        getPathInfo: function() {
            return i
        },
        getSourcePathInfo: function() {
            return h
        },
        listenToPathChange: function(a) {
            j.add(a);
            return {
                cancelListen: function() {
                    return j["delete"](a)
                }
            }
        },
        resetPathInfoForTestingOnly: function() {
            h = null, i = null
        }
    };
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("CometDarkModeContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        currentSetting: "DISABLED",
        onDarkModeToggle: c("emptyFunction"),
        setDarkModeSetting: c("emptyFunction")
    });
    g["default"] = b
}), 98);
__d("CometRouterLoadingContextInternals_DO_NOT_USE", ["emptyFunction", "react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(function(a) {
        c("recoverableViolation")("CometRouterLoadingContextInternals is not set", "comet_infra");
        return c("emptyFunction")
    });
    g["default"] = b
}), 98);
__d("LSBase64Decode.nop", ["Base64Utils", "CryptoLogger", "LSResult", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a) {
        a = a.replace(/-/g, "+").replace(/_/g, "/").replace(/\./g, "=").replace("/,/", "=");
        var b = 4 - a.length % 4;
        if (b < 4)
            for (var c = 0; c < b; c++) a += "=";
        return a
    }

    function j(a) {
        var b = d("CryptoLogger").CryptoLogger("base64decode");
        try {
            return a != null ? d("Base64Utils").toArrayBuffer(i(a)) : void 0
        } catch (c) {
            if ((c == null ? void 0 : c.message) == null) return;
            if (c instanceof Error) b.catching(c).mustfix(c.message);
            else {
                b.mustfix("Base64decode : empty error message for exception: %s, input string: %s", c.message, (b = a) != null ? b : "undefined")
            }
        }
    }
    a = function(a, d, e) {
        return (h || (h = b("Promise"))).resolve(c("LSResult")(j(e)))
    };
    g["default"] = a
}), 98);
__d("EBMessageBulkPointQuery", ["EBAPIQPLPoints", "EBAPISharedUtils", "EBAPIWorkerCheck", "I64", "LSEncryptedBackupsBackupTenancy", "LSIntEnum", "LSVec", "MAWCurrentUser", "MAWEncryptedBackupUtils", "MAWEncryptedBackupsRestoreMessageOverGraphQL", "MAWQplProxy", "WABase64", "WAHashStringToNumber", "WALogger", "WAPushSafeTypes", "WAResultOrError", "WorkerRelay", "asyncToGeneratorRuntime", "cr:7713", "handleRestoreMessagesGraphQLResponse", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] graphQL range restore error ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] mandatory params of client state are null"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] No client state found - unable to restore"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Calling EBLS without EBLS being available for message range query"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] GQL point query called from non-worker context"]);
        n = function() {
            return a
        };
        return a
    }

    function a(a) {
        return o.apply(this, arguments)
    }

    function o() {
        o = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            if (!d("EBAPIWorkerCheck").runningInWorker()) {
                d("WALogger").ERROR(n());
                return d("WAResultOrError").makeError("called-from-main-thread")
            }
            a = d("WAPushSafeTypes").unsafeNotNullable(a);
            var e = a.mpsMessageQuery,
                f = a.sortOrderMsList,
                g = a.source,
                o = a.threadId;
            a = a.traceId;
            var p = a != null ? d("WAHashStringToNumber").hashStringToNumber(a) : void 0,
                q = c("qpl")._(521474469, "2612");
            try {
                d("MAWQplProxy").startQplUserFlow(q, {
                    bool: {
                        mainThreadRestore: !1,
                        workerThreadRestore: !0
                    }
                }, p);
                if (b("cr:7713") == null) {
                    d("WALogger").ERROR(m());
                    d("MAWQplProxy").sendQPLFailThroughBridge(q, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.EBLS_NOT_INITIALIZED, void 0, p);
                    return d("WAResultOrError").makeError("ebls-not-intialized")
                }
                yield b("cr:7713").init();
                var r = (yield b("cr:7713").getLSStorage()),
                    s = (yield d("MAWEncryptedBackupUtils").getBackupTenancy(r.tables));
                if (s != null && !(h || (h = d("I64"))).equal(s, (i || (i = d("LSIntEnum"))).ofNumber(c("LSEncryptedBackupsBackupTenancy").PRODUCTION))) {
                    d("MAWQplProxy").sendQPLFailThroughBridge(q, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.EB_NOT_ENABLED, void 0, p);
                    return d("WAResultOrError").makeError("eb-not-enabled")
                }
                s = (yield d("handleRestoreMessagesGraphQLResponse").getClientState(r));
                if (s == null) {
                    d("WALogger").ERROR(l());
                    d("MAWQplProxy").sendQPLFailThroughBridge(q, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.NO_CLIENT_STATE, void 0, p);
                    return d("WAResultOrError").makeError("no-client-state")
                }
                var t = s.device_id,
                    u = s.locally_available_epochs,
                    v = s.mailboxRootKey;
                s = s.ocmfClientStateBlob;
                if (t == null || v == null || s == null) {
                    d("WALogger").ERROR(k());
                    d("MAWQplProxy").sendQPLFailThroughBridge(q, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.INVALID_CLIENT_STATE, void 0, p);
                    return d("WAResultOrError").makeError("invalid-client-state")
                }
                var w = d("MAWCurrentUser").getAppID();
                u = {
                    restore_context: {
                        act_thread_id: o,
                        site: "www",
                        tam_thread_subtype: 0
                    },
                    success: {
                        device_context: {
                            device_id: (h || (h = d("I64"))).to_float(t),
                            locally_available_epochs: u,
                            raw_tokens: {
                                mailbox_root_key: d("WABase64").encodeB64(v),
                                ocmf_client_state_blob: d("WABase64").encodeB64(s)
                            }
                        },
                        mps_message_query: e
                    }
                };
                if (f != null) {
                    v = c("LSVec").ofArray(f.map(function(a) {
                        return (h || (h = d("I64"))).of_string("" + a)
                    }));
                    u = babelHelpers["extends"]({}, u, {
                        sort_order_ms_list: v
                    })
                }
                d("MAWQplProxy").sendQplPointThroughBridge(q, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.GRAPHQL_QUERY_START, {
                    instanceKey: p
                });
                e = (yield d("WorkerRelay").createWorkerQuery(d("MAWEncryptedBackupsRestoreMessageOverGraphQL").query, {
                    app_id: String((s = w) != null ? s : "0"),
                    restore_payload_string: JSON.stringify(u),
                    restore_type: "MESSAGE_QUERY_RESTORE"
                }));
                f = (yield d("EBAPISharedUtils").constructEBRestoreResponse(e, !0, q, r, p, t, o, g, a, void 0));
                if (f.success) return d("WAResultOrError").makeResult(f.response);
                else return d("WAResultOrError").makeError(f.response)
            } catch (a) {
                d("WALogger").ERROR(j(), a);
                d("MAWQplProxy").sendQPLFailThroughBridge(q, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.RUNTIME_ERROR, void 0, p);
                return d("WAResultOrError").makeError("runtime-error", a)
            }
        });
        return o.apply(this, arguments)
    }
    g.messageBulkPointQuery = a
}), 98);
__d("mergeDeep", ["mergeDeepInto", "mergeHelpers"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        var e;
        a = (e = c("mergeHelpers")).normalizeMergeArg(a);
        b = e.normalizeMergeArg(b);
        e.checkMergeObjectArgs(a, b);
        e.checkArrayStrategy(d);
        e = {};
        c("mergeDeepInto")(e, a, d);
        c("mergeDeepInto")(e, b, d);
        return e
    }
    g["default"] = a
}), 98);
__d("useCometRouterLoadingState", ["CometRouterLoadingContextInternals_DO_NOT_USE", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useContext,
        j = b.useEffect,
        k = b.useState;

    function a() {
        var a = i(c("CometRouterLoadingContextInternals_DO_NOT_USE")),
            b = k(!1),
            d = b[0],
            e = b[1];
        j(function() {
            var b = a(function(a) {
                e(a.loading)
            });
            return function() {
                b()
            }
        }, [a]);
        return d
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometEdfFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1922996");
    b = d("FalcoLoggerInternal").create("comet_edf", a);
    e = b;
    g["default"] = e
}), 98);
__d("MDSPinMessageIcon.react", ["MDSSvgIcon.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsx(c("MDSSvgIcon.react"), babelHelpers["extends"]({}, a, {
            children: i.jsx("path", {
                clipRule: "evenodd",
                d: "M21.3905 21.9975C21.1611 21.9975 20.9611 22.1536 20.9054 22.3762L19.2424 29.0265C18.9197 30.319 17.0805 30.3185 16.7577 29.0265L15.0947 22.3762C15.039 22.1536 14.839 21.9975 14.6096 21.9975H10.1675C9.21767 21.9975 8.68955 20.933 9.19619 20.1815C9.61488 19.5605 10.7291 18.1525 12.7846 17.1415C13.0959 16.9885 13.2942 16.6755 13.3207 16.33C13.4196 15.046 13.6545 12.991 13.7564 11.669C13.7849 11.3 13.606 10.945 13.2912 10.751C12.1855 10.0695 11.526 9.2765 11.2157 8.837C10.6741 8.07 11.2122 7 12.163 7H23.8376C24.7879 7 25.3255 8.0705 24.7844 8.837C24.4741 9.2765 23.8141 10.0695 22.7089 10.751C22.3941 10.945 22.2158 11.3 22.2437 11.669C22.3457 12.991 22.5805 15.046 22.6794 16.33C22.7059 16.6755 22.9048 16.9885 23.216 17.1415C25.2711 18.1525 26.3853 19.5605 26.8039 20.1815C27.3101 20.933 26.783 21.9975 25.8327 21.9975H21.3905Z",
                fillRule: "evenodd"
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWPinnedMessageRowFooterNUX.react", ["fbt", "MDSPinMessageIcon.react", "MWLSThreadCapabilities", "MWPMessageListColumn.react", "MWXText.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react"),
        k = h._("__JHASH__UnoAJjMNsJN__JHASH__");

    function a() {
        var a = d("MWLSThreadCapabilities").useCapabilities();
        a = d("MWLSThreadCapabilities").canPinMessage(a);
        return a && j.jsx(d("MWPMessageListColumn.react").MWPMessageListColumnWithGutters, {
            shrinkwrap: !0,
            children: j.jsxs("div", {
                className: "x6s0dn4 x78zum5 x1q0g3np xr9ek0c",
                children: [j.jsx(c("MDSPinMessageIcon.react"), {
                    color: "tertiary",
                    size: 16
                }), j.jsx("div", {
                    className: "x12mruv9",
                    children: j.jsx(c("MWXText.react"), {
                        color: "tertiary",
                        type: "meta4",
                        children: k
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("declareNUXRequireable", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f["default"] = a
}), 66);
__d("useMWSimpleNuxViewsCounter.react", ["MWInboxPersistedUIState", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useEffect,
        j = 3,
        k = 24 * 60 * 60 * 1e3,
        l = function(a, b) {
            return +new Date() < b + a
        },
        m = function(a) {
            return l(k, a.lastViewDate)
        },
        n = function(a) {
            return a.views >= j
        },
        o = function(a) {
            return !!a && !m(a) && !n(a)
        },
        p = function(a) {
            return {
                lastViewDate: +new Date(),
                views: a.views + 1
            }
        },
        q = {
            lastViewDate: 0,
            views: 0
        };

    function a(a, b, c) {
        a = d("MWInboxPersistedUIState").usePersistedUIState(q, "__MWSimpleNux." + a + "__");
        var e = a[0],
            f = a[1];
        i(function() {
            if (!b || e === void 0) return;
            if (m(e)) return;
            return function() {
                var a = p(e);
                n(a) ? (f(void 0), c()) : f(a)
            }
        }, [b, c, e, f]);
        return o(e)
    }
    g["default"] = a
}), 98);
__d("useNUXLoggers", ["CometEdfFalcoEvent", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useMemo,
        j = b.useRef;

    function a(a, b, d) {
        d === void 0 && (d = !0);
        var e = j({
            hidden: !1,
            visible: !1
        });
        return i(function() {
            return {
                onDismiss: function() {
                    if (a == null || !d) return;
                    b(a);
                    c("CometEdfFalcoEvent").logImmediately(function() {
                        return {
                            nux: a,
                            type: "dismiss"
                        }
                    })
                },
                onHelpful: function(b) {
                    if (a == null || !d) return;
                    c("CometEdfFalcoEvent").log(function() {
                        return {
                            nux: a,
                            step_key: b,
                            type: "helpful"
                        }
                    })
                },
                onHidden: function() {
                    if (a == null || !d || e.current.hidden || e.current.visible !== !0) return;
                    e.current.hidden = !0;
                    c("CometEdfFalcoEvent").log(function() {
                        return {
                            nux: a,
                            type: "hidden"
                        }
                    })
                },
                onNotHelpful: function(b) {
                    if (a == null || !d) return;
                    c("CometEdfFalcoEvent").log(function() {
                        return {
                            nux: a,
                            step_key: b,
                            type: "not_helpful"
                        }
                    })
                },
                onRemoved: function() {
                    if (a == null) return;
                    b(a)
                },
                onVisible: function() {
                    if (a == null || !d || e.current.visible) return;
                    e.current.visible = !0;
                    c("CometEdfFalcoEvent").logCritical(function() {
                        return {
                            nux: a,
                            type: "visible"
                        }
                    })
                }
            }
        }, [d, a, b])
    }
    g["default"] = a
}), 98);
__d("useSharedNUX", ["CometNUXManagerContext", "react", "recoverableViolation", "useNUXLoggers", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useContext,
        j = b.useEffect,
        k = b.useState;

    function a(a) {
        var b = c("useStable")(function() {
            return a
        });
        if (b !== a) {
            var d;
            c("recoverableViolation")("Error nux changed at runtime from " + ((d = b) != null ? d : "null") + " to " + ((d = a) != null ? d : "null") + ", this is not supported and will lead to erratic behavior, we have continued to use your initially supplied nux", "comet_ui")
        }
        d = k(!1);
        var e = d[0],
            f = d[1];
        d = i(c("CometNUXManagerContext"));
        var g = d.registerNUX;
        d = d.removeNUX;
        j(function() {
            if (b == null) return;
            return g(b, f, !0)
        }, [b, g]);
        d = c("useNUXLoggers")(b, d);
        return [e, d]
    }
    g["default"] = a
}), 98);
__d("MWPinnedMessageRowFooterNUXWrapper.react", ["MWPinnedMessageRowFooterNUX.react", "declareNUXRequireable", "react", "useMWSimpleNuxViewsCounter.react", "useSharedNUX"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        function b() {
            var b = c("useSharedNUX")(a),
                d = b[0];
            b = b[1].onDismiss;
            b = c("useMWSimpleNuxViewsCounter.react")(a, d, b);
            return d && b ? i.jsx(c("MWPinnedMessageRowFooterNUX.react"), {}) : null
        }
        b.displayName = b.name + " [from " + f.id + "]";
        return b
    }
    b = c("declareNUXRequireable")(a);
    g["default"] = b
}), 98);
__d("MWPinnedMessagesDialogNUXFactory.react", ["JSResourceForInteraction", "MWInboxPersistedUIState", "declareNUXRequireable", "react", "useMWXLazyDialog", "useSharedNUX"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || (h = d("react"));
    b = h;
    var i = b.useCallback,
        j = b.useMemo,
        k = c("JSResourceForInteraction")("MWPinnedMessagesDialogNUX.react").__setRef("MWPinnedMessagesDialogNUXFactory.react");

    function a(a) {
        function b(b) {
            var e = b.children,
                f = b.dialogProps;
            b = c("useSharedNUX")(a);
            var g = b[0],
                h = b[1];
            b = d("MWInboxPersistedUIState").usePersistedUIState(void 0, "__MWSimpleNux." + a + "__");
            b[0];
            var l = b[1],
                m = i(function() {
                    l(void 0), h.onDismiss()
                }, [h, l]),
                n = j(function() {
                    return {
                        onDismiss: m,
                        pinMessageHandler: f.pinMessageHandler
                    }
                }, [f, m]);
            b = c("useMWXLazyDialog")(k);
            var o = b[0];
            b = function() {
                return o(n)
            };
            return g ? e(b) : e(f.pinMessageHandler)
        }
        b.displayName = b.name + " [from " + f.id + "]";
        return b
    }
    e = c("declareNUXRequireable")(a);
    g["default"] = e
}), 98); /*FB_PKG_DELIM*/
__d("cometTypeaheadODSLogFetchCacheEvent", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("ODS").__setRef("cometTypeaheadODSLogFetchCacheEvent");

    function a(a, b, c) {
        b === void 0 && (b = !0);
        c === void 0 && (c = 1);
        if (!b) return;
        h.onReady(function(b) {
            b.bumpEntityKey(354, a, "fetched-cache", c)
        })
    }
    g["default"] = a
}), 98);
__d("useBaseTypeaheadDataSourceFetchResolverCache", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useCallback;

    function a(a) {
        var b = a.dataSource;
        return i(function(a) {
            var c = a.onResolvePayload;
            a = a.requestParams;
            var d = a.perfTraceAPI;
            a = b.fetchCache(a);
            d && d.addMarkerPoint("cachedResponse", "AppTiming");
            c(a);
            return a
        }, [b])
    }
    g["default"] = a
}), 98);
__d("useBaseTypeaheadDataSourceFetchResolverNetwork", ["promiseDone", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useRef,
        l = b.useState;

    function a(a) {
        var b = a.dataSource;
        a = l(!1);
        var d = a[0],
            e = a[1],
            f = k(0),
            g = k(!1);
        j(function() {
            g.current = !1;
            return function() {
                g.current = !0
            }
        }, []);
        a = i(function(a) {
            var d = a.onResolvePayload;
            a = a.requestParams;
            f.current++;
            var h = f.current,
                i = a.perfTraceAPI;
            e(!0);
            c("promiseDone")(b.fetchNetwork(a).then(function(a) {
                !g.current && h === f.current && (d(a), i && i.addMarkerPoint("networkResponse", "AppTiming"))
            })["finally"](function() {
                !g.current && h === f.current && (f.current = 0, e(!1))
            }))
        }, [b]);
        return [{
            isLoading: d
        }, a]
    }
    g["default"] = a
}), 98);
__d("useBaseTypeaheadDataSourceFetchResolver", ["baseTypeaheadFlattenEntries", "cometTypeaheadODSLogFetchCacheEvent", "cometTypeaheadODSLogFetchNetworkEvent", "emptyObject", "react", "recoverableViolation", "useBaseTypeaheadDataSourceFetchResolverCache", "useBaseTypeaheadDataSourceFetchResolverNetwork", "useDebouncedComet"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useRef,
        k = 8;

    function a(a, b) {
        var d = a.dataSource,
            e = a.dataSourceFetchConfigParams,
            f = a.onResolvePayload;
        e = (a = e) != null ? a : c("emptyObject");
        a = e.renderLimit;
        var g = a === void 0 ? k : a;
        a = e.bypassCacheRenderLimitCheck;
        var h = a === void 0 ? !1 : a;
        a = e.shouldDebounceNetwork;
        var l = a === void 0 ? !0 : a;
        a = e.networkDebounceWaitDuration;
        e = e.requestFlow;
        var m = j(e),
            n = c("useBaseTypeaheadDataSourceFetchResolverCache")({
                dataSource: d
            });
        e = c("useBaseTypeaheadDataSourceFetchResolverNetwork")({
            dataSource: d
        });
        var o = e[0].isLoading,
            p = e[1],
            q = c("useDebouncedComet")(p, {
                wait: a
            });

        function r() {
            var a = !1;

            function e(b, d) {
                var e = d.isTraceComplete;
                d = d.source;
                try {
                    a || f(b, {
                        isTraceComplete: e,
                        source: d
                    })
                } catch (b) {
                    a || c("recoverableViolation")("Failed to resolve fetched payload", "search")
                }
            }

            function i(a) {
                var b = a.requestParams;
                a = a.source;
                var f = b.requestFlow;
                f != null && (m.current = f);
                if (typeof d.fetchCache === "function" && ["all", "cache"].includes(a)) {
                    f = n({
                        onResolvePayload: function(a) {
                            var b = a.entries;
                            b = c("baseTypeaheadFlattenEntries")(b).length;
                            e(a, {
                                isTraceComplete: !h && b >= g,
                                source: "cache"
                            });
                            c("cometTypeaheadODSLogFetchCacheEvent") && c("cometTypeaheadODSLogFetchCacheEvent")("comet.ta.fetch", !0, 1)
                        },
                        requestParams: b
                    });
                    f = f;
                    f = f.entries;
                    f = c("baseTypeaheadFlattenEntries")(f).length;
                    if (!h && f >= g) return
                }
                if (typeof d.fetchNetwork === "function" && ["all", "network"].includes(a)) {
                    f = {
                        onResolvePayload: function(a) {
                            e(a, {
                                isTraceComplete: !0,
                                source: a.entries.length > 0 ? "network" : "network-no-results"
                            }), c("cometTypeaheadODSLogFetchNetworkEvent") && c("cometTypeaheadODSLogFetchNetworkEvent")("comet.ta.fetch", !0, 1)
                        },
                        requestParams: babelHelpers["extends"]({}, b, {
                            requestFlow: m.current
                        })
                    };
                    Boolean(l) ? q(f) : p(f)
                }
            }
            b != null && i(b);
            return function() {
                a = !0
            }
        }
        i(r, [b]);
        return [{
            isLoading: o
        }]
    }
    g["default"] = a
}), 98);
__d("useBaseTypeaheadDataSourceFetch", ["react", "recoverableViolation", "useBaseTypeaheadDataSourceFetchResolver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useState;

    function a(a) {
        var b = j(null),
            d = b[0],
            e = b[1];
        b = c("useBaseTypeaheadDataSourceFetchResolver")(a, d);
        a = b[0].isLoading;
        var f = i(function(a, b) {
            b === void 0 && (b = "all"), e({
                requestParams: a,
                source: b
            })
        }, []);
        b = i(function(a) {
            a = a || {};
            var b = a.requestFlow;
            a = a.source;
            if (d == null) {
                c("recoverableViolation")("Refetch cannot be called with undefined `fetchParams`", "search");
                return
            }
            var e = d.requestParams,
                g = e.loggingEventTrace;
            e = babelHelpers.objectWithoutPropertiesLoose(e, ["loggingEventTrace"]);
            g = babelHelpers["extends"]({
                loggingEventTrace: babelHelpers["extends"]({}, g, {
                    sequenceID: String(Date.now())
                }),
                requestFlow: b
            }, e);
            f(g, a)
        }, [f, d]);
        return [{
            isLoading: a,
            source: (a = d == null ? void 0 : d.source) != null ? a : "all"
        }, f, b]
    }
    g["default"] = a
}), 98);
__d("CometTypeaheadViewList.react", ["CometCompositeStructureContext", "getItemRoleFromCompositeRole", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;

    function a(a) {
        var b = a.ariaProps,
            d = a.children,
            e = a.entries,
            f = a.highlightedEntry;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["ariaProps", "children", "entries", "highlightedEntry"]);
        var g = f != null ? f.key : null,
            h = b.role;
        a = j(function() {
            return babelHelpers["extends"]({}, h != null ? {
                role: h
            } : {})
        }, [h]);
        var k = c("getItemRoleFromCompositeRole")(h);
        return e != null && e.length > 0 ? i.jsx("ul", babelHelpers["extends"]({}, b, {
            className: "x78zum5 xdt5ytf x1iyjqo2",
            "data-testid": void 0,
            children: i.jsx(c("CometCompositeStructureContext").Provider, {
                value: a,
                children: e.map(function(a, b) {
                    var c = g === a.key;
                    return d({
                        entry: a,
                        index: b,
                        isActive: c,
                        itemRole: k
                    })
                })
            })
        })) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTypeaheadViewListStrategy.react", ["CometTypeaheadViewList.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.ariaProps,
            d = a.entries;
        a.extraViewProps;
        var e = a.highlightedEntry;
        a.isLoading;
        a.onAbandonTypeahead_DO_NOT_USE;
        var f = a.viewItemStrategyRenderer,
            g = babelHelpers.objectWithoutPropertiesLoose(a, ["ariaProps", "entries", "extraViewProps", "highlightedEntry", "isLoading", "onAbandonTypeahead_DO_NOT_USE", "viewItemStrategyRenderer"]);
        return i.jsx(c("CometTypeaheadViewList.react"), {
            ariaProps: b,
            entries: d,
            highlightedEntry: e,
            testid: void 0,
            children: function(a) {
                var b = a.entry,
                    c = a.isActive;
                a = a.itemRole;
                return i.createElement(f, babelHelpers["extends"]({}, g, {
                    entry: b,
                    isActive: c,
                    key: b.key,
                    role: a
                }))
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometTypeaheadViewListStrategy", ["CometTypeaheadProgressGlimmer.react", "CometTypeaheadViewListStrategy.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useCallback;

    function a(a) {
        var b = a.emptyStateContent,
            d = a.extraViewProps,
            e = a.loadingState,
            f = a.nullstateContent,
            g = a.viewItemStrategyRenderer,
            i = a.viewListStrategyRenderer,
            l = i === void 0 ? c("CometTypeaheadViewListStrategy.react") : i,
            m = a.viewXStyle;
        return k(function(a) {
            var i = a.entries,
                k = a.isLoading,
                n = a.queryString;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["entries", "isLoading", "queryString"]);
            if (n.length === 0 && f != null) return f;
            return !k && i.length === 0 && b != null ? b : j.jsxs("div", {
                className: (h || (h = c("stylex")))([m]),
                children: [j.jsx(l, babelHelpers["extends"]({}, a, {
                    entries: i,
                    extraViewProps: d,
                    isLoading: !1,
                    queryString: n,
                    viewItemStrategyRenderer: g
                })), k && ((a = e) != null ? a : j.jsx(c("CometTypeaheadProgressGlimmer.react"), {}))]
            })
        }, [l, b, d, e, f, g, m])
    }
    g["default"] = a
}), 98);