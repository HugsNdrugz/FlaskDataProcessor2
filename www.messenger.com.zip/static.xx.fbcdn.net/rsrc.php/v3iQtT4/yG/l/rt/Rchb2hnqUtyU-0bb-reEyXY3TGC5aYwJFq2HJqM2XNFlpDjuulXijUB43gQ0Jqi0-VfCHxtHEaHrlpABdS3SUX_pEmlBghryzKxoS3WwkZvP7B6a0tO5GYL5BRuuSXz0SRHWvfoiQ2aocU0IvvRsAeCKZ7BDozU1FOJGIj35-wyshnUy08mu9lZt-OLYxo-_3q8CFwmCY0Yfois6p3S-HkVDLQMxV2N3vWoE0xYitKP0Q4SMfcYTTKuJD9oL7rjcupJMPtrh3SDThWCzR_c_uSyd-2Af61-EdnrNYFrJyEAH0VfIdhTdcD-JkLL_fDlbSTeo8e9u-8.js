; /*FB_PKG_DELIM*/

__d("BaseFileSelector.react", ["Promise", "promiseDone", "react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    e = i;
    var k = e.useCallback,
        l = e.useEffect,
        m = e.useRef;

    function n(a) {
        return a.map(function(a) {
            if (a.indexOf("/") !== -1 || a[0] === ".") return a;
            c("recoverableViolation")('Accept parameter "' + a + '" for BaseFileSelector is being interpreted as a file extension since it has no slash (/), but file extensions must start with a period (.)', "profile_comet");
            return "." + a
        }).join(",")
    }

    function a(a) {
        var d = a.accept,
            e = a.children,
            f = a.multiple;
        f = f === void 0 ? !1 : f;
        var g = a.onFilesSelected,
            i = m(null);
        l(function() {
            var a = i.current;
            if (a != null) {
                var b = function(a) {
                    a.stopPropagation()
                };
                a.addEventListener("click", b);
                return function() {
                    a.removeEventListener("click", b)
                }
            }
        });
        a = k(function() {
            i.current != null && i.current.click()
        }, []);
        var o = k(function(a) {
            var d = g(a.currentTarget.files);
            d instanceof(h || (h = b("Promise"))) && c("promiseDone")(d);
            a.currentTarget.value = ""
        }, [g]);
        return j.jsxs(j.Fragment, {
            children: [j.jsx("input", {
                accept: d != null ? n(d) : void 0,
                className: "x1s85apg",
                multiple: f,
                onChange: o,
                ref: i,
                type: "file"
            }), e(a)]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWEphemeralGatingUtil", ["$InternalEnum", "MetaConfig", "gkx", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = b("$InternalEnum")({
        SEEN_BASED: 0,
        SEND_BASED: 1
    });
    var h = "0,60,900,86400";

    function a() {
        var a = c("MetaConfig")._("56");
        (a === null || a === "") && (a = h);
        a = a.replace('"', "").split(",").map(function(a) {
            return parseInt(a, 10)
        });
        c("gkx")("2260") && a.push(10, 30, 60, 120);
        return a
    }

    function d() {
        var a = c("MetaConfig")._("65");
        return c("justknobx")._("1546") && a
    }
    g.EphemeralityType = e;
    g.getExpirationOptions = a;
    g.isResetEphemeralSettingsEnabled = d
}), 98);
__d("updateEphemeralDuration", ["JSResourceForInteraction", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f, g, h) {
        var i = d("WATimeUtils").millisTime();
        return c("JSResourceForInteraction")("MAWEphemeralSettingsUpdate").__setRef("updateEphemeralDuration").load().then(function(a) {
            return a.updateEphemeralSettings(b, i, e, h)
        }).then(function(a) {
            f();
            return !0
        })["catch"](function(a) {
            g();
            return !1
        })
    }
    g["default"] = a
}), 98);
__d("useMAWCreateOptimisticSecureMessageNoOp", ["err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return function() {
            throw c("err")("Attempted to use separate read hooks in non-separate read mode")
        }
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("Clipboard", ["Promise", "UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        return window.document && window.document.queryCommandSupported instanceof Function && window.document.queryCommandSupported("copy") && !(c("UserAgent").isBrowser("Firefox < 41") || c("UserAgent").isPlatform("iOS < 10.3")) || c("UserAgent").isBrowser("Chrome >= 43")
    }

    function i(a, b) {
        b = b || document.body;
        if (!b) return !1;
        var d = document.activeElement,
            e = !0,
            f = document.createElement("textarea");
        b.appendChild(f);
        f.value = a;
        if (c("UserAgent").isPlatform("iOS >= 10.3")) {
            a = document.createRange();
            a.selectNodeContents(f);
            var g = window.getSelection();
            g.removeAllRanges();
            g.addRange(a);
            f.setSelectionRange(0, 999999)
        } else f.select();
        try {
            e = document.execCommand("copy")
        } catch (a) {
            e = !1
        }
        b.removeChild(f);
        d != null && d.focus();
        return e
    }

    function d(a) {
        var b = window.getSelection(),
            c = null;
        b.rangeCount > 0 && (c = b.getRangeAt(0));
        var d = document.createRange();
        d.selectNodeContents(a);
        b.removeAllRanges();
        b.addRange(d);
        try {
            document.execCommand("copy"), a = !0
        } catch (b) {
            a = !1
        }
        b.removeAllRanges();
        c !== null && b.addRange(c);
        return a
    }

    function e(a) {
        var c = window.navigator;
        if (c && c.clipboard && typeof c.clipboard.writeText === "function") return c.clipboard.writeText(a);
        return i(a) ? (h || (h = b("Promise"))).resolve() : (h || (h = b("Promise"))).reject()
    }
    g.isSupported = a;
    g.copy = i;
    g.copyDOM = d;
    g.copyAsync = e
}), 98);
__d("goURIOnWindow", ["ConstUriUtils", "FBLogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var e = typeof b === "string" ? d("ConstUriUtils").getUri(b) : d("ConstUriUtils").isConstUri(b);
        if (e) {
            if (a == null) return !1;
            a.location = e.toString();
            return !0
        } else {
            a = "Invalid URI " + b.toString() + " provided to goURIOnWindow";
            c("FBLogger")("comet_infra").blameToPreviousFrame().mustfix(a);
            return !1
        }
    }
    g["default"] = a
}), 98);
__d("useCopyText", ["Clipboard", "DateConsts", "clearTimeout", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useRef,
        k = b.useState;

    function a(a) {
        var b = a.onCopyPress,
            e = a.value;
        a = k(!1);
        var f = a[0],
            g = a[1],
            h = j(null),
            l = d("Clipboard").isSupported();
        a = i(function() {
            b != null && b();
            if (l && typeof e === "string") {
                var a = d("Clipboard").copy(e);
                a === !0 && (g(!0), c("clearTimeout")(h.current), h.current = c("setTimeout")(function() {
                    g(!1)
                }, .75 * d("DateConsts").MS_PER_SEC))
            }
        }, [b, l, e]);
        return [l, f, a]
    }
    g["default"] = a
}), 98);
__d("XMessengerHelpCenterContentControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/help/messenger-app/{cms_id}/{?cms_title}/", Object.freeze({
        region_hint: [],
        expand_folders: []
    }), void 0);
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("BrowserLockManager", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = typeof window !== "undefined" ? window : self;
    c = a == null ? void 0 : (b = a.navigator) == null ? void 0 : b.locks;
    f["default"] = c
}), 66);
__d("LockManager", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        Exclusive: "exclusive",
        Shared_NOT_IMPLEMENTED: "shared"
    });
    f.LockMode = a
}), 66);
__d("hasMultipleTabs", ["BrowserLockManager", "FBLogger", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "multiple_tab_lock";

    function a(a) {
        var d, e;
        return b("regeneratorRuntime").async(function(f) {
            while (1) switch (f.prev = f.next) {
                case 0:
                    a === void 0 && (a = !0);
                    f.prev = 1;
                    if (!c("BrowserLockManager")) {
                        f.next = 11;
                        break
                    }
                    f.next = 5;
                    return b("regeneratorRuntime").awrap(c("BrowserLockManager").query());
                case 5:
                    d = f.sent;
                    e = d.held.filter(function(a) {
                        return a.name === h
                    }).length + d.pending.filter(function(a) {
                        return a.name === h
                    }).length;
                    a || e++;
                    if (!(e > 1)) {
                        f.next = 10;
                        break
                    }
                    return f.abrupt("return", !0);
                case 10:
                    return f.abrupt("return", !1);
                case 11:
                    return f.abrupt("return");
                case 14:
                    f.prev = 14;
                    f.t0 = f["catch"](1);
                    c("FBLogger")("messenger_e2ee_web").catching(f.t0).warn("[MultipleTabsLogger] Fail to query lock manager");
                    return f.abrupt("return");
                case 18:
                case "end":
                    return f.stop()
            }
        }, null, this, [
            [1, 14]
        ])
    }
    g.MULTIPLE_TAB_LOCK_NAME = h;
    g.hasMultipleTabs = a
}), 98);
__d("memoizeOneWithArgs", ["areEqual"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b) {
        b === void 0 && (b = h || (h = c("areEqual")));
        var d, e, f = !1;
        return function() {
            for (var c = arguments.length, g = new Array(c), h = 0; h < c; h++) g[h] = arguments[h];
            if (f && b(g, d)) return e;
            d = g;
            e = a.apply(void 0, g);
            f = !0;
            return e
        }
    }
    g["default"] = a
}), 98);
__d("MultipleTabsLogger", ["BrowserLockManager", "InteractionTracingMetrics", "LockManager", "Promise", "QPLUserFlow", "hasMultipleTabs", "memoizeOneWithArgs", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = !1,
        j = !1;

    function a() {
        return i
    }

    function k() {
        return d("hasMultipleTabs").hasMultipleTabs(j)
    }

    function l() {
        var a;
        return b("regeneratorRuntime").async(function(c) {
            while (1) switch (c.prev = c.next) {
                case 0:
                    c.next = 2;
                    return b("regeneratorRuntime").awrap(k());
                case 2:
                    a = c.sent;
                    return c.abrupt("return", a != null ? a.toString() : "undefined");
                case 4:
                case "end":
                    return c.stop()
            }
        }, null, this)
    }

    function e(a) {
        void l().then(function(b) {
            return c("InteractionTracingMetrics").addMetadata(a, "multipleTabs", b)
        })
    }

    function f(a, b) {
        void l().then(function(d) {
            b !== null ? c("QPLUserFlow").addAnnotations(a, {
                string: {
                    multipleTabs: d
                }
            }, {
                instanceKey: b
            }) : c("QPLUserFlow").addAnnotations(a, {
                string: {
                    multipleTabs: d
                }
            })
        })
    }
    var m = c("memoizeOneWithArgs")(function(a) {
        c("BrowserLockManager") && (j = !0, void c("BrowserLockManager").request(d("hasMultipleTabs").MULTIPLE_TAB_LOCK_NAME, {
            mode: d("LockManager").LockMode.Exclusive
        }, function(c) {
            if (c) {
                i = !0;
                return new(h || (h = b("Promise")))(function(b) {
                    if (a) return b(a())
                })
            }
        }))
    });
    g.hasUniqueLock = a;
    g.hasMultipleTabs = k;
    g.getMultipleTabsAnnotation = l;
    g.addAnnotationWithInteractionUuid = e;
    g.addAnnotationToQPLEvent = f;
    g.init = m
}), 98); /*FB_PKG_DELIM*/
__d("useShouldShowPlaybackErrorFallback", ["I64", "LSIntEnum", "MAWVideoAudioPlaybackErrorHandlerUtils", "MessagingAttachmentType", "cr:12242", "useEmptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (e = b("cr:12242")) != null ? e : c("useEmptyFunction");

    function a(a, b) {
        b = (b = j(a, b)) != null ? b : {};
        b = b.validationResult;
        a = a.attachmentType;
        a = (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").VIDEO)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").AUDIO));
        if (!a) return !1;
        a = d("MAWVideoAudioPlaybackErrorHandlerUtils").isPlaybackErrorFallbackEnabled();
        if (!a) return !1;
        b = (a = b) != null ? a : {};
        a = b.mimeType;
        return a === "invalid-mp4"
    }
    g["default"] = a
}), 98);
__d("useShouldShowUnsupportedCodecFallback", ["I64", "LSIntEnum", "MAWVideoAudioPlaybackErrorHandlerUtils", "MessagingAttachmentType", "UserAgent", "cr:12242", "useEmptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (e = b("cr:12242")) != null ? e : c("useEmptyFunction"),
        k = Object.freeze({
            Chrome: ["H263", "Vvc"],
            Edge: ["H263", "Vvc"],
            Firefox: ["H263", "Vvc", "Hevc"],
            Safari: ["H263", "Vvc", "Vp9", "Av1"]
        });

    function l(a) {
        if (a == null) return !0;
        if (c("UserAgent").isBrowser("Chrome")) return k.Chrome.includes(a) === !1;
        else if (c("UserAgent").isBrowser("Firefox")) return k.Firefox.includes(a) === !1;
        else if (c("UserAgent").isBrowser("Edge")) return k.Edge.includes(a) === !1;
        else if (c("UserAgent").isBrowser("Safari")) return k.Safari.includes(a) === !1;
        return !0
    }

    function a(a, b) {
        b = (b = j(a, b)) != null ? b : {};
        b = b.validationResult;
        a = a.attachmentType;
        a = (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").VIDEO)) || (h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").AUDIO));
        if (!a) return !1;
        a = d("MAWVideoAudioPlaybackErrorHandlerUtils").isPlaybackErrorFallbackEnabled();
        if (!a) return !1;
        b = (a = b) != null ? a : {};
        a = b.videoStreamType;
        return l(a) === !1
    }
    g["default"] = a
}), 98);
__d("MAWVideoAudioPlaybackErrorHandlerUtils", ["fbt", "BaseMiddot.react", "I64", "LSIntEnum", "MWXLink.react", "MessagingAttachmentType", "qex", "react", "useMWV2MediaViewerSecurePlayableUrl", "useShouldShowPlaybackErrorFallback", "useShouldShowUnsupportedCodecFallback"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = k || c("react");

    function a(a) {
        if (a === !0) {
            return (a = c("qex")._("3007")) != null ? a : !1
        }
        return (a = c("qex")._("3008")) != null ? a : !1
    }

    function b(a, b, e) {
        var f, g;
        f = (f = c("useShouldShowPlaybackErrorFallback")(a, null)) != null ? f : !1;
        g = (g = c("useShouldShowUnsupportedCodecFallback")(a, null)) != null ? g : !1;
        var k = c("useMWV2MediaViewerSecurePlayableUrl")();
        if (f) return {
            downloadButton: null,
            mediaStatusText: h._("__JHASH__9pTPm1txftc__JHASH__"),
            retryButton: null
        };
        if (g) {
            f = (i || (i = d("I64"))).equal(a.attachmentType, (j || (j = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").VIDEO));
            g = i.equal(a.attachmentType, j.ofNumber(c("MessagingAttachmentType").AUDIO));
            if (f) {
                f = l.jsxs(l.Fragment, {
                    children: [l.jsx(c("BaseMiddot.react"), {}), l.jsx(c("MWXLink.react"), {
                        download: !0,
                        href: k(a, "MAWVideoAudioPlaybackErrorHandlerUtils"),
                        children: h._("__JHASH__3MspJ4rRDaT__JHASH__")
                    })]
                });
                return {
                    downloadButton: f,
                    mediaStatusText: h._("__JHASH__-Hi1PFpXdXk__JHASH__"),
                    retryButton: null
                }
            }
            if (g) return {
                downloadButton: null,
                mediaStatusText: h._("__JHASH__x5Yq4cFsR_G__JHASH__"),
                retryButton: null
            }
        }
        k = b ? l.jsxs(l.Fragment, {
            children: [l.jsx(c("BaseMiddot.react"), {}), l.jsx(c("MWXLink.react"), {
                onClick: e,
                children: h._("__JHASH__BGxC_0TtXwE__JHASH__")
            })]
        }) : null;
        return {
            downloadButton: null,
            mediaStatusText: h._("__JHASH__jCbL2nmLvOs__JHASH__"),
            retryButton: k
        }
    }
    g.isPlaybackErrorFallbackEnabled = a;
    g.useGetMetadataForMediaNotRendered = b
}), 226); /*FB_PKG_DELIM*/
__d("BaseList.react", ["CometCompositeStructureContext", "CometFocusGroup.react", "focusScopeQueries", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;
    b = i.forwardRef(a);

    function a(a, b) {
        var e = a["aria-label"],
            f = a["aria-labelledby"],
            g = a.children,
            h = a.keyNavOrientation_DEPRECATED,
            k = a.role,
            l = a.testid,
            m = a.xstyle,
            n = (l = k) != null ? l : "list";
        a = j(function() {
            return {
                role: n
            }
        }, [n]);
        return h != null ? i.jsx(c("CometFocusGroup.react"), {
            orientation: h,
            role: k,
            tabScopeQuery: d("focusScopeQueries").tabbableScopeQuery,
            children: function(a) {
                var c;
                return i.jsx(d("react-strict-dom").html.div, {
                    "aria-label": (c = e) != null ? c : void 0,
                    "aria-labelledby": f,
                    ref: b,
                    role: (c = k) != null ? c : void 0,
                    style: [a, [m]],
                    children: g
                })
            }
        }) : i.jsx(d("react-strict-dom").html.div, {
            "aria-label": (l = e) != null ? l : void 0,
            "aria-labelledby": f,
            "data-testid": void 0,
            ref: b,
            role: n,
            style: m,
            children: i.jsx(c("CometCompositeStructureContext").Provider, {
                value: a,
                children: g
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("CometList.react", ["BaseList.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            margins: {
                marginBottom: "x1oo3vh0",
                marginTop: "x1rdy4ex",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        var d = a.children,
            e = a.items,
            f = a.keyNavOrientation_DEPRECATED,
            g = a.label,
            h = a.role,
            k = a.testid;
        a = a.withNegativeMargins;
        e = typeof d === "function" ? ((e = e) != null ? e : []).map(function(a, b) {
            if (a == null || typeof a !== "object") return null;
            if (a.key == null) return d({
                item: a,
                key: b
            });
            a.key;
            b = babelHelpers.objectWithoutPropertiesLoose(a, ["key"]);
            return d({
                item: b,
                key: a.key
            })
        }) : d;
        g = {
            "aria-label": g,
            keyNavOrientation_DEPRECATED: f,
            role: h,
            testid: k
        };
        return i.jsx(c("BaseList.react"), babelHelpers["extends"]({}, g, {
            ref: b,
            xstyle: a && j.margins,
            children: e
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("XInstagramHelpDotComContentControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/{cms_id}/{?cms_title}/", Object.freeze({
        region_hint: [],
        expand_folders: [],
        force_new_ighc: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("useJSON", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useMemo;

    function a(a, b) {
        return i(function() {
            return JSON.parse(a, b)
        }, [a, b])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("MDSScrollableAreaStyles", [], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        themed: {
            scrollbarColor: "x16o0dkt",
            $$css: !0
        },
        unthemed: {
            scrollbarColor: "xgjnz6y",
            $$css: !0
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("MDSScrollableArea.react", ["CometScrollableArea.react", "MDSScrollableAreaStyles", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["xstyle"]);
        return i.jsx(c("CometScrollableArea.react"), babelHelpers["extends"]({
            forceBrowserDefault: !0,
            xstyle: [c("MDSScrollableAreaStyles").unthemed, b]
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MessengerWebEventsFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("230");
    b = d("FalcoLoggerInternal").create("messenger_web_events", a);
    e = b;
    g["default"] = e
}), 98);
__d("intlList", ["fbt", "invariant", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    a = i || b("react");
    var j = {
            AND: "AND",
            NONE: "NONE",
            OR: "OR"
        },
        k = {
            BULLET: "BULLET",
            COMMA: "COMMA",
            SEMICOLON: "SEMICOLON"
        };
    c = function(a, b, c) {
        a = a.filter(Boolean);
        var d = a.length;
        if (d === 0) return "";
        else if (d === 1) return a[0];
        var e = a[d - 1],
            f = a[0];
        for (var h = 1; h < d - 1; ++h) switch (c) {
            case k.SEMICOLON:
                f = g._("__JHASH__2xRftcH2vsr__JHASH__", [g._param("previous items", f), g._param("following items", a[h])]);
                break;
            case k.BULLET:
                f = g._("__JHASH__A8Te3iyJoQY__JHASH__", [g._param("previous items", f), g._param("following items", a[h])]);
                break;
            default:
                f = g._("__JHASH__ymp6OXT1HEX__JHASH__", [g._param("previous items", f), g._param("following items", a[h])])
        }
        return l(f, e, b || j.AND, c || k.COMMA)
    };

    function l(a, b, c, d) {
        switch (c) {
            case j.AND:
                return g._("__JHASH__qQ-J1F_2ppK__JHASH__", [g._param("list of items", a), g._param("last item", b)]);
            case j.OR:
                return g._("__JHASH__pqsshngVpqN__JHASH__", [g._param("list of items", a), g._param("last item", b)]);
            case j.NONE:
                switch (d) {
                    case k.SEMICOLON:
                        return g._("__JHASH__KtjanthXGG0__JHASH__", [g._param("previous items", a), g._param("last item", b)]);
                    case k.BULLET:
                        return g._("__JHASH__pWqMqQJ5cvg__JHASH__", [g._param("list of items", a), g._param("last item", b)]);
                    default:
                        return g._("__JHASH__QEekv2-b_Os__JHASH__", [g._param("list of items", a), g._param("last item", b)])
                }
            default:
                h(0, 568, c)
        }
    }
    c.DELIMITERS = k;
    c.CONJUNCTIONS = j;
    d = c;
    e.exports = d
}), 130); /*FB_PKG_DELIM*/
__d("MDSButtonGroup.react", ["Box.react", "CometFocusTableContext", "MDSButton.react", "MDSRow.react", "MDSRowItem.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            hiddenButton: {
                height: "xqtp20y",
                opacity: "xg01cxk",
                $$css: !0
            },
            resetFlexBasis: {
                flexBasis: "xdl72j9",
                $$css: !0
            }
        };

    function l(a) {
        var b = j(c("CometFocusTableContext"));
        b = b.FocusCell;
        a = a.children;
        return b != null ? i.jsx(b, {
            children: a
        }) : a
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.align,
            d = b === void 0 ? "justify" : b;
        b = a.direction;
        b = b === void 0 ? "forward" : b;
        var e = a.expanding;
        e = e === void 0 ? !1 : e;
        var f = a.paddingHorizontal,
            g = a.paddingTop,
            h = a.primary,
            j = a.secondary,
            m = a.secondaryIcon,
            n = a.size,
            o = a.testid;
        o = a.verticalAlign;
        a = a.wrap;
        a = a === void 0 ? "none" : a;
        var p = [],
            q = [],
            r = null;
        if (h != null) {
            var s = h.ref,
                t = h.testid;
            t = h.type;
            h = babelHelpers.objectWithoutPropertiesLoose(h, ["ref", "testid", "type"]);
            r = i.jsx(l, {
                children: i.jsx(c("MDSButton.react"), babelHelpers["extends"]({}, h, {
                    ref: s,
                    size: n,
                    testid: void 0,
                    type: t
                }))
            });
            p.push({
                hidden: i.jsx(c("MDSButton.react"), babelHelpers["extends"]({}, h, {
                    disabled: !0,
                    padding: "normal",
                    size: n,
                    type: t
                })),
                visible: r
            })
        }
        if (j != null) {
            s = j.ref;
            h = j.testid;
            t = babelHelpers.objectWithoutPropertiesLoose(j, ["ref", "testid"]);
            p.push({
                hidden: i.jsx(c("MDSButton.react"), babelHelpers["extends"]({}, t, {
                    disabled: !0,
                    padding: "normal",
                    size: n,
                    type: "secondary"
                })),
                visible: i.jsx(l, {
                    children: i.jsx(c("MDSButton.react"), babelHelpers["extends"]({}, t, {
                        ref: s,
                        size: n,
                        testid: void 0,
                        type: "secondary"
                    }))
                })
            })
        } else m != null && q.push(i.jsx(c("MDSRowItem.react"), {
            children: i.jsx(l, {
                children: i.jsx(c("MDSButton.react"), babelHelpers["extends"]({}, m, {
                    labelIsHidden: !0,
                    size: n,
                    type: "secondary"
                }))
            })
        }, "secondary-icon"));
        h = p.map(function(a, b) {
            return i.jsx(c("MDSRowItem.react"), {
                expanding: d === "justify",
                xstyle: k.resetFlexBasis,
                children: p.map(function(a, d) {
                    return i.jsx(i.Fragment, {
                        children: b !== d ? i.jsx(c("Box.react"), {
                            "aria-hidden": !0,
                            xstyle: k.hiddenButton,
                            children: a.hidden
                        }) : a.visible
                    }, d)
                })
            }, b)
        });
        j = r != null ? i.jsx(c("MDSRowItem.react"), {
            expanding: d === "justify",
            xstyle: k.resetFlexBasis,
            children: r
        }, "primary") : null;
        t = [j].concat(q);
        s = p.length === 2;
        return i.jsx(c("MDSRow.react"), {
            align: d,
            direction: b,
            expanding: e,
            paddingHorizontal: f,
            paddingTop: g,
            spacing: 8,
            testid: void 0,
            verticalAlign: o,
            wrap: a,
            children: s || r == null ? h : t
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometVPVDUserActivityMonitor", ["CometUserActivityMonitor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        isUserActive: function() {
            return d("CometUserActivityMonitor").getActivityState() === "ACTIVE"
        },
        subscribe: function(a) {
            var b = d("CometUserActivityMonitor").subscribe(function(b) {
                b = b === "ACTIVE";
                a && a(b)
            });
            return function() {
                b && b.remove()
            }
        }
    };
    g["default"] = a
}), 98);
__d("isIntersectionObserverEntryVPVDVisible", ["intersectionObserverEntryIsIntersecting"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 200,
        i = {
            height: 0
        };

    function a(a, b) {
        b === void 0 && (b = h);
        var d = c("intersectionObserverEntryIsIntersecting")(a);
        if (d === !1) return !1;
        d = a.boundingClientRect;
        var e = a.intersectionRect,
            f = a.rootBounds;
        d = d || i;
        e = e || i;
        f = f || i;
        return e.height >= b || e.height >= f.height / 2 || e.height === d.height || a.intersectionRatio > .95
    }
    g["default"] = a
}), 98);
__d("isIntersectionObserverEntryVPVDVisiblePct", ["intersectionObserverEntryIsIntersecting"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = .5,
        i = {
            height: 0
        };

    function a(a, b) {
        b === void 0 && (b = h);
        var d = c("intersectionObserverEntryIsIntersecting")(a);
        if (d === !1) return !1;
        d = a.intersectionRect;
        var e = a.rootBounds,
            f = a.boundingClientRect;
        if (f == null || f.height === 0) return !1;
        d = d || i;
        e = e || i;
        return d.height / f.height >= b || d.height >= e.height / 2 || a.intersectionRatio > .95
    }
    g["default"] = a
}), 98);
__d("useNoopDebuggingInfoComponent", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = function() {};

    function a() {
        return [null, g]
    }
    f["default"] = a
}), 66);
__d("vpvdConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 250;
    b = 200;
    f.DEFAULT_MIN_VISIBLE_TIME_MS = a;
    f.DEFAULT_MIN_VISIBLE_PX = b
}), 66);
__d("useVPVDImpression", ["CometVPVDUserActivityMonitor", "cr:921407", "isIntersectionObserverEntryVPVDVisible", "isIntersectionObserverEntryVPVDVisiblePct", "react", "useVisibilityObserver", "vpvdConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useCallback;

    function a(a) {
        var e = a.isLite,
            f = a.minVisiblePct,
            g = a.minVisiblePx;
        g = g === void 0 ? d("vpvdConstants").DEFAULT_MIN_VISIBLE_PX : g;
        var h = a.minVisibleTimeMs,
            j = h === void 0 ? d("vpvdConstants").DEFAULT_MIN_VISIBLE_TIME_MS : h,
            k = a.onVPVDEnd;
        h = a.onVPVDStart;
        a = b("cr:921407")();
        var l = a[0];
        a = a[1];
        var m = i(function(a) {
                if (a.visibleDuration < j) return;
                k(a)
            }, [j, k]),
            n = e === !0 ? 1 : g;
        g = i(function(a) {
            return f != null ? c("isIntersectionObserverEntryVPVDVisiblePct")(a, f) : c("isIntersectionObserverEntryVPVDVisible")(a, n)
        }, [n, f]);
        e = e === !0 ? null : {
            thresholdOverride: "EXPENSIVE"
        };
        g = babelHelpers["extends"]({
            activityMonitorOverride: c("CometVPVDUserActivityMonitor"),
            isEntryInViewport: g
        }, e);
        e = c("useVisibilityObserver")({
            onHidden: m,
            onVisibilityDurationUpdated: a,
            onVisible: h,
            options: g
        });
        return [e, l]
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LSSetMessageDisplayedContentTypes", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return b.sequence([function(d) {
                return b.db.table(16).fetch([
                    [
                        [a[0], a[1]]
                    ]
                ]).next().then(function(a, b) {
                    var d = a.done;
                    a = a.value;
                    return d ? (d = [void 0, void 0], c[0] = d[0], c[1] = d[1], d) : (b = a.item, d = [b.attachmentType, b.xmaLayoutType], c[0] = d[0], c[1] = d[1], d)
                })
            }, function(d) {
                return b.filter(b.db.table(12).fetch([
                    [
                        [a[0], a[2], a[1]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(c.timestampMs, a[2]) && c.messageId === a[1]
                }).next().then(function(a, d) {
                    var e = a.done;
                    a = a.value;
                    return e ? (e = [b.i64.cast([0, 0]), void 0, void 0], c[3] = e[0], c[4] = e[1], c[5] = e[2], e) : (d = a.item, e = [d.replySourceTypeV2, d.replySourceId, d.text], c[3] = e[0], c[4] = e[1], c[5] = e[2], e)
                })
            }, function(d) {
                return b.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var d = a.done;
                    a = a.value;
                    return d ? c[7] = void 0 : (b = a.item, c[7] = b.customEmoji)
                })
            }, function(d) {
                return b.i64.eq(c[0], b.i64.cast([0, 6])) ? c[9] = b.i64.cast([0, 64]) : (b.i64.eq(c[0], b.i64.cast([0, 5])) ? c[15] = b.i64.cast([0, 4]) : (b.i64.eq(c[0], b.i64.cast([0, 3])) ? c[16] = b.i64.cast([0, 16384]) : (b.i64.eq(c[0], b.i64.cast([0, 2])) ? c[17] = b.i64.cast([0, 2]) : (b.i64.eq(c[0], b.i64.cast([0, 4])) ? c[18] = b.i64.cast([0, 2]) : c[18] = a[5] ? b.i64.cast([0, 4096]) : b.i64.cast([0, 0]), c[17] = c[18]), c[16] = c[17]), c[15] = c[16]), c[9] = c[15]), c[10] = c[5] !== void 0 && c[5] !== "" && c[5] !== c[7] ? b.i64.or_(c[9], b.i64.cast([0, 1])) : c[9], c[11] = c[7] !== void 0 && c[7] === c[5] ? b.i64.or_(c[10], b.i64.cast([0, 128])) : c[10], c[12] = b.i64.eq(c[0], b.i64.cast([0, 7])) ? b.i64.or_(c[11], b.i64.cast([0, 8])) : c[11], c[13] = b.i64.eq(c[1], b.i64.cast([0, 0])) ? b.i64.or_(c[12], b.i64.cast([0, 1024])) : b.i64.eq(c[1], b.i64.cast([0, 1])) ? b.i64.or_(c[12], b.i64.cast([0, 2048])) : c[12], c[14] = b.i64.eq(c[3], b.i64.cast([0, 2])) && c[4] !== void 0 ? b.i64.or_(c[13], b.i64.cast([0, 512])) : c[13], b.forEach(b.filter(b.db.table(12).fetch([
                    [
                        [a[0], a[2], a[1]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(c.timestampMs, a[2]) && c.messageId === a[1]
                }), function(d) {
                    var e = d.update;
                    d.item;
                    return e({
                        displayedContentTypes: a[4] ? b.i64.cast([0, 32]) : b.i64.eq(c[3], b.i64.cast([0, 3])) ? b.i64.or_(c[14], b.i64.cast([0, 8192])) : c[14]
                    })
                })
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxSetMessageDisplayedContentTypesStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("OCCastingZenonUtils", ["UserAgent", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = function(a) {
        return a === "Connected" || a === "Connecting"
    };

    function a() {
        return c("gkx")("1930") || c("gkx")("25763") && (c("UserAgent").isBrowser("Chrome for iOS") || c("UserAgent").isBrowser("Mobile Safari"))
    }
    g.hasCallStarted = b;
    g.isBrowserSupportedForMobileWebCasting = a
}), 98);
__d("RTWebIncomingRingConfiguration", ["OCCastingZenonUtils", "UserAgent", "ZenonRTWebBrowserFeatureSupport", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("UserAgent").isBrowser("Chrome >= 77") || c("UserAgent").isBrowser("Edge (Chromium Based) >= 79") || c("UserAgent").isBrowser("Edge PWA (Chromium Based) >= 79") || c("UserAgent").isBrowser("Opera >= 67") || c("UserAgent").isBrowser("Firefox >= 70") || c("UserAgent").isBrowser("Safari >= 16") && c("gkx")("24226") || c("UserAgent").isBrowser("Safari >= 15.4") && c("gkx")("24227") || c("UserAgent").isBrowser("Oculus Browser >= 7") && c("gkx")("24228") || d("OCCastingZenonUtils").isBrowserSupportedForMobileWebCasting()
    }

    function b() {
        return c("gkx")("23430") && d("ZenonRTWebBrowserFeatureSupport").isInsertableStreamsSupported()
    }
    g.isSupportedClient = a;
    g.isE2EESupportedClient = b
}), 98);
__d("debounceCore", ["TimeSlice"], (function(a, b, c, d, e, f, g) {
    function a(a, b, d, e, f, g) {
        d === void 0 && (d = null);
        e === void 0 && (e = setTimeout);
        f === void 0 && (f = clearTimeout);
        g === void 0 && (g = !1);
        var h, i = !0;

        function j() {
            for (var k = arguments.length, l = new Array(k), m = 0; m < k; m++) l[m] = arguments[m];
            var n;
            if (g) {
                n = c("TimeSlice").guard(function() {
                    i = !0, h = null
                }, "debounceCore");
                if (!i) {
                    f(h);
                    h = e(n, b);
                    return
                }
                i = !1;
                a.apply(d, l)
            } else j.reset(), n = c("TimeSlice").guard(function() {
                h = null, a.apply(d, l)
            }, "debounceCore");
            n.__SMmeta = a.__SMmeta;
            h = e(n, b)
        }
        j.reset = function() {
            f(h), h = null, i = !0
        };
        j.isPending = function() {
            return h != null
        };
        return j
    }
    g["default"] = a
}), 98);
__d("debounce", ["clearTimeout", "debounceCore", "setTimeout"], (function(a, b, c, d, e, f, g) {
    function a(a, b, d, e, f) {
        b === void 0 && (b = 100);
        var g = function(a, b, d) {
            return c("setTimeout")(a, b, d, !e)
        };
        return c("debounceCore")(a, b, d, g, c("clearTimeout"), f)
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("XAdsCMAccountSettingsPageControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/ads/manager/account/settings/", Object.freeze({
        tab: "information",
        highlight_tax_id: !1
    }), new Set(["highlight_tax_id"]));
    b = a;
    g["default"] = b
}), 98);
__d("XAdsCMControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/ads/manager/{?page}/{?tab}/", Object.freeze({
        help_tray: !1,
        no_redirect: !1,
        pixel_conversion_dialog: !1,
        show_edit_modal: !1,
        is_split_test: !1,
        m2w: !1,
        ads_manager_read_regions: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("XAdsPEControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/adsmanager/", Object.freeze({
        _fb_noscript: !1,
        breakdown_regrouping: !1,
        is_reload_from_account_change: !1,
        is_split_test: !1,
        launch_quick_creation: !1,
        show_view_history: !1,
        show_inbox_re_tos: !1,
        from_ads_ai: !1,
        ads_manager_read_regions: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("AdsManagerConstURIUtils", ["AdsManagerReadRegions", "XAdsCMAccountSettingsPageControllerRouteBuilder", "XAdsCMControllerRouteBuilder", "XAdsPEControllerRouteBuilder", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        b = c("XAdsPEControllerRouteBuilder").buildUri(babelHelpers["extends"]({}, d, {
            nav_entry_point: (d = b) != null ? d : void 0,
            nav_source: a
        }));
        h(b.toString()) && b.addQueryParam("ads_manager_read_regions", "true");
        return b
    }

    function b(a, b, d) {
        b = c("XAdsCMControllerRouteBuilder").buildUri(babelHelpers["extends"]({}, d, {
            nav_entry_point: (d = b) != null ? d : void 0,
            nav_source: a
        }));
        h(b.toString()) && b.addQueryParam("ads_manager_read_regions", "true");
        return b
    }

    function d(a, b, d) {
        return c("XAdsCMAccountSettingsPageControllerRouteBuilder").buildUri(babelHelpers["extends"]({}, d, {
            nav_entry_point: (d = b) != null ? d : void 0,
            nav_source: a
        }))
    }

    function h(a) {
        return a.includes("adsmanager") && !c("AdsManagerReadRegions").excluded_endpoints.some(function(b) {
            return a.includes(b)
        }) && c("gkx")("1221") ? !0 : !1
    }
    g.getAdsManagerURI = a;
    g.getXAdsCMControllerURI = b;
    g.getXAdsCMAccountSettingsPageURI = d;
    g.shouldRedirectToAMReadRegions = h
}), 98); /*FB_PKG_DELIM*/
__d("MWSupportTranslationsContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    c = h;
    var j = c.useContext,
        k = c.useMemo,
        l = c.useState,
        m = {
            setShowToggleMustache: function() {},
            setShowUntranslatedText: function() {},
            showToggleMustache: !1,
            showUntranslatedText: !1
        },
        n = i.createContext(m);

    function a(a) {
        var b, c = a.children;
        a = a.value;
        a = a === void 0 ? m : a;
        b = l((b = a == null ? void 0 : a.showUntranslatedText) != null ? b : !1);
        var d = b[0],
            e = b[1];
        a = l((b = a == null ? void 0 : a.showToggleMustache) != null ? b : !1);
        var f = a[0],
            g = a[1];
        b = k(function() {
            return {
                setShowToggleMustache: g,
                setShowUntranslatedText: e,
                showToggleMustache: f,
                showUntranslatedText: d
            }
        }, [d, f]);
        return i.jsx(n.Provider, {
            value: b,
            children: c
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return j(n)
    }
    g.MWSupportTranslationsContextProvider = a;
    g.useMWSupportTranslationsContext = b
}), 98);
__d("MWXEntryPointPopoverTrigger.react", ["cr:1000", "cr:930", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        if (b("cr:930") != null) return i.jsx(b("cr:930"), babelHelpers["extends"]({}, a));
        return b("cr:1000") != null ? i.jsx(b("cr:1000"), babelHelpers["extends"]({}, a)) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXIconDots3Horizontal", ["MWXSvgIcon", "SVGIcon", "cr:12398", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12398")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MessageRequestsBulkActionsContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("react")).createContext;
    b = a({
        bulkActionsSelectedThreads: new Set(),
        bulkActionsUnreadSelectedThreads: new Set(),
        isBulkActionsEditMode: !1,
        setBulkActionsSelectedThreads: function() {},
        setBulkActionsUnreadSelectedThreads: function() {},
        setIsBulkActionsEditMode: function() {}
    });
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("UFI2UserActivityIdleTimeout", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 3e4;
    f["default"] = a
}), 66);
__d("CometUserActivityMonitor", ["ErrorGuard", "ExecutionEnvironment", "SubscriptionsHandler", "UFI2UserActivityIdleTimeout", "UserActivity", "Visibility"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = [],
        k = !1,
        l = (h || (h = c("ExecutionEnvironment"))).canUseDOM && c("UserActivity").isOnTab() && c("UserActivity").isActive(c("UFI2UserActivityIdleTimeout")) ? "ACTIVE" : "INACTIVE",
        m = [],
        n;

    function o(a) {
        k = !0;
        m.push.apply(m, j);
        var b = function() {
            var b = m.shift();
            (i || (i = c("ErrorGuard"))).applyWithGuard(function() {
                return b(a)
            }, null, [], {
                name: "CometUserActivityMonitor"
            })
        };
        while (m.length) b();
        k = !1
    }

    function p(a) {
        var b = l;
        l = a;
        b !== a && o(a)
    }

    function a() {
        return l
    }
    d = function() {
        n == null && (n = new(c("SubscriptionsHandler"))(), n.addSubscriptions(c("UserActivity").subscribe(function(a, b) {
            a = b.event;
            if (/^mouse(enter|leave|move|over|out)$/.test(a.type) && c("UserActivity").isOnTab() === !1) return;
            p("ACTIVE")
        }), function() {
            var a = function() {
                p("INACTIVE")
            };
            window.addEventListener("blur", a, {
                passive: !0
            });
            return {
                remove: function() {
                    return window.removeEventListener(a, {
                        passive: !0
                    })
                }
            }
        }(), c("Visibility").addListener(c("Visibility").HIDDEN, function() {
            p("INACTIVE")
        })))
    };

    function b(a) {
        j.push(a);
        k && m.push(a);
        var b = !1;
        return {
            remove: function() {
                if (b) return;
                var c = j.indexOf(a);
                c !== -1 && j.splice(c, 1);
                if (k) {
                    c = m.indexOf(a);
                    c !== -1 && m.splice(c, 1)
                }
                b = !0
            }
        }
    }(h || (h = c("ExecutionEnvironment"))).canUseDOM && d();
    g.getActivityState = a;
    g.init = d;
    g.subscribe = b
}), 98); /*FB_PKG_DELIM*/
__d("MWXButtonGroup.react", ["cr:227", "cr:5023", "cr:5028", "cr:6106", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var c = a.align,
            d = a.direction;
        d = d === void 0 ? "backward" : d;
        var e = a.expanding;
        e = e === void 0 ? !1 : e;
        var f = a.paddingHorizontal;
        f = f === void 0 ? 0 : f;
        var g = a.primary;
        a = a.secondary;
        if (b("cr:6106") != null) {
            var h, j = g.icon,
                k = g.loading,
                l = g.type,
                m = babelHelpers.objectWithoutPropertiesLoose(g, ["icon", "loading", "type"]);
            l = l === "destructive" ? "fdsOverride_negative" : l;
            var n = f === 10 ? 8 : f;
            return i.jsx(b("cr:6106"), {
                align: (h = c) != null ? h : "end",
                direction: d,
                expanding: e,
                paddingHorizontal: n,
                primary: babelHelpers["extends"]({}, m, {
                    addOnPrimary: k === !0 && b("cr:5023") ? i.jsx(b("cr:5023"), {
                        color: "disabled_DEPRECATED",
                        size: 16
                    }) : void 0,
                    icon: j == null ? void 0 : j.component,
                    type: l
                }),
                secondary: a != null ? babelHelpers["extends"]({}, a, {
                    icon: (h = a.icon) == null ? void 0 : h.component,
                    reduceEmphasis: !0,
                    type: "secondary"
                }) : null
            })
        }
        if (b("cr:227") != null) {
            e = g.icon;
            n = g.loading;
            m = babelHelpers.objectWithoutPropertiesLoose(g, ["icon", "loading"]);
            return i.jsx(b("cr:227"), {
                align: c,
                direction: d,
                paddingHorizontal: f,
                primary: babelHelpers["extends"]({}, m, {
                    addOnStart: n === !0 && b("cr:5028") ? i.jsx(b("cr:5028"), {
                        color: "grey",
                        size: 24
                    }) : void 0,
                    icon: e == null ? void 0 : e.originalComponent
                }),
                secondary: a != null ? babelHelpers["extends"]({}, a, {
                    icon: (k = a.icon) == null ? void 0 : k.originalComponent
                }) : null
            })
        }
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("MAWMessageIntegrityLoggingSampleRate", ["QuickPerformanceLogger", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new Set([c("qpl")._(25303796, "1974")]);

    function a() {
        for (var a = i, b = Array.isArray(a), d = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var e;
            if (b) {
                if (d >= a.length) break;
                e = a[d++]
            } else {
                d = a.next();
                if (d.done) break;
                e = d.value
            }
            e = e;
            (h || (h = c("QuickPerformanceLogger"))).setAlwaysOnSampleRate(e, 1)
        }
    }

    function b() {
        return 1
    }
    g.overwriteSamplingRate = a;
    g.getIntegrityCheckSampleRate = b
}), 98);
__d("MWInboxInfoDetailsSectionUnifiedPresenceStatusText.react", ["MWXColumnItem.react", "MWXText.react", "react", "usePresenceUnifiedStatusText"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || c("react");

    function a(a) {
        var b = a.threadKey;
        a = a.threadType;
        b = c("usePresenceUnifiedStatusText")(b, a);
        return i.jsx(c("MWXColumnItem.react"), {
            paddingTop: 8,
            children: i.jsx(c("MWXText.react"), {
                align: "center",
                color: "secondary",
                type: "body4",
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("IntlCLDRNumberType10", ["IntlVariations"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getVariation: function(a) {
            if (a === 1) return c("IntlVariations").NUMBER_ONE;
            else return c("IntlVariations").NUMBER_OTHER
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("MWMessengerDesktopFeedbackSurvey.react", ["react", "useRainbowNativeSurveyDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useRef,
        k = "803596357188560";

    function a() {
        var a = c("useRainbowNativeSurveyDialog")(k),
            b = j(!1);
        i(function() {
            b.current || (a(), b.current = !0)
        }, []);
        return null
    }
    g["default"] = a
}), 98);
__d("MessengerThreadlistFooterDesktopAppLinkV2Deferred.react", ["CometPlaceholder.react", "deferredLoadComponent", "react", "requireDeferredForDisplay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || c("react"),
        j = c("deferredLoadComponent")(c("requireDeferredForDisplay")("MessengerThreadlistFooterDesktopAppLinkV2.react").__setRef("MessengerThreadlistFooterDesktopAppLinkV2Deferred.react"));

    function a() {
        return i.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            name: "MessengerThreadlistFooterDesktopAppLinkV2Deferred",
            children: i.jsx(j, {})
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("useCometLogout", ["CometPlaceholder.react", "deferredLoadComponent", "react", "recoverableViolation", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    e = h;
    var j = e.useCallback,
        k = e.useContext,
        l = e.useRef,
        m = e.useState,
        n = c("deferredLoadComponent")(c("requireDeferred")("LogoutHandler.react").__setRef("useCometLogout")),
        o = i.createContext(function() {
            c("recoverableViolation")("No provider of CometLogoutContext exists", "comet_infra")
        });

    function a(a) {
        a = a.children;
        var b = m(!1),
            d = b[0],
            e = b[1],
            f = l();
        b = j(function() {
            f.current != null ? f.current.logout() : e(!0)
        }, []);
        return i.jsxs(o.Provider, {
            value: b,
            children: [i.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                name: "CometLogoutProvider",
                children: i.jsx(n, {
                    ref: f,
                    shouldInitiateLogout: d
                })
            }), a]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return k(o)
    }
    g.CometLogoutProvider = a;
    g.useCometLogout = b
}), 98); /*FB_PKG_DELIM*/
__d("TetraIcon.react", ["FDSIcon.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        return i.jsx(c("FDSIcon.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("useBaseLazyDialog", ["CometDialogContext", "CometSuspendedDialogImpl.react", "lazyLoadComponent", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useContext;

    function a(a, b, d, e) {
        var f = j(c("CometDialogContext")),
            g = e == null ? void 0 : e.baseModalProps;
        e = i(function(e, h, i) {
            var j = c("lazyLoadComponent")(a);
            f(c("CometSuspendedDialogImpl.react"), {
                dialog: j,
                dialogProps: e,
                fallback: b
            }, {
                loadType: "lazy",
                tracePolicy: d
            }, h, {
                baseModalProps: g,
                replaceCurrentDialog: i
            })
        }, [f, g, a, b, d]);
        var h = i(function() {
            a.preload()
        }, [a]);
        return [e, h]
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("smoothScrollTo", ["ExecutionEnvironment", "UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = c("UserAgent").isBrowser("Firefox");
    b = (h || (h = c("ExecutionEnvironment"))).canUseDOM && window.matchMedia("(prefers-reduced-motion: reduce)");
    var j = b && b.matches,
        k = (h || (h = c("ExecutionEnvironment"))).canUseDOM && document.documentElement != null && "scrollBehavior" in document.documentElement.style,
        l = new WeakMap();

    function a(a, b, c) {
        var d = b.left;
        d = d === void 0 ? 0 : d;
        b = b.top;
        b = b === void 0 ? 0 : b;
        i && (!l.get(a) && d !== 0 && (a.scrollLeft += d / Math.abs(d), l.set(a, !0)));
        k ? (a.scrollTo({
            behavior: j ? "auto" : "smooth",
            left: d,
            top: b
        }), c != null && "onscrollend" in window && a.addEventListener("scrollend", c, {
            once: !0
        })) : (a.scrollTo(d, b), c == null ? void 0 : c())
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("BaseLazyPopoverTrigger.react", ["BasePopoverTrigger.react", "lazyLoadComponent", "react", "tracePolicyFromResource", "useCometPopoverInteractionTracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo;

    function a(a) {
        var b = a.fallback,
            d = a.popoverResource,
            e = a.preloadTrigger,
            f = a.tracePolicy;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback", "popoverResource", "preloadTrigger", "tracePolicy"]);
        var g = j(function() {
            return c("lazyLoadComponent")(d)
        }, [d]);
        f = c("useCometPopoverInteractionTracing")((f = f) != null ? f : c("tracePolicyFromResource")("comet.popover", d), "lazy", e);
        return i.jsx(c("BasePopoverTrigger.react"), babelHelpers["extends"]({
            fallback: b,
            interactionTracker: f,
            popover: g,
            popoverPreloadResource: d,
            preloadTrigger: e
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometPassiveGetRouterStateContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouterRouteTopNavTypeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext("default");
    g["default"] = b
}), 98);
__d("getCometEntityKey", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.entityKeyConfig;
        return b == null ? null : g(b, a)
    }

    function g(a, b) {
        var c = {};
        for (var d in a) c[d] = i(a[d], b);
        return c
    }

    function h(a, b) {
        return a == null || a[b] == null ? null : String(a[b])
    }

    function i(a, b) {
        switch (a.source) {
            case "prop":
                return h(b.rootView.props, a.value);
            case "param":
                return h(b.params, a.value);
            case "constant":
                return a.value
        }
        return null
    }
    f["default"] = a
}), 66); /*FB_PKG_DELIM*/
__d("useSimpleImpression", ["HiddenSubtreePassiveContext", "react", "useAfterPaint", "useDynamicCallbackDANGEROUS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useRef;

    function a(a) {
        var b = j(c("HiddenSubtreePassiveContext")),
            d = k(!0),
            e = c("useDynamicCallbackDANGEROUS")(a);
        a = i(function() {
            var a = function(a) {
                a = a.hiddenOrBackgrounded_FIXME;
                a === !1 && d.current === !0 && e();
                a = b.getCurrentState();
                d.current = a.hiddenOrBackgrounded_FIXME
            };
            a(b.getCurrentState());
            var c = b.subscribeToChanges(a);
            return function() {
                return c.remove()
            }
        }, [b, e]);
        c("useAfterPaint")(a)
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("AdsDataAtomDebugger", ["URI"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = {
        shouldLog: !!new(g || b("URI"))(window.location.href).getQueryData().dispatcherevents,
        toggleLogging: function() {
            h.shouldLog = !h.shouldLog
        },
        isLogging: function() {
            return h.shouldLog
        },
        attach: function(a) {
            a.register(function(a) {
                a = a.action;
                if (a) {
                    console.timeStamp && console.timeStamp(a.type);
                    if (h.shouldLog) {
                        var b = a.type,
                            c = a.actionType;
                        a = babelHelpers.objectWithoutPropertiesLoose(a, ["type", "actionType"]);
                        console.groupCollapsed(b || c, a);
                        console.trace();
                        console.groupEnd()
                    }
                }
            })
        }
    };
    e.exports = h
}), null); /*FB_PKG_DELIM*/
__d("XCometProfileControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/profile.php", Object.freeze({
        show_switched_toast: !1,
        show_switched_tooltip: !1,
        is_tour_dismissed: !1,
        is_tour_completed: !1,
        show_podcast_settings: !1,
        show_community_review_changes: !1,
        should_open_composer: !1,
        badge_type: "NEW_MEMBER",
        show_community_rollback_toast: !1,
        show_community_rollback: !1,
        show_follower_visibility_disclosure: !1
    }), new Set(["show_switched_toast", "show_switched_tooltip", "is_tour_dismissed", "is_tour_completed", "show_podcast_settings", "show_community_review_changes", "should_open_composer", "show_community_rollback_toast", "show_community_rollback", "show_follower_visibility_disclosure"]));
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("LSThreadAttributionStore", ["I64"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new Map();

    function a(a, b) {
        var c;
        a = (c = (c = i.get(b)) != null ? c : a) != null ? c : {
            type: "MWLSEntrypoint",
            value: "unknown"
        };
        i["delete"](b);
        return a
    }

    function b(a, b) {
        i.set(a, {
            type: "MWLSEntrypoint",
            value: b
        })
    }

    function c(a, b) {
        b = (h || (h = d("I64"))).of_string(b);
        i.set(a, {
            type: "LSThreadAttribution",
            value: b
        })
    }

    function e(a) {
        i.set("", {
            type: "MWLSEntrypoint",
            value: a
        })
    }

    function f() {
        var a = i.get("");
        if (a == null || a.type === "LSThreadAttribution") return "unknown";
        else return a.value
    }
    g.getSource = a;
    g.setSource = b;
    g.setLSMessagingThreadAttribution = c;
    g.setSourceForNewThread = e;
    g.getSourceForNewThread = f
}), 98); /*FB_PKG_DELIM*/
__d("LSGetCursor", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(e) {
            return b.sequence([function(d) {
                return b.db.table(1).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var d = a.done;
                    a = a.value;
                    return d ? c[0] = void 0 : (b = a.item, c[0] = b.currentCursor)
                })
            }, function(a) {
                return d[0] = c[0]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSCoreGetCursorStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("Deferred", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;
    (g || (g = b("Promise"))).resolve();
    a = function() {
        function a(a) {
            var c = this;
            a = a || g || (g = b("Promise"));
            this.$1 = !1;
            this.$2 = new a(function(a, b) {
                c.$3 = a, c.$4 = b
            })
        }
        var c = a.prototype;
        c.getPromise = function() {
            return this.$2
        };
        c.resolve = function(a) {
            this.$1 = !0, this.$3(a)
        };
        c.reject = function(a) {
            this.$1 = !0, this.$4(a)
        };
        c.isSettled = function() {
            return this.$1
        };
        return a
    }();
    f["default"] = a
}), 66); /*FB_PKG_DELIM*/
__d("WAHashStringToNumber", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = 0;
        for (var c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            b = (b << 5) - b + d;
            b |= 0
        }
        return Math.abs(b)
    }
    f.hashStringToNumber = a
}), 66); /*FB_PKG_DELIM*/
__d("MWXIconDownload", ["MWXSvgIcon", "SVGIcon", "cr:12400", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12400")), c("gkx")("23219"));
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometFocusTableContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        FocusCell: null,
        FocusRow: null,
        FocusTable: null
    });
    g["default"] = b
}), 98);