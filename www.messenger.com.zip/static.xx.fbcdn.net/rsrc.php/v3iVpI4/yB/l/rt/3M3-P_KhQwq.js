; /*FB_PKG_DELIM*/

__d("LSFetchOTCEligibleEBDevicesV2", ["LSIssueNewEbTaskAndGetTaskIDV2"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(a) {
            return c.sequence([function(a) {
                return c.forEach(c.db.table(261).fetch(), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return d[0] = "", c.forEach(c.filter(c.db.table(261).fetch([
                    [
                        [d[0]]
                    ]
                ]), function(a) {
                    return a.deviceId === d[0] && c.i64.lt(a.authorityLevel, c.i64.cast([0, 20]))
                }), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return c.db.table(261).add({
                    deviceId: d[0],
                    authorityLevel: c.i64.cast([0, 20])
                })
            }, function(a) {
                return d[1] = new c.Map(), d[2] = c.toJSON(d[1]), c.storedProcedure(b("LSIssueNewEbTaskAndGetTaskIDV2"), "meb_fetch_otc_eligible_devices", c.i64.cast([0, 50028]), d[2], c.i64.cast([0, 0]), c.i64.cast([0, 93]), c.i64.cast([0, 0]), void 0, c.i64.cast([0, 0])).then(function(a) {
                    return a = a, d[3] = a[0], a
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSEncryptedBackupsFetchOTCEligibleEBDevicesV2StoredProcedure";
    e.exports = a
}), null);
__d("LSFetchOTCEligibleEBDevicesV2StoredProcedure", ["LSFetchOTCEligibleEBDevicesV2", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return c("LSFetchOTCEligibleEBDevicesV2")(a)
    }
    g["default"] = a
}), 98);
__d("LSSendOTCNotifications", ["LSIssueNewEbTaskAndGetTaskIDV2"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(a) {
                return c.forEach(c.db.table(285).fetch(), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return c.forEach(c.filter(c.db.table(285).fetch([
                    [
                        [c.i64.cast([0, 1])]
                    ]
                ]), function(a) {
                    return c.i64.eq(a.pk, c.i64.cast([0, 1])) && c.i64.lt(a.authorityLevel, c.i64.cast([0, 20]))
                }), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return c.db.table(285).add({
                    pk: c.i64.cast([0, 1]),
                    notificationSendingStatus: c.i64.cast([0, 2]),
                    authorityLevel: c.i64.cast([0, 20])
                })
            }, function(e) {
                return d[0] = new c.Map(), d[0].set("device_ids", a[0]), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewEbTaskAndGetTaskIDV2"), "meb_send_otc_notifications", c.i64.cast([0, 50032]), d[1], c.i64.cast([0, 0]), c.i64.cast([0, 93]), c.i64.cast([0, 0]), void 0, c.i64.cast([0, 0])).then(function(a) {
                    return a = a, d[2] = a[0], a
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSEncryptedBackupsSendOTCNotificationsStoredProcedure";
    e.exports = a
}), null);
__d("LSSendOTCNotificationsStoredProcedure", ["LSSendOTCNotifications", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSSendOTCNotifications")(b.deviceIds, a)
    }
    g["default"] = a
}), 98);
__d("MWEBOTCDialogStep.react", ["deferredLoadComponent", "qex", "react", "requireDeferredForDisplay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("qex")._("2055") ? c("deferredLoadComponent")(c("requireDeferredForDisplay")("MWEBOTCCheckFirstStep.react").__setRef("MWEBOTCDialogStep.react")) : c("deferredLoadComponent")(c("requireDeferredForDisplay")("MWEncryptedBackupsInsertOTCStep.react").__setRef("MWEBOTCDialogStep.react"));

    function a(a) {
        return i.jsx(j, babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEBRestoreOTCFirstDialogStepDeferred.react", ["deferredLoadComponent", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferred")("MWEBRestoreOTCFirstStep.react").__setRef("MWEBRestoreOTCFirstDialogStepDeferred.react"));

    function a(a) {
        return i.jsx(j, babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsViewAllOtcEligibleDialogStepDeferred.react", ["deferredLoadComponent", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferred")("MWEncryptedBackupsViewAllOtcEligibleDialogStep.react").__setRef("MWEncryptedBackupsViewAllOtcEligibleDialogStepDeferred.react"));

    function a(a) {
        return i.jsx(j, babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsOtcRestoreSteps", ["MWEBOTCDialogStep.react", "MWEncryptedBackupsViewAllOtcEligibleDialogStepDeferred.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function j(a) {
        var b = a.onResendCodeFailure;
        a = a.pushPage;
        a(function(a) {
            a = a.onReturn;
            return i.jsx(c("MWEncryptedBackupsViewAllOtcEligibleDialogStepDeferred.react"), {
                onResendCodeFailure: b,
                onReturn: a
            })
        })
    }

    function a(a) {
        var b = a.onClose,
            d = a.onOtcComplete,
            e = a.onSkip,
            f = a.pushPage;
        f(function() {
            return i.jsx(c("MWEBOTCDialogStep.react"), {
                onClose: b,
                onComplete: d,
                onSkip: e,
                onViewAllDevices: function(a) {
                    a = a.onResendCodeFailure;
                    return j({
                        onResendCodeFailure: a,
                        pushPage: f
                    })
                }
            })
        })
    }
    g.pushViewOtcEligibleDevicesPage = j;
    g.pushByOneTimeCodePage = a
}), 98);
__d("MAWEncryptedBackupsRestoreStep.react", ["MWChatEncryptedBackupsQPLSource.enum", "MWEBOTCDialogStep.react", "MWEBRestoreOTCFirstDialogStepDeferred.react", "MWEncryptedBackupsOtcRestoreSteps", "deferredLoadComponent", "react", "requireDeferred", "requireDeferredForDisplay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferred")("MWChatEncryptedBackupsAccessCodeInputStep.react").__setRef("MAWEncryptedBackupsRestoreStep.react")),
        k = c("deferredLoadComponent")(c("requireDeferredForDisplay")("MWChatEncryptedBackupsPinCodeRestoreStep.react").__setRef("MAWEncryptedBackupsRestoreStep.react")),
        l = c("deferredLoadComponent")(c("requireDeferred")("MWChatEncryptedBackupsKVSOnlyRestoreStep.react").__setRef("MAWEncryptedBackupsRestoreStep.react"));

    function m(a) {
        var b = a.offlineDevicesCount,
            e = a.onChooseOtc,
            f = a.onClose,
            g = a.onComplete,
            h = a.onForgotRC,
            k = a.onSkip,
            m = a.pushPage,
            n = a.shouldShowForgotButton;
        a = a.source;
        if (e != null) {
            a = a === c("MWChatEncryptedBackupsQPLSource.enum").INBOX_INTERSTITIAL_SOFTBLOCK;
            return a ? i.jsx(c("MWEBRestoreOTCFirstDialogStepDeferred.react"), {
                onCloseDialog: f,
                onComplete: g,
                onSkip: k,
                pushPage: m
            }) : i.jsx(c("MWEBOTCDialogStep.react"), {
                onClose: f,
                onComplete: g,
                onSkip: k,
                onViewAllDevices: function(a) {
                    a = a.onResendCodeFailure;
                    return d("MWEncryptedBackupsOtcRestoreSteps").pushViewOtcEligibleDevicesPage({
                        onResendCodeFailure: a,
                        pushPage: m
                    })
                }
            })
        }
        return b !== null && b >= 1 ? i.jsx(j, {
            onChooseOtc: e,
            onComplete: g,
            onForgotRC: h,
            shouldShowForgotButton: n
        }) : i.jsx(l, {
            onClose: f,
            onComplete: g,
            pushPage: m
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.clientID,
            c = a.offlineDevicesCount,
            d = a.onChooseOtc,
            e = a.onClose,
            f = a.onComplete,
            g = a.onForgotPin,
            h = a.onForgotRC,
            j = a.onSkip,
            l = a.pushPage,
            n = a.shouldShowForgotButton;
        a = a.source;
        return b != null ? i.jsx(k, {
            clientID: b,
            onChooseOtc: d,
            onClose: e,
            onComplete: f,
            onForgotPin: g,
            shouldShowForgotButton: n
        }) : i.jsx(m, {
            offlineDevicesCount: c,
            onChooseOtc: d,
            onClose: e,
            onComplete: f,
            onForgotRC: h,
            onSkip: j,
            pushPage: l,
            shouldShowForgotButton: n,
            source: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWPinCodeGating", ["gkx", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("gkx")("3955") && c("justknobx")._("1015")
    }
    g.isPinCodeEnabled = a
}), 98);
__d("MWChatEBPinCodeVerifyIndicator.react", ["fbt", "MWXRow.react", "MWXRowItem.react", "MWXSpinner.react", "MWXText.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        a = a.isMessenger;
        return j.jsxs(c("MWXRow.react"), {
            align: "center",
            paddingTop: 8,
            spacing: 8,
            children: [j.jsx(c("MWXRowItem.react"), {
                verticalAlign: "center",
                children: j.jsx(c("MWXSpinner.react"), {
                    color: a ? "disabled" : "blue",
                    size: 12
                })
            }), j.jsx(c("MWXRowItem.react"), {
                verticalAlign: "center",
                children: j.jsx(c("MWXText.react"), {
                    color: "secondary",
                    testid: void 0,
                    type: "meta3",
                    children: h._("__JHASH__sqvt0agiqDI__JHASH__")
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWChatEncrypedBackupsNumericCodeValidation", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = function(a) {
        var b = /^[0-9]*$/;
        return b.test(a)
    };
    a = function(a, b) {
        return a.length > b ? !1 : g(a)
    };
    b = function(a, b) {
        return a.length !== b ? !1 : g(a)
    };
    f.numericCodeIsValid = a;
    f.numericCodeIsCompleted = b
}), 66);
__d("MWChatEncryptedBackupsDismissalDialogContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        isDismissedDisabled: !1,
        setIsDismissedDisabled: function() {}
    });
    g["default"] = b
}), 98);
__d("MWChatEncryptedBackupsNumericCodeErrorWrapper.react", ["MWXColumn.react", "MWXColumnItem.react", "MWXText.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            inputWrapperErrorOnly: {
                paddingBottom: "x18d9i69",
                $$css: !0
            },
            outterWrapper: {
                minHeight: "x10sr9ya",
                $$css: !0
            },
            outterWrapperSmall: {
                minHeight: "x1h7t28c",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.children,
            d = a.error;
        a = a.inputSize;
        a = a === void 0 ? "large" : a;
        var e = a === "large" ? k.outterWrapper : k.outterWrapperSmall;
        return j.jsx(c("MWXColumn.react"), {
            xstyle: e,
            children: j.jsxs(c("MWXColumnItem.react"), {
                align: "center",
                paddingHorizontal: a === "large" ? 20 : 0,
                paddingTop: 0,
                children: [j.jsx("div", {
                    className: (h || (h = c("stylex")))(d != null && [k.inputWrapperErrorOnly]),
                    children: b
                }), d != null ? j.jsx("div", {
                    className: "x1o1nzlu x1y1aw1k x2b8uid",
                    children: j.jsx(c("MWXText.react"), {
                        color: "negative",
                        testid: void 0,
                        type: "body4",
                        children: d
                    })
                }) : null]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWChatEncryptedBackupsNumericCodeInputInner.react", ["BaseTextInput.react", "FocusRegion.react", "MWChatEncrypedBackupsNumericCodeValidation", "focusScopeQueries", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useEffect,
        l = b.useRef,
        m = b.useState,
        n = c("gkx")("24058"),
        o = {
            input: {
                height: "x5yr21d",
                start: "x17qophe",
                left: null,
                right: null,
                opacity: "xg01cxk",
                position: "x10l6tqk",
                top: "x13vifvy",
                width: "xh8yej3",
                $$css: !0
            },
            testOpacity: {
                opacity: "x1ptxcow",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.extraProps.setFocus;
        a = a.props;
        var e = a["aria-label"],
            f = a.disabled,
            g = f === void 0 ? !1 : f;
        a.enableMasking;
        var h = a.focusRegionId;
        f = a.inputMode;
        var p = a.onChange,
            q = a.onCompletionChange,
            r = a.size,
            s = a.testid;
        a = a.value;
        var t = m(a.length === r),
            u = t[0],
            v = t[1],
            w = l(null),
            x = l(g);
        t = "mw-numeric-code-input-prevent-composer-focus-steal";
        var y = j(function(a) {
            var b = d("MWChatEncrypedBackupsNumericCodeValidation").numericCodeIsCompleted(a, r);
            p(a);
            q != null && b !== u && (v(b), q(b))
        }, [u, p, q, r]);
        k(function() {
            var a = function(a) {
                    a.preventDefault()
                },
                b = w.current;
            b == null ? void 0 : b.addEventListener("selectstart", a);
            return function() {
                b == null ? void 0 : b.removeEventListener("selectstart", a)
            }
        }, []);
        k(function() {
            g && b(!1)
        }, [g, b]);
        k(function() {
            x.current !== g && (x.current = g, g || d("FocusRegion.react").focusRegionById(h, d("focusScopeQueries").tabbableScopeQuery))
        }, [g, h]);
        return i.jsx(c("BaseTextInput.react"), {
            "aria-label": e,
            autoComplete: "one-time-code",
            disabled: g,
            id: s != null ? s + "-" + t : t,
            inputMode: f,
            maxLength: r,
            onBlur: function() {
                b(!1)
            },
            onFocus: function() {
                b(!0)
            },
            onKeyDown: function(a) {
                var b = a.keyCode;
                (b === 37 || b === 38 || b === 39 || b === 40) && (a.preventDefault(), a.stopPropagation())
            },
            onValueChange: function(a) {
                a = a.toString();
                d("MWChatEncrypedBackupsNumericCodeValidation").numericCodeIsValid(a, r) && y(a)
            },
            ref: w,
            testid: void 0,
            value: a,
            xstyle: [o.input, n && o.testOpacity]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWChatEncryptedBackupsNumericCodeInputRenderer.react", ["CometRow.react", "CometRowItem.react", "MWXText.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useEffect,
        l = b.useState,
        m = {
            focusRing: {
                boxShadow: "x18bame2",
                outline: "xvetz19 x1a2a7pz",
                $$css: !0
            },
            input: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "xhk9q7s",
                borderTopEndRadius: "x1otrzb0",
                borderBottomEndRadius: "x1i1ezom",
                borderBottomStartRadius: "x1o6z2jb",
                borderTopStyle: "x1ejq31n",
                borderEndStyle: "xd10rxx",
                borderBottomStyle: "x1sy0etr",
                borderStartStyle: "x17r0tee",
                boxSizing: "x9f619",
                display: "x78zum5",
                height: "xng8ra",
                justifyContent: "xl56j7k",
                position: "x1n2onr6",
                width: "x1o817pb",
                $$css: !0
            },
            inputBox: {
                marginTop: "x1k70j0n",
                marginEnd: "x1w0mnb",
                marginBottom: "xzueoph",
                marginStart: "x1mnrxsn",
                $$css: !0
            },
            inputColorPrimary: {
                backgroundColor: "xljulmy",
                $$css: !0
            },
            inputColorSecondary: {
                backgroundColor: "xwcfey6",
                $$css: !0
            },
            inputSmall: {
                height: "xaymia4",
                width: "x1bgwkul",
                $$css: !0
            },
            inputTiny: {
                height: "x1vqgdyp",
                width: "x10faclu",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.color,
            d = b === void 0 ? "primary" : b;
        b = a.disabled;
        var e = b === void 0 ? !1 : b;
        b = a.enableMasking;
        var f = b === void 0 ? !1 : b,
            g = a.hasFocus;
        b = a.inputSize;
        var i = b === void 0 ? "large" : b,
            n = a.size;
        b = a.testid;
        b = b === void 0 ? "numeric-renderer" : b;
        var o = a.value,
            p = function(a) {
                return (o.length === a || o.length > a && a === n - 1) && g
            };
        b = l(Array(n).fill(""));
        a = b[0];
        var q = b[1];
        k(function() {
            q(Array(n).fill().map(function(a, b) {
                return o[b] != null ? f ? "\u25cf" : o[b] : ""
            }))
        }, [f, n, o]);
        return j.jsx(c("CometRow.react"), {
            align: "center",
            paddingHorizontal: 0,
            paddingVertical: 0,
            role: "group",
            spacing: 0,
            children: a.map(function(a, b) {
                return j.jsx(c("CometRowItem.react"), {
                    xstyle: m.inputBox,
                    children: j.jsx("div", {
                        className: (h || (h = c("stylex")))(m.input, i === "small" && m.inputSmall, i === "tiny" && m.inputTiny, d === "primary" && m.inputColorPrimary, d === "secondary" && m.inputColorSecondary, p(b) && m.focusRing),
                        "data-testid": void 0,
                        children: f ? j.jsx(c("MWXText.react"), {
                            color: e ? "disabled" : "primary",
                            type: "headlineEmphasized4",
                            children: e ? "\u25cf" : a
                        }) : j.jsx(c("MWXText.react"), {
                            color: e ? "disabled" : "primary",
                            type: "headlineEmphasized1",
                            children: a
                        })
                    })
                }, b)
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.MWChatEncryptedBackupsNumericCodeInputRenderer = a
}), 98);
__d("MWChatEncryptedBackupsNumericCodeInput.react", ["MWChatEncryptedBackupsNumericCodeInputInner.react", "MWChatEncryptedBackupsNumericCodeInputRenderer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useState;

    function a(a) {
        var b = a.enableMasking,
            e = a.inputSize,
            f = a.size,
            g = a.testid;
        g = a.value;
        var h = j(!1),
            k = h[0];
        h = h[1];
        return i.jsxs("div", {
            className: "x1n2onr6",
            children: [i.jsx(d("MWChatEncryptedBackupsNumericCodeInputRenderer.react").MWChatEncryptedBackupsNumericCodeInputRenderer, {
                color: a.color,
                disabled: a.disabled,
                enableMasking: b,
                hasFocus: k,
                inputSize: e,
                size: f,
                testid: void 0,
                value: g
            }), i.jsx(c("MWChatEncryptedBackupsNumericCodeInputInner.react"), {
                extraProps: {
                    setFocus: h
                },
                props: a
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWChatEncryptedBackupsSetIsDialogPersistedContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        setIsDialogPersisted: function() {}
    });
    g["default"] = b
}), 98);
__d("MWEBHasSeenAutoRestoreNoticeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        hasSeenNotice: !1
    });
    g["default"] = b
}), 98);
__d("MWEBLazyLoadResetPinPage", ["JSResourceForInteraction", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("JSResourceForInteraction")("MWEBPushResetPinPage").__setRef("MWEBLazyLoadResetPinPage");

    function a(a, b) {
        c("promiseDone")(h.load().then(function(c) {
            return c(a, b)
        }))
    }
    g["default"] = a
}), 98);
__d("MWEBPinCodeSize", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 6;
    f.EB_PIN_CODE_SIZE = a
}), 66);
__d("MWEncryptedBackupsOTCShowNotificationSentToast", ["fbt", "ix", "MWChatEncryptedBackupsQPLEvents", "QPLUserFlow", "SVGIcon", "cr:4027", "cr:6570", "fbicon", "mwPushToast", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = j || d("react");

    function a() {
        var a = b("cr:6570") ? k.jsx(b("cr:6570"), {
                icon: d("fbicon")._(i("477815"), 24)
            }) : void 0,
            e = b("cr:4027") ? d("SVGIcon").svgIcon(b("cr:4027")) : void 0;
        d("mwPushToast").mwPushToast({
            body: h._("__JHASH__jo46UlZ-CxV__JHASH__"),
            icon: {
                comet: a,
                mds: e
            },
            testid: "mw-chat-encrypted-backups-otc-notification-sent-successful-toast"
        });
        c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_RESTORE_NOTIFICATION_SENT_SUCCESSFUL_TOAST")
    }
    g.showOTCNotificationSentToast = a
}), 226);
__d("MWEncrypedBackupsSendOTCNotifications", ["FBLogger", "I64", "LSAuthorityLevel", "LSEncryptedBackupsOpStatus", "LSFactory", "LSSendOTCNotificationsStoredProcedure", "LSVec", "MWEncryptedBackupsOTCShowNotificationSentToast", "Promise", "ReQL", "ReQLSuspense", "asyncToGeneratorRuntime", "err", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = (k || d("react")).useCallback;

    function m(a) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var e = a.db,
                g = a.deviceIds;
            a = new(i || (i = b("Promise")))(function(a, b) {
                var f = d("ReQL").fromTableAscending(e.tables.encrypted_backups_otc_notification_sending_status),
                    g = f.subscribe(function(e, f) {
                        if (f.operation === "delete") return;
                        e = f.value;
                        if (e == null) return;
                        f = (j || (j = d("I64"))).to_int32(e.authorityLevel);
                        if (f !== c("LSAuthorityLevel").AUTHORITATIVE) return;
                        g();
                        switch ((j || (j = d("I64"))).to_int32(e.notificationSendingStatus)) {
                            case c("LSEncryptedBackupsOpStatus").SUCCESS:
                                d("MWEncryptedBackupsOTCShowNotificationSentToast").showOTCNotificationSentToast();
                                return a();
                            case c("LSEncryptedBackupsOpStatus").FAILURE:
                                return b(c("err")("[sendOTCNotifications] Failure"));
                            default:
                                c("FBLogger")("labyrinth_web").mustfix("OTC: Unexpected UNKNOWN status type for notification sending result.");
                                return b(c("err")("[sendOTCNotifications] Unknown"))
                        }
                    })
            });
            yield e.runInTransaction(function(a) {
                return c("LSSendOTCNotificationsStoredProcedure")(c("LSFactory")(a), {
                    deviceIds: c("LSVec").ofArray((a = g) != null ? a : [])
                })
            }, "readwrite", void 0, void 0, f.id + ":81");
            return a
        });
        return n.apply(this, arguments)
    }

    function a() {
        var a, b = (h || (h = c("useReStore")))();
        a = (a = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(b.tables.encrypted_backups_otc_notification_sending_status)
        }, [b.tables.encrypted_backups_otc_notification_sending_status], f.id + ":98")) == null ? void 0 : a.authorityLevel;
        a = a != null && (j || (j = d("I64"))).to_int32(a) === c("LSAuthorityLevel").OPTIMISTIC;
        var e = l(function(a) {
            return m({
                db: b,
                deviceIds: a
            })
        }, [b]);
        return [e, a]
    }
    g.sendOTCNotifications = m;
    g.useSendOTCNotifications = a
}), 98);
__d("MWEncryptedBackupsDeviceUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = [6628568379, 173847642670370, 350685531728];
    b = [173847642670370];
    f.FB_APP_IDS = a;
    f.TABLET_APP_IDS = b
}), 66);
__d("MWXIconMobile", ["MWXSvgIcon", "SVGIcon", "cr:12502", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12502")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWXIconTablet", ["MWXSvgIcon", "SVGIcon", "cr:12599", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12599")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsDeviceListCell.react", ["fbt", "AddOnStartOverride.react", "BaseMiddot.react", "FDSRelativeTimestamp.react", "I64", "MWEncryptedBackupsDeviceUtils", "MWXIconForListCell.react", "MWXIconMobile", "MWXIconTablet", "MWXListCell.react", "MWXTextPairing.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = i || (i = d("react")),
        l = i.useMemo;

    function a(a) {
        var b = a.device;
        a = l(function() {
            return b.appId != null ? (j || (j = d("I64"))).to_float(b.appId) : null
        }, [b.appId]);
        var e = d("MWEncryptedBackupsDeviceUtils").TABLET_APP_IDS.includes(a);
        a = d("MWEncryptedBackupsDeviceUtils").FB_APP_IDS.includes(a) ? h._("__JHASH__X0e88liSOaT__JHASH__") : h._("__JHASH__f4zXRCPfA02__JHASH__");
        return k.jsx(c("MWXListCell.react"), {
            addOnStart: k.jsx(c("AddOnStartOverride.react"), {
                children: k.jsx(c("MWXIconForListCell.react"), {
                    icon: e ? c("MWXIconTablet") : c("MWXIconMobile"),
                    size: "large"
                })
            }),
            content: k.jsx(c("MWXTextPairing.react"), {
                body: b.lastUploadTime != null && h._("__JHASH__x7Td_cS4dOE__JHASH__", [h._param("last_seen", k.jsx(c("FDSRelativeTimestamp.react"), {
                    date: new Date(Number(b.lastUploadTime) * 1e3)
                }))]),
                bodyColor: "secondary",
                headline: b.model != null ? k.jsxs(k.Fragment, {
                    children: [a, k.jsx(c("BaseMiddot.react"), {}), b.model]
                }) : a,
                level: 4
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWEncryptedBackupsForgotPinStep", ["deferredLoadComponent", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferred")("MWChatEncryptedBackupsForgotPinStep.react").__setRef("MWEncryptedBackupsForgotPinStep")),
        k = c("deferredLoadComponent")(c("requireDeferred")("MWChatEncryptedBackupsForgotPinInformationalResetPin.react").__setRef("MWEncryptedBackupsForgotPinStep"));

    function a(a) {
        var b = a.offlineDeviceCount,
            c = a.onClose,
            d = a.onComplete,
            e = a.pushPage;
        e(function() {
            var a = b > 0;
            if (a) return i.jsx(j, {
                isRCDeviceEnabled: a,
                onClose: c,
                onComplete: d,
                pushPage: e
            });
            else return i.jsx(k, {
                onClose: c,
                onComplete: d,
                pushPage: e
            })
        })
    }
    g.pushForgotPinPage = a
}), 98);
__d("MWEncryptedBackupsForgotRCStep", ["deferredLoadComponent", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("deferredLoadComponent")(c("requireDeferred")("MWChatEncryptedBackupsGenerateNewRecoveryCodeInstruction.react").__setRef("MWEncryptedBackupsForgotRCStep"));

    function a(a) {
        var b = a.onClose,
            c = a.onComplete,
            d = a.pushPage;
        d(function() {
            return i.jsx(j, {
                onClose: b,
                onComplete: c,
                pushPage: d
            })
        })
    }
    g.pushForgotRCPage = a
}), 98);
__d("MWXIconExclamationMarkCircleOutline", ["MWXSvgIcon", "SVGIcon", "cr:12406", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12406")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("useFetchOTCEligibleEBDevices", ["FBLogger", "LSAuthorityLevel", "LSFactory", "LSFetchOTCEligibleEBDevicesV2StoredProcedure", "LSIntEnum", "ReQL", "ReQLSuspense", "asyncToGeneratorRuntime", "gkx", "promiseDone", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;
    e = j || d("react");
    var k = e.useCallback,
        l = e.useEffect,
        m = e.useMemo,
        n = e.useRef,
        o = c("gkx")("24064");

    function a(a) {
        a === void 0 && (a = "store-or-network");
        var e = (h || (h = c("useReStore")))(),
            g = n(!1),
            j = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(e.tables.encrypted_backups_otc_devices)
            }, [e], f.id + ":42"),
            p = k(function() {
                return e.runInTransaction(function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                        var b = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.encrypted_backups_otc_devices)));
                        b = b != null && (i || (i = d("LSIntEnum"))).toNumber(b.authorityLevel) === c("LSAuthorityLevel").OPTIMISTIC;
                        if (!b) return c("LSFetchOTCEligibleEBDevicesV2StoredProcedure")(c("LSFactory")(a))
                    });
                    return function(b) {
                        return a.apply(this, arguments)
                    }
                }(), "readwrite", void 0, void 0, f.id + ":48")
            }, [e]),
            q = k(function() {
                c("promiseDone")(p(), null, function() {
                    c("FBLogger")("labyrinth_web").mustfix("Failed to fetch OTC eligible devices")
                })
            }, [p]);
        l(function() {
            g.current !== !0 && (j.length === 0 || a === "network-only") && (g.current = !0, q())
        }, [a, j.length, q]);
        var r = m(function() {
                return j.length > 0 && (i || (i = d("LSIntEnum"))).toNumber(j[0].authorityLevel) === c("LSAuthorityLevel").OPTIMISTIC
            }, [j]),
            s = m(function() {
                return !r && j.length > 0 && j[0].deviceId === "-1"
            }, [r, j]);
        l(function() {
            s && c("FBLogger")("labyrinth_web").mustfix("Encrypted Backups OTC: Failed to fetch otc eligible devices.")
        }, [s, p, a, r, j, q]);
        var t = m(function() {
            return j.filter(function(a) {
                return (i || (i = d("LSIntEnum"))).toNumber(a.authorityLevel) !== c("LSAuthorityLevel").OPTIMISTIC && a.deviceId !== ""
            })
        }, [j]);
        return {
            doesUserHaveOtcEligibleDevices: t.length > 0 || o,
            failedToFetchOtcDevices: s,
            isFetchOtcDevicesInFlight: r,
            otcEligibleDevices: t,
            triggerFetchOtcEligibleDevices: q
        }
    }
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsOTCEligibleDevicesList.react", ["fbt", "AddOnStartOverride.react", "MWChatEncryptedBackupsQPLEvents", "MWEncryptedBackupsDeviceListCell.react", "MWXGlimmer.react", "MWXIconExclamationMarkCircleOutline", "MWXIconForListCell.react", "MWXLink.react", "MWXList.react", "MWXListCell.react", "MWXText.react", "MWXTextPairing.react", "QPLUserFlow", "react", "useFetchOTCEligibleEBDevices"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react"));
    b = i;
    var k = b.useEffect,
        l = b.useRef,
        m = {
            glimmerBody: {
                borderTopStartRadius: "xa9qn9j",
                borderTopEndRadius: "x1trwbdj",
                borderBottomEndRadius: "x6a0fk7",
                borderBottomStartRadius: "xuyh7jl",
                height: "xlzyvqe",
                width: "x3hqpx7",
                $$css: !0
            },
            glimmerHeadline: {
                borderTopStartRadius: "xa9qn9j",
                borderTopEndRadius: "x1trwbdj",
                borderBottomEndRadius: "x6a0fk7",
                borderBottomStartRadius: "xuyh7jl",
                height: "xlzyvqe",
                width: "xktia5q",
                $$css: !0
            },
            glimmerIcon: {
                borderTopStartRadius: "xlid4zk",
                borderTopEndRadius: "x13tp074",
                borderBottomEndRadius: "x1qns1p2",
                borderBottomStartRadius: "xipx5yg",
                height: "xc9qbxq",
                width: "x14qfxbe",
                $$css: !0
            }
        };

    function n() {
        return j.jsx(c("MWXListCell.react"), {
            addOnStart: j.jsx(c("AddOnStartOverride.react"), {
                children: j.jsx(c("MWXGlimmer.react"), {
                    index: 0,
                    xstyle: m.glimmerIcon
                })
            }),
            content: j.jsx(c("MWXTextPairing.react"), {
                body: j.jsx(c("MWXGlimmer.react"), {
                    index: 2,
                    xstyle: m.glimmerBody
                }),
                headline: j.jsx(c("MWXGlimmer.react"), {
                    index: 1,
                    xstyle: m.glimmerHeadline
                }),
                level: 4
            })
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a() {
        var a = c("useFetchOTCEligibleEBDevices")(),
            b = a.failedToFetchOtcDevices,
            e = a.isFetchOtcDevicesInFlight,
            f = a.otcEligibleDevices;
        a = a.triggerFetchOtcEligibleDevices;
        var g = l(!1);
        k(function() {
            e || (c("QPLUserFlow").addAnnotations(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, {
                "int": {
                    otc_eligible_devices: f.length
                }
            }), b ? g.current || (g.current = !0, c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_DEVICES_LIST_FAILURE")) : !g.current && f.length > 0 && (g.current = !0, c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "OTC_DEVICES_LIST_LOADED")))
        }, [b, e, f.length]);
        if (e) return j.jsx(n, {});
        else if (b) return j.jsx(c("MWXListCell.react"), {
            addOnStart: j.jsx(c("AddOnStartOverride.react"), {
                children: j.jsx(c("MWXIconForListCell.react"), {
                    icon: c("MWXIconExclamationMarkCircleOutline"),
                    size: "large"
                })
            }),
            content: j.jsx(c("MWXText.react"), {
                type: "headlineEmphasized4",
                children: h._("__JHASH__kJ5r2sR46Qc__JHASH__", [h._param("try_again", j.jsx(c("MWXText.react"), {
                    color: "blueLink",
                    type: "headlineEmphasized4",
                    children: j.jsx(c("MWXLink.react"), {
                        onClick: a,
                        children: h._("__JHASH__03dyiSnSf15__JHASH__")
                    })
                }))])
            })
        });
        else return j.jsx(c("MWXList.react"), {
            testid: void 0,
            children: f.map(function(a) {
                return j.jsx(c("MWEncryptedBackupsDeviceListCell.react"), {
                    device: a
                }, a.deviceId)
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("PAKECleanupSessionReasonEnum", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        FLOW_ABANDONED: 0,
        TIMEOUT: 1
    });
    f["default"] = a
}), 66);
__d("PAKEMessageTypeEnum", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        AWAITING_CLIENT: 0,
        PAKE_MESSAGE_1: 1,
        PAKE_MESSAGE_2_AND_SECRET: 2,
        SESSION_EXPIRED_ERROR: 3,
        MAX_ATTEMPTS_ERROR: 4,
        GENERIC_ERROR: 5,
        MESSAGE_SENT_ERROR: 6,
        PREVIOUS_MESSAGE_MISSING_ERROR: 7,
        INVALID_PREVIOUS_MESSAGE_ERROR: 8,
        ENCRYPTION_ERROR: 9,
        DECRYPTION_ERROR: 10,
        CPACE_STEP_2_ERROR: 11,
        FETCH_SECRETS_ERROR: 12,
        CPACE_STEP_1_ERROR: 13,
        CPACE_STEP_3_ERROR: 14,
        PAKE_HANDSHAKE_SUCCESS: 15,
        SERIALIZATION_ERROR: 16,
        NO_ACTIVE_SESSION: 17,
        MULTIPLE_ACTIVE_SESSIONS_ERROR: 18,
        PROCESS_SECRETS_ERROR: 19,
        TIMEOUT_ERROR: 20,
        FLOW_ABANDONED_ERROR: 21,
        DESERIALIZE_SECRETS_ERROR: 22,
        CODE_REQUESTED: 23
    });
    f["default"] = a
}), 66);
__d("PakeCpaceUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.buffer.slice(a.byteOffset, a.byteLength + a.byteOffset)
    }

    function b(a, b) {
        var c = new a.VectorInt();
        b.forEach(function(a) {
            c.push_back(a)
        });
        return c
    }
    f.typedArrayToBuffer = a;
    f.uint8ArrayToVectorInt = b
}), 66);
__d("pakeCpace", ["Promise"], (function(a, b, c, d, e, f) {
    var g, h = function() {
        var a = typeof document !== "undefined" && document.currentScript ? document.currentScript.src : void 0;
        return function(c) {
            c = c || {};
            var c = typeof c !== "undefined" ? c : {},
                d = Object.assign,
                i, j;
            c.ready = new(g || (g = b("Promise")))(function(a, b) {
                i = a, j = b
            });
            var k = d({}, c),
                l = [],
                m = "./this.program";
            (function(a, b) {
                throw b
            });
            var n = !0,
                o = !1,
                p = "";

            function aa(a) {
                return c.locateFile ? c.locateFile(a, p) : p + a
            }
            var ba, ca, da;
            (n || o) && (o ? p = self.location.href : typeof document !== "undefined" && document.currentScript && (p = document.currentScript.src), a && (p = a), p.indexOf("blob:") !== 0 ? p = p.substr(0, p.replace(/[?#].*/, "").lastIndexOf("/") + 1) : p = "", (ba = function(a) {
                var b = new XMLHttpRequest();
                b.open("GET", a, !1);
                b.send(null);
                return b.responseText
            }, o && (da = function(a) {
                var b = new XMLHttpRequest();
                b.open("GET", a, !1);
                b.responseType = "arraybuffer";
                b.send(null);
                return new Uint8Array(b.response)
            }), ca = function(a, b, c) {
                var d = new XMLHttpRequest();
                d.open("GET", a, !0);
                d.responseType = "arraybuffer";
                d.onload = function() {
                    if (d.status == 200 || d.status == 0 && d.response) {
                        b(d.response);
                        return
                    }
                    c()
                };
                d.onerror = c;
                d.send(null)
            }), function(a) {
                return document.title = a
            });
            var ea = c.print || emptyFunction.bind(console),
                q = c.printErr || emptyFunction.bind(console);
            d(c, k);
            k = null;
            c.arguments && (l = c.arguments);
            c.thisProgram && (m = c.thisProgram);
            c.quit && c.quit;
            var fa = 0,
                r = function(a) {
                    fa = a
                },
                ga = function() {
                    return fa
                },
                s;
            c.wasmBinary && (s = c.wasmBinary);
            c.noExitRuntime || !0;
            typeof WebAssembly !== "object" && A("no native wasm support detected");
            var ha, ia = !1;

            function ja(a, b) {
                a || A(b)
            }
            var ka = typeof TextDecoder !== "undefined" ? new TextDecoder("utf8") : void 0;

            function t(a, b, c) {
                c = b + c;
                var d = b;
                while (a[d] && !(d >= c)) ++d;
                if (d - b > 16 && a.subarray && ka) return ka.decode(a.subarray(b, d));
                else {
                    c = "";
                    while (b < d) {
                        var e = a[b++];
                        if (!(e & 128)) {
                            c += String.fromCharCode(e);
                            continue
                        }
                        var f = a[b++] & 63;
                        if ((e & 224) == 192) {
                            c += String.fromCharCode((e & 31) << 6 | f);
                            continue
                        }
                        var g = a[b++] & 63;
                        (e & 240) == 224 ? e = (e & 15) << 12 | f << 6 | g : e = (e & 7) << 18 | f << 12 | g << 6 | a[b++] & 63;
                        if (e < 65536) c += String.fromCharCode(e);
                        else {
                            f = e - 65536;
                            c += String.fromCharCode(55296 | f >> 10, 56320 | f & 1023)
                        }
                    }
                }
                return c
            }

            function la(a, b) {
                return a ? t(v, a, b) : ""
            }

            function ma(a, b, c, d) {
                if (!(d > 0)) return 0;
                var e = c;
                d = c + d - 1;
                for (var f = 0; f < a.length; ++f) {
                    var g = a.charCodeAt(f);
                    if (g >= 55296 && g <= 57343) {
                        var h = a.charCodeAt(++f);
                        g = 65536 + ((g & 1023) << 10) | h & 1023
                    }
                    if (g <= 127) {
                        if (c >= d) break;
                        b[c++] = g
                    } else if (g <= 2047) {
                        if (c + 1 >= d) break;
                        b[c++] = 192 | g >> 6;
                        b[c++] = 128 | g & 63
                    } else if (g <= 65535) {
                        if (c + 2 >= d) break;
                        b[c++] = 224 | g >> 12;
                        b[c++] = 128 | g >> 6 & 63;
                        b[c++] = 128 | g & 63
                    } else {
                        if (c + 3 >= d) break;
                        b[c++] = 240 | g >> 18;
                        b[c++] = 128 | g >> 12 & 63;
                        b[c++] = 128 | g >> 6 & 63;
                        b[c++] = 128 | g & 63
                    }
                }
                b[c] = 0;
                return c - e
            }

            function na(a, b, c) {
                return ma(a, v, b, c)
            }

            function oa(a) {
                var b = 0;
                for (var c = 0; c < a.length; ++c) {
                    var d = a.charCodeAt(c);
                    d >= 55296 && d <= 57343 && (d = 65536 + ((d & 1023) << 10) | a.charCodeAt(++c) & 1023);
                    d <= 127 ? ++b : d <= 2047 ? b += 2 : d <= 65535 ? b += 3 : b += 4
                }
                return b
            }
            var pa = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-16le") : void 0;

            function qa(a, b) {
                var c = a,
                    d = c >> 1,
                    e = d + b / 2;
                while (!(d >= e) && za[d]) ++d;
                c = d << 1;
                if (c - a > 32 && pa) return pa.decode(v.subarray(a, c));
                else {
                    e = "";
                    for (d = 0; !(d >= b / 2); ++d) {
                        c = w[a + d * 2 >> 1];
                        if (c == 0) break;
                        e += String.fromCharCode(c)
                    }
                    return e
                }
            }

            function ra(a, b, c) {
                c === void 0 && (c = 2147483647);
                if (c < 2) return 0;
                c -= 2;
                var d = b;
                c = c < a.length * 2 ? c / 2 : a.length;
                for (var e = 0; e < c; ++e) {
                    var f = a.charCodeAt(e);
                    w[b >> 1] = f;
                    b += 2
                }
                w[b >> 1] = 0;
                return b - d
            }

            function sa(a) {
                return a.length * 2
            }

            function ta(a, b) {
                var c = 0,
                    d = "";
                while (!(c >= b / 4)) {
                    var e = x[a + c * 4 >> 2];
                    if (e == 0) break;
                    ++c;
                    if (e >= 65536) {
                        var f = e - 65536;
                        d += String.fromCharCode(55296 | f >> 10, 56320 | f & 1023)
                    } else d += String.fromCharCode(e)
                }
                return d
            }

            function ua(a, b, c) {
                c === void 0 && (c = 2147483647);
                if (c < 4) return 0;
                var d = b;
                c = d + c - 4;
                for (var e = 0; e < a.length; ++e) {
                    var f = a.charCodeAt(e);
                    if (f >= 55296 && f <= 57343) {
                        var g = a.charCodeAt(++e);
                        f = 65536 + ((f & 1023) << 10) | g & 1023
                    }
                    x[b >> 2] = f;
                    b += 4;
                    if (b + 4 > c) break
                }
                x[b >> 2] = 0;
                return b - d
            }

            function va(a) {
                var b = 0;
                for (var c = 0; c < a.length; ++c) {
                    var d = a.charCodeAt(c);
                    d >= 55296 && d <= 57343 && ++c;
                    b += 4
                }
                return b
            }

            function wa(b, a) {
                u.set(b, a)
            }

            function xa(b, a, c) {
                for (var d = 0; d < b.length; ++d) u[a++ >> 0] = b.charCodeAt(d);
                c || (u[a >> 0] = 0)
            }
            var ya, u, v, w, za, x, y, Aa, Ba;

            function Ca(a) {
                ya = a, c.HEAP8 = u = new Int8Array(a), c.HEAP16 = w = new Int16Array(a), c.HEAP32 = x = new Int32Array(a), c.HEAPU8 = v = new Uint8Array(a), c.HEAPU16 = za = new Uint16Array(a), c.HEAPU32 = y = new Uint32Array(a), c.HEAPF32 = Aa = new Float32Array(a), c.HEAPF64 = Ba = new Float64Array(a)
            }
            c.INITIAL_MEMORY || 16777216;
            var Da, Ea = [],
                Fa = [],
                Ga = [];

            function Ha() {
                if (c.preRun) {
                    typeof c.preRun == "function" && (c.preRun = [c.preRun]);
                    while (c.preRun.length) Ka(c.preRun.shift())
                }
                Xa(Ea)
            }

            function Ia() {
                !c.noFSInit && !K.init.initialized && K.init(), K.ignorePermissions = !1, I.init(), Xa(Fa)
            }

            function Ja() {
                if (c.postRun) {
                    typeof c.postRun == "function" && (c.postRun = [c.postRun]);
                    while (c.postRun.length) Ma(c.postRun.shift())
                }
                Xa(Ga)
            }

            function Ka(a) {
                Ea.unshift(a)
            }

            function La(a) {
                Fa.unshift(a)
            }

            function Ma(a) {
                Ga.unshift(a)
            }
            var z = 0,
                Na = null,
                Oa = null;

            function Pa(a) {
                return a
            }

            function Qa(a) {
                z++, c.monitorRunDependencies && c.monitorRunDependencies(z)
            }

            function Ra(a) {
                z--;
                c.monitorRunDependencies && c.monitorRunDependencies(z);
                if (z == 0) {
                    Na !== null && (clearInterval(Na), Na = null);
                    if (Oa) {
                        a = Oa;
                        Oa = null;
                        a()
                    }
                }
            }
            c.preloadedImages = {};
            c.preloadedAudios = {};

            function A(a) {
                c.onAbort && c.onAbort(a);
                a = "Aborted(" + a + ")";
                q(a);
                ia = !0;
                a += ". Build with -s ASSERTIONS=1 for more info.";
                a = new WebAssembly.RuntimeError(a);
                j(a);
                throw a
            }
            var Sa = "data:application/octet-stream;base64,";

            function Ta(a) {
                return a.startsWith(Sa)
            }
            var B;
            B = "pakeCpace.wasm";
            Ta(B) || (B = aa(B));

            function Ua(a) {
                try {
                    if (a == B && s) return new Uint8Array(s);
                    if (da) return da(a);
                    else throw "both async and sync fetching of the wasm failed"
                } catch (a) {
                    A(a)
                }
            }

            function Va() {
                return !s && (n || o) && typeof fetch === "function" ? fetch(B, {
                    credentials: "same-origin"
                }).then(function(a) {
                    if (!a.ok) throw "failed to load wasm binary file at '" + B + "'";
                    return a.arrayBuffer()
                })["catch"](function() {
                    return Ua(B)
                }) : (g || (g = b("Promise"))).resolve().then(function() {
                    return Ua(B)
                })
            }

            function Wa() {
                var b = {
                    a: vd
                };

                function d(b, a) {
                    a = b.exports;
                    c.asm = a;
                    ha = c.asm.ha;
                    Ca(ha.buffer);
                    Da = c.asm.ka;
                    La(c.asm.ia);
                    Ra("wasm-instantiate")
                }
                Qa("wasm-instantiate");

                function g(a) {
                    d(a.instance)
                }

                function h(a) {
                    return Va().then(function(a) {
                        return WebAssembly.instantiate(a, b)
                    }).then(function(a) {
                        return a
                    }).then(a, function(a) {
                        q("failed to asynchronously prepare wasm: " + a), A(a)
                    })
                }

                function i() {
                    if (!s && typeof WebAssembly.instantiateStreaming === "function" && !Ta(B) && typeof fetch === "function") return fetch(B, {
                        credentials: "same-origin"
                    }).then(function(a) {
                        a = WebAssembly.instantiateStreaming(a, b);
                        return a.then(g, function(a) {
                            q("wasm streaming compile failed: " + a);
                            q("falling back to ArrayBuffer instantiation");
                            return h(g)
                        })
                    });
                    else return h(g)
                }
                if (c.instantiateWasm) try {
                    var a = c.instantiateWasm(b, d);
                    return a
                } catch (a) {
                    q("Module.instantiateWasm callback failed with error: " + a);
                    return !1
                }
                i()["catch"](j);
                return {}
            }
            var C, D;

            function Xa(a) {
                while (a.length > 0) {
                    var b = a.shift();
                    if (typeof b == "function") {
                        b(c);
                        continue
                    }
                    var d = b.func;
                    typeof d === "number" ? b.arg === void 0 ? E(d)() : E(d)(b.arg) : d(b.arg === void 0 ? null : b.arg)
                }
            }

            function E(a) {
                return Da.get(a)
            }

            function Ya(a) {
                return wd(a + 16) + 16
            }

            function Za(a) {
                this.excPtr = a, this.ptr = a - 16, this.set_type = function(a) {
                    x[this.ptr + 4 >> 2] = a
                }, this.get_type = function() {
                    return x[this.ptr + 4 >> 2]
                }, this.set_destructor = function(a) {
                    x[this.ptr + 8 >> 2] = a
                }, this.get_destructor = function() {
                    return x[this.ptr + 8 >> 2]
                }, this.set_refcount = function(a) {
                    x[this.ptr >> 2] = a
                }, this.set_caught = function(a) {
                    a = a ? 1 : 0, u[this.ptr + 12 >> 0] = a
                }, this.get_caught = function() {
                    return u[this.ptr + 12 >> 0] != 0
                }, this.set_rethrown = function(a) {
                    a = a ? 1 : 0, u[this.ptr + 13 >> 0] = a
                }, this.get_rethrown = function() {
                    return u[this.ptr + 13 >> 0] != 0
                }, this.init = function(a, b) {
                    this.set_type(a), this.set_destructor(b), this.set_refcount(0), this.set_caught(!1), this.set_rethrown(!1)
                }, this.add_ref = function() {
                    var a = x[this.ptr >> 2];
                    x[this.ptr >> 2] = a + 1
                }, this.release_ref = function() {
                    var a = x[this.ptr >> 2];
                    x[this.ptr >> 2] = a - 1;
                    return a === 1
                }
            }

            function $a(a) {
                this.free = function() {
                    X(this.ptr), this.ptr = 0
                }, this.set_base_ptr = function(a) {
                    x[this.ptr >> 2] = a
                }, this.get_base_ptr = function() {
                    return x[this.ptr >> 2]
                }, this.set_adjusted_ptr = function(a) {
                    x[this.ptr + 4 >> 2] = a
                }, this.get_adjusted_ptr_addr = function() {
                    return this.ptr + 4
                }, this.get_adjusted_ptr = function() {
                    return x[this.ptr + 4 >> 2]
                }, this.get_exception_ptr = function() {
                    var a = zd(this.get_exception_info().get_type());
                    if (a) return x[this.get_base_ptr() >> 2];
                    a = this.get_adjusted_ptr();
                    return a !== 0 ? a : this.get_base_ptr()
                }, this.get_exception_info = function() {
                    return new Za(this.get_base_ptr())
                }, a === void 0 ? (this.ptr = wd(8), this.set_adjusted_ptr(0)) : this.ptr = a
            }
            var ab = [];

            function bb(a) {
                a.add_ref()
            }
            var cb = 0;

            function db(a) {
                a = new $a(a);
                var b = a.get_exception_info();
                b.get_caught() || (b.set_caught(!0), cb--);
                b.set_rethrown(!1);
                ab.push(a);
                bb(b);
                return a.get_exception_ptr()
            }
            var F = 0;

            function eb(a) {
                try {
                    return X(new Za(a).ptr)
                } catch (a) {}
            }

            function fb(a) {
                if (a.release_ref() && !a.get_rethrown()) {
                    var b = a.get_destructor();
                    b && E(b)(a.excPtr);
                    eb(a.excPtr)
                }
            }

            function gb() {
                Y(0);
                var a = ab.pop();
                fb(a.get_exception_info());
                a.free();
                F = 0
            }

            function hb(a) {
                a = new $a(a);
                var b = a.get_base_ptr();
                F || (F = b);
                a.free();
                throw b
            }

            function ib() {
                var a = F;
                if (!a) {
                    r(0);
                    return 0 | 0
                }
                var b = new Za(a),
                    c = b.get_type(),
                    d = new $a();
                d.set_base_ptr(a);
                d.set_adjusted_ptr(a);
                if (!c) {
                    r(0);
                    return d.ptr | 0
                }
                var e = Array.prototype.slice.call(arguments);
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    if (g === 0 || g === c) break;
                    if (yd(g, c, d.get_adjusted_ptr_addr())) {
                        r(g);
                        return d.ptr | 0
                    }
                }
                r(c);
                return d.ptr | 0
            }

            function jb() {
                var a = F;
                if (!a) {
                    r(0);
                    return 0 | 0
                }
                var b = new Za(a),
                    c = b.get_type(),
                    d = new $a();
                d.set_base_ptr(a);
                d.set_adjusted_ptr(a);
                if (!c) {
                    r(0);
                    return d.ptr | 0
                }
                var e = Array.prototype.slice.call(arguments);
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    if (g === 0 || g === c) break;
                    if (yd(g, c, d.get_adjusted_ptr_addr())) {
                        r(g);
                        return d.ptr | 0
                    }
                }
                r(c);
                return d.ptr | 0
            }

            function kb() {
                var a = ab.pop();
                a || A("no exception to throw");
                var b = a.get_exception_info(),
                    c = a.get_base_ptr();
                !b.get_rethrown() ? (ab.push(a), b.set_rethrown(!0), b.set_caught(!1), cb++) : a.free();
                F = c;
                throw c
            }

            function lb(a, b, c) {
                var d = new Za(a);
                d.init(b, c);
                F = a;
                cb++;
                throw a
            }

            function mb() {
                return cb
            }
            var G = {
                splitPath: function(a) {
                    var b = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
                    return b.exec(a).slice(1)
                },
                normalizeArray: function(a, b) {
                    var c = 0;
                    for (var d = a.length - 1; d >= 0; d--) {
                        var e = a[d];
                        e === "." ? a.splice(d, 1) : e === ".." ? (a.splice(d, 1), c++) : c && (a.splice(d, 1), c--)
                    }
                    if (b)
                        for (; c; c--) a.unshift("..");
                    return a
                },
                normalize: function(a) {
                    var b = a.charAt(0) === "/",
                        c = a.substr(-1) === "/";
                    a = G.normalizeArray(a.split("/").filter(function(a) {
                        return !!a
                    }), !b).join("/");
                    !a && !b && (a = ".");
                    a && c && (a += "/");
                    return (b ? "/" : "") + a
                },
                dirname: function(a) {
                    a = G.splitPath(a);
                    var b = a[0];
                    a = a[1];
                    if (!b && !a) return ".";
                    a && (a = a.substr(0, a.length - 1));
                    return b + a
                },
                basename: function(a) {
                    if (a === "/") return "/";
                    a = G.normalize(a);
                    a = a.replace(/\/$/, "");
                    var b = a.lastIndexOf("/");
                    return b === -1 ? a : a.substr(b + 1)
                },
                extname: function(a) {
                    return G.splitPath(a)[3]
                },
                join: function() {
                    var a = Array.prototype.slice.call(arguments, 0);
                    return G.normalize(a.join("/"))
                },
                join2: function(a, b) {
                    return G.normalize(a + "/" + b)
                }
            };

            function nb() {
                if (typeof crypto === "object" && typeof crypto.getRandomValues === "function") {
                    var a = new Uint8Array(1);
                    return function() {
                        crypto.getRandomValues(a);
                        return a[0]
                    }
                } else return function() {
                    A("randomDevice")
                }
            }
            var H = {
                    resolve: function() {
                        var a = "",
                            b = !1;
                        for (var c = arguments.length - 1; c >= -1 && !b; c--) {
                            var d = c >= 0 ? arguments[c] : K.cwd();
                            if (typeof d !== "string") throw new TypeError("Arguments to path.resolve must be strings");
                            else if (!d) return "";
                            a = d + "/" + a;
                            b = d.charAt(0) === "/"
                        }
                        a = G.normalizeArray(a.split("/").filter(function(a) {
                            return !!a
                        }), !b).join("/");
                        return (b ? "/" : "") + a || "."
                    },
                    relative: function(a, b) {
                        a = H.resolve(a).substr(1);
                        b = H.resolve(b).substr(1);

                        function c(a) {
                            var b = 0;
                            for (; b < a.length; b++)
                                if (a[b] !== "") break;
                            var c = a.length - 1;
                            for (; c >= 0; c--)
                                if (a[c] !== "") break;
                            return b > c ? [] : a.slice(b, c - b + 1)
                        }
                        a = c(a.split("/"));
                        c = c(b.split("/"));
                        b = Math.min(a.length, c.length);
                        var d = b;
                        for (var e = 0; e < b; e++)
                            if (a[e] !== c[e]) {
                                d = e;
                                break
                            }
                        b = [];
                        for (var e = d; e < a.length; e++) b.push("..");
                        b = b.concat(c.slice(d));
                        return b.join("/")
                    }
                },
                I = {
                    ttys: [],
                    init: function() {},
                    shutdown: function() {},
                    register: function(a, b) {
                        I.ttys[a] = {
                            input: [],
                            output: [],
                            ops: b
                        }, K.registerDevice(a, I.stream_ops)
                    },
                    stream_ops: {
                        open: function(a) {
                            var b = I.ttys[a.node.rdev];
                            if (!b) throw new K.ErrnoError(43);
                            a.tty = b;
                            a.seekable = !1
                        },
                        close: function(a) {
                            a.tty.ops.flush(a.tty)
                        },
                        flush: function(a) {
                            a.tty.ops.flush(a.tty)
                        },
                        read: function(b, a, c, d, e) {
                            if (!b.tty || !b.tty.ops.get_char) throw new K.ErrnoError(60);
                            e = 0;
                            for (var f = 0; f < d; f++) {
                                var g;
                                try {
                                    g = b.tty.ops.get_char(b.tty)
                                } catch (a) {
                                    throw new K.ErrnoError(29)
                                }
                                if (g === void 0 && e === 0) throw new K.ErrnoError(6);
                                if (g === null || g === void 0) break;
                                e++;
                                a[c + f] = g
                            }
                            e && (b.node.timestamp = Date.now());
                            return e
                        },
                        write: function(b, a, c, d, e) {
                            if (!b.tty || !b.tty.ops.put_char) throw new K.ErrnoError(60);
                            try {
                                for (var f = 0; f < d; f++) b.tty.ops.put_char(b.tty, a[c + f])
                            } catch (a) {
                                throw new K.ErrnoError(29)
                            }
                            d && (b.node.timestamp = Date.now());
                            return f
                        }
                    },
                    default_tty_ops: {
                        get_char: function(a) {
                            if (!a.input.length) {
                                var b = null;
                                typeof window != "undefined" && typeof window.prompt == "function" ? (b = window.prompt("Input: "), b !== null && (b += "\n")) : typeof readline == "function" && (b = readline(), b !== null && (b += "\n"));
                                if (!b) return null;
                                a.input = ud(b, !0)
                            }
                            return a.input.shift()
                        },
                        put_char: function(a, b) {
                            b === null || b === 10 ? (ea(t(a.output, 0)), a.output = []) : b != 0 && a.output.push(b)
                        },
                        flush: function(a) {
                            a.output && a.output.length > 0 && (ea(t(a.output, 0)), a.output = [])
                        }
                    },
                    default_tty1_ops: {
                        put_char: function(a, b) {
                            b === null || b === 10 ? (q(t(a.output, 0)), a.output = []) : b != 0 && a.output.push(b)
                        },
                        flush: function(a) {
                            a.output && a.output.length > 0 && (q(t(a.output, 0)), a.output = [])
                        }
                    }
                };

            function ob(a) {
                A()
            }
            var J = {
                ops_table: null,
                mount: function(a) {
                    return J.createNode(null, "/", 16384 | 511, 0)
                },
                createNode: function(a, b, c, d) {
                    if (K.isBlkdev(c) || K.isFIFO(c)) throw new K.ErrnoError(63);
                    J.ops_table || (J.ops_table = {
                        dir: {
                            node: {
                                getattr: J.node_ops.getattr,
                                setattr: J.node_ops.setattr,
                                lookup: J.node_ops.lookup,
                                mknod: J.node_ops.mknod,
                                rename: J.node_ops.rename,
                                unlink: J.node_ops.unlink,
                                rmdir: J.node_ops.rmdir,
                                readdir: J.node_ops.readdir,
                                symlink: J.node_ops.symlink
                            },
                            stream: {
                                llseek: J.stream_ops.llseek
                            }
                        },
                        file: {
                            node: {
                                getattr: J.node_ops.getattr,
                                setattr: J.node_ops.setattr
                            },
                            stream: {
                                llseek: J.stream_ops.llseek,
                                read: J.stream_ops.read,
                                write: J.stream_ops.write,
                                allocate: J.stream_ops.allocate,
                                mmap: J.stream_ops.mmap,
                                msync: J.stream_ops.msync
                            }
                        },
                        link: {
                            node: {
                                getattr: J.node_ops.getattr,
                                setattr: J.node_ops.setattr,
                                readlink: J.node_ops.readlink
                            },
                            stream: {}
                        },
                        chrdev: {
                            node: {
                                getattr: J.node_ops.getattr,
                                setattr: J.node_ops.setattr
                            },
                            stream: K.chrdev_stream_ops
                        }
                    });
                    c = K.createNode(a, b, c, d);
                    K.isDir(c.mode) ? (c.node_ops = J.ops_table.dir.node, c.stream_ops = J.ops_table.dir.stream, c.contents = {}) : K.isFile(c.mode) ? (c.node_ops = J.ops_table.file.node, c.stream_ops = J.ops_table.file.stream, c.usedBytes = 0, c.contents = null) : K.isLink(c.mode) ? (c.node_ops = J.ops_table.link.node, c.stream_ops = J.ops_table.link.stream) : K.isChrdev(c.mode) && (c.node_ops = J.ops_table.chrdev.node, c.stream_ops = J.ops_table.chrdev.stream);
                    c.timestamp = Date.now();
                    a && (a.contents[b] = c, a.timestamp = c.timestamp);
                    return c
                },
                getFileDataAsTypedArray: function(a) {
                    if (!a.contents) return new Uint8Array(0);
                    return a.contents.subarray ? a.contents.subarray(0, a.usedBytes) : new Uint8Array(a.contents)
                },
                expandFileStorage: function(a, b) {
                    var c = a.contents ? a.contents.length : 0;
                    if (c >= b) return;
                    var d = 1024 * 1024;
                    b = Math.max(b, c * (c < d ? 2 : 1.125) >>> 0);
                    c != 0 && (b = Math.max(b, 256));
                    d = a.contents;
                    a.contents = new Uint8Array(b);
                    a.usedBytes > 0 && a.contents.set(d.subarray(0, a.usedBytes), 0)
                },
                resizeFileStorage: function(a, b) {
                    if (a.usedBytes == b) return;
                    if (b == 0) a.contents = null, a.usedBytes = 0;
                    else {
                        var c = a.contents;
                        a.contents = new Uint8Array(b);
                        c && a.contents.set(c.subarray(0, Math.min(b, a.usedBytes)));
                        a.usedBytes = b
                    }
                },
                node_ops: {
                    getattr: function(a) {
                        var b = {};
                        b.dev = K.isChrdev(a.mode) ? a.id : 1;
                        b.ino = a.id;
                        b.mode = a.mode;
                        b.nlink = 1;
                        b.uid = 0;
                        b.gid = 0;
                        b.rdev = a.rdev;
                        K.isDir(a.mode) ? b.size = 4096 : K.isFile(a.mode) ? b.size = a.usedBytes : K.isLink(a.mode) ? b.size = a.link.length : b.size = 0;
                        b.atime = new Date(a.timestamp);
                        b.mtime = new Date(a.timestamp);
                        b.ctime = new Date(a.timestamp);
                        b.blksize = 4096;
                        b.blocks = Math.ceil(b.size / b.blksize);
                        return b
                    },
                    setattr: function(a, b) {
                        b.mode !== void 0 && (a.mode = b.mode), b.timestamp !== void 0 && (a.timestamp = b.timestamp), b.size !== void 0 && J.resizeFileStorage(a, b.size)
                    },
                    lookup: function(a, b) {
                        throw K.genericErrors[44]
                    },
                    mknod: function(a, b, c, d) {
                        return J.createNode(a, b, c, d)
                    },
                    rename: function(a, b, c) {
                        if (K.isDir(a.mode)) {
                            var d;
                            try {
                                d = K.lookupNode(b, c)
                            } catch (a) {}
                            if (d)
                                for (var e in d.contents) throw new K.ErrnoError(55)
                        }
                        delete a.parent.contents[a.name];
                        a.parent.timestamp = Date.now();
                        a.name = c;
                        b.contents[c] = a;
                        b.timestamp = a.parent.timestamp;
                        a.parent = b
                    },
                    unlink: function(a, b) {
                        delete a.contents[b], a.timestamp = Date.now()
                    },
                    rmdir: function(a, b) {
                        var c = K.lookupNode(a, b);
                        for (c in c.contents) throw new K.ErrnoError(55);
                        delete a.contents[b];
                        a.timestamp = Date.now()
                    },
                    readdir: function(a) {
                        var b = [".", ".."];
                        for (var c in a.contents) {
                            if (!Object.prototype.hasOwnProperty.call(a.contents, c)) continue;
                            b.push(c)
                        }
                        return b
                    },
                    symlink: function(a, b, c) {
                        a = J.createNode(a, b, 511 | 40960, 0);
                        a.link = c;
                        return a
                    },
                    readlink: function(a) {
                        if (!K.isLink(a.mode)) throw new K.ErrnoError(28);
                        return a.link
                    }
                },
                stream_ops: {
                    read: function(b, a, c, d, e) {
                        var f = b.node.contents;
                        if (e >= b.node.usedBytes) return 0;
                        b = Math.min(b.node.usedBytes - e, d);
                        if (b > 8 && f.subarray) a.set(f.subarray(e, e + b), c);
                        else
                            for (d = 0; d < b; d++) a[c + d] = f[e + d];
                        return b
                    },
                    write: function(b, a, c, d, e, f) {
                        if (!d) return 0;
                        b = b.node;
                        b.timestamp = Date.now();
                        if (a.subarray && (!b.contents || b.contents.subarray))
                            if (f) {
                                b.contents = a.subarray(c, c + d);
                                b.usedBytes = d;
                                return d
                            } else if (b.usedBytes === 0 && e === 0) {
                            b.contents = a.slice(c, c + d);
                            b.usedBytes = d;
                            return d
                        } else if (e + d <= b.usedBytes) {
                            b.contents.set(a.subarray(c, c + d), e);
                            return d
                        }
                        J.expandFileStorage(b, e + d);
                        if (b.contents.subarray && a.subarray) b.contents.set(a.subarray(c, c + d), e);
                        else
                            for (f = 0; f < d; f++) b.contents[e + f] = a[c + f];
                        b.usedBytes = Math.max(b.usedBytes, e + d);
                        return d
                    },
                    llseek: function(a, b, c) {
                        b = b;
                        c === 1 ? b += a.position : c === 2 && (K.isFile(a.node.mode) && (b += a.node.usedBytes));
                        if (b < 0) throw new K.ErrnoError(28);
                        return b
                    },
                    allocate: function(a, b, c) {
                        J.expandFileStorage(a.node, b + c), a.node.usedBytes = Math.max(a.node.usedBytes, b + c)
                    },
                    mmap: function(a, b, c, d, e, f) {
                        if (b !== 0) throw new K.ErrnoError(28);
                        if (!K.isFile(a.node.mode)) throw new K.ErrnoError(43);
                        e = a.node.contents;
                        if (!(f & 2) && e.buffer === ya) b = !1, a = e.byteOffset;
                        else {
                            (d > 0 || d + c < e.length) && (e.subarray ? e = e.subarray(d, d + c) : e = Array.prototype.slice.call(e, d, d + c));
                            b = !0;
                            a = ob(c);
                            if (!a) throw new K.ErrnoError(48);
                            u.set(e, a)
                        }
                        return {
                            ptr: a,
                            allocated: b
                        }
                    },
                    msync: function(b, a, c, d, e) {
                        if (!K.isFile(b.node.mode)) throw new K.ErrnoError(43);
                        if (e & 2) return 0;
                        J.stream_ops.write(b, a, 0, d, c, !1);
                        return 0
                    }
                }
            };

            function pb(a, b, c, d) {
                var e = d ? "" : Pa("al " + a);
                ca(a, function(c) {
                    ja(c, 'Loading data file "' + a + '" failed (no arrayBuffer).'), b(new Uint8Array(c)), e && Ra(e)
                }, function(b) {
                    if (c) c();
                    else throw 'Loading data file "' + a + '" failed.'
                });
                e && Qa(e)
            }
            var K = {
                    root: null,
                    mounts: [],
                    devices: {},
                    streams: [],
                    nextInode: 1,
                    nameTable: null,
                    currentPath: "/",
                    initialized: !1,
                    ignorePermissions: !0,
                    ErrnoError: null,
                    genericErrors: {},
                    filesystems: null,
                    syncFSRequests: 0,
                    lookupPath: function(a, b) {
                        b === void 0 && (b = {});
                        a = H.resolve(K.cwd(), a);
                        if (!a) return {
                            path: "",
                            node: null
                        };
                        var c = {
                            follow_mount: !0,
                            recurse_count: 0
                        };
                        for (var d in c) b[d] === void 0 && (b[d] = c[d]);
                        if (b.recurse_count > 8) throw new K.ErrnoError(32);
                        c = G.normalizeArray(a.split("/").filter(function(a) {
                            return !!a
                        }), !1);
                        d = K.root;
                        a = "/";
                        for (var e = 0; e < c.length; e++) {
                            var f = e === c.length - 1;
                            if (f && b.parent) break;
                            d = K.lookupNode(d, c[e]);
                            a = G.join2(a, c[e]);
                            K.isMountpoint(d) && ((!f || f && b.follow_mount) && (d = d.mounted.root));
                            if (!f || b.follow) {
                                f = 0;
                                while (K.isLink(d.mode)) {
                                    var g = K.readlink(a);
                                    a = H.resolve(G.dirname(a), g);
                                    g = K.lookupPath(a, {
                                        recurse_count: b.recurse_count
                                    });
                                    d = g.node;
                                    if (f++ > 40) throw new K.ErrnoError(32)
                                }
                            }
                        }
                        return {
                            path: a,
                            node: d
                        }
                    },
                    getPath: function(a) {
                        var b;
                        while (!0) {
                            if (K.isRoot(a)) {
                                var c = a.mount.mountpoint;
                                return !b ? c : c[c.length - 1] !== "/" ? c + "/" + b : c + b
                            }
                            b = b ? a.name + "/" + b : a.name;
                            a = a.parent
                        }
                    },
                    hashName: function(a, b) {
                        var c = 0;
                        for (var d = 0; d < b.length; d++) c = (c << 5) - c + b.charCodeAt(d) | 0;
                        return (a + c >>> 0) % K.nameTable.length
                    },
                    hashAddNode: function(a) {
                        var b = K.hashName(a.parent.id, a.name);
                        a.name_next = K.nameTable[b];
                        K.nameTable[b] = a
                    },
                    hashRemoveNode: function(a) {
                        var b = K.hashName(a.parent.id, a.name);
                        if (K.nameTable[b] === a) K.nameTable[b] = a.name_next;
                        else {
                            b = K.nameTable[b];
                            while (b) {
                                if (b.name_next === a) {
                                    b.name_next = a.name_next;
                                    break
                                }
                                b = b.name_next
                            }
                        }
                    },
                    lookupNode: function(a, b) {
                        var c = K.mayLookup(a);
                        if (c) throw new K.ErrnoError(c, a);
                        c = K.hashName(a.id, b);
                        for (c = K.nameTable[c]; c; c = c.name_next) {
                            var d = c.name;
                            if (c.parent.id === a.id && d === b) return c
                        }
                        return K.lookup(a, b)
                    },
                    createNode: function(a, b, c, d) {
                        a = new K.FSNode(a, b, c, d);
                        K.hashAddNode(a);
                        return a
                    },
                    destroyNode: function(a) {
                        K.hashRemoveNode(a)
                    },
                    isRoot: function(a) {
                        return a === a.parent
                    },
                    isMountpoint: function(a) {
                        return !!a.mounted
                    },
                    isFile: function(a) {
                        return (a & 61440) === 32768
                    },
                    isDir: function(a) {
                        return (a & 61440) === 16384
                    },
                    isLink: function(a) {
                        return (a & 61440) === 40960
                    },
                    isChrdev: function(a) {
                        return (a & 61440) === 8192
                    },
                    isBlkdev: function(a) {
                        return (a & 61440) === 24576
                    },
                    isFIFO: function(a) {
                        return (a & 61440) === 4096
                    },
                    isSocket: function(a) {
                        return (a & 49152) === 49152
                    },
                    flagModes: {
                        r: 0,
                        "r+": 2,
                        w: 577,
                        "w+": 578,
                        a: 1089,
                        "a+": 1090
                    },
                    modeStringToFlags: function(a) {
                        var b = K.flagModes[a];
                        if (typeof b === "undefined") throw new Error("Unknown file open mode: " + a);
                        return b
                    },
                    flagsToPermissionString: function(a) {
                        var b = ["r", "w", "rw"][a & 3];
                        a & 512 && (b += "w");
                        return b
                    },
                    nodePermissions: function(a, b) {
                        if (K.ignorePermissions) return 0;
                        if (b.includes("r") && !(a.mode & 292)) return 2;
                        else if (b.includes("w") && !(a.mode & 146)) return 2;
                        else if (b.includes("x") && !(a.mode & 73)) return 2;
                        return 0
                    },
                    mayLookup: function(a) {
                        var b = K.nodePermissions(a, "x");
                        if (b) return b;
                        return !a.node_ops.lookup ? 2 : 0
                    },
                    mayCreate: function(a, b) {
                        try {
                            K.lookupNode(a, b);
                            return 20
                        } catch (a) {}
                        return K.nodePermissions(a, "wx")
                    },
                    mayDelete: function(a, b, c) {
                        var d;
                        try {
                            d = K.lookupNode(a, b)
                        } catch (a) {
                            return a.errno
                        }
                        b = K.nodePermissions(a, "wx");
                        if (b) return b;
                        if (c) {
                            if (!K.isDir(d.mode)) return 54;
                            if (K.isRoot(d) || K.getPath(d) === K.cwd()) return 10
                        } else if (K.isDir(d.mode)) return 31;
                        return 0
                    },
                    mayOpen: function(a, b) {
                        if (!a) return 44;
                        if (K.isLink(a.mode)) return 32;
                        else if (K.isDir(a.mode) && (K.flagsToPermissionString(b) !== "r" || b & 512)) return 31;
                        return K.nodePermissions(a, K.flagsToPermissionString(b))
                    },
                    MAX_OPEN_FDS: 4096,
                    nextfd: function(a, b) {
                        a === void 0 && (a = 0);
                        b === void 0 && (b = K.MAX_OPEN_FDS);
                        for (a = a; a <= b; a++)
                            if (!K.streams[a]) return a;
                        throw new K.ErrnoError(33)
                    },
                    getStream: function(a) {
                        return K.streams[a]
                    },
                    createStream: function(a, b, c) {
                        K.FSStream || (K.FSStream = function() {}, K.FSStream.prototype = {
                            object: {
                                get: function() {
                                    return this.node
                                },
                                set: function(a) {
                                    this.node = a
                                }
                            },
                            isRead: {
                                get: function() {
                                    return (this.flags & 2097155) !== 1
                                }
                            },
                            isWrite: {
                                get: function() {
                                    return (this.flags & 2097155) !== 0
                                }
                            },
                            isAppend: {
                                get: function() {
                                    return this.flags & 1024
                                }
                            }
                        });
                        var d = new K.FSStream();
                        for (var e in a) d[e] = a[e];
                        a = d;
                        e = K.nextfd(b, c);
                        a.fd = e;
                        K.streams[e] = a;
                        return a
                    },
                    closeStream: function(a) {
                        K.streams[a] = null
                    },
                    chrdev_stream_ops: {
                        open: function(a) {
                            var b = K.getDevice(a.node.rdev);
                            a.stream_ops = b.stream_ops;
                            a.stream_ops.open && a.stream_ops.open(a)
                        },
                        llseek: function() {
                            throw new K.ErrnoError(70)
                        }
                    },
                    major: function(a) {
                        return a >> 8
                    },
                    minor: function(a) {
                        return a & 255
                    },
                    makedev: function(a, b) {
                        return a << 8 | b
                    },
                    registerDevice: function(a, b) {
                        K.devices[a] = {
                            stream_ops: b
                        }
                    },
                    getDevice: function(a) {
                        return K.devices[a]
                    },
                    getMounts: function(a) {
                        var b = [];
                        a = [a];
                        while (a.length) {
                            var c = a.pop();
                            b.push(c);
                            a.push.apply(a, c.mounts)
                        }
                        return b
                    },
                    syncfs: function(a, b) {
                        typeof a === "function" && (b = a, a = !1);
                        K.syncFSRequests++;
                        K.syncFSRequests > 1 && q("warning: " + K.syncFSRequests + " FS.syncfs operations in flight at once, probably just doing extra work");
                        var c = K.getMounts(K.root.mount),
                            d = 0;

                        function e(a) {
                            K.syncFSRequests--;
                            return b(a)
                        }

                        function f(a) {
                            if (a) {
                                if (!f.errored) {
                                    f.errored = !0;
                                    return e(a)
                                }
                                return
                            }++d >= c.length && e(null)
                        }
                        c.forEach(function(b) {
                            if (!b.type.syncfs) return f(null);
                            b.type.syncfs(b, a, f)
                        })
                    },
                    mount: function(a, b, c) {
                        var d = c === "/",
                            e = !c,
                            f;
                        if (d && K.root) throw new K.ErrnoError(10);
                        else if (!d && !e) {
                            e = K.lookupPath(c, {
                                follow_mount: !1
                            });
                            c = e.path;
                            f = e.node;
                            if (K.isMountpoint(f)) throw new K.ErrnoError(10);
                            if (!K.isDir(f.mode)) throw new K.ErrnoError(54)
                        }
                        e = {
                            type: a,
                            opts: b,
                            mountpoint: c,
                            mounts: []
                        };
                        b = a.mount(e);
                        b.mount = e;
                        e.root = b;
                        d ? K.root = b : f && (f.mounted = e, f.mount && f.mount.mounts.push(e));
                        return b
                    },
                    unmount: function(a) {
                        a = K.lookupPath(a, {
                            follow_mount: !1
                        });
                        if (!K.isMountpoint(a.node)) throw new K.ErrnoError(28);
                        a = a.node;
                        var b = a.mounted,
                            c = K.getMounts(b);
                        Object.keys(K.nameTable).forEach(function(a) {
                            a = K.nameTable[a];
                            while (a) {
                                var b = a.name_next;
                                c.includes(a.mount) && K.destroyNode(a);
                                a = b
                            }
                        });
                        a.mounted = null;
                        b = a.mount.mounts.indexOf(b);
                        a.mount.mounts.splice(b, 1)
                    },
                    lookup: function(a, b) {
                        return a.node_ops.lookup(a, b)
                    },
                    mknod: function(a, b, c) {
                        var d = K.lookupPath(a, {
                            parent: !0
                        });
                        d = d.node;
                        a = G.basename(a);
                        if (!a || a === "." || a === "..") throw new K.ErrnoError(28);
                        var e = K.mayCreate(d, a);
                        if (e) throw new K.ErrnoError(e);
                        if (!d.node_ops.mknod) throw new K.ErrnoError(63);
                        return d.node_ops.mknod(d, a, b, c)
                    },
                    create: function(a, b) {
                        b = b !== void 0 ? b : 438;
                        b &= 4095;
                        b |= 32768;
                        return K.mknod(a, b, 0)
                    },
                    mkdir: function(a, b) {
                        b = b !== void 0 ? b : 511;
                        b &= 511 | 512;
                        b |= 16384;
                        return K.mknod(a, b, 0)
                    },
                    mkdirTree: function(a, b) {
                        a = a.split("/");
                        var c = "";
                        for (var d = 0; d < a.length; ++d) {
                            if (!a[d]) continue;
                            c += "/" + a[d];
                            try {
                                K.mkdir(c, b)
                            } catch (a) {
                                if (a.errno != 20) throw a
                            }
                        }
                    },
                    mkdev: function(a, b, c) {
                        typeof c === "undefined" && (c = b, b = 438);
                        b |= 8192;
                        return K.mknod(a, b, c)
                    },
                    symlink: function(a, b) {
                        if (!H.resolve(a)) throw new K.ErrnoError(44);
                        var c = K.lookupPath(b, {
                            parent: !0
                        });
                        c = c.node;
                        if (!c) throw new K.ErrnoError(44);
                        b = G.basename(b);
                        var d = K.mayCreate(c, b);
                        if (d) throw new K.ErrnoError(d);
                        if (!c.node_ops.symlink) throw new K.ErrnoError(63);
                        return c.node_ops.symlink(c, b, a)
                    },
                    rename: function(a, b) {
                        var c = G.dirname(a),
                            d = G.dirname(b),
                            e = G.basename(a),
                            f = G.basename(b),
                            g, h;
                        g = K.lookupPath(a, {
                            parent: !0
                        });
                        h = g.node;
                        g = K.lookupPath(b, {
                            parent: !0
                        });
                        g = g.node;
                        if (!h || !g) throw new K.ErrnoError(44);
                        if (h.mount !== g.mount) throw new K.ErrnoError(75);
                        var i = K.lookupNode(h, e);
                        a = H.relative(a, d);
                        if (a.charAt(0) !== ".") throw new K.ErrnoError(28);
                        a = H.relative(b, c);
                        if (a.charAt(0) !== ".") throw new K.ErrnoError(55);
                        var j;
                        try {
                            j = K.lookupNode(g, f)
                        } catch (a) {}
                        if (i === j) return;
                        d = K.isDir(i.mode);
                        b = K.mayDelete(h, e, d);
                        if (b) throw new K.ErrnoError(b);
                        b = j ? K.mayDelete(g, f, d) : K.mayCreate(g, f);
                        if (b) throw new K.ErrnoError(b);
                        if (!h.node_ops.rename) throw new K.ErrnoError(63);
                        if (K.isMountpoint(i) || j && K.isMountpoint(j)) throw new K.ErrnoError(10);
                        if (g !== h) {
                            b = K.nodePermissions(h, "w");
                            if (b) throw new K.ErrnoError(b)
                        }
                        K.hashRemoveNode(i);
                        try {
                            h.node_ops.rename(i, g, f)
                        } catch (a) {
                            throw a
                        } finally {
                            K.hashAddNode(i)
                        }
                    },
                    rmdir: function(a) {
                        var b = K.lookupPath(a, {
                            parent: !0
                        });
                        b = b.node;
                        a = G.basename(a);
                        var c = K.lookupNode(b, a),
                            d = K.mayDelete(b, a, !0);
                        if (d) throw new K.ErrnoError(d);
                        if (!b.node_ops.rmdir) throw new K.ErrnoError(63);
                        if (K.isMountpoint(c)) throw new K.ErrnoError(10);
                        b.node_ops.rmdir(b, a);
                        K.destroyNode(c)
                    },
                    readdir: function(a) {
                        a = K.lookupPath(a, {
                            follow: !0
                        });
                        a = a.node;
                        if (!a.node_ops.readdir) throw new K.ErrnoError(54);
                        return a.node_ops.readdir(a)
                    },
                    unlink: function(a) {
                        var b = K.lookupPath(a, {
                            parent: !0
                        });
                        b = b.node;
                        if (!b) throw new K.ErrnoError(44);
                        a = G.basename(a);
                        var c = K.lookupNode(b, a),
                            d = K.mayDelete(b, a, !1);
                        if (d) throw new K.ErrnoError(d);
                        if (!b.node_ops.unlink) throw new K.ErrnoError(63);
                        if (K.isMountpoint(c)) throw new K.ErrnoError(10);
                        b.node_ops.unlink(b, a);
                        K.destroyNode(c)
                    },
                    readlink: function(a) {
                        a = K.lookupPath(a);
                        a = a.node;
                        if (!a) throw new K.ErrnoError(44);
                        if (!a.node_ops.readlink) throw new K.ErrnoError(28);
                        return H.resolve(K.getPath(a.parent), a.node_ops.readlink(a))
                    },
                    stat: function(a, b) {
                        a = K.lookupPath(a, {
                            follow: !b
                        });
                        b = a.node;
                        if (!b) throw new K.ErrnoError(44);
                        if (!b.node_ops.getattr) throw new K.ErrnoError(63);
                        return b.node_ops.getattr(b)
                    },
                    lstat: function(a) {
                        return K.stat(a, !0)
                    },
                    chmod: function(a, b, c) {
                        if (typeof a === "string") {
                            c = K.lookupPath(a, {
                                follow: !c
                            });
                            c = c.node
                        } else c = a;
                        if (!c.node_ops.setattr) throw new K.ErrnoError(63);
                        c.node_ops.setattr(c, {
                            mode: b & 4095 | c.mode & -4096,
                            timestamp: Date.now()
                        })
                    },
                    lchmod: function(a, b) {
                        K.chmod(a, b, !0)
                    },
                    fchmod: function(a, b) {
                        a = K.getStream(a);
                        if (!a) throw new K.ErrnoError(8);
                        K.chmod(a.node, b)
                    },
                    chown: function(a, b, c, d) {
                        if (typeof a === "string") {
                            b = K.lookupPath(a, {
                                follow: !d
                            });
                            c = b.node
                        } else c = a;
                        if (!c.node_ops.setattr) throw new K.ErrnoError(63);
                        c.node_ops.setattr(c, {
                            timestamp: Date.now()
                        })
                    },
                    lchown: function(a, b, c) {
                        K.chown(a, b, c, !0)
                    },
                    fchown: function(a, b, c) {
                        a = K.getStream(a);
                        if (!a) throw new K.ErrnoError(8);
                        K.chown(a.node, b, c)
                    },
                    truncate: function(a, b) {
                        if (b < 0) throw new K.ErrnoError(28);
                        if (typeof a === "string") {
                            var c = K.lookupPath(a, {
                                follow: !0
                            });
                            c = c.node
                        } else c = a;
                        if (!c.node_ops.setattr) throw new K.ErrnoError(63);
                        if (K.isDir(c.mode)) throw new K.ErrnoError(31);
                        if (!K.isFile(c.mode)) throw new K.ErrnoError(28);
                        a = K.nodePermissions(c, "w");
                        if (a) throw new K.ErrnoError(a);
                        c.node_ops.setattr(c, {
                            size: b,
                            timestamp: Date.now()
                        })
                    },
                    ftruncate: function(a, b) {
                        a = K.getStream(a);
                        if (!a) throw new K.ErrnoError(8);
                        if ((a.flags & 2097155) === 0) throw new K.ErrnoError(28);
                        K.truncate(a.node, b)
                    },
                    utime: function(a, b, c) {
                        a = K.lookupPath(a, {
                            follow: !0
                        });
                        a = a.node;
                        a.node_ops.setattr(a, {
                            timestamp: Math.max(b, c)
                        })
                    },
                    open: function(a, b, d, e, f) {
                        if (a === "") throw new K.ErrnoError(44);
                        b = typeof b === "string" ? K.modeStringToFlags(b) : b;
                        d = typeof d === "undefined" ? 438 : d;
                        b & 64 ? d = d & 4095 | 32768 : d = 0;
                        var g;
                        if (typeof a === "object") g = a;
                        else {
                            a = G.normalize(a);
                            try {
                                var h = K.lookupPath(a, {
                                    follow: !(b & 131072)
                                });
                                g = h.node
                            } catch (a) {}
                        }
                        h = !1;
                        if (b & 64)
                            if (g) {
                                if (b & 128) throw new K.ErrnoError(20)
                            } else g = K.mknod(a, d, 0), h = !0;
                        if (!g) throw new K.ErrnoError(44);
                        K.isChrdev(g.mode) && (b &= -513);
                        if (b & 65536 && !K.isDir(g.mode)) throw new K.ErrnoError(54);
                        if (!h) {
                            d = K.mayOpen(g, b);
                            if (d) throw new K.ErrnoError(d)
                        }
                        b & 512 && K.truncate(g, 0);
                        b &= ~(128 | 512 | 131072);
                        h = K.createStream({
                            node: g,
                            path: K.getPath(g),
                            flags: b,
                            seekable: !0,
                            position: 0,
                            stream_ops: g.stream_ops,
                            ungotten: [],
                            error: !1
                        }, e, f);
                        h.stream_ops.open && h.stream_ops.open(h);
                        c.logReadFiles && !(b & 1) && (K.readFiles || (K.readFiles = {}), a in K.readFiles || (K.readFiles[a] = 1));
                        return h
                    },
                    close: function(a) {
                        if (K.isClosed(a)) throw new K.ErrnoError(8);
                        a.getdents && (a.getdents = null);
                        try {
                            a.stream_ops.close && a.stream_ops.close(a)
                        } catch (a) {
                            throw a
                        } finally {
                            K.closeStream(a.fd)
                        }
                        a.fd = null
                    },
                    isClosed: function(a) {
                        return a.fd === null
                    },
                    llseek: function(a, b, c) {
                        if (K.isClosed(a)) throw new K.ErrnoError(8);
                        if (!a.seekable || !a.stream_ops.llseek) throw new K.ErrnoError(70);
                        if (c != 0 && c != 1 && c != 2) throw new K.ErrnoError(28);
                        a.position = a.stream_ops.llseek(a, b, c);
                        a.ungotten = [];
                        return a.position
                    },
                    read: function(b, a, c, d, e) {
                        if (d < 0 || e < 0) throw new K.ErrnoError(28);
                        if (K.isClosed(b)) throw new K.ErrnoError(8);
                        if ((b.flags & 2097155) === 1) throw new K.ErrnoError(8);
                        if (K.isDir(b.node.mode)) throw new K.ErrnoError(31);
                        if (!b.stream_ops.read) throw new K.ErrnoError(28);
                        var f = typeof e !== "undefined";
                        if (!f) e = b.position;
                        else if (!b.seekable) throw new K.ErrnoError(70);
                        a = b.stream_ops.read(b, a, c, d, e);
                        f || (b.position += a);
                        return a
                    },
                    write: function(b, a, c, d, e, f) {
                        if (d < 0 || e < 0) throw new K.ErrnoError(28);
                        if (K.isClosed(b)) throw new K.ErrnoError(8);
                        if ((b.flags & 2097155) === 0) throw new K.ErrnoError(8);
                        if (K.isDir(b.node.mode)) throw new K.ErrnoError(31);
                        if (!b.stream_ops.write) throw new K.ErrnoError(28);
                        b.seekable && b.flags & 1024 && K.llseek(b, 0, 2);
                        var g = typeof e !== "undefined";
                        if (!g) e = b.position;
                        else if (!b.seekable) throw new K.ErrnoError(70);
                        a = b.stream_ops.write(b, a, c, d, e, f);
                        g || (b.position += a);
                        return a
                    },
                    allocate: function(a, b, c) {
                        if (K.isClosed(a)) throw new K.ErrnoError(8);
                        if (b < 0 || c <= 0) throw new K.ErrnoError(28);
                        if ((a.flags & 2097155) === 0) throw new K.ErrnoError(8);
                        if (!K.isFile(a.node.mode) && !K.isDir(a.node.mode)) throw new K.ErrnoError(43);
                        if (!a.stream_ops.allocate) throw new K.ErrnoError(138);
                        a.stream_ops.allocate(a, b, c)
                    },
                    mmap: function(a, b, c, d, e, f) {
                        if ((e & 2) !== 0 && (f & 2) === 0 && (a.flags & 2097155) !== 2) throw new K.ErrnoError(2);
                        if ((a.flags & 2097155) === 1) throw new K.ErrnoError(2);
                        if (!a.stream_ops.mmap) throw new K.ErrnoError(43);
                        return a.stream_ops.mmap(a, b, c, d, e, f)
                    },
                    msync: function(b, a, c, d, e) {
                        return !b || !b.stream_ops.msync ? 0 : b.stream_ops.msync(b, a, c, d, e)
                    },
                    munmap: function(a) {
                        return 0
                    },
                    ioctl: function(a, b, c) {
                        if (!a.stream_ops.ioctl) throw new K.ErrnoError(59);
                        return a.stream_ops.ioctl(a, b, c)
                    },
                    readFile: function(a, b) {
                        b === void 0 && (b = {});
                        b.flags = b.flags || 0;
                        b.encoding = b.encoding || "binary";
                        if (b.encoding !== "utf8" && b.encoding !== "binary") throw new Error('Invalid encoding type "' + b.encoding + '"');
                        var c, d = K.open(a, b.flags);
                        a = K.stat(a);
                        a = a.size;
                        var e = new Uint8Array(a);
                        K.read(d, e, 0, a, 0);
                        b.encoding === "utf8" ? c = t(e, 0) : b.encoding === "binary" && (c = e);
                        K.close(d);
                        return c
                    },
                    writeFile: function(a, b, c) {
                        c === void 0 && (c = {});
                        c.flags = c.flags || 577;
                        a = K.open(a, c.flags, c.mode);
                        if (typeof b === "string") {
                            var d = new Uint8Array(oa(b) + 1),
                                e = ma(b, d, 0, d.length);
                            K.write(a, d, 0, e, void 0, c.canOwn)
                        } else if (ArrayBuffer.isView(b)) K.write(a, b, 0, b.byteLength, void 0, c.canOwn);
                        else throw new Error("Unsupported data type");
                        K.close(a)
                    },
                    cwd: function() {
                        return K.currentPath
                    },
                    chdir: function(a) {
                        a = K.lookupPath(a, {
                            follow: !0
                        });
                        if (a.node === null) throw new K.ErrnoError(44);
                        if (!K.isDir(a.node.mode)) throw new K.ErrnoError(54);
                        var b = K.nodePermissions(a.node, "x");
                        if (b) throw new K.ErrnoError(b);
                        K.currentPath = a.path
                    },
                    createDefaultDirectories: function() {
                        K.mkdir("/tmp"), K.mkdir("/home"), K.mkdir("/home/web_user")
                    },
                    createDefaultDevices: function() {
                        K.mkdir("/dev");
                        K.registerDevice(K.makedev(1, 3), {
                            read: function() {
                                return 0
                            },
                            write: function(b, a, c, d, e) {
                                return d
                            }
                        });
                        K.mkdev("/dev/null", K.makedev(1, 3));
                        I.register(K.makedev(5, 0), I.default_tty_ops);
                        I.register(K.makedev(6, 0), I.default_tty1_ops);
                        K.mkdev("/dev/tty", K.makedev(5, 0));
                        K.mkdev("/dev/tty1", K.makedev(6, 0));
                        var a = nb();
                        K.createDevice("/dev", "random", a);
                        K.createDevice("/dev", "urandom", a);
                        K.mkdir("/dev/shm");
                        K.mkdir("/dev/shm/tmp")
                    },
                    createSpecialDirectories: function() {
                        K.mkdir("/proc");
                        var a = K.mkdir("/proc/self");
                        K.mkdir("/proc/self/fd");
                        K.mount({
                            mount: function() {
                                var b = K.createNode(a, "fd", 16384 | 511, 73);
                                b.node_ops = {
                                    lookup: function(a, b) {
                                        a = +b;
                                        var c = K.getStream(a);
                                        if (!c) throw new K.ErrnoError(8);
                                        b = {
                                            parent: null,
                                            mount: {
                                                mountpoint: "fake"
                                            },
                                            node_ops: {
                                                readlink: function() {
                                                    return c.path
                                                }
                                            }
                                        };
                                        b.parent = b;
                                        return b
                                    }
                                };
                                return b
                            }
                        }, {}, "/proc/self/fd")
                    },
                    createStandardStreams: function() {
                        c.stdin ? K.createDevice("/dev", "stdin", c.stdin) : K.symlink("/dev/tty", "/dev/stdin"), c.stdout ? K.createDevice("/dev", "stdout", null, c.stdout) : K.symlink("/dev/tty", "/dev/stdout"), c.stderr ? K.createDevice("/dev", "stderr", null, c.stderr) : K.symlink("/dev/tty1", "/dev/stderr"), K.open("/dev/stdin", 0), K.open("/dev/stdout", 1), K.open("/dev/stderr", 1)
                    },
                    ensureErrnoError: function() {
                        if (K.ErrnoError) return;
                        K.ErrnoError = function(a, b) {
                            this.node = b, this.setErrno = function(a) {
                                this.errno = a
                            }, this.setErrno(a), this.message = "FS error"
                        };
                        K.ErrnoError.prototype = new Error();
                        K.ErrnoError.prototype.constructor = K.ErrnoError;
                        [44].forEach(function(a) {
                            K.genericErrors[a] = new K.ErrnoError(a), K.genericErrors[a].stack = "<generic error, no stack>"
                        })
                    },
                    staticInit: function() {
                        K.ensureErrnoError(), K.nameTable = new Array(4096), K.mount(J, {}, "/"), K.createDefaultDirectories(), K.createDefaultDevices(), K.createSpecialDirectories(), K.filesystems = {
                            MEMFS: J
                        }
                    },
                    init: function(a, b, d) {
                        K.init.initialized = !0, K.ensureErrnoError(), c.stdin = a || c.stdin, c.stdout = b || c.stdout, c.stderr = d || c.stderr, K.createStandardStreams()
                    },
                    quit: function() {
                        K.init.initialized = !1;
                        for (var a = 0; a < K.streams.length; a++) {
                            var b = K.streams[a];
                            if (!b) continue;
                            K.close(b)
                        }
                    },
                    getMode: function(a, b) {
                        var c = 0;
                        a && (c |= 292 | 73);
                        b && (c |= 146);
                        return c
                    },
                    findObject: function(a, b) {
                        a = K.analyzePath(a, b);
                        if (a.exists) return a.object;
                        else return null
                    },
                    analyzePath: function(a, b) {
                        try {
                            var c = K.lookupPath(a, {
                                follow: !b
                            });
                            a = c.path
                        } catch (a) {}
                        var d = {
                            isRoot: !1,
                            exists: !1,
                            error: 0,
                            name: null,
                            path: null,
                            object: null,
                            parentExists: !1,
                            parentPath: null,
                            parentObject: null
                        };
                        try {
                            var c = K.lookupPath(a, {
                                parent: !0
                            });
                            d.parentExists = !0;
                            d.parentPath = c.path;
                            d.parentObject = c.node;
                            d.name = G.basename(a);
                            c = K.lookupPath(a, {
                                follow: !b
                            });
                            d.exists = !0;
                            d.path = c.path;
                            d.object = c.node;
                            d.name = c.node.name;
                            d.isRoot = c.path === "/"
                        } catch (a) {
                            d.error = a.errno
                        }
                        return d
                    },
                    createPath: function(a, b, c, d) {
                        a = typeof a === "string" ? a : K.getPath(a);
                        c = b.split("/").reverse();
                        while (c.length) {
                            d = c.pop();
                            if (!d) continue;
                            var e = G.join2(a, d);
                            try {
                                K.mkdir(e)
                            } catch (a) {}
                            a = e
                        }
                        return e
                    },
                    createFile: function(a, b, c, d, e) {
                        c = G.join2(typeof a === "string" ? a : K.getPath(a), b);
                        a = K.getMode(d, e);
                        return K.create(c, a)
                    },
                    createDataFile: function(a, b, c, d, e, f) {
                        var g = b;
                        a && (a = typeof a === "string" ? a : K.getPath(a), g = b ? G.join2(a, b) : a);
                        b = K.getMode(d, e);
                        a = K.create(g, b);
                        if (c) {
                            if (typeof c === "string") {
                                d = new Array(c.length);
                                for (e = 0, g = c.length; e < g; ++e) d[e] = c.charCodeAt(e);
                                c = d
                            }
                            K.chmod(a, b | 146);
                            e = K.open(a, 577);
                            K.write(e, c, 0, c.length, 0, f);
                            K.close(e);
                            K.chmod(a, b)
                        }
                        return a
                    },
                    createDevice: function(a, b, c, d) {
                        a = G.join2(typeof a === "string" ? a : K.getPath(a), b);
                        b = K.getMode(!!c, !!d);
                        K.createDevice.major || (K.createDevice.major = 64);
                        var e = K.makedev(K.createDevice.major++, 0);
                        K.registerDevice(e, {
                            open: function(a) {
                                a.seekable = !1
                            },
                            close: function(a) {
                                d && d.buffer && d.buffer.length && d(10)
                            },
                            read: function(b, a, d, e, f) {
                                f = 0;
                                for (var g = 0; g < e; g++) {
                                    var h;
                                    try {
                                        h = c()
                                    } catch (a) {
                                        throw new K.ErrnoError(29)
                                    }
                                    if (h === void 0 && f === 0) throw new K.ErrnoError(6);
                                    if (h === null || h === void 0) break;
                                    f++;
                                    a[d + g] = h
                                }
                                f && (b.node.timestamp = Date.now());
                                return f
                            },
                            write: function(b, a, c, e, f) {
                                for (f = 0; f < e; f++) try {
                                    d(a[c + f])
                                } catch (a) {
                                    throw new K.ErrnoError(29)
                                }
                                e && (b.node.timestamp = Date.now());
                                return f
                            }
                        });
                        return K.mkdev(a, b, e)
                    },
                    forceLoadFile: function(a) {
                        if (a.isDevice || a.isFolder || a.link || a.contents) return !0;
                        if (typeof XMLHttpRequest !== "undefined") throw new Error("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");
                        else if (ba) try {
                            a.contents = ud(ba(a.url), !0), a.usedBytes = a.contents.length
                        } catch (a) {
                            throw new K.ErrnoError(29)
                        } else throw new Error("Cannot load without read() or XMLHttpRequest.")
                    },
                    createLazyFile: function(a, b, c, d, e) {
                        function f() {
                            this.lengthKnown = !1, this.chunks = []
                        }
                        f.prototype.get = function(a) {
                            if (a > this.length - 1 || a < 0) return void 0;
                            var b = a % this.chunkSize;
                            a = a / this.chunkSize | 0;
                            return this.getter(a)[b]
                        };
                        f.prototype.setDataGetter = function(a) {
                            this.getter = a
                        };
                        f.prototype.cacheLength = function() {
                            var a = new XMLHttpRequest();
                            a.open("HEAD", c, !1);
                            a.send(null);
                            if (!(a.status >= 200 && a.status < 300 || a.status === 304)) throw new Error("Couldn't load " + c + ". Status: " + a.status);
                            var b = Number(a.getResponseHeader("Content-length")),
                                d, e = (d = a.getResponseHeader("Accept-Ranges")) && d === "bytes";
                            a = (d = a.getResponseHeader("Content-Encoding")) && d === "gzip";
                            var f = 1024 * 1024;
                            e || (f = b);
                            var g = function(d, e) {
                                    if (d > e) throw new Error("invalid range (" + d + ", " + e + ") or no bytes requested!");
                                    if (e > b - 1) throw new Error("only " + b + " bytes available! programmer error!");
                                    var a = new XMLHttpRequest();
                                    a.open("GET", c, !1);
                                    b !== f && a.setRequestHeader("Range", "bytes=" + d + "-" + e);
                                    typeof Uint8Array != "undefined" && (a.responseType = "arraybuffer");
                                    a.overrideMimeType && a.overrideMimeType("text/plain; charset=x-user-defined");
                                    a.send(null);
                                    if (!(a.status >= 200 && a.status < 300 || a.status === 304)) throw new Error("Couldn't load " + c + ". Status: " + a.status);
                                    if (a.response !== void 0) return new Uint8Array(a.response || []);
                                    else return ud(a.responseText || "", !0)
                                },
                                h = this;
                            h.setDataGetter(function(a) {
                                var c = a * f,
                                    d = (a + 1) * f - 1;
                                d = Math.min(d, b - 1);
                                typeof h.chunks[a] === "undefined" && (h.chunks[a] = g(c, d));
                                if (typeof h.chunks[a] === "undefined") throw new Error("doXHR failed!");
                                return h.chunks[a]
                            });
                            (a || !b) && (f = b = 1, b = this.getter(0).length, f = b, ea("LazyFiles on gzip forces download of the whole file when length is accessed"));
                            this._length = b;
                            this._chunkSize = f;
                            this.lengthKnown = !0
                        };
                        if (typeof XMLHttpRequest !== "undefined") {
                            if (!o) throw "Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc";
                            f = new f();
                            Object.defineProperties(f, {
                                length: {
                                    get: function() {
                                        this.lengthKnown || this.cacheLength();
                                        return this._length
                                    }
                                },
                                chunkSize: {
                                    get: function() {
                                        this.lengthKnown || this.cacheLength();
                                        return this._chunkSize
                                    }
                                }
                            });
                            f = {
                                isDevice: !1,
                                contents: f
                            }
                        } else var f = {
                            isDevice: !1,
                            url: c
                        };
                        var g = K.createFile(a, b, f, d, e);
                        f.contents ? g.contents = f.contents : f.url && (g.contents = null, g.url = f.url);
                        Object.defineProperties(g, {
                            usedBytes: {
                                get: function() {
                                    return this.contents.length
                                }
                            }
                        });
                        var h = {};
                        a = Object.keys(g.stream_ops);
                        a.forEach(function(a) {
                            var b = g.stream_ops[a];
                            h[a] = function() {
                                K.forceLoadFile(g);
                                return b.apply(null, arguments)
                            }
                        });
                        h.read = function(b, a, c, d, e) {
                            K.forceLoadFile(g);
                            b = b.node.contents;
                            if (e >= b.length) return 0;
                            d = Math.min(b.length - e, d);
                            if (b.slice)
                                for (var f = 0; f < d; f++) a[c + f] = b[e + f];
                            else
                                for (var f = 0; f < d; f++) a[c + f] = b.get(e + f);
                            return d
                        };
                        g.stream_ops = h;
                        return g
                    },
                    createPreloadedFile: function(a, b, c, d, e, f, g, h, i, j) {
                        var k = b ? H.resolve(G.join2(a, b)) : a,
                            l = Pa("cp " + k);

                        function m(c) {
                            function m(c) {
                                j && j(), h || K.createDataFile(a, b, c, d, e, i), f && f(), Ra(l)
                            }
                            if (Browser.handledByPreloadPlugin(c, k, m, function() {
                                    g && g(), Ra(l)
                                })) return;
                            m(c)
                        }
                        Qa(l);
                        typeof c == "string" ? pb(c, function(a) {
                            return m(a)
                        }, g) : m(c)
                    },
                    indexedDB: function() {
                        return window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB
                    },
                    DB_NAME: function() {
                        return "EM_FS_" + window.location.pathname
                    },
                    DB_VERSION: 20,
                    DB_STORE_NAME: "FILE_DATA",
                    saveFilesToDB: function(a, b, c) {
                        b = b || function() {};
                        c = c || function() {};
                        var d = K.indexedDB();
                        try {
                            var e = d.open(K.DB_NAME(), K.DB_VERSION)
                        } catch (a) {
                            return c(a)
                        }
                        e.onupgradeneeded = function() {
                            ea("creating db");
                            var a = e.result;
                            a.createObjectStore(K.DB_STORE_NAME)
                        };
                        e.onsuccess = function() {
                            var d = e.result;
                            d = d.transaction([K.DB_STORE_NAME], "readwrite");
                            var f = d.objectStore(K.DB_STORE_NAME),
                                g = 0,
                                h = 0,
                                i = a.length;

                            function j() {
                                h == 0 ? b() : c()
                            }
                            a.forEach(function(a) {
                                a = f.put(K.analyzePath(a).object.contents, a);
                                a.onsuccess = function() {
                                    g++, g + h == i && j()
                                };
                                a.onerror = function() {
                                    h++, g + h == i && j()
                                }
                            });
                            d.onerror = c
                        };
                        e.onerror = c
                    },
                    loadFilesFromDB: function(a, b, c) {
                        b = b || function() {};
                        c = c || function() {};
                        var d = K.indexedDB();
                        try {
                            var e = d.open(K.DB_NAME(), K.DB_VERSION)
                        } catch (a) {
                            return c(a)
                        }
                        e.onupgradeneeded = c;
                        e.onsuccess = function() {
                            var d = e.result;
                            try {
                                var f = d.transaction([K.DB_STORE_NAME], "readonly")
                            } catch (a) {
                                c(a);
                                return
                            }
                            var g = f.objectStore(K.DB_STORE_NAME),
                                h = 0,
                                i = 0,
                                j = a.length;

                            function k() {
                                i == 0 ? b() : c()
                            }
                            a.forEach(function(a) {
                                var b = g.get(a);
                                b.onsuccess = function() {
                                    K.analyzePath(a).exists && K.unlink(a), K.createDataFile(G.dirname(a), G.basename(a), b.result, !0, !0, !0), h++, h + i == j && k()
                                };
                                b.onerror = function() {
                                    i++, h + i == j && k()
                                }
                            });
                            f.onerror = c
                        };
                        e.onerror = c
                    }
                },
                L = {
                    mappings: {},
                    DEFAULT_POLLMASK: 5,
                    calculateAt: function(a, b, c) {
                        if (b[0] === "/") return b;
                        var d;
                        if (a === -100) d = K.cwd();
                        else {
                            a = K.getStream(a);
                            if (!a) throw new K.ErrnoError(8);
                            d = a.path
                        }
                        if (b.length == 0) {
                            if (!c) throw new K.ErrnoError(44);
                            return d
                        }
                        return G.join2(d, b)
                    },
                    doStat: function(a, b, c) {
                        try {
                            var d = a(b)
                        } catch (a) {
                            if (a && a.node && G.normalize(b) !== G.normalize(K.getPath(a.node))) return -54;
                            throw a
                        }
                        x[c >> 2] = d.dev;
                        x[c + 4 >> 2] = 0;
                        x[c + 8 >> 2] = d.ino;
                        x[c + 12 >> 2] = d.mode;
                        x[c + 16 >> 2] = d.nlink;
                        x[c + 20 >> 2] = d.uid;
                        x[c + 24 >> 2] = d.gid;
                        x[c + 28 >> 2] = d.rdev;
                        x[c + 32 >> 2] = 0;
                        D = [d.size >>> 0, (C = d.size, +Math.abs(C) >= 1 ? C > 0 ? (Math.min(+Math.floor(C / 4294967296), 4294967295) | 0) >>> 0 : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0 : 0)], x[c + 40 >> 2] = D[0], x[c + 44 >> 2] = D[1];
                        x[c + 48 >> 2] = 4096;
                        x[c + 52 >> 2] = d.blocks;
                        x[c + 56 >> 2] = d.atime.getTime() / 1e3 | 0;
                        x[c + 60 >> 2] = 0;
                        x[c + 64 >> 2] = d.mtime.getTime() / 1e3 | 0;
                        x[c + 68 >> 2] = 0;
                        x[c + 72 >> 2] = d.ctime.getTime() / 1e3 | 0;
                        x[c + 76 >> 2] = 0;
                        D = [d.ino >>> 0, (C = d.ino, +Math.abs(C) >= 1 ? C > 0 ? (Math.min(+Math.floor(C / 4294967296), 4294967295) | 0) >>> 0 : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0 : 0)], x[c + 80 >> 2] = D[0], x[c + 84 >> 2] = D[1];
                        return 0
                    },
                    doMsync: function(a, b, c, d, e) {
                        a = v.slice(a, a + c);
                        K.msync(b, a, e, c, d)
                    },
                    doMkdir: function(a, b) {
                        a = G.normalize(a);
                        a[a.length - 1] === "/" && (a = a.substr(0, a.length - 1));
                        K.mkdir(a, b, 0);
                        return 0
                    },
                    doMknod: function(a, b, c) {
                        switch (b & 61440) {
                            case 32768:
                            case 8192:
                            case 24576:
                            case 4096:
                            case 49152:
                                break;
                            default:
                                return -28
                        }
                        K.mknod(a, b, c);
                        return 0
                    },
                    doReadlink: function(a, b, c) {
                        if (c <= 0) return -28;
                        a = K.readlink(a);
                        var d = Math.min(c, oa(a)),
                            e = u[b + d];
                        na(a, b, c + 1);
                        u[b + d] = e;
                        return d
                    },
                    doAccess: function(a, b) {
                        if (b & -8) return -28;
                        a = K.lookupPath(a, {
                            follow: !0
                        });
                        a = a.node;
                        if (!a) return -44;
                        var c = "";
                        b & 4 && (c += "r");
                        b & 2 && (c += "w");
                        b & 1 && (c += "x");
                        return c && K.nodePermissions(a, c) ? -2 : 0
                    },
                    doDup: function(a, b, c) {
                        var d = K.getStream(c);
                        d && K.close(d);
                        return K.open(a, b, 0, c, c).fd
                    },
                    doReadv: function(a, b, c, d) {
                        var e = 0;
                        for (var f = 0; f < c; f++) {
                            var g = x[b + f * 8 >> 2],
                                h = x[b + (f * 8 + 4) >> 2];
                            g = K.read(a, u, g, h, d);
                            if (g < 0) return -1;
                            e += g;
                            if (g < h) break
                        }
                        return e
                    },
                    doWritev: function(a, b, c, d) {
                        var e = 0;
                        for (var f = 0; f < c; f++) {
                            var g = x[b + f * 8 >> 2],
                                h = x[b + (f * 8 + 4) >> 2];
                            g = K.write(a, u, g, h, d);
                            if (g < 0) return -1;
                            e += g
                        }
                        return e
                    },
                    varargs: void 0,
                    get: function() {
                        L.varargs += 4;
                        var a = x[L.varargs - 4 >> 2];
                        return a
                    },
                    getStr: function(a) {
                        a = la(a);
                        return a
                    },
                    getStreamFromFD: function(a) {
                        a = K.getStream(a);
                        if (!a) throw new K.ErrnoError(8);
                        return a
                    },
                    get64: function(a, b) {
                        return a
                    }
                };

            function qb(a, b) {
                try {
                    if (b === 0) return -28;
                    var c = K.cwd(),
                        d = oa(c);
                    if (b < d + 1) return -68;
                    na(c, a, b);
                    return a
                } catch (a) {
                    if (typeof K === "undefined" || !(a instanceof K.ErrnoError)) throw a;
                    return -a.errno
                }
            }

            function rb(a, b, c) {
                L.varargs = c;
                try {
                    a = L.getStr(a);
                    c = c ? L.get() : 0;
                    a = K.open(a, b, c);
                    return a.fd
                } catch (a) {
                    if (typeof K === "undefined" || !(a instanceof K.ErrnoError)) throw a;
                    return -a.errno
                }
            }

            function sb(a, b, c, d, e) {}

            function tb(a) {
                switch (a) {
                    case 1:
                        return 0;
                    case 2:
                        return 1;
                    case 4:
                        return 2;
                    case 8:
                        return 3;
                    default:
                        throw new TypeError("Unknown type size: " + a)
                }
            }

            function ub() {
                var a = new Array(256);
                for (var b = 0; b < 256; ++b) a[b] = String.fromCharCode(b);
                vb = a
            }
            var vb = void 0;

            function M(a) {
                var b = "";
                a = a;
                while (v[a]) b += vb[v[a++]];
                return b
            }
            var N = {},
                O = {},
                wb = {},
                xb = 48,
                yb = 57;

            function zb(a) {
                if (void 0 === a) return "_unknown";
                a = a.replace(/[^a-zA-Z0-9_]/g, "$");
                var b = a.charCodeAt(0);
                if (b >= xb && b <= yb) return "_" + a;
                else return a
            }

            function Ab(a, b) {
                zb(a);
                return function() {
                    return b.apply(this, arguments)
                }
            }

            function Bb(a, b) {
                var c = Ab(b, function(a) {
                    this.name = b;
                    this.message = a;
                    a = new Error(a).stack;
                    a !== void 0 && (this.stack = this.toString() + "\n" + a.replace(/^Error(:[^\n]*)?\n/, ""))
                });
                c.prototype = Object.create(a.prototype);
                c.prototype.constructor = c;
                c.prototype.toString = function() {
                    if (this.message === void 0) return this.name;
                    else return this.name + ": " + this.message
                };
                return c
            }
            var P = void 0;

            function Q(a) {
                throw new P(a)
            }
            var Cb = void 0;

            function Db(a) {
                throw new Cb(a)
            }

            function R(a, b, c) {
                a.forEach(function(a) {
                    wb[a] = b
                });

                function d(b) {
                    b = c(b);
                    b.length !== a.length && Db("Mismatched type converter count");
                    for (var d = 0; d < a.length; ++d) S(a[d], b[d])
                }
                var e = new Array(b.length),
                    f = [],
                    g = 0;
                b.forEach(function(a, b) {
                    Object.prototype.hasOwnProperty.call(O, a) ? e[b] = O[a] : (f.push(a), Object.prototype.hasOwnProperty.call(N, a) || (N[a] = []), N[a].push(function() {
                        e[b] = O[a], ++g, g === f.length && d(e)
                    }))
                });
                0 === f.length && d(e)
            }

            function S(a, b, c) {
                c === void 0 && (c = {});
                if (!("argPackAdvance" in b)) throw new TypeError("registerType registeredInstance requires argPackAdvance");
                var d = b.name;
                a || Q('type "' + d + '" must have a positive integer typeid pointer');
                if (Object.prototype.hasOwnProperty.call(O, a))
                    if (c.ignoreDuplicateRegistrations) return;
                    else Q("Cannot register type '" + d + "' twice");
                O[a] = b;
                delete wb[a];
                if (Object.prototype.hasOwnProperty.call(N, a)) {
                    c = N[a];
                    delete N[a];
                    c.forEach(function(a) {
                        a()
                    })
                }
            }

            function Eb(a, b, c, d, e) {
                var f = tb(c);
                b = M(b);
                S(a, {
                    name: b,
                    fromWireType: function(a) {
                        return !!a
                    },
                    toWireType: function(a, b) {
                        return b ? d : e
                    },
                    argPackAdvance: 8,
                    readValueFromPointer: function(a) {
                        var d;
                        if (c === 1) d = u;
                        else if (c === 2) d = w;
                        else if (c === 4) d = x;
                        else throw new TypeError("Unknown boolean type size: " + b);
                        return this.fromWireType(d[a >> f])
                    },
                    destructorFunction: null
                })
            }

            function Fb(a) {
                if (!(this instanceof T)) return !1;
                if (!(a instanceof T)) return !1;
                var b = this.$$.ptrType.registeredClass,
                    c = this.$$.ptr,
                    d = a.$$.ptrType.registeredClass;
                a = a.$$.ptr;
                while (b.baseClass) c = b.upcast(c), b = b.baseClass;
                while (d.baseClass) a = d.upcast(a), d = d.baseClass;
                return b === d && c === a
            }

            function Gb(a) {
                return {
                    count: a.count,
                    deleteScheduled: a.deleteScheduled,
                    preservePointerOnDelete: a.preservePointerOnDelete,
                    ptr: a.ptr,
                    ptrType: a.ptrType,
                    smartPtr: a.smartPtr,
                    smartPtrType: a.smartPtrType
                }
            }

            function Hb(a) {
                function b(a) {
                    return a.$$.ptrType.registeredClass.name
                }
                Q(b(a) + " instance already deleted")
            }
            var Ib = !1;

            function Jb(a) {}

            function Kb(a) {
                a.smartPtr ? a.smartPtrType.rawDestructor(a.smartPtr) : a.ptrType.registeredClass.rawDestructor(a.ptr)
            }

            function Lb(a) {
                a.count.value -= 1;
                var b = 0 === a.count.value;
                b && Kb(a)
            }

            function Mb(a) {
                if ("undefined" === typeof FinalizationGroup) {
                    Mb = function(a) {
                        return a
                    };
                    return a
                }
                Ib = new FinalizationGroup(function(a) {
                    for (var b = a.next(); !b.done; b = a.next()) {
                        var c = b.value;
                        c.ptr && Lb(c)
                    }
                });
                Mb = function(a) {
                    Ib.register(a, a.$$, a.$$);
                    return a
                };
                Jb = function(a) {
                    Ib.unregister(a.$$)
                };
                return Mb(a)
            }

            function Nb() {
                this.$$.ptr || Hb(this);
                if (this.$$.preservePointerOnDelete) {
                    this.$$.count.value += 1;
                    return this
                } else {
                    var a = Mb(Object.create(Object.getPrototypeOf(this), {
                        $$: {
                            value: Gb(this.$$)
                        }
                    }));
                    a.$$.count.value += 1;
                    a.$$.deleteScheduled = !1;
                    return a
                }
            }

            function Ob() {
                this.$$.ptr || Hb(this), this.$$.deleteScheduled && !this.$$.preservePointerOnDelete && Q("Object already scheduled for deletion"), Jb(this), Lb(this.$$), this.$$.preservePointerOnDelete || (this.$$.smartPtr = void 0, this.$$.ptr = void 0)
            }

            function Pb() {
                return !this.$$.ptr
            }
            var Qb = void 0,
                Rb = [];

            function Sb() {
                while (Rb.length) {
                    var a = Rb.pop();
                    a.$$.deleteScheduled = !1;
                    a["delete"]()
                }
            }

            function Tb() {
                this.$$.ptr || Hb(this);
                this.$$.deleteScheduled && !this.$$.preservePointerOnDelete && Q("Object already scheduled for deletion");
                Rb.push(this);
                Rb.length === 1 && Qb && Qb(Sb);
                this.$$.deleteScheduled = !0;
                return this
            }

            function Ub() {
                T.prototype.isAliasOf = Fb, T.prototype.clone = Nb, T.prototype["delete"] = Ob, T.prototype.isDeleted = Pb, T.prototype.deleteLater = Tb
            }

            function T() {}
            var Vb = {};

            function Wb(a, b, c) {
                if (void 0 === a[b].overloadTable) {
                    var d = a[b];
                    a[b] = function() {
                        Object.prototype.hasOwnProperty.call(a[b].overloadTable, arguments.length) || Q("Function '" + c + "' called with an invalid number of arguments (" + arguments.length + ") - expects one of (" + a[b].overloadTable + ")!");
                        return a[b].overloadTable[arguments.length].apply(this, arguments)
                    };
                    a[b].overloadTable = [];
                    a[b].overloadTable[d.argCount] = d
                }
            }

            function Xb(a, b, d) {
                Object.prototype.hasOwnProperty.call(c, a) ? ((void 0 === d || void 0 !== c[a].overloadTable && void 0 !== c[a].overloadTable[d]) && Q("Cannot register public name '" + a + "' twice"), Wb(c, a, a), Object.prototype.hasOwnProperty.call(c, d) && Q("Cannot register multiple overloads of a function with the same number of arguments (" + d + ")!"), c[a].overloadTable[d] = b) : (c[a] = b, void 0 !== d && (c[a].numArguments = d))
            }

            function Yb(a, b, c, d, e, f, g, h) {
                this.name = a, this.constructor = b, this.instancePrototype = c, this.rawDestructor = d, this.baseClass = e, this.getActualType = f, this.upcast = g, this.downcast = h, this.pureVirtualFunctions = []
            }

            function Zb(a, b, c) {
                while (b !== c) b.upcast || Q("Expected null or instance of " + c.name + ", got an instance of " + b.name), a = b.upcast(a), b = b.baseClass;
                return a
            }

            function $b(a, b) {
                if (b === null) {
                    this.isReference && Q("null is not a valid " + this.name);
                    return 0
                }
                b.$$ || Q('Cannot pass "' + Lc(b) + '" as a ' + this.name);
                b.$$.ptr || Q("Cannot pass deleted object as a pointer of type " + this.name);
                a = b.$$.ptrType.registeredClass;
                b = Zb(b.$$.ptr, a, this.registeredClass);
                return b
            }

            function ac(a, b) {
                var c;
                if (b === null) {
                    this.isReference && Q("null is not a valid " + this.name);
                    if (this.isSmartPointer) {
                        c = this.rawConstructor();
                        a !== null && a.push(this.rawDestructor, c);
                        return c
                    } else return 0
                }
                b.$$ || Q('Cannot pass "' + Lc(b) + '" as a ' + this.name);
                b.$$.ptr || Q("Cannot pass deleted object as a pointer of type " + this.name);
                !this.isConst && b.$$.ptrType.isConst && Q("Cannot convert argument of type " + (b.$$.smartPtrType ? b.$$.smartPtrType.name : b.$$.ptrType.name) + " to parameter type " + this.name);
                var d = b.$$.ptrType.registeredClass;
                c = Zb(b.$$.ptr, d, this.registeredClass);
                if (this.isSmartPointer) {
                    void 0 === b.$$.smartPtr && Q("Passing raw pointer to smart pointer is illegal");
                    switch (this.sharingPolicy) {
                        case 0:
                            b.$$.smartPtrType === this ? c = b.$$.smartPtr : Q("Cannot convert argument of type " + (b.$$.smartPtrType ? b.$$.smartPtrType.name : b.$$.ptrType.name) + " to parameter type " + this.name);
                            break;
                        case 1:
                            c = b.$$.smartPtr;
                            break;
                        case 2:
                            if (b.$$.smartPtrType === this) c = b.$$.smartPtr;
                            else {
                                var e = b.clone();
                                c = this.rawShare(c, Jc.toHandle(function() {
                                    e["delete"]()
                                }));
                                a !== null && a.push(this.rawDestructor, c)
                            }
                            break;
                        default:
                            Q("Unsupporting sharing policy")
                    }
                }
                return c
            }

            function bc(a, b) {
                if (b === null) {
                    this.isReference && Q("null is not a valid " + this.name);
                    return 0
                }
                b.$$ || Q('Cannot pass "' + Lc(b) + '" as a ' + this.name);
                b.$$.ptr || Q("Cannot pass deleted object as a pointer of type " + this.name);
                b.$$.ptrType.isConst && Q("Cannot convert argument of type " + b.$$.ptrType.name + " to parameter type " + this.name);
                a = b.$$.ptrType.registeredClass;
                b = Zb(b.$$.ptr, a, this.registeredClass);
                return b
            }

            function cc(a) {
                return this.fromWireType(y[a >> 2])
            }

            function dc(a) {
                this.rawGetPointee && (a = this.rawGetPointee(a));
                return a
            }

            function ec(a) {
                this.rawDestructor && this.rawDestructor(a)
            }

            function fc(a) {
                a !== null && a["delete"]()
            }

            function gc(a, b, c) {
                if (b === c) return a;
                if (void 0 === c.baseClass) return null;
                a = gc(a, b, c.baseClass);
                return a === null ? null : c.downcast(a)
            }

            function hc() {
                return Object.keys(lc).length
            }

            function ic() {
                var a = [];
                for (var b in lc) Object.prototype.hasOwnProperty.call(lc, b) && a.push(lc[b]);
                return a
            }

            function jc(a) {
                Qb = a, Rb.length && Qb && Qb(Sb)
            }

            function kc() {
                c.getInheritedInstanceCount = hc, c.getLiveInheritedInstances = ic, c.flushPendingDeletes = Sb, c.setDelayFunction = jc
            }
            var lc = {};

            function mc(a, b) {
                b === void 0 && Q("ptr should not be undefined");
                while (a.baseClass) b = a.upcast(b), a = a.baseClass;
                return b
            }

            function nc(a, b) {
                b = mc(a, b);
                return lc[b]
            }

            function oc(a, b) {
                (!b.ptrType || !b.ptr) && Db("makeClassHandle requires ptr and ptrType");
                var c = !!b.smartPtrType,
                    d = !!b.smartPtr;
                c !== d && Db("Both smartPtrType and smartPtr must be specified");
                b.count = {
                    value: 1
                };
                return Mb(Object.create(a, {
                    $$: {
                        value: b
                    }
                }))
            }

            function pc(a) {
                var b = this.getPointee(a);
                if (!b) {
                    this.destructor(a);
                    return null
                }
                var c = nc(this.registeredClass, b);
                if (void 0 !== c)
                    if (0 === c.$$.count.value) {
                        c.$$.ptr = b;
                        c.$$.smartPtr = a;
                        return c.clone()
                    } else {
                        c = c.clone();
                        this.destructor(a);
                        return c
                    }
                function d() {
                    if (this.isSmartPointer) return oc(this.registeredClass.instancePrototype, {
                        ptrType: this.pointeeType,
                        ptr: b,
                        smartPtrType: this,
                        smartPtr: a
                    });
                    else return oc(this.registeredClass.instancePrototype, {
                        ptrType: this,
                        ptr: a
                    })
                }
                c = this.registeredClass.getActualType(b);
                c = Vb[c];
                if (!c) return d.call(this);
                var e;
                this.isConst ? e = c.constPointerType : e = c.pointerType;
                c = gc(b, this.registeredClass, e.registeredClass);
                if (c === null) return d.call(this);
                if (this.isSmartPointer) return oc(e.registeredClass.instancePrototype, {
                    ptrType: e,
                    ptr: c,
                    smartPtrType: this,
                    smartPtr: a
                });
                else return oc(e.registeredClass.instancePrototype, {
                    ptrType: e,
                    ptr: c
                })
            }

            function qc() {
                U.prototype.getPointee = dc, U.prototype.destructor = ec, U.prototype.argPackAdvance = 8, U.prototype.readValueFromPointer = cc, U.prototype.deleteObject = fc, U.prototype.fromWireType = pc
            }

            function U(a, b, c, d, e, f, g, h, i, j, k) {
                this.name = a, this.registeredClass = b, this.isReference = c, this.isConst = d, this.isSmartPointer = e, this.pointeeType = f, this.sharingPolicy = g, this.rawGetPointee = h, this.rawConstructor = i, this.rawShare = j, this.rawDestructor = k, !e && b.baseClass === void 0 ? d ? (this.toWireType = $b, this.destructorFunction = null) : (this.toWireType = bc, this.destructorFunction = null) : this.toWireType = ac
            }

            function rc(a, b, d) {
                Object.prototype.hasOwnProperty.call(c, a) || Db("Replacing nonexistant public symbol"), void 0 !== c[a].overloadTable && void 0 !== d ? c[a].overloadTable[d] = b : (c[a] = b, c[a].argCount = d)
            }

            function sc(a, b, d) {
                a = c["dynCall_" + a];
                return d && d.length ? a.apply(null, [b].concat(d)) : a.call(null, b)
            }

            function tc(a, b, c) {
                return a.includes("j") ? sc(a, b, c) : E(b).apply(null, c)
            }

            function uc(a, b) {
                var c = [];
                return function() {
                    c.length = arguments.length;
                    for (var d = 0; d < arguments.length; d++) c[d] = arguments[d];
                    return tc(a, b, c)
                }
            }

            function V(a, b) {
                a = M(a);

                function c() {
                    return a.includes("j") ? uc(a, b) : E(b)
                }
                c = c();
                typeof c !== "function" && Q("unknown function pointer with signature " + a + ": " + b);
                return c
            }
            var vc = void 0;

            function wc(a) {
                a = xd(a);
                var b = M(a);
                X(a);
                return b
            }

            function xc(a, b) {
                var c = [],
                    d = {};

                function e(a) {
                    if (d[a]) return;
                    if (O[a]) return;
                    if (wb[a]) {
                        wb[a].forEach(e);
                        return
                    }
                    c.push(a);
                    d[a] = !0
                }
                b.forEach(e);
                throw new vc(a + ": " + c.map(wc).join([", "]))
            }

            function yc(a, b, c, d, e, f, g, h, i, j, k, l, m) {
                k = M(k);
                f = V(e, f);
                h && (h = V(g, h));
                j && (j = V(i, j));
                m = V(l, m);
                var n = zb(k);
                Xb(n, function() {
                    xc("Cannot construct " + k + " due to unbound types", [d])
                });
                R([a, b, c], d ? [d] : [], function(b) {
                    b = b[0];
                    var c;
                    d ? (c = b.registeredClass, b = c.instancePrototype) : b = T.prototype;
                    var e = Ab(n, function() {
                            if (Object.getPrototypeOf(this) !== g) throw new P("Use 'new' to construct " + k);
                            if (void 0 === i.constructor_body) throw new P(k + " has no accessible constructor");
                            var a = i.constructor_body[arguments.length];
                            if (void 0 === a) throw new P("Tried to invoke ctor of " + k + " with invalid number of parameters (" + arguments.length + ") - expected (" + Object.keys(i.constructor_body).toString() + ") parameters instead!");
                            return a.apply(this, arguments)
                        }),
                        g = Object.create(b, {
                            constructor: {
                                value: e
                            }
                        });
                    e.prototype = g;
                    var i = new Yb(k, e, g, m, c, f, h, j);
                    b = new U(k, i, !0, !1, !1);
                    var l = new U(k + "*", i, !1, !1, !1),
                        o = new U(k + " const*", i, !1, !0, !1);
                    Vb[a] = {
                        pointerType: l,
                        constPointerType: o
                    };
                    rc(n, e);
                    return [b, l, o]
                })
            }

            function zc(a, b) {
                var c = [];
                for (var d = 0; d < a; d++) c.push(x[(b >> 2) + d]);
                return c
            }

            function Ac(a) {
                while (a.length) {
                    var b = a.pop(),
                        c = a.pop();
                    c(b)
                }
            }

            function Bc(a, b, c, d, e, f) {
                ja(b > 0);
                var g = zc(b, c);
                e = V(d, e);
                R([], [a], function(a) {
                    a = a[0];
                    var c = "constructor " + a.name;
                    void 0 === a.registeredClass.constructor_body && (a.registeredClass.constructor_body = []);
                    if (void 0 !== a.registeredClass.constructor_body[b - 1]) throw new P("Cannot register multiple constructors with identical number of parameters (" + (b - 1) + ") for class '" + a.name + "'! Overload resolution is currently only performed using the parameter count, not actual type info!");
                    a.registeredClass.constructor_body[b - 1] = function() {
                        xc("Cannot construct " + a.name + " due to unbound types", g)
                    };
                    R([], g, function(d) {
                        d.splice(1, 0, null);
                        a.registeredClass.constructor_body[b - 1] = Cc(c, d, null, e, f);
                        return []
                    });
                    return []
                })
            }

            function Cc(a, b, c, d, e) {
                var f = b.length;
                f < 2 && Q("argTypes array size mismatch! Must at least get return value and 'this' types!");
                var g = b[1] !== null && c !== null,
                    h = !1;
                for (c = 1; c < b.length; ++c)
                    if (b[c] !== null && b[c].destructorFunction === void 0) {
                        h = !0;
                        break
                    }
                var i = b[0].name !== "void",
                    j = f - 2,
                    k = new Array(j),
                    l = [],
                    m = [];
                return function() {
                    arguments.length !== j && Q("function " + a + " called with " + arguments.length + " arguments, expected " + j + " args!");
                    m.length = 0;
                    var c;
                    l.length = g ? 2 : 1;
                    l[0] = e;
                    g && (c = b[1].toWireType(m, this), l[1] = c);
                    for (var f = 0; f < j; ++f) k[f] = b[f + 2].toWireType(m, arguments[f]), l.push(k[f]);
                    var n = d.apply(null, l);

                    function o(d) {
                        if (h) Ac(m);
                        else
                            for (var a = g ? 1 : 2; a < b.length; a++) {
                                var e = a === 1 ? c : k[a - 2];
                                b[a].destructorFunction !== null && b[a].destructorFunction(e)
                            }
                        if (i) return b[0].fromWireType(d)
                    }
                    return o(n)
                }
            }

            function Dc(a, b, c, d, e, f, g, h) {
                var i = zc(c, d);
                b = M(b);
                f = V(e, f);
                R([], [a], function(a) {
                    a = a[0];
                    var d = a.name + "." + b;
                    b.startsWith("@@") && (b = Symbol[b.substring(2)]);
                    h && a.registeredClass.pureVirtualFunctions.push(b);

                    function e() {
                        xc("Cannot call " + d + " due to unbound types", i)
                    }
                    var j = a.registeredClass.instancePrototype,
                        k = j[b];
                    void 0 === k || void 0 === k.overloadTable && k.className !== a.name && k.argCount === c - 2 ? (e.argCount = c - 2, e.className = a.name, j[b] = e) : (Wb(j, b, d), j[b].overloadTable[c - 2] = e);
                    R([], i, function(e) {
                        e = Cc(d, e, a, f, g);
                        void 0 === j[b].overloadTable ? (e.argCount = c - 2, j[b] = e) : j[b].overloadTable[c - 2] = e;
                        return []
                    });
                    return []
                })
            }
            var Ec = [],
                W = [{}, {
                    value: void 0
                }, {
                    value: null
                }, {
                    value: !0
                }, {
                    value: !1
                }];

            function Fc(a) {
                a > 4 && 0 === --W[a].refcount && (W[a] = void 0, Ec.push(a))
            }

            function Gc() {
                var a = 0;
                for (var b = 5; b < W.length; ++b) W[b] !== void 0 && ++a;
                return a
            }

            function Hc() {
                for (var a = 5; a < W.length; ++a)
                    if (W[a] !== void 0) return W[a];
                return null
            }

            function Ic() {
                c.count_emval_handles = Gc, c.get_first_emval = Hc
            }
            var Jc = {
                toValue: function(a) {
                    a || Q("Cannot use deleted val. handle = " + a);
                    return W[a].value
                },
                toHandle: function(a) {
                    switch (a) {
                        case void 0:
                            return 1;
                        case null:
                            return 2;
                        case !0:
                            return 3;
                        case !1:
                            return 4;
                        default:
                            var b = Ec.length ? Ec.pop() : W.length;
                            W[b] = {
                                refcount: 1,
                                value: a
                            };
                            return b
                    }
                }
            };

            function Kc(a, b) {
                b = M(b), S(a, {
                    name: b,
                    fromWireType: function(a) {
                        var b = Jc.toValue(a);
                        Fc(a);
                        return b
                    },
                    toWireType: function(a, b) {
                        return Jc.toHandle(b)
                    },
                    argPackAdvance: 8,
                    readValueFromPointer: cc,
                    destructorFunction: null
                })
            }

            function Lc(a) {
                if (a === null) return "null";
                var b = typeof a;
                if (b === "object" || b === "array" || b === "function") return a.toString();
                else return "" + a
            }

            function Mc(a, b) {
                switch (b) {
                    case 2:
                        return function(a) {
                            return this.fromWireType(Aa[a >> 2])
                        };
                    case 3:
                        return function(a) {
                            return this.fromWireType(Ba[a >> 3])
                        };
                    default:
                        throw new TypeError("Unknown float type: " + a)
                }
            }

            function Nc(a, b, c) {
                c = tb(c);
                b = M(b);
                S(a, {
                    name: b,
                    fromWireType: function(a) {
                        return a
                    },
                    toWireType: function(a, b) {
                        return b
                    },
                    argPackAdvance: 8,
                    readValueFromPointer: Mc(b, c),
                    destructorFunction: null
                })
            }

            function Oc(a, b, c, d, e, f) {
                var g = zc(b, c);
                a = M(a);
                e = V(d, e);
                Xb(a, function() {
                    xc("Cannot call " + a + " due to unbound types", g)
                }, b - 1);
                R([], g, function(c) {
                    c = [c[0], null].concat(c.slice(1));
                    rc(a, Cc(a, c, null, e, f), b - 1);
                    return []
                })
            }

            function Pc(a, b, c) {
                switch (b) {
                    case 0:
                        return c ? function(a) {
                            return u[a]
                        } : function(a) {
                            return v[a]
                        };
                    case 1:
                        return c ? function(a) {
                            return w[a >> 1]
                        } : function(a) {
                            return za[a >> 1]
                        };
                    case 2:
                        return c ? function(a) {
                            return x[a >> 2]
                        } : function(a) {
                            return y[a >> 2]
                        };
                    default:
                        throw new TypeError("Unknown integer type: " + a)
                }
            }

            function Qc(a, b, c, d, e) {
                b = M(b);
                e === -1 && (e = 4294967295);
                e = tb(c);
                var f = function(a) {
                    return a
                };
                if (d === 0) {
                    var g = 32 - 8 * c;
                    f = function(a) {
                        return a << g >>> g
                    }
                }
                c = b.includes("unsigned");
                var h = function(a, b) {};
                c ? c = function(a, b) {
                    h(b, this.name);
                    return b >>> 0
                } : c = function(a, b) {
                    h(b, this.name);
                    return b
                };
                S(a, {
                    name: b,
                    fromWireType: f,
                    toWireType: c,
                    argPackAdvance: 8,
                    readValueFromPointer: Pc(b, e, d !== 0),
                    destructorFunction: null
                })
            }

            function Rc(a, b, c) {
                var d = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array],
                    e = d[b];

                function f(a) {
                    a = a >> 2;
                    var b = y,
                        c = b[a];
                    b = b[a + 1];
                    return new e(ya, b, c)
                }
                c = M(c);
                S(a, {
                    name: c,
                    fromWireType: f,
                    argPackAdvance: 8,
                    readValueFromPointer: f
                }, {
                    ignoreDuplicateRegistrations: !0
                })
            }

            function Sc(a, b) {
                b = M(b);
                var c = b === "std::string";
                S(a, {
                    name: b,
                    fromWireType: function(a) {
                        var b = y[a >> 2],
                            d;
                        if (c) {
                            var e = a + 4;
                            for (var f = 0; f <= b; ++f) {
                                var g = a + 4 + f;
                                if (f == b || v[g] == 0) {
                                    var h = g - e;
                                    h = la(e, h);
                                    d === void 0 ? d = h : (d += String.fromCharCode(0), d += h);
                                    e = g + 1
                                }
                            }
                        } else {
                            h = new Array(b);
                            for (var f = 0; f < b; ++f) h[f] = String.fromCharCode(v[a + 4 + f]);
                            d = h.join("")
                        }
                        X(a);
                        return d
                    },
                    toWireType: function(a, b) {
                        b instanceof ArrayBuffer && (b = new Uint8Array(b));
                        var d, e = typeof b === "string";
                        e || b instanceof Uint8Array || b instanceof Uint8ClampedArray || b instanceof Int8Array || Q("Cannot pass non-string to std::string");
                        c && e ? d = function() {
                            return oa(b)
                        } : d = function() {
                            return b.length
                        };
                        d = d();
                        var f = wd(4 + d + 1);
                        y[f >> 2] = d;
                        if (c && e) na(b, f + 4, d + 1);
                        else if (e)
                            for (e = 0; e < d; ++e) {
                                var g = b.charCodeAt(e);
                                g > 255 && (X(f), Q("String has UTF-16 code units that do not fit in 8 bits"));
                                v[f + 4 + e] = g
                            } else
                                for (e = 0; e < d; ++e) v[f + 4 + e] = b[e];
                        a !== null && a.push(X, f);
                        return f
                    },
                    argPackAdvance: 8,
                    readValueFromPointer: cc,
                    destructorFunction: function(a) {
                        X(a)
                    }
                })
            }

            function Tc(a, b, c) {
                c = M(c);
                var d, e, f, g, h;
                b === 2 ? (d = qa, e = ra, g = sa, f = function() {
                    return za
                }, h = 1) : b === 4 && (d = ta, e = ua, g = va, f = function() {
                    return y
                }, h = 2);
                S(a, {
                    name: c,
                    fromWireType: function(a) {
                        var c = y[a >> 2],
                            e = f(),
                            g, i = a + 4;
                        for (var j = 0; j <= c; ++j) {
                            var k = a + 4 + j * b;
                            if (j == c || e[k >> h] == 0) {
                                var l = k - i;
                                l = d(i, l);
                                g === void 0 ? g = l : (g += String.fromCharCode(0), g += l);
                                i = k + b
                            }
                        }
                        X(a);
                        return g
                    },
                    toWireType: function(a, d) {
                        typeof d === "string" || Q("Cannot pass non-string to C++ string type " + c);
                        var f = g(d),
                            i = wd(4 + f + b);
                        y[i >> 2] = f >> h;
                        e(d, i + 4, f + b);
                        a !== null && a.push(X, i);
                        return i
                    },
                    argPackAdvance: 8,
                    readValueFromPointer: cc,
                    destructorFunction: function(a) {
                        X(a)
                    }
                })
            }

            function Uc(a, b) {
                b = M(b), S(a, {
                    isVoid: !0,
                    name: b,
                    argPackAdvance: 0,
                    fromWireType: function() {
                        return void 0
                    },
                    toWireType: function(a, b) {
                        return void 0
                    }
                })
            }

            function Vc(a) {
                a > 4 && (W[a].refcount += 1)
            }

            function Wc(a, b) {
                var c = O[a];
                void 0 === c && Q(b + " has unknown type " + wc(a));
                return c
            }

            function Xc(a, b) {
                a = Wc(a, "_emval_take_value");
                a = a.readValueFromPointer(b);
                return Jc.toHandle(a)
            }

            function Yc() {
                A("")
            }

            function Zc(a) {
                A("OOM")
            }

            function $c(a) {
                v.length, a = a >>> 0, Zc(a)
            }
            var ad = {};

            function bd() {
                return m || "./this.program"
            }

            function cd() {
                if (!cd.strings) {
                    var a = (typeof navigator === "object" && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8";
                    a = {
                        USER: "web_user",
                        LOGNAME: "web_user",
                        PATH: "/",
                        PWD: "/",
                        HOME: "/home/web_user",
                        LANG: a,
                        _: bd()
                    };
                    for (var b in ad) ad[b] === void 0 ? delete a[b] : a[b] = ad[b];
                    var c = [];
                    for (var b in a) c.push(b + "=" + a[b]);
                    cd.strings = c
                }
                return cd.strings
            }

            function dd(a, b) {
                var c = 0;
                cd().forEach(function(d, e) {
                    var f = b + c;
                    x[a + e * 4 >> 2] = f;
                    xa(d, f);
                    c += d.length + 1
                });
                return 0
            }

            function ed(a, b) {
                var c = cd();
                x[a >> 2] = c.length;
                var d = 0;
                c.forEach(function(a) {
                    d += a.length + 1
                });
                x[b >> 2] = d;
                return 0
            }

            function fd(a) {
                try {
                    a = L.getStreamFromFD(a);
                    K.close(a);
                    return 0
                } catch (a) {
                    if (typeof K === "undefined" || !(a instanceof K.ErrnoError)) throw a;
                    return a.errno
                }
            }

            function gd(a, b, c, d) {
                try {
                    a = L.getStreamFromFD(a);
                    a = L.doReadv(a, b, c);
                    x[d >> 2] = a;
                    return 0
                } catch (a) {
                    if (typeof K === "undefined" || !(a instanceof K.ErrnoError)) throw a;
                    return a.errno
                }
            }

            function hd(a, b, c, d, e) {
                try {
                    a = L.getStreamFromFD(a);
                    var f = 4294967296;
                    c = c * f + (b >>> 0);
                    f = 9007199254740992;
                    if (c <= -f || c >= f) return -61;
                    K.llseek(a, c, d);
                    D = [a.position >>> 0, (C = a.position, +Math.abs(C) >= 1 ? C > 0 ? (Math.min(+Math.floor(C / 4294967296), 4294967295) | 0) >>> 0 : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0 : 0)], x[e >> 2] = D[0], x[e + 4 >> 2] = D[1];
                    a.getdents && c === 0 && d === 0 && (a.getdents = null);
                    return 0
                } catch (a) {
                    if (typeof K === "undefined" || !(a instanceof K.ErrnoError)) throw a;
                    return a.errno
                }
            }

            function id(a, b, c, d) {
                try {
                    a = L.getStreamFromFD(a);
                    a = L.doWritev(a, b, c);
                    x[d >> 2] = a;
                    return 0
                } catch (a) {
                    if (typeof K === "undefined" || !(a instanceof K.ErrnoError)) throw a;
                    return a.errno
                }
            }

            function jd() {
                return ga()
            }

            function kd(a) {
                r(a)
            }

            function ld(a) {
                return a % 4 === 0 && (a % 100 !== 0 || a % 400 === 0)
            }

            function md(a, b) {
                var c = 0;
                for (var d = 0; d <= b; c += a[d++]);
                return c
            }
            var nd = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                od = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

            function pd(a, b) {
                a = new Date(a.getTime());
                while (b > 0) {
                    var c = ld(a.getFullYear()),
                        d = a.getMonth();
                    c = (c ? nd : od)[d];
                    if (b > c - a.getDate()) b -= c - a.getDate() + 1, a.setDate(1), d < 11 ? a.setMonth(d + 1) : (a.setMonth(0), a.setFullYear(a.getFullYear() + 1));
                    else {
                        a.setDate(a.getDate() + b);
                        return a
                    }
                }
                return a
            }

            function qd(a, b, c, d) {
                var e = x[d + 40 >> 2];
                d = {
                    tm_sec: x[d >> 2],
                    tm_min: x[d + 4 >> 2],
                    tm_hour: x[d + 8 >> 2],
                    tm_mday: x[d + 12 >> 2],
                    tm_mon: x[d + 16 >> 2],
                    tm_year: x[d + 20 >> 2],
                    tm_wday: x[d + 24 >> 2],
                    tm_yday: x[d + 28 >> 2],
                    tm_isdst: x[d + 32 >> 2],
                    tm_gmtoff: x[d + 36 >> 2],
                    tm_zone: e ? la(e) : ""
                };
                e = la(c);
                c = {
                    "%c": "%a %b %d %H:%M:%S %Y",
                    "%D": "%m/%d/%y",
                    "%F": "%Y-%m-%d",
                    "%h": "%b",
                    "%r": "%I:%M:%S %p",
                    "%R": "%H:%M",
                    "%T": "%H:%M:%S",
                    "%x": "%m/%d/%y",
                    "%X": "%H:%M:%S",
                    "%Ec": "%c",
                    "%EC": "%C",
                    "%Ex": "%m/%d/%y",
                    "%EX": "%H:%M:%S",
                    "%Ey": "%y",
                    "%EY": "%Y",
                    "%Od": "%d",
                    "%Oe": "%e",
                    "%OH": "%H",
                    "%OI": "%I",
                    "%Om": "%m",
                    "%OM": "%M",
                    "%OS": "%S",
                    "%Ou": "%u",
                    "%OU": "%U",
                    "%OV": "%V",
                    "%Ow": "%w",
                    "%OW": "%W",
                    "%Oy": "%y"
                };
                for (var f in c) e = e.replace(new RegExp(f, "g"), c[f]);
                var g = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    h = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

                function i(a, b, c) {
                    a = typeof a === "number" ? a.toString() : a || "";
                    while (a.length < b) a = c[0] + a;
                    return a
                }

                function j(a, b) {
                    return i(a, b, "0")
                }

                function k(a, b) {
                    function c(a) {
                        return a < 0 ? -1 : a > 0 ? 1 : 0
                    }
                    var d;
                    (d = c(a.getFullYear() - b.getFullYear())) === 0 && ((d = c(a.getMonth() - b.getMonth())) === 0 && (d = c(a.getDate() - b.getDate())));
                    return d
                }

                function l(a) {
                    switch (a.getDay()) {
                        case 0:
                            return new Date(a.getFullYear() - 1, 11, 29);
                        case 1:
                            return a;
                        case 2:
                            return new Date(a.getFullYear(), 0, 3);
                        case 3:
                            return new Date(a.getFullYear(), 0, 2);
                        case 4:
                            return new Date(a.getFullYear(), 0, 1);
                        case 5:
                            return new Date(a.getFullYear() - 1, 11, 31);
                        case 6:
                            return new Date(a.getFullYear() - 1, 11, 30)
                    }
                }

                function m(a) {
                    a = pd(new Date(a.tm_year + 1900, 0, 1), a.tm_yday);
                    var b = new Date(a.getFullYear(), 0, 4),
                        c = new Date(a.getFullYear() + 1, 0, 4);
                    b = l(b);
                    c = l(c);
                    if (k(b, a) <= 0)
                        if (k(c, a) <= 0) return a.getFullYear() + 1;
                        else return a.getFullYear();
                    else return a.getFullYear() - 1
                }
                c = {
                    "%a": function(a) {
                        return g[a.tm_wday].substring(0, 3)
                    },
                    "%A": function(a) {
                        return g[a.tm_wday]
                    },
                    "%b": function(a) {
                        return h[a.tm_mon].substring(0, 3)
                    },
                    "%B": function(a) {
                        return h[a.tm_mon]
                    },
                    "%C": function(a) {
                        a = a.tm_year + 1900;
                        return j(a / 100 | 0, 2)
                    },
                    "%d": function(a) {
                        return j(a.tm_mday, 2)
                    },
                    "%e": function(a) {
                        return i(a.tm_mday, 2, " ")
                    },
                    "%g": function(a) {
                        return m(a).toString().substring(2)
                    },
                    "%G": function(a) {
                        return m(a)
                    },
                    "%H": function(a) {
                        return j(a.tm_hour, 2)
                    },
                    "%I": function(a) {
                        a = a.tm_hour;
                        a == 0 ? a = 12 : a > 12 && (a -= 12);
                        return j(a, 2)
                    },
                    "%j": function(a) {
                        return j(a.tm_mday + md(ld(a.tm_year + 1900) ? nd : od, a.tm_mon - 1), 3)
                    },
                    "%m": function(a) {
                        return j(a.tm_mon + 1, 2)
                    },
                    "%M": function(a) {
                        return j(a.tm_min, 2)
                    },
                    "%n": function() {
                        return "\n"
                    },
                    "%p": function(a) {
                        if (a.tm_hour >= 0 && a.tm_hour < 12) return "AM";
                        else return "PM"
                    },
                    "%S": function(a) {
                        return j(a.tm_sec, 2)
                    },
                    "%t": function() {
                        return "\t"
                    },
                    "%u": function(a) {
                        return a.tm_wday || 7
                    },
                    "%U": function(a) {
                        var b = new Date(a.tm_year + 1900, 0, 1),
                            c = b.getDay() === 0 ? b : pd(b, 7 - b.getDay());
                        a = new Date(a.tm_year + 1900, a.tm_mon, a.tm_mday);
                        if (k(c, a) < 0) {
                            var d = md(ld(a.getFullYear()) ? nd : od, a.getMonth() - 1) - 31,
                                e = 31 - c.getDate();
                            e = e + d + a.getDate();
                            return j(Math.ceil(e / 7), 2)
                        }
                        return k(c, b) === 0 ? "01" : "00"
                    },
                    "%V": function(a) {
                        var b = new Date(a.tm_year + 1900, 0, 4),
                            c = new Date(a.tm_year + 1901, 0, 4);
                        b = l(b);
                        c = l(c);
                        var d = pd(new Date(a.tm_year + 1900, 0, 1), a.tm_yday);
                        if (k(d, b) < 0) return "53";
                        if (k(c, d) <= 0) return "01";
                        b.getFullYear() < a.tm_year + 1900 ? c = a.tm_yday + 32 - b.getDate() : c = a.tm_yday + 1 - b.getDate();
                        return j(Math.ceil(c / 7), 2)
                    },
                    "%w": function(a) {
                        return a.tm_wday
                    },
                    "%W": function(a) {
                        var b = new Date(a.tm_year, 0, 1),
                            c = b.getDay() === 1 ? b : pd(b, b.getDay() === 0 ? 1 : 7 - b.getDay() + 1);
                        a = new Date(a.tm_year + 1900, a.tm_mon, a.tm_mday);
                        if (k(c, a) < 0) {
                            var d = md(ld(a.getFullYear()) ? nd : od, a.getMonth() - 1) - 31,
                                e = 31 - c.getDate();
                            e = e + d + a.getDate();
                            return j(Math.ceil(e / 7), 2)
                        }
                        return k(c, b) === 0 ? "01" : "00"
                    },
                    "%y": function(a) {
                        return (a.tm_year + 1900).toString().substring(2)
                    },
                    "%Y": function(a) {
                        return a.tm_year + 1900
                    },
                    "%z": function(a) {
                        a = a.tm_gmtoff;
                        var b = a >= 0;
                        a = Math.abs(a) / 60;
                        a = a / 60 * 100 + a % 60;
                        return (b ? "+" : "-") + String("0000" + a).slice(-4)
                    },
                    "%Z": function(a) {
                        return a.tm_zone
                    },
                    "%%": function() {
                        return "%"
                    }
                };
                for (var f in c) e.includes(f) && (e = e.replace(new RegExp(f, "g"), c[f](d)));
                c = ud(e, !1);
                if (c.length > b) return 0;
                wa(c, a);
                return c.length - 1
            }

            function rd(a, b, c, d) {
                return qd(a, b, c, d)
            }
            d = function(a, b, c, d) {
                a || (a = this), this.parent = a, this.mount = a.mount, this.mounted = null, this.id = K.nextInode++, this.name = b, this.mode = c, this.node_ops = {}, this.stream_ops = {}, this.rdev = d
            };
            var sd = 292 | 73,
                td = 146;
            Object.defineProperties(d.prototype, {
                read: {
                    get: function() {
                        return (this.mode & sd) === sd
                    },
                    set: function(a) {
                        a ? this.mode |= sd : this.mode &= ~sd
                    }
                },
                write: {
                    get: function() {
                        return (this.mode & td) === td
                    },
                    set: function(a) {
                        a ? this.mode |= td : this.mode &= ~td
                    }
                },
                isFolder: {
                    get: function() {
                        return K.isDir(this.mode)
                    }
                },
                isDevice: {
                    get: function() {
                        return K.isChrdev(this.mode)
                    }
                }
            });
            K.FSNode = d;
            K.staticInit();
            ub();
            P = c.BindingError = Bb(Error, "BindingError");
            Cb = c.InternalError = Bb(Error, "InternalError");
            Ub();
            qc();
            kc();
            vc = c.UnboundTypeError = Bb(Error, "UnboundTypeError");
            Ic();

            function ud(a, b, c) {
                c = c > 0 ? c : oa(a) + 1;
                c = new Array(c);
                a = ma(a, c, 0, c.length);
                b && (c.length = a);
                return c
            }
            var vd = {
                p: Ya,
                t: db,
                w: gb,
                b: ib,
                g: jb,
                x: eb,
                K: kb,
                u: lb,
                Y: mb,
                d: hb,
                ba: qb,
                _: rb,
                U: sb,
                da: Eb,
                z: yc,
                y: Bc,
                o: Dc,
                ca: Kc,
                N: Nc,
                ga: Oc,
                s: Qc,
                m: Rc,
                M: Sc,
                G: Tc,
                ea: Uc,
                fa: Fc,
                R: Vc,
                Q: Xc,
                C: Yc,
                Z: $c,
                $: dd,
                aa: ed,
                W: fd,
                L: gd,
                T: hd,
                F: id,
                a: jd,
                H: Qd,
                I: Pd,
                l: Rd,
                c: Dd,
                e: Gd,
                k: Hd,
                h: Md,
                X: Nd,
                q: Fd,
                J: Od,
                P: Jd,
                B: Td,
                S: Wd,
                i: Kd,
                r: Ed,
                f: Bd,
                j: Cd,
                D: Id,
                O: Ld,
                n: Sd,
                v: Ud,
                A: Vd,
                E: kd,
                V: rd
            };
            Wa();
            c.___wasm_call_ctors = function() {
                return (c.___wasm_call_ctors = c.asm.ia).apply(null, arguments)
            };
            c._bytearray_free = function() {
                return (c._bytearray_free = c.asm.ja).apply(null, arguments)
            };
            var X = c._free = function() {
                    return (X = c._free = c.asm.la).apply(null, arguments)
                },
                wd = c._malloc = function() {
                    return (wd = c._malloc = c.asm.ma).apply(null, arguments)
                },
                xd = c.___getTypeName = function() {
                    return (xd = c.___getTypeName = c.asm.na).apply(null, arguments)
                };
            c.___embind_register_native_and_builtin_types = function() {
                return (c.___embind_register_native_and_builtin_types = c.asm.oa).apply(null, arguments)
            };
            var Y = c._setThrew = function() {
                    return (Y = c._setThrew = c.asm.pa).apply(null, arguments)
                },
                Z = c.stackSave = function() {
                    return (Z = c.stackSave = c.asm.qa).apply(null, arguments)
                },
                $ = c.stackRestore = function() {
                    return ($ = c.stackRestore = c.asm.ra).apply(null, arguments)
                },
                yd = c.___cxa_can_catch = function() {
                    return (yd = c.___cxa_can_catch = c.asm.sa).apply(null, arguments)
                },
                zd = c.___cxa_is_pointer_type = function() {
                    return (zd = c.___cxa_is_pointer_type = c.asm.ta).apply(null, arguments)
                };
            c.dynCall_ji = function() {
                return (c.dynCall_ji = c.asm.ua).apply(null, arguments)
            };
            c.dynCall_viijii = function() {
                return (c.dynCall_viijii = c.asm.va).apply(null, arguments)
            };
            c.dynCall_jiji = function() {
                return (c.dynCall_jiji = c.asm.wa).apply(null, arguments)
            };
            var Ad = c.dynCall_jiiii = function() {
                return (Ad = c.dynCall_jiiii = c.asm.xa).apply(null, arguments)
            };
            c.dynCall_iiiiij = function() {
                return (c.dynCall_iiiiij = c.asm.ya).apply(null, arguments)
            };
            c.dynCall_iiiiijj = function() {
                return (c.dynCall_iiiiijj = c.asm.za).apply(null, arguments)
            };
            c.dynCall_iiiiiijj = function() {
                return (c.dynCall_iiiiiijj = c.asm.Aa).apply(null, arguments)
            };

            function Bd(a, b, c) {
                var d = Z();
                try {
                    E(a)(b, c)
                } catch (a) {
                    $(d);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Cd(a, b, c, d) {
                var e = Z();
                try {
                    E(a)(b, c, d)
                } catch (a) {
                    $(e);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Dd(a, b) {
                var c = Z();
                try {
                    return E(a)(b)
                } catch (a) {
                    $(c);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Ed(a, b) {
                var c = Z();
                try {
                    E(a)(b)
                } catch (a) {
                    $(c);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Fd(a, b, c, d, e, f, g) {
                var h = Z();
                try {
                    return E(a)(b, c, d, e, f, g)
                } catch (a) {
                    $(h);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Gd(a, b, c) {
                var d = Z();
                try {
                    return E(a)(b, c)
                } catch (a) {
                    $(d);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Hd(a, b, c, d) {
                var e = Z();
                try {
                    return E(a)(b, c, d)
                } catch (a) {
                    $(e);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Id(a, b, c, d, e) {
                var f = Z();
                try {
                    E(a)(b, c, d, e)
                } catch (a) {
                    $(f);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Jd(a, b, c, d, e, f, g, h, i) {
                var j = Z();
                try {
                    return E(a)(b, c, d, e, f, g, h, i)
                } catch (a) {
                    $(j);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Kd(a) {
                var b = Z();
                try {
                    E(a)()
                } catch (a) {
                    $(b);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Ld(a, b, c, d, e, f) {
                var g = Z();
                try {
                    E(a)(b, c, d, e, f)
                } catch (a) {
                    $(g);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Md(a, b, c, d, e) {
                var f = Z();
                try {
                    return E(a)(b, c, d, e)
                } catch (a) {
                    $(f);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Nd(a, b, c, d, e, f) {
                var g = Z();
                try {
                    return E(a)(b, c, d, e, f)
                } catch (a) {
                    $(g);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Od(a, b, c, d, e, f, g, h) {
                var i = Z();
                try {
                    return E(a)(b, c, d, e, f, g, h)
                } catch (a) {
                    $(i);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Pd(a, b, c, d) {
                var e = Z();
                try {
                    return E(a)(b, c, d)
                } catch (a) {
                    $(e);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Qd(a, b, c, d) {
                var e = Z();
                try {
                    return E(a)(b, c, d)
                } catch (a) {
                    $(e);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Rd(a) {
                var b = Z();
                try {
                    return E(a)()
                } catch (a) {
                    $(b);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Sd(a, b, c, d, e, f, g, h) {
                var i = Z();
                try {
                    E(a)(b, c, d, e, f, g, h)
                } catch (a) {
                    $(i);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Td(a, b, c, d, e, f, g, h, i, j, k, l) {
                var m = Z();
                try {
                    return E(a)(b, c, d, e, f, g, h, i, j, k, l)
                } catch (a) {
                    $(m);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Ud(a, b, c, d, e, f, g, h, i, j, k) {
                var l = Z();
                try {
                    E(a)(b, c, d, e, f, g, h, i, j, k)
                } catch (a) {
                    $(l);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Vd(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p) {
                var aa = Z();
                try {
                    E(a)(b, c, d, e, f, g, h, i, j, k, l, m, n, o, p)
                } catch (a) {
                    $(aa);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }

            function Wd(a, b, c, d, e) {
                var f = Z();
                try {
                    return Ad(a, b, c, d, e)
                } catch (a) {
                    $(f);
                    if (a !== a + 0 && a !== "longjmp") throw a;
                    Y(1, 0)
                }
            }
            var Xd;
            Oa = function a() {
                Xd || Yd(), Xd || (Oa = a)
            };

            function Yd(a) {
                a || l;
                if (z > 0) return;
                Ha();
                if (z > 0) return;

                function b() {
                    if (Xd) return;
                    Xd = !0;
                    c.calledRun = !0;
                    if (ia) return;
                    Ia();
                    i(c);
                    c.onRuntimeInitialized && c.onRuntimeInitialized();
                    Ja()
                }
                c.setStatus ? (c.setStatus("Running..."), setTimeout(function() {
                    setTimeout(function() {
                        c.setStatus("")
                    }, 1), b()
                }, 1)) : b()
            }
            c.run = Yd;
            if (c.preInit) {
                typeof c.preInit == "function" && (c.preInit = [c.preInit]);
                while (c.preInit.length > 0) c.preInit.pop()()
            }
            Yd();
            return c.ready
        }
    }();
    typeof f === "object" && typeof e === "object" ? e.exports = h : typeof define === "function" && define.amd ? define([], function() {
        return h
    }) : typeof f === "object" && (f.Module = h)
}), null);
__d("PakeCpaceWasm", ["PakeCpaceUtils", "Promise", "bx", "err", "pakeCpace"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var e = {
            locateFile: function() {
                return c("bx").getURL(c("bx")("20913"))
            },
            wasmBinary: a
        };
        return new(h || (h = b("Promise")))(function(a) {
            c("pakeCpace")(e).then(function(b) {
                return a({
                    clientBegin: function(a, c, d) {
                        var e = 0;
                        try {
                            e = a.clientBegin(c, d);
                            a = b.getInt8Array(e);
                            return a
                        } finally {
                            b._bytearray_free(e)
                        }
                    },
                    clientFinalize: function(a, c) {
                        var e = 0,
                            f = 0;
                        try {
                            c = d("PakeCpaceUtils").uint8ArrayToVectorInt(b, c);
                            a = a.clientFinalize(c);
                            e = a.getKey1Ptr();
                            c = b.getInt8Array(e);
                            f = a.getKey2Ptr();
                            a = b.getInt8Array(f);
                            return {
                                clientKey1: c,
                                clientKey2: a
                            }
                        } finally {
                            b._bytearray_free(e), b._bytearray_free(f)
                        }
                    },
                    createCPaceClient: function(a) {
                        return new b.PAKEClient(a)
                    },
                    createCPaceServer: function(a) {
                        return new b.PAKEServer(a)
                    },
                    serverHandleClientStepOnePacket: function(a, c, e, f) {
                        var g = 0,
                            h = 0,
                            i = 0;
                        try {
                            e = d("PakeCpaceUtils").uint8ArrayToVectorInt(b, e);
                            a = a.handleClientStepOnePacket(c, e, f);
                            g = a.getKey1Ptr();
                            c = b.getInt8Array(g);
                            h = a.getKey2Ptr();
                            e = b.getInt8Array(h);
                            i = a.getPacketPtr();
                            f = b.getInt8Array(i);
                            return {
                                serverKey1: c,
                                serverKey2: e,
                                stepTwoPacket: f
                            }
                        } finally {
                            b._bytearray_free(g), b._bytearray_free(h), b._bytearray_free(i)
                        }
                    }
                })
            })["catch"](function(a) {
                throw c("err")("Failed to initialize wasm module, " + a)
            })
        })
    }
    g.PakeCPaceWasm = a
}), 98);
__d("useMWChatEncryptedBackupsAddDevice", ["Promise", "cr:3676", "promiseDone", "react", "requireDeferred", "useAsyncReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    e = i || d("react");
    var j = e.useCallback,
        k = e.useRef,
        l = e.useState,
        m = c("requireDeferred")("MAWEncryptedBackupsClearRecoveryCode").__setRef("useMWChatEncryptedBackupsAddDevice"),
        n = c("requireDeferred")("MWEncryptedBackupsFetchBackupIds").__setRef("useMWChatEncryptedBackupsAddDevice"),
        o = c("requireDeferred")("mwEBAddDevice").__setRef("useMWChatEncryptedBackupsAddDevice");

    function a(a) {
        var d = a.hsmFleetMigrationResetPIN,
            e = a.onComplete,
            f = a.onFailure,
            g = a.onInvalidRecoveryCode,
            i = a.onStart;
        a = l(!1);
        var p = a[0],
            q = a[1],
            r = j(function() {
                q(!1), b("cr:3676") != null && void b("cr:3676").call()
            }, []),
            s = c("useAsyncReStore")(),
            t = k("");
        return [j(function(a, j, k) {
            t.current = k || "", c("promiseDone")((h || (h = b("Promise"))).all([s, m.load(), o.load(), n.load()]), function(b) {
                var h = b[0],
                    k = b[1].encryptedBackupsClearRecoveryCode,
                    l = b[2],
                    m = b[3].encryptedBackupsFetchBackupIds;
                c("promiseDone")(k(h), function() {
                    return l({
                        onFailure: function(a) {
                            r(), f(a)
                        },
                        onInvalidRecoveryCode: function() {
                            r(), g()
                        },
                        onStart: function() {
                            q(!0), i == null ? void 0 : i()
                        },
                        onSuccess: function() {
                            c("promiseDone")(m(h)), r(), e(), d && t.current !== "" && d(t.current)
                        },
                        recoveryCode: a,
                        storage: h,
                        traceId: j
                    })
                })
            })
        }, [s, d, e, f, r, g, i]), p]
    }
    g["default"] = a
}), 98);
__d("useMWChatEncryptedBackupsNumericCode", ["FocusRegion.react", "MWChatEncrypedBackupsNumericCodeValidation", "asyncToGeneratorRuntime", "focusScopeQueries", "promiseDone", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || (h = d("react"));
    var i = h.useState;

    function a(a) {
        var e = a.checkPreviouslyInsertedCode,
            f = a.clearInputOnComplete,
            g = f === void 0 ? !1 : f;
        f = a.enableMasking;
        var h = a.focusRegionId,
            j = a.inputSize,
            k = a.onChange,
            l = a.onComplete;
        a = i(!1);
        var m = a[0],
            n = a[1];
        a = i(!0);
        var o = a[0],
            p = a[1];
        a = i("");
        var q = a[0],
            r = a[1];
        a = function(a) {
            p(!a)
        };
        var s = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                if (d("MWChatEncrypedBackupsNumericCodeValidation").numericCodeIsCompleted(a, j)) {
                    if (e != null) {
                        var b = e.onCodeMismatch,
                            c = e.previouslyInsertedCode;
                        c = c === a;
                        if (!c) {
                            b();
                            return
                        }
                    }
                    p(!0);
                    n(!0);
                    try {
                        yield l(a), g && r("")
                    } catch (a) {
                        r("")
                    } finally {
                        n(!1)
                    }
                }
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }();
        return [{
            disabled: m,
            enableMasking: f,
            focusRegionId: h,
            onChange: function(a) {
                var b = function() {
                    d("MWChatEncrypedBackupsNumericCodeValidation").numericCodeIsValid(a, j) && (r(a), k == null ? void 0 : k(a), c("promiseDone")(s(a)))
                };
                b()
            },
            onCompletionChange: a,
            size: j,
            value: q
        }, {
            clearNumericInput: function() {
                return r("")
            },
            disabled: o,
            focusOnInput: function() {
                d("FocusRegion.react").focusRegionById(h, d("focusScopeQueries").tabbableScopeQuery)
            },
            isLoading: m,
            onPress: function() {
                c("promiseDone")(s(q))
            }
        }]
    }
    g.useMWChatEncryptedBackupsNumericCode = a
}), 98);
__d("useMWEBFlowSourceContext", ["FBLogger", "MWChatEncryptedBackupsQPLSource.enum", "MWEBFlowSourceContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useContext;

    function a() {
        var a = j(c("MWEBFlowSourceContext")),
            b = a.source;
        return i(function() {
            if (b == null) {
                c("FBLogger")("labyrinth_web").mustfix("[labyrinth][web] source is null. Did you wrap your flow with MWEBFlowSourceContextProvider?");
                return c("MWChatEncryptedBackupsQPLSource.enum").UNKNOWN
            }
            return b
        }, [b])
    }
    g["default"] = a
}), 98);
__d("useMWChatEncryptedBackupsPinCodeRestore", ["CometRelay", "EBSMGating", "JSResourceForInteraction", "MWChatEncryptedBackupsLogging", "MWChatEncryptedBackupsQPLEvents", "MWChatEncryptedBackupsSetIsDialogPersistedContext", "MWEBODSEntityName.enum", "MWEBPinCodeSize", "MWEBUpsellDismissedEnum.facebook", "MWEncryptedBackupsLocalStorageEntryEnum", "QPLUserFlow", "asyncToGeneratorRuntime", "promiseDone", "react", "requireDeferred", "useLabyrinthLogging", "useMWChatEncryptedBackupsAddDevice", "useMWChatEncryptedBackupsNumericCode", "useMWEBFlowSourceContext", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    e = i || d("react");
    var j = e.useCallback,
        k = e.useContext,
        l = e.useEffect,
        m = e.useRef,
        n = e.useState,
        o = c("requireDeferred")("MWEBUseLocalStorage").__setRef("useMWChatEncryptedBackupsPinCodeRestore"),
        p = c("requireDeferred")("MWEncryptedBackupsSharedState").__setRef("useMWChatEncryptedBackupsPinCodeRestore"),
        q = c("requireDeferred")("mwEBGetPINSecretFromVesta").__setRef("useMWChatEncryptedBackupsPinCodeRestore"),
        r = c("requireDeferred")("updateUpsellsStateInRelayStore").__setRef("useMWChatEncryptedBackupsPinCodeRestore"),
        s = c("JSResourceForInteraction")("MWEncryptedBackupsHsmFleetMigrationGated").__setRef("useMWChatEncryptedBackupsPinCodeRestore");

    function a(a) {
        var e = a.clientID,
            f = a.focusRegionId,
            g = a.onSubmitPin,
            i = a.onSubmitPinFailure,
            t = a.onVestaComplete,
            u = d("CometRelay").useRelayEnvironment();
        a = n(!1);
        var v = a[0],
            w = a[1];
        a = n(!1);
        var x = a[0],
            y = a[1];
        a = n(!1);
        var z = a[0],
            A = a[1],
            B = m(!1);
        a = d("useLabyrinthLogging").useLabyrinthLoggingFlow();
        var C = a.startFlow,
            D = (h || (h = c("useReStore")))(),
            E = c("useMWEBFlowSourceContext")();
        a = n(!1);
        var F = a[0],
            G = a[1],
            H = k(c("MWChatEncryptedBackupsSetIsDialogPersistedContext")).setIsDialogPersisted;
        a = c("useMWChatEncryptedBackupsAddDevice")({
            hsmFleetMigrationResetPIN: j(function(a) {
                c("promiseDone")(s.load().then(function(b) {
                    b({
                        db: D,
                        environment: u,
                        pinCode: a,
                        startFlow: C
                    })
                }))
            }, [D, u, C]),
            onComplete: j(function() {
                var a;
                c("QPLUserFlow").addPoint((a = d("MWChatEncryptedBackupsQPLEvents")).restoreDeviceAuthQplEvent, "add_device_success");
                c("QPLUserFlow").addPoint(a.restoreQplEvent, "restore_auth_finished_and_dismissed");
                p.onReady(function(a) {
                    a = a.upsertEBSharedStateEntry;
                    c("promiseDone")(a({
                        db: D,
                        stateKey: c("MWEncryptedBackupsLocalStorageEntryEnum").ENCRYPTED_BACKUPS_RESTORED_SUCCESSFULLY
                    }))
                });
                o.onReady(function(a) {
                    var b = a.mwEBCreateLocalStorageEntry;
                    a = a.mwEBDeleteLocalStorageEntry;
                    b(c("MWEncryptedBackupsLocalStorageEntryEnum").MW_EB_HAS_RESTORED_IN_CURRENT_SESSION);
                    b(c("MWEncryptedBackupsLocalStorageEntryEnum").MW_EB_HAS_RESTORED_IN_CURRENT_SESSION_2);
                    a(c("MWEncryptedBackupsLocalStorageEntryEnum").EBSM_CORRUPTION_WIPE)
                });
                d("MWChatEncryptedBackupsLogging").endSuccess({
                    annotations: {
                        bool: {
                            is_backend_setup: d("EBSMGating").isBackendSetupSuccessfulForEBSM()
                        }
                    },
                    event: a.restoreQplEvent
                });
                d("MWChatEncryptedBackupsLogging").endSuccess({
                    event: a.restoreDeviceAuthQplEvent,
                    odsEntityName: c("MWEBODSEntityName.enum").MW_EB_PIN_RESTORE_AUTH
                });
                t();
                G(!1)
            }, [D, t]),
            onFailure: j(function(a) {
                i == null ? void 0 : i(), B.current = !0, y(!0), G(!1), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, a), d("MWChatEncryptedBackupsLogging").endFailure({
                    errorName: a,
                    event: d("MWChatEncryptedBackupsQPLEvents").restoreDeviceAuthQplEvent,
                    odsEntityName: c("MWEBODSEntityName.enum").MW_EB_PIN_RESTORE_AUTH
                }), c("promiseDone")(r.load(), function(a) {
                    a({
                        environment: u,
                        updateValue: d("MWEBUpsellDismissedEnum.facebook").MWEBUpsellDismissedStateEnum.NOT_DISMISSED
                    })
                }), H == null ? void 0 : H(!1)
            }, [u, i, H]),
            onInvalidRecoveryCode: j(function() {
                i == null ? void 0 : i(), B.current = !0, y(!0), G(!1), d("MWChatEncryptedBackupsLogging").endFailure({
                    errorName: "pin_code_restore_wrong_recovery_code",
                    event: d("MWChatEncryptedBackupsQPLEvents").restoreDeviceAuthQplEvent,
                    odsEntityName: c("MWEBODSEntityName.enum").MW_EB_PIN_RESTORE_AUTH
                }), c("QPLUserFlow").addPoint(d("MWChatEncryptedBackupsQPLEvents").restoreQplEvent, "pin_code_restore_wrong_recovery_code"), c("promiseDone")(r.load(), function(a) {
                    a({
                        environment: u,
                        updateValue: d("MWEBUpsellDismissedEnum.facebook").MWEBUpsellDismissedStateEnum.NOT_DISMISSED
                    })
                }), H == null ? void 0 : H(!1)
            }, [u, i, H])
        });
        var I = a[0];
        a = d("useMWChatEncryptedBackupsNumericCode").useMWChatEncryptedBackupsNumericCode({
            enableMasking: !0,
            focusRegionId: f,
            inputSize: d("MWEBPinCodeSize").EB_PIN_CODE_SIZE,
            onChange: function() {
                y(!1), A(!1), w(!1)
            },
            onComplete: function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    var b = (yield q.load());
                    yield b({
                        addDevice: I,
                        clientID: e,
                        environment: u,
                        getSourceFromContext: E,
                        onSubmitPin: g,
                        onSubmitPinFailure: i,
                        onVestaSecretFetch: function() {
                            c("promiseDone")(r.load(), function(a) {
                                a({
                                    environment: u,
                                    updateValue: d("MWEBUpsellDismissedEnum.facebook").MWEBUpsellDismissedStateEnum.UPSELLS_DISMISSED
                                })
                            }), H == null ? void 0 : H(!0)
                        },
                        pinCode: a,
                        productUseCase: "MSGR_ENC_BACKUP",
                        setIsInProgress: G,
                        setIsPinCodeIncorrect: w,
                        setIsVestaError: A,
                        startFlow: C
                    })
                });

                function f(b) {
                    return a.apply(this, arguments)
                }
                return f
            }()
        });
        f = a[0];
        a = a[1];
        var J = a.clearNumericInput,
            K = a.disabled;
        a = a.focusOnInput;
        l(function() {
            B.current && (J(), B.current = !1)
        }, [J]);
        return {
            focusOnInput: a,
            inputProps: f,
            isDisabled: (a = K) != null ? a : !1,
            isInProgress: F,
            isLabyrinthError: x,
            isPinCodeIncorrect: v,
            isVestaError: z
        }
    }
    g.useMWChatEncryptedBackupsPinCodeRestore = a
}), 98);
__d("useMWEBSetHasSeenNoticeMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7918563381593344"
}), null);
__d("useMWEBSetHasSeenNoticeMutation.graphql", ["useMWEBSetHasSeenNoticeMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
            alias: null,
            args: null,
            concreteType: "SetHasSeenEbAutoRestoreNoticeResponsePayload",
            kind: "LinkedField",
            name: "set_has_seen_eb_auto_restore_notice",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                concreteType: "Viewer",
                kind: "LinkedField",
                name: "viewer",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "__typename",
                    storageKey: null
                }],
                storageKey: null
            }],
            storageKey: null
        }];
        return {
            fragment: {
                argumentDefinitions: [],
                kind: "Fragment",
                metadata: null,
                name: "useMWEBSetHasSeenNoticeMutation",
                selections: a,
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [],
                kind: "Operation",
                name: "useMWEBSetHasSeenNoticeMutation",
                selections: a
            },
            params: {
                id: b("useMWEBSetHasSeenNoticeMutation_facebookRelayOperation"),
                metadata: {},
                name: "useMWEBSetHasSeenNoticeMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useMWEBSetHasSeenNotice", ["CometRelay", "react", "useMWEBSetHasSeenNoticeMutation.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (i || d("react")).useCallback;

    function a() {
        var a = d("CometRelay").useMutation(h !== void 0 ? h : h = b("useMWEBSetHasSeenNoticeMutation.graphql")),
            c = a[0];
        a[1];
        return j(function() {
            c({
                variables: {}
            })
        }, [c])
    }
    g["default"] = a
}), 98);