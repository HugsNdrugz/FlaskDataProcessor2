; /*FB_PKG_DELIM*/

__d("CometEventPermalinkTab", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        ABOUT: "about",
        DISCUSSION: "discussion",
        BRACKETS: "brackets",
        BROADCASTS: "broadcasts",
        PARTICIPANTS: "participants",
        STANDINGS: "standings",
        VIDEOS: "videos",
        PAID_ACCESS: "paid_access"
    });
    c = a;
    f["default"] = c
}), 66);
__d("CommunityBotEnabledStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        ENABLED: "ENABLED",
        NOT_ENABLED: "NOT_ENABLED"
    });
    f["default"] = a
}), 66);
__d("LSClearDiscoverableChatsParticipantsAndRanges", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(a) {
            return b.sequence([function(a) {
                return b.forEach(b.db.table(248).fetch(), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return b.forEach(b.db.table(249).fetch(), function(a) {
                    return a["delete"]()
                })
            }])
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxClearDiscoverableChatsParticipantsAndRangesStoredProcedure";
    e.exports = a
}), null);
__d("LSClearDiscoverableChatsParticipantsAndRangesStoredProcedure", ["LSClearDiscoverableChatsParticipantsAndRanges", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return c("LSClearDiscoverableChatsParticipantsAndRanges")(a)
    }
    g["default"] = a
}), 98);
__d("LSUpsertDiscoverableChatsParticipantsRanges", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(249).put({
                threadId: a[0],
                minName: "",
                source: a[4],
                maxName: a[5],
                isLoadingBefore: !1,
                isLoadingAfter: a[2],
                hasMoreBefore: !1,
                hasMoreAfter: a[1],
                nextPageCursor: a[3]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpsertDiscoverableChatsParticipantsRangesStoredProcedure";
    e.exports = a
}), null);
__d("LSFetchDiscoverableChatParticipants", ["LSIssueNewTask", "LSUpsertDiscoverableChatsParticipantsRanges"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var e = a.done;
                    a = a.value;
                    return e ? d[0] = c.i64.cast([0, 1]) : (b = a.item, d[7] = b.syncGroup, c.i64.neq(d[7], void 0) ? d[6] = d[7] : d[6] = c.i64.cast([0, 1]), d[0] = d[6])
                })
            }, function(d) {
                return c.storedProcedure(b("LSUpsertDiscoverableChatsParticipantsRanges"), a[0], !1, !0, "", a[2], a[3])
            }, function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var e = a.done;
                    a = a.value;
                    return e ? d[2] = c.i64.cast([0, 1]) : (b = a.item, d[7] = b.syncGroup, c.i64.neq(d[7], void 0) ? d[6] = d[7] : d[6] = c.i64.cast([0, 1]), d[2] = d[6])
                })
            }, function(e) {
                return d[4] = new c.Map(), d[4].set("thread_key", a[0]), d[4].set("cursor", a[1]), d[4].set("source", a[2]), d[4].set("sync_group", d[2]), d[5] = c.toJSON(d[4]), c.storedProcedure(b("LSIssueNewTask"), "fetch_discoverable_chat_participant_list", c.i64.cast([0, 110006]), d[5], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxFetchDiscoverableChatParticipantsStoredProcedure";
    e.exports = a
}), null);
__d("LSFetchDiscoverableChatParticipantsStoredProcedure", ["LSFetchDiscoverableChatParticipants", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSFetchDiscoverableChatParticipants")(b.threadKey, b.cursor, b.source, b.maxName, a)
    }
    g["default"] = a
}), 98);
__d("LSFetchDiscoverableChatsPersonalInboxInfo", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("thread_key", a[0]), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTask"), "fetch_discoverable_chats_personal_inbox_info", c.i64.cast([0, 110019]), d[1], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxFetchDiscoverableChatsPersonalInboxInfoStoredProcedure";
    e.exports = a
}), null);
__d("LSFetchDiscoverableChatsPersonalInboxInfoStoredProcedure", ["LSFetchDiscoverableChatsPersonalInboxInfo", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSFetchDiscoverableChatsPersonalInboxInfo")(b.threadKey, a)
    }
    g["default"] = a
}), 98);
__d("LSHideBroadcastChannelFromPersonalInbox", ["LSIssueNewTaskWithExtraOperations"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("thread_id", a[0]), d[0].set("entry_point", ""), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTaskWithExtraOperations"), "hide_broadcast_channel_from_personal_inbox", c.i64.cast([0, 110018]), d[1], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), void 0, c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxHideBroadcastChannelFromPersonalInboxStoredProcedure";
    e.exports = a
}), null);
__d("LSHideBroadcastChannelFromPersonalInboxStoredProcedure", ["LSHideBroadcastChannelFromPersonalInbox", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSHideBroadcastChannelFromPersonalInbox")(b.threadId, a)
    }
    g["default"] = a
}), 98);
__d("LSIssueBotsInfoFetch", ["LSIssueNewTaskAndGetTaskID"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("thread_key", a[0]), c.i64.gt(c.i64.cast([0, 0]), c.i64.cast([0, 0])) ? (d[4] = c.i64.of_float(Date.now()), d[1] = c.i64.add(d[4], c.i64.cast([0, 0]))) : d[1] = c.i64.cast([0, 0]), d[2] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTaskAndGetTaskID"), "fetch_bot_info", c.i64.cast([0, 571]), d[2], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, d[1], c.i64.cast([0, 0])).then(function(a) {
                return a = a, d[3] = a[0], a
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxIssueBotsInfoFetchStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueBotsInfoFetchStoredProcedure", ["LSIssueBotsInfoFetch", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSIssueBotsInfoFetch")(b.threadKey, a)
    }
    g["default"] = a
}), 98);
__d("LSShowBroadcastChannelInPersonalInbox", ["LSIssueNewTaskWithExtraOperations"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("thread_id", a[0]), d[0].set("entry_point", ""), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTaskWithExtraOperations"), "show_broadcast_channel_in_personal_inbox", c.i64.cast([0, 110017]), d[1], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), void 0, c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxShowBroadcastChannelInPersonalInboxStoredProcedure";
    e.exports = a
}), null);
__d("LSShowBroadcastChannelInPersonalInboxStoredProcedure", ["LSShowBroadcastChannelInPersonalInbox", "cr:8709"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return c("LSShowBroadcastChannelInPersonalInbox")(b.threadId, a)
    }
    g["default"] = a
}), 98);
__d("MWInboxInfoPhotoGalleryItemThumbnailContent.react", ["FDSImageCover.react", "I64", "LSIntEnum", "MWMediaGalleryVideoThumbnail.react", "MWThumbnailDurationPill", "MWVideoPlayerPlayButton.react", "MWXImage.react", "MessagingAttachmentType", "VideoPlayerPlayButton.react", "gkx", "justknobx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = h || d("react"),
        l = 1e6,
        m = 1e3,
        n = {
            videoThumbnailPlayIcon: {
                start: "xtzzx4i",
                left: null,
                right: null,
                position: "x10l6tqk",
                top: "xwa60dl",
                transform: "x11lhmoz",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.attachment,
            e = a.fallbackVideoUrl,
            f = a.mediaRenderQpl;
        a = a.previewUrl;
        var g = (i || (i = d("I64"))).equal(b.attachmentType, (j || (j = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").VIDEO));
        if (g) {
            g = (i || (i = d("I64"))).to_float((g = b.playableDurationMs) != null ? g : (i || (i = d("I64"))).zero);
            g = Math.round(g / (c("justknobx")._("3228") && g >= l ? Math.pow(m, 2) : m));
            var h = c("gkx")("7350") ? k.jsx(c("MWVideoPlayerPlayButton.react"), {
                isVisible: !0,
                size: "SMALL"
            }) : c("gkx")("769") ? k.jsx(c("VideoPlayerPlayButton.react"), {
                iconSize: "MEDIUM",
                isVisible: !0
            }) : k.jsx(c("MWXImage.react"), {
                src: "/images/video/play_48dp.png",
                xstyle: n.videoThumbnailPlayIcon
            });
            g = g > 0 ? k.jsx(c("MWThumbnailDurationPill"), {
                spacing: "TIGHT",
                videoDuration: g
            }) : null;
            return k.jsxs("div", {
                className: "x1rg5ohu x5yr21d xl1xv1r x1n2onr6 xh8yej3",
                children: [k.jsx(c("MWMediaGalleryVideoThumbnail.react"), {
                    alt: b.filename,
                    fallbackVideoUrl: (e = e) != null ? e : "",
                    mediaRenderQpl: f,
                    previewUrl: a
                }), c("gkx")("7350") === !0 ? g === null && h : h, g]
            })
        }
        return k.jsx(c("FDSImageCover.react"), {
            alt: (e = b.filename) != null ? e : "",
            onError: function() {
                return f == null ? void 0 : f.endFail("load-image-error")
            },
            onLoad: function() {
                return f == null ? void 0 : f.endSuccess()
            },
            src: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWMediaGalleryRenderQpl", ["MWMediaRenderQplUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return d("MWMediaRenderQplUtils").useCommonMediaRenderQplForAttachment(a, b, "gallery_view")
    }
    g.useMediaGalleryRenderQpl = a
}), 98);
__d("MWInboxInfoPhotoGalleryItem.react", ["fbt", "CometHeroHoldTrigger.react", "CometPlaceholder.react", "I64", "JSResourceForInteraction", "LSIntEnum", "LSMessagingThreadTypeUtil", "MAWGetIsMediaDownloadStatusEnabled", "MWInboxInfoPhotoGalleryItemThumbnailContent.react", "MWMediaGalleryRenderQpl", "MWMediaRenderQplUtils", "MWMessageListMediaPressableContainer.react", "MWV2AttachmentErrorPlaceholder.react", "MWV2AttachmentLoadingPlaceholder.react", "MessagingAttachmentType", "MessengerWebUXLogger", "cr:11024", "cr:7482", "gkx", "react", "useEmptyFunction", "useMWMediaViewerOpenQPLLogger", "useMWV2MediaViewerURL", "useMWXLazyDialog"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = i || (i = d("react")),
        m = i.useMemo,
        n = (e = b("cr:11024")) != null ? e : c("useEmptyFunction"),
        o = (e = b("cr:7482")) != null ? e : c("useEmptyFunction"),
        p = {
            attachmentContainer: {
                height: "x5yr21d",
                $$css: !0
            },
            errorPlaceholder: {
                borderTopStartRadius: "x168nmei",
                borderTopEndRadius: "x13lgxp2",
                borderBottomEndRadius: "x5pf9jr",
                borderBottomStartRadius: "xo71vjh",
                $$css: !0
            },
            loadingPlaceholder: {
                borderTopStartRadius: "x168nmei",
                borderTopEndRadius: "x13lgxp2",
                borderBottomEndRadius: "x5pf9jr",
                borderBottomStartRadius: "xo71vjh",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.attachment,
            e = a.getPlayableUrl,
            f = a.getPreviewUrl,
            g = a.navigateToRouteForMediaViewer,
            h = a.onPress;
        a = a.threadType;
        var i = d("MWMediaGalleryRenderQpl").useMediaGalleryRenderQpl(b, a),
            j = d("LSMessagingThreadTypeUtil").isArmadilloSecure(a),
            k = j && d("MAWGetIsMediaDownloadStatusEnabled").getIsMediaDownloadStatusEnabled() ? b : null;
        k = n(k, i);
        i.addAnnotations({
            string: {
                downloadStatus: k == null ? void 0 : k.downloadStatus
            }
        });
        k = m(function() {
            return [b]
        }, [b]);
        o({
            attachments: k,
            isSecure: j,
            mediaRenderQpl: i,
            triggerUIView: "gallery"
        });
        if (b.hasMedia === !1) {
            i == null ? void 0 : i.addPoint("loading_has_media_false");
            return l.jsxs(l.Fragment, {
                children: [l.jsx(c("MWV2AttachmentLoadingPlaceholder.react"), {
                    descriptionForLogging: "MWInboxInfoPhotoGalleryItem.NoMedia",
                    height: 512,
                    mediaRenderQpl: i,
                    width: 512,
                    xstyle: p.loadingPlaceholder
                }), l.jsx(c("CometHeroHoldTrigger.react"), {
                    description: "MWInboxInfoPhotoGalleryItem.NoMedia",
                    hold: !0
                })]
            })
        }
        k = function(a) {
            return l.jsx(c("MWV2AttachmentErrorPlaceholder.react"), {
                height: 512,
                width: 512,
                xstyle: p.errorPlaceholder
            })
        };
        return l.jsx(c("CometPlaceholder.react"), {
            fallback: l.jsx(c("MWV2AttachmentLoadingPlaceholder.react"), {
                descriptionForLogging: "MWInboxInfoPhotoGalleryItem.Suspense",
                height: 512,
                mediaRenderQpl: i,
                width: 512,
                xstyle: p.loadingPlaceholder
            }),
            name: "MWInboxInfoPhotoGalleryItem.Suspense",
            children: l.jsx(q, {
                attachment: b,
                getPlayableUrl: e,
                getPreviewUrl: f,
                isSecure: j,
                mediaRenderQpl: i,
                navigateToRouteForMediaViewer: g,
                onPress: h,
                renderUnsupportedAttachment: k,
                threadType: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function q(a) {
        var b = a.attachment,
            e = a.getPlayableUrl,
            f = a.getPreviewUrl,
            g = a.isSecure,
            i = a.mediaRenderQpl,
            m = a.navigateToRouteForMediaViewer,
            n = a.onPress,
            o = a.renderUnsupportedAttachment,
            q = a.threadType;
        f = (a = f(b, "MWInboxInfoPhotoGalleryItem", i)) != null ? a : "";
        a = Boolean(f) ? void 0 : e(b, "MWInboxInfoPhotoGalleryItem", i);
        e = c("useMWV2MediaViewerURL")(b);
        var r = c("useMWXLazyDialog")(c("JSResourceForInteraction")("MWV2MediaViewer.react").__setRef("MWInboxInfoPhotoGalleryItem.react")),
            s = r[0],
            t = r[1];
        r = (j || (j = d("I64"))).equal(b.attachmentType, (k || (k = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").VIDEO));
        var u = d("useMWMediaViewerOpenQPLLogger").useMWMediaViewerOpenQPLLogger(),
            v = c("MessengerWebUXLogger").useInteractionLogger();
        if (f == null || f.length === 0) {
            if (!r || !c("gkx")("3368")) {
                i == null ? void 0 : i.endFail("empty_preview_url");
                return (r = o == null ? void 0 : o(b)) != null ? r : null
            }
            if (a == null || a.length === 0) {
                i == null ? void 0 : i.endFail("empty_video_preview_and_playable_url");
                return (r = o == null ? void 0 : o(b)) != null ? r : null
            }
        }
        o = m ? {
            passthroughProps: {
                origSrc: f
            },
            url: e
        } : void 0;
        return l.jsx(c("MWMessageListMediaPressableContainer.react"), {
            ariaLabel: h._("__JHASH__mrw3CpFXi7r__JHASH__"),
            attachment: b,
            linkProps_: o,
            mediaRenderQpl: i,
            onHoverIn: function() {
                if (!m) return t()
            },
            onPress: function() {
                u.startFlow({
                    attachmentType: d("MWMediaRenderQplUtils").getAttachmentTypeStringFromEnum(b.attachmentType),
                    entryPoint: "media_gallery",
                    isSecure: g
                });
                v == null ? void 0 : v({
                    eventName: "open_media_viewer_from_gallery",
                    extraData: {
                        attachmentType: d("MWMediaRenderQplUtils").getAttachmentTypeStringFromEnum(b.attachmentType)
                    },
                    threadType: q
                });
                n != null && n(b);
                if (!m) return s({
                    attachment: b
                }, function() {})
            },
            overlayDisabled: !0,
            testid: void 0,
            xstyle: p.attachmentContainer,
            children: l.jsx(c("MWInboxInfoPhotoGalleryItemThumbnailContent.react"), {
                attachment: b,
                fallbackVideoUrl: a,
                mediaRenderQpl: i,
                previewUrl: f
            })
        })
    }
    q.displayName = q.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWSharedContentCommonFbt", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = h._("__JHASH__7iXxkHlQ-F-__JHASH__");
    g.armadilloMediaGalleryMissingMediaNoticeFbt = a
}), 226);
__d("MWInboxInfoSharedContentEmptyTab.react", ["fbt", "LSMessagingThreadTypeUtil", "LSThreadTitle.react", "MAWMediaGalleryM2Utils", "MWSharedContentCommonFbt", "MWXColumnItem.react", "MWXText.react", "ReQL", "ReQLSuspense", "deferredLoadComponent", "gkx", "react", "requireDeferred", "stylex", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = k || d("react"),
        m = c("deferredLoadComponent")(c("requireDeferred")("MWInboxMediaGalleryEBRestoreUpsell.react").__setRef("MWInboxInfoSharedContentEmptyTab.react")),
        n = {
            container: {
                paddingTop: "xy8btvn",
                position: "x1n2onr6",
                $$css: !0
            },
            containerOld: {
                paddingTop: "x1g7c3p3",
                position: "x1n2onr6",
                $$css: !0
            }
        };

    function o(a) {
        switch (a) {
            case "media":
                return "Photos and videos";
            case "files":
                return "Files";
            case "links":
                return "Links"
        }
    }

    function p(a, b, e) {
        var f = d("LSMessagingThreadTypeUtil").isArmadilloSecure(e.threadType);
        f = f && b === "media" && c("gkx")("2616") === !0;
        if (f && !a) return d("MWSharedContentCommonFbt").armadilloMediaGalleryMissingMediaNoticeFbt;
        f = o(b);
        if (d("LSMessagingThreadTypeUtil").isDiscoverableChannel(e.threadType)) return h._("__JHASH__PpijmwC5Lut__JHASH__", [h._enum(f, {
            "Photos and videos": "Photos and videos",
            Files: "Files",
            Links: "Links"
        })]);
        return d("LSMessagingThreadTypeUtil").isOneToOne(e.threadType) ? h._("__JHASH__6OltF4lnito__JHASH__", [h._enum(f, {
            "Photos and videos": "Photos and videos",
            Files: "Files",
            Links: "Links"
        }), h._param("name", l.jsx(c("LSThreadTitle.react"), {
            thread: e,
            wrapOutput: function(a, b) {
                return b
            }
        }))]) : h._("__JHASH__0YQmVoWIu6A__JHASH__", [h._enum(f, {
            "Photos and videos": "Photos and videos",
            Files: "Files",
            Links: "Links"
        })])
    }

    function a(a) {
        var b = a.backupState,
            e = a.contentType,
            g = a.threadKey,
            k = (i || (i = c("useReStore")))();
        a = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(k.tables.threads, ["threadType", "threadKey", "threadName"]).getKeyRange(g)
        }, [k, g], f.id + ":131");
        if (a == null) return null;
        var o = d("LSMessagingThreadTypeUtil").isArmadilloSecure(a.threadType),
            q = o && e === "media" && d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled();
        o = o && e === "files" && d("MAWMediaGalleryM2Utils").isFilesEBRestoreEnabled();
        q = q || o;
        o = h._("__JHASH__F8WROxnU5px__JHASH__", [h._enum(e, {
            media: "media",
            files: "files",
            links: "links"
        })]);
        a = p(q, e, a);
        b = b === 4;
        return l.jsxs("div", {
            className: (j || (j = c("stylex")))([q ? n.container : n.containerOld]),
            children: [l.jsx("div", {
                className: "xr1yuqi xkrivgy x4ii5y1 x1gryazu xwib8y2",
                children: q ? l.jsx(c("MWXText.react"), {
                    align: "center",
                    color: "primary",
                    type: "headlineEmphasized4",
                    children: o
                }) : l.jsx(c("MWXText.react"), {
                    align: "center",
                    color: "secondary",
                    type: "body2",
                    children: o
                })
            }), l.jsx("div", {
                className: "xr1yuqi xkrivgy x4ii5y1 x1gryazu xtxm24l x1y1aw1k x4uap5 xwib8y2 xkhd6sd",
                children: l.jsx(c("MWXText.react"), {
                    align: "center",
                    color: "secondary",
                    type: q ? "body4" : "body3",
                    children: a
                })
            }), q && b && l.jsx(c("MWXColumnItem.react"), {
                align: "center",
                paddingTop: 12,
                paddingVertical: 16,
                children: b && l.jsx(m, {
                    contentType: e
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWInboxInfoSharedContentTabWithFooter.react", ["MWXColumn.react", "MWXColumnItem.react", "MWXScrollableArea.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            content: {
                flexShrink: "xs83m0k",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.children,
            d = a.footer;
        a = a.shouldShowFooter;
        return i.jsxs(c("MWXColumn.react"), {
            expanding: !0,
            children: [i.jsx(c("MWXColumnItem.react"), {
                xstyle: j.content,
                children: i.jsx(c("MWXScrollableArea.react"), {
                    expanding: !0,
                    children: i.jsx("div", {
                        children: b
                    })
                })
            }), a ? i.jsx(c("MWXColumnItem.react"), {
                paddingHorizontal: 0,
                paddingVertical: 8,
                children: d
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxInfoPhotoGallery.react", ["CometErrorBoundary.react", "CometInfiniteScrollTrigger.react", "CometPhotoGrid.react", "CometProgressIndicator.react", "I64", "LSMessagingThreadTypeUtil", "MAWMediaGalleryM2Utils", "MWInboxInfoPhotoGalleryItem.react", "MWInboxInfoSharedContentEmptyTab.react", "MWInboxInfoSharedContentTabWithFooter.react", "MWSharedContentCommonFbt", "MWXColumnItem.react", "MWXText.react", "MessengerWebUXLogger", "cr:5008", "cr:8625", "deferredLoadComponent", "gkx", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react"));
    e = h;
    var k = e.Fragment,
        l = e.useState,
        m = c("deferredLoadComponent")(c("requireDeferred")("MWInboxMediaGalleryEBRestoreUpsell.react").__setRef("MWInboxInfoPhotoGallery.react")),
        n = c("deferredLoadComponent")(c("requireDeferred")("MWInboxMediaGalleryEBRestoreSyncBanner.react").__setRef("MWInboxInfoPhotoGallery.react")),
        o = {
            photoGridSpacingNormalizer: {
                marginTop: "xr9ek0c",
                marginEnd: "xfs2ol5",
                marginBottom: "xjpr12u",
                marginStart: "x12mruv9",
                $$css: !0
            },
            progressRingContainer: {
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginTop: "x1xmf6yo",
                paddingTop: "x123j3cw",
                paddingEnd: "x1mpkggp",
                paddingBottom: "xs9asl8",
                paddingStart: "x1t2a60a",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.backupState,
            d = a.hasMore,
            e = a.isLoading,
            f = a.isRestoringFromEB,
            g = a.media,
            h = a.threadType,
            i = a.threadKey;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["threadKey"]);
        h = c("MessengerWebUXLogger").useImpressionLoggerRef({
            eventName: "media_gallery_rendered",
            threadKey: i,
            threadType: h
        });
        return j.jsx("div", {
            className: "x78zum5 xdt5ytf x1iyjqo2 xs83m0k x2lwn1j x6ikm8r x10wlt62 x1swvt13 x1pi30zi",
            ref: h,
            children: g.length > 0 || d || e || f === !0 ? j.jsx(p, babelHelpers["extends"]({
                isRestoringFromEB: f,
                threadKey: i
            }, a, {
                backupState: b,
                navigateToRouteForMediaViewer: !1
            })) : j.jsx(c("MWInboxInfoSharedContentEmptyTab.react"), {
                backupState: b,
                contentType: "media",
                threadKey: i
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function p(a) {
        var e = a.backupState,
            f = a.getPlayableUrl,
            g = a.getPreviewUrl,
            h = a.hasMore,
            p = a.isBackButtonPressed;
        p = p === void 0 ? !1 : p;
        var q = a.isLoading,
            r = a.isRestoringFromEB,
            s = a.media,
            t = a.navigateToRouteForMediaViewer,
            u = t === void 0 ? !0 : t;
        t = a.onLoadMore;
        var v = a.onPressMedia,
            w = a.threadKey,
            x = a.threadType;
        a = a.uniformGrid;
        a = a === void 0 ? !0 : a;
        e = e === 4;
        var y = d("LSMessagingThreadTypeUtil").isArmadilloSecure(x),
            z = y && d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled(),
            A = l(!1),
            B = A[0],
            C = A[1];
        return j.jsx(c("MWInboxInfoSharedContentTabWithFooter.react"), {
            footer: z ? j.jsxs(j.Fragment, {
                children: [e && j.jsx(c("CometErrorBoundary.react"), {
                    fallback: function() {
                        return null
                    },
                    children: j.jsx(m, {
                        contentType: "media"
                    })
                }), r === !0 && j.jsx(n, {
                    contentType: "media"
                })]
            }) : j.jsx(c("MWXText.react"), {
                align: "center",
                color: "tertiary",
                type: "meta3",
                children: d("MWSharedContentCommonFbt").armadilloMediaGalleryMissingMediaNoticeFbt
            }),
            shouldShowFooter: (z ? !0 : s.length > 0) && y && !p && c("gkx")("2616") === !0,
            children: j.jsxs(c("MWXColumnItem.react"), {
                hidden: s.length === 0 && r === !0,
                paddingHorizontal: 4,
                paddingVertical: 4,
                children: [j.jsx("div", {
                    onContextMenu: c("gkx")("7066") ? function(a) {
                        a.altKey && (a.preventDefault(), C(!B))
                    } : void 0,
                    style: o.photoGridSpacingNormalizer,
                    title: c("gkx")("7066") && !B ? "alt + right click to show attachments debug buttons" : void 0,
                    children: j.jsx(c("CometPhotoGrid.react"), {
                        uniformGrid: a,
                        children: s.map(function(a) {
                            function e() {
                                if (y && (i || (i = d("I64"))).equal(a.threadKey, w) && b("cr:5008") != null) return j.jsx(b("cr:5008"), {
                                    attachment: a,
                                    getPlayableUrl: f,
                                    getPreviewUrl: g,
                                    navigateToRouteForMediaViewer: u,
                                    onPress: v,
                                    threadType: x
                                });
                                else return j.jsx(c("MWInboxInfoPhotoGalleryItem.react"), {
                                    attachment: a,
                                    getPlayableUrl: f,
                                    getPreviewUrl: g,
                                    navigateToRouteForMediaViewer: u,
                                    onPress: v,
                                    threadType: x
                                })
                            }
                            return j.jsxs(k, {
                                children: [e(), b("cr:8625") && B ? j.jsx(b("cr:8625"), {
                                    attachment: a
                                }) : null]
                            }, a.attachmentFbid + a.messageId)
                        })
                    })
                }), j.jsx(c("CometInfiniteScrollTrigger.react"), {
                    hasMore: h,
                    isLoading: q,
                    onLoadMore: t,
                    scrollMargin: 16,
                    xstyle: o.progressRingContainer,
                    children: j.jsx(c("CometProgressIndicator.react"), {
                        size: "default"
                    })
                })]
            })
        })
    }
    p.displayName = p.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useMAWResetAttachmensRangeOnUnmount", ["I64", "Int64Hooks", "LSIntEnum", "ReQL", "asyncToGeneratorRuntime", "gkx", "promiseDone", "useAsyncReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a, b) {
        var e = c("useAsyncReStore")();
        d("Int64Hooks").useEffectInt64(function() {
            return function() {
                c("gkx")("1338") === !0 && c("promiseDone")(j(e, a, b))
            }
        }, [e, a, b])
    }

    function j(a, b, c) {
        return k.apply(this, arguments)
    }

    function k() {
        k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c, e) {
            var g = (yield a),
                j = (h || (h = d("LSIntEnum"))).ofNumber(e);
            return g.runInTransaction(function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    var b = (yield d("ReQL").firstAsync(d("ReQL").fromTableDescending(g.tables.attachments_ranges_v2__generated).getKeyRange(c).filter(function(a) {
                        return (i || (i = d("I64"))).equal(a.mediaGroup, j)
                    })));
                    b != null && (yield a.attachments_ranges_v2__generated["delete"](c, j, b.minTimestampMs))
                });
                return function(b) {
                    return a.apply(this, arguments)
                }
            }(), "readwrite", "ui", void 0, f.id + ":58")
        });
        return k.apply(this, arguments)
    }
    g["default"] = a
}), 98);
__d("MAWCutoverInboxInfoSharedMediaTab.react", ["FBLogger", "I64", "LSThreadMediaGalleryGroup", "MAWThreadCutover", "MWInboxInfoPhotoGallery.react", "justknobx", "react", "recoverableViolation", "useMAWLoadMoreCutoverThreadSharedAttachments", "useMAWResetAttachmensRangeOnUnmount", "useMWV2MediaViewerOpenPlayableUrl", "useMWV2MediaViewerOpenPreviewUrl", "useMWV2MediaViewerSecurePlayableUrl", "useMWV2MediaViewerSecurePreviewUrl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react"));
    b = h;
    var k = b.useCallback,
        l = b.useEffect,
        m = b.useRef;

    function a(a) {
        var b = a.backupState,
            e = a.isBackButtonPressed,
            f = a.isRestoringFromEB,
            g = a.onFirstLoadedMedia,
            h = a.secureThreadKey;
        a = a.threadType;
        var n = d("MAWThreadCutover").useGetCutoverOpenThreadKey(h);
        n == null && c("FBLogger")("messenger_web_media").mustfix("Cutover open thread key is null for secure thread key: %s", (i || (i = d("I64"))).to_string(h));
        n = c("useMAWLoadMoreCutoverThreadSharedAttachments")(h, (n = n) != null ? n : (i || (i = d("I64"))).zero, a, {
            entrypoint: "media_gallery"
        }, c("LSThreadMediaGalleryGroup").PHOTOS_AND_VIDEOS, f, c("justknobx")._("1132"));
        var o = n.attachments,
            p = n.completedFirstLoad,
            q = n.hasMore,
            r = n.isLoadingMore;
        n = n.onLoadMore;
        var s = m(!1);
        l(function() {
            s.current === !1 && p === !0 && (s.current = !0, g(o))
        }, [p, o, g]);
        var t = c("useMWV2MediaViewerOpenPreviewUrl")(),
            u = c("useMWV2MediaViewerOpenPlayableUrl")(),
            v = c("useMWV2MediaViewerSecurePreviewUrl")(),
            w = c("useMWV2MediaViewerSecurePlayableUrl")(),
            x = k(function(a, b, d) {
                if (a.transportKey === "FBBroker" || a.transportKey === "FBLegacyBroker") {
                    var e;
                    e = (e = t(a, b)) != null ? e : "";
                    e === "" && c("FBLogger")("messenger_web_media").mustfix("Cutover Shared Media Gallery open media previewUrl is an empty string");
                    return e
                }
                a = (e = v(a, b, d)) != null ? e : "";
                a === "" && c("recoverableViolation")("Cutover Shared Media Gallery secure media previewUrl is an empty string", "messenger_web_media", void 0, {
                    trackOnly: !0
                });
                return a
            }, [t, v]),
            y = k(function(a, b, c) {
                if (a.transportKey === "FBBroker" || a.transportKey === "FBLegacyBroker") {
                    var d;
                    return (d = u(a, b)) != null ? d : ""
                }
                return (d = w(a, b, c)) != null ? d : ""
            }, [u, w]);
        c("useMAWResetAttachmensRangeOnUnmount")(h, c("LSThreadMediaGalleryGroup").PHOTOS_AND_VIDEOS);
        return j.jsx(c("MWInboxInfoPhotoGallery.react"), {
            backupState: b,
            getPlayableUrl: y,
            getPreviewUrl: x,
            hasMore: q,
            isBackButtonPressed: e,
            isLoading: r,
            isRestoringFromEB: f,
            media: o,
            navigateToRouteForMediaViewer: !1,
            onLoadMore: n,
            threadKey: h,
            threadType: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWXProgressRing.react", ["cr:6782", "cr:6783", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var c = a.color,
            d = a.percentage;
        a = a.size;
        if (b("cr:6782") != null) {
            var e;
            return i.jsx(b("cr:6782"), {
                color: (e = c) != null ? e : "light",
                percentage: (e = d) != null ? e : 0,
                size: (e = a) != null ? e : 16
            })
        }
        return b("cr:6783") != null ? i.jsx(b("cr:6783"), {
            color: c,
            percentage: d,
            size: a
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("mwReplaceToast", ["BaseToasterStateManager", "MWXToast.react", "err", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = c("BaseToasterStateManager").getInstance();

    function a(a) {
        var b = a.body,
            d = a.icon,
            e = a.startAddOn;
        e = e === void 0 ? null : e;
        var f = a.supressCloseButton;
        f = f === void 0 ? !1 : f;
        var g = a.title,
            h = a.toastId;
        if (h == null) {
            c("err")("toastId or toasterStateManager is not provided");
            return
        }
        j.replace(h, i.jsx(c("MWXToast.react"), {
            body: b,
            icon: d,
            onDismiss: function() {
                return j.expire(h)
            },
            startAddOn: e,
            supressCloseButton: f,
            title: g
        }))
    }
    g.mwReplaceToast = a
}), 98);
__d("MAWLoadingSpinner.react", ["BaseToasterStateManager", "MWXIconCheckmarkCircle", "MWXIconStrict.react", "MWXProgressRing.react", "MWXSpinner.react", "mwPushToast", "mwReplaceToast", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useEffect,
        k = b.useLayoutEffect,
        l = b.useRef,
        m = c("BaseToasterStateManager").getInstance();

    function n(a, b, d, e) {
        e === void 0 && (e = 0);
        if (a === "spinner") return {
            icon: {
                comet: i.jsx(c("MWXSpinner.react"), {
                    color: b ? "light" : "dark",
                    size: 24
                })
            },
            startAddOn: {
                type: "spinner"
            },
            title: d
        };
        else if (a === "progressRing") return {
            icon: {
                comet: i.jsx(c("MWXProgressRing.react"), {
                    color: b ? "light" : "dark",
                    size: 24
                })
            },
            startAddOn: {
                source: e,
                type: "progressRing"
            },
            title: d
        };
        else return {
            icon: {
                comet: i.jsx(c("MWXSpinner.react"), {
                    color: b ? "light" : "dark",
                    size: 24
                })
            },
            startAddOn: {
                type: "spinner"
            },
            title: d
        }
    }

    function o(a, b) {
        d("mwReplaceToast").mwReplaceToast({
            icon: {
                comet: i.jsx(c("MWXIconStrict.react"), {
                    icon: c("MWXIconCheckmarkCircle"),
                    size: 24
                }),
                mds: c("MWXIconCheckmarkCircle").component
            },
            title: b,
            toastId: a
        })
    }

    function a(a, b, e, f, g, h) {
        var i = l();
        k(function() {
            if (g) i.current == null ? i.current = d("mwPushToast").mwPushToast(n(a, b, e, h), Number.MAX_SAFE_INTEGER) : d("mwReplaceToast").mwReplaceToast(babelHelpers["extends"]({}, n(a, b, e, h), {
                toastId: i.current
            }));
            else if (i.current != null) {
                var j = i.current;
                o(j, f);
                c("setTimeout")(function() {
                    m.expire(j), i.current = void 0
                }, 2750)
            }
        }, [g, b, a, e, h, f]);
        j(function() {
            return function() {
                i.current != null && m.expire(i.current)
            }
        }, [])
    }
    g.useMAWLoadingSpinner = a
}), 98);
__d("MAWLoadingStateToastSelectors", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        return a.offlineQueueCount
    };
    b = function(a) {
        return a.offlineQueueProgressDownloaded
    };
    c = function(a) {
        return a.offlineQueueProgressProcessed
    };
    f.offlineQueueCountSelector = a;
    f.offlineQueueProgressCountSelector = b;
    f.offlineQueueConsumerProgressCountSelector = c
}), 66);
__d("MAWLoadingStateSpinner.react", ["fbt", "CometDarkModeContext", "MAWLoadingSpinner.react", "MAWLoadingStateToastSelectors", "MAWStateContext.react", "react", "useMAWOfflineQueueLoadingIndicator"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    i || (i = d("react"));
    b = i;
    e = b.memo;
    var j = b.useContext,
        k = function(a) {
            return h._("__JHASH__LlHcIvsh5It__JHASH__", [h._param("restoredPercentage", a.toFixed(0).toString())])
        },
        l = h._("__JHASH__EPxp6BXcf-B__JHASH__");

    function m(a, b, c) {
        if (c === 0) return 100;
        a = 50 * (a / c);
        b = 50 * (b / c);
        return Math.min(100, b + a)
    }

    function a() {
        var a = j(c("CometDarkModeContext")).currentSetting === "ENABLED",
            b = c("useMAWOfflineQueueLoadingIndicator")(!0),
            e = d("MAWStateContext.react").useMAWSelector(d("MAWLoadingStateToastSelectors").offlineQueueCountSelector),
            f = d("MAWStateContext.react").useMAWSelector(d("MAWLoadingStateToastSelectors").offlineQueueProgressCountSelector),
            g = d("MAWStateContext.react").useMAWSelector(d("MAWLoadingStateToastSelectors").offlineQueueConsumerProgressCountSelector);
        f = m(f, g, e);
        g = k(f);
        d("MAWLoadingSpinner.react").useMAWLoadingSpinner("progressRing", a, g, l, b, f);
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = e(a);
    g["default"] = b
}), 226);
__d("MAWMigrationStateToastSelector.react", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        return a.isDbMigrating
    };
    f.isDbMigratingSelector = a
}), 66);
__d("MAWMigrationStateSpinner.react", ["fbt", "CometDarkModeContext", "MAWLoadingSpinner.react", "MAWMigrationStateToastSelector.react", "MAWStateContext.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    i || (i = d("react"));
    b = i;
    e = b.memo;
    var j = b.useContext,
        k = h._("__JHASH__BcL_Hf5UaRM__JHASH__"),
        l = h._("__JHASH__UJ0S4v9Hktq__JHASH__");

    function a() {
        var a = j(c("CometDarkModeContext")).currentSetting === "ENABLED",
            b = d("MAWStateContext.react").useMAWSelector(d("MAWMigrationStateToastSelector.react").isDbMigratingSelector);
        d("MAWLoadingSpinner.react").useMAWLoadingSpinner("spinner", a, k, l, b);
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = e(a);
    g["default"] = b
}), 226);
__d("MWInboxInfoSharedContentFilePreview.react", ["fbt", "MDSSvgDocumentCompleteIcon.react", "MWChatMessageId", "MWXCircleButton.react", "MWXIconExclamationMarkCircle", "MWXIconRefreshAlt", "MWXIconStrict.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        var b = a.isError,
            e = a.isRetryableError,
            f = a.messageID;
        a = a.onRetry;
        if (b === !0) return j.jsx("div", {
            className: "x6s0dn4 xgx9qek x14yjl9h xudhj91 x18nykt9 xww2gxu x78zum5 x10w6t97 xl56j7k x1td3qas",
            children: e === !0 ? j.jsx(c("MWXCircleButton.react"), {
                color: "primary",
                icon: c("MWXIconRefreshAlt"),
                label: h._("__JHASH__BGxC_0TtXwE__JHASH__"),
                onPress: a,
                size: 24,
                type: "normal"
            }) : j.jsx("div", {
                children: j.jsx(c("MWXIconStrict.react"), {
                    color: "primary",
                    icon: c("MWXIconExclamationMarkCircle"),
                    size: 20
                })
            })
        });
        b = f != null ? d("MWChatMessageId").getMessageId(f) : void 0;
        return b == null ? null : j.jsx(c("MDSSvgDocumentCompleteIcon.react"), {
            color: "primary",
            size: 24
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWInboxInfoSharedContentFile.react", ["fbt", "I64", "MWFilePressable.react", "MWInboxInfoSharedContentFilePreview.react", "MWXRow.react", "MWXRowItem.react", "MWXTextPairing.react", "formatFileSize", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = i || d("react"),
        l = {
            contentRowItem: {
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            filePressable: {
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                $$css: !0
            },
            fileRow: {
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                $$css: !0
            },
            iconRowItem: {
                backgroundColor: "xlhe6ec",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                height: "xdd8jsf",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "xyinxu5",
                paddingEnd: "xmns6w2",
                paddingBottom: "x1g2khh7",
                paddingStart: "xpkgp8e",
                width: "xvni27",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.attachmentID,
            e = a.fileName,
            f = a.fileSize,
            g = a.messageID,
            i = a.onPress;
        a = a.url;
        e = e != null ? e : h._("__JHASH__uiTAWyhPCWI__JHASH__");
        f = f != null ? (j || (j = d("I64"))).to_int32(f) : void 0;
        f = f != null ? c("formatFileSize")(f) : null;
        return k.jsx(c("MWFilePressable.react"), {
            attachmentID: b,
            entryPoint: "inbox_info_v1",
            mediaRenderQpl: null,
            messageID: g,
            onPress: i,
            url: a,
            xstyle: l.filePressable,
            children: k.jsxs(c("MWXRow.react"), {
                expanding: !0,
                paddingTop: 0,
                verticalAlign: "center",
                xstyle: l.fileRow,
                children: [k.jsx(c("MWXRowItem.react"), {
                    xstyle: l.iconRowItem,
                    children: k.jsx(c("MWInboxInfoSharedContentFilePreview.react"), {
                        messageID: g
                    })
                }), k.jsx(c("MWXRowItem.react"), {
                    expanding: !0,
                    xstyle: l.contentRowItem,
                    children: k.jsx(c("MWXTextPairing.react"), {
                        body: f,
                        bodyColor: "secondary",
                        headline: e,
                        headlineLineLimit: 1,
                        level: 4
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWInboxInfoSharedContentTheme", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        divider: "var(--hover-overlay)"
    };
    b = {
        divider: "var(--hover-overlay)"
    };
    c = {
        dark: b,
        light: a,
        type: "VARIABLES"
    };
    f.config = c
}), 66);
__d("MWInboxInfoFileGallery.react", ["BaseTheme.react", "CometErrorBoundary.react", "CometInfiniteScrollTrigger.react", "CometProgressIndicator.react", "I64", "LSMediaUrlAttachment", "LSMessagingThreadTypeUtil", "MAWMediaGalleryM2Utils", "MWChatMessageId", "MWInboxInfoSharedContentEmptyTab.react", "MWInboxInfoSharedContentFile.react", "MWInboxInfoSharedContentTabWithFooter.react", "MWInboxInfoSharedContentTheme", "MWXColumn.react", "MWXColumnItem.react", "MessengerWebUXLogger", "cr:4856", "deferredLoadComponent", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || d("react"),
        k = c("deferredLoadComponent")(c("requireDeferred")("MWInboxMediaGalleryEBRestoreUpsell.react").__setRef("MWInboxInfoFileGallery.react")),
        l = c("deferredLoadComponent")(c("requireDeferred")("MWInboxMediaGalleryEBRestoreSyncBanner.react").__setRef("MWInboxInfoFileGallery.react")),
        m = {
            progressIndicator: {
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginTop: "x1xmf6yo",
                paddingTop: "x123j3cw",
                paddingEnd: "x1mpkggp",
                paddingBottom: "xs9asl8",
                paddingStart: "x1t2a60a",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.backupState,
            d = a.files,
            e = a.hasMore,
            f = a.isRestoringFromEB,
            g = a.threadType,
            h = a.threadKey;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["threadKey"]);
        g = c("MessengerWebUXLogger").useImpressionLoggerRef({
            eventName: "file_gallery_rendered",
            threadKey: h,
            threadType: g
        });
        return j.jsx("div", {
            className: "x78zum5 xdt5ytf x1iyjqo2 xs83m0k x2lwn1j x1swvt13 x1pi30zi",
            ref: g,
            children: d.length === 0 && !e && f !== !0 ? j.jsx(c("MWInboxInfoSharedContentEmptyTab.react"), {
                backupState: b,
                contentType: "files",
                threadKey: h
            }) : j.jsx(n, babelHelpers["extends"]({
                isRestoringFromEB: f
            }, a, {
                backupState: b,
                threadKey: h
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function n(a) {
        var e = a.backupState,
            f = a.files,
            g = a.hasMore,
            h = a.isLoading,
            n = a.isRestoringFromEB,
            o = a.onLoadMore,
            p = a.onPressFile,
            q = a.threadKey,
            r = a.threadType;
        a = e === 4;
        var s = d("LSMessagingThreadTypeUtil").isArmadilloSecure(r);
        e = s && d("MAWMediaGalleryM2Utils").isFilesEBRestoreEnabled();
        var t = c("MessengerWebUXLogger").useInteractionLogger();
        return j.jsx(c("MWInboxInfoSharedContentTabWithFooter.react"), {
            footer: e === !0 && j.jsxs(j.Fragment, {
                children: [a && j.jsx(c("CometErrorBoundary.react"), {
                    fallback: function() {
                        return null
                    },
                    children: j.jsx(k, {
                        contentType: "files"
                    })
                }), n === !0 && j.jsx(l, {
                    contentType: "files"
                })]
            }),
            shouldShowFooter: e,
            children: j.jsx(c("BaseTheme.react"), {
                config: d("MWInboxInfoSharedContentTheme").config,
                children: j.jsxs(c("MWXColumn.react"), {
                    hasDividers: !0,
                    hidden: f.length === 0 && n === !0,
                    paddingVertical: 8,
                    spacing: 20,
                    children: [f.map(function(a) {
                        if (s && (i || (i = d("I64"))).equal(a.threadKey, q) && b("cr:4856") != null) return j.jsx(c("MWXColumnItem.react"), {
                            children: j.jsx(b("cr:4856"), {
                                file: a,
                                onPress: function() {
                                    t == null ? void 0 : t({
                                        eventName: "open_file_from_gallery",
                                        threadType: r
                                    })
                                },
                                threadType: r
                            })
                        }, a.messageId);
                        else return j.jsx(c("MWXColumnItem.react"), {
                            children: j.jsx(c("MWInboxInfoSharedContentFile.react"), {
                                attachmentID: a.attachmentFbid,
                                fileName: a.filename,
                                fileSize: a.filesize,
                                messageID: d("MWChatMessageId").makeSent((i || (i = d("I64"))).to_string(a.threadKey), a.messageId, i.to_string(a.timestampMs)),
                                onPress: function() {
                                    t == null ? void 0 : t({
                                        eventName: "open_file_from_gallery",
                                        threadType: r
                                    }), p != null && p(a)
                                },
                                url: d("LSMediaUrlAttachment").playableUrl(a)
                            }, a.attachmentFbid)
                        }, a.attachmentFbid)
                    }), j.jsx(c("MWXColumnItem.react"), {
                        children: j.jsx(c("CometInfiniteScrollTrigger.react"), {
                            hasMore: g,
                            isLoading: h,
                            onLoadMore: o,
                            xstyle: m.progressIndicator,
                            children: j.jsx(c("CometProgressIndicator.react"), {
                                size: "default"
                            })
                        })
                    }, "infinite_scroll_trigger")]
                })
            })
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWSecureInboxInfoSharedFilesTab.react", ["LSThreadMediaGalleryGroup", "MAWDbMsg", "MAWMediaGalleryM2Utils", "MWInboxInfoFileGallery.react", "MWSharedAttachmentsSectionHooks", "justknobx", "react", "useMAWLoadMoreThreadSharedAttachments", "useMAWResetAttachmensRangeOnUnmount", "useMWMediaLoadingQplLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useEffect,
        k = b.useRef;

    function a(a) {
        var b, e = a.backupState,
            f = a.isRestoringFromEB,
            g = a.onFirstLoadedMedia;
        a = a.thread;
        var h = d("MWSharedAttachmentsSectionHooks").useQueryFileAttachments(a.threadKey, {
                removeUnsentMessages: !d("MAWMediaGalleryM2Utils").isFilesEBRestoreEnabled()
            }),
            l = h[0];
        h[1];
        var m = h[2],
            n = h[3];
        h = h[4];
        b = (b = h) != null ? b : !0;
        var o = (m == null ? void 0 : m.lastLoadedMessageId) != null ? d("MAWDbMsg").toMsgId(m == null ? void 0 : m.lastLoadedMessageId) : void 0,
            p = c("useMWMediaLoadingQplLogger")({
                entrypoint: "file_gallery",
                threadType: a.threadType
            });
        n = c("useMAWLoadMoreThreadSharedAttachments")(a.threadKey, h, n, d("MAWMediaGalleryM2Utils").isFilesEBRestoreEnabled() ? (h = o) != null ? h : void 0 : void 0, p.logLoadMediaStart, c("LSThreadMediaGalleryGroup").FILES_ONLY, c("justknobx")._("1132"));
        var q = k(!1);
        o = d("MWSharedAttachmentsSectionHooks").useLoader({
            attachmentsRange: m,
            hasMore: b,
            loadMore: n,
            logLoadMediaCancel: p.logLoadMediaCancel,
            logLoadMediaSuccess: p.logLoadMediaSuccess,
            media: l
        });
        h = o[0];
        m = o[1];
        var r = o[2];
        c("useMAWResetAttachmensRangeOnUnmount")(a.threadKey, c("LSThreadMediaGalleryGroup").FILES_ONLY);
        j(function() {
            q.current === !1 && r === !0 && (q.current = !0, g(l))
        }, [r, l, g]);
        return i.jsx(c("MWInboxInfoFileGallery.react"), {
            backupState: e,
            files: l,
            hasMore: b,
            isLoading: h,
            isRestoringFromEB: f,
            onLoadMore: m,
            threadKey: a.threadKey,
            threadType: a.threadType
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxInfoListItem.react", ["MWXColumnItem.react", "MWXPressable.react", "MWXRow.react", "MWXRowItem.react", "MWXTextPairing.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo,
        k = {
            containerRow: {
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                $$css: !0
            },
            contentItem: {
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            mediaItem: {
                alignItems: "x6s0dn4",
                backgroundColor: "xlhe6ec",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                display: "x78zum5",
                height: "xdd8jsf",
                justifyContent: "xl56j7k",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                width: "xvni27",
                $$css: !0
            },
            pressable: {
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.mediaElement,
            d = a.onPress,
            e = a.subtitle,
            f = a.title,
            g = a.url;
        a = j(function() {
            return {
                target: "_blank",
                url: g
            }
        }, [g]);
        return i.jsx(c("MWXColumnItem.react"), {
            children: i.jsx(c("MWXPressable.react"), {
                display: "inline",
                linkProps: a,
                onPress: d,
                overlayDisabled: !0,
                xstyle: function() {
                    return [k.pressable]
                },
                children: i.jsxs(c("MWXRow.react"), {
                    expanding: !0,
                    verticalAlign: "center",
                    xstyle: k.containerRow,
                    children: [i.jsx(c("MWXRowItem.react"), {
                        xstyle: k.mediaItem,
                        children: b
                    }), i.jsx(c("MWXRowItem.react"), {
                        expanding: !0,
                        xstyle: k.contentItem,
                        children: i.jsx(c("MWXTextPairing.react"), {
                            body: e,
                            bodyColor: "secondary",
                            headline: f,
                            headlineLineLimit: 1,
                            level: 4
                        })
                    })]
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.MWInboxInfoListItem = a
}), 98);
__d("MWInboxInfoSharedLink.react", ["CometPlaceholder.react", "FDSImageCover.react", "LSMediaUrlAttachment", "MWInboxInfoListItem.react", "MWMediaGalleryRenderQpl", "MWV2AttachmentLoadingPlaceholder.react", "MWXIconLink", "MWXIconStrict.react", "ReQL", "ReQLSuspense", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useEffect,
        l = 60,
        m = 350,
        n = {
            loadingPlaceholder: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.attachment,
            e = a.onPress;
        a = a.threadType;
        a = d("MWMediaGalleryRenderQpl").useMediaGalleryRenderQpl(b, a);
        return j.jsx(c("CometPlaceholder.react"), {
            fallback: j.jsx(c("MWV2AttachmentLoadingPlaceholder.react"), {
                descriptionForLogging: "MWInboxInfoSharedLink.Suspense",
                height: l,
                mediaRenderQpl: a,
                width: m,
                xstyle: n.loadingPlaceholder
            }),
            name: "MWInboxInfoSharedLink.Suspense",
            children: j.jsx(o, {
                attachment: b,
                mediaRenderQpl: a,
                onPress: e
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function o(a) {
        var b, e, g = a.attachment,
            i = a.mediaRenderQpl;
        a = a.onPress;
        var l = (h || (h = c("useReStore")))(),
            m = d("ReQLSuspense").useFirst(function() {
                var a = g.defaultCtaId;
                return a != null ? d("ReQL").fromTableAscending(l.tables.attachment_ctas).getKeyRange(a) : d("ReQL").empty()
            }, [l, g.defaultCtaId], f.id + ":76"),
            n = d("LSMediaUrlAttachment").previewUrl(g),
            o = d("LSMediaUrlAttachment").faviconUrl(g);
        k(function() {
            n == null && o == null && (i == null ? void 0 : i.endSuccess())
        }, [n, o, i]);
        m = m == null ? void 0 : m.actionUrl;
        if (m == null) return null;
        b = (b = g.titleText) != null ? b : m;
        e = (e = g.accessibilitySummaryText) != null ? e : b;
        e = n != null ? j.jsx(c("FDSImageCover.react"), {
            alt: e,
            onError: function() {
                return i == null ? void 0 : i.endFail("load-image-error")
            },
            onLoad: function() {
                return i == null ? void 0 : i.endSuccess()
            },
            src: n
        }) : o != null ? j.jsx(c("FDSImageCover.react"), {
            alt: e,
            onError: function() {
                return i == null ? void 0 : i.endFail("load-image-error")
            },
            onLoad: function() {
                return i == null ? void 0 : i.endSuccess()
            },
            src: o
        }) : j.jsx(c("MWXIconStrict.react"), {
            color: "primary",
            icon: c("MWXIconLink"),
            size: 16
        });
        return j.jsx(d("MWInboxInfoListItem.react").MWInboxInfoListItem, {
            mediaElement: e,
            onPress: a,
            subtitle: (e = g.subtitleText) != null ? e : "",
            title: b,
            url: m
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWSecureInboxInfoSharedLinksTab.react", ["BaseTheme.react", "CometInfiniteScrollTrigger.react", "CometProgressIndicator.react", "LSThreadMediaGalleryGroup", "MWInboxInfoSharedContentEmptyTab.react", "MWInboxInfoSharedContentTheme", "MWInboxInfoSharedLink.react", "MWSharedAttachmentsSectionHooks", "MWXColumn.react", "MWXColumnItem.react", "emptyFunction", "gkx", "justknobx", "react", "useMAWLoadMoreThreadSharedAttachments", "useMAWResetAttachmensRangeOnUnmount"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            progressIndicator: {
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginTop: "x1xmf6yo",
                paddingTop: "x123j3cw",
                paddingEnd: "x1mpkggp",
                paddingBottom: "xs9asl8",
                paddingStart: "x1t2a60a",
                $$css: !0
            }
        };

    function a(a) {
        var b, e = a.thread;
        a = d("MWSharedAttachmentsSectionHooks").useQueryLinkAttachments(e.threadKey, {
            removeUnsentMessages: !0
        });
        var f = a[0];
        a[1];
        var g = a[2],
            h = a[3];
        a = a[4];
        b = (b = a) != null ? b : !c("gkx")("2616");
        a = c("useMAWLoadMoreThreadSharedAttachments")(e.threadKey, a, h, void 0, void 0, c("LSThreadMediaGalleryGroup").LINKS, c("justknobx")._("1132"));
        h = d("MWSharedAttachmentsSectionHooks").useLoader({
            attachmentsRange: g,
            hasMore: b,
            loadMore: a,
            media: f
        });
        g = h[0];
        a = h[1];
        c("useMAWResetAttachmensRangeOnUnmount")(e.threadKey, c("LSThreadMediaGalleryGroup").LINKS);
        return f.length === 0 && !b ? i.jsx(c("MWInboxInfoSharedContentEmptyTab.react"), {
            contentType: "links",
            threadKey: e.threadKey
        }) : i.jsx(c("BaseTheme.react"), {
            config: d("MWInboxInfoSharedContentTheme").config,
            children: i.jsxs(c("MWXColumn.react"), {
                hasDividers: !0,
                paddingHorizontal: 16,
                paddingVertical: 8,
                spacing: 20,
                children: [f.map(function(a) {
                    return i.jsx(c("MWXColumnItem.react"), {
                        children: i.jsx(c("MWInboxInfoSharedLink.react"), {
                            attachment: a,
                            onPress: c("emptyFunction"),
                            threadType: e.threadType
                        })
                    }, a.messageId)
                }), i.jsx(c("MWXColumnItem.react"), {
                    children: i.jsx(c("CometInfiniteScrollTrigger.react"), {
                        hasMore: b,
                        isLoading: g,
                        onLoadMore: a,
                        xstyle: j.progressIndicator,
                        children: i.jsx(c("CometProgressIndicator.react"), {
                            size: "default"
                        })
                    })
                }, "infinite_scroll_trigger")]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWSecureInboxInfoSharedMediaTab.react", ["LSThreadMediaGalleryGroup", "MAWDbMsg", "MWInboxInfoPhotoGallery.react", "MWSharedAttachmentsSectionHooks", "gkx", "justknobx", "react", "recoverableViolation", "useMAWLoadMoreThreadSharedAttachments", "useMAWQuerySecureMediaAttachments", "useMAWResetAttachmensRangeOnUnmount", "useMWMediaLoadingQplLogger", "useMWV2MediaViewerSecurePlayableUrl", "useMWV2MediaViewerSecurePreviewUrl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useEffect,
        l = b.useRef;

    function a(a) {
        var b, e = a.backupState,
            f = a.isBackButtonPressed,
            g = a.isRestoringFromEB,
            h = a.onFirstLoadedMedia;
        a = a.thread;
        var m = l(!1),
            n = d("useMAWQuerySecureMediaAttachments").useMAWQuerySecureMediaAttachments(a.threadKey, {
                removeUnsentMessages: !c("gkx")("2616")
            }),
            o = n[0];
        n[1];
        var p = n[2],
            q = n[3];
        n = n[4];
        b = (b = n) != null ? b : !0;
        var r = (p == null ? void 0 : p.lastLoadedMessageId) != null ? d("MAWDbMsg").toMsgId(p == null ? void 0 : p.lastLoadedMessageId) : void 0,
            s = c("useMWMediaLoadingQplLogger")({
                entrypoint: "media_gallery",
                threadType: a.threadType
            });
        q = c("useMAWLoadMoreThreadSharedAttachments")(a.threadKey, n, q, c("gkx")("2616") === !0 ? (n = r) != null ? n : void 0 : void 0, s.logLoadMediaStart, c("LSThreadMediaGalleryGroup").PHOTOS_AND_VIDEOS, c("justknobx")._("1132"));
        r = d("MWSharedAttachmentsSectionHooks").useLoader({
            attachmentsRange: p,
            hasMore: b,
            loadMore: q,
            logLoadMediaCancel: s.logLoadMediaCancel,
            logLoadMediaSuccess: s.logLoadMediaSuccess,
            media: o
        });
        n = r[0];
        p = r[1];
        var t = r[2];
        k(function() {
            m.current === !1 && t === !0 && (m.current = !0, h(o))
        }, [t, o, h]);
        var u = c("useMWV2MediaViewerSecurePreviewUrl")();
        q = c("useMWV2MediaViewerSecurePlayableUrl")();
        s = j(function(a, b, d) {
            a = u(a, b, d);
            a === "" && c("recoverableViolation")("MAW Shared Media Gallery previewUrl is an empty string", "messenger_web_media", void 0, {
                trackOnly: !0
            });
            return a
        }, [u]);
        c("useMAWResetAttachmensRangeOnUnmount")(a.threadKey, c("LSThreadMediaGalleryGroup").PHOTOS_AND_VIDEOS);
        return i.jsx(c("MWInboxInfoPhotoGallery.react"), {
            backupState: e,
            getPlayableUrl: q,
            getPreviewUrl: s,
            hasMore: b,
            isBackButtonPressed: f,
            isLoading: n,
            isRestoringFromEB: g,
            media: o,
            navigateToRouteForMediaViewer: !1,
            onLoadMore: p,
            threadKey: a.threadKey,
            threadType: a.threadType
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWUnsupportedIndexedDBNuxKey", ["WebStorage"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = "maw_unsupported_browser_nux_dismissed",
        j = "dismissed";
    a = function() {
        var a;
        return ((a = (h || (h = c("WebStorage"))).getLocalStorageForRead()) == null ? void 0 : a.getItem(i)) === j
    };
    b = function() {
        var a;
        (a = (h || (h = c("WebStorage"))).getLocalStorage()) == null ? void 0 : a.setItem(i, j)
    };
    g.getIsDismissed = a;
    g.setIsDismissed = b
}), 98);
__d("MAWUserVisibleErrorsNux.react", ["ix", "MAWLoggerUtils", "MWXIconCautionTriangle", "MWXQPCard.react", "QPLUserFlow", "gkx", "qpl", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useEffect;

    function a(a) {
        var b = a.hasNoMargin,
            e = a.nuxBodyText,
            f = a.nuxButtonProps,
            g = a.nuxTitleText;
        a = a.onCloseButtonClick;
        var i = d("MAWLoggerUtils").getInstanceKey();
        k(function() {
            c("QPLUserFlow").start(c("qpl")._(1056846286, "652"), {
                annotations: {
                    string: {
                        nuxTitleText: g.toString()
                    }
                },
                instanceKey: i
            });
            return function() {
                return c("QPLUserFlow").endSuccess(c("qpl")._(1056846286, "652"), {
                    instanceKey: i
                })
            }
        }, [i, g]);
        var l = c("gkx")("4425") ? h("428841") : h("212797"),
            m = c("gkx")("4425") ? {
                props: {
                    src: h("1745665")
                },
                type: "image"
            } : {
                props: {
                    color: "negative",
                    icon: c("MWXIconCautionTriangle"),
                    size: 24
                },
                type: "icon"
            };
        return j.jsx("div", {
            "data-testid": void 0,
            children: j.jsx(c("MWXQPCard.react"), {
                addOnPrimary: f,
                body: e,
                hasNoMargin: b,
                headline: g,
                icon: c("gkx")("23219") ? {
                    props: {
                        src: l
                    },
                    type: "image"
                } : m,
                onClose: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWUserVisibleErrorsNuxWrapper.react", ["fbt", "CometPlaceholder.react", "MAWIssueNewUserVisibleErrors", "MAWUnsupportedIndexedDBNuxKey", "asyncToGeneratorRuntime", "cr:4216", "cr:9767", "promiseDone", "react", "requireDeferred", "useMAWGetUserVisibleErrors", "useMAWUnsupportedBrowserNUX"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react"));
    e = i;
    var k = e.useCallback,
        l = e.useState,
        m = c("requireDeferred")("MAWEncryptionErrorHandler").__setRef("MAWUserVisibleErrorsNuxWrapper.react");

    function a(a) {
        var e = a.children;
        a = a.hasNoMargin;
        var f = l(d("MAWUnsupportedIndexedDBNuxKey").getIsDismissed()),
            g = f[0],
            i = f[1];
        f = (f = b("cr:4216").buildUri({
            cms_id: "597429858389632"
        }).setDomain("www.facebook.com")) == null ? void 0 : (f = f.setProtocol("https")) == null ? void 0 : f.toString();
        f = {
            label: h._("__JHASH__W_KwwnBzw9K__JHASH__"),
            linkProps: {
                target: "_blank",
                url: f
            }
        };
        var n = d("useMAWUnsupportedBrowserNUX").useMAWUnsupportedBrowserNUX();
        n = n.shouldShowQP;
        var o = l(!1),
            p = o[0],
            q = o[1];
        o = c("useMAWGetUserVisibleErrors")();
        var r = o[0],
            s = o[1];
        o = k(function() {
            c("promiseDone")(b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                q(!0);
                if ((r == null ? void 0 : r.errorExtraData) === "MAWEARKeychainDecryptionError") {
                    var a = (yield m.load());
                    yield a.handleEARKeychainError()
                }
                return s()
            })(), function() {
                window.location.reload(!0)
            }, function() {
                q(!1)
            })
        }, [s, r]);
        var t = d("MAWIssueNewUserVisibleErrors").errorMsgBodyToFbtMap.get(r == null ? void 0 : r.errorBodyText),
            u = d("MAWIssueNewUserVisibleErrors").errorMsgTitleToFbtMap.get(r == null ? void 0 : r.errorTitleText);
        return j.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            name: "MAWUserVisibleErrorsNuxWrapper",
            children: b("cr:9767") && n && !g ? j.jsx(b("cr:9767"), {
                hasNoMargin: a,
                nuxBodyText: d("MAWIssueNewUserVisibleErrors").MAWUnsupportedIndexedDBErrorMsg,
                nuxButtonProps: f,
                nuxTitleText: d("MAWIssueNewUserVisibleErrors").MAWUnsupportedIndexedDBErrorMsgTitle,
                onCloseButtonClick: function() {
                    i(!0), d("MAWUnsupportedIndexedDBNuxKey").setIsDismissed()
                }
            }) : r && b("cr:9767") && u != null && t != null ? j.jsx(b("cr:9767"), {
                nuxBodyText: t,
                nuxButtonProps: {
                    disabled: p,
                    label: h._("__JHASH__PnVpnKg9Gg___JHASH__"),
                    loading: p,
                    onPress: o
                },
                nuxTitleText: u,
                onCloseButtonClick: function() {
                    c("promiseDone")(s())
                }
            }) : e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWAddMemberToGroupListCell.react", ["fbt", "MWXIconForListCell.react", "MWXIconFriendGenericAdd", "MWXListCellPressable.react", "MWXText.react", "react", "useMWAddParticipantDialog"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        var b = a.testid;
        b = a.thread;
        var d = c("useMWAddParticipantDialog")(b.threadKey, b.threadType);
        a = {
            eventName: "open_add_members_dialog",
            threadKey: b.threadKey,
            threadType: b.threadType
        };
        return j.jsx(c("MWXListCellPressable.react"), {
            addOnStart: j.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconFriendGenericAdd"),
                size: "large"
            }),
            content: j.jsx(c("MWXText.react"), {
                type: "headline4",
                children: h._("__JHASH__P1CnLTqi4fK__JHASH__")
            }),
            loggingEvent: a,
            onPress: function() {
                return d()
            },
            size: "medium",
            testid: void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWCMBotStrings", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = h._("__JHASH__K0E4NNoKNtJ__JHASH__");
    b = h._("__JHASH__sbctGC-UNw4__JHASH__");
    g.addedToChatLegend = a;
    g.notAddedToChatLegend = b
}), 226);
__d("MWCMBotDetailsEntrypoint.react", ["fbt", "ix", "CommunityBotEnabledStatus", "I64", "Int64Hooks", "JSResourceForInteraction", "LSFactory", "LSIssueBotsInfoFetchStoredProcedure", "MWCMBotStrings", "MWInboxInfoButton.react", "MWXIcon.react", "MWXIconBot", "MWXIconForListCell.react", "MWXLazyPopoverTrigger.react", "ReQL", "ReQLSuspense", "asyncToGeneratorRuntime", "fbicon", "promiseDone", "react", "useReStore"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k, l, m = l || d("react"),
        n = c("JSResourceForInteraction")("MWCMBotDetailsEntrypointDropdownMenu.react").__setRef("MWCMBotDetailsEntrypoint.react");

    function o(a) {
        var b = a.bot;
        a = a.thread;
        return m.jsx(c("MWXLazyPopoverTrigger.react"), {
            align: "end",
            popoverProps: {
                bot: b,
                thread: a
            },
            popoverResource: n,
            popoverType: "menu",
            children: function(a, e) {
                return m.jsx(c("MWInboxInfoButton.react"), {
                    addOnEnd: m.jsx(c("MWXIcon.react"), {
                        "aria-label": h._("__JHASH__JFJx3iugODR__JHASH__"),
                        icon: d("fbicon")._(i("484391"), 24),
                        onPress: e,
                        ref: a
                    }),
                    addOnStart: m.jsx(c("MWXIconForListCell.react"), {
                        icon: c("MWXIconBot")
                    }),
                    label: b.name,
                    subLabelElement: b.enabledStatus === c("CommunityBotEnabledStatus").ENABLED ? d("MWCMBotStrings").addedToChatLegend : d("MWCMBotStrings").notAddedToChatLegend
                })
            }
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function a(a) {
        var e = a.thread,
            g = (j || (j = c("useReStore")))();
        d("Int64Hooks").useEffectInt64(function() {
            var a = function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                    yield g.runInTransaction(function(a) {
                        return c("LSIssueBotsInfoFetchStoredProcedure")(c("LSFactory")(a), {
                            threadKey: e.threadKey
                        })
                    }, "readwrite")
                });
                return function() {
                    return a.apply(this, arguments)
                }
            }();
            c("promiseDone")(a())
        }, [g, e.threadKey]);
        a = d("ReQLSuspense").useArray(function() {
            return d("ReQL").fromTableDescending(g.tables.bots).getKeyRange(e.threadKey)
        }, [g, e.threadKey], f.id + ":95");
        return a.length === 0 ? null : m.jsx(m.Fragment, {
            children: a.map(function(a) {
                return m.jsx(o, {
                    bot: a,
                    thread: e
                }, (k || (k = d("I64"))).to_string(a.botId))
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWCMInboxInfoGroupCopyLinkButton.react", ["fbt", "CurrentEnvironment", "LSThreadBitOffset", "MWCMChannelLinkShareTrigger.react", "MWCMShortLinkShare.react", "MWInboxInfoButton.react", "MWPBumpEntityKey", "MWXIconForListCell.react", "MWXIconMenuItemLink", "mwCMisStandAloneCommunity", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react"),
        k = h._("__JHASH__c2UIg9XVAm2__JHASH__"),
        l = h._("__JHASH__iEaTUwEK-KE__JHASH__");

    function a(a) {
        var b = a.folder;
        a = a.thread;
        var e = d("LSThreadBitOffset").has(124, a),
            f = c("CurrentEnvironment").facebookdotcom;
        return e && f && !c("mwCMisStandAloneCommunity")(b == null ? void 0 : b.communityType) ? j.jsx(c("MWCMChannelLinkShareTrigger.react"), {
            threadKey: a.threadKey,
            children: function(a) {
                return j.jsx(c("MWInboxInfoButton.react"), {
                    addOnStart: j.jsx(c("MWXIconForListCell.react"), {
                        icon: c("MWXIconMenuItemLink")
                    }),
                    label: k,
                    onPress: a,
                    subLabel: l
                })
            }
        }) : j.jsx(c("MWCMShortLinkShare.react"), {
            thread: a,
            children: function(a, b) {
                return j.jsx(c("MWInboxInfoButton.react"), {
                    addOnStart: j.jsx(c("MWXIconForListCell.react"), {
                        icon: c("MWXIconMenuItemLink")
                    }),
                    label: k,
                    onPress: function() {
                        d("MWPBumpEntityKey").bumpEntityKeyWithAppId("mw.infobar", "copy_link"), b()
                    },
                    subLabel: l
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWCMInboxInfoGroupEventsButton.react", ["fbt", "GroupsCometChatsEngagementLogger", "I64", "MWInboxInfoButton.react", "MWXIconCalendar", "MWXIconForListCell.react", "ReQL", "ReQLSuspense", "deferredLoadComponent", "react", "requireDeferredForDisplay", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = j || d("react"),
        m = c("deferredLoadComponent")(c("requireDeferredForDisplay")("MWInboxInfoEventsListSection.react").__setRef("MWCMInboxInfoGroupEventsButton.react"));

    function n(a, b) {
        return function() {
            d("GroupsCometChatsEngagementLogger").log({
                action: "tap",
                client_extras: {
                    entry_point: "inbox"
                },
                event: "render_event_list",
                parent_surface: "thread_view",
                source: "event_button",
                surface: "thread_settings",
                thread_id: (k || (k = d("I64"))).to_string(b)
            }), a(function(a) {
                a = a.onReturn;
                return l.jsx(m, {
                    loggingParentSurface: "thread_settings",
                    loggingSource: "event_button",
                    onReturn: a,
                    threadKey: b
                })
            })
        }
    }

    function a(a) {
        var b = a.pushPage,
            e = a.threadKey,
            g = (i || (i = c("useReStore")))();
        a = h._("__JHASH__AyF1PV5UJkW__JHASH__");
        var j = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(g.tables.cm_channel_events.index("eventsInThread")).getKeyRange(e).map(function(a) {
                    return d("ReQLSuspense").first(d("ReQL").fromTableAscending(g.tables.fb_events).getKeyRange(a.eventId), f.id + ":75")
                })
            }, [g, e], f.id + ":70"),
            m = j.filter(function(a) {
                return (a == null ? void 0 : a.startTimeMs) != null ? (k || (k = d("I64"))).to_float(a.startTimeMs) > Date.now() : !1
            }).length;
        b = n(b, e);
        var o = m != null && m > 0;
        o = o ? h._("__JHASH__t79c9SrYA8D__JHASH__", [h._plural(m), h._param("Number of upcoming events", m)]) : void 0;
        return j.length > 0 ? l.jsx(c("MWInboxInfoButton.react"), {
            addOnStart: l.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconCalendar")
            }),
            label: a,
            onPress: b,
            subLabel: o
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWXIconMenuItemAppGroups", ["MWXSvgIcon", "SVGIcon", "cr:9352", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgMenuItemIcon(d("SVGIcon").svgIcon(b("cr:9352")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWCMInboxInfoGroupLink.react", ["fbt", "CurrentEnvironment", "I64", "MWInboxInfoButton.react", "MWXIconForListCell.react", "MWXIconMenuItemAppGroups", "XCometGroupLandingControllerRouteBuilder", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = i || d("react");

    function a(a) {
        a = a.folder;
        var b = a.fbGroupId;
        a = a.name;
        b = "https://www.facebook.com" + c("XCometGroupLandingControllerRouteBuilder").buildURL({
            group_id: (j || (j = d("I64"))).to_string(b)
        });
        var e = c("CurrentEnvironment").messengerdotcom ? "_blank" : "_self";
        return k.jsx(c("MWInboxInfoButton.react"), {
            addOnStart: k.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconMenuItemAppGroups")
            }),
            label: h._("__JHASH__XLqB3kIUlsv__JHASH__", [h._param("facebook group name", a)]),
            linkProps: {
                target: e,
                url: b
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWGroupMembershipListItemWrapper", ["MWGroupMembershipListItem"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a.tag) {
            case "ParticipantAndContact":
                return {
                    contact: a.value[1],
                    participant: a.value[0],
                    type: d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ParticipantAndContact
                };
            case "CommunityMember":
                return {
                    communityMember: a.value,
                    type: d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.CommunityMember
                };
            case "ServerSearchResult":
                return {
                    serverSearchResult: a.value,
                    type: d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ServerSearchResult
                };
            case "BroadcastChannelParticipant":
                return {
                    participant: a.value,
                    type: d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.BroadcastChannelParticipant
                }
        }
    }
    g.tToRE = a
}), 98);
__d("MWLSGroupMembershipMemberCellProfilePhoto.react", ["fbt", "IntlVariations", "MWXProfilePhoto.react", "MWXTooltip.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        var b = a.linkProps,
            d = a.name,
            e = a.onPress,
            f = a.profilePictureUrl;
        a = a.showTooltip;
        b = j.jsx(c("MWXProfilePhoto.react"), {
            alt: d,
            "aria-label": h._("__JHASH__5FWHZ8StuMQ__JHASH__", [h._name("name", d, c("IntlVariations").GENDER_UNKNOWN)]),
            linkProps: b,
            onPress: e,
            shape: "circle",
            size: 36,
            source: {
                uri: f
            }
        });
        return a ? j.jsx(c("MWXTooltip.react"), {
            position: "above",
            tooltip: h._("__JHASH__gvt-u-jxLjT__JHASH__", [h._name("name", d, c("IntlVariations").GENDER_UNKNOWN)]),
            children: b
        }) : b
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("useMWLSGroupMembershipMenuQuery$Parameters", ["useMWLSGroupMembershipMenuQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("useMWLSGroupMembershipMenuQuery_facebookRelayOperation"),
            metadata: {},
            name: "useMWLSGroupMembershipMenuQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWLSGroupMembershipMenu.entrypoint", ["JSResourceForInteraction", "useMWLSGroupMembershipMenuQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            var b = a.groupID;
            a = a.userID;
            return {
                queries: {
                    groupMembershipMenuQueryRef: {
                        parameters: c("useMWLSGroupMembershipMenuQuery$Parameters"),
                        variables: {
                            groupID: b,
                            userID: a
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("MWLSGroupMembershipMenu.react").__setRef("MWLSGroupMembershipMenu.entrypoint")
    };
    g["default"] = a
}), 98);
__d("MWLSGroupMembershipMemberCell.react", ["fbt", "AddOnEndOverride.react", "BaseMiddotSeparator.react", "GenderConst", "I64", "Int64Hooks", "LSContactBlockedByViewerStatus", "LSContactGenderToGenderConst", "LSFactory", "LSGroupParticipantJoinState", "LSIntEnum", "LSIssueCommunityAdminModerationActionsFetchStoredProcedure", "LSThreadBitOffset", "LSWhatsAppConnectStatus", "MWCMThreadTypes.react", "MWGroupMembershipListItem", "MWLSContactTypeExactUtils", "MWLSGroupMembershipMemberCellProfilePhoto.react", "MWLSGroupMembershipMenu.entrypoint", "MWPActor.react", "MWXCircleButton.react", "MWXEntryPointPopoverTrigger.react", "MWXIconDots3Horizontal", "MWXListCell.react", "MWXText.react", "MWXTextPairing.react", "MWXTooltip.react", "getFBTSafeGenderFromGenderConst", "getLSMediaContactProfilePictureUrl", "gkx", "pageID", "promiseDone", "react", "useMWNavigateToThreadFromGroupMembership", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l, m = j || (j = d("react")),
        n = j.useMemo,
        o = h._("__JHASH__3WTOYPxVm2l__JHASH__"),
        p = h._("__JHASH__J1b76x4xKfs__JHASH__"),
        q = h._("__JHASH__d3jtAkHct5c__JHASH__"),
        r = "member_list_profile_sheet_source_" + c("pageID");

    function s(a, b) {
        return n(function() {
            if (a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ServerSearchResult && a.serverSearchResult.contextLine !== "") return [m.jsx(m.Fragment, {
                children: a.serverSearchResult.contextLine
            })];
            var e = b.filter(function(a) {
                return a != null
            });
            return e.length > 0 ? m.jsx(c("BaseMiddotSeparator.react"), {
                children: e
            }) : null
        }, [a, b])
    }

    function t(a) {
        if (a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ParticipantAndContact) {
            var b = a.contact,
                e = a.participant,
                f = b.blockedByViewerStatus,
                g = b.contactTypeExact,
                h = b.gender,
                i = b.name,
                j = b.secondaryName,
                m = b.waConnectStatus,
                n = e.groupParticipantJoinState,
                o = e.isSuperAdmin;
            e = e.subscribeSource;
            return {
                gender: c("LSContactGenderToGenderConst")(h),
                isBlocked: !(k || (k = d("I64"))).equal(f, (l || (l = d("LSIntEnum"))).ofNumber(c("LSContactBlockedByViewerStatus").UNBLOCKED)),
                isInvitedByViewer: k.equal(n, l.ofNumber(c("LSGroupParticipantJoinState").INVITED)),
                isSuperAdmin: o === !0,
                name: i,
                nonWaAddressable: k.equal(m, l.ofNumber(c("LSWhatsAppConnectStatus").WHATSAPP_NOT_ADDRESSABLE)),
                profilePictureUrl: c("getLSMediaContactProfilePictureUrl")(b),
                secondaryName: j != null && d("MWLSContactTypeExactUtils").isIgContact(g) ? j : null,
                subscribeSource: (h = e) != null ? h : null,
                username: b.username
            }
        }
        if (a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.CommunityMember) {
            f = a.communityMember;
            n = f.isBlocked;
            o = f.name;
            i = f.nickname;
            m = f.profilePictureUrl;
            g = f.subtitle;
            return {
                gender: c("GenderConst").NOT_A_PERSON,
                isBlocked: (j = n) != null ? j : !1,
                isInvitedByViewer: !1,
                isSuperAdmin: !1,
                name: (e = i) != null ? e : o,
                nonWaAddressable: !1,
                profilePictureUrl: (h = m) != null ? h : "<PLACEHOLDER>",
                secondaryName: i != null ? o : null,
                subscribeSource: null,
                subtitle: g
            }
        }
        if (a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.BroadcastChannelParticipant) {
            b = a.participant;
            f = b.isBlocked;
            n = b.name;
            j = b.nickname;
            e = b.profilePictureUrl;
            m = b.profilePictureUrlFallback;
            return {
                gender: c("GenderConst").NOT_A_PERSON,
                isBlocked: (h = f) != null ? h : !1,
                isInvitedByViewer: !1,
                isSuperAdmin: !1,
                name: (i = j) != null ? i : n,
                nonWaAddressable: !1,
                profilePictureUrl: (g = (o = e) != null ? o : m) != null ? g : "<PLACEHOLDER>",
                secondaryName: null,
                subscribeSource: null
            }
        }
        b = a.serverSearchResult;
        f = b.displayName;
        h = b.profilePicUrl;
        return {
            gender: c("GenderConst").NOT_A_PERSON,
            isBlocked: !(k || (k = d("I64"))).equal(b.blockedByViewerStatus, (l || (l = d("LSIntEnum"))).ofNumber(c("LSContactBlockedByViewerStatus").UNBLOCKED)),
            isInvitedByViewer: !1,
            isSuperAdmin: !1,
            name: f,
            nonWaAddressable: !1,
            profilePictureUrl: (j = h) != null ? j : "<PLACEHOLDER>",
            secondaryName: null,
            subscribeSource: null
        }
    }

    function u(a, b, c, e, f, g, i) {
        var j, k, l;
        j = (j = d("MWGroupMembershipListItem").isAdmin(a)) != null ? j : !1;
        k = (k = d("MWGroupMembershipListItem").isModerator(a)) != null ? k : !1;
        l = (l = d("MWGroupMembershipListItem").isHost(a)) != null ? l : !1;
        a = t(a);
        var m = a.isInvitedByViewer,
            n = a.isSuperAdmin,
            r = a.nonWaAddressable,
            s = a.subscribeSource;
        a = a.subtitle;
        if (b && r && !m) return h._("__JHASH__YJ7dDY2F-1___JHASH__").toString();
        if (b && !r && m) return h._("__JHASH__XW-fqo6HqSP__JHASH__").toString();
        if (s != null && n) return c ? o : s;
        if (j && e) return o;
        if (k && g) return p;
        if (l && f) return q;
        return c && i && a != null ? a : null
    }

    function a(a) {
        var b = a.canMessageUser,
            e = a.folder,
            g = a.isMAWParticipantSuperAdmin,
            j = a.isSecure,
            n = a.membershipListItem,
            o = a.onClose,
            p = a.showAdminIndicator,
            q = a.showHostIndicator;
        q = q === void 0 ? !1 : q;
        var v = a.showInvitedByViewerOnly;
        v = v === void 0 ? !1 : v;
        var w = a.showModeratorIndicator,
            x = a.thread;
        a = d("MWPActor.react").useActor();
        var y = d("MWGroupMembershipListItem").contactId(n),
            z = d("LSThreadBitOffset").has(66, x) && d("MWCMThreadTypes.react").isStandardCMThread(x.threadType),
            A = (i || (i = c("useReStore")))(),
            B = c("useMWNavigateToThreadFromGroupMembership")(),
            C = t(n),
            D = C.gender,
            E = C.isBlocked,
            F = C.isInvitedByViewer,
            G = C.isSuperAdmin,
            H = C.name,
            I = C.profilePictureUrl,
            J = C.secondaryName,
            K = C.subscribeSource;
        C = C.username;
        var L = d("MWCMThreadTypes.react").isJoinedCMThread(x.threadType),
            M = d("Int64Hooks").useCallbackInt64(function() {
                e != null && c("promiseDone")(A.runInTransaction(function(a) {
                    return c("LSIssueCommunityAdminModerationActionsFetchStoredProcedure")(c("LSFactory")(a), {
                        fbGroupId: e == null ? void 0 : e.folderId,
                        requestId: r,
                        source: (l || (l = d("LSIntEnum"))).ofNumber(14),
                        targetUserId: y,
                        threadId: x.threadKey
                    })
                }, "readwrite", void 0, void 0, f.id + ":322"))
            }, [y, A, e, x.threadKey]);
        E = s(n, [E ? h._("__JHASH__iywW1hlnypb__JHASH__") : null, J, u(n, j, L, p, q, w, z), K != null && !G && !L ? K : null, c("gkx")("23433") && c("gkx")("538") ? C : null]);
        J = j && F && !v;
        return m.jsx(c("MWXListCell.react"), {
            addOnEnd: m.jsx(c("AddOnEndOverride.react"), {
                children: m.jsx(c("MWXEntryPointPopoverTrigger.react"), {
                    align: "end",
                    entryPointParams: {
                        groupID: (k || (k = d("I64"))).to_string((p = e == null ? void 0 : e.fbGroupId) != null ? p : (k || (k = d("I64"))).zero),
                        userID: k.to_string(a)
                    },
                    otherProps: {
                        folder: e,
                        isMAWParticipantSuperAdmin: g,
                        membershipListItem: n,
                        onCloseDialog: o,
                        thread: x
                    },
                    popoverEntryPoint: c("MWLSGroupMembershipMenu.entrypoint"),
                    popoverType: "menu",
                    preloadTrigger: "button",
                    children: function(a, b, d, e, f, g, i) {
                        return m.jsx(c("MWXTooltip.react"), {
                            align: "middle",
                            position: "above",
                            tooltip: h._("__JHASH__I91w8MVMuJd__JHASH__"),
                            children: m.jsx(c("MWXCircleButton.react"), {
                                icon: c("MWXIconDots3Horizontal"),
                                label: h._("__JHASH__-R08aUV4n3s__JHASH__", [h._name("name", H, c("getFBTSafeGenderFromGenderConst")(D))]),
                                onHoverIn: function(a) {
                                    M(), e == null ? void 0 : e(a)
                                },
                                onHoverOut: function() {
                                    f == null ? void 0 : f()
                                },
                                onPress: function() {
                                    return b()
                                },
                                onPressIn: g,
                                ref: a,
                                size: 36,
                                testid: void 0,
                                type: "deemphasized"
                            })
                        })
                    }
                })
            }),
            addOnEndVerticalAlign: "center",
            addOnStart: m.jsx(c("MWLSGroupMembershipMemberCellProfilePhoto.react"), {
                name: H,
                onPress: function() {
                    B(y, j), o()
                },
                profilePictureUrl: I,
                showTooltip: b
            }),
            content: E != null ? m.jsx(c("MWXTextPairing.react"), {
                body: m.jsx(c("MWXText.react"), {
                    color: J ? "disabled" : "secondary",
                    type: "body4",
                    children: E
                }),
                headline: m.jsx(c("MWXText.react"), {
                    color: J ? "disabled" : "primary",
                    type: "headline4",
                    children: H
                }),
                level: 4
            }) : m.jsx(c("MWXText.react"), {
                align: "start",
                numberOfLines: 1,
                type: "headline4",
                children: H
            }),
            size: "medium",
            testid: void 0
        }, k.to_string(y))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("useMAWGetGroupSuperAdmin", ["Int64Hooks", "MAWMiActOnActThreadReadyDeferred", "cr:9779", "promiseDone", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, e, f) {
        var g = (h || (h = c("useReStore")))();
        d("Int64Hooks").useEffectInt64(function() {
            if (b("cr:9779") != null && e) {
                var d = b("cr:9779").sendAndReceive;
                c("promiseDone")(c("MAWMiActOnActThreadReadyDeferred")(g, a, "MWLSGroupMembershipMemberList.bs", function(a, b) {
                    return d("backend", "getGroupSuperAdmin", {
                        chatJid: b
                    }).then(function(a) {
                        return f(a)
                    })
                }))
            }
        }, [g, e, f, a])
    }
    g["default"] = a
}), 98);
__d("MWLSGroupMembershipMemberList.react", ["fbt", "I64", "LSGroupParticipantJoinState", "LSIntEnum", "LSMessagingThreadTypeUtil", "MDSInfiniteScrollList.react", "MWDialogTextPairing.react", "MWGroupMembershipListItem", "MWLSGroupMembershipMemberCell.react", "MWMemberListGlimmer.react", "MWPActor.react", "emptyFunction", "react", "react-strict-dom", "useMAWGetGroupSuperAdmin"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = i || (i = d("react"));
    b = i;
    var m = b.useCallback,
        n = b.useState,
        o = {
            noHosts: {
                alignItems: "x6s0dn4",
                alignSelf: "xamitd3",
                display: "x78zum5",
                flexGrow: "x1iyjqo2",
                height: "x1egiwwb",
                justifyContent: "xl56j7k",
                width: "xdzyupr",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.disableScroll;
        b = b === void 0 ? !1 : b;
        var e = a.doSortParticipants;
        e = e === void 0 ? !0 : e;
        var f = a.folder,
            g = a.hasMore;
        g = g === void 0 ? !1 : g;
        var i = a.isLoading;
        i = i === void 0 ? !1 : i;
        var p = a.onClose,
            q = p === void 0 ? c("emptyFunction") : p;
        p = a.onLoadMore;
        p = p === void 0 ? c("emptyFunction") : p;
        var r = a.participantsAndContacts,
            s = a.showAdmodIndicator,
            t = a.showAdmodsOnly,
            u = a.showHostsOnly,
            v = a.showInvitedByViewerOnly,
            w = a.thread;
        a = n(c("emptyFunction"));
        var x = a[0];
        a = a[1];
        var y = d("MWPActor.react").isAPPlus();
        t = t ? r.filter(function(a) {
            var b;
            b = (b = d("MWGroupMembershipListItem").isAdmin(a)) != null ? b : !1;
            a = (a = d("MWGroupMembershipListItem").isModerator(a)) != null ? a : !1;
            return b || a
        }) : v ? r.filter(function(a) {
            a = a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ParticipantAndContact ? a.participant.groupParticipantJoinState : (j || (j = d("LSIntEnum"))).ofNumber(c("LSGroupParticipantJoinState").MEMBER);
            return (k || (k = d("I64"))).equal(a, (j || (j = d("LSIntEnum"))).ofNumber(c("LSGroupParticipantJoinState").INVITED))
        }) : u ? r.filter(function(a) {
            return (a = d("MWGroupMembershipListItem").isHost(a)) != null ? a : !1
        }) : r;
        r = e ? t.slice(0).sort(function(a, b) {
            if (a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ParticipantAndContact && b.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ParticipantAndContact) return a.contact.name.localeCompare(b.contact.name);
            if (a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.CommunityMember && b.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.CommunityMember) return a.communityMember.name.localeCompare(b.communityMember.name);
            return a.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ServerSearchResult && b.type === d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ServerSearchResult ? a.serverSearchResult.displayName.localeCompare(b.serverSearchResult.displayName) : 0
        }) : t;
        var z = d("LSMessagingThreadTypeUtil").isArmadilloSecure(w.threadType);
        c("useMAWGetGroupSuperAdmin")(w.threadKey, z, a);
        e = m(function(a) {
            var b = d("MWGroupMembershipListItem").contactId(a);
            return l.jsx(c("MWLSGroupMembershipMemberCell.react"), {
                canMessageUser: !y,
                folder: f,
                isMAWParticipantSuperAdmin: z && x != null ? x === (k || (k = d("I64"))).to_string(b) : !1,
                isSecure: z,
                membershipListItem: a,
                onClose: q,
                showAdminIndicator: s,
                showHostIndicator: s,
                showInvitedByViewerOnly: v,
                showModeratorIndicator: s,
                thread: w
            }, (k || (k = d("I64"))).to_string(b))
        }, [f, y, z, q, s, v, x, w]);
        return r.length === 0 && u && i === !1 && g === !1 ? l.jsx(d("react-strict-dom").html.div, {
            style: o.noHosts,
            children: l.jsx(c("MWDialogTextPairing.react"), {
                body: h._("__JHASH__M-jFobtfz3M__JHASH__"),
                bodyColor: "secondary",
                headline: h._("__JHASH__7DQH5InZyqq__JHASH__"),
                textAlign: "center"
            })
        }) : b ? r.map(e) : l.jsx(c("MDSInfiniteScrollList.react"), {
            hasMore: g,
            isLoading: i,
            items: r,
            loadingIndicator: l.jsx(c("MWMemberListGlimmer.react"), {}),
            onLoadMore: p,
            renderItem: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWParticipantsForBroadcastChannelUtils", ["Int64Hooks", "LSClearDiscoverableChatsParticipantsAndRangesStoredProcedure", "LSFactory", "LSFetchDiscoverableChatParticipantsStoredProcedure", "LSIntEnum", "LSMessagingThreadTypeUtil", "ReQL", "ReQLSuspense", "promiseDone", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = (j || d("react")).useCallback;

    function a(a, b) {
        var e = (h || (h = c("useReStore")))();
        d("Int64Hooks").useEffectInt64(function() {
            d("LSMessagingThreadTypeUtil").isDiscoverablePublicBroadcastChannel(a.threadType) && c("promiseDone")(e.runInTransaction(function(e) {
                return c("LSFetchDiscoverableChatParticipantsStoredProcedure")(c("LSFactory")(e), {
                    cursor: "",
                    maxName: "",
                    source: (i || (i = d("LSIntEnum"))).ofNumber(b),
                    threadKey: a.threadKey
                })
            }, "readwrite", void 0, void 0, f.id + ":39"))
        }, [e, b, a.threadKey, a.threadType])
    }

    function b() {
        var a = (h || (h = c("useReStore")))();
        return k(function() {
            return a.runInTransaction(function(a) {
                return c("LSClearDiscoverableChatsParticipantsAndRangesStoredProcedure")(c("LSFactory")(a))
            }, "readwrite", void 0, void 0, f.id + ":59")
        }, [a])
    }

    function e(a) {
        var b = (h || (h = c("useReStore")))();
        return d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(b.tables.discoverable_chat_participants_ranges_v2__generated).getKeyRange(a)
        }, [b, a], f.id + ":75")
    }
    g.useFetchBroadcastChannelMembers = a;
    g.useClearBroadcastChannelParticipantsList = b;
    g.useMWParticipantsForBroadcastChannelRanges = e
}), 98);
__d("MWCMInboxInfoMemberList.react", ["fbt", "I64", "LSMessagingThreadTypeUtil", "MWGroupMembershipListItemWrapper", "MWLSGroupMembershipDialog.entrypoint", "MWLSGroupMembershipMemberList.react", "MWMemberListGlimmer.react", "MWPBumpEntityKey", "MWParticipantsForBroadcastChannelUtils", "MWXIconForListCell.react", "MWXIconGroup", "MWXListCellPressable.react", "MWXText.react", "ReQL", "ReQLSuspense", "pageID", "promiseDone", "react", "useCommunityMembers", "useMWXEntryPointDialog", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = j || (j = d("react")),
        m = j.useEffect,
        n = "inbox_info_member_list_" + c("pageID"),
        o = "member_list_profile_sheet_source_" + c("pageID"),
        p = (k || (k = d("I64"))).of_int32(7);

    function a(a) {
        var b = a.folder,
            e = a.thread,
            g = (i || (i = c("useReStore")))(),
            j = b == null ? e.threadKey : b.folderId;
        d("useCommunityMembers").useFetchCommunityMembers({
            communityIdOrThreadKey: j,
            requestId: n,
            source: p,
            thread: e
        });
        var q = d("ReQLSuspense").useArray(function() {
            return d("ReQL").fromTableAscending(g.tables.community_members.index("communitySource")).getKeyRange(j, p, n).take(15)
        }, [g, j], f.id + ":89");
        d("MWParticipantsForBroadcastChannelUtils").useFetchBroadcastChannelMembers(e, 0);
        a = d("ReQLSuspense").useArray(function() {
            return d("ReQL").fromTableAscending(g.tables.discoverable_chat_participants).getKeyRange(e.threadKey).take(15)
        }, [g, e.threadKey], f.id + ":101");
        var r = d("useCommunityMembers").useClearMemberList(),
            s = d("useCommunityMembers").useClearMemberList(14),
            t = d("MWParticipantsForBroadcastChannelUtils").useClearBroadcastChannelParticipantsList(),
            u = (k || (k = d("I64"))).to_string(e.threadKey),
            v = d("LSMessagingThreadTypeUtil").isDiscoverablePublicBroadcastChannel(e.threadType);
        v = v ? a.map(function(a) {
            return d("MWGroupMembershipListItemWrapper").tToRE({
                tag: "BroadcastChannelParticipant",
                value: a
            })
        }) : q.map(function(a) {
            return d("MWGroupMembershipListItemWrapper").tToRE({
                tag: "CommunityMember",
                value: a
            })
        });
        m(function() {
            c("promiseDone")(r(n));
            c("promiseDone")(s(o));
            c("promiseDone")(t());
            return function() {
                c("promiseDone")(r(n)), c("promiseDone")(s(o)), c("promiseDone")(t())
            }
        }, [u, r, t, s]);
        m(function() {
            q.length > 0 && d("MWPBumpEntityKey").bumpEntityKeyWithAppId("mw.cm.member_list", "community_members_loaded")
        }, [q.length]);
        var w = {
            folder: b
        };
        u = c("useMWXEntryPointDialog")(c("MWLSGroupMembershipDialog.entrypoint"), {
            groupID: k.to_string((a = b == null ? void 0 : b.fbGroupId) != null ? a : (k || (k = d("I64"))).zero)
        });
        var x = u[0],
            y = function() {
                return x(w)
            };
        return v.length === 0 ? l.jsx(c("MWMemberListGlimmer.react"), {}) : l.jsxs(l.Fragment, {
            children: [l.jsx(c("MWLSGroupMembershipMemberList.react"), {
                disableScroll: !0,
                doSortParticipants: !1,
                folder: b,
                participantsAndContacts: v,
                showAdmodIndicator: !0,
                showAdmodsOnly: !1,
                showHostsOnly: !1,
                showInvitedByViewerOnly: !1,
                thread: e
            }), l.jsx(c("MWXListCellPressable.react"), {
                addOnStart: l.jsx("div", {
                    className: "x6s0dn4 xljulmy x14yjl9h xudhj91 x18nykt9 xww2gxu x78zum5 xc9qbxq xl56j7k x14qfxbe",
                    children: l.jsx(c("MWXIconForListCell.react"), {
                        hasBackground: !1,
                        icon: c("MWXIconGroup"),
                        size: "medium"
                    })
                }),
                content: l.jsx(c("MWXText.react"), {
                    type: "headline4",
                    children: h._("__JHASH__BN54OIlz3MA__JHASH__")
                }),
                onPress: function(a) {
                    d("MWPBumpEntityKey").bumpEntityKeyWithAppId("mw.cm.member_list", "see_all"), y()
                },
                size: "medium"
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWXIconFriendGenericCheckmark", ["MWXSvgIcon", "SVGIcon", "cr:12440", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12440")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWCMInboxInfoMemberRequests.react", ["fbt", "Int64Hooks", "MWCMRequestToJoinUtils", "MWInboxInfoButton.react", "MWInboxInfoMemberRequestsPushPage.react", "MWXIconForListCell.react", "MWXIconFriendGenericCheckmark", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        var b = a.pushPage,
            e = a.thread,
            f = d("Int64Hooks").useCallbackInt64(function(a) {
                if (b != null) return b(function(b) {
                    return j.jsx(c("MWInboxInfoMemberRequestsPushPage.react"), {
                        onReturn: b.onReturn,
                        parentSurface: a,
                        threadKey: e.threadKey
                    })
                })
            }, [b, e.threadKey]);
        a = d("MWCMRequestToJoinUtils").memberRequestsMenuItemSubtitle(e);
        return j.jsx(c("MWInboxInfoButton.react"), {
            addOnStart: j.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconFriendGenericCheckmark")
            }),
            label: h._("__JHASH__4FAWQwvEk9h__JHASH__"),
            onPress: function() {
                return f()
            },
            subLabel: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWXIconMenuItemThread", ["MWXSvgIcon", "SVGIcon", "cr:9644", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgMenuItemIcon(d("SVGIcon").svgIcon(b("cr:9644")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWCMSubthreadlistMenuItem.react", ["fbt", "I64", "MWInboxInfoButton.react", "MWInboxInfoPanelContext.react", "MWXIconForListCell.react", "MWXIconMenuItemThread", "ReQL", "ReQLSuspense", "intlSummarizeNumber", "react", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = k || d("react");

    function a(a) {
        var b = a.threadKey,
            e = (i || (i = c("useReStore")))();
        a = (a = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(e.tables.threads, ["subthreadCount"]).getKeyRange(b)
        }, [e, b], f.id + ":29")) == null ? void 0 : a.subthreadCount;
        a = a != null ? "(" + c("intlSummarizeNumber")((j || (j = d("I64"))).to_int32(a)) + ")" : "";
        a = h._("__JHASH__B36kC69TSuv__JHASH__", [h._param("subthread_count", a)]);
        var g = d("MWInboxInfoPanelContext.react").useMWInboxInfoPanelContext(),
            k = g.setShowSubthreadList;
        return l.jsx(c("MWInboxInfoButton.react"), {
            addOnStart: l.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconMenuItemThread")
            }),
            label: a,
            onPress: function() {
                k(!0)
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWChannelsPersonalInboxOptInPage.react", ["fbt", "CometPlaceholder.react", "Int64Hooks", "LSFactory", "LSFetchDiscoverableChatsPersonalInboxInfoStoredProcedure", "LSHideBroadcastChannelFromPersonalInboxStoredProcedure", "LSShowBroadcastChannelInPersonalInboxStoredProcedure", "Locale", "MWAdminForBroadcastChannelUtils", "MWLogBroadcastChannelFalcoEvent", "MWXCircleButton.react", "MWXColumn.react", "MWXIconArrowLeft", "MWXIconArrowRight", "MWXListCell.react", "MWXProfilePhoto.react", "MWXRow.react", "MWXRowItem.react", "MWXSwitch.react", "MWXText.react", "MWXTextPairing.react", "MWXThreadThemeColor", "ReQL", "ReQLSuspense", "getLSMediaContactProfilePictureUrl", "promiseDone", "react", "useReStore", "useSinglePartialViewImpression"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = j || (j = d("react"));
    b = j;
    var l = b.useCallback,
        m = b.useId,
        n = b.useState;

    function o(a) {
        var b = a.channelCreator,
            e = a.personalInboxInfo,
            g = a.threadKey;
        a = n(e.isShownInPersonalInbox);
        var j = a[0],
            o = a[1];
        a = m();
        var p = (i || (i = c("useReStore")))(),
            q = h._("__JHASH__cO3zYIieEQ4__JHASH__"),
            r = l(function(a) {
                c("promiseDone")(a ? p.runInTransaction(function(a) {
                    return c("LSShowBroadcastChannelInPersonalInboxStoredProcedure")(c("LSFactory")(a), {
                        threadId: g
                    })
                }, "readwrite", void 0, void 0, f.id + ":78") : p.runInTransaction(function(a) {
                    return c("LSHideBroadcastChannelFromPersonalInboxStoredProcedure")(c("LSFactory")(a), {
                        threadId: g
                    })
                }, "readwrite", void 0, void 0, f.id + ":86"), function() {
                    o(a)
                })
            }, [p, g]),
            s = d("Int64Hooks").useCallbackInt64(function() {
                d("MWLogBroadcastChannelFalcoEvent").logBroadcastChannelFalcoEvent({
                    action: 2,
                    event: 276,
                    parentSurface: 11,
                    source: 62,
                    surface: 16,
                    threadFbid: g
                })
            }, [g]);
        s = c("useSinglePartialViewImpression")({
            onImpressionStart: s
        });
        return k.jsxs(k.Fragment, {
            children: [k.jsx(c("MWXRow.react"), {
                expanding: !0,
                children: k.jsx(c("MWXRowItem.react"), {
                    expanding: !0,
                    children: k.jsx(c("MWXListCell.react"), {
                        addOnEnd: k.jsx(c("MWXSwitch.react"), {
                            "aria-describedby": a,
                            "aria-label": q,
                            onValueChange: function() {
                                r(!j)
                            },
                            size: "small",
                            value: j
                        }),
                        addOnEndVerticalAlign: "center",
                        addOnStart: k.jsx(c("MWXProfilePhoto.react"), {
                            size: 36,
                            source: {
                                uri: c("getLSMediaContactProfilePictureUrl")(b)
                            }
                        }),
                        content: k.jsx(c("MWXTextPairing.react"), {
                            headline: k.jsx(c("MWXText.react"), {
                                type: "headline4",
                                children: q
                            }),
                            level: 4
                        }),
                        ref: s,
                        size: "large"
                    })
                })
            }), k.jsx(c("MWXRow.react"), {
                paddingHorizontal: 16,
                paddingVertical: 16,
                children: k.jsx(c("MWXRowItem.react"), {
                    children: k.jsx("div", {
                        className: "x1e558r4 x150jy0e",
                        children: k.jsx(c("MWXText.react"), {
                            color: "tertiary",
                            type: "body4",
                            children: h._("__JHASH__nO-_JTOnN3T__JHASH__", [h._param("page_name", b.name), h._param("acting_account_name", e.actingAccountName)])
                        })
                    })
                })
            })]
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.onReturn,
            e = a.threadKey,
            g = (i || (i = c("useReStore")))();
        a = d("MWAdminForBroadcastChannelUtils").useFetchBroadcastChannelCreator(e);
        d("Int64Hooks").useEffectInt64(function() {
            c("promiseDone")(g.runInTransaction(function(a) {
                return c("LSFetchDiscoverableChatsPersonalInboxInfoStoredProcedure")(c("LSFactory")(a), {
                    threadKey: e
                })
            }, "readwrite", void 0, void 0, f.id + ":182"))
        }, [g, e]);
        var j = d("ReQLSuspense").useFirst(function() {
            return d("ReQL").fromTableAscending(g.tables.discoverable_chats_personal_inbox_info).getKeyRange(e)
        }, [g, e], f.id + ":193");
        return k.jsxs(c("MWXColumn.react"), {
            expanding: !0,
            children: [k.jsxs(c("MWXRow.react"), {
                align: "start",
                verticalAlign: "center",
                children: [k.jsx(c("MWXRowItem.react"), {
                    children: k.jsx(c("MWXCircleButton.react"), {
                        color: d("MWXThreadThemeColor").mwxThreadThemeColor("var(--mwp-header-button-color)"),
                        icon: d("Locale").isRTL() ? c("MWXIconArrowRight") : c("MWXIconArrowLeft"),
                        label: h._("__JHASH__wSyF3E_Fmrl__JHASH__"),
                        onPress: b,
                        size: 32,
                        type: "deemphasized"
                    })
                }), k.jsx(c("MWXRowItem.react"), {
                    children: k.jsx(c("MWXText.react"), {
                        type: "headlineEmphasized2",
                        children: h._("__JHASH__iMHo6cQn9S___JHASH__")
                    })
                })]
            }), k.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                name: "MWChannelsPersonalInboxOptInPage",
                children: a != null && j != null ? k.jsx(o, {
                    channelCreator: a,
                    personalInboxInfo: j,
                    threadKey: e
                }) : null
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWEncryptedBackupsThreadListNux_query.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [{
            defaultValue: null,
            kind: "LocalArgument",
            name: "qpWithPinEnabled"
        }],
        kind: "Fragment",
        metadata: null,
        name: "MWEncryptedBackupsThreadListNux_query",
        selections: [{
            alias: null,
            args: null,
            concreteType: "XFBEncryptedBackup",
            kind: "LinkedField",
            name: "xfb_backup",
            plural: !1,
            selections: [{
                args: null,
                kind: "FragmentSpread",
                name: "useMWEncryptedBackupsGetVirtualDevicesPreloaded_xfbEncryptedBackup"
            }, {
                alias: null,
                args: [{
                    kind: "Literal",
                    name: "family_device_id",
                    value: ""
                }],
                kind: "ScalarField",
                name: "has_otc_eligible_devices",
                storageKey: 'has_otc_eligible_devices(family_device_id:"")'
            }],
            storageKey: null
        }, {
            kind: "RequiredField",
            field: {
                alias: null,
                args: null,
                concreteType: "Viewer",
                kind: "LinkedField",
                name: "viewer",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "MessengerDefaultEncryptedBackup",
                    kind: "LinkedField",
                    name: "messenger_default_encrypted_backup",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "VestaGetUserInfoResponse",
                        kind: "LinkedField",
                        name: "vesta_user_info",
                        plural: !1,
                        selections: [{
                            args: null,
                            kind: "FragmentSpread",
                            name: "useMWChatEncryptedBackupsVestaUserInfo_vestaGetUserInfoResponse"
                        }],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            },
            action: "THROW",
            path: "viewer"
        }, {
            kind: "Defer",
            selections: [{
                args: [{
                    kind: "Variable",
                    name: "qpWithPinEnabled",
                    variableName: "qpWithPinEnabled"
                }],
                kind: "FragmentSpread",
                name: "MWEncryptedBackupsThreadListRestoreQPWrapperDeferred_query"
            }]
        }],
        type: "Query",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("MWEncryptedBackupsThreadListNux.react", ["CometPlaceholder.react", "CometRelay", "MWChatEncryptedBackupsQPLSource.enum", "MWEBEntrypointsKillswitch.enum", "MWEBVestaUserInfoContext.react", "MWEBVirtualDevicesContextProvider.react", "MWEncryptedBackupsThreadListNux_query.graphql", "MWEncryptedBackupsThreadListQPWrapper.react", "cr:10250", "cr:10251", "cr:2046", "cr:2542", "react", "useMWChatEncryptedBackupsVestaUserInfo", "useMWEBBackupState", "useMWEncryptedBackupsGetVirtualDevicesPreloaded"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useMemo;

    function l(a) {
        var e, f, g = a.children;
        a = a.fragmentKey;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("MWEncryptedBackupsThreadListNux_query.graphql"), a);
        var i = c("useMWEBBackupState")({
            entrypoint: c("MWEBEntrypointsKillswitch.enum").INBOX_THREADLIST
        });
        e = (e = a.viewer.messenger_default_encrypted_backup) == null ? void 0 : e.vesta_user_info;
        var l = c("useMWChatEncryptedBackupsVestaUserInfo")({
            vestaGetUserInfoResponse$key: e
        });
        e = k(function() {
            return {
                attemptsRemaining: l.attemptsRemaining,
                loginTimeoutRemainingSecs: l.loginTimeoutRemainingSecs,
                vestaClientID: null
            }
        }, [l.attemptsRemaining, l.loginTimeoutRemainingSecs]);
        var n = c("useMWEncryptedBackupsGetVirtualDevicesPreloaded")({
            encryptedBackup: a == null ? void 0 : a.xfb_backup
        });
        n = n.getVirtualDevices;
        n = n();
        var o = n.offlineDevicesCount;
        n = n.vestaClientID;
        return j.jsx(c("MWEBVirtualDevicesContextProvider.react"), {
            hasOtcEligibleDevicesInitialValue: (f = a == null ? void 0 : (f = a.xfb_backup) == null ? void 0 : f.has_otc_eligible_devices) != null ? f : void 0,
            offlineDevicesCountInitialValue: o,
            vestaClientIDInitialValue: n,
            children: j.jsx(d("MWEBVestaUserInfoContext.react").MWEBVestaUserInfoContext.Provider, {
                value: e,
                children: j.jsx(m, {
                    backupState: i,
                    children: g,
                    fragment: a
                })
            })
        })
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function m(a) {
        var e = a.backupState,
            f = a.children;
        a = a.fragment;
        switch (e) {
            case 4:
                return b("cr:2542") || b("cr:2046") ? b("cr:2542") != null ? j.jsx(b("cr:2542"), {
                    trigger: d("MWEncryptedBackupsThreadListQPWrapper.react").MWEncryptedBackupsQPTrigger.THREAD_LIST,
                    children: f
                }) : b("cr:2046") != null && j.jsx(b("cr:2046"), {
                    fragmentKey: a,
                    trigger: d("MWEncryptedBackupsThreadListQPWrapper.react").MWEncryptedBackupsQPTrigger.THREAD_LIST,
                    children: f
                }) : f;
            case 1:
                return null;
            case 2:
                return b("cr:10250") || b("cr:10251") ? j.jsx(c("CometPlaceholder.react"), {
                    fallback: null,
                    name: "MWEncryptedBackupsThreadListNux.OnboardingThreadListQP",
                    children: b("cr:10250") != null ? j.jsx(b("cr:10250"), {
                        source: c("MWChatEncryptedBackupsQPLSource.enum").INBOX_THREADLIST_QP,
                        children: f
                    }) : b("cr:10251") != null && j.jsx(b("cr:10251"), {
                        source: c("MWChatEncryptedBackupsQPLSource.enum").INBOX_THREADLIST_ONBOARDING_QP,
                        trigger: d("MWEncryptedBackupsThreadListQPWrapper.react").MWEncryptedBackupsQPTrigger.THREAD_LIST,
                        children: f
                    })
                }) : f;
            default:
                return f
        }
    }
    m.displayName = m.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.children;
        a = a.fragmentKey;
        return j.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            name: "MWEncryptedBackupsThreadListNux.Query",
            children: j.jsx(l, {
                fragmentKey: a,
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWEncryptedBackupsThreadListRestoreQPWrapperDeferredWithEBCheck.react", ["cr:9938"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:9938")
}), 98);
__d("MWInboxInfoChannelCreatorProfileLink.react", ["fbt", "CometPageVerificationIcon.react", "CurrentEnvironment", "I64", "LSContactBitOffset", "MWAdminForBroadcastChannelUtils", "MWXListCellPressable.react", "MWXProfilePhoto.react", "MWXText.react", "MWXTextPairing.react", "XCometProfileControllerRouteBuilder", "getLSMediaContactProfilePictureUrl", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = i || d("react"),
        l = {
            creatorBadge: {
                display: "xt0psk2",
                marginStart: "xsgj6o6",
                $$css: !0
            }
        };

    function a(a) {
        var b, e;
        a = a.threadKey;
        a = d("MWAdminForBroadcastChannelUtils").useFetchBroadcastChannelCreator(a);
        if (a == null) return null;
        b = (b = c("XCometProfileControllerRouteBuilder").buildUri({
            id: (j || (j = d("I64"))).to_string(a.id)
        }).setDomain("www.facebook.com")) == null ? void 0 : (b = b.setProtocol("https")) == null ? void 0 : b.toString();
        var f = c("CurrentEnvironment").messengerdotcom ? "_blank" : "_self";
        e = d("LSContactBitOffset").has(23, (e = a) != null ? e : {});
        return k.jsx(c("MWXListCellPressable.react"), {
            addOnStart: k.jsx(c("MWXProfilePhoto.react"), {
                size: 36,
                source: {
                    uri: c("getLSMediaContactProfilePictureUrl")(a)
                }
            }),
            addOnStartVerticalAlign: "top",
            content: k.jsx(c("MWXTextPairing.react"), {
                headline: k.jsxs(k.Fragment, {
                    children: [k.jsx(c("MWXText.react"), {
                        type: "headline4",
                        children: a.name
                    }), e ? k.jsx(c("CometPageVerificationIcon.react"), {
                        size: "small",
                        verificationBadge: "BLUE_VERIFIED",
                        xstyle: l.creatorBadge
                    }) : null]
                }),
                level: 4,
                meta: h._("__JHASH__NOWur2M4WPy__JHASH__")
            }),
            linkProps: {
                target: f,
                url: b
            },
            size: "medium"
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWXIconAccountSwitch", ["MWXSvgIcon", "SVGIcon", "cr:12265", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MWXSvgIcon").mwxSvgIcon(d("SVGIcon").svgIcon(b("cr:12265")), c("gkx")("23219"));
    g["default"] = a
}), 98);
__d("MWInboxInfoChannelPersonalInboxOptIn.react", ["fbt", "Int64Hooks", "MWChannelsPersonalInboxOptInPage.react", "MWInboxInfoButton.react", "MWXIconAccountSwitch", "MWXIconForListCell.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        var b = a.pushPage,
            e = a.thread,
            f = d("Int64Hooks").useCallbackInt64(function() {
                return b(function(a) {
                    return j.jsx(c("MWChannelsPersonalInboxOptInPage.react"), {
                        onReturn: a.onReturn,
                        threadKey: e.threadKey
                    })
                })
            }, [b, e.threadKey]);
        return j.jsx(c("MWInboxInfoButton.react"), {
            addOnStart: j.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconAccountSwitch")
            }),
            label: h._("__JHASH__iMEghxYa-Iu__JHASH__"),
            onPress: function() {
                return f()
            },
            subLabel: void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWInboxInfoSubPageHeader.react", ["fbt", "Locale", "MWXCircleButton.react", "MWXIconArrowLeft", "MWXIconArrowRight", "MWXRow.react", "MWXRowItem.react", "MWXText.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function a(a) {
        var b = a.onPressBack,
            d = a.title;
        a = a.titleComponent;
        return j.jsxs(c("MWXRow.react"), {
            paddingHorizontal: 16,
            paddingVertical: 16,
            spacingHorizontal: 8,
            children: [j.jsx(c("MWXRowItem.react"), {
                children: j.jsx(c("MWXCircleButton.react"), {
                    icon: c("Locale").isRTL() ? c("MWXIconArrowRight") : c("MWXIconArrowLeft"),
                    label: h._("__JHASH__sqTeJmgA5ut__JHASH__"),
                    onPress: b,
                    size: 32,
                    type: "deemphasized"
                })
            }), j.jsx(c("MWXRowItem.react"), {
                expanding: !0,
                verticalAlign: "center",
                children: d != null ? j.jsx(c("MWXText.react"), {
                    type: "bodyLink2",
                    children: d
                }) : a
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("XCometEventPermalinkControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/events/{event_id}/{?child_event_id}/", Object.freeze({
        active_tab: "about",
        show_created_event_toast: !1,
        hide_invite_flow_filter_groups: !1,
        show_join_in_vr_dialog: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("MWInboxInfoEventsListSection.react", ["fbt", "GroupsCometChatsEngagementLogger", "I64", "JSResourceForInteraction", "LSCommunityBitOffset", "MWCMGetValidId", "MWInboxInfoSubPageHeader.react", "MWLSThread", "MWXButton.react", "MWXCircleButton.react", "MWXColumn.react", "MWXColumnItem.react", "MWXIconAppFacebook", "MWXIconDots3Horizontal", "MWXImage.react", "MWXLazyPopoverTrigger.react", "MWXListCellPressable.react", "MWXPopoverLoadingState.react", "MWXScrollableArea.react", "MWXTextPairing.react", "ReQL", "ReQLSuspense", "XCometEventCreateControllerRouteBuilder", "XCometEventPermalinkControllerRouteBuilder", "formatDate", "gkx", "react", "useCommunityFolder", "useGroupsCometChatsEngagementImpressionLogger", "useReStore"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k, l = j || (j = d("react"));
    b = j;
    var m = b.useCallback,
        n = b.useRef,
        o = {
            eventImage: {
                borderTopStartRadius: "x1ykpwxx",
                borderTopEndRadius: "x118zf8b",
                borderBottomEndRadius: "xnwxkdh",
                borderBottomStartRadius: "xfocsrx",
                marginEnd: "xq8finb",
                $$css: !0
            }
        },
        p = c("JSResourceForInteraction")("MWInboxInfoEventsListDropdownMenu.react").__setRef("MWInboxInfoEventsListSection.react");

    function q(a) {
        var b = a.commonLoggingData,
            e = a.event,
            f = e.eventId,
            g = e.eventName,
            i = e.eventPictureUrl,
            j = e.eventPictureUrlFallback,
            m = e.numGoingUsers,
            n = e.numInterestedUsers;
        e = e.startTimeMs;
        a = a.isAdmin;
        m = (k || (k = d("I64"))).to_string(m);
        n = k.to_string(n);
        i = (i = i) != null ? i : j;
        j = e != null ? (k || (k = d("I64"))).to_float(e) : 0;
        e = new Date(j);
        var q = c("formatDate")(e, "M d");
        e = c("formatDate")(e, "g:ia");
        q = h._("__JHASH__Ah2RnxbIZcr__JHASH__", [h._param("Event start day", q), h._param("Event start time", e)]);
        e = j <= Date.now() && j !== 0;
        j = h._("__JHASH__v5PrQVy1sl6__JHASH__", [h._plural(Number(m), "number")]);
        m = h._("__JHASH__XSB3PsCrhNb__JHASH__", [h._plural(Number(m), "number")]);
        n = h._("__JHASH__fXxTlY6mdIj__JHASH__", [h._plural(Number(n), "number")]);
        e = e ? j : m.toString() + " \u2022\xa0" + n.toString();
        n = (j = c("XCometEventPermalinkControllerRouteBuilder").buildUri({
            event_id: (k || (k = d("I64"))).to_string(f)
        }).setProtocol("https")) == null ? void 0 : (m = j.setDomain("www.facebook.com")) == null ? void 0 : m.toString();
        var r = l.jsx(c("MWXTextPairing.react"), {
                body: q,
                bodyColor: "secondary",
                bodyLineLimit: 2,
                headline: g,
                level: 4,
                meta: e
            }),
            s = l.jsx(c("MWXImage.react"), {
                height: 50,
                src: i,
                xstyle: o.eventImage
            });
        j = a && c("gkx")("24076");
        return j ? l.jsx(c("MWXLazyPopoverTrigger.react"), {
            align: "end",
            fallback: l.jsx(c("MWXPopoverLoadingState.react"), {
                withArrow: !1
            }),
            popoverProps: {
                eventId: f
            },
            popoverResource: p,
            popoverType: "menu",
            children: function(a, b, d, e, f, g) {
                return l.jsx(c("MWXListCellPressable.react"), {
                    addOnEnd: l.jsx(c("MWXCircleButton.react"), {
                        icon: c("MWXIconDots3Horizontal"),
                        label: h._("__JHASH__BtbmbekLHtu__JHASH__"),
                        onHoverIn: e,
                        onHoverOut: f,
                        onPress: b,
                        onPressIn: g,
                        ref: a,
                        size: 40,
                        type: "deemphasized"
                    }),
                    addOnStart: s,
                    content: r,
                    size: "medium",
                    testid: void 0
                })
            }
        }) : l.jsx(c("MWXListCellPressable.react"), {
            addOnEnd: l.jsx(c("MWXCircleButton.react"), {
                icon: c("MWXIconAppFacebook"),
                label: h._("__JHASH__X0KyQ0oU0tZ__JHASH__"),
                linkProps: {
                    target: "_blank",
                    url: n
                },
                onPress: function() {
                    d("GroupsCometChatsEngagementLogger").log(babelHelpers["extends"]({}, b, {
                        action: "tap",
                        client_extras: {
                            event_id: (k || (k = d("I64"))).to_string(f)
                        },
                        event: "transition_to_fb_group",
                        parent_surface: "thread_view",
                        source: "event_row",
                        surface: "unknown"
                    }))
                },
                size: 40
            }),
            addOnStart: s,
            content: r,
            size: "medium",
            testid: void 0
        })
    }
    q.displayName = q.name + " [from " + f.id + "]";

    function r(a) {
        a = Array.from(a).sort(function(a, b) {
            var c;
            if ((k || (k = d("I64"))).lt((c = a == null ? void 0 : a.startTimeMs) != null ? c : (k || (k = d("I64"))).zero, (c = b == null ? void 0 : b.startTimeMs) != null ? c : (k || (k = d("I64"))).zero)) return -1;
            return (k || (k = d("I64"))).gt((c = a == null ? void 0 : a.startTimeMs) != null ? c : (k || (k = d("I64"))).zero, (a = b == null ? void 0 : b.startTimeMs) != null ? a : (k || (k = d("I64"))).zero) ? 1 : 0
        });
        var b = [],
            c = [];
        a.forEach(function(a) {
            if (a == null) return a;
            var e = a.startTimeMs != null ? (k || (k = d("I64"))).to_float(a.startTimeMs) : -1;
            e = e <= Date.now() && e !== -1;
            e ? b.push(a) : c.push(a)
        });
        return c.concat(b)
    }

    function a(a) {
        var b = a.loggingParentSurface,
            e = a.loggingSource,
            g = a.onReturn,
            j = a.threadKey,
            o = (i || (i = c("useReStore")))();
        a = d("MWLSThread").useThreadExn(j);
        var p = c("useCommunityFolder")(a),
            s = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(o.tables.cm_channel_events.index("eventsInThread")).getKeyRange(j).map(function(a) {
                    return d("ReQLSuspense").first(d("ReQL").fromTableAscending(o.tables.fb_events).getKeyRange(a.eventId), f.id + ":288")
                })
            }, [o, j], f.id + ":283"),
            t = p != null ? d("LSCommunityBitOffset").has(9, p) : !1,
            u = p != null && d("LSCommunityBitOffset").has(52, p),
            v = n(!1),
            w = m(function() {
                v.current = !0;
                return g()
            }, [g]),
            x = h._("__JHASH__1bPihBJj8iC__JHASH__");
        u = !v.current && u;
        a = (a = c("XCometEventCreateControllerRouteBuilder").buildUri({
            group_id: p != null ? (k || (k = d("I64"))).to_string(p.fbGroupId) : void 0,
            group_thread_id: (k || (k = d("I64"))).to_string(a.threadKey)
        }).setProtocol("https")) == null ? void 0 : (a = a.setDomain("www.facebook.com")) == null ? void 0 : a.toString();
        var y = {
            group_id: d("MWCMGetValidId").MWCMHasValidFbGroupId(p == null ? void 0 : p.fbGroupId) ? (k || (k = d("I64"))).to_string(p.fbGroupId) : null,
            surface: "event_list",
            thread_id: (k || (k = d("I64"))).to_string(j)
        };
        p = r(s);
        s = c("useGroupsCometChatsEngagementImpressionLogger")(babelHelpers["extends"]({}, y, {
            client_extras: {
                event_id_list: p.map(function(a) {
                    return (k || (k = d("I64"))).to_string(a.eventId)
                }).join(",")
            },
            event: "event_list_rendered",
            parent_surface: b,
            source: e
        }));
        return l.jsxs("div", {
            className: "x78zum5 x1r8uery xdt5ytf x1iyjqo2 xs83m0k x2lwn1j",
            children: [l.jsx(c("MWInboxInfoSubPageHeader.react"), {
                onPressBack: w,
                title: x
            }), l.jsx("div", {
                className: "x78zum5 xdt5ytf xs83m0k x2lwn1j",
                children: l.jsx(c("MWXScrollableArea.react"), {
                    expanding: !0,
                    children: l.jsx(c("MWXColumn.react"), {
                        hasDividers: !1,
                        paddingHorizontal: 8,
                        ref: s,
                        spacing: 20,
                        children: p.map(function(a) {
                            return l.jsx(c("MWXColumnItem.react"), {
                                children: l.jsx(q, {
                                    commonLoggingData: y,
                                    event: a,
                                    isAdmin: t
                                })
                            }, (k || (k = d("I64"))).to_string(a.eventId))
                        })
                    })
                })
            }), u && l.jsx("div", {
                className: "xyamay9 x1l90r2v x1swvt13 x1pi30zi",
                children: l.jsx(c("MWXButton.react"), {
                    label: h._("__JHASH__jhw66QHG4uX__JHASH__"),
                    linkProps: {
                        target: "_blank",
                        url: a
                    },
                    onPress: function() {
                        d("GroupsCometChatsEngagementLogger").log(babelHelpers["extends"]({}, y, {
                            action: "tap",
                            event: "create_event_clicked",
                            parent_surface: "thread_settings",
                            source: "create_new_event_button"
                        }))
                    },
                    type: "secondary"
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWInboxInfoViewPinnedMessages.react", ["fbt", "JSResourceForInteraction", "LSMessagingThreadTypeUtil", "MWBroadcastChannelLoggingShapes", "MWInboxInfoButton.react", "MWLogBroadcastChannelFalcoEvent", "MWPBumpEntityKey", "MWXIconForListCell.react", "MWXIconPushpin", "react", "useMWXLazyDialog"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react"),
        k = h._("__JHASH__xaWBg6G3BFD__JHASH__"),
        l = c("JSResourceForInteraction")("MWPinnedMessagesDialog.react").__setRef("MWInboxInfoViewPinnedMessages.react");

    function a(a) {
        var b = a.thread;
        a = c("useMWXLazyDialog")(l);
        var e = a[0];
        a = {
            eventName: "open_view_pinned_messages_dialog",
            threadKey: b.threadKey,
            threadType: b.threadType
        };
        var f = d("LSMessagingThreadTypeUtil").isDiscoverablePublicBroadcastChannel(b.threadType);
        return j.jsx(c("MWInboxInfoButton.react"), {
            addOnStart: j.jsx(c("MWXIconForListCell.react"), {
                icon: c("MWXIconPushpin")
            }),
            label: k,
            loggingEvent: a,
            onPress: function() {
                d("MWPBumpEntityKey").bumpEntityKeyWithAppId("mw.infobar", "view_pinned_messages"), f && d("MWLogBroadcastChannelFalcoEvent").logBroadcastChannelFalcoEvent(babelHelpers["extends"]({}, d("MWBroadcastChannelLoggingShapes").VIEW_PINNED_MESSAGES_FROM_THREAD_DETAIL, {
                    threadFbid: b.threadKey
                })), e({
                    threadKey: b.threadKey
                })
            },
            testid: void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWInboxInfoGroupInfoSection.react", ["LSCommunityBitOffset", "MWCMBotDetailsEntrypoint.react", "MWCMInboxInfoGroupEventsButton.react", "MWCMInboxInfoGroupLink.react", "MWCMInboxInfoMemberRequests.react", "MWCMSubthreadlistMenuItem.react", "MWInboxInfoChannelCreatorProfileLink.react", "MWInboxInfoChannelPersonalInboxOptIn.react", "MWInboxInfoViewPinnedMessages.react", "MWPActor.react", "cr:3773", "gkx", "qex", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var e = a.pushPage,
            f = a.thread;
        a = a.utilities;
        var g = a.folder,
            h = a.inviteLink,
            j = a.isAdmin,
            k = a.isChannel,
            l = a.isSMCC,
            m = a.shouldShowBotEntryPoint,
            n = a.shouldShowPinnedMessagesLink,
            o = a.showCMMemberRequestsMenuItem,
            p = a.showMemberRequests;
        a = a.showSubthreadListButton;
        j = k && j && d("MWPActor.react").isAPPlus();
        k = [k ? i.jsx(c("MWInboxInfoChannelCreatorProfileLink.react"), {
            threadKey: f.threadKey
        }, "creator-profile") : null, j && c("gkx")("3812") && c("qex")._("837") ? i.jsx(c("MWInboxInfoChannelPersonalInboxOptIn.react"), {
            pushPage: e,
            thread: f
        }, "channel-personal-inbox") : null, m ? i.jsx(c("MWCMBotDetailsEntrypoint.react"), {
            thread: f
        }, "bot") : null, g != null && d("LSCommunityBitOffset").has(3, g) ? i.jsx(c("MWCMInboxInfoGroupLink.react"), {
            folder: g
        }, "group-link") : null, a ? i.jsx(c("MWCMSubthreadlistMenuItem.react"), {
            threadKey: f.threadKey
        }, "subthreads-button") : null, h != null ? h : null, g != null && !l ? i.jsx(c("MWCMInboxInfoGroupEventsButton.react"), {
            pushPage: e,
            threadKey: f.threadKey
        }, "events-button") : null, n ? i.jsx(c("MWInboxInfoViewPinnedMessages.react"), {
            thread: f
        }, "pin") : null, p && b("cr:3773") != null ? i.jsx(b("cr:3773"), {
            pushPage: e,
            thread: f
        }, "reqs") : null, o ? i.jsx(c("MWCMInboxInfoMemberRequests.react"), {
            pushPage: e,
            thread: f
        }, "cm-member-requests") : null];
        j = k.some(function(a) {
            return a != null
        });
        return j ? k : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWPParticipantsAndContactsForThread_DO_NOT_USE_THIS_WILL_KILL_PERFORMANCE", ["ReQL", "ReQLSuspense", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var b = (h || (h = c("useReStore")))();
        return d("ReQLSuspense").useArray(function() {
            return d("ReQL").mergeJoin(d("ReQL").fromTableAscending(b.tables.participants).getKeyRange(a.threadKey), d("ReQL").fromTableAscending(b.tables.contacts))
        }, [b, a.threadKey], f.id + ":28")
    }
    g.useValue = a
}), 98);
__d("MWInboxInfoMemberList.react", ["fbt", "LSMessagingThreadTypeUtil", "MWAddMemberToGroupListCell.react", "MWGroupLimitContainer.react", "MWGroupMembershipListItem", "MWLSGroupMembershipMemberList.react", "MWPParticipantsAndContactsForThread_DO_NOT_USE_THIS_WILL_KILL_PERFORMANCE", "MWXListCell.react", "MWXText.react", "canMWAddMemberToGroupThread", "isFeatureLimitEnabled", "mwCMIsAnyCMThread", "react", "useIsReadOnlyFeatureLimitedWithThreadType", "withCometPlaceholder"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || d("react");

    function k(a) {
        a = a.thread;
        return j.jsx(c("MWGroupLimitContainer.react"), {
            groupLimitReachedContent: j.jsx(c("MWXListCell.react"), {
                content: j.jsx(c("MWXText.react"), {
                    color: "secondary",
                    testid: void 0,
                    type: "body4",
                    children: h._("__JHASH____m4bWP_4pT__JHASH__")
                }),
                size: "medium"
            }),
            thread: a,
            children: j.jsx(c("MWAddMemberToGroupListCell.react"), {
                thread: a
            })
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function a(a) {
        a = a.thread;
        var b = d("LSMessagingThreadTypeUtil").isArmadilloSecure(a.threadType);
        b = c("useIsReadOnlyFeatureLimitedWithThreadType")(a.threadType) && (!b || c("isFeatureLimitEnabled")());
        b = c("canMWAddMemberToGroupThread")(a, b);
        var e = d("MWPParticipantsAndContactsForThread_DO_NOT_USE_THIS_WILL_KILL_PERFORMANCE").useValue(a),
            f = !c("mwCMIsAnyCMThread")(a.threadType);
        return j.jsxs(j.Fragment, {
            children: [j.jsx(c("MWLSGroupMembershipMemberList.react"), {
                disableScroll: !0,
                participantsAndContacts: e.map(function(a) {
                    var b = a[0];
                    a = a[1];
                    return {
                        contact: a,
                        participant: b,
                        type: d("MWGroupMembershipListItem").MWGroupMembershipMemberTypes.ParticipantAndContact
                    }
                }),
                showAdmodIndicator: f,
                showAdmodsOnly: !1,
                showHostsOnly: !1,
                showInvitedByViewerOnly: !1,
                thread: a
            }), b ? j.jsx(k, {
                thread: a
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = d("withCometPlaceholder").withCometPlaceholder(a, null, "MWInboxInfoMemberListInternal");
    g["default"] = b
}), 226);
__d("MessengerRoomContentActionsFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("822");
    b = d("FalcoLoggerInternal").create("messenger_room_content_actions", a);
    e = b;
    g["default"] = e
}), 98);
__d("MWInboxInfoSharedContentLogger", ["$InternalEnum", "I64", "LSIntEnum", "MessengerRoomContentActionsFalcoEvent", "MessengerWebEventsFalcoEvent", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = b("$InternalEnum").Mirrored(["FilesTab", "LinksTab", "MediaTab", "ThreadDetails"]);

    function k(a, b) {
        var c = a.threadKey;
        a = a.threadType;
        c = (h || (h = d("I64"))).to_string(c);
        var e = b || !(h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(2)) ? null : c;
        b = b || !(h || (h = d("I64"))).equal(a, (i || (i = d("LSIntEnum"))).ofNumber(1)) ? null : c;
        return [e, b]
    }
    var l = c("gkx")("24035");

    function m(a) {
        switch (a) {
            case j.FilesTab:
                return "files_tab";
            case j.LinksTab:
                return "links_tab";
            case j.MediaTab:
                return "media_tab";
            case j.ThreadDetails:
                return "thread_details"
        }
    }

    function n(a) {
        switch (a) {
            case j.FilesTab:
                return "files_tab";
            case j.LinksTab:
                return "links_tab";
            case j.MediaTab:
                return "media_tab";
            case j.ThreadDetails:
                return "thread_details"
        }
    }

    function o(a) {
        if (l) return c("MessengerWebEventsFalcoEvent").log(a)
    }

    function a(a, b) {
        a = k(a, b);
        var d = a[0],
            e = a[1];
        return c("MessengerRoomContentActionsFalcoEvent").log(function() {
            return {
                event: "open_content_panel",
                peer_id: e,
                thread_id: d
            }
        })
    }

    function e(a, b, e, f, g) {
        var i = m(e),
            j = n(e);
        e = k(b, f);
        var l = e[0],
            p = e[1];
        o(function() {
            return {
                entry_point: i,
                event_name: "shared_file_click",
                "interface": "Web Chat",
                is_secured: f,
                other_user_fbid: p,
                thread_fbid: l
            }
        });
        return c("MessengerRoomContentActionsFalcoEvent").log(function() {
            return {
                entry_point: j,
                event: "click_shared_file",
                file_size: a.filesize != null ? (h || (h = d("I64"))).to_int32(a.filesize).toString() : void 0,
                num_attachments: g.toString(),
                peer_id: p,
                thread_id: l
            }
        })
    }

    function f(a, b, e, f, g) {
        var i = m(e),
            j = n(e);
        e = k(b, f);
        var l = e[0],
            p = e[1];
        o(function() {
            return {
                entry_point: i,
                event_name: "shared_media_click",
                "interface": "Web Chat",
                is_secured: f,
                other_user_fbid: p,
                thread_fbid: l
            }
        });
        return c("MessengerRoomContentActionsFalcoEvent").log(function() {
            return {
                entry_point: j,
                event: "click_shared_media",
                file_size: a.filesize != null ? (h || (h = d("I64"))).to_int32(a.filesize).toString() : void 0,
                num_attachments: g.toString(),
                peer_id: p,
                thread_id: l
            }
        })
    }

    function p(a, b, d, e) {
        var f = m(b),
            g = n(b);
        b = k(a, d);
        var h = b[0],
            i = b[1];
        o(function() {
            return {
                entry_point: f,
                event_name: "shared_link_click",
                "interface": "Web Chat",
                is_secured: d,
                other_user_fbid: i,
                thread_fbid: h
            }
        });
        return c("MessengerRoomContentActionsFalcoEvent").log(function() {
            return {
                entry_point: g,
                event: "click_shared_link",
                num_attachments: e.toString(),
                peer_id: i,
                thread_id: h
            }
        })
    }
    g.SharedContentEntrypoint = j;
    g.getWebEntrypoint = m;
    g.logOpenContentPanel = a;
    g.logFilePress = e;
    g.logMediaPress = f;
    g.logLinkPress = p
}), 98);
__d("MWInboxInfoSharedContentFilesTab.react", ["MWInboxInfoFileGallery.react", "MWInboxInfoSharedContentLogger", "MWSharedAttachmentsSectionHooks", "react", "useLoadMoreThreadSharedAttachments.react", "useMWMediaLoadingQplLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useEffect,
        l = b.useRef;

    function a(a) {
        var b = a.isSecureThread,
            e = a.onFirstLoadedMedia,
            f = a.thread;
        a = d("MWSharedAttachmentsSectionHooks").useQueryFileAttachments(f.threadKey);
        var g = a[0],
            h = a[1],
            m = a[2];
        a[3];
        a = a[4];
        var n = l(!1),
            o = c("useMWMediaLoadingQplLogger")({
                entrypoint: "file_gallery",
                threadType: f.threadType
            });
        h = c("useLoadMoreThreadSharedAttachments.react")(h, f.threadKey, o.logLoadMediaStart);
        m = d("MWSharedAttachmentsSectionHooks").useLoader({
            attachmentsRange: m,
            hasMore: (m = a) != null ? m : !0,
            loadMore: h,
            logLoadMediaCancel: o.logLoadMediaCancel,
            logLoadMediaSuccess: o.logLoadMediaSuccess,
            media: g
        });
        h = m[0];
        o = m[1];
        var p = m[2];
        k(function() {
            n.current === !1 && p === !0 && (n.current = !0, e(g))
        }, [p, g, e]);
        m = j(function(a) {
            d("MWInboxInfoSharedContentLogger").logFilePress(a, f, d("MWInboxInfoSharedContentLogger").SharedContentEntrypoint.FilesTab, b, g.length)
        }, [f, b, g]);
        return i.jsx(c("MWInboxInfoFileGallery.react"), {
            files: g,
            hasMore: (a = a) != null ? a : !0,
            isLoading: h,
            onLoadMore: o,
            onPressFile: m,
            threadKey: f.threadKey,
            threadType: f.threadType
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxInfoSharedLinks.react", ["BaseTheme.react", "CometInfiniteScrollTrigger.react", "CometProgressIndicator.react", "MWInboxInfoSharedContentEmptyTab.react", "MWInboxInfoSharedContentTheme", "MWInboxInfoSharedLink.react", "MWXColumn.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            progressIndicator: {
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginBottom: "x1e56ztr",
                marginTop: "x1xmf6yo",
                paddingTop: "x123j3cw",
                paddingEnd: "x1mpkggp",
                paddingBottom: "xs9asl8",
                paddingStart: "x1t2a60a",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.hasMore,
            e = a.isLoading,
            f = a.links,
            g = a.onLoadMore,
            h = a.onPressLink,
            k = a.thread;
        if (f.length === 0 && !e && !b) return i.jsx(c("MWInboxInfoSharedContentEmptyTab.react"), {
            contentType: "links",
            threadKey: k.threadKey
        });
        else return i.jsx(c("BaseTheme.react"), {
            config: d("MWInboxInfoSharedContentTheme").config,
            children: i.jsxs(c("MWXColumn.react"), {
                hasDividers: !0,
                paddingHorizontal: 16,
                spacing: 20,
                children: [f.map(function(a) {
                    return i.jsx(c("MWInboxInfoSharedLink.react"), {
                        attachment: a,
                        onPress: h,
                        threadType: k.threadType
                    }, a.attachmentFbid)
                }), i.jsx(c("CometInfiniteScrollTrigger.react"), {
                    hasMore: b,
                    isLoading: e,
                    onLoadMore: g,
                    xstyle: j.progressIndicator,
                    children: i.jsx(c("CometProgressIndicator.react"), {
                        size: "default"
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxInfoSharedLinksSection.react", ["MWInboxInfoSharedContentLogger", "MWInboxInfoSharedLinks.react", "MWSharedAttachmentsSectionHooks", "react", "useLoadMoreThreadSharedAttachments.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useEffect,
        l = b.useRef;

    function a(a) {
        var b = a.isSecureThread,
            e = a.onFirstLoadedMedia,
            f = a.thread;
        a = d("MWSharedAttachmentsSectionHooks").useQueryLinkAttachments(f.threadKey);
        var g = a[0],
            h = a[1],
            m = a[2];
        a[3];
        a = a[4];
        var n = c("useLoadMoreThreadSharedAttachments.react")(h, f.threadKey),
            o = l(!1);
        k(function() {
            n()
        }, [n]);
        m = d("MWSharedAttachmentsSectionHooks").useLoader({
            attachmentsRange: m,
            hasMore: (h = a) != null ? h : !0,
            loadMore: n,
            media: g
        });
        h = m[0];
        var p = m[1],
            q = m[2];
        k(function() {
            o.current === !1 && q === !0 && (o.current = !0, e(g))
        }, [q, g, e]);
        m = j(function() {
            d("MWInboxInfoSharedContentLogger").logLinkPress(f, d("MWInboxInfoSharedContentLogger").SharedContentEntrypoint.LinksTab, b, g.length)
        }, [f, b, g]);
        return i.jsx(c("MWInboxInfoSharedLinks.react"), {
            hasMore: (a = a) != null ? a : !0,
            isLoading: h,
            links: g,
            onLoadMore: p,
            onPressLink: m,
            thread: f
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxInfoSharedMediaTab.react", ["MWInboxInfoPhotoGallery.react", "MWInboxInfoSharedContentLogger", "MWSharedAttachmentsSectionHooks", "react", "useLoadMoreThreadSharedAttachments.react", "useMWMediaLoadingQplLogger", "useMWV2MediaViewerOpenPlayableUrl", "useMWV2MediaViewerOpenPreviewUrl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useCallback,
        k = b.useEffect,
        l = b.useRef;

    function a(a) {
        var b = a.isSecureThread,
            e = a.onFirstLoadedMedia,
            f = a.thread,
            g = l(!1);
        a = d("MWSharedAttachmentsSectionHooks").useQueryMediaAttachments(f.threadKey);
        var h = a[0],
            m = a[1],
            n = a[2];
        a[3];
        a = a[4];
        a = a === void 0 ? !0 : a;
        var o = c("useMWMediaLoadingQplLogger")({
            entrypoint: "media_gallery",
            threadType: f.threadType
        });
        m = c("useLoadMoreThreadSharedAttachments.react")(m, f.threadKey, o.logLoadMediaStart);
        n = d("MWSharedAttachmentsSectionHooks").useLoader({
            attachmentsRange: n,
            hasMore: a,
            loadMore: m,
            logLoadMediaCancel: o.logLoadMediaCancel,
            logLoadMediaSuccess: o.logLoadMediaSuccess,
            media: h
        });
        m = n[0];
        o = n[1];
        var p = n[2];
        k(function() {
            g.current === !1 && p === !0 && (g.current = !0, e(h))
        }, [p, h, e]);
        var q = c("useMWV2MediaViewerOpenPreviewUrl")();
        n = c("useMWV2MediaViewerOpenPlayableUrl")();
        var r = j(function(a, b, c) {
                return (c = q(a, b)) != null ? c : ""
            }, [q]),
            s = j(function(a) {
                d("MWInboxInfoSharedContentLogger").logMediaPress(a, f, d("MWInboxInfoSharedContentLogger").SharedContentEntrypoint.MediaTab, b, h.length)
            }, [f, b, h.length]);
        return i.jsx(c("MWInboxInfoPhotoGallery.react"), {
            getPlayableUrl: n,
            getPreviewUrl: r,
            hasMore: a,
            isLoading: m,
            media: h,
            onLoadMore: o,
            onPressMedia: s,
            threadKey: f.threadKey,
            threadType: f.threadType
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxInfoSharedTabContent.react", ["I64", "MAWCutoverInboxInfoSharedMediaTab.react", "MAWMediaGalleryM2Utils", "MAWSecureInboxInfoSharedFilesTab.react", "MAWSecureInboxInfoSharedLinksTab.react", "MAWSecureInboxInfoSharedMediaTab.react", "MWEBEntrypointsKillswitch.enum", "MWInboxInfoSharedContentFilesTab.react", "MWInboxInfoSharedLinksSection.react", "MWInboxInfoSharedMediaTab.react", "MWInboxMessageSearchStatusTypes", "MWMediaRestoreQplUtils", "MWMediaRestoreStatus", "MWXScrollableArea.react", "cr:10179", "cr:10264", "cr:7835", "gkx", "react", "useMWEBBackupState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h || (h = d("react"));
    e = h;
    var k = e.useEffect,
        l = e.useMemo;

    function a(a) {
        var e = a.isBackButtonPressed,
            f = a.isCutoverThread,
            g = a.isSecureThread,
            h = a.onFirstLoadedMedia,
            m = a.selectedTab,
            q = a.sharedLinksEnabled;
        a = a.thread;
        var r = a.threadKey,
            s = a.threadType,
            t = g && m === "media" && d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled(),
            u = g && m === "files" && d("MAWMediaGalleryM2Utils").isFilesEBRestoreEnabled(),
            v = b("cr:7835")({
                threadKey: r,
                threadType: s
            }),
            w = c("useMWEBBackupState")({
                entrypoint: c("MWEBEntrypointsKillswitch.enum").MEDIA_GALLERY_RESTORE
            }),
            x = b("cr:10179")({
                threadKey: r,
                threadType: s
            });
        s = x === d("MWInboxMessageSearchStatusTypes").RestoreStatus.IN_PROGRESS;
        var y = l(function() {
            return d("MWMediaRestoreQplUtils").createMediaRestoreLoadAllQPLFlow()
        }, []);
        k(function() {
            if (w === 3 && (t || u)) {
                x === d("MWInboxMessageSearchStatusTypes").RestoreStatus.NOT_RUNNING && (y.start(), (v == null ? void 0 : v.onEBOnboarded) && (v == null ? void 0 : v.onEBOnboarded()));
                if (x === d("MWInboxMessageSearchStatusTypes").RestoreStatus.COMPLETE) {
                    var a = d("MWMediaRestoreStatus").getRestoreStatus(),
                        b = a.mediaCount,
                        c = a.messageCount;
                    a = a.threadId;
                    a != null && (i || (i = d("I64"))).equal(r, a) && y.addAnnotations({
                        "int": {
                            media_count: b,
                            message_count: c
                        }
                    });
                    y.endSuccess()
                }
            }
        }, [w, v, u, t, y, x, r]);
        switch (m) {
            case "media":
                return j.jsx(n, {
                    backupState: w,
                    isBackButtonPressed: e,
                    isCutoverThread: f,
                    isRestoringFromEB: s,
                    isSecureThread: g,
                    onFirstLoadedMedia: h,
                    thread: a
                });
            case "files":
                return j.jsx(o, {
                    backupState: w,
                    isCutoverThread: f,
                    isRestoringFromEB: s,
                    isSecureThread: g,
                    onFirstLoadedMedia: h,
                    thread: a
                });
            case "links":
                return j.jsx(p, {
                    isSecureThread: g,
                    onFirstLoadedMedia: h,
                    sharedLinksEnabled: q,
                    thread: a
                })
        }
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function m(a) {
        var b = a.isSecureThread,
            d = a.onFirstLoadedMedia,
            e = a.sharedLinksEnabled;
        a = a.thread;
        if (!e) return null;
        return b ? j.jsx(c("MAWSecureInboxInfoSharedLinksTab.react"), {
            thread: a
        }) : j.jsx(c("MWInboxInfoSharedLinksSection.react"), {
            isSecureThread: b,
            onFirstLoadedMedia: d,
            thread: a
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";

    function n(a) {
        var b = a.backupState,
            d = a.isBackButtonPressed,
            e = a.isCutoverThread,
            f = a.isRestoringFromEB,
            g = a.isSecureThread,
            h = a.onFirstLoadedMedia;
        a = a.thread;
        if (e && c("gkx")("2616") === !0) return j.jsx(c("MAWCutoverInboxInfoSharedMediaTab.react"), {
            backupState: b,
            isBackButtonPressed: d,
            isRestoringFromEB: f,
            onFirstLoadedMedia: h,
            secureThreadKey: a.threadKey,
            threadType: a.threadType
        });
        return g ? j.jsx(c("MAWSecureInboxInfoSharedMediaTab.react"), {
            backupState: b,
            isBackButtonPressed: d,
            isRestoringFromEB: f,
            onFirstLoadedMedia: h,
            thread: a
        }) : j.jsx(c("MWInboxInfoSharedMediaTab.react"), {
            isSecureThread: g,
            onFirstLoadedMedia: h,
            thread: a
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function o(a) {
        var d = a.backupState,
            e = a.isCutoverThread,
            f = a.isRestoringFromEB,
            g = a.isSecureThread,
            h = a.onFirstLoadedMedia;
        a = a.thread;
        if (e && b("cr:10264") != null) return j.jsx(b("cr:10264"), {
            backupState: d,
            isRestoringFromEB: f,
            onFirstLoadedMedia: h,
            secureThreadKey: a.threadKey,
            threadType: a.threadType
        });
        return g ? j.jsx(c("MAWSecureInboxInfoSharedFilesTab.react"), {
            backupState: d,
            isRestoringFromEB: f,
            onFirstLoadedMedia: h,
            thread: a
        }) : j.jsx(c("MWInboxInfoSharedContentFilesTab.react"), {
            isSecureThread: g,
            onFirstLoadedMedia: h,
            thread: a
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function p(a) {
        var b = a.isSecureThread,
            d = a.onFirstLoadedMedia,
            e = a.sharedLinksEnabled;
        a = a.thread;
        return j.jsx(c("MWXScrollableArea.react"), {
            expanding: !0,
            children: j.jsx(m, {
                isSecureThread: b,
                onFirstLoadedMedia: d,
                sharedLinksEnabled: e,
                thread: a
            })
        })
    }
    p.displayName = p.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxInfoSharedContent.react", ["fbt", "MWInboxInfoSharedContentLogger", "MWInboxInfoSharedTabContent.react", "MWInboxInfoSubPageHeader.react", "MWXColumn.react", "MWXColumnItem.react", "MWXTabs.react", "MessengerWebUXLogger", "react", "usePrevious", "withCometPlaceholder"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react"));
    b = i;
    var k = b.useCallback,
        l = b.useEffect,
        m = b.useMemo,
        n = b.useRef,
        o = b.useState,
        p = {
            root: {
                flexBasis: "x1r8uery",
                flexGrow: "x1iyjqo2",
                minHeight: "x2lwn1j",
                $$css: !0
            }
        };

    function q(a, b, c) {
        var d, e, f;
        switch (a) {
            case "media":
                f = "mw_shared_media_tab";
                e = h._("__JHASH__Vlach4Yw5My__JHASH__");
                break;
            case "files":
                f = "mw_shared_files_tab";
                e = h._("__JHASH__FHoGsrpePI0__JHASH__");
                break;
            case "links":
                f = "mw_shared_links_tab";
                e = h._("__JHASH__HIyYRXboLqA__JHASH__");
                break
        }
        return {
            label: (d = e) != null ? d : "",
            onPress: function() {
                return c(a)
            },
            selected: b === a,
            testid: (d = f) != null ? d : ""
        }
    }

    function a(a) {
        var b = a.initialTab,
            e = a.isCutoverThread,
            f = a.isSecureThread,
            g = a.onReturn,
            i = a.sharedLinksEnabled,
            r = a.thread,
            s = m(function() {
                return ["media", "files"].concat(i ? "links" : [])
            }, [i]);
        a = o((a = b) != null ? a : s[0]);
        var t = a[0],
            u = a[1],
            v = c("usePrevious")(t),
            w = n(new Set()),
            x = c("MessengerWebUXLogger").useInteractionLogger();
        a = k(function(a) {
            var b, c;
            if (v == null) b = "thread_details";
            else switch (v) {
                case "media":
                    b = "media_tab";
                    break;
                case "files":
                    b = "files_tab";
                    break;
                case "links":
                    b = "links_tab";
                    break;
                default:
                    b = "thread_details";
                    break
            }
            a = a.length;
            w.current.add(t);
            switch (t) {
                case "media":
                    c = "open_media_tab";
                    break;
                case "files":
                    c = "open_files_tab";
                    break;
                case "links":
                    c = "open_links_tab";
                    break;
                default:
                    c = "open_media_tab";
                    break
            }
            x == null ? void 0 : x({
                entryPoint: b,
                eventName: c,
                extraData: {
                    isCutoverThread: e.toString(),
                    numAttachments: a.toString()
                },
                threadKey: r.threadKey,
                threadType: r.threadType
            })
        }, [v, r, t, w, x, e]);
        var y = m(function() {
                return s.map(function(a) {
                    return q(a, t, u)
                })
            }, [s, t]),
            z = o(!1),
            A = z[0],
            B = z[1];
        z = k(function() {
            B(!0);
            return g()
        }, [g]);
        l(function() {
            d("MWInboxInfoSharedContentLogger").logOpenContentPanel(r, f)
        }, [b, A, f, s, r]);
        return j.jsxs(c("MWXColumn.react"), {
            spacing: 12,
            xstyle: p.root,
            children: [j.jsx(c("MWXColumnItem.react"), {
                children: j.jsx(c("MWInboxInfoSubPageHeader.react"), {
                    onPressBack: z,
                    title: i ? h._("__JHASH__IJaUCbo68p8__JHASH__") : h._("__JHASH__4EGmvHMttO2__JHASH__")
                })
            }), j.jsx(c("MWXColumnItem.react"), {
                paddingHorizontal: 16,
                children: j.jsx(c("MWXTabs.react"), {
                    tabs: y
                })
            }), j.jsx(c("MWXColumnItem.react"), {
                expanding: !0,
                children: j.jsx(c("MWInboxInfoSharedTabContent.react"), {
                    isBackButtonPressed: A,
                    isCutoverThread: e,
                    isSecureThread: f,
                    onFirstLoadedMedia: a,
                    selectedTab: t,
                    sharedLinksEnabled: i,
                    thread: r
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = d("withCometPlaceholder").withCometPlaceholder(a, null, "MWInboxInfoSharedContent");
    g["default"] = e
}), 226);
__d("MWInfoMemberListWrapper.react", ["LSMessagingThreadTypeUtil", "MWInboxInfoMemberList.react", "cr:4705", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var e = a.folder,
            f = a.isCMThread;
        a = a.thread;
        var g = d("LSMessagingThreadTypeUtil").isJoinedSocialChannelV2(a.threadType),
            h = d("LSMessagingThreadTypeUtil").isDiscoverablePublicBroadcastChannel(a.threadType);
        return b("cr:4705") == null || !(e != null && f) && !g && !h ? i.jsx(c("MWInboxInfoMemberList.react"), {
            thread: a
        }) : i.jsx(b("cr:4705"), {
            folder: e,
            thread: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MessengerAccountSwitchFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M24 14c-1.613 0-3-1.141-3-3.624C21 8.351 22.263 7 24 7s3 1.35 3 3.376C27 12.86 25.613 14 24 14zM19 19c0-1.933 2.239-3.5 5-3.5s5 1.567 5 3.5a1 1 0 0 1-1 1h-8a1 1 0 0 1-1-1zM12 23c-1.613 0-3-1.141-3-3.624C9 17.351 10.263 16 12 16s3 1.351 3 3.376C15 21.86 13.613 23 12 23zM7 28c0-1.933 2.239-3.5 5-3.5s5 1.567 5 3.5a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1zM19.013 9.976c.022-.326.078-.775.21-1.263.093-.346-.153-.713-.51-.713H12a4 4 0 0 0-4 4v2.78c0 .45.552.665.856.335.39-.325.827-.584 1.296-.77a.536.536 0 0 0 .348-.49V12a1.5 1.5 0 0 1 1.5-1.5h6.475c.286 0 .518-.24.538-.524zM26.5 22a1 1 0 0 0-1 1v1a1.5 1.5 0 0 1-1.5 1.5h-4.832c-.395 0-.642.444-.494.81.149.373.253.77.299 1.19.03.275.25.5.527.5H24a4 4 0 0 0 4-4v-1a1 1 0 0 0-1-1h-.5z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("MessengerFriendGenericCheckmarkFilled.svg.react", ["XPlatReactSVG", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs(d("XPlatReactSVG").Svg, babelHelpers["extends"]({
            viewBox: "0 0 36 36",
            fill: "currentColor",
            width: "1em",
            height: "1em",
            title: a.title
        }, a, {
            children: [a.children != null && i.jsx(d("XPlatReactSVG").Defs, {
                children: a.children
            }), i.jsx(d("XPlatReactSVG").Path, {
                d: "M17.25 12.305C17.25 16.207 19.446 18 22 18s4.75-1.793 4.75-5.695C26.75 9.123 24.75 7 22 7s-4.75 2.123-4.75 5.305zM29.94 28c.69 0 1.06-.595 1.06-1.335C31 22.985 26.835 20 22 20s-9 2.985-9 6.665c0 .74.37 1.335 1.06 1.335h15.88zM13.865 12.502a1 1 0 0 0-1.73-1.004l-3.829 6.595a.25.25 0 0 1-.393.051l-2.206-2.206a1 1 0 0 0-1.414 1.414l3.355 3.355a1 1 0 0 0 1.572-.205l4.645-8z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);