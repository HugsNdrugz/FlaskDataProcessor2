; /*FB_PKG_DELIM*/

__d("EmojiRendererData", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {}
        a.isEmoji = function(a) {
            return a > 983041 || a < 35 ? !1 : a === 35 || a === 42 || a >= 48 && a <= 57 || a === 169 || a === 174 || a === 8205 || a === 8252 || a === 8265 || a === 8419 || a === 8482 || a === 8505 || a >= 8596 && a <= 8601 || a >= 8617 && a <= 8618 || a >= 8986 && a <= 8987 || a === 9e3 || a === 9167 || a >= 9193 && a <= 9203 || a >= 9208 && a <= 9210 || a === 9410 || a >= 9642 && a <= 9643 || a === 9654 || a === 9664 || a >= 9723 && a <= 9726 || a >= 9728 && a <= 9732 || a === 9742 || a === 9745 || a >= 9748 && a <= 9749 || a === 9752 || a === 9760 || a >= 9762 && a <= 9763 || a === 9766 || a === 9770 || a >= 9774 && a <= 9775 || a >= 9784 && a <= 9786 || a === 9792 || a === 9794 || a >= 9800 && a <= 9811 || a >= 9823 && a <= 9824 || a === 9827 || a >= 9829 && a <= 9830 || a === 9832 || a === 9851 || a >= 9854 && a <= 9855 || a >= 9874 && a <= 9879 || a === 9881 || a >= 9883 && a <= 9884 || a >= 9888 && a <= 9889 || a === 9895 || a >= 9898 && a <= 9899 || a >= 9904 && a <= 9905 || a >= 9917 && a <= 9918 || a >= 9924 && a <= 9925 || a === 9928 || a >= 9934 && a <= 9935 || a === 9937 || a >= 9939 && a <= 9940 || a >= 9961 && a <= 9962 || a >= 9968 && a <= 9973 || a >= 9975 && a <= 9976 || a === 9978 || a === 9981 || a === 9986 || a === 9989 || a >= 9992 && a <= 9993 || a === 9999 || a === 10002 || a === 10004 || a === 10006 || a === 10013 || a === 10017 || a === 10024 || a >= 10035 && a <= 10036 || a === 10052 || a === 10055 || a === 10060 || a === 10062 || a >= 10067 && a <= 10069 || a === 10071 || a >= 10083 && a <= 10084 || a >= 10133 && a <= 10135 || a === 10145 || a === 10160 || a === 10175 || a >= 10548 && a <= 10549 || a >= 11013 && a <= 11015 || a >= 11035 && a <= 11036 || a === 11088 || a === 11093 || a === 12336 || a === 12349 || a === 12951 || a === 12953 || a === 126980 || a === 127183 || a >= 127344 && a <= 127345 || a >= 127358 && a <= 127359 || a === 127374 || a >= 127377 && a <= 127386 || a >= 127462 && a <= 127487 || a >= 127489 && a <= 127490 || a === 127514 || a === 127535 || a >= 127538 && a <= 127546 || a >= 127568 && a <= 127569 || a >= 127744 && a <= 127777 || a >= 127780 && a <= 127876 || a >= 127878 && a <= 127891 || a >= 127894 && a <= 127895 || a >= 127897 && a <= 127899 || a >= 127902 && a <= 127937 || a >= 127941 && a <= 127942 || a >= 127944 && a <= 127945 || a >= 127949 && a <= 127984 || a >= 127987 && a <= 127989 || a >= 127991 && a <= 127994 || a >= 128e3 && a <= 128065 || a >= 128068 && a <= 128069 || a >= 128081 && a <= 128101 || a >= 128121 && a <= 128123 || a >= 128125 && a <= 128128 || a === 128132 || a >= 128136 && a <= 128142 || a === 128144 || a >= 128146 && a <= 128169 || a >= 128171 && a <= 128253 || a >= 128255 && a <= 128317 || a >= 128329 && a <= 128334 || a >= 128336 && a <= 128359 || a >= 128367 && a <= 128368 || a === 128371 || a >= 128374 && a <= 128377 || a === 128391 || a >= 128394 && a <= 128397 || a >= 128420 && a <= 128421 || a === 128424 || a >= 128433 && a <= 128434 || a === 128444 || a >= 128450 && a <= 128452 || a >= 128465 && a <= 128467 || a >= 128476 && a <= 128478 || a === 128481 || a === 128483 || a === 128488 || a === 128495 || a === 128499 || a >= 128506 && a <= 128580 || a >= 128584 && a <= 128586 || a >= 128640 && a <= 128674 || a >= 128676 && a <= 128691 || a >= 128695 && a <= 128703 || a >= 128705 && a <= 128709 || a === 128715 || a >= 128717 && a <= 128722 || a >= 128725 && a <= 128727 || a >= 128732 && a <= 128741 || a === 128745 || a >= 128747 && a <= 128748 || a === 128752 || a >= 128755 && a <= 128764 || a >= 128992 && a <= 129003 || a === 129008 || a >= 129293 && a <= 129294 || a >= 129296 && a <= 129303 || a >= 129312 && a <= 129317 || a >= 129319 && a <= 129327 || a === 129338 || a >= 129343 && a <= 129349 || a >= 129351 && a <= 129398 || a >= 129400 && a <= 129460 || a === 129463 || a === 129466 || a >= 129468 && a <= 129484 || a === 129488 || a >= 129502 && a <= 129535 || a >= 129648 && a <= 129660 || a >= 129664 && a <= 129672 || a >= 129680 && a <= 129725 || a >= 129727 && a <= 129730 || a >= 129742 && a <= 129755 || a >= 129760 && a <= 129768 || a >= 917536 && a <= 917631 || a >= 983040 && a <= 983041
        };
        a.isEmojiModifier = function(a) {
            return a > 127999 || a < 127995 ? !1 : a >= 127995 && a <= 127999
        };
        a.isEmojiModifierBase = function(a) {
            return a > 129784 || a < 9757 ? !1 : a === 9757 || a === 9977 || a >= 9994 && a <= 9997 || a === 127877 || a >= 127938 && a <= 127940 || a === 127943 || a >= 127946 && a <= 127948 || a >= 128066 && a <= 128067 || a >= 128070 && a <= 128080 || a >= 128102 && a <= 128120 || a === 128124 || a >= 128129 && a <= 128131 || a >= 128133 && a <= 128135 || a === 128143 || a === 128145 || a === 128170 || a >= 128372 && a <= 128373 || a === 128378 || a === 128400 || a >= 128405 && a <= 128406 || a >= 128581 && a <= 128583 || a >= 128587 && a <= 128591 || a === 128675 || a >= 128692 && a <= 128694 || a === 128704 || a === 128716 || a === 129292 || a === 129295 || a >= 129304 && a <= 129311 || a === 129318 || a >= 129328 && a <= 129337 || a >= 129340 && a <= 129342 || a === 129399 || a >= 129461 && a <= 129462 || a >= 129464 && a <= 129465 || a === 129467 || a >= 129485 && a <= 129487 || a >= 129489 && a <= 129501 || a >= 129731 && a <= 129733 || a >= 129776 && a <= 129784
        };
        a.isEmojiVariationSelector = function(a) {
            return a === 65039
        };
        a.isNonSpacingCombiningMark = function(a) {
            return a > 8419 || a < 8416 ? !1 : a === 8416 || a === 8419
        };
        a.isRegionalIndicator = function(a) {
            return a > 127487 || a < 127462 ? !1 : a >= 127462 && a <= 127487
        };
        a.isTagSpec = function(a) {
            return a > 917630 || a < 917536 ? !1 : a >= 917536 && a <= 917568 || a >= 917595 && a <= 917630
        };
        a.isTagTerm = function(a) {
            return a === 917631
        };
        a.isText = function(a) {
            return a > 8419 || a < 35 ? !1 : a === 35 || a === 42 || a >= 48 && a <= 57 || a === 8419
        };
        a.isTextVariationSelector = function(a) {
            return a === 65038
        };
        a.isDefaultTextPresentation = function(a) {
            return a > 917631 || a < 35 ? !1 : a === 35 || a === 42 || a >= 48 && a <= 57 || a === 169 || a === 174 || a === 8205 || a === 8252 || a === 8265 || a === 8419 || a === 8482 || a === 8505 || a >= 8596 && a <= 8597 || a >= 8617 && a <= 8618 || a === 9e3 || a === 9167 || a >= 9197 && a <= 9199 || a >= 9201 && a <= 9202 || a >= 9208 && a <= 9210 || a === 9410 || a === 9654 || a === 9664 || a >= 9730 && a <= 9732 || a === 9745 || a === 9752 || a === 9760 || a >= 9762 && a <= 9763 || a === 9766 || a === 9770 || a >= 9774 && a <= 9775 || a >= 9784 && a <= 9785 || a === 9792 || a === 9794 || a === 9823 || a === 9851 || a === 9854 || a === 9874 || a >= 9876 && a <= 9879 || a === 9881 || a >= 9883 && a <= 9884 || a === 9895 || a >= 9904 && a <= 9905 || a === 9928 || a === 9935 || a === 9937 || a === 9939 || a === 9961 || a >= 9968 && a <= 9969 || a === 9972 || a >= 9975 && a <= 9977 || a === 9997 || a === 9999 || a === 10002 || a === 10004 || a === 10013 || a === 10017 || a === 10052 || a === 10055 || a === 10083 || a === 12336 || a >= 127344 && a <= 127345 || a >= 127358 && a <= 127359 || a === 127777 || a >= 127780 && a <= 127788 || a === 127798 || a === 127869 || a >= 127894 && a <= 127895 || a >= 127897 && a <= 127899 || a >= 127902 && a <= 127903 || a >= 127947 && a <= 127950 || a >= 127956 && a <= 127967 || a === 127987 || a === 127989 || a === 127991 || a === 128063 || a === 128065 || a === 128253 || a >= 128329 && a <= 128330 || a >= 128367 && a <= 128368 || a >= 128371 && a <= 128377 || a === 128391 || a >= 128394 && a <= 128397 || a === 128400 || a === 128421 || a === 128424 || a >= 128433 && a <= 128434 || a === 128444 || a >= 128450 && a <= 128452 || a >= 128465 && a <= 128467 || a >= 128476 && a <= 128478 || a === 128481 || a === 128483 || a === 128488 || a === 128495 || a === 128499 || a === 128506 || a === 128715 || a >= 128717 && a <= 128719 || a >= 128736 && a <= 128741 || a === 128745 || a === 128752 || a === 128755 || a >= 917536 && a <= 917631
        };
        a.isSymbol = function(a) {
            return a > 8482 || a < 169 ? !1 : a === 169 || a === 174 || a === 8482
        };
        a.isZWJ = function(a) {
            return a === 8205
        };
        return a
    }();
    e.exports = a
}), null);
__d("UnicodeUtils", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = 55296,
        j = 56319,
        k = 56320,
        l = 57343,
        m = /[\uD800-\uDFFF]/;

    function n(a) {
        return i <= a && a <= l
    }

    function a(a, b) {
        0 <= b && b < a.length || h(0, 1346, b, a.length);
        if (b + 1 === a.length) return !1;
        var c = a.charCodeAt(b);
        a = a.charCodeAt(b + 1);
        return i <= c && c <= j && k <= a && a <= l
    }

    function o(a) {
        return m.test(a)
    }

    function p(a, b) {
        a = n(a.charCodeAt(b));
        return a ? 2 : 1
    }

    function b(a) {
        if (!o(a)) return a.length;
        var b = 0;
        for (var c = 0; c < a.length; c += p(a, c)) b++;
        return b
    }

    function c(a, b) {
        return r(a, b, b + 1)
    }

    function q(a, b, c) {
        var d = b || 0;
        c = c === void 0 ? Infinity : c || 0;
        if (!o(a)) return a.substr(d, c);
        var e = a.length;
        if (e <= 0 || d > e || c <= 0) return "";
        var f = 0;
        if (d > 0) {
            for (; d > 0 && f < e; d--) f += p(a, f);
            if (f >= e) return ""
        } else if (b < 0) {
            for (f = e; d < 0 && 0 < f; d++) f -= p(a, f - 1);
            f < 0 && (f = 0)
        }
        b = e;
        if (c < e)
            for (b = f; c > 0 && b < e; c--) b += p(a, b);
        return a.substring(f, b)
    }

    function r(a, b, c) {
        b = b || 0;
        c = c === void 0 ? Infinity : c || 0;
        b < 0 && (b = 0);
        c < 0 && (c = 0);
        var d = Math.abs(c - b);
        b = b < c ? b : c;
        return q(a, b, d)
    }

    function d(a) {
        var b = [];
        for (var c = 0; c < a.length; c += p(a, c)) b.push(a.codePointAt(c));
        return b
    }
    g.isCodeUnitInSurrogateRange = n;
    g.isSurrogatePair = a;
    g.hasSurrogateUnit = o;
    g.getUTF16Length = p;
    g.strlen = b;
    g.charAt = c;
    g.substr = q;
    g.substring = r;
    g.getCodePoints = d
}), 98); /*FB_PKG_DELIM*/
__d("BaseFocusRing.react", ["FocusWithinHandler.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            focused: {
                boxShadow: "x18bame2",
                outline: "x1a2a7pz xvetz19",
                $$css: !0
            },
            focusedInset: {
                boxShadow: "xpud6h4",
                $$css: !0
            },
            unfocused: {
                outline: "x1a2a7pz",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.children,
            d = a.focusRingPosition,
            e = d === void 0 ? "default" : d;
        d = a.mode;
        var f = d === void 0 ? "focus-visible" : d;
        d = a.suppressFocusRing;
        var g = d === void 0 ? !1 : d;
        d = a.testOnly;
        return i.jsx(c("FocusWithinHandler.react"), {
            testOnly: d,
            children: function(a, c) {
                a = !g && a && (c || f === "focus");
                return b(a ? e === "inset" ? j.focusedInset : j.focused : j.unfocused)
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseInput.react", ["CometContainerPressableContext", "Locale", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useContext,
        l = b.useMemo,
        m = {
            root: {
                WebkitTapHighlightColor: "x1i10hfl",
                boxSizing: "x9f619",
                touchAction: "xggy1nq",
                ":disabled_cursor": "x1s07b3s",
                $$css: !0
            },
            zIndex: {
                zIndex: "x1vjfegm",
                $$css: !0
            }
        },
        n = d("Locale").isRTL();
    e = j.forwardRef(a);

    function a(a, b) {
        var d = a.xstyle,
            e = a.onChange,
            f = a.onClick,
            g = a.onValueChange,
            i = a.testid,
            o = a.type,
            p = o === void 0 ? "text" : o;
        o = babelHelpers.objectWithoutPropertiesLoose(a, ["xstyle", "onChange", "onClick", "onValueChange", "testid", "type"]);
        a = l(function() {
            switch (p) {
                case "switch":
                    return "checkbox";
                default:
                    return p
            }
        }, [p]);
        var q = a === "checkbox" || a === "radio",
            r = a === "textarea",
            s = k(c("CometContainerPressableContext")) != null;
        o = babelHelpers["extends"]({
            dir: n ? "rtl" : "ltr"
        }, o, c("testID")(i), {
            className: (h || (h = c("stylex")))(m.root, d, s && m.zIndex),
            onChange: function(a) {
                q || (g == null ? void 0 : g(a.target.value, a)), e == null ? void 0 : e(a)
            },
            onClick: function(a) {
                q && (g == null ? void 0 : g(a.target.checked, a)), f == null ? void 0 : f(a)
            }
        });
        return r ? j.jsx("textarea", babelHelpers["extends"]({}, o, {
            ref: b
        })) : j.jsx("input", babelHelpers["extends"]({}, o, {
            ref: b,
            type: a
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = j.memo(e);
    g["default"] = b
}), 98);
__d("BaseMiddot.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        return i.jsxs("span", babelHelpers["extends"]({}, a, {
            children: [i.jsx("span", {
                className: "xzpqnlu xjm9jq1 x6ikm8r x10wlt62 x10l6tqk x1i1rx1s",
                children: "\xa0"
            }), i.jsx("span", {
                "aria-hidden": "true",
                children: " \xb7 "
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseNonBreakingSpace.react", ["react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            marginInlineEnd: function(a) {
                return [{
                    marginEnd: a + "ch" == null ? null : "x9wsmhn",
                    $$css: !0
                }, {
                    "--marginInlineEnd": function(a) {
                        return typeof a === "number" ? a + "px" : a != null ? a : void 0
                    }(a + "ch")
                }]
            }
        };

    function a(a) {
        a = a.size;
        if (a != null) return i.jsx(d("react-strict-dom").html.span, {
            style: j.marginInlineEnd(a),
            children: "\ufeff"
        });
        else return i.jsx(i.Fragment, {
            children: "\xa0"
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometAccessibilityAnnouncement.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            offscreenAccessibilityElement: {
                clip: "xzpqnlu",
                clipPath: "x1hyvwdk",
                height: "xjm9jq1",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x10l6tqk",
                width: "x1i1rx1s",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.assertive;
        b = b === void 0 ? !1 : b;
        var d = a.children;
        d = d === void 0 ? null : d;
        var e = a.isVisible;
        e = e === void 0 ? !1 : e;
        a = a.role;
        a = a === void 0 ? "alert" : a;
        return j.jsx("div", {
            "aria-atomic": !0,
            "aria-live": b ? "assertive" : "polite",
            className: (h || (h = c("stylex")))(e === !1 && k.offscreenAccessibilityElement),
            role: a,
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometBackupPlaceholder.react", ["react", "useCometPlaceholderImpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");

    function a(a) {
        return c("useCometPlaceholderImpl")(babelHelpers["extends"]({}, a, {
            unstable_avoidThisFallback: !0
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometCompositeStructureContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext({
        horizontal: !1,
        vertical: !1
    });
    g["default"] = b
}), 98);
__d("CometRoutePassthroughPropsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouterParentRouteContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometRouterRenderTypeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("SubscriptionsHandler", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function i(a) {
        return a.remove || a.reset || a.unsubscribe || a.cancel || a.dispose
    }

    function j(a) {
        i(a).call(a)
    }
    a = function() {
        function a() {
            this.$1 = []
        }
        var b = a.prototype;
        b.addSubscriptions = function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            b.every(i) || h(0, 3659);
            this.$1 != null ? this.$1 = this.$1.concat(b) : b.forEach(j)
        };
        b.engage = function() {
            this.$1 == null && (this.$1 = [])
        };
        b.release = function() {
            this.$1 != null && (this.$1.forEach(j), this.$1 = null)
        };
        b.releaseOne = function(a) {
            var b = this.$1;
            if (b == null) return;
            var c = b.indexOf(a);
            c !== -1 && (j(a), b.splice(c, 1), b.length === 0 && (this.$1 = null))
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("TetraCircleButton.react", ["FDSCircleButton.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        return i.jsx(c("FDSCircleButton.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("asset", [], (function(a, b, c, d, e, f) {
    function a() {
        for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
        throw new Error("asset(" + b.join(",") + "): Unexpected asset reference")
    }
    e.exports = a
}), null);
__d("filterObject", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = Object.prototype.hasOwnProperty;

    function a(a, b, c) {
        if (!a) return null;
        var d = {};
        for (var e in a) g.call(a, e) && b.call(c, a[e], e, a) && (d[e] = a[e]);
        return d
    }
    f["default"] = a
}), 66);
__d("getTopMostRoute", ["getTopMostRouteInfo"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("getTopMostRouteInfo")(a).route
    }
    g["default"] = a
}), 98);
__d("useLayerKeyCommands", ["CometLayerKeyCommandWidget"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("CometLayerKeyCommandWidget").useKeyCommands
}), 98);
__d("useRoutePassthroughProps", ["CometRoutePassthroughPropsContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useContext;

    function a() {
        return i(c("CometRoutePassthroughPropsContext"))
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("MAWInitError", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c) {
            var d;
            d = a.call(this, b) || this;
            d.error = void 0;
            d.name = "MAWInitError";
            d.message = b;
            d.error = c;
            return d
        }
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    f.MAWInitError = a
}), 66);
__d("mergeHelpers", ["invariant", "FbtResultBase"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = 36,
        j = function(a) {
            return typeof a !== "object" || a instanceof Date || a === null || a instanceof c("FbtResultBase")
        },
        k = {
            MAX_MERGE_DEPTH: i,
            isTerminal: j,
            normalizeMergeArg: function(a) {
                return a == null ? {} : a
            },
            checkMergeArrayArgs: function(a, b) {
                Array.isArray(a) && Array.isArray(b) || h(0, 3714, a, b)
            },
            checkMergeObjectArgs: function(a, b) {
                k.checkMergeObjectArg(a), k.checkMergeObjectArg(b)
            },
            checkMergeObjectArg: function(a) {
                !j(a) && !Array.isArray(a) || h(0, 3715, a)
            },
            checkMergeIntoObjectArg: function(a) {
                (!j(a) || typeof a === "function") && !Array.isArray(a) || h(0, 3716, a)
            },
            checkMergeLevel: function(a) {
                a < i || h(0, 3717)
            },
            checkArrayStrategy: function(a) {
                a == null || a in k.ArrayStrategies || h(0, 3718)
            },
            ArrayStrategies: {
                Clobber: "Clobber",
                Concat: "Concat",
                IndexByIndex: "IndexByIndex"
            }
        };
    a = k;
    g["default"] = a
}), 98);
__d("mergeDeepInto", ["invariant", "mergeHelpers"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = (c = b("mergeHelpers")).ArrayStrategies,
        i = c.checkArrayStrategy,
        j = c.checkMergeArrayArgs,
        k = c.checkMergeLevel,
        l = c.checkMergeObjectArgs,
        m = c.isTerminal,
        n = c.normalizeMergeArg,
        o = function(a, b, c, d) {
            l(a, b);
            k(d);
            var e = b ? Object.keys(b) : [];
            for (var f = 0; f < e.length; f++) {
                var g = e[f];
                q(a, b, g, c, d)
            }
        },
        p = function(a, b, c, d) {
            j(a, b);
            k(d);
            if (c === h.Concat) a.push.apply(a, b);
            else {
                var e = Math.max(a.length, b.length);
                for (var f = 0; f < e; f++) q(a, b, f, c, d)
            }
        },
        q = function(a, b, c, d, e) {
            var f = b[c];
            b = Object.prototype.hasOwnProperty.call(b, c);
            var i = b && m(f),
                j = b && Array.isArray(f),
                k = b && !j && !j,
                l = a[c],
                n = Object.prototype.hasOwnProperty.call(a, c),
                q = n && m(l),
                r = n && Array.isArray(l),
                s = n && !r && !r;
            q ? i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k ? (a[c] = {}, o(a[c], f, d, e + 1)) : b || (a[c] = l) : r ? i ? a[c] = f : j ? (d && h[d] || g(0, 5117), d === h.Clobber && (l.length = 0), p(l, f, d, e + 1)) : k && (a[c] = {}, o(a[c], f, d, e + 1)) : s ? i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k && o(l, f, d, e + 1) : n || (i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k && (a[c] = {}, o(a[c], f, d, e + 1)))
        };

    function a(a, b, c) {
        b = n(b);
        i(c);
        o(a, b, c, 0)
    }
    f["default"] = a
}), 66);
__d("WebAsyncStorage", ["Deferred", "Promise", "err", "mergeDeepInto", "mergeHelpers"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = typeof window !== "undefined" ? window : self;
    var i = a.indexedDB,
        j = 1,
        k = "data",
        l = !1,
        m;
    d = Date.now();
    var n = new(c("Deferred"))(),
        o = 3;

    function p() {
        var a = i.open("AsyncStorage", j);
        a.onerror = function(b) {
            b = (b = a.error) != null ? b : new Error("Failed to open AsyncStorage IndexedDB instance.");
            if (b.name === "UnknownError" && o > 0) {
                o--;
                return p()
            }
            n.reject(b)
        };
        a.onsuccess = function(a) {
            l && !1, m = a.target.result, n.resolve({
                db: m
            }), m.onerror = function(a) {
                a = new Error("AsyncStorage error: " + a.target.error.message);
                n.reject(a)
            }
        };
        a.onupgradeneeded = function(a) {
            a = a.currentTarget.result;
            if (a.objectStoreNames && a.objectStoreNames.contains(k)) return;
            a.createObjectStore(k, {
                keyPath: "key"
            })
        }
    }
    i && p();

    function q(a, b) {
        if (m) try {
            a()
        } catch (a) {
            b && b(a)
        } else n.getPromise().then(function() {
            l && !1, q(a, b)
        }, function(a) {
            b && b(a)
        })
    }
    e = {
        setItem: function(a, b, c) {
            this.multiSet([
                [a, b]
            ], function(a) {
                c(a && a[0] || null)
            })
        },
        getItem: function(a, b) {
            this.multiGet([a], function(a, c) {
                c = c !== void 0 && c[0] !== void 0 && c[0][1] !== void 0 ? c[0][1] : null;
                b(a && a[0] || null, c)
            })
        },
        removeItem: function(a, b) {
            this.multiRemove([a], function(a) {
                b(a && a[0] || null)
            })
        },
        multiGet: function(a, b) {
            var c = [];
            this._multiOp(a, "readonly", function(a) {
                return b(a, c)
            }, function(a) {
                return a
            }, function(a, b, d) {
                b && a === b.key ? (l && !1, c.push([a, b.value.value])) : c.push([a, null])
            })
        },
        multiSet: function(a, b) {
            if (this._persistentWritesDisabled) {
                b(new Array(a.length).fill("writes disabled"));
                return
            }
            this._multiOp(a, "readwrite", b, function(a) {
                return a[0]
            }, function(a, b, c) {
                if (b && a[0] === b.key) {
                    var d = b.value;
                    d.value = a[1];
                    l && !1;
                    b.update(d)
                } else c.push(a)
            })
        },
        multiMerge: function(a, b) {
            this._multiOp(a, "readwrite", b, function(a) {
                return a[0]
            }, function(a, b, d) {
                if (b && a[0] === b.key) {
                    var e = b.value,
                        f = JSON.parse(e.value);
                    c("mergeDeepInto")(f, JSON.parse(a[1]), c("mergeHelpers").ArrayStrategies.Clobber);
                    l && !1;
                    e.value = JSON.stringify(f);
                    b.update(e)
                } else l && !1, d.push(a)
            })
        },
        multiRemove: function(a, b) {
            this._multiOp(a, "readwrite", b, function(a) {
                return a
            }, function(a, b, c) {
                b && a === b.key && (l && !1, b["delete"]())
            })
        },
        getAllKeys: function(a) {
            q(function() {
                var b = m.transaction([k], "readonly");
                b = b.objectStore(k).openCursor();
                var c = [];
                b.onsuccess = function(b) {
                    b = b.target.result;
                    if (!b) {
                        a(null, c);
                        return
                    }
                    c.push(b.key);
                    b["continue"]()
                }
            }, function(b) {
                return a(null, [])
            })
        },
        clear: function(a) {
            q(function() {
                var b = m.transaction([k], "readwrite");
                b = b.objectStore(k).openCursor();
                b.onsuccess = function(b) {
                    b = b.target.result;
                    if (!b) {
                        a(null);
                        return
                    }
                    b["delete"]();
                    b["continue"]()
                }
            }, function(b) {
                return a(null)
            })
        },
        _multiOp: function(a, b, c, d, e) {
            q(function() {
                var f = !1,
                    g = a.slice().sort(function(a, b) {
                        a = d(a);
                        b = d(b);
                        if (a === b) {
                            var e = new Error("AsyncStorage._multiOp cannot process duplicate keys.");
                            c && c([e]);
                            f = !0;
                            return 0
                        }
                        return a < b ? -1 : 1
                    });
                if (f) return;
                var h = m.transaction([k], b),
                    i = h.objectStore(k).openCursor(),
                    j = [],
                    n = 0;
                i.onsuccess = function(a) {
                    a = a.target.result;
                    if (!a) {
                        while (n < g.length) e(g[n], a, j), n++;
                        o();
                        return
                    }
                    var b = a.key;
                    l && !1;
                    while (d(g[n]) <= b) {
                        l && !1;
                        e(g[n], a, j);
                        n++;
                        if (n === g.length) {
                            o();
                            return
                        }
                    }
                    b = d(g[n]);
                    a["continue"](b)
                };

                function o() {
                    var a = h.objectStore(k);
                    j.forEach(function(b) {
                        l && !1, a.add({
                            key: b[0],
                            value: b[1]
                        })
                    })
                }
                h.oncomplete = function() {
                    c && c(null)
                };
                h.onerror = function(a) {
                    a = new Error("IndexedDB error: " + a.target.error.message);
                    c && c([a])
                };
                l && !1
            }, function(a) {
                c && c([a])
            })
        },
        _persistentWritesDisabled: !1,
        disablePersistentWrites: function() {
            this._persistentWritesDisabled = !0
        },
        isOpenPromiseSettled: function() {
            return n.isSettled()
        },
        isOperational: function() {
            return i == null ? (h || (h = b("Promise"))).resolve({
                success: !1,
                error: c("err")("IDB interface not available")
            }) : n.getPromise().then(function() {
                return {
                    success: !0
                }
            })["catch"](function(a) {
                return {
                    success: !1,
                    error: a
                }
            })
        }
    };
    f = e;
    g["default"] = f
}), 98); /*FB_PKG_DELIM*/
__d("CometContextualMessage.react", ["fbt", "ix", "CometRow.react", "CometRowItem.react", "FDSIcon.react", "FDSTextPairing.react", "FbtResultBase", "fbicon", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k, l = k || d("react"),
        m = {
            root: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "x1iorvi4",
                paddingEnd: "x150jy0e",
                paddingStart: "x1e558r4",
                paddingBottom: "x1l90r2v",
                $$css: !0
            }
        },
        n = {
            highlight: {
                backgroundColor: "xwnonoy",
                $$css: !0
            },
            "highlight-bg": {
                backgroundColor: "xfmpgtx",
                $$css: !0
            },
            primary: {
                backgroundColor: "x1jx94hy",
                $$css: !0
            },
            secondary: {
                backgroundColor: "xlhe6ec",
                $$css: !0
            }
        };
    b = l.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var e = a.addOnPrimary,
            f = a.addOnSecondary,
            g = a.body,
            k = a.headline,
            o = a.headlineLineLimit,
            p = a.icon,
            q = a.level;
        q = q === void 0 ? 3 : q;
        var r = a.meta,
            s = a.testid;
        s = a.type;
        s = s === void 0 ? "primary" : s;
        var t = a.onClose != null ? a.onClose : null;
        a = a.headlineAriaLabel != null ? a.headlineAriaLabel : typeof k === "string" || k instanceof c("FbtResultBase") ? k : null;
        return l.jsxs("div", {
            className: (j || (j = c("stylex")))(m.root, n[s]),
            "data-testid": void 0,
            ref: b,
            children: [l.jsxs(c("CometRow.react"), {
                verticalAlign: "center",
                children: [p != null ? l.jsx(c("CometRowItem.react"), {
                    verticalAlign: "top",
                    children: l.jsx("div", {
                        className: "x1rdy4ex",
                        children: p
                    })
                }) : null, l.jsx(c("CometRowItem.react"), {
                    expanding: !0,
                    children: l.jsx(c("FDSTextPairing.react"), {
                        body: g,
                        bodyColor: s === "highlight" ? "white" : "secondary",
                        headline: k,
                        headlineColor: s === "highlight" ? "white" : "primary",
                        headlineLineLimit: (b = o) != null ? b : 2,
                        isSemanticHeading: !0,
                        level: q
                    })
                }), t != null ? l.jsx(c("CometRowItem.react"), {
                    verticalAlign: "top",
                    children: l.jsx("div", {
                        className: "xcud41i x9otpla",
                        children: l.jsx(c("FDSIcon.react"), {
                            "aria-label": a != null ? h._("__JHASH__jdA38No1bHZ__JHASH__", [h._param("card name", a)]) : h._("__JHASH__PfdWOKkgwGk__JHASH__"),
                            color: s === "highlight" ? "white" : "secondary",
                            icon: d("fbicon")._(i("478232"), 16),
                            onPress: t,
                            size: 16,
                            testid: void 0
                        })
                    })
                }) : null]
            }), e, f, r != null && l.jsx(c("CometRow.react"), {
                paddingTop: 12,
                children: l.jsx(c("CometRowItem.react"), {
                    children: l.jsx(c("FDSTextPairing.react"), {
                        level: q,
                        meta: r
                    })
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 226);
__d("MWChatUnsendNUXReceiverBanner.react", ["fbt", "ix", "FDSButton.react", "FDSSkittleIcon.react", "JSResourceForInteraction", "MDSRow.react", "MDSRowItem.react", "MWXText.react", "fbicon", "react", "useMWXLazyDialog"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = j || d("react"),
        l = c("JSResourceForInteraction")("MWChatUnsendNUXInterstitialDialog.react").__setRef("MWChatUnsendNUXReceiverBanner.react"),
        m = {
            button: {
                flexBasis: "x1r8uery",
                flexGrow: "x1iyjqo2",
                $$css: !0
            },
            imageRow: {
                paddingTop: "x1nn3v0j",
                $$css: !0
            }
        };

    function a(a) {
        var b, e = a.onDismiss,
            f = a.onView;
        a = h._("__JHASH__7PesNdiLm6N__JHASH__");
        var g = h._("__JHASH__jjSY-Fh1rGw__JHASH__"),
            j = {},
            n = c("useMWXLazyDialog")(l),
            o = n[0],
            p = function() {
                return o(j, function() {})
            };
        return k.jsxs("div", {
            className: "xcrg951 x7m3og9 x10l6tqk xh8yej3 x1vjfegm",
            children: [k.jsxs(n = c("MDSRow.react"), {
                paddingHorizontal: 12,
                paddingTop: 12,
                children: [k.jsx(b = c("MDSRowItem.react"), {
                    xstyle: m.imageRow,
                    children: k.jsx(c("FDSSkittleIcon.react"), {
                        color: "gray",
                        icon: d("fbicon")._(i("685851"), 16),
                        size: 36
                    })
                }), k.jsxs(b, {
                    expanding: !0,
                    children: [k.jsx(n, {
                        paddingHorizontal: 0,
                        paddingTop: 0,
                        children: k.jsx(b, {
                            children: k.jsx(c("MWXText.react"), {
                                color: "primary",
                                type: "headline4",
                                children: a
                            })
                        })
                    }), k.jsx(n, {
                        paddingHorizontal: 0,
                        paddingTop: 8,
                        children: k.jsx(b, {
                            children: k.jsx(c("MWXText.react"), {
                                color: "secondary",
                                type: "body4",
                                children: g
                            })
                        })
                    })]
                })]
            }), k.jsxs(n, {
                paddingHorizontal: 12,
                paddingTop: 8,
                paddingVertical: 12,
                wrap: "forward",
                children: [k.jsx(b, {
                    xstyle: m.button,
                    children: k.jsx(c("FDSButton.react"), {
                        label: h._("__JHASH__W_KwwnBzw9K__JHASH__"),
                        onPress: function() {
                            p();
                            return f()
                        },
                        type: "secondary"
                    })
                }), k.jsx(b, {
                    xstyle: m.button,
                    children: k.jsx(c("FDSButton.react"), {
                        label: h._("__JHASH__CqytfJoYvSJ__JHASH__"),
                        onPress: e,
                        type: "secondary"
                    })
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MWChatUnsendNUXReceiver.react", ["I64", "Int64Hooks", "LSMessagingThreadTypeUtil", "MWChatUnsendNUXReceiverBanner.react", "MWLSThread", "MWPActor.react", "MWThreadKey.react", "ReQL", "isMessageUnsentInLastTenSeconds", "react", "useMessengerUnsendNUX", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = j || (j = d("react"));
    b = j;
    var l = b.useCallback,
        m = b.useRef,
        n = b.useState;

    function a() {
        var a = d("MWPActor.react").useActor(),
            b = d("MWThreadKey.react").useMWThreadKeyMemoizedExn(),
            e = d("MWLSThread").useThread(b, function(a) {
                return a.threadType
            });
        e = e != null && d("LSMessagingThreadTypeUtil").isDiscoverableChannel(e);
        var f = (h || (h = c("useReStore")))(),
            g = n(!1),
            j = g[0],
            o = g[1],
            p = m(!1),
            q = m(!1),
            r = m();
        g = c("useMessengerUnsendNUX")(8568);
        var s = g[0],
            t = g[1],
            u = g[2],
            v = l(function() {
                var a = r.current;
                if (a != null) {
                    a();
                    r.current = void 0;
                    return
                }
            }, []);
        g = l(function() {
            q.current = !0;
            t();
            v();
            return o(!1)
        }, [t, v]);
        var w = l(function(a) {
            var b = !j && !p.current;
            if (b && c("isMessageUnsentInLastTenSeconds")(a)) {
                p.current = !0;
                return s(function(a) {
                    p.current = !1;
                    if (a) return o(!0);
                    else {
                        v();
                        q.current = !0;
                        return
                    }
                })
            }
        }, [j, s, v]);
        d("Int64Hooks").useEffectInt64(function() {
            if (q.current) return;
            r.current = d("ReQL").fromTableAscending(f.tables.messages).getKeyRange(b).filter(function(b) {
                if (b.isUnsent) return !(i || (i = d("I64"))).equal(b.senderId, a);
                else return !1
            }).subscribe(function(a, b) {
                b.operation !== "delete" && w(b.value)
            });
            return function() {
                v();
                if (j && !q.current) return u()
            }
        }, [f, a, j, u, w, b, v]);
        if (j && !e) return k.jsx(c("MWChatUnsendNUXReceiverBanner.react"), {
            onDismiss: g,
            onView: g
        });
        else return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("regeneratorRuntime", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = Object.prototype.hasOwnProperty,
        i = typeof Symbol === "function" && (typeof Symbol === "function" ? Symbol.iterator : "@@iterator") || "@@iterator",
        j = e.exports;

    function k(a, b, c, d) {
        b = Object.create((b || r).prototype);
        d = new A(d || []);
        b._invoke = x(a, c, d);
        return b
    }
    j.wrap = k;

    function l(a, b, c) {
        try {
            return {
                type: "normal",
                arg: a.call(b, c)
            }
        } catch (a) {
            return {
                type: "throw",
                arg: a
            }
        }
    }
    var m = "suspendedStart",
        n = "suspendedYield",
        o = "executing",
        p = "completed",
        q = {};

    function r() {}

    function s() {}

    function t() {}
    var u = t.prototype = r.prototype;
    s.prototype = u.constructor = t;
    t.constructor = s;
    s.displayName = "GeneratorFunction";

    function a(a) {
        ["next", "throw", "return"].forEach(function(b) {
            a[b] = function(a) {
                return this._invoke(b, a)
            }
        })
    }
    j.isGeneratorFunction = function(a) {
        a = typeof a === "function" && a.constructor;
        return a ? a === s || (a.displayName || a.name) === "GeneratorFunction" : !1
    };
    j.mark = function(a) {
        Object.setPrototypeOf ? Object.setPrototypeOf(a, t) : Object.assign(a, t);
        a.prototype = Object.create(u);
        return a
    };
    j.awrap = function(a) {
        return new v(a)
    };

    function v(a) {
        this.arg = a
    }

    function w(a) {
        function c(c, f) {
            var h = a[c](f);
            c = h.value;
            return c instanceof v ? (g || (g = b("Promise"))).resolve(c.arg).then(d, e) : (g || (g = b("Promise"))).resolve(c).then(function(a) {
                h.value = a;
                return h
            })
        }
        typeof process === "object" && process.domain && (c = process.domain.bind(c));
        var d = c.bind(a, "next"),
            e = c.bind(a, "throw");
        c.bind(a, "return");
        var f;

        function h(a, d) {
            var e = f ? f.then(function() {
                return c(a, d)
            }) : new(g || (g = b("Promise")))(function(b) {
                b(c(a, d))
            });
            f = e["catch"](function(a) {});
            return e
        }
        this._invoke = h
    }
    a(w.prototype);
    j.async = function(a, b, c, d) {
        var e = new w(k(a, b, c, d));
        return j.isGeneratorFunction(b) ? e : e.next().then(function(a) {
            return a.done ? a.value : e.next()
        })
    };

    function x(a, b, c) {
        var d = m;
        return function(e, f) {
            if (d === o) throw new Error("Generator is already running");
            if (d === p) {
                if (e === "throw") throw f;
                return C()
            }
            while (!0) {
                var g = c.delegate;
                if (g) {
                    if (e === "return" || e === "throw" && g.iterator[e] === void 0) {
                        c.delegate = null;
                        var h = g.iterator["return"];
                        if (h) {
                            h = l(h, g.iterator, f);
                            if (h.type === "throw") {
                                e = "throw";
                                f = h.arg;
                                continue
                            }
                        }
                        if (e === "return") continue
                    }
                    h = l(g.iterator[e], g.iterator, f);
                    if (h.type === "throw") {
                        c.delegate = null;
                        e = "throw";
                        f = h.arg;
                        continue
                    }
                    e = "next";
                    f = void 0;
                    var i = h.arg;
                    if (i.done) c[g.resultName] = i.value, c.next = g.nextLoc;
                    else {
                        d = n;
                        return i
                    }
                    c.delegate = null
                }
                if (e === "next") d === n ? c.sent = f : c.sent = void 0;
                else if (e === "throw") {
                    if (d === m) {
                        d = p;
                        throw f
                    }
                    c.dispatchException(f) && (e = "next", f = void 0)
                } else e === "return" && c.abrupt("return", f);
                d = o;
                h = l(a, b, c);
                if (h.type === "normal") {
                    d = c.done ? p : n;
                    var i = {
                        value: h.arg,
                        done: c.done
                    };
                    if (h.arg === q) c.delegate && e === "next" && (f = void 0);
                    else return i
                } else h.type === "throw" && (d = p, e = "throw", f = h.arg)
            }
        }
    }
    a(u);
    u[i] = function() {
        return this
    };
    u.toString = function() {
        return "[object Generator]"
    };

    function y(a) {
        var b = {
            tryLoc: a[0]
        };
        1 in a && (b.catchLoc = a[1]);
        2 in a && (b.finallyLoc = a[2], b.afterLoc = a[3]);
        this.tryEntries.push(b)
    }

    function z(a) {
        var b = a.completion || {};
        b.type = "normal";
        delete b.arg;
        a.completion = b
    }

    function A(a) {
        this.tryEntries = [{
            tryLoc: "root"
        }], a.forEach(y, this), this.reset(!0)
    }
    j.keys = function(a) {
        var b = [];
        for (var c in a) b.push(c);
        b.reverse();
        return function c() {
            while (b.length) {
                var d = b.pop();
                if (d in a) {
                    c.value = d;
                    c.done = !1;
                    return c
                }
            }
            c.done = !0;
            return c
        }
    };

    function B(a) {
        if (a) {
            var b = a[i];
            if (b) return b.call(a);
            if (typeof a.next === "function") return a;
            if (!isNaN(a.length)) {
                var c = -1;
                b = function b() {
                    while (++c < a.length)
                        if (h.call(a, c)) {
                            b.value = a[c];
                            b.done = !1;
                            return b
                        }
                    b.value = void 0;
                    b.done = !0;
                    return b
                };
                return b.next = b
            }
        }
        return {
            next: C
        }
    }
    j.values = B;

    function C() {
        return {
            value: void 0,
            done: !0
        }
    }
    A.prototype = {
        constructor: A,
        reset: function(a) {
            this.prev = 0;
            this.next = 0;
            this.sent = void 0;
            this.done = !1;
            this.delegate = null;
            this.tryEntries.forEach(z);
            if (!a)
                for (a in this) a.charAt(0) === "t" && h.call(this, a) && !isNaN(+a.slice(1)) && (this[a] = void 0)
        },
        stop: function() {
            this.done = !0;
            var a = this.tryEntries[0];
            a = a.completion;
            if (a.type === "throw") throw a.arg;
            return this.rval
        },
        dispatchException: function(a) {
            if (this.done) throw a;
            var b = this;

            function c(c, d) {
                f.type = "throw";
                f.arg = a;
                b.next = c;
                return !!d
            }
            for (var d = this.tryEntries.length - 1; d >= 0; --d) {
                var e = this.tryEntries[d],
                    f = e.completion;
                if (e.tryLoc === "root") return c("end");
                if (e.tryLoc <= this.prev) {
                    var g = h.call(e, "catchLoc"),
                        i = h.call(e, "finallyLoc");
                    if (g && i) {
                        if (this.prev < e.catchLoc) return c(e.catchLoc, !0);
                        else if (this.prev < e.finallyLoc) return c(e.finallyLoc)
                    } else if (g) {
                        if (this.prev < e.catchLoc) return c(e.catchLoc, !0)
                    } else if (i) {
                        if (this.prev < e.finallyLoc) return c(e.finallyLoc)
                    } else throw new Error("try statement without catch or finally")
                }
            }
        },
        abrupt: function(a, b) {
            for (var c = this.tryEntries.length - 1; c >= 0; --c) {
                var d = this.tryEntries[c];
                if (d.tryLoc <= this.prev && h.call(d, "finallyLoc") && this.prev < d.finallyLoc) {
                    var e = d;
                    break
                }
            }
            e && (a === "break" || a === "continue") && e.tryLoc <= b && b <= e.finallyLoc && (e = null);
            d = e ? e.completion : {};
            d.type = a;
            d.arg = b;
            e ? this.next = e.finallyLoc : this.complete(d);
            return q
        },
        complete: function(a, b) {
            if (a.type === "throw") throw a.arg;
            a.type === "break" || a.type === "continue" ? this.next = a.arg : a.type === "return" ? (this.rval = a.arg, this.next = "end") : a.type === "normal" && b && (this.next = b)
        },
        finish: function(a) {
            for (var b = this.tryEntries.length - 1; b >= 0; --b) {
                var c = this.tryEntries[b];
                if (c.finallyLoc === a) {
                    this.complete(c.completion, c.afterLoc);
                    z(c);
                    return q
                }
            }
        },
        "catch": function(a) {
            for (var b = this.tryEntries.length - 1; b >= 0; --b) {
                var c = this.tryEntries[b];
                if (c.tryLoc === a) {
                    var d = c.completion;
                    if (d.type === "throw") {
                        var e = d.arg;
                        z(c)
                    }
                    return e
                }
            }
            throw new Error("illegal catch attempt")
        },
        delegateYield: function(a, b, c) {
            this.delegate = {
                iterator: B(a),
                resultName: b,
                nextLoc: c
            };
            return q
        }
    }
}), null);
__d("asyncToGeneratorRuntime", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function h(a, c, d, e, f, h, i) {
        try {
            var j = a[h](i),
                k = j.value
        } catch (a) {
            d(a);
            return
        }
        j.done ? c(k) : (g || (g = b("Promise"))).resolve(k).then(e, f)
    }

    function a(a) {
        return function() {
            var c = this,
                d = arguments;
            return new(g || (g = b("Promise")))(function(b, e) {
                var f = a.apply(c, d);

                function g(a) {
                    h(f, b, e, g, i, "next", a)
                }

                function i(a) {
                    h(f, b, e, g, i, "throw", a)
                }
                g(void 0)
            })
        }
    }
    f.asyncToGenerator = a
}), 66); /*FB_PKG_DELIM*/
__d("XFBBotFeedbackKind.facebook", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum").Mirrored(["BOT_FEEDBACK_NEGATIVE_ACCURATE", "BOT_FEEDBACK_NEGATIVE_CLARITY", "BOT_FEEDBACK_NEGATIVE_GENERIC", "BOT_FEEDBACK_NEGATIVE_HELPFUL", "BOT_FEEDBACK_NEGATIVE_INTERESTING", "BOT_FEEDBACK_NEGATIVE_NOT_RELEVANT_TO_TEXT", "BOT_FEEDBACK_NEGATIVE_NOT_VISUALLY_APPEALING", "BOT_FEEDBACK_NEGATIVE_OTHER", "BOT_FEEDBACK_NEGATIVE_PERSONALIZED", "BOT_FEEDBACK_NEGATIVE_REFUSED", "BOT_FEEDBACK_NEGATIVE_SAFE", "BOT_FEEDBACK_POSITIVE"]);
    c = a;
    f["default"] = c
}), 66);
__d("useUGCAgentsSubmitFeedbackMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6987348644727826"
}), null);
__d("useUGCAgentsSubmitFeedbackMutation.graphql", ["useUGCAgentsSubmitFeedbackMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "data",
                    variableName: "input"
                }],
                kind: "ScalarField",
                name: "xfb_gen_ai_persona_submit_feedback",
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "useUGCAgentsSubmitFeedbackMutation",
                selections: c,
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "useUGCAgentsSubmitFeedbackMutation",
                selections: c
            },
            params: {
                id: b("useUGCAgentsSubmitFeedbackMutation_facebookRelayOperation"),
                metadata: {},
                name: "useUGCAgentsSubmitFeedbackMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useUGCAgentsSubmitFeedbackMutation", ["fbt", "BotFeedbackKind", "FBLogger", "RelayHooks", "XFBBotFeedbackKind.facebook", "cdsPushToast", "objectEntries", "react", "useUGCAgentsSubmitFeedbackMutation.graphql"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = (j || d("react")).useCallback,
        l = i !== void 0 ? i : i = b("useUGCAgentsSubmitFeedbackMutation.graphql"),
        m = function(a) {
            var b = c("objectEntries")(c("BotFeedbackKind")).find(function(b) {
                b[0];
                b = b[1];
                return b === a
            });
            if (b == null) {
                c("FBLogger")("ugc_personas").mustfix("ugc_personas_could_not_convert_bot_feedback_kind_type");
                return
            }
            b = c("XFBBotFeedbackKind.facebook").cast(b[0]);
            if (b == null) {
                c("FBLogger")("ugc_personas").mustfix("ugc_personas_could_not_cast_bot_feedback_kind_type");
                return
            }
            return b
        };

    function a(a, b) {
        var e = d("RelayHooks").useMutation(l),
            f = e[0];
        return k(function(e) {
            a == null ? void 0 : a.setIsFeedbackSubmitted(!0);
            e = m(e);
            if (!e) return;
            f({
                onCompleted: function(a) {
                    b()
                },
                onError: function(b) {
                    c("FBLogger")("ugc_personas").event("ugc_personas_submit_feedback_error").catching(b), d("cdsPushToast").pushToast({
                        message: h._("__JHASH__2M6kSClZEXW__JHASH__")
                    }), a == null ? void 0 : a.setIsFeedbackSubmitted(!1)
                },
                variables: {
                    input: {
                        bot_feedback_kind: e,
                        response_id: (e = a == null ? void 0 : a.responseId) != null ? e : "",
                        surface: "AI_STUDIO_WEB"
                    }
                }
            })
        }, [b, a, f])
    }
    g["default"] = a
}), 226);
__d("useGenAiNegativeFeedback", ["fbt", "JSResourceForInteraction", "handleMWV2NoMessageOrTurn", "useGenAiFeedbackSubmittedToast", "useMWV2SubmitFeedbackAction", "useMWXLazyDialog", "useUGCAgentsSubmitFeedbackMutation"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = c("JSResourceForInteraction")("MWV2SubmitNegativeFeedbackDialog.react").__setRef("useGenAiNegativeFeedback");

    function a(a, b) {
        var d = c("useGenAiFeedbackSubmittedToast")(a, b),
            e = "";
        if (a) {
            var f;
            e = (f = a.botResponseId) != null ? f : ""
        } else b ? e = b.responseId : c("handleMWV2NoMessageOrTurn")();
        f = c("useMWV2SubmitFeedbackAction")(e, d);
        e = c("useUGCAgentsSubmitFeedbackMutation")(b, d);
        var g;
        a ? g = f : b ? g = e : c("handleMWV2NoMessageOrTurn")();
        d = c("useMWXLazyDialog")(i);
        var j = d[0];
        f = h._("__JHASH__HrskqaLxsoO__JHASH__");
        e = function() {
            return j({
                message: a,
                onSubmit: g,
                turn: b
            })
        };
        return [e, f]
    }
    g["default"] = a
}), 226);
__d("MWV2NegativeFeedbackButton.react", ["BaseView.react", "MWMessageActionButton.react", "MWXIconLike", "handleMWV2NoMessageOrTurn", "react", "useGenAiNegativeFeedback"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            container: {
                marginEnd: "x11i5rnm",
                transform: "x19jd1h0",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.message;
        a = a.turn;
        var d = c("useGenAiNegativeFeedback")(b, a),
            e = d[0];
        d = d[1];
        if (!b && !a) {
            c("handleMWV2NoMessageOrTurn")();
            return null
        }
        return i.jsx(c("BaseView.react"), {
            xstyle: j.container,
            children: i.jsx(c("MWMessageActionButton.react"), {
                icon: c("MWXIconLike"),
                label: d,
                onPress: e,
                testid: void 0
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWV2NegativeFeedbackMenuItem.react", ["MWXMenuItem.react", "react", "useGenAiNegativeFeedback"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        a = a.message;
        a = c("useGenAiNegativeFeedback")(a);
        var b = a[0];
        a = a[1];
        return i.jsx(c("MWXMenuItem.react"), {
            "aria-label": a,
            onClick: b,
            primaryText: a,
            testid: void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useGenAiPositiveFeedback", ["fbt", "BotFeedbackKind", "MWMessageListLoggingContext", "MessengerWebUXLogger", "handleMWV2NoMessageOrTurn", "react", "useGenAiFeedbackSubmittedToast", "useMWV2SubmitFeedbackAction", "useUGCAgentsSubmitFeedbackMutation"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    b = i || d("react");
    var j = b.useCallback,
        k = b.useMemo;

    function a(a, b) {
        var e = "";
        if (a) {
            var f;
            e = (f = a.botResponseId) != null ? f : ""
        } else b ? e = b.responseId : c("handleMWV2NoMessageOrTurn")();
        f = c("useGenAiFeedbackSubmittedToast")(a, b);
        var g = c("useMWV2SubmitFeedbackAction")(e, f);
        f = c("useUGCAgentsSubmitFeedbackMutation")(b, f);
        var i;
        a ? i = g : b ? i = f : c("handleMWV2NoMessageOrTurn")();
        var l = d("MWMessageListLoggingContext").useFlowInstanceId(),
            m = k(function() {
                return {
                    extraData: {
                        botResponseId: e
                    },
                    flowInstanceId: l.current
                }
            }, [e, l]),
            n = c("MessengerWebUXLogger").useInteractionLogger();
        a = j(function() {
            i(c("BotFeedbackKind").BOT_FEEDBACK_POSITIVE), n == null ? void 0 : n(babelHelpers["extends"]({
                eventName: "submit_positive_feedback"
            }, m))
        }, [i, n, m]);
        g = h._("__JHASH__UiU1vrQt_qf__JHASH__");
        return [a, g]
    }
    g["default"] = a
}), 226);
__d("MWV2PositiveFeedbackButton.react", ["BaseView.react", "MWMessageActionButton.react", "MWXIconLike", "handleMWV2NoMessageOrTurn", "react", "useGenAiPositiveFeedback"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            container: {
                marginEnd: "x11i5rnm",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.message;
        a = a.turn;
        var d = c("useGenAiPositiveFeedback")(b, a),
            e = d[0];
        d = d[1];
        if (!b && !a) {
            c("handleMWV2NoMessageOrTurn")();
            return null
        }
        return i.jsx(c("BaseView.react"), {
            xstyle: j.container,
            children: i.jsx(c("MWMessageActionButton.react"), {
                icon: c("MWXIconLike"),
                label: d,
                onPress: e,
                testid: void 0
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWV2PositiveFeedbackMenuItem.react", ["MWXMenuItem.react", "react", "useGenAiPositiveFeedback"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        a = a.message;
        a = c("useGenAiPositiveFeedback")(a);
        var b = a[0];
        a = a[1];
        return i.jsx(c("MWXMenuItem.react"), {
            "aria-label": a,
            onClick: b,
            primaryText: a,
            testid: void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useShowPersistentGenAIFeedbackButtons", ["ReQL", "ReQLSuspense", "useGenAIFeedbackSubmissionStatus", "useIsGenAiFeedbackEnabled", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b, e) {
        var g = (h || (h = c("useReStore")))();
        e = c("useIsGenAiFeedbackEnabled")(b, e);
        var i = d("ReQLSuspense").useFirst(function() {
                return d("ReQL").fromTableDescending(g.tables.messages.index("threadKeyPrimarySortKeySecondarySortKeyBotResponseId"), ["botResponseId"]).getKeyRange(a)
            }, [g, a], f.id + ":43"),
            j = c("useGenAIFeedbackSubmissionStatus")(b);
        return e && (i == null ? void 0 : i.botResponseId) === b && j == null
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("BaseModal.react", ["cr:1824473", "cr:994756", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    h || d("react");
    a = b("cr:1824473") != null ? b("cr:1824473") : b("cr:994756");
    g["default"] = a
}), 98);
__d("EBAPIWorkerCheck", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        try {
            return WorkerGlobalScope !== void 0 && self instanceof WorkerGlobalScope
        } catch (a) {
            return !1
        }
    }
    f.runningInWorker = a
}), 66);
__d("LSInitSyncCompleteSubscription", ["I64", "LSIntEnum", "Promise", "ReQL"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;

    function k(a, c) {
        return new(j || (j = b("Promise")))(function(b, e) {
            var f = d("ReQL").fromTableAscending(a.tables.sync_groups).getKeyRange(c).subscribe(function(a, c) {
                if (c.operation === "delete") return;
                if ((h || (h = d("I64"))).equal(c.value.syncStatus, (i || (i = d("LSIntEnum"))).ofNumber(2))) {
                    f();
                    return b()
                }
            })
        })
    }

    function a(a, b) {
        return d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.tables.sync_groups).getKeyRange(b)).then(function(c) {
            if (c != null && (h || (h = d("I64"))).equal(c.syncStatus, (i || (i = d("LSIntEnum"))).ofNumber(2))) return;
            return k(a, b)
        })
    }

    function c(a) {
        return k(a, (i || (i = d("LSIntEnum"))).ofNumber(1))
    }
    g.maybeWaitForSyncGroup = a;
    g.use = c
}), 98);
__d("MAWTrackPendingOccamadilloThreads", ["Deferred", "LSDatabaseSingleton", "LSInitSyncCompleteSubscription", "LSIntEnum", "MAWMIC", "MAWMICSchema", "QuickPerformanceLogger", "asyncToGeneratorRuntime", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k, l = (h = {}, h[d("MAWMICSchema").ANNOTATIONS.occamadilloBatchesSentToWorker] = 0, h[d("MAWMICSchema").ANNOTATIONS.occamadilloPendingThreadsAfterInitSync] = 0, h[d("MAWMICSchema").ANNOTATIONS.occamadilloDuplicateThreads] = 0, h);
    (function() {
        Object.keys(l).forEach(function(a) {
            d("MAWMIC").addIntAnnotation(a, 0)
        })
    })();

    function m(a) {
        d("MAWMIC").addIntAnnotation(a, ++l[a])
    }
    var n = new(c("Deferred"))(),
        o = new Set(),
        p = new Set();

    function a() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_first_nop_start")
    }

    function e() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_acto_nop_start")
    }
    var q = null;

    function f(a) {
        d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_start);
        if (o.has(a)) {
            m(d("MAWMICSchema").ANNOTATIONS.occamadilloDuplicateThreads);
            return
        }
        p.add(a);
        q = (k || (k = c("QuickPerformanceLogger"))).currentTimestamp();
        o.add(a);
        d("MAWMIC").addIntAnnotation("occamadilloThreadCount", o.size);
        d("MAWMIC").wasEventLogged(d("MAWMICSchema").POINTS.ls_sync_end) && (m(d("MAWMICSchema").ANNOTATIONS.occamadilloPendingThreadsAfterInitSync), d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_new_pending_thread_after_init_sync))
    }

    function r() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_first_thread_check_in_ui_start")
    }

    function s() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_acto_check_in_ui_start")
    }

    function t() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_first_thread_check_in_worker_start")
    }

    function u() {
        d("MAWMIC").markEvent("occamadillo_thread_mapping_acto_check_in_worker_start")
    }

    function v(a) {
        d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_bridge_call_acked, a)
    }
    var w = [];

    function x(a) {
        d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_first_bulk_batch_run), m("occamadilloBatchesSentToWorker"), w.push(a), d("MAWMIC").addIntArrayAnnotation(d("MAWMICSchema").ANNOTATIONS.occamadilloBulkBatchSizes, w)
    }

    function y(a) {
        return z.apply(this, arguments)
    }

    function z() {
        z = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            if (c("gkx")("2661")) yield n.getPromise();
            else {
                var b = (yield(i || (i = d("LSDatabaseSingleton"))).LSDatabaseSingleton);
                yield d("LSInitSyncCompleteSubscription").maybeWaitForSyncGroup(b, (j || (j = d("LSIntEnum"))).ofNumber(95))
            }
            d("MAWMIC").markEvent("occamadillo_sync_group_complete");
            p["delete"](a);
            d("MAWMIC").addIntAnnotation("occamadilloCompleteThreadCount", o.size - p.size);
            B()
        });
        return z.apply(this, arguments)
    }

    function A() {
        n.resolve(), B()
    }

    function B() {
        p.size === 0 && (d("MAWMIC").addIntAnnotation("occamadilloThreadCount", o.size), q != null && d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_last_thread_added_to_pending, q), d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.occamadillo_thread_mapping_end))
    }
    g.incrementCounter = m;
    g.markFirstThreadPassedToNativeOp = a;
    g.markACTOPassedToNativeOp = e;
    g.addPendingThread = f;
    g.markFirstThreadCheckedInUiThread = r;
    g.markACTOCheckedInUiThread = s;
    g.markFirstThreadCheckedInWorker = t;
    g.markACTOCheckedInWorker = u;
    g.markBridgeCallAcked = v;
    g.markBulkBatchRun = x;
    g.removePendingThread = y;
    g.completeSync = A;
    g.maybeEndOccamadilloThreadMapping = B
}), 98);
__d("MWEncryptedBackupsFirstRestoreUpsellTime", ["EBAPIWorkerCheck", "FBLogger", "WebStorage", "getMWEncryptedBackupsIsLocalStorageSupported", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = "mw_encrypted_backups_restore_upsell_first_impression_time_key";

    function a() {
        var a = Date.now().toString();
        if (c("gkx")("3551") === !0 && d("EBAPIWorkerCheck").runningInWorker()) return k(a);
        if (!d("getMWEncryptedBackupsIsLocalStorageSupported").getMWEncryptedBackupsIsLocalStorageSupported()) return a;
        try {
            var b;
            b = (b = (h || (h = c("WebStorage"))).getLocalStorage()) == null ? void 0 : b.getItem(i);
            if (b == null) {
                var e;
                (e = (h || (h = c("WebStorage"))).getLocalStorage()) == null ? void 0 : e.setItem(i, a);
                return a
            }
            return b
        } catch (b) {
            c("FBLogger")("labyrinth_web").warn("[labyrinth][web] Failed to set EB session identifier due to %s", b);
            return a
        }
    }
    var j = null;

    function k(a) {
        j == null && (j = a);
        return j
    }
    g.getFirstRestoreUpsellTime = a;
    g.getFirstRestoreUpsellTimeForEBLS = k
}), 98);
__d("ZenonRTWebBrowserFeatureSupport", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return typeof window.HTMLCanvasElement === "function" && typeof window.HTMLCanvasElement.prototype.captureStream === "function"
    }

    function b() {
        return g("getSenders")
    }

    function c() {
        return typeof window.RTCRtpSender === "function" && typeof window.RTCRtpSender.prototype.replaceTrack === "function"
    }

    function d() {
        return typeof window.RTCRtpSender === "function" && typeof window.RTCRtpSender.prototype.createEncodedStreams === "function"
    }

    function e() {
        return window.RTCRtpSender && "transform" in RTCRtpSender.prototype
    }

    function g(a) {
        return typeof RTCPeerConnection.prototype[a] === "function"
    }
    f.isCanvasStreamSupported = a;
    f.isGetSendersSupported = b;
    f.isReplaceTrackSupported = c;
    f.isInsertableStreamsSupported = d;
    f.isInsertableStreamsSupportedInSafari = e
}), 66);
__d("useEmptyFunction", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return
    }
    b = a;
    f["default"] = b
}), 66);
__d("usePrevious", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useEffect,
        j = b.useRef;

    function a(a) {
        var b = j(null);
        i(function() {
            b.current = a
        });
        return b.current
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("IntlCLDRNumberType36", ["IntlVariations"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getVariation: function(a) {
            if (a === 0 || a === 1) return c("IntlVariations").NUMBER_ONE;
            else return c("IntlVariations").NUMBER_OTHER
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("MWPMessageRowCalculateStatusV2.react", ["GenderConst", "I64", "MAWThreadCutover", "MWClickedMessageContext.react", "MWMessageDeliveryStatus", "MWPActor.react", "MWPThreadCapabilitiesContext", "ReQL", "ReQLSuspense", "getLSMediaContactProfilePictureUrl", "gkx", "react", "useGetMediaGroupInformation", "useMWIsReadReceiptsDisabledForThread", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;
    j || (j = d("react"));
    b = j;
    var k = b.useEffect,
        l = b.useMemo,
        m = b.useState,
        n = {
            type: "NoneStatus"
        },
        o = {
            type: "Loading"
        },
        p = {
            type: "RetriableError"
        },
        q = {
            type: "Error"
        },
        r = {
            type: "Sending"
        },
        s = {
            type: "Sent"
        },
        t = {
            type: "Delivered"
        };

    function a(a) {
        var b = a.children,
            e = a.isBroadcastChannel,
            g = e === void 0 ? !1 : e;
        e = a.isBroadcastThread;
        var j = a.isLargeGroup,
            m = a.isSecureGroupThread,
            w = a.isSecureThread,
            x = a.message,
            y = a.nextMessage,
            z = d("MWPActor.react").useActor(),
            A = (h || (h = c("useReStore")))(),
            B = (i || (i = d("I64"))).equal(z, x.senderId),
            C = y != null && !(i || (i = d("I64"))).equal(z, y.senderId),
            D = x.isUnsent,
            E = d("MWPThreadCapabilitiesContext").useMWPThreadCapabilitiesContext();
        E = E.seenCountV2Enabled;
        var F = !x.isUnsent && E,
            G = y == null;
        E = c("useMWIsReadReceiptsDisabledForThread")(x.threadKey) && c("gkx")("24094");
        w = c("useGetMediaGroupInformation")(x, w);
        var H = c("MWClickedMessageContext.react").useHook(),
            I = H.clickedMessageId,
            J = H.fetchMessageSeenCount,
            K = H.hasError;
        H = H.isLoading;
        var L = d("ReQLSuspense").useFirst(function() {
            return F ? d("ReQL").fromTableAscending(A.tables.community_chat_message_seen_count, ["seenCount"]).getKeyRange(x.threadKey, x.messageId) : d("ReQL").empty()
        }, [A, F, x.threadKey, x.messageId], f.id + ":110");
        k(function() {
            g === !0 && G && J(x.threadKey, x.messageId)
        }, [J, x.messageId, x.threadKey, G, g, B]);
        var M = u(a, function(a) {
                return !G && a.length === 0
            }, [G]),
            N = v(function() {
                return d("ReQL").fromTableDescending(A.tables.participants.index("threadKeyReadWatermarkTimestampMs"), ["contactId"]).getKeyRange(x.threadKey).filter(function(a) {
                    return !(i || (i = d("I64"))).equal(a.contactId, z)
                }).take(1)
            }, function(a) {
                return a.length > 0
            }, [x.threadKey, z]).length > 0,
            O = v(function() {
                return d("ReQL").fromTableDescending(A.tables.participants.index("threadKeyReadWatermarkTimestampMs"), ["readWatermarkTimestampMs", "contactId"]).getKeyRange(x.threadKey).bounds({
                    gte: d("ReQL").key(x.timestampMs)
                }).filter(function(a) {
                    return !(i || (i = d("I64"))).equal(a.contactId, z)
                }).take(1)
            }, function(a) {
                return N && a.length > 0
            }, [x.timestampMs, x.threadKey, z, N]),
            P = O.length > 0;
        O = v(function() {
            return d("ReQL").fromTableDescending(A.tables.participants.index("threadKeyDeliveredWatermarkTimestampMs"), ["contactId"]).getKeyRange(x.threadKey).bounds({
                gte: d("ReQL").key(x.timestampMs)
            }).filter(function(a) {
                return !(i || (i = d("I64"))).equal(a.contactId, z)
            }).take(1)
        }, function(a) {
            return a.length > 0 || P
        }, [x.threadKey, x.timestampMs, P, z]).length > 0;
        var Q = u(a, function(a) {
                return P && a.length === 0
            }, [P]),
            R = l(function() {
                var a;
                return d("MWMessageDeliveryStatus").seenCount((i || (i = d("I64"))).to_int32((a = L == null ? void 0 : L.seenCount) != null ? a : (i || (i = d("I64"))).zero))
            }, [L == null ? void 0 : L.seenCount]),
            S = l(function() {
                return d("MWMessageDeliveryStatus").seenHead(M)
            }, [M]),
            T = l(function() {
                return d("MWMessageDeliveryStatus").seenHead(Q)
            }, [Q]);
        if (x.isAdminMessage) return b(n);
        if (e)
            if (!F) {
                if (!B || y != null || D) return b(n)
            } else {
                if (I !== x.messageId) return b(n);
                if (H) return b(o);
                return K ? b(p) : L != null ? b(R) : b(o)
            }
        if (!B) {
            if (m && !c("gkx")("3265") || j) return b(n);
            return g === !0 ? L != null ? b(R) : b(n) : M.length > 0 ? a.children(S) : a.children(n)
        }
        if (B && G && g && (L != null && (i || (i = d("I64"))).to_int32(L.seenCount) > 0)) return b(R);
        if (C && m) return b(n);
        if ((i || (i = d("I64"))).equal(x.sendStatusV2, (i || (i = d("I64"))).of_int32(0))) return b(n);
        if ((i || (i = d("I64"))).equal(x.sendStatusV2, (i || (i = d("I64"))).of_int32(4))) return b(q);
        if ((i || (i = d("I64"))).equal(x.sendStatusV2, (i || (i = d("I64"))).of_int32(5))) return b(p);
        if ((i || (i = d("I64"))).equal(x.sendStatusV2, (i || (i = d("I64"))).of_int32(1))) return b(r);
        if ((i || (i = d("I64"))).equal(x.sendStatusV2, (i || (i = d("I64"))).of_int32(6))) return b(s);
        if (j)
            if (y != null || D) return b(n);
            else if ((i || (i = d("I64"))).equal(x.sendStatusV2, (i || (i = d("I64"))).of_int32(2))) return b(t);
        if (P && !E) return Q.length > 0 ? b(T) : b(n);
        if (w != null && w.isMediaGroupLastMessage)
            if (w.hasAllMessagesSent) return b(s);
            else return b(r);
        return O ? b(t) : b(s)
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function u(a, b, e) {
        var g = (h || (h = c("useReStore")))(),
            j = d("MWPActor.react").useActor(),
            k = a.message,
            l = a.nextMessage,
            m = c("useMWIsReadReceiptsDisabledForThread")(k.threadKey) && c("gkx")("24094");
        a = d("MAWThreadCutover").useGetCutoverSecureThreadKey(a.isSecureThread ? (i || (i = d("I64"))).to_string(k.threadKey) : void 0);
        var n = a != null ? (i || (i = d("I64"))).of_string(a) : null;
        a = v(function() {
            var a = l != null ? {
                gte: d("ReQL").key(k.timestampMs),
                lt: d("ReQL").key(l.timestampMs)
            } : {
                gte: d("ReQL").key(k.timestampMs)
            };
            a = d("ReQL").fromTableAscending(g.tables.participants.index("threadKeyReadWatermarkTimestampMs"), ["contactId", "nickname", "readActionTimestampMs"]).getKeyRange(k.threadKey).bounds(a).filter(function(a) {
                return !(i || (i = d("I64"))).equal(a.contactId, j)
            });
            var b = {
                    gte: d("ReQL").key(k.timestampMs)
                },
                c = n != null ? d("ReQL").fromTableAscending(g.tables.participants.index("threadKeyReadWatermarkTimestampMs"), ["contactId", "nickname", "readActionTimestampMs"]).getKeyRange(n).bounds(b).filter(function(a) {
                    return !(i || (i = d("I64"))).equal(a.contactId, j)
                }) : d("ReQL").empty();
            return d("ReQL").union(a, c).map(function(a) {
                var b = d("ReQLSuspense").toArray(c, f.id + ":453").some(function(b) {
                    return (i || (i = d("I64"))).equal(b.contactId, a.contactId)
                });
                return b ? void 0 : a
            }).filter(Boolean).map(function(a) {
                var b = d("ReQLSuspense").first(d("ReQL").fromTableAscending(g.tables.contacts, ["id", "name", "profilePictureFallbackUrl", "profilePictureUrl", "profilePictureUrlExpirationTimestampMs"]).getKeyRange(a.contactId), f.id + ":468");
                return [a, b]
            })
        }, b, [g, k.threadKey, k.timestampMs, l == null ? void 0 : l.timestampMs, l == null, n == null, j].concat(e));
        return m ? [] : a.map(function(a) {
            var b, e = a[0];
            a = a[1];
            if (a == null) return;
            return {
                gender: c("GenderConst").UNKNOWN_SINGULAR,
                id: (i || (i = d("I64"))).to_string(a.id),
                imageSrc: c("getLSMediaContactProfilePictureUrl")(a),
                name: (b = e.nickname) != null ? b : a.name,
                timestamp: i.to_float(e.readActionTimestampMs)
            }
        }).filter(Boolean)
    }

    function v(a, b, c) {
        var e = m(void 0),
            g = e[0];
        e = e[1];
        c = d("ReQLSuspense").useArray(function() {
            return g != null ? d("ReQL").empty() : a()
        }, [].concat(c, [g]), f.id + ":528");
        b(c) && g == null && e(c);
        return g != null ? g : c
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("MWV2AttachmentPlaceholderWithBlurImage.react", ["CometBlurredBackgroundImage.react", "CometPlaceholder.react", "MWV2ChatImage.react", "MWXAspectRatioContainer.react", "MWXMessageBubbleCornerStyles.react", "react", "stylex", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            content: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "x1tlxs6b",
                borderTopEndRadius: "x1g8br2z",
                borderBottomEndRadius: "x1gn5b1j",
                borderBottomStartRadius: "x230xth",
                display: "x78zum5",
                height: "x5yr21d",
                justifyContent: "xl56j7k",
                width: "xh8yej3",
                $$css: !0
            },
            dark: {
                backgroundColor: "xhzw6zf",
                $$css: !0
            },
            gallery: {
                backgroundPosition: "x1bz1qqp",
                $$css: !0
            },
            light: {
                backgroundColor: "x1vtvx1t",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.connectBottom,
            e = a.connectTop,
            f = a.dbAttachment,
            g = a.getPreviewUrl,
            i = a.hasAppAttribution,
            m = a.height,
            n = a.isGroupedImage,
            o = a.maxHeight,
            p = a.maxWidth,
            q = a.mediaRenderQpl,
            r = a.message,
            s = a.outgoing,
            t = a.width,
            u = a.xstyle,
            v = c("useCurrentDisplayMode")();
        m = (a = m) != null ? a : 100;
        t = (a = t) != null ? a : 200;
        var w = d("MWXMessageBubbleCornerStyles.react").getMWXBubbleCornerStyles({
                align: s === !0 ? "right" : "left",
                connectBottom: b,
                connectTop: e,
                flatten: i === !0 ? "bottom" : "none"
            }),
            x = j.jsx(c("MWXAspectRatioContainer.react"), {
                height: m,
                maxHeight: (a = o) != null ? a : 200,
                maxWidth: (i = p) != null ? i : 480,
                width: t,
                children: function(a) {
                    return j.jsx("div", {
                        className: (h || (h = c("stylex")))([a, k.content, v === "dark" ? k.dark : k.light, w, u]),
                        "data-testid": void 0
                    })
                }
            });
        return j.jsx("div", {
            className: "x47corl",
            children: r != null ? j.jsx(c("CometPlaceholder.react"), {
                fallback: x,
                name: "MWV2AttachmentErrorPlaceholderWithBlurImage",
                children: j.jsx(c("MWV2ChatImage.react"), {
                    attachment: f,
                    connectBottom: b,
                    connectTop: e,
                    getPreviewUrl: g,
                    isGroupedImage: n,
                    isSecure: !0,
                    maxHeight: (a = o) != null ? a : m,
                    maxWidth: (i = p) != null ? i : t,
                    mediaRenderQpl: null,
                    message: r,
                    navigateToRouteForMediaViewer: !1,
                    outgoing: s,
                    renderUnsupportedAttachment: function() {
                        return x
                    },
                    shouldBlur: !0
                })
            }) : j.jsx(c("CometPlaceholder.react"), {
                fallback: x,
                name: "MWV2AttachmentErrorPlaceholderWithBlurImage",
                children: j.jsx(l, {
                    dbAttachment: f,
                    fallback: x,
                    getPreviewUrl: g,
                    heightCalculated: m,
                    maxHeight: o,
                    maxWidth: p,
                    mediaRenderQpl: q,
                    widthCalculated: t
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function l(a) {
        var b = a.dbAttachment,
            d = a.fallback,
            e = a.getPreviewUrl,
            f = a.heightCalculated,
            g = a.maxHeight,
            h = a.maxWidth,
            i = a.mediaRenderQpl;
        a = a.widthCalculated;
        var l = e(b, "MWV2AttachmentErrorPlaceholderWithBlurImage.react", i);
        return l != null ? j.jsx(c("MWXAspectRatioContainer.react"), {
            height: f,
            maxHeight: g,
            maxWidth: h,
            width: a,
            children: function(a) {
                return j.jsx(c("CometBlurredBackgroundImage.react"), {
                    src: l,
                    xstyle: [a, k.gallery]
                })
            }
        }) : d
    }
    l.displayName = l.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWV2AttachmentErrorPlaceholderWithBlurImage.react", ["MAWVideoAudioPlaybackErrorHandlerUtils", "MWV2AttachmentPlaceholderWithBlurImage.react", "MWXIconExclamationMarkCircle", "MWXIconStrict.react", "MWXText.react", "MWXTooltip.react", "MediaDownloadStatusIconSize", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useEffect,
        l = {
            galleryMediaStatusIcon: {
                height: "xxk0z11",
                width: "xvy4d1p",
                $$css: !0
            },
            nonRetryableError: {
                alignItems: "x6s0dn4",
                backgroundColor: "x18l40ae",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                color: "x14ctfv",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                $$css: !0
            },
            threadMediaStatusIcon: {
                height: "x1vqgdyp",
                width: "x100vrsf",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.connectBottom,
            e = a.connectTop,
            f = a.dbAttachment,
            g = a.getPreviewUrl,
            i = a.hasAppAttribution,
            m = a.height,
            n = a.iconSize,
            o = a.isGroupedImage,
            p = a.maxHeight,
            q = a.maxWidth,
            r = a.mediaRenderQpl,
            s = a.message,
            t = a.outgoing,
            u = a.width,
            v = a.withTooltip;
        a = a.xstyle;
        k(function() {
            r == null ? void 0 : r.addPoint("render-error-placeholder-with-blur-image", {
                bool: {
                    has_message: s != null
                }
            })
        }, [r, s]);
        var w = d("MAWVideoAudioPlaybackErrorHandlerUtils").useGetMetadataForMediaNotRendered(f, !1),
            x = w.mediaStatusText;
        w = w.retryButton;
        n = j.jsxs(j.Fragment, {
            children: [j.jsx("div", {
                className: "xtzzx4i x10l6tqk xwa60dl x11lhmoz x1vjfegm",
                children: j.jsx("div", {
                    className: (h || (h = c("stylex")))([l.nonRetryableError, n === c("MediaDownloadStatusIconSize").Large ? l.threadMediaStatusIcon : l.galleryMediaStatusIcon]),
                    "data-testid": void 0,
                    children: j.jsx(c("MWXIconStrict.react"), {
                        color: "white",
                        icon: c("MWXIconExclamationMarkCircle"),
                        size: n === c("MediaDownloadStatusIconSize").Large ? 20 : 12
                    })
                })
            }), j.jsx(c("MWV2AttachmentPlaceholderWithBlurImage.react"), {
                connectBottom: b,
                connectTop: e,
                dbAttachment: f,
                getPreviewUrl: g,
                hasAppAttribution: i,
                height: m,
                isGroupedImage: o,
                maxHeight: p,
                maxWidth: q,
                mediaRenderQpl: r,
                message: s,
                outgoing: t,
                width: u,
                xstyle: a
            })]
        });
        return v === !0 ? j.jsx(c("MWXTooltip.react"), {
            label: x,
            tooltip: j.jsxs(c("MWXText.react"), {
                color: "tooltip",
                type: "meta4",
                children: [x, w]
            }),
            children: n
        }) : n
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWV2AttachmentRetriableErrorPlaceholderWithBlurImage.react", ["fbt", "MAWVideoAudioPlaybackErrorHandlerUtils", "MWV2AttachmentPlaceholderWithBlurImage.react", "MWXCircleButton.react", "MWXIconRefreshAlt", "MWXText.react", "MWXTooltip.react", "MediaDownloadStatusIconSize", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useEffect;

    function a(a) {
        var b = a.connectBottom,
            e = a.connectTop,
            f = a.dbAttachment,
            g = a.getPreviewUrl,
            i = a.hasAppAttribution,
            l = a.height,
            m = a.iconSize,
            n = a.isGroupedImage,
            o = a.maxHeight,
            p = a.maxWidth,
            q = a.mediaRenderQpl,
            r = a.message,
            s = a.onRetry,
            t = a.outgoing,
            u = a.width,
            v = a.withTooltip;
        a = a.xstyle;
        k(function() {
            q == null ? void 0 : q.addPoint("render-error-placeholder-with-blur-image", {
                bool: {
                    has_message: r != null,
                    is_retryable_error: !0
                }
            })
        }, [q, r]);
        var w = d("MAWVideoAudioPlaybackErrorHandlerUtils").useGetMetadataForMediaNotRendered(f, !0, s),
            x = w.mediaStatusText;
        w = w.retryButton;
        s = j.jsxs(j.Fragment, {
            children: [j.jsx("div", {
                className: "xtzzx4i x10l6tqk xwa60dl x11lhmoz x1vjfegm",
                children: j.jsx(c("MWXCircleButton.react"), {
                    color: "white",
                    icon: c("MWXIconRefreshAlt"),
                    label: h._("__JHASH__BGxC_0TtXwE__JHASH__"),
                    onPress: s,
                    size: m === c("MediaDownloadStatusIconSize").Large ? 40 : 24,
                    testid: void 0,
                    type: "dark-overlay"
                })
            }), j.jsx(c("MWV2AttachmentPlaceholderWithBlurImage.react"), {
                connectBottom: b,
                connectTop: e,
                dbAttachment: f,
                getPreviewUrl: g,
                hasAppAttribution: i,
                height: l,
                isGroupedImage: n,
                maxHeight: o,
                maxWidth: p,
                mediaRenderQpl: q,
                message: r,
                outgoing: t,
                width: u,
                xstyle: a
            })]
        });
        return v === !0 ? j.jsx(c("MWXTooltip.react"), {
            label: x,
            tooltip: j.jsxs(c("MWXText.react"), {
                color: "tooltip",
                type: "meta4",
                children: [x, w]
            }),
            children: s
        }) : s
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226); /*FB_PKG_DELIM*/
__d("MAWIsXMAWithPlaintextHash", ["I64", "LSIntEnum", "MessagingAttachmentType"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a) {
        return !(h || (h = d("I64"))).equal(a.attachmentType, (i || (i = d("LSIntEnum"))).ofNumber(c("MessagingAttachmentType").XMA)) ? !1 : ![a.xmaPreviewFbid, a.xmaHeaderImageFbid, a.xmaFaviconFbid].filter(Boolean).every(isFinite)
    }
    g.isXMAWithPlaintextHash = a
}), 98);
__d("MAWOneTimeCodeGating", ["gkx", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("gkx")("1910") && c("justknobx")._("1601")
    }
    g.isOneTimeCodeEnabled = a
}), 98);
__d("MWEBVestaUserInfoContext.react", ["react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    e = b.createContext;
    var i = b.useContext,
        j = e(null);

    function k() {
        var a = i(j);
        if (a == null) throw c("unrecoverableViolation")("useMWEBVestaUserInfo must be used inside MWEBVestaUserInfoContext", "messenger_web_product");
        return a
    }

    function a() {
        var a = k(),
            b = a.attemptsRemaining;
        a = a.loginTimeoutRemainingSecs;
        return b === 0 || a != null && a > 0
    }
    g.MWEBVestaUserInfoContext = j;
    g.useMWEBVestaUserInfo = k;
    g.useMWEBIsCooldownOrLockOutState = a
}), 98);
__d("MWEBVirtualDevicesContext.react", ["react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || (h = d("react"));
    var i = h.useContext,
        j = b.createContext(null);

    function a() {
        var a = i(j);
        if (a == null) throw c("unrecoverableViolation")("useEBVirtualDevices must be used inside MWEBVirtualDevicesContext", "messenger_web_product");
        return a
    }
    g.MWEBVirtualDevicesContext = j;
    g.useMWEBVirtualDevices = a
}), 98);
__d("useHasOTCEligibleDevices", ["MAWOneTimeCodeGating", "ReQL", "ReQLSuspense", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        var a = (h || (h = c("useReStore")))(),
            b = d("ReQLSuspense").useFirst(function() {
                return d("ReQL").fromTableAscending(a.tables.encrypted_backups)
            }, [a], f.id + ":19");
        return b == null || !d("MAWOneTimeCodeGating").isOneTimeCodeEnabled() ? !1 : b.hasOtcEligibleDevices
    }
    g["default"] = a
}), 98);
__d("useMWEncryptedBackupsListenForChangesToVirtualDevicesV2", ["Base64Utils", "I64", "LSIntEnum", "ReQL", "ReQLSuspense", "react", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k;
    b = k || d("react");
    var l = b.useEffect,
        m = b.useMemo,
        n = b.useState;

    function a(a) {
        a = a === void 0 ? {} : a;
        var b = a.offlineDevicesCountInitialValue,
            e = a.vestaClientIDInitialValue,
            g = (h || (h = c("useReStore")))(),
            k = d("ReQLSuspense").useArray(function() {
                return d("ReQL").fromTableAscending(g.tables.encrypted_backups_virtual_devices)
            }, [g], f.id + ":52");
        a = m(function() {
            if (e != null) return e;
            var a = k.filter(function(a) {
                return (i || (i = d("I64"))).equal(a.virtualDeviceType, (j || (j = d("LSIntEnum"))).ofNumber(2))
            });
            a = a[0];
            return a != null ? d("Base64Utils").fromArrayBuffer(a.virtualDeviceId) : void 0
        }, [k, e]);
        var o = m(function() {
            return b != null ? b : k.filter(function(a) {
                return (i || (i = d("I64"))).equal(a.virtualDeviceType, (j || (j = d("LSIntEnum"))).ofNumber(1))
            }).length
        }, [k, b]);
        a = n(a);
        var p = a[0],
            q = a[1];
        a = n(o);
        o = a[0];
        var r = a[1];
        l(function() {
            if (k.length === 0) return;
            var a = k.filter(function(a) {
                return (i || (i = d("I64"))).equal(a.virtualDeviceType, (j || (j = d("LSIntEnum"))).ofNumber(2))
            });
            a = a[0];
            var b = k.filter(function(a) {
                return (i || (i = d("I64"))).equal(a.virtualDeviceType, (j || (j = d("LSIntEnum"))).ofNumber(1))
            });
            q(a != null ? d("Base64Utils").fromArrayBuffer(a.virtualDeviceId) : void 0);
            r(b.length)
        }, [k]);
        return {
            offlineDevicesCount: o,
            vestaClientID: p
        }
    }
    g["default"] = a
}), 98);
__d("MWEBVirtualDevicesContextProvider.react", ["MAWOneTimeCodeGating", "MWEBVirtualDevicesContext.react", "gkx", "react", "useHasOTCEligibleDevices", "useMWEncryptedBackupsListenForChangesToVirtualDevicesV2"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useMemo,
        k = (b = c("gkx")("24064")) != null ? b : !1;

    function a(a) {
        var b = a.children,
            e = a.hasOtcEligibleDevicesInitialValue,
            f = a.offlineDevicesCountInitialValue;
        f = f === void 0 ? -1 : f;
        a = a.vestaClientIDInitialValue;
        a = c("useMWEncryptedBackupsListenForChangesToVirtualDevicesV2")({
            offlineDevicesCountInitialValue: f,
            vestaClientIDInitialValue: (f = a) != null ? f : void 0
        });
        var g = a.offlineDevicesCount,
            h = a.vestaClientID;
        f = c("useHasOTCEligibleDevices")();
        var l = d("MAWOneTimeCodeGating").isOneTimeCodeEnabled() && (k === !0 || e === !0 || f);
        a = j(function() {
            return {
                virtualDeviceInfo: {
                    doesUserHaveOtcEligibleDevices: l,
                    isPINCodeRegistered: h != null,
                    offlineDevicesCount: g,
                    vestaClientID: h
                }
            }
        }, [l, g, h]);
        return i.jsx(d("MWEBVirtualDevicesContext.react").MWEBVirtualDevicesContext.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useMWChatEncryptedBackupsVestaUserInfo_vestaGetUserInfoResponse.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useMWChatEncryptedBackupsVestaUserInfo_vestaGetUserInfoResponse",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "attempts_remaining",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_registered",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "login_timeout_remaining_secs",
            storageKey: null
        }],
        type: "VestaGetUserInfoResponse",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useMWChatEncryptedBackupsVestaUserInfo", ["CometRelay", "useMWChatEncryptedBackupsVestaUserInfo_vestaGetUserInfoResponse.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var c;
        a = a.vestaGetUserInfoResponse$key;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useMWChatEncryptedBackupsVestaUserInfo_vestaGetUserInfoResponse.graphql"), a);
        return {
            attemptsRemaining: (c = a == null ? void 0 : a.attempts_remaining) != null ? c : null,
            isRegistered: (c = a == null ? void 0 : a.is_registered) != null ? c : null,
            loginTimeoutRemainingSecs: (c = a == null ? void 0 : a.login_timeout_remaining_secs) != null ? c : null
        }
    }
    g["default"] = a
}), 98);
__d("useMWEncryptedBackupsGetVirtualDevicesPreloaded_xfbEncryptedBackup.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useMWEncryptedBackupsGetVirtualDevicesPreloaded_xfbEncryptedBackup",
        selections: [{
            alias: null,
            args: null,
            concreteType: "XFBEBVirtualDevice",
            kind: "LinkedField",
            name: "virtual_devices",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "client_generated_id",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "device_type",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "XFBEncryptedBackup",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useMWEncryptedBackupsGetVirtualDevicesPreloaded", ["CometRelay", "react", "useMWEncryptedBackupsGetVirtualDevicesPreloaded_xfbEncryptedBackup.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (i || d("react")).useCallback;

    function a(a) {
        a = a.encryptedBackup;
        var c = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useMWEncryptedBackupsGetVirtualDevicesPreloaded_xfbEncryptedBackup.graphql"), a);
        a = j(function() {
            var a = 0,
                b = null;
            c == null ? void 0 : c.virtual_devices.forEach(function(c) {
                switch (c.device_type) {
                    case "HSM":
                        b = c.client_generated_id;
                        break;
                    case "OFFLINE":
                        a += 1;
                        break;
                    default:
                        break
                }
            });
            return {
                offlineDevicesCount: a,
                vestaClientID: b
            }
        }, [c == null ? void 0 : c.virtual_devices]);
        return {
            getVirtualDevices: a
        }
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("EBSMGating", ["MAWWaitForBackendSetup", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        return c("gkx")("24151")
    }

    function a() {
        return d("MAWWaitForBackendSetup").isBackendSetupSuccessful() || h()
    }
    g.isPersistedEBTableEnabled = h;
    g.isBackendSetupSuccessfulForEBSM = a
}), 98);
__d("EBSMProperties", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = ["encrypted_backups_virtual_devices", "secure_encrypted_backups_recovery_code_status", "device_metadata", "secure_encrypted_backups_epochs", "secure_encrypted_backups_client_state", "encrypted_backups", "experiences_shared_state", "occamadillo_most_recent_message_per_thread", "auto_restore_opt_out"];
    b = new Set(["secure_encrypted_backups_client_state", "secure_encrypted_backups_epochs"]);
    c = {
        dbVersion: 5,
        mandatoryTables: b,
        persistedTables: new Set(a),
        persistedTablesArray: a
    };
    d = c;
    f["default"] = d
}), 66);
__d("MAWEncryptedBackupsPersistedDB", ["EBSMGating", "EBSMProperties", "FBLogger", "LSMetadata", "MAWCurrentUser", "MAWIndexedDBDeletion", "MAWIndexedDbMetadata", "MWEBODSCategory", "MWEBODSEntityKey.enum", "MWEBODSEntityName.enum", "ODS", "Promise", "QPLUserFlow", "WALoggerDeferred", "err", "gkx", "justknobx", "qex", "qpl", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB upgrade needed"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EBSM upgrade failed: ", ". Falling back to ephemeral LSDB"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB onVersionChange: closing the db"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB initialization successsful"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB initialization: db blocked"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] EB state DB initialization failed"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Initializing EB state DB"]);
        p = function() {
            return a
        };
        return a
    }
    var q = null,
        r = c("justknobx")._("2243");

    function a() {
        if (q == null) throw c("err")("EB state IndexedDB should've been initialized");
        return q
    }
    var s = (i || (i = b("Promise"))).resolve();

    function e() {
        return s
    }

    function f(a) {
        a === void 0 && (a = !1);
        return !a && !d("EBSMGating").isPersistedEBTableEnabled() ? (i || (i = b("Promise"))).resolve() : (i || (i = b("Promise"))).resolve().then(function() {
            if (q == null) {
                c("QPLUserFlow").start(c("qpl")._(521471732, "1454"));
                (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").START);
                void d("WALoggerDeferred").LOG(p());
                var a = indexedDB.open(d("MAWIndexedDbMetadata").ebLSDBName(d("MAWCurrentUser").getID()), c("EBSMProperties").dbVersion);
                return new(i || (i = b("Promise")))(function(e, f) {
                    a.onerror = function(a) {
                        c("QPLUserFlow").endFailure(c("qpl")._(521471732, "1454"), "EB state idb initialization failed"), void d("WALoggerDeferred").ERROR(o()), c("QPLUserFlow").endFailure(c("qpl")._(521477507, "1406"), "Initialisation failed. Reached onerror."), c("FBLogger")("labyrinth_web").catching(a).mustfix("[labyrinth_web] EBSM idb init failed: %s", a), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").FAIL), f(a)
                    }, a.onblocked = function() {
                        void d("WALoggerDeferred").LOG(n()), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, "blocked")
                    }, a.onsuccess = function(a) {
                        var b = a.target.result;
                        void d("WALoggerDeferred").LOG(m());
                        b.onversionchange = function() {
                            void d("WALoggerDeferred").LOG(l()), b.close()
                        };
                        q = b;
                        return s.then(function() {
                            c("QPLUserFlow").endSuccess(c("qpl")._(521471732, "1454")), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").SUCCESS), e(b)
                        })["catch"](function(a) {
                            void d("WALoggerDeferred").ERROR(k(), a.message), c("QPLUserFlow").endFailure(c("qpl")._(521471732, "1454"), "EB state idb upgrade failed"), (h || (h = d("ODS"))).bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, "upgrade.fail"), h.bumpEntityKey(c("MWEBODSCategory"), c("MWEBODSEntityName.enum").MW_EBSM_IDB, c("MWEBODSEntityKey.enum").FAIL), e(null)
                        })
                    }, a.onupgradeneeded = function(a) {
                        var e = a.target.result;
                        a = new(i || (i = b("Promise")))(function(a, b) {
                            setTimeout(function() {
                                b(c("err")("EBSM upgrade timeout"))
                            }, r)
                        });
                        var f = new i(function(a) {
                            c("QPLUserFlow").addPoint(c("qpl")._(521471732, "1454"), "eb_state_idb_upgrade_start", {
                                data: {
                                    bool: {
                                        eb_state_upgrade: !0
                                    }
                                }
                            });
                            void d("WALoggerDeferred").LOG(j());
                            var b = Object.keys(d("LSMetadata").schema.tableNames);
                            for (var f = 0; f < b.length; f++) {
                                var g = b[f];
                                c("EBSMProperties").persistedTables.has(g) && !e.objectStoreNames.contains(g) && e.createObjectStore(g, {
                                    autoIncrement: !0
                                })
                            }
                            c("QPLUserFlow").addPoint(c("qpl")._(521471732, "1454"), "eb_state_idb_upgrade_end", {
                                data: {
                                    bool: {
                                        eb_state_upgrade: !0
                                    }
                                }
                            });
                            a()
                        });
                        s = i.race([f, a])
                    }
                })
            } else return q
        })
    }

    function t(a) {
        a = a.hasUserGivenAutoRestoreConsent;
        var b = a ? ["secure_encrypted_backups_epochs", "secure_encrypted_backups_client_state"] : [];
        c("qex")._("926") && b.push("occamadillo_most_recent_message_per_thread");
        c("gkx")("5229") && b.push("auto_restore_opt_out");
        a = Array.from(c("EBSMProperties").persistedTables).filter(function(a) {
            return !b.includes(a)
        });
        try {
            if (q != null) {
                var d = q.transaction(a, "readwrite");
                a.forEach(function(a) {
                    a = d.objectStore(a);
                    a.clear()
                });
                d.oncomplete = function() {
                    d.db.close()
                }
            }
        } catch (a) {
            c("recoverableViolation")(a, "labyrinth_web")
        }
    }

    function u() {
        var a = d("MAWIndexedDbMetadata").ebLSDBName(d("MAWCurrentUser").getID());
        return d("MAWIndexedDBDeletion").deleteDB(a, "ebsm")
    }

    function v(a) {
        if (q != null) {
            var c = q.transaction([a], "readwrite");
            a = c.objectStore(a);
            a.clear();
            c.oncomplete = function() {
                c.db.close()
            }
        }
        return (i || (i = b("Promise"))).resolve()
    }
    g.getEBLSDB = a;
    g.isDBBeingUpgraded = e;
    g.makeEBIDB = f;
    g.clearEBIDBNonPersistedRows = t;
    g.deleteEBIDB = u;
    g.clearEBSMTable = v
}), 98); /*FB_PKG_DELIM*/
__d("BaseSwitch.react", ["BaseFocusRing.react", "BaseInput.react", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            "switch": {
                cursor: "x1ypdohk",
                height: "x5yr21d",
                start: "x17qophe",
                left: null,
                right: null,
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                opacity: "x1w3u9th",
                outline: "x1a2a7pz",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                position: "x10l6tqk",
                top: "x13vifvy",
                width: "xh8yej3",
                $$css: !0
            },
            wrapper: {
                position: "x1n2onr6",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        var d = a.children,
            e = a.xstyle,
            f = a.suppressFocusRing,
            g = a.testid,
            h = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "xstyle", "suppressFocusRing", "testid"]);
        return i.jsx(c("BaseFocusRing.react"), {
            suppressFocusRing: f,
            children: function(a) {
                return i.jsxs(c("BaseView.react"), {
                    testid: void 0,
                    xstyle: [j.wrapper, a, e],
                    children: [d, i.jsx(c("BaseInput.react"), babelHelpers["extends"]({}, h, {
                        "aria-checked": (a = h.checked) != null ? a : !1,
                        ref: b,
                        role: "switch",
                        type: "checkbox",
                        xstyle: j["switch"]
                    }))]
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = i.memo(b);
    g["default"] = e
}), 98);
__d("FDSSkittleIcon.react", ["FDSIcon.react", "MetaConfig", "profilePhotoUtils", "react", "react-strict-dom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            circle: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                $$css: !0
            },
            iconBadge: {
                alignItems: "x6s0dn4",
                backgroundColor: "xwnonoy",
                borderTopColor: "x6zyg47",
                borderEndColor: "x1xm1mqw",
                borderBottomColor: "xpn8fn3",
                borderStartColor: "xtct9fg",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "xamhcws",
                borderEndWidth: "xol2nv",
                borderBottomWidth: "xlxy82",
                borderStartWidth: "x19p7ews",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "x1nn3v0j",
                paddingEnd: "xg83lxy",
                paddingBottom: "x1120s5i",
                paddingStart: "x1h0ha7o",
                position: "x10l6tqk",
                $$css: !0
            },
            roundedRect: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                $$css: !0
            },
            skittle: {
                alignItems: "x6s0dn4",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxSizing: "x9f619",
                display: "x3nfvp2",
                justifyContent: "xl56j7k",
                position: "x1n2onr6",
                $$css: !0
            }
        },
        k = {
            accent: {
                backgroundColor: "xwnonoy",
                $$css: !0
            },
            blue: {
                backgroundColor: "x11goek",
                $$css: !0
            },
            cherry: {
                backgroundColor: "x1tzrqqp",
                $$css: !0
            },
            grape: {
                backgroundColor: "x17f3y5z",
                $$css: !0
            },
            gray: {
                backgroundColor: "x1qhmfi1",
                $$css: !0
            },
            green: {
                backgroundColor: "xv9rvxn",
                $$css: !0
            },
            lemon: {
                backgroundColor: "xacajkf",
                $$css: !0
            },
            lightblue: {
                backgroundColor: "x1hr4nm9",
                $$css: !0
            },
            lime: {
                backgroundColor: "xbmc1ew",
                $$css: !0
            },
            pink: {
                backgroundColor: "x1qrsksh",
                $$css: !0
            },
            "primary-on-media": {
                backgroundColor: "xyyilqk",
                $$css: !0
            },
            "primary-on-media-legacy": {
                backgroundColor: "x9bbmet",
                $$css: !0
            },
            red: {
                backgroundColor: "x1ciooss",
                $$css: !0
            },
            seafoam: {
                backgroundColor: "x1tw9p8u",
                $$css: !0
            },
            teal: {
                backgroundColor: "x1emf0wh",
                $$css: !0
            },
            tomato: {
                backgroundColor: "xqjkjv5",
                $$css: !0
            },
            white: {
                backgroundColor: "x14hiurz",
                $$css: !0
            }
        },
        l = {
            32: {
                height: "x10w6t97",
                width: "x1td3qas",
                $$css: !0
            },
            36: {
                height: "xc9qbxq",
                width: "x14qfxbe",
                $$css: !0
            },
            40: {
                height: "x1vqgdyp",
                width: "x100vrsf",
                $$css: !0
            },
            48: {
                height: "xsdox4t",
                width: "x1useyqa",
                $$css: !0
            },
            56: {
                height: "xnnlda6",
                width: "x15yg21f",
                $$css: !0
            },
            60: {
                height: "xng8ra",
                width: "x1247r65",
                $$css: !0
            }
        },
        m = new Map([
            [24, 16],
            [36, 20],
            [40, 24],
            [48, 24],
            [56, 24],
            [60, 24]
        ]);

    function n(a) {
        switch (a) {
            case "gray":
                return "primary";
            case "white":
                return "primary";
            case "lightblue":
                return "highlight";
            case "primary-on-media":
                return c("MetaConfig")._("179") ? "primaryButtonIconOnMedia" : "secondary";
            default:
                return "white"
        }
    }
    b = i.forwardRef(a);

    function a(a, b) {
        var e = a.color,
            f = a.disabled;
        f = f === void 0 ? !1 : f;
        var g = a.icon,
            h = a.iconBadge,
            o = a.iconBadgeAria,
            p = a.shape;
        p = p === void 0 ? "circle" : p;
        var q = a.size;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["color", "disabled", "icon", "iconBadge", "iconBadgeAria", "shape", "size"]);
        var r = a["aria-label"] == null && a["aria-labelledby"] == null,
            s = (o == null ? void 0 : o["aria-label"]) == null && (o == null ? void 0 : o["aria-labelledby"]) == null;
        return i.jsxs(d("react-strict-dom").html.div, {
            ref: b,
            style: [p === "circle" && j.circle, p === "roundedRect" && j.roundedRect, j.skittle, e === "primary-on-media" ? c("MetaConfig")._("179") ? k["primary-on-media"] : k["primary-on-media-legacy"] : k[e], l[q]],
            children: [i.jsx(c("FDSIcon.react"), babelHelpers["extends"]({}, r ? {
                isDecorative: r
            } : a, {
                color: f ? "disabled" : n(e),
                icon: g,
                size: m.get(q)
            })), h != null && i.jsx(d("react-strict-dom").html.div, {
                style: [j.iconBadge, [d("profilePhotoUtils").getBadgePosition(q / 2)]],
                children: i.jsx(c("FDSIcon.react"), babelHelpers["extends"]({}, s ? {
                    isDecorative: s
                } : o, {
                    color: "white",
                    icon: h,
                    size: 8
                }))
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98); /*FB_PKG_DELIM*/
__d("BaseInfiniteScrollList.react", ["BaseScrollableAreaContext", "CometDialogContext", "CometInfiniteScrollTrigger.react", "CometScrollableArea.react", "FBLogger", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext;

    function a(a) {
        var b = a.forceBrowserDefault,
            d = a.items,
            e = a.loadingIndicator,
            f = a.onScroll,
            g = a.onScrollBottom,
            h = a.onScrollTop,
            k = a.renderItem,
            l = a.role,
            m = a.testid;
        m = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["forceBrowserDefault", "items", "loadingIndicator", "onScroll", "onScrollBottom", "onScrollTop", "renderItem", "role", "testid", "xstyle"]);
        var n = j(c("CometDialogContext")),
            o = j(c("BaseScrollableAreaContext"));
        n == null && o.length > 0 && c("FBLogger")("comet_ui").blameToPreviousFrame().warn("For XPlat React compatibility, BaseInfiniteScrollList should not be nested inside scrollable containers such as BaseScrollableArea with the same orientation. It may cause unexpected behaviors and break infinite scroll in React Native platforms.");
        return i.jsxs(c("CometScrollableArea.react"), {
            forceBrowserDefault: b,
            horizontal: !1,
            onScroll: f,
            onScrollBottom: g,
            onScrollTop: h,
            role: l,
            testid: void 0,
            xstyle: m,
            children: [d.map(k), i.jsx(c("CometInfiniteScrollTrigger.react"), babelHelpers["extends"]({}, a, {
                children: e
            }))]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MDSInfiniteScrollList.react", ["BaseInfiniteScrollList.react", "MDSScrollableAreaStyles", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["xstyle"]);
        return i.jsx(c("BaseInfiniteScrollList.react"), babelHelpers["extends"]({
            forceBrowserDefault: !0,
            xstyle: [c("MDSScrollableAreaStyles").unthemed, b]
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useMWLogLongSuspense", ["MWPBumpEntityKey", "clearTimeout", "react", "setTimeout", "useMergeRefs", "useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useRef;

    function a(a, b) {
        var d = m(a, 5, b),
            e = m(a, 15, b),
            f = m(a, 60, b);
        a = m(a, 300, b);
        return c("useMergeRefs")(d, e, f, a)
    }
    var l = /\W/g;

    function m(a, b, e) {
        var f = a.replace(l, "_"),
            g = k();
        a = i(function() {
            g.current = c("setTimeout")(function() {
                d("MWPBumpEntityKey").bumpEntityKeyWithAppId("mwp", "long_suspension." + f + ".suspended_" + b + "_sec"), e == null ? void 0 : e(b)
            }, b * 1e3)
        }, [e, f, b]);
        var h = i(function() {
            c("clearTimeout")(g.current)
        }, []);
        j(function() {
            return h
        }, [h]);
        return c("useVisibilityObserver")({
            onHidden: h,
            onVisible: a
        })
    }
    g["default"] = a
}), 98);
__d("MWThreadListGlimmer.react", ["CometVisualCompletionAttributes", "MWXGlimmer.react", "gkx", "react", "react-strict-dom", "useMWLogLongSuspense"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            glimmerBody: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                height: "xlup9mm",
                width: "xktia5q",
                $$css: !0
            },
            glimmerHeadline: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                height: "x1qx5ct2",
                marginBottom: "x1e56ztr",
                width: "x3hqpx7",
                $$css: !0
            },
            glimmerPhoto48: {
                borderTopStartRadius: "xzolkzo",
                borderTopEndRadius: "x12go9s9",
                borderBottomEndRadius: "x1rnf11y",
                borderBottomStartRadius: "xprq8jg",
                height: "xsdox4t",
                marginEnd: "xmo9yow",
                width: "x1useyqa",
                $$css: !0
            },
            glimmerPhoto56: {
                borderTopStartRadius: "xzolkzo",
                borderTopEndRadius: "x12go9s9",
                borderBottomEndRadius: "x1rnf11y",
                borderBottomStartRadius: "xprq8jg",
                height: "xnnlda6",
                marginEnd: "xmo9yow",
                width: "x15yg21f",
                $$css: !0
            },
            glimmerRoot: {
                display: "x78zum5",
                paddingBottom: "x1a8lsjc",
                paddingStart: "x1swvt13",
                paddingEnd: "x1pi30zi",
                paddingLeft: null,
                paddingRight: null,
                paddingTop: "x889kno",
                $$css: !0
            },
            glimmerText: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                justifyContent: "xl56j7k",
                $$css: !0
            }
        },
        k = c("gkx")("23219"),
        l = i.forwardRef(function(a, b) {
            var e = a.role;
            a = a.vcIgnore;
            return i.jsxs(d("react-strict-dom").html.div, babelHelpers["extends"]({
                ref: b,
                role: e,
                style: j.glimmerRoot
            }, a === !0 ? c("CometVisualCompletionAttributes").IGNORE : {}, {
                children: [i.jsx(c("MWXGlimmer.react"), {
                    index: 0,
                    xstyle: k ? j.glimmerPhoto48 : j.glimmerPhoto56
                }), i.jsxs(d("react-strict-dom").html.div, {
                    style: j.glimmerText,
                    children: [i.jsx(c("MWXGlimmer.react"), {
                        index: 1,
                        xstyle: j.glimmerHeadline
                    }), i.jsx(c("MWXGlimmer.react"), {
                        index: 2,
                        xstyle: j.glimmerBody
                    })]
                })]
            }))
        });

    function a(a) {
        var b = a.numberOfItems;
        b = b === void 0 ? 1 : b;
        var d = a.parentComponentForDebug,
            e = a.role,
            f = a.vcIgnore,
            g = c("useMWLogLongSuspense")(d + ".MWThreadListGlimmer");
        return i.jsx(i.Fragment, {
            children: Array(b).fill(!0).map(function(a, b) {
                return i.jsx(l, {
                    ref: b === 0 ? g : void 0,
                    role: e,
                    vcIgnore: f
                }, "mw_list_glimmer_" + b)
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWInboxLeftRailContentPlaceholder.react", ["MWThreadListGlimmer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a() {
        return i.jsx(c("MWThreadListGlimmer.react"), {
            numberOfItems: 6,
            parentComponentForDebug: "MWInboxLeftRailContent"
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("JSResource", ["JSResourceReferenceImpl"], (function(a, b, c, d, e, f, g) {
    var h = {};

    function i(a, b) {
        h[a] = b
    }

    function j(a) {
        return h[a]
    }

    function a(a) {
        a = a;
        var b = j(a);
        if (b) return b;
        b = new(c("JSResourceReferenceImpl"))(a);
        i(a, b);
        return b
    }
    a.loadAll = c("JSResourceReferenceImpl").loadAll;
    g["default"] = a
}), 98);
__d("JSResourceForInteraction", ["JSResource"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return c("JSResource").call(null, a)
    }
    b = a;
    g["default"] = b
}), 98);
__d("MWCMChatsFullBannerRootQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5804383839665166"
}), null);
__d("MWCMChatsFullBannerRootQuery$Parameters", ["MWCMChatsFullBannerRootQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWCMChatsFullBannerRootQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWCMChatsFullBannerRootQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6072064999529637"
}), null);
__d("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery$Parameters", ["MWCMInboxLeftRailSidebarBusinessSupportButtonQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWCMInboxLeftRailSidebarBusinessSupportButtonQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWCMThreadListQPBannerContainerQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6673229072767704"
}), null);
__d("MWCMThreadListQPBannerContainerQuery$Parameters", ["MWCMThreadListQPBannerContainerQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWCMThreadListQPBannerContainerQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWCMThreadListQPBannerContainerQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWChatEncryptedBackupsUpsellMessengerInboxQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "26639038685694819"
}), null);
__d("MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters", ["MWChatEncryptedBackupsUpsellMessengerInboxQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWChatEncryptedBackupsUpsellMessengerInboxQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWChatEncryptedBackupsUpsellMessengerInboxQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWChatMediaRootQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6057149221048635"
}), null);
__d("MWEncryptedBackupsThreadListNuxWrapperQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8425379747569466"
}), null);
__d("MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters", ["MWEncryptedBackupsThreadListNuxWrapperQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWEncryptedBackupsThreadListNuxWrapperQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWEncryptedBackupsThreadListNuxWrapperQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWLSInboxQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6909378019106583"
}), null);
__d("MWLSInboxQuery$Parameters", ["MWLSInboxQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWLSInboxQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWLSInboxQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("MWQuickPromotionDesktopInterstitialUpsellQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6587787004613839"
}), null);
__d("MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters", ["MWQuickPromotionDesktopInterstitialUpsellQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("MWQuickPromotionDesktopInterstitialUpsellQuery_facebookRelayOperation"),
            metadata: {},
            name: "MWQuickPromotionDesktopInterstitialUpsellQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("createGenericCompoundEntryPointBuilder", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return function(c) {
            return {
                getPreloadProps: function(a) {
                    return {
                        entryPoints: c(a),
                        extraProps: null,
                        queries: b(a)
                    }
                },
                root: a
            }
        }
    }
    f["default"] = a
}), 66);
__d("createContentAreaCompoundEntryPointBuilder", ["createGenericCompoundEntryPointBuilder"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var d = c("createGenericCompoundEntryPointBuilder")(a, b);
        return function(a, b) {
            var c = {
                getPreloadProps: b,
                root: a
            };
            return d(function(a) {
                return {
                    contentEntryPoint: {
                        entryPoint: c,
                        entryPointParams: a
                    }
                }
            })
        }
    }
    g["default"] = a
}), 98);
__d("buildMWInboxRoot.entrypoint", ["JSResourceForInteraction", "MWCMInboxLeftRailSidebarBusinessSupportButtonQuery$Parameters", "MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters", "MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters", "MWLSInboxQuery$Parameters", "MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters", "createContentAreaCompoundEntryPointBuilder", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("gkx")("33119"),
        i = c("gkx")("1625"),
        j = i || h,
        k = c("gkx")("3730");
    a = c("createContentAreaCompoundEntryPointBuilder")(c("JSResourceForInteraction")("MWInboxRoot.react").__setRef("buildMWInboxRoot.entrypoint"), function(a) {
        a = {};
        j && (a.mWChatEncryptedBackupsRestoreUpsellMessengerInboxQueryReference = {
            parameters: b("MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters"),
            variables: {
                doesUserHaveAnEB: i,
                isEBWebOnlyOnboardingEnabled: h
            }
        });
        a.mWEncryptedBackupsThreadListNuxWrapper = {
            parameters: b("MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters"),
            variables: {
                qpWithPinEnabled: k
            }
        };
        !c("gkx")("2669") && c("gkx")("1002") && (a.mWQuickPromotionDesktopInterstitialUpsell = {
            parameters: b("MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters"),
            variables: {}
        }, a.mCMInboxLeftRailSidebarBusinessSupportButtonQueryRef = {
            parameters: b("MWCMInboxLeftRailSidebarBusinessSupportButtonQuery$Parameters"),
            variables: {}
        });
        return a
    });
    d = c("createContentAreaCompoundEntryPointBuilder")(c("JSResourceForInteraction")("MWLSInbox.react").__setRef("buildMWInboxRoot.entrypoint"), function(a) {
        a = {
            mWLSInboxQueryReference: {
                parameters: b("MWLSInboxQuery$Parameters"),
                variables: {}
            }
        };
        j && (a.mWChatEncryptedBackupsRestoreUpsellMessengerInboxQueryReference = {
            parameters: b("MWChatEncryptedBackupsUpsellMessengerInboxQuery$Parameters"),
            variables: {
                doesUserHaveAnEB: i,
                isEBWebOnlyOnboardingEnabled: h
            }
        });
        a.mWEncryptedBackupsThreadListNuxWrapper = {
            parameters: b("MWEncryptedBackupsThreadListNuxWrapperQuery$Parameters"),
            variables: {
                qpWithPinEnabled: k
            }
        };
        !c("gkx")("2669") && c("gkx")("1002") && (a.mWQuickPromotionDesktopInterstitialUpsell = {
            parameters: b("MWQuickPromotionDesktopInterstitialUpsellQuery$Parameters"),
            variables: {}
        });
        return a
    });
    e = c("gkx")("23433") ? a : d;
    f = e;
    g["default"] = f
}), 98);
__d("MWInboxArchivedThreadsRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxArchivedThreadsRoot.react").__setRef("MWInboxArchivedThreadsRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("MWInboxCommunityThreadsRoot.entrypoint", ["JSResourceForInteraction", "MWCMChatsFullBannerRootQuery$Parameters", "MWCMThreadListQPBannerContainerQuery$Parameters", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxCommunityThreadsRoot.react").__setRef("MWInboxCommunityThreadsRoot.entrypoint"), function(a) {
        a = a.routeProps;
        return {
            queries: {
                qpBannerContainerQueryRef: {
                    parameters: c("MWCMThreadListQPBannerContainerQuery$Parameters"),
                    variables: {
                        fb_group_id: a.fb_group_id
                    }
                },
                queryReference: {
                    parameters: b("MWCMChatsFullBannerRootQuery$Parameters"),
                    variables: {
                        folderID: a.folder_id
                    }
                }
            }
        }
    });
    g["default"] = a
}), 98);
__d("MWInboxHomeRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxHomeRoot.react").__setRef("MWInboxHomeRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("MWInboxMarketplaceThreadsRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxMarketplaceThreadsRoot.react").__setRef("MWInboxMarketplaceThreadsRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("MWInboxMessageRequestsRoot.entrypoint", ["JSResourceForInteraction", "buildMWInboxRoot.entrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("buildMWInboxRoot.entrypoint")(c("JSResourceForInteraction")("MWInboxMessageRequestsRoot.react").__setRef("MWInboxMessageRequestsRoot.entrypoint"), function(a) {
        return {}
    });
    g["default"] = a
}), 98);
__d("ServerJsRuntimeEnvironment", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;

    function a(a, b) {
        i == null || h(0, 71696), i = {
            platform: a,
            executionContext: b
        }
    }

    function b() {
        return i != null
    }

    function c() {
        var a;
        return (a = i) == null ? void 0 : a.executionContext
    }

    function d() {
        var a;
        return (a = i) == null ? void 0 : a.platform
    }
    g.init = a;
    g.isRunningServerJsRuntime = b;
    g.getExecutionContext = c;
    g.getPlatform = d
}), 98);
__d("WAGetSafeQPLError", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a == null) return "<null>";
        return a instanceof Error || typeof a === "string" ? a.toString() : "<unknown>"
    }
    f.getSafeQPLErrorMessage = a
}), 66);
__d("WebPixelRatio", ["SiteData"], (function(a, b, c, d, e, f, g) {
    function a() {
        return c("SiteData").pr != null && c("SiteData").pr > 0 ? c("SiteData").pr : window.devicePixelRatio || 1
    }
    g.get = a
}), 98); /*FB_PKG_DELIM*/
__d("react-relay/relay-hooks/preloadQuery_DEPRECATED", ["relay-runtime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = (c = b("relay-runtime")).Observable,
        h = c.PreloadableQueryRegistry,
        i = c.ReplaySubject,
        j = c.createOperationDescriptor,
        k = c.getRequest,
        l = c.getRequestIdentifier,
        m = 30 * 1e3;
    d = typeof WeakMap === "function";
    var n = "store-or-network",
        o = d ? new WeakMap() : new Map();

    function a(a, b, c, d, e) {
        var f = o.get(a);
        f == null && (f = new Map(), o.set(a, f));
        var h = f,
            i = p(a, h, b, c, d);
        f = i.kind === "network" ? g.create(function(e) {
            var f;
            if (h.get(i.cacheKey) == null) {
                var g = p(a, h, b, c, d);
                g.kind === "network" && (f = g.subject.subscribe(e))
            } else f = i.subject.subscribe(e);
            return function() {
                var b;
                (b = f) == null ? void 0 : b.unsubscribe();
                if (a.isServer()) return;
                setTimeout(function() {
                    i != null && q(h, i)
                }, m)
            }
        }) : null;
        return {
            kind: "PreloadedQuery_DEPRECATED",
            environment: a,
            environmentProviderOptions: e,
            fetchKey: i.fetchKey,
            fetchPolicy: i.fetchPolicy,
            networkCacheConfig: d == null ? void 0 : d.networkCacheConfig,
            id: i.id,
            name: i.name,
            source: f,
            variables: c,
            status: i.status
        }
    }

    function p(a, b, c, d, e) {
        var f, g;
        if (c.kind === "PreloadableConcreteRequest") {
            var o = c;
            o = o.params;
            g = o.id != null ? h.get(o.id) : null
        } else g = k(c), o = g.params;
        c = a.getNetwork();
        f = (f = e == null ? void 0 : e.fetchPolicy) != null ? f : n;
        var p = e == null ? void 0 : e.fetchKey;
        e = babelHelpers["extends"]({
            force: !0
        }, e == null ? void 0 : e.networkCacheConfig);
        var r = "" + l(o, d) + (p != null ? "-" + p : ""),
            s = b.get(r),
            t = f === n && g != null && g != null ? a.check(j(g, d, e)) : {
                status: "missing"
            },
            u;
        if (t.status === "available" && g != null) {
            u = s && s.kind === "cache" ? s : {
                cacheKey: r,
                fetchKey: p,
                fetchPolicy: f,
                kind: "cache",
                id: o.id,
                name: o.name,
                status: {
                    cacheConfig: e,
                    source: "cache",
                    fetchTime: (g = t == null ? void 0 : t.fetchTime) != null ? g : null
                }
            };
            !a.isServer() && s == null && setTimeout(function() {
                u != null && q(b, u)
            }, m)
        } else if (s == null || s.kind !== "network") {
            t = c.execute(o, d, e, null);
            var v = new i();
            u = {
                cacheKey: r,
                fetchKey: p,
                fetchPolicy: f,
                kind: "network",
                id: o.id,
                name: o.name,
                status: {
                    cacheConfig: e,
                    source: "network",
                    fetchTime: null
                },
                subject: v,
                subscription: t["finally"](function() {
                    if (a.isServer()) return;
                    setTimeout(function() {
                        u != null && q(b, u)
                    }, m)
                }).subscribe({
                    complete: function() {
                        v.complete()
                    },
                    error: function(a) {
                        v.error(a)
                    },
                    next: function(a) {
                        v.next(a)
                    }
                })
            }
        } else u = s;
        b.set(r, u);
        return u
    }

    function q(a, b) {
        var c = a.get(b.cacheKey);
        c != null && c === b && (c.kind === "network" && c.subscription.unsubscribe(), a["delete"](c.cacheKey))
    }
    e.exports = a
}), null);
__d("react-relay/relay-hooks/prepareEntryPoint_DEPRECATED", ["react-relay/relay-hooks/preloadQuery_DEPRECATED"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, c, d) {
        c.root.getModuleIfRequired() == null && c.root.load();
        c = c.getPreloadProps(d);
        var e = c.queries,
            f = c.entryPoints,
            h = {},
            i = {};
        if (e != null) {
            d = Object.keys(e);
            d.forEach(function(c) {
                var d = e[c],
                    f = d.environmentProviderOptions,
                    g = d.options,
                    i = d.parameters;
                d = d.variables;
                var j = a.getEnvironment(f);
                h[c] = b("react-relay/relay-hooks/preloadQuery_DEPRECATED")(j, i, d, g, f)
            })
        }
        if (f != null) {
            c = Object.keys(f);
            c.forEach(function(b) {
                var c = f[b];
                if (c == null) return;
                var d = c.entryPoint;
                c = c.entryPointParams;
                i[b] = g(a, d, c)
            })
        }
    }
    e.exports = g
}), null);
__d("RelayHooks", ["RelayFBEnvironmentActorID", "configureRelayForWWW", "react-relay/relay-hooks/EntryPointContainer.react", "react-relay/relay-hooks/RelayEnvironmentProvider", "react-relay/relay-hooks/loadEntryPoint", "react-relay/relay-hooks/loadQuery", "react-relay/relay-hooks/preloadQuery_DEPRECATED", "react-relay/relay-hooks/prepareEntryPoint_DEPRECATED", "react-relay/relay-hooks/useClientQuery", "react-relay/relay-hooks/useEntryPointLoader", "react-relay/relay-hooks/useFragment", "react-relay/relay-hooks/useLazyLoadQuery", "react-relay/relay-hooks/usePaginationFragment", "react-relay/relay-hooks/usePreloadedQuery", "react-relay/relay-hooks/useQueryLoader", "react-relay/relay-hooks/useRefetchableFragment", "react-relay/relay-hooks/useRelayEnvironment", "react-relay/relay-hooks/useSubscribeToInvalidationState", "relay-runtime", "relay-runtime/query/PreloadableQueryRegistry", "useFBMutation", "useFBSubscription"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("RelayFBEnvironmentActorID").useActorID;
    c = b("react-relay/relay-hooks/loadQuery").loadQuery;
    d = b("relay-runtime").fetchQuery;
    f = b("relay-runtime").graphql;
    var g = b("relay-runtime").readInlineData;
    b("configureRelayForWWW")();
    e.exports = {
        EntryPointContainer: b("react-relay/relay-hooks/EntryPointContainer.react"),
        PreloadableQueryRegistry: b("relay-runtime/query/PreloadableQueryRegistry"),
        RelayEnvironmentProvider: b("react-relay/relay-hooks/RelayEnvironmentProvider"),
        fetchQuery: d,
        graphql: f,
        loadQuery: c,
        loadEntryPoint: b("react-relay/relay-hooks/loadEntryPoint"),
        preloadQuery_DEPRECATED: b("react-relay/relay-hooks/preloadQuery_DEPRECATED"),
        prepareEntryPoint_DEPRECATED: b("react-relay/relay-hooks/prepareEntryPoint_DEPRECATED"),
        readInlineData: g,
        useActorID: a,
        useClientQuery: b("react-relay/relay-hooks/useClientQuery"),
        useFragment: b("react-relay/relay-hooks/useFragment"),
        useLazyLoadQuery: b("react-relay/relay-hooks/useLazyLoadQuery"),
        useEntryPointLoader: b("react-relay/relay-hooks/useEntryPointLoader"),
        useQueryLoader: b("react-relay/relay-hooks/useQueryLoader"),
        usePaginationFragment: b("react-relay/relay-hooks/usePaginationFragment"),
        useMutation: b("useFBMutation"),
        usePreloadedQuery: b("react-relay/relay-hooks/usePreloadedQuery"),
        useRefetchableFragment: b("react-relay/relay-hooks/useRefetchableFragment"),
        useRelayEnvironment: b("react-relay/relay-hooks/useRelayEnvironment"),
        useSubscribeToInvalidationState: b("react-relay/relay-hooks/useSubscribeToInvalidationState"),
        useSubscription: b("useFBSubscription")
    }
}), null); /*FB_PKG_DELIM*/
__d("CometHeadlineWithAddOn.react", ["BaseRow.react", "BaseRowItem.react", "FDSText.react", "Locale", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            addOn: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                justifyContent: "xl56j7k",
                marginStart: "x1i64zmx",
                $$css: !0
            },
            nonBreakingSpace: {
                visibility: "xlshs6z",
                width: "xnalus7",
                $$css: !0
            }
        },
        k = {
            ltr: {
                direction: "xzt5al7",
                $$css: !0
            },
            rtl: {
                direction: "xzyj77d",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        var e = a.headlineRef;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["headlineRef"]);
        var f = a.addOn,
            g = a.children,
            h = a.color,
            l = a.id,
            m = a.isPrimaryHeading,
            n = a.isSemanticHeading,
            o = a.numberOfLines,
            p = a.truncationTooltip;
        a = a.type;
        return i.jsx(c("FDSText.react"), {
            isSemanticHeading: !1,
            ref: b,
            type: a,
            children: i.jsxs(c("BaseRow.react"), {
                verticalAlign: "center",
                xstyle: k[d("Locale").isRTL() ? "rtl" : "ltr"],
                children: [i.jsx(c("BaseRowItem.react"), {
                    expanding: !0,
                    children: i.jsx(c("FDSText.react"), {
                        color: h,
                        id: l,
                        isPrimaryHeading: m,
                        isSemanticHeading: n,
                        numberOfLines: o,
                        ref: e,
                        truncationTooltip: p,
                        type: a,
                        children: g
                    })
                }), i.jsx(c("BaseRowItem.react"), {
                    verticalAlign: "top",
                    xstyle: j.addOn,
                    children: i.jsxs(c("BaseRow.react"), {
                        verticalAlign: "center",
                        children: [i.jsx(c("BaseRowItem.react"), {
                            xstyle: j.nonBreakingSpace,
                            children: "\xa0"
                        }), i.jsx(c("BaseRowItem.react"), {
                            children: i.jsx(c("BaseRow.react"), {
                                children: f
                            })
                        })]
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("getFDSTextHierarchyStyle", ["memoizeWithArgs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("memoizeWithArgs")(function(a, b) {
        switch (a) {
            case 1:
                return {
                    bodyType: "body1",
                    headlineType: "headlineEmphasized1",
                    metaType: "meta1"
                };
            case 2:
                return {
                    bodyType: "body2",
                    headlineType: "headlineEmphasized2",
                    metaType: "meta2"
                };
            case 3:
                return {
                    bodyType: "body3",
                    headlineType: b === !0 ? "headline3" : "headlineEmphasized3",
                    metaType: "meta3"
                };
            default:
            case 4:
                return {
                    bodyType: "body4",
                    headlineType: b === !0 ? "headline4" : "headlineEmphasized4",
                    metaType: "meta4"
                };
            case "entityHeader1":
                return {
                    bodyType: "body2",
                    headlineType: "entityHeaderHeadline1",
                    metaType: "entityHeaderMeta1"
                };
            case "entityHeader2":
                return {
                    bodyType: "body2",
                    headlineType: "entityHeaderHeadline2",
                    metaType: "entityHeaderMeta2"
                }
        }
    }, function(a, b) {
        return String(a) + (b === !0 ? "" : "e")
    });
    g["default"] = a
}), 98);
__d("FDSTextPairing.react", ["CometHeadlineWithAddOn.react", "FDSText.react", "getFDSTextHierarchyStyle", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            item: {
                marginBottom: "xu06os2",
                marginTop: "x1ok221b",
                $$css: !0
            },
            root: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                marginBottom: "xz62fqu",
                marginTop: "x16ldp7u",
                $$css: !0
            }
        },
        l = {
            1: {
                marginBottom: "x11tup63",
                marginTop: "x16z1lm9",
                $$css: !0
            },
            2: {
                marginBottom: "x4cne27",
                marginTop: "xifccgj",
                $$css: !0
            },
            3: {
                $$css: !0
            },
            4: {
                $$css: !0
            },
            entityHeader1: {
                marginBottom: "x1wsgfga",
                marginTop: "x9otpla",
                $$css: !0
            },
            entityHeader2: {
                marginBottom: "x1wsgfga",
                marginTop: "x9otpla",
                $$css: !0
            }
        },
        m = {
            1: {
                marginBottom: "xwoyzhm",
                marginTop: "x1rhet7l",
                $$css: !0
            },
            2: {
                marginBottom: "xzueoph",
                marginTop: "x1k70j0n",
                $$css: !0
            },
            3: {
                $$css: !0
            },
            4: {
                $$css: !0
            },
            entityHeader1: {
                marginBottom: "x1e56ztr",
                marginTop: "x1xmf6yo",
                $$css: !0
            },
            entityHeader2: {
                marginBottom: "x1e56ztr",
                marginTop: "x1xmf6yo",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.body,
            d = a.bodyColor;
        d = d === void 0 ? "primary" : d;
        var e = a.bodyId,
            f = a.bodyLineLimit,
            g = a.bodyRef,
            i = a.bodyTruncationTooltip,
            n = a.dir;
        n = n === void 0 ? "auto" : n;
        var o = a.headline,
            p = a.headlineAddOn,
            q = a.headlineColor;
        q = q === void 0 ? "primary" : q;
        var r = a.headlineId,
            s = a.headlineLineLimit,
            t = a.headlineRef,
            u = a.headlineTruncationTooltip,
            v = a.isPrimaryHeading,
            w = a.isSemanticHeading,
            x = a.level,
            y = a.meta,
            z = a.metaColor;
        z = z === void 0 ? "secondary" : z;
        var A = a.metaId,
            B = a.metaLineLimit,
            C = a.metaLocation;
        C = C === void 0 ? "below" : C;
        var D = a.metaRef,
            E = a.metaTestID;
        E = a.metaTruncationTooltip;
        var F = a.reduceEmphasis;
        F = F === void 0 ? !1 : F;
        var G = a.testid;
        G = a.textAlign;
        a = G === void 0 ? "start" : G;
        G = c("getFDSTextHierarchyStyle")(x, F);
        F = G.bodyType;
        var H = G.headlineType;
        G = G.metaType;
        var I = (h || (h = c("stylex")))(k.item, m[x]);
        p = o != null && j.jsx("div", {
            className: I,
            children: p != null ? j.jsx(c("CometHeadlineWithAddOn.react"), {
                addOn: p,
                color: q,
                headlineRef: t,
                id: r,
                isPrimaryHeading: v,
                isSemanticHeading: w,
                numberOfLines: s,
                truncationTooltip: u,
                type: H,
                children: o
            }) : j.jsx(c("FDSText.react"), {
                align: a,
                color: q,
                dir: n,
                id: r,
                isPrimaryHeading: v,
                isSemanticHeading: w,
                numberOfLines: s,
                ref: t,
                truncationTooltip: u,
                type: H,
                children: o
            })
        });
        q = y != null && j.jsx("div", {
            className: I,
            children: j.jsx(c("FDSText.react"), {
                align: a,
                color: z,
                dir: n,
                id: A,
                isSemanticHeading: !1,
                numberOfLines: B,
                ref: D,
                testid: void 0,
                truncationTooltip: E,
                type: G,
                children: y
            })
        });
        return j.jsxs("div", {
            className: h(k.root, l[x]),
            "data-testid": void 0,
            children: [C === "above" && q, p, b != null && j.jsx("div", {
                className: I,
                children: j.jsx(c("FDSText.react"), {
                    align: a,
                    color: d,
                    dir: n,
                    id: e,
                    isSemanticHeading: !1,
                    numberOfLines: f,
                    ref: g,
                    truncationTooltip: i,
                    type: F,
                    children: b
                })
            }), C === "below" && q]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LSClearLoadingFlagsForThreadRange", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return a[1] ? b.forEach(b.db.table(10).fetch([
                [
                    [a[0]]
                ]
            ]), function(a) {
                var b = a.update;
                a.item;
                return b({
                    isLoadingAfter: !1
                })
            }) : b.sequence([function(d) {
                return b.i64.eq(b.i64.cast([0, 0]), a[0]) ? b.sequence([function(c) {
                    return b.forEach(b.db.table(198).fetch([
                        [
                            [a[2]]
                        ]
                    ]), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            isLoadingBefore: !1
                        })
                    })
                }, function(a) {
                    return c[8] = b.i64.cast([0, 0]), c[9] = void 0, c[10] = !1, c[11] = !1, b.forEach(b.db.table(198).fetch(), function(a) {
                        a = a.item;
                        return c[12] = a.minLastActivityTimestampMs, c[14] = a.minThreadKey, c[13] = b.i64.lt(c[8] == null ? c[12] : c[8], c[12]), c[8] = c[13] ? c[12] : c[8], c[9] = c[13] ? c[14] : c[9], c[10] = c[10] || a.isLoadingBefore, c[11] = c[11] || b.i64.gt(c[12], b.i64.cast([0, 1])) && b.i64.gt(c[14], b.i64.cast([-2147483648, 0]))
                    })
                }, function(a) {
                    return a = [c[8], c[9], c[10], c[11]], c[0] = a[0], c[1] = a[1], c[2] = a[2], c[3] = a[3], a
                }]) : b.resolve((d = [b.i64.cast([0, 0]), void 0, !1, !1], c[0] = d[0], c[1] = d[1], c[2] = d[2], c[3] = d[3], d))
            }, function(c) {
                return b.forEach(b.db.table(220).fetch([
                    [
                        [a[2], a[0]]
                    ]
                ]), function(a) {
                    var b = a.update;
                    a.item;
                    return b({
                        isLoadingBefore: !1
                    })
                })
            }, function(d) {
                return c[4] = c[0], c[5] = c[1], c[6] = c[2], c[7] = c[3], b.forEach(b.filter(b.db.table(220).fetch(), function(c) {
                    return b.i64.eq(c.parentThreadKey, a[0])
                }), function(a) {
                    a = a.item;
                    return c[8] = a.minLastActivityTimestampMs, c[10] = a.minThreadKey, c[9] = b.i64.lt(c[4] == null ? c[8] : c[4], c[8]), c[4] = c[9] ? c[8] : c[4], c[5] = c[9] ? c[10] : c[5], c[6] = c[6] || a.isLoadingBefore, c[7] = c[7] || b.i64.gt(c[8], b.i64.cast([0, 1])) && b.i64.gt(c[10], b.i64.cast([-2147483648, 0]))
                })
            }, function(d) {
                return b.forEach(b.db.table(10).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(a) {
                    var b = a.update;
                    a.item;
                    return b({
                        isLoadingBefore: c[6]
                    })
                })
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxClearLoadingFlagsForThreadRangeStoredProcedure";
    e.exports = a
}), null);
__d("LSThreadsRangesQuery", ["LSClearLoadingFlagsForThreadRange", "LSGetCursor", "LSIssueNewTaskAndGetTaskID", "LSUpsertInboxThreadsRange", "LSUpsertSyncGroupThreadsRange"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return a[1] && c.i64.eq(a[6], c.i64.cast([0, 0])) ? c.storedProcedure(b("LSClearLoadingFlagsForThreadRange"), a[0], !1, c.i64.cast([0, 1])) : (a[1] && c.i64.neq(a[6], void 0) && c.i64.neq(a[3], void 0) || a[2] && c.i64.neq(a[5], void 0) && c.i64.neq(a[4], void 0)) && !(a[1] && c.i64.neq(a[6], void 0) && c.i64.neq(a[3], void 0) && a[2] && c.i64.neq(a[5], void 0) && c.i64.neq(a[4], void 0)) ? c.sequence([function(e) {
                    return d[16] = a[3] == null ? c.i64.cast([-2147483648, 0]) : a[3], d[15] = a[6] == null ? c.i64.cast([0, 1]) : a[6], d[17] = c.i64.gt(d[15], c.i64.cast([0, 1])) && c.i64.gt(d[16], c.i64.cast([-2147483648, 0])), d[4] = c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 1])) || c.i64.eq(c.i64.cast([0, 1]), c.i64.cast([0, 95])), d[4] && c.i64.eq(a[0], c.i64.cast([0, 0])) ? c.sequence([function(a) {
                        return c.storedProcedure(b("LSUpsertInboxThreadsRange"), c.i64.cast([0, 1]), d[15], d[17], !0, d[16])
                    }, function(a) {
                        return d[18] = d[15], d[19] = d[16], d[20] = !0, d[21] = d[17], c.forEach(c.db.table(198).fetch(), function(a) {
                            a = a.item;
                            return d[22] = a.minLastActivityTimestampMs, d[24] = a.minThreadKey, d[23] = c.i64.lt(d[18] == null ? d[22] : d[18], d[22]), d[18] = d[23] ? d[22] : d[18], d[19] = d[23] ? d[24] : d[19], d[20] = d[20] || a.isLoadingBefore, d[21] = d[21] || c.i64.gt(d[22], c.i64.cast([0, 1])) && c.i64.gt(d[24], c.i64.cast([-2147483648, 0]))
                        })
                    }, function(a) {
                        return a = [d[18], d[19], d[20], d[21]], d[0] = a[0], d[1] = a[1], d[2] = a[2], d[3] = a[3], a
                    }]) : c.resolve((e = [d[15], d[16], !0, d[17]], d[0] = e[0], d[1] = e[1], d[2] = e[2], d[3] = e[3], e))
                }, function(e) {
                    return d[4] ? c.sequence([function(e) {
                        return c.storedProcedure(b("LSUpsertSyncGroupThreadsRange"), c.i64.cast([0, 1]), a[0], d[15], d[17], !0, d[16])
                    }, function(b) {
                        return d[18] = d[15], d[19] = d[16], d[20] = !0, d[21] = d[17], c.forEach(c.filter(c.db.table(220).fetch(), function(b) {
                            return c.i64.eq(b.parentThreadKey, a[0])
                        }), function(a) {
                            a = a.item;
                            return d[22] = a.minLastActivityTimestampMs, d[24] = a.minThreadKey, d[23] = c.i64.lt(d[18] == null ? d[22] : d[18], d[22]), d[18] = d[23] ? d[22] : d[18], d[19] = d[23] ? d[24] : d[19], d[20] = d[20] || a.isLoadingBefore, d[21] = d[21] || c.i64.gt(d[22], c.i64.cast([0, 1])) && c.i64.gt(d[24], c.i64.cast([-2147483648, 0]))
                        })
                    }, function(a) {
                        return a = [d[18], d[19], d[20], d[21]], d[5] = a[0], d[6] = a[1], d[7] = a[2], d[8] = a[3], a
                    }]) : c.resolve((e = [d[0], d[1], d[2], d[3]], d[5] = e[0], d[6] = e[1], d[7] = e[2], d[8] = e[3], e))
                }, function(a) {
                    return c.storedProcedure(b("LSGetCursor"), c.i64.cast([0, 1])).then(function(a) {
                        return a = a, d[9] = a[0], a
                    })
                }, function(e) {
                    return d[10] = new c.Map(), d[10].set("is_after", a[2]), d[10].set("parent_thread_key", a[0]), d[10].set("reference_thread_key", a[2] ? a[4] : a[3]), d[10].set("reference_activity_timestamp", a[2] ? a[5] : a[6]), d[10].set("additional_pages_to_fetch", a[7]), d[10].set("cursor", d[9]), d[10].set("messaging_tag", void 0), d[10].set("sync_group", c.i64.cast([0, 1])), c.i64.gt(c.i64.cast([0, 0]), c.i64.cast([0, 0])) ? (d[18] = c.i64.of_float(Date.now()), d[11] = c.i64.add(d[18], c.i64.cast([0, 0]))) : d[11] = c.i64.cast([0, 0]), d[12] = c.toJSON(d[10]), c.storedProcedure(b("LSIssueNewTaskAndGetTaskID"), "trq", c.i64.cast([0, 145]), d[12], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, d[11], c.i64.cast([0, 0])).then(function(a) {
                        return a = a, d[13] = a[0], a
                    })
                }, function(b) {
                    return c.db.table(10).fetch([
                        [
                            [a[0]]
                        ]
                    ]).next().then(function(b, e) {
                        e = b.done;
                        b = b.value;
                        return e ? c.db.table(10).add({
                            parentThreadKey: a[0],
                            minThreadKey: d[6] == null ? c.i64.cast([-2147483648, 0]) : d[6],
                            minLastActivityTimestampMs: d[5] == null ? c.i64.cast([0, 1]) : d[5],
                            maxLastActivityTimestampMs: c.i64.cast([0, 1]),
                            maxThreadKey: c.i64.cast([-2147483648, 0]),
                            isLoadingBefore: d[7],
                            isLoadingAfter: !1,
                            hasMoreBefore: d[8],
                            hasMoreAfter: !1
                        }) : (b.item, c.forEach(c.db.table(10).fetch([
                            [
                                [a[0]]
                            ]
                        ]), function(a) {
                            var b = a.update;
                            a.item;
                            return b({
                                isLoadingBefore: d[7],
                                isLoadingAfter: !1,
                                hasMoreBefore: d[8],
                                hasMoreAfter: !1
                            })
                        }))
                    })
                }]) : c.resolve()
            }, function(e) {
                return a[1] && c.i64.eq(a[6], c.i64.cast([0, 0])) ? c.storedProcedure(b("LSClearLoadingFlagsForThreadRange"), a[0], !1, c.i64.cast([0, 95])) : (a[1] && c.i64.neq(a[6], void 0) && c.i64.neq(a[3], void 0) || a[2] && c.i64.neq(a[5], void 0) && c.i64.neq(a[4], void 0)) && !(a[1] && c.i64.neq(a[6], void 0) && c.i64.neq(a[3], void 0) && a[2] && c.i64.neq(a[5], void 0) && c.i64.neq(a[4], void 0)) ? c.sequence([function(e) {
                    return d[16] = a[3] == null ? c.i64.cast([-2147483648, 0]) : a[3], d[15] = a[6] == null ? c.i64.cast([0, 1]) : a[6], d[17] = c.i64.gt(d[15], c.i64.cast([0, 1])) && c.i64.gt(d[16], c.i64.cast([-2147483648, 0])), d[4] = c.i64.eq(c.i64.cast([0, 95]), c.i64.cast([0, 1])) || c.i64.eq(c.i64.cast([0, 95]), c.i64.cast([0, 95])), d[4] && c.i64.eq(a[0], c.i64.cast([0, 0])) ? c.sequence([function(a) {
                        return c.storedProcedure(b("LSUpsertInboxThreadsRange"), c.i64.cast([0, 95]), d[15], d[17], !0, d[16])
                    }, function(a) {
                        return d[18] = d[15], d[19] = d[16], d[20] = !0, d[21] = d[17], c.forEach(c.db.table(198).fetch(), function(a) {
                            a = a.item;
                            return d[22] = a.minLastActivityTimestampMs, d[24] = a.minThreadKey, d[23] = c.i64.lt(d[18] == null ? d[22] : d[18], d[22]), d[18] = d[23] ? d[22] : d[18], d[19] = d[23] ? d[24] : d[19], d[20] = d[20] || a.isLoadingBefore, d[21] = d[21] || c.i64.gt(d[22], c.i64.cast([0, 1])) && c.i64.gt(d[24], c.i64.cast([-2147483648, 0]))
                        })
                    }, function(a) {
                        return a = [d[18], d[19], d[20], d[21]], d[0] = a[0], d[1] = a[1], d[2] = a[2], d[3] = a[3], a
                    }]) : c.resolve((e = [d[15], d[16], !0, d[17]], d[0] = e[0], d[1] = e[1], d[2] = e[2], d[3] = e[3], e))
                }, function(e) {
                    return d[4] ? c.sequence([function(e) {
                        return c.storedProcedure(b("LSUpsertSyncGroupThreadsRange"), c.i64.cast([0, 95]), a[0], d[15], d[17], !0, d[16])
                    }, function(b) {
                        return d[18] = d[15], d[19] = d[16], d[20] = !0, d[21] = d[17], c.forEach(c.filter(c.db.table(220).fetch(), function(b) {
                            return c.i64.eq(b.parentThreadKey, a[0])
                        }), function(a) {
                            a = a.item;
                            return d[22] = a.minLastActivityTimestampMs, d[24] = a.minThreadKey, d[23] = c.i64.lt(d[18] == null ? d[22] : d[18], d[22]), d[18] = d[23] ? d[22] : d[18], d[19] = d[23] ? d[24] : d[19], d[20] = d[20] || a.isLoadingBefore, d[21] = d[21] || c.i64.gt(d[22], c.i64.cast([0, 1])) && c.i64.gt(d[24], c.i64.cast([-2147483648, 0]))
                        })
                    }, function(a) {
                        return a = [d[18], d[19], d[20], d[21]], d[5] = a[0], d[6] = a[1], d[7] = a[2], d[8] = a[3], a
                    }]) : c.resolve((e = [d[0], d[1], d[2], d[3]], d[5] = e[0], d[6] = e[1], d[7] = e[2], d[8] = e[3], e))
                }, function(a) {
                    return c.storedProcedure(b("LSGetCursor"), c.i64.cast([0, 95])).then(function(a) {
                        return a = a, d[9] = a[0], a
                    })
                }, function(e) {
                    return d[10] = new c.Map(), d[10].set("is_after", a[2]), d[10].set("parent_thread_key", a[0]), d[10].set("reference_thread_key", a[2] ? a[4] : a[3]), d[10].set("reference_activity_timestamp", a[2] ? a[5] : a[6]), d[10].set("additional_pages_to_fetch", a[7]), d[10].set("cursor", d[9]), d[10].set("messaging_tag", void 0), d[10].set("sync_group", c.i64.cast([0, 95])), c.i64.gt(c.i64.cast([0, 0]), c.i64.cast([0, 0])) ? (d[18] = c.i64.of_float(Date.now()), d[11] = c.i64.add(d[18], c.i64.cast([0, 0]))) : d[11] = c.i64.cast([0, 0]), d[12] = c.toJSON(d[10]), c.storedProcedure(b("LSIssueNewTaskAndGetTaskID"), "trq", c.i64.cast([0, 145]), d[12], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, d[11], c.i64.cast([0, 0])).then(function(a) {
                        return a = a, d[13] = a[0], a
                    })
                }, function(b) {
                    return c.db.table(10).fetch([
                        [
                            [a[0]]
                        ]
                    ]).next().then(function(b, e) {
                        e = b.done;
                        b = b.value;
                        return e ? c.db.table(10).add({
                            parentThreadKey: a[0],
                            minThreadKey: d[6] == null ? c.i64.cast([-2147483648, 0]) : d[6],
                            minLastActivityTimestampMs: d[5] == null ? c.i64.cast([0, 1]) : d[5],
                            maxLastActivityTimestampMs: c.i64.cast([0, 1]),
                            maxThreadKey: c.i64.cast([-2147483648, 0]),
                            isLoadingBefore: d[7],
                            isLoadingAfter: !1,
                            hasMoreBefore: d[8],
                            hasMoreAfter: !1
                        }) : (b.item, c.forEach(c.db.table(10).fetch([
                            [
                                [a[0]]
                            ]
                        ]), function(a) {
                            var b = a.update;
                            a.item;
                            return b({
                                isLoadingBefore: d[7],
                                isLoadingAfter: !1,
                                hasMoreBefore: d[8],
                                hasMoreAfter: !1
                            })
                        }))
                    })
                }]) : c.resolve()
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxThreadsRangesQueryStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("XPlatReactNestedPressableContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("useCometPressableEventHandlers", ["ExecutionEnvironment", "XPlatReactNestedPressableContext", "emptyObject", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react"));
    b = i;
    var k = b.useCallback,
        l = b.useContext,
        m = b.useEffect,
        n = b.useLayoutEffect,
        o = b.useRef,
        p = b.useState,
        q = new Set();
    (h || (h = c("ExecutionEnvironment"))).canUseDOM && document.addEventListener("mousedown", function() {
        q.forEach(function(a) {
            return a()
        })
    }, !0);
    var r = function(a) {
            q.add(a);
            return function() {
                q["delete"](a)
            }
        },
        s = new Set();
    (h || (h = c("ExecutionEnvironment"))).canUseDOM && document.addEventListener("keydown", function(a) {
        switch (a.key) {
            case "ArrowUp":
            case "ArrowRight":
            case "ArrowDown":
            case "ArrowLeft":
            case "Tab":
            case "Enter":
            case " ":
            case "Escape":
                s.forEach(function(a) {
                    return a()
                })
        }
    }, !0);
    var t = function(a) {
            s.add(a);
            return function() {
                s["delete"](a)
            }
        },
        u = (h || (h = c("ExecutionEnvironment"))).canUseDOM ? null : !0;

    function v() {
        u == null && (u = !window.matchMedia("(pointer: coarse)").matches);
        return u
    }
    var w = 0,
        x = 1;

    function a(a) {
        var b = a.clickOnSpace,
            d = b === void 0 ? !1 : b;
        b = a.disabled;
        b = b === void 0 ? !1 : b;
        var e = a.onFocusChange,
            f = a.onFocusIn,
            g = a.onFocusOut,
            h = a.onFocusVisibleChange,
            i = a.onHoverChange,
            q = a.onHoverIn,
            s = a.onHoverOut,
            u = a.onPress,
            y = a.onPressChange,
            z = a.onPressIn,
            A = a.onPressOut;
        a = a.testOnly_pressed;
        var B = a === void 0 ? !1 : a;
        a = l(c("XPlatReactNestedPressableContext"));
        var C = o(w),
            D = p(!1),
            E = D[0],
            F = D[1];
        D = p(b);
        var G = D[0];
        D = D[1];
        var H = p(B),
            I = H[0],
            J = H[1];
        H = p(!1);
        var K = H[0],
            L = H[1];
        H = p(!1);
        var M = H[0],
            N = H[1];
        H = p(!1);
        var O = H[0],
            P = H[1];
        m(function() {
            var a = r(function() {
                    C.current = w
                }),
                b = t(function() {
                    C.current = x
                });
            return function() {
                a(), b()
            }
        }, []);
        var Q = k(function(a) {
                J(a), y && y(a)
            }, [y]),
            R = k(function(a) {
                L(a), e && e(a), (C.current === x || !a && M) && (N(a), h && h(a))
            }, [e, h, M]),
            S = k(function(a) {
                P(a), i && i(a)
            }, [i]);
        H = p(B);
        var T = H[0],
            U = H[1];
        n(function() {
            B !== T && (Q(B), U(B))
        }, [T, Q, B]);
        H = o(null);
        var V = k(function(a) {
                R(!0), f && f(a)
            }, [f, R]),
            W = k(function(a) {
                K && (R(!1), g && g(a))
            }, [K, g, R]),
            X = k(function(a) {
                if (!v()) return;
                E && (Q(!0), !I && z && z(a));
                S(!0);
                q && q(a)
            }, [E, q, z, I, S, Q]),
            Y = k(function(a) {
                I && (Q(!1), A && A(a)), O && (S(!1), s && s(a))
            }, [O, s, A, I, S, Q]),
            Z = k(function(a) {
                F(!0), Q(!0), z && z(a)
            }, [z, Q]),
            aa = k(function(a) {
                F(!1), I && (Q(!1), A && A(a))
            }, [A, I, Q]),
            $ = o(!1),
            ba = k(function(a) {
                $.current = a.touches.length === 1, Q($.current), $.current && z != null && z(a)
            }, [z, Q]),
            ca = k(function(a) {
                $.current = !1, I && (Q(!1), A && A(a))
            }, [A, I, Q]),
            da = k(function(a) {
                I && (Q(!1), $.current && a.touches.length === 1 && (A && A(a)))
            }, [A, I, Q]);
        m(function() {
            if (E && !O) {
                var a = function() {
                    F(!1)
                };
                document.addEventListener("mouseup", a, {
                    capture: !0,
                    passive: !0
                });
                return function() {
                    document.removeEventListener("mouseup", a, {
                        capture: !0,
                        passive: !0
                    })
                }
            }
            return function() {}
        }, [a, E, Q, O]);
        var ea = k(function(a) {
                var b = a.target;
                u != null && b instanceof HTMLElement && b.tagName === "LABEL" && a.preventDefault();
                F(!1);
                u && u(a)
            }, [u]),
            fa = k(function(a) {
                a.key === "Enter" && (u && u(a)), a.key === " " && d && (u && u(a))
            }, [d, u]);
        b !== G && (b && (Q(!1), R(!1), S(!1)), D(b));
        G = b ? c("emptyObject") : {
            onBlur: W,
            onClick: ea,
            onFocus: V,
            onKeyDown: fa,
            onMouseDown: Z,
            onMouseEnter: X,
            onMouseLeave: Y,
            onMouseUp: aa,
            onTouchEnd: da,
            onTouchMove: ca,
            onTouchStart: ba
        };
        D = k(function(a) {
            a = a.children;
            return j.jsx(c("XPlatReactNestedPressableContext").Provider, {
                value: !0,
                children: a
            })
        }, []);
        return [H, a, {
            disabled: b,
            focused: K,
            focusVisible: M,
            hovered: O,
            pressed: I
        }, G, D]
    }
    g["default"] = a
}), 98);
__d("XMessengerDotComHelpContentControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/help/{cms_id}/{?cms_title}/", Object.freeze({
        region_hint: [],
        expand_folders: []
    }), void 0);
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("TrustedTypesWebWorkerScriptURLPolicy", ["TrustedTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        createScriptURL: function(a) {
            return a
        }
    };
    b = c("TrustedTypes").createPolicy("web-worker-url", a);
    d = b;
    g["default"] = d
}), 98);
__d("XCometFBMultiSiteWebWorkerV2HasteResponseControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/static_resources/webworker/rsrc/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("WebWorkerV2DynamicData", ["Promise", "XCometFBMultiSiteWebWorkerV2HasteResponseControllerRouteBuilder", "cometAsyncFetchShared", "err", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new Map();

    function a(a) {
        var b = a.name,
            c = i.get(b);
        c == null && (c = j(a), i.set(b, c));
        return c
    }

    function j(a) {
        var d = a.name,
            e = a.v2HasteResponsePreloader;
        if (e == null) return k(d);
        var f = null;
        a = new(h || (h = b("Promise")))(function(a, b) {
            e.onLoaded(function(b) {
                b = b.data;
                f = b;
                a(b)
            }).onError(b)
        });
        return h.race([a, new h(function(a, b) {
            window.setTimeout(function() {
                f == null ? c("promiseDone")(k(d), a, b) : a(f)
            }, 1e4)
        })])
    }

    function k(a) {
        return c("cometAsyncFetchShared")(c("XCometFBMultiSiteWebWorkerV2HasteResponseControllerRouteBuilder").buildUri({
            worker_module: a
        }).toString(), {
            data: {},
            getFullPayload: !0,
            method: "POST",
            skipSRState: !0
        }).then(function(b) {
            if (b != null && typeof b === "object" && Object.prototype.hasOwnProperty.call(b, "hrp") && typeof b.hrp === "object") return b;
            throw c("err")("Unexpected data from WorkerInitResourceDeliveryController for worker %s", a)
        })
    }
    g.readDynamicDataForWorker = a
}), 98);
__d("getWorkerInitScriptSPINParams", ["SiteData", "StaticSiteData", "objectEntries"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a, b, d, e = (b = c("SiteData"))[(d = c("StaticSiteData")).spin_mhenv_key];
        d = babelHelpers["extends"]((a = {}, a[d.hs_key] = b.haste_session, a[d.spin_rev_key] = b[d.spin_rev_key], a[d.spin_branch_key] = b[d.spin_branch_key], a[d.spin_time_key] = b[d.spin_time_key], a), Boolean(e) ? (b = {}, b[c("StaticSiteData").spin_mhenv_key] = e, b) : null);
        return new Map(c("objectEntries")(d))
    }
    g["default"] = a
}), 98);
__d("XCometFBMultiSiteWebWorkerV2InitScriptControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/static_resources/webworker/init_script/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("supportsModuleWorker", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;

    function a(a) {
        if (h != null) return h;
        if (h != null) return h;
        if (c("UserAgent").isEngine("Blink")) {
            h = a ? c("UserAgent").isEngine_DEPRECATED_DANGEROUS("Blink > 83") : c("UserAgent").isEngine_DEPRECATED_DANGEROUS("Blink > 80.1");
            return h
        }
        if (c("UserAgent").isBrowser("Safari")) {
            h = c("UserAgent").isBrowser("Safari > 14.9");
            return h
        }
        if (c("UserAgent").isBrowser("Firefox")) {
            h = c("UserAgent").isBrowser("Firefox > 113");
            return h
        }
        if (c("UserAgent").isEngine("WebKit")) {
            h = c("UserAgent").isEngine_DEPRECATED_DANGEROUS("WebKit > 606");
            return h
        }
        if (c("UserAgent").isBrowser("IE")) {
            h = !1;
            return h
        }
        var b = {
            get type() {
                h = !0
            }
        };
        try {
            a ? new SharedWorker("blob://", b) : new Worker("blob://", b)
        } finally {
            h = (a = h) != null ? a : !1;
            return h
        }
    }
    g["default"] = a
}), 98);
__d("WebWorkerV2Resource", ["TrustedTypesWebWorkerScriptURLPolicy", "WebWorkerV2DynamicData", "XCometFBMultiSiteWebWorkerV2InitScriptControllerRouteBuilder", "forEachObject", "getAsyncParamsFromCurrentPageURI", "getWorkerInitScriptSPINParams", "nullthrows", "promiseDone", "supportsModuleWorker"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = (b = b) != null ? b : a.name;
        var e = c("supportsModuleWorker")(!1) ? "module" : "classic",
            f = c("getWorkerInitScriptSPINParams")();
        c("forEachObject")(c("getAsyncParamsFromCurrentPageURI")(), function(a, b) {
            f.set(b, a)
        });
        var g = c("nullthrows")(c("XCometFBMultiSiteWebWorkerV2InitScriptControllerRouteBuilder").buildUri({
            worker_type: c("supportsModuleWorker")(!1) ? "MODULE" : "CLASSIC"
        }).addQueryParams(f)).toString();
        g = c("TrustedTypesWebWorkerScriptURLPolicy").createScriptURL(g);
        var h = new Worker(g, {
            name: b,
            type: e
        });
        c("promiseDone")(d("WebWorkerV2DynamicData").readDynamicDataForWorker(a).then(function(a) {
            h.postMessage({
                type: "ww-hrp-init",
                hrp: a.hrp,
                js_env: a.js_env,
                is_dev: !1,
                tiered: !0
            })
        }));
        return {
            worker: h,
            url: g.toString()
        }
    }
    g.createDedicatedV2WebWorker = a
}), 98); /*FB_PKG_DELIM*/
__d("CometQuickPromotionLoggerContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRowContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometRowItem.react", ["BaseRowItem.react", "CometErrorBoundary.react", "CometPlaceholder.react", "CometRowContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            4: {
                paddingEnd: "xg83lxy",
                paddingStart: "x1h0ha7o",
                $$css: !0
            },
            8: {
                paddingEnd: "x150jy0e",
                paddingStart: "x1e558r4",
                $$css: !0
            },
            12: {
                paddingEnd: "xsyo7zv",
                paddingStart: "x16hj40l",
                $$css: !0
            },
            16: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha",
                $$css: !0
            },
            24: {
                paddingEnd: "xn6708d",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            32: {
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13",
                $$css: !0
            }
        },
        l = {
            4: {
                paddingBottom: "x1120s5i",
                paddingTop: "x1nn3v0j",
                $$css: !0
            },
            8: {
                paddingBottom: "xjkvuk6",
                paddingTop: "x1iorvi4",
                $$css: !0
            },
            12: {
                paddingBottom: "x10b6aqq",
                paddingTop: "x1yrsyyn",
                $$css: !0
            },
            16: {
                paddingBottom: "xwib8y2",
                paddingTop: "x1y1aw1k",
                $$css: !0
            },
            24: {
                paddingBottom: "xsag5q8",
                paddingTop: "xz9dl7a",
                $$css: !0
            },
            32: {
                paddingBottom: "x1l90r2v",
                paddingTop: "xyamay9",
                $$css: !0
            }
        },
        m = i.forwardRef(a);

    function a(a, b) {
        var d;
        a = babelHelpers["extends"]({}, a);
        d = (d = j(c("CometRowContext"))) != null ? d : {};
        var e = d.spacingHorizontal;
        d = d.spacingVertical;
        var f = a.fallback,
            g = a.placeholder,
            h = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback", "placeholder"]);
        if (g !== void 0) {
            a.placeholder;
            var n = babelHelpers.objectWithoutPropertiesLoose(a, ["placeholder"]);
            return i.jsx(c("CometPlaceholder.react"), {
                fallback: g != null ? i.jsx(m, babelHelpers["extends"]({}, n, {
                    ref: b,
                    children: g
                })) : null,
                children: i.jsx(m, babelHelpers["extends"]({}, n, {
                    ref: b
                }))
            })
        }
        if (f !== void 0) {
            a.fallback;
            var o = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback"]);
            return f === null ? i.jsx(c("CometErrorBoundary.react"), {
                children: i.jsx(m, babelHelpers["extends"]({}, o, {
                    ref: b
                }))
            }) : i.jsx(c("CometErrorBoundary.react"), {
                fallback: function(a, c) {
                    return i.jsx(m, babelHelpers["extends"]({}, o, {
                        ref: b,
                        children: typeof f === "function" ? f(a, c) : f
                    }))
                },
                children: i.jsx(m, babelHelpers["extends"]({}, o, {
                    ref: b
                }))
            })
        }
        return i.jsx(c("BaseRowItem.react"), babelHelpers["extends"]({}, h, {
            ref: b,
            useDeprecatedStyles: h.useDeprecatedStyles,
            xstyle: [k[e], l[d], h.xstyle],
            children: i.jsx(c("CometRowContext").Provider, {
                value: null,
                children: h.children
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = m;
    g["default"] = b
}), 98);
__d("CometRow.react", ["BaseRow.react", "CometColumnContext", "CometColumnItem.react", "CometRowContext", "CometRowItem.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react"));
    b = h;
    var j = b.useContext,
        k = b.useMemo,
        l = {
            4: {
                paddingEnd: "x150jy0e",
                paddingStart: "x1e558r4",
                $$css: !0
            },
            8: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha",
                $$css: !0
            },
            12: {
                paddingEnd: "xn6708d",
                paddingStart: "x1ye3gou",
                $$css: !0
            },
            16: {
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13",
                $$css: !0
            }
        },
        m = {
            0: {
                paddingTop: "xexx8yu",
                $$css: !0
            },
            4: {
                paddingTop: "x1iorvi4",
                $$css: !0
            },
            8: {
                paddingTop: "x1y1aw1k",
                $$css: !0
            },
            12: {
                paddingTop: "xz9dl7a",
                $$css: !0
            },
            16: {
                paddingTop: "xyamay9",
                $$css: !0
            }
        },
        n = {
            4: {
                paddingBottom: "xjkvuk6",
                paddingTop: "x1iorvi4",
                $$css: !0
            },
            8: {
                paddingBottom: "xwib8y2",
                paddingTop: "x1y1aw1k",
                $$css: !0
            },
            12: {
                paddingBottom: "xsag5q8",
                paddingTop: "xz9dl7a",
                $$css: !0
            },
            16: {
                paddingBottom: "x1l90r2v",
                paddingTop: "xyamay9",
                $$css: !0
            }
        },
        o = {
            4: {
                marginEnd: "xwrv7xz",
                marginStart: "x8182xy",
                $$css: !0
            },
            8: {
                marginEnd: "xcud41i",
                marginStart: "x139jcc6",
                $$css: !0
            },
            12: {
                marginEnd: "xykv574",
                marginStart: "xbmpl8g",
                $$css: !0
            },
            16: {
                marginEnd: "x1n0m28w",
                marginStart: "xp7jhwk",
                $$css: !0
            },
            24: {
                marginEnd: "x12rz0ws",
                marginStart: "x16hk5td",
                $$css: !0
            },
            32: {
                marginEnd: "x19f6ikt",
                marginStart: "x169t7cy",
                $$css: !0
            }
        },
        p = {
            4: {
                marginBottom: "xmgb6t1",
                marginTop: "x1kgmq87",
                $$css: !0
            },
            8: {
                marginBottom: "x4vbgl9",
                marginTop: "x1rdy4ex",
                $$css: !0
            },
            12: {
                marginBottom: "x4cne27",
                marginTop: "xifccgj",
                $$css: !0
            },
            16: {
                marginBottom: "x1wsgfga",
                marginTop: "x9otpla",
                $$css: !0
            },
            24: {
                marginBottom: "xh3wvx0",
                marginTop: "x7wgvq7",
                $$css: !0
            },
            32: {
                marginBottom: "x1oo3vh0",
                marginTop: "xwya9rg",
                $$css: !0
            }
        };
    e = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = j(c("CometColumnContext")),
            e = j(c("CometRowContext")),
            f = (d == null ? void 0 : d.paddingHorizontal) != null ? 0 : 12,
            g = (d == null ? void 0 : d.spacing) != null ? 0 : 16,
            h = a.children,
            q = a.paddingHorizontal;
        f = q === void 0 ? f : q;
        q = a.paddingVertical;
        q = q === void 0 ? 0 : q;
        var r = a.paddingTop;
        g = r === void 0 ? a.paddingVertical == null ? g : null : r;
        r = a.spacing;
        r = r === void 0 ? 12 : r;
        var s = a.spacingHorizontal,
            t = s === void 0 ? r : s;
        s = a.spacingVertical;
        var u = s === void 0 ? r : s;
        r = a.xstyle;
        s = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "paddingHorizontal", "paddingVertical", "paddingTop", "spacing", "spacingHorizontal", "spacingVertical", "xstyle"]);
        a = k(function() {
            return {
                spacingHorizontal: t,
                spacingVertical: u
            }
        }, [t, u]);
        b = i.jsx(c("BaseRow.react"), babelHelpers["extends"]({}, s, {
            ref: b,
            xstyle: [l[f], n[q], g != null && m[g], o[t], p[u], r],
            children: i.jsx(c("CometRowContext").Provider, {
                value: a,
                children: h
            })
        }));
        if (e != null) return i.jsx(c("CometRowItem.react"), {
            expanding: s.expanding,
            children: b
        });
        return d != null ? i.jsx(c("CometColumnItem.react"), {
            expanding: s.expanding,
            children: b
        }) : b
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = e;
    g["default"] = d
}), 98); /*FB_PKG_DELIM*/
__d("AdsDataAtomPerfProfiler", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = new Map()
        }
        var b = a.prototype;
        b.addFluxActionDispatchInfo = function(a, b) {
            this.$1.set(String(a), b)
        };
        b.getFluxActionDispatchInfo = function(a) {
            return this.$1.get(String(a))
        };
        return a
    }();
    b = new a();
    f["default"] = b
}), 66);
__d("MAWAttachmentStateHandlerContentBase.react", ["FBLogger", "MAWMediaDownloadStatusUIStateType", "react", "useMAWBulkMediaDownloadManualRetry", "useMAWMaybeAutoTriggerDownload", "useMAWMediaDownloadStatus", "useMAWMediaStatusUIState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    b = i || d("react");
    h || (h = c("react"));
    var j = b.useEffect,
        k = b.useMemo;

    function a(a) {
        var b = a.attachmentsFromGroupToRetry,
            e = a.dbAttachment,
            f = a.descriptionForLogging,
            g = a.downloadStatusKeyOverride,
            h = a.errorComponentRenderer,
            i = a.errorWithBlurComponentRenderer,
            l = a.loadingPlaceholderRenderer,
            m = a.mediaRenderQpl;
        a = a.successfulComponentRenderer;
        var n = k(function() {
            return b != null && b.length > 0 ? b : [e]
        }, [e, b]);
        n = c("useMAWBulkMediaDownloadManualRetry")(n, m);
        var o = c("useMAWMediaStatusUIState")(e, m, g),
            p = o.downloadStatus;
        o = (o = c("useMAWMediaDownloadStatus")(e, m, g)) != null ? o : {};
        var q = o.status;
        c("useMAWMaybeAutoTriggerDownload")(e, m, "thread", g);
        j(function() {
            var a, b = {
                string: {
                    call_site: f,
                    download_status_main_details: q == null ? void 0 : q.mainMediaStatusDetails,
                    download_status_main_media: String(q == null ? void 0 : q.mainMediaStatus),
                    download_status_preview_details: q == null ? void 0 : q.previewMediaStatusDetails,
                    download_status_preview_media: String(q == null ? void 0 : q.previewMediaStatus),
                    download_status_ui_state: p
                }
            };
            m == null ? void 0 : m.addPoint("render-attachment-state-handler-content-wrapper-" + ((a = p) != null ? a : "null"), b)
        }, [m, p, q == null ? void 0 : q.mainMediaStatusDetails, q == null ? void 0 : q.mainMediaStatus, q == null ? void 0 : q.previewMediaStatusDetails, q == null ? void 0 : q.previewMediaStatus, f]);
        j(function() {
            switch (p) {
                case "non_retryable_error":
                case "retryable_error":
                case "non_retryable_error_with_preview":
                case "retryable_error_with_preview":
                    Boolean(q == null ? void 0 : q.mainMediaStatusDetails) ? m == null ? void 0 : m.endFail(p + ": " + (q == null ? void 0 : q.mainMediaStatusDetails)) : m == null ? void 0 : m.endFail(p);
                    break;
                case null:
                case "downloaded":
                case "loading":
                    break;
                default:
                    m == null ? void 0 : m.endFail("unknown_state", {
                        string: {
                            unknown_state_value: p
                        }
                    });
                    break
            }
        }, [m, p, f]);
        o = d("MAWMediaDownloadStatusUIStateType").isRetryableErrorState(p);
        switch (p) {
            case null:
            case "loading":
                return l(f + ".MAWAttachmentStateHandlerContentBase.NoMedia", !1);
            case "non_retryable_error":
            case "retryable_error":
                return h(o, n);
            case "non_retryable_error_with_preview":
            case "retryable_error_with_preview":
                return i == null ? h(o, n) : i(o, n);
            case "downloaded":
                return a(l);
            default:
                c("FBLogger")("messenger_web_media").mustfix("[MAW Attachment Content] Unknown MediaDownloadStatusUIState %s", p);
                return l(f + ".MAWAttachmentStateHandlerContentBase.UnknownState", !1)
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWThreadViewAttachmentStateHandlerContent.react", ["CometHeroHoldTrigger.react", "MAWAttachmentStateHandlerContentBase.react", "MWV2AttachmentLoadingPlaceholder.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || c("react");

    function a(a) {
        var b = a.attachmentsFromGroupToRetry,
            d = a.connectBottom,
            e = a.connectTop,
            f = a.dbAttachment,
            g = a.descriptionForLogging,
            h = a.downloadStatusKeyOverride,
            j = a.errorComponentRenderer,
            k = a.errorWithBlurComponentRenderer,
            l = a.loadingPlaceholderStyle,
            m = a.mediaRenderQpl,
            n = a.outgoing,
            o = a.placeholderHeight,
            p = a.placeholderMaxHeight,
            q = a.placeholderMaxWidth,
            r = a.placeholderWidth;
        a = a.successfulComponentRenderer;
        return i.jsx(c("MAWAttachmentStateHandlerContentBase.react"), {
            attachmentsFromGroupToRetry: b,
            dbAttachment: f,
            descriptionForLogging: g + ".MAWThreadViewAttachmentStateHandlerContent",
            downloadStatusKeyOverride: h,
            errorComponentRenderer: j,
            errorWithBlurComponentRenderer: k,
            loadingPlaceholderRenderer: function(a, b) {
                var g;
                return i.jsxs(i.Fragment, {
                    children: [i.jsx(c("MWV2AttachmentLoadingPlaceholder.react"), {
                        connectBottom: d,
                        connectTop: e,
                        descriptionForLogging: a,
                        hasAppAttribution: (f == null ? void 0 : f.attributionAppName) != null,
                        height: o,
                        maxHeight: (g = p) != null ? g : o,
                        maxWidth: (g = q) != null ? g : r,
                        mediaRenderQpl: m,
                        outgoing: n,
                        width: r,
                        xstyle: l
                    }), !b && i.jsx(c("CometHeroHoldTrigger.react"), {
                        description: a,
                        hold: !0
                    })]
                })
            },
            mediaRenderQpl: m,
            successfulComponentRenderer: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("useChatVisibility_PresenceStatusChatVisibilityQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8337586946305905"
}), null);
__d("useChatVisibility_PresenceStatusChatVisibilityQuery.graphql", ["useChatVisibility_PresenceStatusChatVisibilityQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
            alias: null,
            args: null,
            concreteType: "Viewer",
            kind: "LinkedField",
            name: "viewer",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "chat_visibility",
                storageKey: null
            }],
            storageKey: null
        }];
        return {
            fragment: {
                argumentDefinitions: [],
                kind: "Fragment",
                metadata: null,
                name: "useChatVisibility_PresenceStatusChatVisibilityQuery",
                selections: a,
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [],
                kind: "Operation",
                name: "useChatVisibility_PresenceStatusChatVisibilityQuery",
                selections: a
            },
            params: {
                id: b("useChatVisibility_PresenceStatusChatVisibilityQuery_facebookRelayOperation"),
                metadata: {},
                name: "useChatVisibility_PresenceStatusChatVisibilityQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useChatVisibility.react", ["CometRelay", "react", "relay-runtime", "useChatVisibility_PresenceStatusChatVisibilityQuery.graphql", "useDebouncedState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (i || d("react")).useEffect,
        k = h !== void 0 ? h : h = b("useChatVisibility_PresenceStatusChatVisibilityQuery.graphql");

    function a() {
        var a = d("CometRelay").useRelayEnvironment(),
            b = d("relay-runtime").getRequest(k);
        b = d("relay-runtime").createOperationDescriptor(b, {});
        var e = a.lookup(b.fragment);
        b = (b = e.data) == null ? void 0 : b.viewer;
        var f = typeof b === "object" ? b == null ? void 0 : b.chat_visibility : null;
        b = c("useDebouncedState")(function() {
            return !!f
        });
        var g = b[0],
            h = b[1];
        j(function() {
            var b = a.subscribe(e, function(a) {
                a = a.data;
                a = a == null ? void 0 : a.viewer;
                if (typeof a !== "object" || a == null) return;
                h(a.chat_visibility === !0)
            });
            return function() {
                b.dispose()
            }
        }, [a, h, e]);
        return g
    }
    g["default"] = a
}), 98);
__d("useInitPresenceUnifiedClient", ["asyncToGeneratorRuntime", "promiseDone", "react", "useChatVisibility.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useEffect;

    function a(a) {
        var d = c("useChatVisibility.react")();
        i(function() {
            var e = function() {
                var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                    d ? yield a.startStream(): yield a.closeStream()
                });
                return function() {
                    return c.apply(this, arguments)
                }
            }();
            c("promiseDone")(e())
        }, [a, d])
    }
    g["default"] = a
}), 98);
__d("RealtimeNexusSessionDataTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    c = (a = b("$InternalEnum"))({
        MESSENGER_CP: 0,
        NON_MESSENGER_CP: 1,
        MESSENGER_MQTT: 2,
        NON_MESSENGER_MQTT: 3
    });
    d = a({
        ACTIVE: 1,
        IDLE: 2,
        OFFLINE: 3
    });
    f = a({
        MQTT: 1,
        SESSION_MESSAGE_HANDLER: 2,
        PRESENCE_HANDLER: 3,
        RTC_SESSION_MESSAGE_HANDLER: 4,
        WWW: 5,
        PRESENCE_STREAM_CONTROLLER: 6,
        RPSIGNALING: 7
    });
    b = a({
        FbId: "fbId",
        IgId: "igId"
    });
    e.exports = {
        BuddyListSessionType: c,
        PresenceAvailability: d,
        SessionOwnerId$Types: b,
        SessionType: f
    }
}), null);
__d("usePresenceUnifiedActivityMonitor.react", ["CometUserActivityMonitor", "RealtimeNexusSessionDataTypes", "promiseDone", "react", "useDebounced"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = h || d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = 2e3;

    function a(a) {
        var b = i(function(b) {
                c("promiseDone")(a.reportUserPresence(b))
            }, [a]),
            e = c("useDebounced")(b, k);
        j(function() {
            var b = function(b) {
                    b === "ACTIVE" ? (e(d("RealtimeNexusSessionDataTypes").PresenceAvailability.ACTIVE), a.addAdditionalContacts([]), a.startAdditionalContactsPolling()) : e(d("RealtimeNexusSessionDataTypes").PresenceAvailability.IDLE)
                },
                c = d("CometUserActivityMonitor").getActivityState();
            b(c);
            var f = d("CometUserActivityMonitor").subscribe(b);
            return function() {
                return f && f.remove()
            }
        }, [a, e])
    }
    g["default"] = a
}), 98);
__d("PresenceUnifiedSetup.react", ["useInitPresenceUnifiedClient", "usePresenceUnifiedActivityMonitor.react"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = a.client;
        c("useInitPresenceUnifiedClient")(a);
        c("usePresenceUnifiedActivityMonitor.react")(a);
        return null
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("BaseContainerQueryElement.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = {
            root: {
                boxSizing: "x9f619",
                flexShrink: "x2lah0s",
                position: "x1n2onr6",
                $$css: !0
            }
        };
    b = j.forwardRef(a);

    function a(a, b) {
        var d = a.breakpoint,
            e = a.inverseToContainer;
        e = e === void 0 ? !1 : e;
        var f = a.maxWidth,
            g = a.minWidth,
            i = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["breakpoint", "inverseToContainer", "maxWidth", "minWidth", "xstyle"]);
        d = d - .1;
        return j.jsx("div", babelHelpers["extends"]({}, a, {
            className: (h || (h = c("stylex")))(k.root, i),
            ref: b,
            style: {
                maxWidth: f,
                minWidth: g,
                width: e ? "calc((" + d + "px - 100%) * 9999)" : "calc((100% - " + d + "px) * 9999)"
            }
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("BaseTextInput.react", ["BaseFocusRing.react", "BaseInput.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            root: {
                ":disabled_color": "x1kdt53j",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        var d = a.suppressFocusRing,
            e = a.xstyle,
            f = babelHelpers.objectWithoutPropertiesLoose(a, ["suppressFocusRing", "xstyle"]);
        return i.jsx(c("BaseFocusRing.react"), {
            suppressFocusRing: d,
            children: function(a) {
                return i.jsx(c("BaseInput.react"), babelHelpers["extends"]({}, f, {
                    ref: b,
                    xstyle: [j.root, a, e]
                }))
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = i.memo(b);
    g["default"] = e
}), 98);
__d("CometContextualLayer.react", ["BaseContextualLayer.react", "react", "useCometVisualChangeTracker", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = c("useCometVisualChangeTracker")();
        b = c("useMergeRefs")(b, d);
        return i.jsx(c("BaseContextualLayer.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("TetraProfilePhoto.react", ["CometProfilePhoto.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        return i.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("processBaseInputValidators", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, b) {
        if (typeof b === "function") return [b(a)];
        var c = [];
        for (var b = b, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= b.length) break;
                f = b[e++]
            } else {
                e = b.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            Array.isArray(f) ? c.push.apply(c, g(a, f)) : typeof f === "function" && c.push(f(a))
        }
        return c.filter(function(a) {
            return a.type !== "CORRECT"
        })
    }
    f["default"] = g
}), 66);
__d("useIsPristineValue", ["react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useState;

    function a(a, b) {
        b = i(b);
        var d = b[0];
        b = b[1];
        var e = c("useStable")(function() {
            return a
        });
        d && a !== e && b(!1);
        return d
    }
    g["default"] = a
}), 98);
__d("validateBaseInput", ["processBaseInputValidators"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        a = d != null && !a ? c("processBaseInputValidators")(b, d) : [];
        if (a.length === 0) return {
            allResults: a,
            topResultReason: null,
            topResultType: "CORRECT"
        };
        var e = a.some(function(a) {
            return a.type === "ERROR"
        });
        d = (b = a.find(function(a) {
            return a.type === (e ? "ERROR" : "WARN")
        })) != null ? b : null;
        return {
            allResults: a,
            topResultReason: d != null && d.reason != null ? d.reason : null,
            topResultType: d != null ? d.type : "CORRECT"
        }
    }
    g["default"] = a
}), 98);
__d("useBaseInputValidators", ["react", "useIsPristineValue", "validateBaseInput"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useMemo;

    function a(a) {
        var b = a.isInitialValuePristine;
        b = b === void 0 ? !0 : b;
        var d = a.validator,
            e = a.value,
            f = c("useIsPristineValue")(e, b);
        return i(function() {
            return c("validateBaseInput")(f, e, d)
        }, [f, d, e])
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("BaseTextArea.react", ["BaseFocusRing.react", "BaseInput.react", "react", "stylex", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || (i = d("react")),
        k = i.useRef,
        l = {
            containerOverride: {
                backgroundColor: "xjbqb8w",
                backgroundImage: "x18o3ruo",
                borderLeftWidth: "xyj58a3",
                borderRightWidth: "xgfja2r",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                display: "xrvj5dj",
                paddingBottom: null,
                paddingLeft: null,
                paddingRight: null,
                paddingStart: null,
                paddingEnd: null,
                paddingTop: null,
                position: "x1n2onr6",
                ":active_backgroundColor": "xyftt0y",
                ":active_backgroundImage": "xuqm82a",
                ":focus_backgroundColor": "xyc4ar7",
                ":focus_backgroundImage": "x19zaomo",
                ":hover_backgroundColor": "x1n5bzlp",
                ":hover_backgroundImage": "xn3cpwa",
                $$css: !0
            },
            divOverride: {
                overflowWrap: "x1mzt3pk",
                pointerEvents: "x47corl",
                visibility: "xlshs6z",
                whiteSpace: "x126k92a",
                $$css: !0
            },
            elementOverride: {
                gridColumnEnd: "x1ls7aod",
                gridColumnStart: "xcrlgei",
                gridRowEnd: "x1byulpo",
                gridRowStart: "x1agbcgv",
                lineHeight: "x15bjb6t",
                marginBottom: null,
                marginLeft: null,
                marginRight: null,
                marginStart: null,
                marginEnd: null,
                marginTop: null,
                $$css: !0
            },
            maxHeight: function(a) {
                return [{
                    WebkitBoxOrient: "x1ua5tub",
                    WebkitLineClamp: a == null ? null : "x65k6ix",
                    display: "x104kibb",
                    $$css: !0
                }, {
                    "--WebkitLineClamp": a != null ? a : void 0
                }]
            },
            unresizable: {
                bottom: "x1ey2m1c",
                end: "xds687c",
                start: "x17qophe",
                left: null,
                right: null,
                position: "x10l6tqk",
                resize: "xtt52l0",
                top: "x13vifvy",
                $$css: !0
            }
        };
    b = j.forwardRef(a);

    function a(a, b) {
        var d = a.maxRows;
        d = d === void 0 ? 200 : d;
        var e = a.minRows;
        e = e === void 0 ? 1 : e;
        var f = a.suppressFocusRing;
        f = f === void 0 ? !1 : f;
        var g = a.unresizable,
            i = g === void 0 ? !1 : g;
        g = a.value;
        var m = a.xstyle,
            n = babelHelpers.objectWithoutPropertiesLoose(a, ["maxRows", "minRows", "suppressFocusRing", "unresizable", "value", "xstyle"]),
            o = g != null ? String(g) : g;
        a = k(null);
        var p = k(null),
            q = c("useMergeRefs")(a, b),
            r = function(a) {
                var b = a.target.value,
                    c = p.current;
                if (c != null && o != null) {
                    b = b.endsWith("\n") ? b + " " : b;
                    c.textContent = b
                }
                n.onChange && n.onChange(a)
            };
        return j.jsxs("div", babelHelpers["extends"]({}, (h || (h = c("stylex"))).props(m, l.containerOverride), {
            children: [j.jsx("div", babelHelpers["extends"]({}, h.props(m, l.elementOverride, l.divOverride), {
                "aria-hidden": "true",
                ref: p,
                children: Array.from({
                    length: (g = e) != null ? g : 1
                }).map(function(a, b) {
                    return j.jsx("br", {}, b)
                })
            })), j.jsx("div", babelHelpers["extends"]({}, h.props(m, l.elementOverride, l.divOverride, l.maxHeight((a = d) != null ? a : 220)), {
                "aria-hidden": "true",
                ref: p,
                children: o != null && o.endsWith("\n") ? o + " " : o
            })), j.jsx(c("BaseFocusRing.react"), {
                suppressFocusRing: f,
                children: function(a) {
                    return j.jsx(c("BaseInput.react"), babelHelpers["extends"]({}, n, {
                        onChange: r,
                        ref: q,
                        type: "textarea",
                        value: o,
                        xstyle: [a, i === !0 && l.unresizable, m, l.elementOverride]
                    }))
                }
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98); /*FB_PKG_DELIM*/
__d("BaseListCell.react", ["BaseRow.react", "BaseRowItem.react", "BaseView.react", "CometCompositeStructureContext", "Locale", "getItemRoleFromCompositeRole", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || (h = d("react")),
        j = h.useContext,
        k = {
            bottomAddOn: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                $$css: !0
            },
            bottomAddOnResponsive: {
                flexGrow: "x1iyjqo2",
                $$css: !0
            },
            item: {
                display: "x78zum5",
                $$css: !0
            },
            root: {
                alignItems: "x1qjc9v5",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                justifyContent: "xl56j7k",
                minWidth: "xeuugli",
                $$css: !0
            },
            textContent: {
                flexGrow: "x1iyjqo2",
                $$css: !0
            },
            textContentContainer: {
                flexBasis: "xdl72j9",
                $$css: !0
            },
            textWithResponsiveAddOnBottom: {
                flexBasis: "x4pfjvb",
                maxWidth: "x193iq5w",
                minWidth: "x1mkiy5m",
                $$css: !0
            }
        },
        l = {
            top: {
                alignSelf: "xqcrz7y",
                $$css: !0
            }
        };
    b = i.forwardRef(a);

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var d = a.action,
            e = a.addOnBottom,
            f = a.addOnBottomResponsive;
        f = f === void 0 ? !1 : f;
        var g = a.addOnEnd,
            h = a.addOnEndVerticalAlign,
            m = a.addOnEndXStyle,
            n = a.addOnFooter,
            o = a.addOnStart,
            p = a.addOnStartVerticalAlign,
            q = a.addOnStartXStyle,
            r = a["aria-hidden"];
        r = r === void 0 ? !1 : r;
        var s = a.content,
            t = a.contentId,
            u = a.contentVerticalAlign;
        u = u === void 0 ? "center" : u;
        var v = a.contentXStyle,
            w = a.nestedSpacing,
            x = a.role,
            y = a.tabIndex,
            z = a.testid;
        z = a.verticalAlign;
        z = z === void 0 ? "center" : z;
        a = a.xstyle;
        var A = c("Locale").isRTL();
        A = w != null ? A ? {
            marginRight: w
        } : {
            marginLeft: w
        } : void 0;
        w = j(c("CometCompositeStructureContext"));
        w = w.role;
        w = c("getItemRoleFromCompositeRole")(w);
        return i.jsxs(c("BaseView.react"), {
            "aria-hidden": r ? !0 : void 0,
            "aria-selected": w === "option" ? !1 : void 0,
            ref: b,
            role: (b = (r = x) != null ? r : w) != null ? b : void 0,
            tabIndex: y,
            testid: void 0,
            xstyle: [k.root, a],
            children: [i.jsxs(c("BaseRow.react"), {
                verticalAlign: z,
                children: [A != null && i.jsx(c("BaseRowItem.react"), {
                    children: i.jsx("div", {
                        style: A
                    })
                }), d != null && i.jsx(c("BaseRowItem.react"), {
                    verticalAlign: "center",
                    xstyle: k.item,
                    children: d
                }), o != null && i.jsx(c("BaseRowItem.react"), {
                    verticalAlign: p,
                    xstyle: [k.item, q],
                    children: o
                }), i.jsxs(c("BaseRow.react"), {
                    expanding: !0,
                    verticalAlign: "center",
                    wrap: "forward",
                    xstyle: [k.textContentContainer, u !== "center" && l[u], v],
                    children: [s != null && i.jsx(c("BaseRowItem.react"), {
                        xstyle: [k.textContent, f && k.textWithResponsiveAddOnBottom],
                        children: t != null ? i.jsx("div", {
                            "aria-hidden": !0,
                            children: i.jsx("div", {
                                id: t,
                                children: s
                            })
                        }) : s
                    }), e != null && i.jsx(c("BaseRowItem.react"), {
                        xstyle: [k.bottomAddOn, f && k.bottomAddOnResponsive],
                        children: e
                    })]
                }), g != null && i.jsx(c("BaseRowItem.react"), {
                    verticalAlign: h,
                    xstyle: [k.item, m],
                    children: g
                })]
            }), n != null && n]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b;
    g["default"] = e
}), 98);
__d("useAfterPaint", ["cancelAnimationFrame", "react", "requestAnimationFrame"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useEffect;

    function a(a) {
        i(function() {
            var b = null,
                d = c("requestAnimationFrame")(function() {
                    d = c("requestAnimationFrame")(function() {
                        b = a()
                    })
                });
            return function() {
                c("cancelAnimationFrame")(d), b && b()
            }
        }, [a])
    }
    g["default"] = a
}), 98);
__d("getRequestConstUri", ["ConstUriUtils", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = d("ConstUriUtils").getUri(window.location.href);
        if (a == null) throw c("unrecoverableViolation")("Cannot create ConstUriImpl of current request", "comet_infra");
        return a
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("LSRemoveBlindedTokens", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(308).fetch(), function(b) {
                return b.configId === a[0]
            }), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSAnonymousCredentialsRemoveBlindedTokensStoredProcedure";
    e.exports = a
}), null);
__d("LSVoprfLoggingUtils", ["Env", "MemoryUtils", "QPLUserFlow", "justknobx", "mergeDeep", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = d("MemoryUtils").getCurrentMemory();
        a = a.usedJSHeapSize;
        return {
            "int": {
                usedJSHeapSizeStart: a
            }
        }
    }

    function k(a) {
        var b = d("MemoryUtils").getCurrentMemory(),
            c = b.deviceMemory,
            e = b.jsHeapSizeLimit,
            f = b.totalJSHeapSize;
        b = b.usedJSHeapSize;
        return {
            "int": {
                deviceMemory: c,
                jsHeapSizeLimit: e,
                totalJSHeapSize: f,
                usedJSHeapSize: b,
                wasmMemorySize: a
            }
        }
    }

    function l(a) {
        return (h || (h = c("performanceAbsoluteNow")))() - a
    }

    function a(a) {
        var b = Math.floor(Math.random() * 1e6);
        return {
            addPoint: function(d) {
                c("QPLUserFlow").addPoint(a, d, {
                    instanceKey: b
                })
            },
            addTimeSinceCreationAnnotation: function() {},
            addVoprfLoadedPoint: function(d) {
                c("QPLUserFlow").addPoint(a, "loaded_xplat_react_voprf", {
                    instanceKey: b
                }), c("QPLUserFlow").addAnnotations(a, {
                    "int": {
                        timeSinceVoprfInstanceCreationNs: l(d)
                    }
                }, {
                    instanceKey: b
                })
            },
            endFailure: function(d) {
                var e = d.error;
                d = d.wasmMemorySize;
                c("QPLUserFlow").addAnnotations(a, k(d));
                c("QPLUserFlow").endFailure(a, e.name, {
                    error: e,
                    instanceKey: b
                })
            },
            endSuccess: function(d) {
                d = d.wasmMemorySize;
                c("QPLUserFlow").addAnnotations(a, k(d), {
                    instanceKey: b
                });
                c("QPLUserFlow").endSuccess(a, {
                    instanceKey: b
                })
            },
            start: function() {
                c("QPLUserFlow").start(a, {
                    instanceKey: b,
                    onFlowTimeout: function(d, e) {
                        c("QPLUserFlow").addAnnotations(a, k(), {
                            instanceKey: b
                        })
                    },
                    timeoutInMs: 6e4
                }), c("QPLUserFlow").addAnnotations(a, c("mergeDeep")(j(), {
                    string: {
                        brsid: c("justknobx")._("3105") && (i || (i = c("Env"))).brsid != null ? String((i || (i = c("Env"))).brsid) : void 0
                    }
                }), {
                    instanceKey: b
                })
            }
        }
    }
    g.getMemoryAnnotationsStart = j;
    g.getMemoryAnnotationsEnd = k;
    g.getTimeSinceInstanceCreationNs = l;
    g.getAcsQplEventLogger = a
}), 98);
__d("XPlatReactVoprf", ["Promise", "WAWasmModuleCache", "asyncToGeneratorRuntime", "performanceAbsoluteNow", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = c("requireDeferred")("LSVoprfWasm").__setRef("XPlatReactVoprf");

    function k() {
        return l.apply(this, arguments)
    }

    function l() {
        l = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            var a = (yield j.load()),
                b = a.LSVoprfWasm,
                e = a.locateFile;
            a = (yield b({
                getWasmModule: function() {
                    return d("WAWasmModuleCache").loadWasmModule(e())
                }
            }));
            var f, g;
            try {
                f = a.createCurveRistretto();
                g = a.createVoprfExpTwohashdh(f);
                b = {
                    voprfInfo: {
                        curvePtr: f,
                        voprfPtr: g
                    },
                    voprfWasm: a
                };
                return {
                    instanceCreationTimestampNs: (i || (i = c("performanceAbsoluteNow")))(),
                    voprfInstance: b
                }
            } catch (b) {
                f != null && a.freeCurve(f);
                g != null && a.freeVoprf(g);
                throw b
            }
        });
        return l.apply(this, arguments)
    }

    function a() {
        return (h || (h = b("Promise"))).resolve(k())
    }

    function e(a) {
        var b = a.voprfInfo;
        a = a.voprfWasm;
        var c = b.curvePtr;
        b = b.voprfPtr;
        a.freeCurve(c);
        a.freeVoprf(b)
    }
    g.loadXPlatReactVoprf = a;
    g.freeVoprfInstance = e
}), 98); /*FB_PKG_DELIM*/
__d("MAWSecureVideoInvalidAttachment.react", ["MWV2AttachmentErrorPlaceholderV2.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.attachment,
            d = a.connectBottom,
            e = a.connectTop,
            f = a.height,
            g = a.iconSize,
            h = a.maxHeight,
            j = a.maxWidth,
            k = a.mediaRenderQpl,
            l = a.outgoing,
            m = a.width,
            n = a.withTooltip;
        a = a.xstyle;
        return i.jsx(c("MWV2AttachmentErrorPlaceholderV2.react"), {
            attachment: b,
            connectBottom: d,
            connectTop: e,
            height: f,
            iconSize: g,
            isRetryableError: !1,
            maxHeight: h,
            maxWidth: j,
            mediaRenderQpl: k,
            outgoing: l,
            width: m,
            withTooltip: n,
            xstyle: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWV2AttachmentDownloadablePlaceholderWithBlurImage.react", ["fbt", "MAWVideoAudioPlaybackErrorHandlerUtils", "MWV2AttachmentPlaceholderWithBlurImage.react", "MWXCircleButton.react", "MWXIconDownload", "MWXText.react", "MWXTooltip.react", "MediaDownloadStatusIconSize", "react", "useMWV2MediaViewerSecurePlayableUrl"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || (i = d("react")),
        k = i.useEffect;

    function a(a) {
        var b = a.connectBottom,
            e = a.connectTop,
            f = a.dbAttachment,
            g = a.getPreviewUrl,
            i = a.hasAppAttribution,
            l = a.height,
            m = a.iconSize,
            n = a.isGroupedImage,
            o = a.maxHeight,
            p = a.maxWidth,
            q = a.mediaRenderQpl,
            r = a.message,
            s = a.onRetry,
            t = a.outgoing,
            u = a.width,
            v = a.withTooltip;
        a = a.xstyle;
        var w = c("useMWV2MediaViewerSecurePlayableUrl")();
        k(function() {
            q == null ? void 0 : q.addPoint("render-error-placeholder-with-blur-image", {
                bool: {
                    has_message: r != null,
                    is_downloadable: !0
                }
            })
        }, [q, r]);
        s = d("MAWVideoAudioPlaybackErrorHandlerUtils").useGetMetadataForMediaNotRendered(f, !1, s);
        s = s.mediaStatusText;
        w = j.jsxs(j.Fragment, {
            children: [j.jsx("div", {
                className: "xtzzx4i x10l6tqk xwa60dl x11lhmoz x1vjfegm",
                children: j.jsx(c("MWXCircleButton.react"), {
                    color: "white",
                    icon: c("MWXIconDownload"),
                    label: h._("__JHASH__aP8gCQjcFIz__JHASH__"),
                    linkProps: {
                        download: !0,
                        url: w(f, "MWV2AttachmentDownloadablePlaceholderWithBlurImage")
                    },
                    size: m === c("MediaDownloadStatusIconSize").Large ? 40 : 24,
                    type: "dark-overlay"
                })
            }), j.jsx(c("MWV2AttachmentPlaceholderWithBlurImage.react"), {
                connectBottom: b,
                connectTop: e,
                dbAttachment: f,
                getPreviewUrl: g,
                hasAppAttribution: i,
                height: l,
                isGroupedImage: n,
                maxHeight: o,
                maxWidth: p,
                mediaRenderQpl: q,
                message: r,
                outgoing: t,
                width: u,
                xstyle: a
            })]
        });
        return v === !0 ? j.jsx(c("MWXTooltip.react"), {
            label: s,
            tooltip: j.jsx(c("MWXText.react"), {
                color: "tooltip",
                type: "meta4",
                children: s
            }),
            children: w
        }) : w
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 226);
__d("MAWSecureVideoUnsupportedCodecAttachment.react", ["MAWVideoAudioPlaybackErrorHandlerUtils", "MWV2AttachmentDownloadablePlaceholderWithBlurImage.react", "MWXText.react", "MWXTooltip.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");

    function a(a) {
        var b = a.connectBottom,
            e = a.connectTop,
            f = a.dbAttachment,
            g = a.getPreviewUrl,
            h = a.hasAppAttribution,
            j = a.height,
            k = a.iconSize,
            l = a.maxHeight,
            m = a.maxWidth,
            n = a.message,
            o = a.outgoing,
            p = a.width,
            q = a.withTooltip;
        a = a.xstyle;
        var r = d("MAWVideoAudioPlaybackErrorHandlerUtils").useGetMetadataForMediaNotRendered(f, !1);
        r = r.mediaStatusText;
        f = i.jsx(c("MWV2AttachmentDownloadablePlaceholderWithBlurImage.react"), {
            connectBottom: (b = b) != null ? b : !1,
            connectTop: (b = e) != null ? b : !1,
            dbAttachment: f,
            getPreviewUrl: g,
            hasAppAttribution: (e = h) != null ? e : !1,
            height: j,
            iconSize: k,
            maxHeight: l,
            maxWidth: m,
            mediaRenderQpl: null,
            message: n,
            outgoing: (b = o) != null ? b : !1,
            width: p,
            xstyle: a
        });
        return q === !0 ? i.jsx(c("MWXTooltip.react"), {
            label: r,
            tooltip: i.jsx(c("MWXText.react"), {
                color: "tooltip",
                type: "meta4",
                children: r
            }),
            children: f
        }) : f
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("MAWSecureThreadQPContainerQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6567523950018015"
}), null);
__d("MAWSecureThreadQPContainerQuery.graphql", ["MAWSecureThreadQPContainerQuery_facebookRelayOperation", "relay-runtime"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
            kind: "Literal",
            name: "surface_nux_id",
            value: 8879
        }, {
            kind: "Literal",
            name: "trigger",
            value: "MESSENGER_E2EE_THREAD_OPEN"
        }];
        return {
            fragment: {
                argumentDefinitions: [],
                kind: "Fragment",
                metadata: null,
                name: "MAWSecureThreadQPContainerQuery",
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "Viewer",
                    kind: "LinkedField",
                    name: "viewer",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: a,
                        concreteType: "ViewerEligibleQuickPromotionsConnection",
                        kind: "LinkedField",
                        name: "eligible_promotions",
                        plural: !1,
                        selections: [{
                            args: null,
                            kind: "FragmentSpread",
                            name: "MAWSecureThreadQuickPromotion_eligiblePromotions"
                        }],
                        storageKey: 'eligible_promotions(surface_nux_id:8879,trigger:"MESSENGER_E2EE_THREAD_OPEN")'
                    }],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [],
                kind: "Operation",
                name: "MAWSecureThreadQPContainerQuery",
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "Viewer",
                    kind: "LinkedField",
                    name: "viewer",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: a,
                        concreteType: "ViewerEligibleQuickPromotionsConnection",
                        kind: "LinkedField",
                        name: "eligible_promotions",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "QuickPromotion",
                            kind: "LinkedField",
                            name: "nodes",
                            plural: !0,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "CometQuickPromotionSections",
                                kind: "LinkedField",
                                name: "comet_qp_sections",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: [{
                                        kind: "Literal",
                                        name: "supported",
                                        value: "1OzhWV"
                                    }],
                                    concreteType: null,
                                    kind: "LinkedField",
                                    name: "renderer_strategy",
                                    plural: !1,
                                    selections: [{
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "__typename",
                                        storageKey: null
                                    }, {
                                        kind: "InlineFragment",
                                        selections: [{
                                            args: null,
                                            documentName: "MAWSecureThreadQuickPromotion_eligiblePromotions",
                                            fragmentName: "CometQuickPromotionArmadilloXMAPreviewSettingsNUXRendererStrategy_quickPromotionRef",
                                            fragmentPropName: "quickPromotionRef",
                                            kind: "ModuleImport"
                                        }],
                                        type: "CometQuickPromotionArmadilloXMAPreviewSettingsNUXRendererStrategy",
                                        abstractKey: null
                                    }],
                                    storageKey: 'renderer_strategy(supported:"1OzhWV")'
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "id",
                                storageKey: null
                            }],
                            storageKey: null
                        }],
                        storageKey: 'eligible_promotions(surface_nux_id:8879,trigger:"MESSENGER_E2EE_THREAD_OPEN")'
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("MAWSecureThreadQPContainerQuery_facebookRelayOperation"),
                metadata: {},
                name: "MAWSecureThreadQPContainerQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    b("relay-runtime").PreloadableQueryRegistry.set(a.params.id, a);
    e.exports = a
}), null);
__d("MAWSecureThreadQuickPromotion_eligiblePromotions.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "MAWSecureThreadQuickPromotion_eligiblePromotions",
        selections: [{
            alias: null,
            args: null,
            concreteType: "QuickPromotion",
            kind: "LinkedField",
            name: "nodes",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                concreteType: "CometQuickPromotionSections",
                kind: "LinkedField",
                name: "comet_qp_sections",
                plural: !1,
                selections: [{
                    alias: null,
                    args: [{
                        kind: "Literal",
                        name: "supported",
                        value: "1OzhWV"
                    }],
                    concreteType: null,
                    kind: "LinkedField",
                    name: "renderer_strategy",
                    plural: !1,
                    selections: [{
                        kind: "InlineFragment",
                        selections: [{
                            args: null,
                            documentName: "MAWSecureThreadQuickPromotion_eligiblePromotions",
                            fragmentName: "CometQuickPromotionArmadilloXMAPreviewSettingsNUXRendererStrategy_quickPromotionRef",
                            fragmentPropName: "quickPromotionRef",
                            kind: "ModuleImport"
                        }],
                        type: "CometQuickPromotionArmadilloXMAPreviewSettingsNUXRendererStrategy",
                        abstractKey: null
                    }],
                    storageKey: 'renderer_strategy(supported:"1OzhWV")'
                }],
                storageKey: null
            }],
            storageKey: null
        }],
        type: "ViewerEligibleQuickPromotionsConnection",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("MAWSecureThreadQuickPromotion.react", ["CometQuickPromotionLoggerContext.react", "CometRelay", "MAWSecureThreadQuickPromotion_eligiblePromotions.graphql", "react", "useQuickPromotionFalcoEvent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = h !== void 0 ? h : h = b("MAWSecureThreadQuickPromotion_eligiblePromotions.graphql");

    function a(a) {
        a = a.eligiblePromotions;
        a = d("CometRelay").useFragment(k, a);
        a = a == null ? void 0 : (a = a.nodes) == null ? void 0 : a.find(function(a) {
            return ((a = a.comet_qp_sections) == null ? void 0 : a.renderer_strategy) != null
        });
        a = a == null ? void 0 : (a = a.comet_qp_sections) == null ? void 0 : a.renderer_strategy;
        var b = c("useQuickPromotionFalcoEvent")({
            context_surface_id: 8879,
            context_trigger: "messenger_e2ee_thread_open"
        });
        return a == null ? null : j.jsx(c("CometQuickPromotionLoggerContext.react").Provider, {
            value: b,
            children: j.jsx(d("CometRelay").MatchContainer, {
                match: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MAWSecureThreadQPContainer.react", ["CometErrorBoundary.react", "CometPlaceholder.react", "CometRelay", "MAWSecureThreadQPContainerQuery.graphql", "MAWSecureThreadQuickPromotion.react", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react"),
        k = h !== void 0 ? h : h = b("MAWSecureThreadQPContainerQuery.graphql");

    function a() {
        var a = d("CometRelay").useLazyLoadQuery(k, {});
        a = a == null ? void 0 : (a = a.viewer) == null ? void 0 : a.eligible_promotions;
        return a == null ? null : j.jsx(c("CometErrorBoundary.react"), {
            fallback: c("emptyFunction"),
            children: j.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                name: "MAWSecureThreadQPContainer",
                children: j.jsx(c("MAWSecureThreadQuickPromotion.react"), {
                    eligiblePromotions: a
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("IntlCLDRNumberType12", ["IntlVariations"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getVariation: function(a) {
            if (a % 10 === 1 && a % 100 !== 11) return c("IntlVariations").NUMBER_ONE;
            else return c("IntlVariations").NUMBER_OTHER
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("useMAWFetchSecureMessageByPinnedExternalId", ["LSMEBTaskCreationSource", "MAWBridgeSendAndReceive", "MAWMiActOnActThreadReady", "MAWPutMessagesToDB", "MAWStateContext.react", "MWEBEntrypointsKillswitch.enum", "ReQL", "ReQLSuspense", "WAJids", "WAStanzaUtils", "asyncToGeneratorRuntime", "promiseDone", "react", "requireDeferred", "useMWEBBackupState", "useReStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = (i || d("react")).useContext,
        k = c("requireDeferred")("MAWBridgeIssuePointQueryHandler").__setRef("useMAWFetchSecureMessageByPinnedExternalId");

    function l(a) {
        return m.apply(this, arguments)
    }

    function m() {
        m = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = a.config;
            a = a.externalId;
            return babelHelpers["extends"]({}, yield d("MAWBridgeSendAndReceive").sendAndReceive("backend", "loadMsgsByExternalId", {
                config: b,
                externalId: d("WAStanzaUtils").toStanzaId(a)
            }))
        });
        return m.apply(this, arguments)
    }

    function n(a, b, c, d, e) {
        return o.apply(this, arguments)
    }

    function o() {
        o = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, g, h, i) {
            e = (yield d("MAWMiActOnActThreadReady").waitForACTThreadReady(a.tables, e, "MAWFetchPinnedMessage"));
            var j = e.chatJid;
            e = (yield l({
                config: {
                    admin: !0,
                    editMsgHistory: !1,
                    media: !0,
                    reactions: !1,
                    receiverFetch: !0,
                    xma: !0
                },
                externalId: g
            }));
            yield d("MAWPutMessagesToDB").insertMessageResponseIntoDatabaseByExternalId(a, e, i);
            if (e.msgs.length > 0 || !h) return;
            var m = (yield k.load());
            return a.runInTransaction(function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    yield m.call(a, {
                        jid: j,
                        messageId: g,
                        taskSource: c("LSMEBTaskCreationSource").EB_POINT_QUERY_PINNED_MESSAGES,
                        threadId: d("WAJids").threadIdForChatJid(j)
                    })
                });
                return function(b) {
                    return a.apply(this, arguments)
                }
            }(), "readwrite", void 0, void 0, f.id + ":105")
        });
        return o.apply(this, arguments)
    }

    function a(a) {
        var b = (h || (h = c("useReStore")))(),
            e = j(d("MAWStateContext.react").MAWDispatchContext),
            g = c("useMWEBBackupState")({
                entrypoint: c("MWEBEntrypointsKillswitch.enum").PINNED_MESSAGES
            }),
            i = g === 3;
        g = d("ReQLSuspense").useArray(function() {
            return d("ReQL").fromTableDescending(b.tables.client_web_pinned_messages.index("pinnedMessageDisplayOrder")).getKeyRange(a).map(function(g) {
                g = g.offlineThreadingId;
                var h = d("ReQLSuspense").first(d("ReQL").fromTableDescending(b.tables.messages.index("optimistic")).getKeyRange(g), f.id + ":136");
                h == null && c("promiseDone")(n(b, a, g, i, e));
                return {
                    message: h,
                    pinnedOfflineThreadingId: g
                }
            })
        }, [b, a, i, e], f.id + ":126");
        return g.map(function(a) {
            return a.message
        }).filter(function(a) {
            return !(a == null ? void 0 : a.isUnsent)
        })
    }
    g["default"] = a
}), 98); /*FB_PKG_DELIM*/
__d("CometPageletImpl.react", ["hero-tracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("hero-tracing").HeroPagelet
}), 98);
__d("CometSuspenseList.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = h || d("react");
    b = a.unstable_SuspenseList;
    g["default"] = b
}), 98);
__d("useCometIgnoreLateMutation", ["InteractionTracing", "InteractionTracingMetrics", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = (h || d("react")).useCallback;

    function a(a) {
        return i(function(b) {
            b && a && c("InteractionTracing").getPendingInteractions().forEach(function(a) {
                a = c("InteractionTracingMetrics").get(a.getTraceId());
                a != null && a.lateMutationIgnoreElements.add(b)
            })
        }, [a])
    }
    g["default"] = a
}), 98);
__d("CometPageletWithDiv.react", ["CometBackupPlaceholder.react", "CometPlaceholder.react", "CometSuspenseList.react", "LegacyHidden", "cr:1191379", "gkx", "react", "useCometIgnoreLateMutation", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react");
    d = i.forwardRef(function(a, b) {
        a = a.children;
        return i.jsxs(i.Fragment, {
            children: [" ", a(b, function() {
                return null
            }), " "]
        })
    });
    var j = (b = b("cr:1191379")) != null ? b : d;
    b = i.forwardRef(a);

    function a(a, b) {
        var d = a.children,
            e = a.className,
            f = a.fallback,
            g = a.hidden,
            h = a.ignoreLateMutation,
            k = a.name,
            l = a.pageletAriaProps,
            m = a.pageletLogNamePoisitionLimit,
            n = a.position;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "className", "fallback", "hidden", "ignoreLateMutation", "name", "pageletAriaProps", "pageletLogNamePoisitionLimit", "position"]);
        var o = k;
        m = (m = m) != null ? m : 2;
        n != null && n < m ? o += "_" + n : n != null && (o += "_{n}");
        m = c("gkx")("26331");
        var p = babelHelpers["extends"]({}, m ? null : {
            "data-pagelet": o
        });
        m = c("useCometIgnoreLateMutation")(h === !0);
        h = c("useMergeRefs")(b, m);
        return i.jsx(j, babelHelpers["extends"]({}, a, {
            name: o,
            pageletName: k,
            position: n,
            ref: h,
            children: function(a, b) {
                return i.jsxs(c("CometPlaceholder.react"), {
                    fallback: f,
                    name: o,
                    children: [i.jsx(b, {}), i.jsx(c("LegacyHidden"), {
                        htmlAttributes: babelHelpers["extends"]({
                            className: e
                        }, l, p),
                        mode: g === !0 ? "hidden" : "visible",
                        ref: a,
                        children: d
                    })]
                })
            }
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = i.forwardRef(e);

    function e(a, b) {
        var d = a.children,
            e = a.className,
            f = a.fallback,
            g = a.hidden,
            h = a.ignoreLateMutation,
            k = a.name,
            l = a.pageletAriaProps,
            m = a.pageletLogNamePoisitionLimit,
            n = a.position;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "className", "fallback", "hidden", "ignoreLateMutation", "name", "pageletAriaProps", "pageletLogNamePoisitionLimit", "position"]);
        k = k;
        m = (m = m) != null ? m : 2;
        n != null && n < m ? k += "_" + n : n != null && (k += "_{n}");
        m = c("gkx")("26331");
        var o = babelHelpers["extends"]({}, m ? null : {
            "data-pagelet": k
        });
        m = c("useCometIgnoreLateMutation")(h === !0);
        h = c("useMergeRefs")(b, m);
        return i.jsx(j, babelHelpers["extends"]({}, a, {
            name: k,
            position: n,
            ref: h,
            children: function(a, b) {
                return i.jsxs(c("CometBackupPlaceholder.react"), {
                    fallback: f,
                    children: [i.jsx(b, {}), i.jsx(c("LegacyHidden"), {
                        htmlAttributes: babelHelpers["extends"]({}, o, l, {
                            className: e
                        }),
                        mode: g === !0 ? "hidden" : "visible",
                        ref: a,
                        children: d
                    })]
                })
            }
        }))
    }
    e.displayName = e.name + " [from " + f.id + "]";

    function k(a, b) {
        var d = a.children,
            e = a.className,
            f = a.hidden,
            g = a.name,
            h = a.pageletAriaProps,
            k = a.position,
            l = a.revealOrder,
            m = a.tail;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "className", "hidden", "name", "pageletAriaProps", "position", "revealOrder", "tail"]);
        g = g;
        k != null && k < 2 ? g += "_" + k : k != null && (g += "_{n}");
        var n = c("gkx")("26331"),
            o = babelHelpers["extends"]({}, n ? null : {
                "data-pagelet": g
            });
        return i.jsx(j, babelHelpers["extends"]({}, a, {
            name: g,
            position: k,
            ref: b,
            children: function(a, b) {
                return i.jsxs(c("LegacyHidden"), {
                    htmlAttributes: babelHelpers["extends"]({
                        className: e
                    }, h, o),
                    mode: f === !0 ? "hidden" : "visible",
                    ref: a,
                    children: [i.jsx(b, {}), i.jsx(c("CometSuspenseList.react"), {
                        revealOrder: l,
                        tail: m,
                        children: d
                    })]
                })
            }
        }))
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function l(a, b) {
        var d = a.children,
            e = a.className,
            f = a.hidden,
            g = a.name,
            h = a.pageletAriaProps,
            k = a.position;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "className", "hidden", "name", "pageletAriaProps", "position"]);
        g = g;
        k != null && k < 2 ? g += "_" + k : k != null && (g += "_{n}");
        var l = c("gkx")("26331"),
            m = babelHelpers["extends"]({}, l ? null : {
                "data-pagelet": g
            });
        return i.jsx(j, babelHelpers["extends"]({}, a, {
            name: g,
            position: k,
            ref: b,
            children: function(a, b) {
                return i.jsxs(i.Fragment, {
                    children: [i.jsx(b, {}), i.jsx(c("LegacyHidden"), {
                        htmlAttributes: babelHelpers["extends"]({}, m, h, {
                            className: e
                        }),
                        mode: f === !0 ? "hidden" : "visible",
                        ref: a,
                        children: d
                    })]
                })
            }
        }))
    }
    l.displayName = l.name + " [from " + f.id + "]";
    a = i.forwardRef(k);
    e = i.forwardRef(l);
    g.Placeholder = b;
    g.BackupPlaceholder = d;
    g.SuspenseList = a;
    g.Div = e
}), 98);
__d("useLayoutEffect_SAFE_FOR_SSR", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = (h || d("react")).useLayoutEffect;
    b = a;
    g["default"] = b
}), 98);