; /*FB_PKG_DELIM*/

__d("ZenonMWAddRemoveParticipantsTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "new_room_context";

    function a(a, b) {
        var c = {
            usersToInvite: b.participants
        };
        if (b.groupThreadId != null) {
            b = {
                calling_tags: 2,
                group_thread_id: b.groupThreadId
            };
            if (b) {
                b = [{
                    body: {
                        genericMessage: {
                            data: JSON.stringify(b),
                            topic: h
                        }
                    },
                    header: {
                        topic_DEPRECATED: h
                    }
                }];
                c.appMessages = b
            }
        }
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ADD_PARTICIPANTS, a, {
            addParticipantsRequest: c
        })
    }

    function b(a, b) {
        b = {
            usersToRemove: b.participants
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.REMOVE_PARTICIPANTS, a, {
            removeParticipantsRequest: b
        })
    }
    g.NEW_ROOM_CONTEXT = h;
    g.toAddParticipantsRequest = a;
    g.toRemoveParticipantsRequest = b
}), 98);
__d("ZenonMWApprovalTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = b.approvalStatus;
        b = b.targetUsers;
        c = {
            approvalStatus: c,
            targetUsers: b
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.APPROVAL, a, {
            approvalRequest: c
        })
    }
    g.toApprovalRequest = a
}), 98);
__d("ZenonMWClientEventTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = {
            clientEvents: [{
                type: b.clientEventType
            }]
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CLIENT_EVENT, a, {
            clientEventRequest: b
        })
    }
    g.toClientEventRequest = a
}), 98);
__d("ZenonMWClientMediaUpdateTranslator", ["ZenonMWCommonUtils", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.jsonPayload;
        var c = a.body;
        a = a.header;
        c = c.clientMediaUpdateResponse;
        var e = a.responseStatusCode,
            f = a.responseSubCode,
            g = a.retryAfterMsec;
        if (c) {
            var h = c.answer,
                i = c.mediaStatus,
                j = h != null && i != null;
            d("ZenonMWTranslatorUtils").addStateStoreSignalingEvents(c.stateStore, b, !1, j);
            var k = d("ZenonMWTranslatorUtils").fetchE2eeServerState(c.stateStore);
            if (j) {
                h = (j = h == null ? void 0 : h.sdpString) != null ? j : "";
                j = d("ZenonMWTranslatorUtils").toZenonMediaStates(i);
                i = {
                    ackMessageId: a.transactionId,
                    eventName: "localSdpResponse",
                    hasAnswerInJoinResponse: !1,
                    source: "clientMediaUpdate"
                };
                var l = c.renegotiationOffer,
                    m = null;
                l != null && l.sdpString != null && (m = {
                    sdp: l.sdpString,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(l.sdpString)
                });
                l = {
                    e2eeServerState: k,
                    eventName: "remoteSdpRequest",
                    mediaPath: c.mediaPath,
                    mediaStates: j,
                    negotiateType: !1,
                    renegotiationOffer: m,
                    sdp: {
                        sdp: h,
                        type: "answer",
                        version: d("ZenonMWCommonUtils").getSdpVersion(h)
                    },
                    sdpOriginLocalId: c.sdpOriginLocalId,
                    source: "clientMediaUpdateResponse"
                };
                b.push(i);
                b.push(l)
            }
            k = {
                ackMessageId: a.transactionId,
                acknowledgedVersion: c.currentVersion,
                eventName: "mediaUpdateResponse",
                responseStatusCode: e,
                responseSubCode: f,
                retryAfter: g
            };
            b.push(k)
        }
        return b
    }

    function b(a, b, c) {
        b = {
            fromVersion: b.version,
            mediaUpdates: [{
                mediaStatus: d("ZenonMWTranslatorUtils").toMWMediaStatus(b),
                mediaStatusEx: d("ZenonMWTranslatorUtils").toMWMediaStatusEx(b)
            }],
            toVersion: b.version
        };
        c !== void 0 && (b.offer = {
            sdpString: c.sdp
        });
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CLIENT_MEDIA_UPDATE, a, {
            clientMediaUpdateRequest: b
        })
    }
    g.fromClientMediaUpdateResponse = a;
    g.toClientMediaUpdateRequest = b
}), 98);
__d("ZenonMWConferenceStateTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            c = a.jsonPayload.body.conferenceStateRequest;
        if (c) {
            var e = c.appMessages,
                f = c.participantStates,
                g = {
                    eventName: "participantUpdateRequest",
                    participantStates: new Map(),
                    sctpUserIdNodeIdMap: new Map(),
                    versionId: c.version
                },
                h = {
                    actorRepresentatives: new Map(),
                    eventName: "clientInfoRequest",
                    mediaPath: d("ZenonMWMessageTypes").ZenonMWMediaPath.UNKNOWN,
                    userCapabilities: new Map()
                };
            Object.keys(f).forEach(function(a) {
                var b = f[a],
                    c = b.sctpNodeId,
                    e = b.state;
                b = b.userCapabilities;
                g.participantStates.set(a, d("ZenonMWTranslatorUtils").fromMWParticipantState(e));
                c != null && g.sctpUserIdNodeIdMap.set(a, c);
                h.userCapabilities.set(a, (e = b) != null ? e : "")
            });
            b.push(g);
            b.push(h);
            c = d("ZenonMWTranslatorUtils").getCollisionContextFromAppMessages(e);
            if (c) {
                c.serverInfoData = a.jsonPayload.header.serverInfoData;
                e = {
                    context: c,
                    eventName: "roomContextUpdateRequest"
                };
                b.push(e)
            }
        }
        return b
    }

    function b(a, b) {
        b = {
            currentVersion: b.requestVersionId
        };
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CONFERENCE_STATE, a, {
            conferenceStateResponse: b
        })
    }
    g.fromConferenceStateRequest = a;
    g.toConferenceStateResponse = b
}), 98);
__d("ZenonMWDataMessageTranslator", ["ZenonActorHooks", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.jsonPayload.body.dataMessageRequest;
        if (a) {
            var c = a.message.header,
                e = d("ZenonMWTranslatorUtils").getGenericDataMessageData(a);
            a = d("ZenonMWTranslatorUtils").getGenericDataMessageTopic(a);
            if (e != null && a != null) {
                c = {
                    data: e,
                    eventName: "genericDataMessageRequest",
                    recipientIDs: (e = c.recipients) != null ? e : [],
                    serviceRecipients: (e = c.serviceRecipients) != null ? e : [],
                    topic: a
                };
                b.push(c)
            }
        }
        return b
    }

    function b(a, b) {
        var c = {
            data: b.data,
            topic: b.topic
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DATA_MESSAGE, a, {
            dataMessageRequest: {
                message: {
                    body: {
                        genericMessage: c
                    },
                    header: {
                        recipients: b.recipientIDs,
                        sender: d("ZenonActorHooks").ZenonActor.getID(),
                        serviceRecipients: b.serviceRecipients,
                        topic_DEPRECATED: ""
                    }
                }
            }
        })
    }

    function c(a) {
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DATA_MESSAGE, a, {
            dataMessageResponse: {
                deliveryResult: {}
            }
        })
    }
    g.fromDataMessageRequest = a;
    g.toDataMessageRequest = b;
    g.toDataMessageResponse = c
}), 98);
__d("ZenonMWDismissTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.jsonPayload.body.dismissRequest;
        if (a) {
            var c = a.detailedReasonString;
            a = a.reason;
            a = {
                eventName: "terminateRequest",
                fromJoinResponse: !1,
                reason: d("ZenonMWTranslatorUtils").fromMWDismissReason(a),
                shouldInformPeer: !0,
                subreason: c
            };
            b.push(a)
        }
        return b
    }

    function b(a) {
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DISMISS, a, {})
    }
    g.fromDismissRequest = a;
    g.toDismissResponse = b
}), 98);
__d("ZenonMWHangupTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.jsonPayload.header;
        a = {
            ackMessageId: a.transactionId,
            eventName: "hangupResponse"
        };
        b.push(a);
        return b
    }

    function b(a, b) {
        b = b.reason;
        b = {
            detailedReasonString: "",
            reason: d("ZenonMWTranslatorUtils").toMWHangupReason(b)
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.HANGUP, a, {
            hangupRequest: b
        })
    }
    g.fromHangupResponse = a;
    g.toHangupRequest = b
}), 98);
__d("ZenonMWIceCandidateTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.jsonPayload.body.iceCandidateRequest;
        if (a) {
            a = {
                eventName: "iceCandidateRequest",
                iceCandidates: a.iceCandidateSdps.map(function(a) {
                    var b;
                    return {
                        candidateSdpString: (b = a.candidateSdpString) != null ? b : "",
                        sdpMid: a.sdpMid,
                        sdpMLineIndex: a.sdpMLineIndex
                    }
                })
            };
            b.push(a)
        }
        return b
    }

    function b(a) {
        var b = [];
        a = a.jsonPayload.header;
        a = {
            ackMessageId: a.transactionId,
            eventName: "iceCandidateResponse"
        };
        b.push(a);
        return b
    }

    function c(a) {
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ICE_CANDIDATE, a, {})
    }

    function e(a, b) {
        b = b.iceCandidates;
        b = b.map(function(a) {
            return {
                candidateSdpString: a.candidateSdpString,
                sdpMid: a.sdpMid,
                sdpMLineIndex: a.sdpMLineIndex
            }
        });
        b = {
            iceCandidateSdps: b
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ICE_CANDIDATE, a, {
            iceCandidateRequest: b
        })
    }
    g.fromIceCandidateRequest = a;
    g.fromIceCandidateResponse = b;
    g.toIceCandidateResponse = c;
    g.toIceCandidateRequest = e
}), 98);
__d("ZenonMWJoinTranslator", ["MultiwaySharedTypes", "RoboticsPermission", "ZenonAuditedCheckpointLogId", "ZenonDismissReason", "ZenonInfraActionsLogger", "ZenonJoiningContext", "ZenonMWCommonUtils", "ZenonMWJoinUtils", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils", "ZenonScreenShare", "gkx", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            e = a.jsonPayload.header,
            f = e.responseStatusCode,
            g = e.responseSubCode;
        if (f && f !== d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.OK) {
            g = "JOIN response status code: " + f + " subcode " + ((g = g) != null ? g : "[undefined]");
            c("ZenonInfraActionsLogger").logError({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                callType: "mw",
                checkpoint: "[ZP] Got non-OK " + g,
                errorDomain: "ZenonMWMessageTranslator.fromJoinResponse"
            });
            f = {
                detailedReasonFromMW: e.responseStatusMessage,
                eventName: "terminateRequest",
                fromJoinResponse: !0,
                reason: h(f, e.responseSubCode),
                shouldInformPeer: !1,
                subreason: g
            };
            b.push(f);
            return b
        }
        g = a.jsonPayload.body.joinResponse;
        if (!g) return b;
        f = (a = (f = g.answer) == null ? void 0 : f.sdpString) != null ? a : "";
        a = f !== "";
        d("ZenonMWTranslatorUtils").addStateStoreSignalingEvents(g.stateStore, b, !1, a);
        d("ZenonMWTranslatorUtils").maybeAddOverlayConfigServerUpdateRequest(b, e);
        var i = d("ZenonMWTranslatorUtils").fetchE2eeServerState(g.stateStore);
        e = {
            ackMessageId: e.transactionId,
            eventName: "localSdpResponse",
            hasAnswerInJoinResponse: a,
            source: "joinResponse"
        };
        b.push(e);
        if (a) {
            e = {
                sdp: f,
                type: "answer",
                version: d("ZenonMWCommonUtils").getSdpVersion(f)
            };
            a = d("ZenonMWTranslatorUtils").toZenonMediaStates(g.mediaStatusEx);
            f = g.renegotiationOffer;
            var j = null;
            f != null && f.sdpString != null && (j = {
                sdp: f.sdpString,
                type: "offer",
                version: d("ZenonMWCommonUtils").getSdpVersion(f.sdpString)
            });
            f = {
                e2eeServerState: i,
                eventName: "remoteSdpRequest",
                mediaPath: g.mediaPath,
                mediaStates: a,
                negotiateType: !1,
                renegotiationOffer: j,
                sdp: e,
                sdpOriginLocalId: g.sdpOriginLocalId,
                source: "joinResponse"
            };
            b.push(f)
        }
        i = {
            capabilities: {
                addParticipantEnabled: !0,
                cowatchEnabled: !0,
                cowatchGroupEnabled: !0,
                multipleVideoStreamsAllowed: g.multipleVideoStreamsAllowed
            },
            eventName: "capabilitiesRequest"
        };
        b.push(i);
        if (g.isPendingApproval) {
            a = {
                eventName: "pendingApprovalRequest"
            };
            b.push(a)
        }
        j = g.groupsOfUsers;
        var k = new Map();
        j.forEach(function(a) {
            var b = a.aliasId;
            a = a.users;
            b != null && a.forEach(function(a) {
                k.set(a, b)
            })
        });
        e = {
            actorRepresentatives: k,
            eventName: "clientInfoRequest",
            mediaPath: g.mediaPath,
            userCapabilities: new Map()
        };
        b.push(e);
        return b
    }

    function b(a, b, e, f) {
        var g, h = b.initialSyncStates,
            k = b.isSecondaryJoinRole,
            l = b.userCapabilities;
        g = {
            clientMediaMode: j(e.mediaMode),
            deviceCapabilities: [(g = d("ZenonMWMessageTypes")).ZenonMWCapability.SUPPORT_NEW_PARTICIPANT_STATES, g.ZenonMWCapability.REQUIRE_FULL_SDP_IN_SMU, g.ZenonMWCapability.SUPPORT_SDP_RENEGOTIATION, g.ZenonMWCapability.REQUIRE_FULL_SDP_IN_SMU_OPTIMIZED, g.ZenonMWCapability.SUPPORT_DELTA_SMU].concat(c("gkx")("25225") ? [d("ZenonMWMessageTypes").ZenonMWCapability.SUPPORT_PRECONNECT] : []),
            mediaStatus: d("ZenonMWTranslatorUtils").toMWMediaStatus(e.mediaStates),
            mediaStatusEx: d("ZenonMWTranslatorUtils").toMWMediaStatusEx(e.mediaStates),
            offer: {},
            syncPayload: h ? {
                stateStore: d("ZenonMWTranslatorUtils").toMWSyncStateStore(h)
            } : void 0,
            userCapabilities: l.get(a.userInfo.userID)
        };
        k != null && (g.endpointSettings = {
            joinMode: k ? d("ZenonMWMessageTypes").ZenonMWJoinMode.SECONDARY : d("ZenonMWMessageTypes").ZenonMWJoinMode.PRIMARY
        });
        h = b.isE2eeMandated === !0;
        g.e2eeEnforcement = {
            infraMandatedExpStatus: (l = b.e2eeInfraMandatedExpStatus) != null ? l : d("MultiwaySharedTypes").E2eeInfraMandatedExpStatus.NOT_SET,
            mode: h ? d("ZenonMWMessageTypes").ZenonMWE2eeMode.E2EE_MANDATED : d("ZenonMWMessageTypes").ZenonMWE2eeMode.E2EE_NOT_MANDATED
        };
        e.sdp.type === "offer" && (g.offer = {
            sdpString: e.sdp.sdp
        });
        d("ZenonMWJoinUtils").canUseMwpp(e.sdp.type) && (g.deviceCapabilities.push(d("ZenonMWMessageTypes").ZenonMWCapability.SUPPORT_MWPP), e.sdp.type === "answer" && (g.answer = {
            sdpString: e.sdp.sdp
        }), d("ZenonMWJoinUtils").canDeescalate() && g.deviceCapabilities.push(d("ZenonMWMessageTypes").ZenonMWCapability.SUPPORT_MWPP_DEESCALATION));
        (!d("ZenonScreenShare").screenShareWithReplaceTrack() || c("RoboticsPermission").is_authorized_robot) && g.deviceCapabilities.push(d("ZenonMWMessageTypes").ZenonMWCapability.SUPPORT_MULTIPLE_VIDEO_STREAMS);
        k = f == null ? void 0 : f.otherParticipants;
        k && (g.usersToCall = k);
        b = [];
        e = (l = f == null ? void 0 : f.roomInfo.context) != null ? l : a.roomInfo.context;
        if (e != null) {
            l = d("ZenonJoiningContext").convertCollisionToJoiningContext(e);
            h && (l.calling_tags = 2);
            b = [].concat(b, [{
                body: {
                    genericMessage: {
                        data: JSON.stringify(l),
                        topic: d("ZenonJoiningContext").JOINING_CONTEXT_TOPIC
                    }
                },
                header: {
                    topic_DEPRECATED: d("ZenonJoiningContext").JOINING_CONTEXT_TOPIC
                }
            }])
        }(f == null ? void 0 : f.appMessages) != null && (b = [].concat(b, d("ZenonMWTranslatorUtils").signalingMessageAppMessagesToMWAppMessages(f.appMessages, k)));
        g.appMessages = b;
        h = d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.JOIN, a, {
            joinRequest: g
        });
        e && e.serverInfoData != null && (h.jsonPayload.header.serverInfoData = e.serverInfoData);
        i(e, h.jsonPayload.header) && (h.jsonPayload.header.conferenceType = d("ZenonMWMessageTypes").ZenonMWConferenceType.ROOM);
        return h
    }

    function h(a, b) {
        if (b === d("ZenonMWMessageTypes").ZenonMWResponseSubCode.EXCEEDED_MAX_ALLOWED_PARTICIPANTS) return d("ZenonDismissReason").ZenonDismissReason.MaxAllowedParticipantsReached;
        if (b === d("ZenonMWMessageTypes").ZenonMWResponseSubCode.PRODUCT_SERVER_DEFINED_END_REASON) return d("ZenonDismissReason").ZenonDismissReason.ProductServerDefinedEndReason;
        switch (a) {
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.METHOD_NOT_ALLOWED:
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.UNAUTHORIZED:
                return d("ZenonDismissReason").ZenonDismissReason.NoPermission;
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.SERVICE_UNAVAILABLE:
                return d("ZenonDismissReason").ZenonDismissReason.SignalingMessageFailed;
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.OK:
                throw c("unrecoverableViolation")("Response status code is OK; should not return a dismiss reason", "rtc_www");
            default:
                c("ZenonInfraActionsLogger").logError({
                    auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                    callType: "mw",
                    error: "[ZP] Got unexpected JOIN response status: " + a + " subcode " + ((a = b) != null ? a : "[undefined]"),
                    errorDomain: "fromMWJoinResponseStatusToDismissReason"
                });
                return d("ZenonDismissReason").ZenonDismissReason.UnexpectedEndOfCall
        }
    }

    function i(a, b) {
        return ((a == null ? void 0 : a.peerID) != null || (a == null ? void 0 : a.groupThreadID) != null) && b.conferenceName == null
    }

    function j(a) {
        return a === "p2p" ? d("ZenonMWMessageTypes").ZenonMWMediaPath.P2P : d("ZenonMWMessageTypes").ZenonMWMediaPath.SFU
    }
    g.fromJoinResponse = a;
    g.toJoinRequest = b
}), 98);
__d("ZenonMWMessageMap", ["ZenonMWMessageTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c = Object.freeze((a = {}, a[(b = d("ZenonMWMessageTypes")).ZenonMWSignalingPayloadType.JOIN] = "JOIN", a[b.ZenonMWSignalingPayloadType.SERVER_MEDIA_UPDATE] = "SERVER_MEDIA_UPDATE", a[b.ZenonMWSignalingPayloadType.ICE_CANDIDATE] = "ICE_CANDIDATE", a[b.ZenonMWSignalingPayloadType.HANGUP] = "HANGUP", a[b.ZenonMWSignalingPayloadType.RING] = "RING", a[b.ZenonMWSignalingPayloadType.DISMISS] = "DISMISS", a[b.ZenonMWSignalingPayloadType.CONFERENCE_STATE] = "CONFERENCE_STATE", a[b.ZenonMWSignalingPayloadType.ADD_PARTICIPANTS] = "ADD_PARTICIPANTS", a[b.ZenonMWSignalingPayloadType.SUBSCRIPTION] = "SUBSCRIPTION", a[b.ZenonMWSignalingPayloadType.CLIENT_MEDIA_UPDATE] = "CLIENT_MEDIA_UPDATE", a[b.ZenonMWSignalingPayloadType.DATA_MESSAGE] = "DATA_MESSAGE", a[b.ZenonMWSignalingPayloadType.REMOVE_PARTICIPANTS] = "REMOVE_PARTICIPANTS", a[b.ZenonMWSignalingPayloadType.PING] = "PING", a[b.ZenonMWSignalingPayloadType.P2P_PROTOCOL] = "P2P_PROTOCOL", a[b.ZenonMWSignalingPayloadType.NOTIFY] = "NOTIFY", a[b.ZenonMWSignalingPayloadType.CONNECT] = "CONNECT", a[b.ZenonMWSignalingPayloadType.CLIENT_EVENT] = "CLIENT_EVENT", a[b.ZenonMWSignalingPayloadType.UNSUBSCRIBE] = "UNSUBSCRIBE", a[b.ZenonMWSignalingPayloadType.UPDATE] = "UPDATE", a[b.ZenonMWSignalingPayloadType.APPROVAL] = "APPROVAL", a[b.ZenonMWSignalingPayloadType.WAKEUP] = "WAKEUP", a));
    e = c;
    g["default"] = e
}), 98);
__d("ZenonMWMessageDebugLogger", ["Log", "LogHistory", "ODS", "RpWebStateMachineLoggingBlocklist", "ZenonAuditedCheckpointLogId", "ZenonIceStatsParser", "ZenonInfraActionsLogger", "ZenonMWMessageMap", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils", "formatDate", "isEmployeeTestUserZenonLogging"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function() {
        function a() {
            this.$1 = d("LogHistory").getInstance("webrtc"), this.$2 = new Set(c("RpWebStateMachineLoggingBlocklist").MESSAGE_TYPES)
        }
        var b = a.prototype;
        b.$3 = function(a, b, d) {
            b === void 0 && (b = !0);
            var e = c("formatDate")(new Date(), "[H:i:s:X]", {
                skipPatternLocalization: !0
            });
            this.$1.log("Console", e + " " + a);
            b && c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "[ZP] " + a,
                messageID: d
            })
        };
        b.$4 = function(a) {
            a = a.jsonPayload.header;
            return a.responseStatusCode != null
        };
        b.logMWMessage = function(a, b, d) {
            this.$5(a, b, d);
            if (d.jsonPayload == null || !c("isEmployeeTestUserZenonLogging")()) return;
            var e = d.jsonPayload.header,
                f = c("ZenonMWMessageMap")[e.type],
                g = this.$4(d) ? "RESPONSE" : "REQUEST";
            d = this.$6(d);
            a = "[ms] " + a + " [" + b + "] " + f + " " + g + " [retryCount: " + e.retryCount + (d != null ? " details: " + d : "") + "]";
            this.$2.has(f) || this.$3(a, !0, e.transactionId)
        };
        b.$5 = function(a, b, c) {
            a = this.$7(a, b, c);
            a !== null && (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_signaling", a)
        };
        b.$7 = function(a, b, e) {
            if (e.jsonPayload == null) return null;
            var f = e.jsonPayload,
                g = f.body;
            f = f.header;
            var h = "";
            switch (f.type) {
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DATA_MESSAGE:
                    if (g.dataMessageRequest) {
                        h = (g = d("ZenonMWTranslatorUtils").getGenericDataMessageTopic(g.dataMessageRequest)) != null ? g : "undefined"
                    }
                    break
            }
            g = this.$4(e) ? "RESPONSE" : "REQUEST";
            e = c("ZenonMWMessageMap")[f.type];
            if (h === "") return a + "-" + b + "-" + e + "-" + g;
            else return a + "-" + b + "-" + e + "-" + g + "-" + h
        };
        b.$6 = function(a) {
            if (a.jsonPayload == null) return null;
            var b = a.jsonPayload.header;
            switch (b.type) {
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.JOIN:
                    return this.$8(a);
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SERVER_MEDIA_UPDATE:
                    return this.$9(a);
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CLIENT_MEDIA_UPDATE:
                    return this.$10(a);
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SUBSCRIPTION:
                    return this.$11(a);
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ICE_CANDIDATE:
                    return this.$12(a);
                default:
                    return null
            }
        };
        b.$8 = function(a) {
            var b = a.jsonPayload,
                c = b.body;
            b = b.header;
            if (this.$4(a)) {
                return JSON.stringify({
                    hasAnswer: ((a = c.joinResponse) == null ? void 0 : a.answer) != null,
                    hasRenegotiationOffer: ((a = c.joinResponse) == null ? void 0 : a.renegotiationOffer) != null,
                    isPendingApproval: (a = c.joinResponse) == null ? void 0 : a.isPendingApproval,
                    multipleVideoStreamsAllowed: (a = c.joinResponse) == null ? void 0 : a.multipleVideoStreamsAllowed,
                    statusCode: b.responseStatusCode,
                    subCode: b.responseSubCode
                })
            }
            return JSON.stringify({
                deviceCapabilities: (a = c.joinRequest) == null ? void 0 : a.deviceCapabilities,
                sdpType: ((b = c.joinRequest) == null ? void 0 : b.offer) != null ? "offer" : ((a = c.joinRequest) == null ? void 0 : a.answer) != null ? "answer" : "null",
                userCapabilities: (b = c.joinRequest) == null ? void 0 : b.userCapabilities
            })
        };
        b.$9 = function(a) {
            var b = a.jsonPayload,
                c = b.body;
            b = b.header;
            if (this.$4(a)) {
                return JSON.stringify({
                    currentVersion: (a = c.serverMediaUpdateResponse) == null ? void 0 : a.currentVersion,
                    hasAnswer: ((a = c.serverMediaUpdateResponse) == null ? void 0 : a.answer) != null,
                    statusCode: b.responseStatusCode,
                    subCode: b.responseSubCode
                })
            }
            return JSON.stringify({
                fromVersion: (a = c.serverMediaUpdateRequest) == null ? void 0 : a.fromVersion,
                messageTags: b.messageTags,
                renegotiationRequested: (b = (a = c.serverMediaUpdateRequest) == null ? void 0 : a.renegotiationRequested) != null ? b : !1,
                sdpType: ((a = c.serverMediaUpdateRequest) == null ? void 0 : a.offer) ? "offer" : ((b = c.serverMediaUpdateRequest) == null ? void 0 : b.answer) ? "answer" : ((a = c.serverMediaUpdateRequest) == null ? void 0 : a.update) ? "delta" : "empty",
                toVersion: (a = (b = c.serverMediaUpdateRequest) == null ? void 0 : b.toVersion) != null ? a : ""
            })
        };
        b.$10 = function(a) {
            var b = a.jsonPayload,
                c = b.body;
            b = b.header;
            if (this.$4(a)) {
                return JSON.stringify({
                    currentVersion: (a = (a = c.clientMediaUpdateResponse) == null ? void 0 : a.currentVersion) != null ? a : "",
                    statusCode: b.responseStatusCode,
                    subCode: b.responseSubCode
                })
            }
            return JSON.stringify({
                fromVersion: (b = (a = c.clientMediaUpdateRequest) == null ? void 0 : a.fromVersion) != null ? b : "",
                toVersion: (b = (a = c.clientMediaUpdateRequest) == null ? void 0 : a.toVersion) != null ? b : ""
            })
        };
        b.$11 = function(a) {
            var b = a.jsonPayload.body;
            return this.$4(a) ? null : JSON.stringify({
                subscriptions: (b = (a = b.subscriptionRequest) == null ? void 0 : a.subscriptions) != null ? b : ""
            })
        };
        b.$12 = function(a) {
            var b = a.jsonPayload.body;
            if (this.$4(a)) return null;
            b = (a = b.iceCandidateRequest) == null ? void 0 : a.iceCandidateSdps.map(function(a) {
                a = a.candidateSdpString;
                if (a != null) return d("ZenonIceStatsParser").extractIceInfo(a)
            });
            return JSON.stringify({
                iceCandidates: b
            })
        };
        b.logSendMultiwayMessageFailure = function(a, b) {
            (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "send_message_failure"), h.flush(), c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                checkpoint: "Failed to send MW message of type " + b + ". Error msg: " + a + ":"
            })
        };
        return a
    }();
    b = new a();
    g["default"] = b
}), 98);
__d("ZenonMWMessageQPLLogger", ["DateConsts", "QPLMsgTypesSitevarConfig", "QPLUserFlow", "ZenonLoggingUtils", "ZenonMWMessageMap", "ZenonMWMessageReliabilityLogTypes", "getZenonMqttChannel", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 30 * d("DateConsts").MS_PER_SEC,
        i = c("getZenonMqttChannel")(),
        j = new Map();

    function a(a, b, e) {
        if (!d("ZenonLoggingUtils").shouldAllowLogging()) return;
        var f = a.jsonPayload.header,
            g = c("ZenonMWMessageMap")[f.type].toLowerCase();
        if (!c("QPLMsgTypesSitevarConfig").QPL_MSG_TYPES.includes(g)) return;
        f = k(f.transactionId);
        switch (b) {
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.RECEIVED_REQUEST:
                l(f, g, {
                    connectionState: (b = e == null ? void 0 : e.connectionState) != null ? b : "",
                    peerConnectionState: (b = e == null ? void 0 : e.peerConnectionState) != null ? b : "",
                    signalingState: (b = e == null ? void 0 : e.signalingState) != null ? b : ""
                }, a);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSED_REQUEST:
                m(f);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENDING_RESPONSE:
                n(f, a);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_RESPONSE:
                o(f, a);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SEND_RESPONSE_FAILED:
                p(f, a, e == null ? void 0 : e.errorMessage);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_REQUEST:
                q(f, g, {
                    connectionState: (b = e == null ? void 0 : e.connectionState) != null ? b : "",
                    peerConnectionState: (g = e == null ? void 0 : e.peerConnectionState) != null ? g : "",
                    signalingState: (b = e == null ? void 0 : e.signalingState) != null ? b : ""
                }, a);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENDING_REQUEST:
                r(f);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SEND_REQUEST_FAILED:
                s(f, e == null ? void 0 : e.errorMessage);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.RECEIVED_RESPONSE:
                t(f, a);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_SM_EVENT:
                u(f, e == null ? void 0 : e.smEvent);
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSED_SM_EVENT:
                v(f, e == null ? void 0 : e.smEvent);
                return;
            default:
                return
        }
    }

    function b(a, b) {
        if (!d("ZenonLoggingUtils").shouldAllowLogging()) return;
        c("QPLUserFlow").addAnnotations(c("qpl")._(398988976, "737"), {
            string: babelHelpers["extends"]({}, b)
        }, {
            instanceKey: +a
        })
    }

    function k(a) {
        a = isNaN(+a) ? 0 : +a;
        var b = 9223372036854776e3;
        return Math.round(a % b)
    }

    function l(a, b, d, e) {
        c("QPLUserFlow").start(c("qpl")._(398988976, "737"), {
            annotations: {
                "int": {
                    retryCount: e.jsonPayload.header.retryCount
                },
                int_array: {
                    messageTags: e.jsonPayload.header.messageTags
                },
                string: babelHelpers["extends"]({}, d, {
                    messageType: b,
                    mqttState: i.getConnectionState()
                })
            },
            instanceKey: a,
            timeoutInMs: h
        });
        if (e.jsonPayload.body.serverMediaUpdateRequest) {
            d = e.jsonPayload.body.serverMediaUpdateRequest;
            b = d.answer;
            e = d.offer;
            d = d.update;
            c("QPLUserFlow").addAnnotations(c("qpl")._(398988976, "737"), {
                string: {
                    sdpType: e ? "offer" : b ? "answer" : d ? "delta" : "empty"
                }
            }, {
                instanceKey: a
            })
        }
        e = {
            onMQTTStateChanged: function(b) {
                c("QPLUserFlow").addPoint(c("qpl")._(398988976, "737"), "mqtt_" + b, {
                    instanceKey: a
                })
            }
        };
        i.subscribeChannelEvents(e);
        j.set(a, e);
        return
    }

    function m(a) {
        c("QPLUserFlow").addPoint(c("qpl")._(398988976, "737"), "processed_request", {
            instanceKey: a
        })
    }

    function n(a, b) {
        b = b.jsonPayload.header;
        var d = b.responseStatusCode;
        b = b.responseSubCode;
        c("QPLUserFlow").addPoint(c("qpl")._(398988976, "737"), "sending_response", {
            instanceKey: a
        });
        c("QPLUserFlow").addAnnotations(c("qpl")._(398988976, "737"), {
            "int": {
                responseStatusCode: d,
                responseSubCode: b
            }
        }, {
            instanceKey: a
        })
    }

    function o(a, b) {
        b = b.jsonPayload.header;
        var d = b.responseStatusCode;
        b = b.responseSubCode;
        c("QPLUserFlow").endSuccess(c("qpl")._(398988976, "737"), {
            annotations: {
                "int": {
                    responseStatusCode: d,
                    responseSubCode: b
                }
            },
            instanceKey: a
        });
        d = j.get(a);
        d && (i.unsubscribeChannelEvents(d), j["delete"](a))
    }

    function p(a, b, d) {
        b = b.jsonPayload.header;
        var e = b.responseStatusCode;
        b = b.responseSubCode;
        c("QPLUserFlow").endFailure(c("qpl")._(398988976, "737"), "send_response_failed", {
            annotations: {
                "int": {
                    responseStatusCode: e,
                    responseSubCode: b
                },
                string: {
                    errorMessage: d
                }
            },
            instanceKey: a
        });
        e = j.get(a);
        e && (i.unsubscribeChannelEvents(e), j["delete"](a))
    }

    function q(a, b, d, e) {
        c("QPLUserFlow").start(c("qpl")._(398988976, "737"), {
            annotations: {
                "int": {
                    retryCount: e.jsonPayload.header.retryCount
                },
                int_array: {
                    messageTags: e.jsonPayload.header.messageTags
                },
                string: babelHelpers["extends"]({}, d, {
                    messageType: b,
                    mqttState: i.getConnectionState()
                })
            },
            instanceKey: a,
            timeoutInMs: h
        })
    }

    function r(a) {
        c("QPLUserFlow").addPoint(c("qpl")._(398988976, "737"), "sending_request", {
            instanceKey: a
        })
    }

    function s(a, b) {
        c("QPLUserFlow").endFailure(c("qpl")._(398988976, "737"), "send_request_failed", {
            annotations: {
                string: {
                    errorMessage: b
                }
            },
            instanceKey: a
        })
    }

    function t(a, b) {
        b = b.jsonPayload.header;
        var d = b.responseStatusCode;
        b = b.responseSubCode;
        c("QPLUserFlow").endSuccess(c("qpl")._(398988976, "737"), {
            annotations: {
                "int": {
                    responseStatusCode: d,
                    responseSubCode: b
                }
            },
            instanceKey: a
        })
    }

    function u(a, b) {
        b != null && c("QPLUserFlow").addPoint(c("qpl")._(398988976, "737"), "sent_sm_event:" + b, {
            instanceKey: a
        })
    }

    function v(a, b) {
        b != null && c("QPLUserFlow").addPoint(c("qpl")._(398988976, "737"), "processed_sm_event:" + b, {
            instanceKey: a
        })
    }
    g.log = a;
    g.updateState = b
}), 98);
__d("ZenonMWMessageReliabilityLogger", ["ODS", "ZenonArmadilloLoggingChecks", "ZenonMWMessageMap", "ZenonMWMessageQPLLogger", "ZenonMWMessageReliabilityLogTypes", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new Map(),
        j = new Map(),
        k = new Map();

    function a(a) {
        k.set(a, !0)
    }

    function b(a, b, c) {
        a = j.get(a);
        if (!a) return;
        v(a, b, c)
    }

    function e(a) {
        r(a) ? v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.RECEIVED_RESPONSE) : v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.RECEIVED_REQUEST)
    }

    function f(a) {
        r(a) ? v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSING_RESPONSE) : v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSING_REQUEST)
    }

    function l(a) {
        r(a) || v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.REQUEST_AFTER_NULL_CHECK)
    }

    function m(a) {
        r(a) || v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.REQUEST_AFTER_TRANSLATION)
    }

    function n(a) {
        r(a) ? v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSED_RESPONSE) : v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSED_REQUEST)
    }

    function o(a) {
        r(a) ? v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENDING_RESPONSE) : v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENDING_REQUEST)
    }

    function p(a) {
        r(a) ? v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_RESPONSE) : v(a, d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_REQUEST)
    }

    function q(a, b) {
        var c = r(a) ? d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SEND_RESPONSE_FAILED : d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SEND_REQUEST_FAILED;
        v(a, c, {
            errorMessage: b
        })
    }

    function r(a) {
        a = a.jsonPayload.header;
        return a.responseStatusCode != null
    }

    function s(a, b) {
        var e = a.jsonPayload.header;
        e = c("ZenonMWMessageMap")[e.type].toLowerCase();
        a = r(a) ? "response" : "request";
        switch (b) {
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.RECEIVED_REQUEST:
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.RECEIVED_RESPONSE:
                (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "receive_" + a + "_" + e);
                (h || (h = d("ODS"))).flush();
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSING_REQUEST:
                (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "processing_" + a + "_" + e);
                (h || (h = d("ODS"))).flush();
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSED_REQUEST:
                (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "processed_" + a + "_" + e);
                (h || (h = d("ODS"))).flush();
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENDING_RESPONSE:
                (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "sending_" + a + "_" + e);
                (h || (h = d("ODS"))).flush();
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.REQUEST_AFTER_TRANSLATION:
                (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "after_translation_" + a + "_" + e);
                (h || (h = d("ODS"))).flush();
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.REQUEST_AFTER_NULL_CHECK:
                (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "after_null_check_" + a + "_" + e);
                (h || (h = d("ODS"))).flush();
                return;
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_RESPONSE:
            case d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_REQUEST:
                (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "sent_" + a + "_" + e);
                (h || (h = d("ODS"))).flush();
                return;
            default:
                return
        }
    }
    var t = {
        connectionState: "",
        peerConnectionState: "",
        signalingState: ""
    };

    function u(a) {
        var b = babelHelpers["extends"]({}, t, a);
        if (t.connectionState !== b.connectionState || t.peerConnectionState !== b.peerConnectionState || t.signalingState !== b.signalingState) {
            t = b;
            for (var b = i.keys(), c = Array.isArray(b), e = 0, b = c ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (c) {
                    if (e >= b.length) break;
                    f = b[e++]
                } else {
                    e = b.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                d("ZenonMWMessageQPLLogger").updateState(f, a)
            }
        }
    }

    function v(a, b, e) {
        var f;
        if (c("justknobx")._("855")) return;
        var g = a.jsonPayload.header;
        f = (f = i.get(g.transactionId)) != null ? f : new Set();
        i.set(g.transactionId, f);
        if (b !== d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.SENT_SM_EVENT && b !== d("ZenonMWMessageReliabilityLogTypes").ZenonMWMessageReliabilityEvent.PROCESSED_SM_EVENT && f.has(b)) return;
        f.add(b);
        j.set(g.transactionId, a);
        s(a, b);
        f = (g = k.get((f = g.clientSessionId) != null ? f : "")) != null ? g : !1;
        (!f || d("ZenonArmadilloLoggingChecks").isArmadilloQPLLoggingEnabled()) && d("ZenonMWMessageQPLLogger").log(a, b, babelHelpers["extends"]({}, e, t))
    }
    g.setE2eeIsMandatedForCall = a;
    g.logEventForTxid = b;
    g.logReceivedMessage = e;
    g.logProcessingMessage = f;
    g.logMessageAfterNullCheck = l;
    g.logMessageAfterTranslation = m;
    g.logProcessedMessage = n;
    g.logSendingMessage = o;
    g.logSentMessage = p;
    g.logSendMessageFailed = q;
    g.updateState = u
}), 98);
__d("ZenonMWPingTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.jsonPayload.header;
        a = {
            ackMessageId: a.transactionId,
            eventName: "pingResponse"
        };
        b.push(a);
        return b
    }

    function b(a) {
        var b = Object.freeze({});
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.PING, a, {
            pingRequest: b
        })
    }
    g.fromPingResponse = a;
    g.toPingRequest = b
}), 98);
__d("ZenonMWRingTranslator", ["ZenonMWCommonUtils", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, c) {
        if (b) return {
            groupThreadID: b.groupThreadId,
            peerID: b.peerId,
            serverInfoData: c
        };
        b = d("ZenonMWTranslatorUtils").getCollisionContextFromAppMessages(a);
        b && (b.serverInfoData = c);
        return (a = b) != null ? a : {
            groupThreadID: null,
            peerID: null,
            serverInfoData: c
        }
    }

    function a(a, b) {
        var c = [];
        a = a.jsonPayload;
        var e = a.body;
        a = a.header;
        e = e.ringRequest;
        if (e) {
            var f = e.appMessages,
                g = e.caller,
                i = e.e2eeEnforcement,
                j = e.otherParticipants,
                k = e.ringType,
                l = e.sdpOriginLocalId,
                m = e.threadIdInfo;
            g = g;
            k = k === d("ZenonMWMessageTypes").ZenonMWRingType.PEER_VIDEO_CALL || k === d("ZenonMWMessageTypes").ZenonMWRingType.GROUP_VIDEO_CALL || k === d("ZenonMWMessageTypes").ZenonMWRingType.LIVE_STREAM || k === d("ZenonMWMessageTypes").ZenonMWRingType.PEER_ESCALATED_AUDIO_CALL;
            var n = a.conferenceName;
            a = a.serverInfoData;
            m = h(f, m, a);
            var o = d("ZenonMWTranslatorUtils").getRoomMetadataFromAppMessages(f);
            g = {
                actorID: b.actorID,
                e2eeInfraMandatedExpStatus: i == null ? void 0 : i.infraMandatedExpStatus,
                eventName: "inviteRequest",
                inviterID: g,
                isE2eeMandated: (i == null ? void 0 : i.mode) === d("ZenonMWMessageTypes").ZenonMWE2eeMode.E2EE_MANDATED,
                isRemoteOfferer: !1,
                otherParticipants: j,
                requestingVideo: k,
                roomInfo: babelHelpers["extends"]({
                    context: m,
                    name: n
                }, o == null ? {} : {
                    room: o,
                    sender: o.sender
                }),
                serverInfoData: a,
                userID: b.userInfo.userID
            };
            f != null && (g.appMessages = d("ZenonMWTranslatorUtils").mwAppMessagesToSignalingAppMessages(f));
            c.push(g);
            k = (j = (i = e.offer) == null ? void 0 : i.sdpString) != null ? j : "";
            n = (m = e.mediaStatusEx) != null ? m : null;
            if (k !== "" && n != null) {
                o = {
                    sdp: k,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(k)
                };
                a = d("ZenonMWTranslatorUtils").toZenonMediaStates(n);
                b = {
                    eventName: "remoteSdpRequest",
                    mediaPath: e.mediaPath,
                    mediaStates: a,
                    negotiateType: !1,
                    sdp: o,
                    sdpOriginLocalId: l,
                    source: "ringRequest"
                };
                c.push(b)
            }
        }
        return c
    }

    function b(a, b) {
        b = b.status;
        b === "IN_ANOTHER_CALL" && (a.signalingID = null);
        b = d("ZenonMWTranslatorUtils").toMWDeviceStatus(b);
        b = {
            deviceCapabilities: [d("ZenonMWMessageTypes").ZenonMWCapability.SUPPORT_AUDIO_DEPRECATED, d("ZenonMWMessageTypes").ZenonMWCapability.SUPPORT_VIDEO_DEPRECATED],
            deviceStatus: b
        };
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.RING, a, {
            ringResponse: b
        })
    }
    g.fromRingRequest = a;
    g.toRingResponse = b
}), 98);
__d("ZenonMWServerMediaUpdateTranslator", ["FBLogger", "ZenonAuditedCheckpointLogId", "ZenonInfraActionsLogger", "ZenonMWCommonUtils", "ZenonMWMessageReliabilityLogger", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            e = a.jsonPayload,
            f = e.body;
        e = e.header;
        f = f.serverMediaUpdateRequest;
        var g = e.messageTags,
            i = e.transactionId;
        if (!f) return b;
        var j = f.answer,
            k = f.fromVersion,
            l = f.mediaPath,
            m = f.mediaStatus,
            n = f.multipleVideoStreamsAllowed,
            o = f.offer,
            p = f.prAnswer,
            q = f.renegotiationRequested,
            r = f.sdpOriginLocalId,
            s = f.stateStore,
            t = f.toVersion;
        f = f.update;
        o = (o = o == null ? void 0 : o.sdpString) != null ? o : "";
        j = (j = j == null ? void 0 : j.sdpString) != null ? j : "";
        p = (p = p == null ? void 0 : p.sdpString) != null ? p : "";
        var u = function() {
                d("ZenonMWMessageReliabilityLogger").logProcessedMessage(a)
            },
            v = o !== "",
            w = j !== "",
            x = c("gkx")("25225") && p !== "",
            y = f !== null;
        y = v || w || x || y;
        d("ZenonMWTranslatorUtils").addStateStoreSignalingEvents(s, b, !1, y);
        y = d("ZenonMWTranslatorUtils").fetchE2eeServerState(s);
        if (q) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 1: renegotationRequested"
            });
            q = {
                ackMessageId: i,
                eventName: "initiateRenegotiationRequest",
                fromVersion: k,
                hasRemoteOffer: o !== "",
                mediaPath: l,
                messageTags: (s = g) != null ? s : [],
                onProcessed: u,
                version: t
            };
            b.push(q);
            if (v) {
                s = h(i, k, l, m, {
                    sdp: o,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(o)
                }, r, u, g, y);
                b.push(s)
            }
        } else if (w) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 2: answer SDP"
            });
            q = h(i, k, l, m, {
                sdp: j,
                type: "answer",
                version: d("ZenonMWCommonUtils").getSdpVersion(j)
            }, r, u, g, y);
            if (q.sdp.sdp != null && d("ZenonMWCommonUtils").isUnifiedPlan(q.sdp.sdp)) {
                s = {
                    sdp: j,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(j)
                };
                q.renegotiationOffer = s
            }
            b.push(q)
        } else if (v) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 3: offer SDP"
            });
            w = h(i, k, l, m, {
                sdp: o,
                type: "offer",
                version: d("ZenonMWCommonUtils").getSdpVersion(o)
            }, r, u, g, y);
            b.push(w)
        } else if (f) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 4: delta SDP"
            });
            j = h(i, k, l, m, {
                type: "offer",
                update: f,
                version: t
            }, r, u, g, y);
            b.push(j)
        } else if (x) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 5: prAnswer SDP"
            });
            s = h(i, k, l, m, {
                sdp: p,
                type: "pranswer",
                version: d("ZenonMWCommonUtils").getSdpVersion(p)
            }, r, u, g, y);
            b.push(s)
        } else if (m) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 6: media update"
            });
            v = {
                ackMessageId: i,
                eventName: "mediaUpdateRequest",
                mediaStates: d("ZenonMWTranslatorUtils").toZenonMediaStates(m, k, t),
                messageTags: (q = g) != null ? q : [],
                onProcessed: u
            };
            b.push(v)
        } else {
            o = "Warning: unsupported SMU type. TXID: " + i;
            c("FBLogger")("rpweb").warn(o);
            c("ZenonInfraActionsLogger").logError({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                error: o,
                errorDomain: "ZenonMWServerMediaUpdateTranslator"
            })
        }
        d("ZenonMWTranslatorUtils").maybeAddOverlayConfigServerUpdateRequest(b, e);
        f = {
            capabilities: {
                multipleVideoStreamsAllowed: n
            },
            eventName: "capabilitiesRequest",
            messageTags: (w = g) != null ? w : []
        };
        b.push(f);
        return b
    }

    function h(a, b, c, e, f, g, h, i, j) {
        return {
            ackMessageId: a,
            e2eeServerState: j,
            eventName: "remoteSdpRequest",
            fromVersion: b,
            mediaPath: c,
            mediaStates: d("ZenonMWTranslatorUtils").toZenonMediaStates(e),
            messageTags: (a = i) != null ? a : [],
            negotiateType: !1,
            onProcessed: h,
            sdp: f,
            sdpOriginLocalId: g,
            source: "serverMediaUpdateRequest"
        }
    }

    function b(a, b, c, e) {
        return i(a, b.acknowledgedVersion, d("ZenonMWTranslatorUtils").toMWResponseStatusCode(b.statusCode), d("ZenonMWTranslatorUtils").toMWResponseStatusSubCode(b.subCode), c, e)
    }

    function e(a, b) {
        return i(a, b.acknowledgedVersion, d("ZenonMWTranslatorUtils").toMWResponseStatusCode(b.statusCode), d("ZenonMWTranslatorUtils").toMWResponseStatusSubCode(b.subCode))
    }

    function f(a, b) {
        return i(a, b.acknowledgedVersion, (a = b.responseStatusCode) != null ? a : d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.CONDITIONAL_REQUEST_FAILED, b.responseSubCode)
    }

    function i(a, b, c, e, f, g) {
        b = {
            currentVersion: b
        };
        f && (b.mediaStatus = d("ZenonMWTranslatorUtils").toMWClientMediaStatus(f));
        g && (b.answer = {
            sdpString: g.sdp
        });
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SERVER_MEDIA_UPDATE, a, {
            serverMediaUpdateResponse: b
        }, c, e)
    }
    g.fromServerMediaUpdateRequest = a;
    g.toServerMediaUpdateResponse = b;
    g.toServerMediaUpdateRenegotiationResponse = e;
    g.toServerMediaUpdateNoSdpResponse = f
}), 98);
__d("ZenonMWStateSyncTranslator", ["RequestStreamBodyUtils", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils", "ZenonStateSyncPayloadSerializer"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = a.jsonPayload;
        var b = a.body.updateResponse;
        a = a.header.transactionId;
        if (!b) return [];
        var c = b.topic;
        b = b.version;
        a = {
            ackMessageId: a,
            eventName: "stateSyncUpdateResponse",
            topic: c,
            version: b
        };
        return [a]
    }

    function b(a) {
        a = a.jsonPayload.body.notifyRequest;
        if (!a) return [];
        var b = [];
        if (a.syncPayload != null) d("ZenonMWTranslatorUtils").addStateStoreSignalingEvents(a.syncPayload.stateStore, b, !0, !1);
        else {
            var c = a.data,
                e = a.topic;
            a = a.version;
            c = {
                data: d("ZenonStateSyncPayloadSerializer").stateSyncStringToUint8Array(c),
                eventName: "stateSyncNotifyRequest",
                responseRequired: !0,
                topic: e,
                version: a
            };
            b.push(c)
        }
        return b
    }

    function c(a) {
        a = a.jsonPayload;
        var b = a.body.unsubscribeResponse;
        a = a.header.transactionId;
        if (!b) return [];
        var c = b.topic;
        b = b.version;
        a = {
            ackMessageId: a,
            eventName: "stateSyncUnsubscribeResponse",
            topic: c,
            version: b
        };
        return [a]
    }

    function e(a, b) {
        var c = b.data,
            e = b.topic;
        b = b.version;
        c = {
            data: c ? d("RequestStreamBodyUtils").uint8ArrayToBase64(c) : void 0,
            topic: e,
            version: b
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.UPDATE, a, {
            updateRequest: c
        })
    }

    function f(a, b) {
        var c = b.topic;
        b = b.version;
        c = {
            topic: c,
            version: b
        };
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.NOTIFY, a, {
            notifyResponse: c
        })
    }

    function h(a, b) {
        var c = b.topic;
        b = b.version;
        c = {
            topic: c,
            version: b
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.UNSUBSCRIBE, a, {
            unsubscribeRequest: c
        })
    }
    g.fromUpdateResponse = a;
    g.fromNotifyRequest = b;
    g.fromUnsubscribeResponse = c;
    g.toUpdateRequest = e;
    g.toNotifyResponse = f;
    g.toUnsubscribeRequest = h
}), 98);
__d("ZenonMWSubscriptionTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = b.subscriptions;
        b = {
            subscriptions: b
        };
        return d("ZenonMWTranslatorUtils").createMWRequest(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SUBSCRIPTION, a, {
            subscriptionRequest: b
        })
    }
    g.toSubscriptionRequest = a
}), 98);
__d("ZenonMWWakeupTranslator", ["ZenonMWMessageTypes", "ZenonMWTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.jsonPayload.header;
        a = {
            ackMessageId: a.transactionId,
            eventName: "wakeupRequest"
        };
        b.push(a);
        return b
    }

    function b(a) {
        var b = Object.freeze({});
        return d("ZenonMWTranslatorUtils").createMWResponse(d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.WAKEUP, a, {
            wakeupResponse: b
        })
    }
    g.fromWakeupRequest = a;
    g.toWakeupResponse = b
}), 98);
__d("ZenonMWMessageTranslator", ["FBLogger", "ZenonActorHooks", "ZenonMWAddRemoveParticipantsTranslator", "ZenonMWApprovalTranslator", "ZenonMWClientEventTranslator", "ZenonMWClientMediaUpdateTranslator", "ZenonMWConferenceStateTranslator", "ZenonMWDataMessageTranslator", "ZenonMWDismissTranslator", "ZenonMWHangupTranslator", "ZenonMWIceCandidateTranslator", "ZenonMWJoinTranslator", "ZenonMWMessageTypes", "ZenonMWPingTranslator", "ZenonMWRingTranslator", "ZenonMWServerMediaUpdateTranslator", "ZenonMWStateSyncTranslator", "ZenonMWSubscriptionTranslator", "ZenonMWTranslatorUtils", "ZenonMWWakeupTranslator", "ZenonSignalingMessage", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.getHeader();
        a = a.getEvents();
        if (a.length === 0) throw c("unrecoverableViolation")("Unexpected Translation: called toMWMessage with empty signaling events", "rtc_www");
        else {
            var e = a[0];
            switch (e.eventName) {
                case "addParticipantsRequest":
                    return d("ZenonMWAddRemoveParticipantsTranslator").toAddParticipantsRequest(b, e);
                case "clientEventRequest":
                    return d("ZenonMWClientEventTranslator").toClientEventRequest(b, e);
                case "clientInfoRequest":
                    if (a.length >= 2 && a[1].eventName === "localSdpRequest" && (a[1].sdp.type === "offer" || a[1].sdp.type === "answer")) return d("ZenonMWJoinTranslator").toJoinRequest(b, e, a[1]);
                    break;
                case "genericDataMessageRequest":
                    return d("ZenonMWDataMessageTranslator").toDataMessageRequest(b, e);
                case "inviteRequest":
                    if (a.length >= 3 && a[1].eventName === "clientInfoRequest" && a[2].eventName === "localSdpRequest" && a[2].sdp.type === "offer") return d("ZenonMWJoinTranslator").toJoinRequest(b, a[1], a[2], e);
                    break;
                case "genericDataMessageResponse":
                    return d("ZenonMWDataMessageTranslator").toDataMessageResponse(b);
                case "inviteResponse":
                    return d("ZenonMWRingTranslator").toRingResponse(b, e);
                case "dismissResponse":
                    return d("ZenonMWDismissTranslator").toDismissResponse(b);
                case "initiateRenegotiationResponse":
                    if (a.length >= 3 && a[1].eventName === "remoteSdpResponse" && a[2].eventName === "localSdpRequest" && a[2].sdp.type === "answer") return d("ZenonMWServerMediaUpdateTranslator").toServerMediaUpdateResponse(b, a[1], a[2].mediaStates, a[2].sdp);
                    else return d("ZenonMWServerMediaUpdateTranslator").toServerMediaUpdateRenegotiationResponse(b, e);
                case "iceCandidateRequest":
                    return d("ZenonMWIceCandidateTranslator").toIceCandidateRequest(b, e);
                case "iceCandidateResponse":
                    return d("ZenonMWIceCandidateTranslator").toIceCandidateResponse(b);
                case "localSdpRequest":
                    return d("ZenonMWClientMediaUpdateTranslator").toClientMediaUpdateRequest(b, e.mediaStates, e.sdp);
                case "mediaUpdateRequest":
                    return d("ZenonMWClientMediaUpdateTranslator").toClientMediaUpdateRequest(b, e.mediaStates);
                case "mediaUpdateResponse":
                    return d("ZenonMWServerMediaUpdateTranslator").toServerMediaUpdateNoSdpResponse(b, e);
                case "participantUpdateResponse":
                    return d("ZenonMWConferenceStateTranslator").toConferenceStateResponse(b, e);
                case "pingRequest":
                    return d("ZenonMWPingTranslator").toPingRequest(b);
                case "remoteSdpResponse":
                    return e.type === "offer" && (a.length >= 2 && a[1].eventName === "localSdpRequest" && a[1].sdp.type === "answer") ? a[1].mediaMode !== "p2p" ? d("ZenonMWServerMediaUpdateTranslator").toServerMediaUpdateResponse(b, e, a[1].mediaStates) : d("ZenonMWServerMediaUpdateTranslator").toServerMediaUpdateResponse(b, e, a[1].mediaStates, a[1].sdp) : d("ZenonMWServerMediaUpdateTranslator").toServerMediaUpdateResponse(b, e);
                case "removeParticipantsRequest":
                    return d("ZenonMWAddRemoveParticipantsTranslator").toRemoveParticipantsRequest(b, e);
                case "stateSyncNotifyResponse":
                    return d("ZenonMWStateSyncTranslator").toNotifyResponse(b, e);
                case "stateSyncUnsubscribeRequest":
                    return d("ZenonMWStateSyncTranslator").toUnsubscribeRequest(b, e);
                case "stateSyncUpdateRequest":
                    return d("ZenonMWStateSyncTranslator").toUpdateRequest(b, e);
                case "subscriptionRequest":
                    return d("ZenonMWSubscriptionTranslator").toSubscriptionRequest(b, e);
                case "terminateRequest":
                    return d("ZenonMWHangupTranslator").toHangupRequest(b, e);
                case "usersApprovalRequest":
                    return d("ZenonMWApprovalTranslator").toApprovalRequest(b, e);
                case "wakeupResponse":
                    return d("ZenonMWWakeupTranslator").toWakeupResponse(b)
            }
        }
        return null
    }

    function b(a) {
        var b = a.jsonPayload.header,
            e = h(b);
        if (e != null) {
            c("FBLogger")("rtc_www").info("Ignoring JSON MW message; receiver does not match self ID: " + e, "rtc_www");
            return null
        }
        e = b.type;
        var f = b.responseStatusCode == null;
        b = d("ZenonMWTranslatorUtils").mwMessageHeaderToSignalingMessageHeader(b);
        var g = [];
        switch (e) {
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.RING:
                f && (g = d("ZenonMWRingTranslator").fromRingRequest(a, b));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DISMISS:
                f && (g = d("ZenonMWDismissTranslator").fromDismissRequest(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.JOIN:
                f || (g = d("ZenonMWJoinTranslator").fromJoinResponse(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ICE_CANDIDATE:
                f ? g = d("ZenonMWIceCandidateTranslator").fromIceCandidateRequest(a) : g = d("ZenonMWIceCandidateTranslator").fromIceCandidateResponse(a);
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CONFERENCE_STATE:
                f && (g = d("ZenonMWConferenceStateTranslator").fromConferenceStateRequest(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CLIENT_MEDIA_UPDATE:
                f || (g = d("ZenonMWClientMediaUpdateTranslator").fromClientMediaUpdateResponse(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SERVER_MEDIA_UPDATE:
                f && (g = d("ZenonMWServerMediaUpdateTranslator").fromServerMediaUpdateRequest(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.PING:
                f || (g = d("ZenonMWPingTranslator").fromPingResponse(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.HANGUP:
                f || (g = d("ZenonMWHangupTranslator").fromHangupResponse(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DATA_MESSAGE:
                f && (g = d("ZenonMWDataMessageTranslator").fromDataMessageRequest(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.UPDATE:
                f || (g = d("ZenonMWStateSyncTranslator").fromUpdateResponse(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.UNSUBSCRIBE:
                f || (g = d("ZenonMWStateSyncTranslator").fromUnsubscribeResponse(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.NOTIFY:
                f && (g = d("ZenonMWStateSyncTranslator").fromNotifyRequest(a));
                break;
            case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.WAKEUP:
                f && (g = d("ZenonMWWakeupTranslator").fromWakeupRequest(a))
        }
        return new(c("ZenonSignalingMessage"))(b, g)
    }

    function h(a) {
        var b, c = a.receiverUserId;
        if (d("ZenonActorHooks").ZenonActor.isInstagramUser() || d("ZenonActorHooks").ZenonActor.isOculusUser() || c == null) return null;
        if (c === d("ZenonActorHooks").ZenonActor.getID() || ((b = a.receiver) == null ? void 0 : b.baseId) === d("ZenonActorHooks").ZenonActor.getAccountID()) return null;
        if (c !== d("ZenonActorHooks").ZenonActor.getID() && ((b = a.receiver) == null ? void 0 : b.baseId) == null) return "receiverUserId mismatch and missing header.receiver.baseId";
        return c !== d("ZenonActorHooks").ZenonActor.getID() && ((b = a.receiver) == null ? void 0 : b.baseId) !== d("ZenonActorHooks").ZenonActor.getAccountID() ? "receiverUserId mismatch and mismatched header.receiver.baseId" : "unknown error"
    }
    g.toMWMessage = a;
    g.toSignalingMessage = b
}), 98);