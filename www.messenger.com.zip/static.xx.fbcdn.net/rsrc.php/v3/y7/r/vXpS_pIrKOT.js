; /*FB_PKG_DELIM*/

__d("GHLShouldChangeSponsoredDataFieldName.relayprovider", ["MetaConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("MetaConfig")._("34") && c("MetaConfig")._("70")
    }
    g.get = a
}), 98);
__d("SecurePostMessage", ["invariant"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "*";
    a = {
        sendMessageToSpecificOrigin: function(a, b, c, d) {
            c !== h || g(0, 21157), a.postMessage(b, c, d)
        },
        sendMessageForCurrentOrigin: function(a, b) {
            a.postMessage(b)
        },
        sendMessageAllowAnyOrigin_UNSAFE: function(a, b, c) {
            a.postMessage(b, h, c)
        }
    };
    e.exports = a
}), null);
__d("SecureMessageListener", ["SecurePostMessage", "URI"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function() {
        function a(a) {
            var b = this;
            this.$3 = null;
            this.$4 = !1;
            this.$1 = a;
            this.$5 = function(a) {
                b.run(a)
            }
        }
        var b = a.prototype;
        b.setEventHandler = function(a) {
            this.$2 = a;
            return this
        };
        b.setSupportedOrigins = function(a) {
            this.$3 = a;
            return this
        };
        b.skipOriginCheck_UNSAFE = function() {
            this.$4 = !0;
            return this
        };
        b.beginListening = function() {
            this.$1.addEventListener("message", this.$5);
            return this
        };
        b.stopListening = function() {
            try {
                this.$1.removeEventListener("message", this.$5)
            } catch (a) {
                if (!(a instanceof TypeError)) throw a
            }
            return this
        };
        b.run = function(a) {
            if (this.$3 == null || this.$3.length === 0) {
                if (!this.$4 && a.origin !== this.$1.location.origin) return
            } else if (!this.isSupportedOrigin(this.$3, a.origin)) return;
            if (this.$2) {
                var b = function(b) {
                    d("SecurePostMessage").sendMessageToSpecificOrigin(a.source, b, a.origin)
                };
                this.$2(a, b)
            }
        };
        b.isSupportedOrigin = function(a, b) {
            if (!new RegExp("^https://").test(b)) return !1;
            var d = new(h || (h = c("URI")))(b);
            return a.some(function(a) {
                return d.isSubdomainOfDomain(a)
            })
        };
        return a
    }();
    g["default"] = a
}), 98);