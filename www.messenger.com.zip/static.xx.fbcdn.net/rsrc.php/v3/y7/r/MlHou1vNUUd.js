; /*FB_PKG_DELIM*/

__d("LSDeletePollAttachment", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return !1 === !0 ? b.sequence([function(c) {
                return b.filter(b.db.table(223).fetch([
                    [
                        [a[2]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.pollId, a[2]) && b.i64.eq(c.threadKey, a[0])
                }).next().then(function(c, d) {
                    var e = c.done;
                    c = c.value;
                    return e ? b.forEach(b.filter(b.db.table(16).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(c) {
                        return b.i64.eq(c.threadKey, a[0]) && c.attachmentFbid === a[1] && (b.i64.eq(c.attachmentType, b.i64.cast([0, 7])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 0]))) && c.hasMedia === !1 && c.hasXma === !0 && b.i64.eq(c.ephemeralMediaState, void 0)
                    }), function(a) {
                        return a["delete"]()
                    }) : (d = c.item, b.forEach(b.filter(b.db.table(16).fetch([
                        [
                            [a[0], d.lastUpdateMessageId, a[1]]
                        ]
                    ]), function(c) {
                        return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && c.messageId === d.lastUpdateMessageId && c.attachmentFbid === a[1] && (b.i64.eq(c.attachmentType, b.i64.cast([0, 7])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 0]))) && c.hasMedia === !1 && c.hasXma === !0 && b.i64.eq(c.ephemeralMediaState, void 0)
                    }), function(a) {
                        return a["delete"]()
                    }))
                })
            }, function(c) {
                return b.filter(b.db.table(38).fetch([
                    [
                        [a[2]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.pollId, a[2]) && b.i64.eq(c.threadKey, a[0])
                }).next().then(function(c, d) {
                    var e = c.done;
                    c = c.value;
                    return e ? b.forEach(b.filter(b.db.table(16).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(c) {
                        return b.i64.eq(c.threadKey, a[0]) && c.attachmentFbid === a[1] && (b.i64.eq(c.attachmentType, b.i64.cast([0, 7])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 0]))) && c.hasMedia === !1 && c.hasXma === !0 && b.i64.eq(c.ephemeralMediaState, void 0)
                    }), function(a) {
                        return a["delete"]()
                    }) : (d = c.item, b.forEach(b.filter(b.db.table(16).fetch([
                        [
                            [a[0], d.lastUpdateMessageId, a[1]]
                        ]
                    ]), function(c) {
                        return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && c.messageId === d.lastUpdateMessageId && c.attachmentFbid === a[1] && (b.i64.eq(c.attachmentType, b.i64.cast([0, 7])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 0]))) && c.hasMedia === !1 && c.hasXma === !0 && b.i64.eq(c.ephemeralMediaState, void 0)
                    }), function(a) {
                        return a["delete"]()
                    }))
                })
            }]) : b.filter(b.db.table(38).fetch([
                [
                    [a[2]]
                ]
            ]), function(c) {
                return b.i64.eq(c.pollId, a[2]) && b.i64.eq(c.threadKey, a[0])
            }).next().then(function(c, d) {
                var e = c.done;
                c = c.value;
                return e ? b.forEach(b.filter(b.db.table(16).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[0]) && c.attachmentFbid === a[1] && (b.i64.eq(c.attachmentType, b.i64.cast([0, 7])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 0]))) && c.hasMedia === !1 && c.hasXma === !0 && b.i64.eq(c.ephemeralMediaState, void 0)
                }), function(a) {
                    return a["delete"]()
                }) : (d = c.item, b.forEach(b.filter(b.db.table(16).fetch([
                    [
                        [a[0], d.lastUpdateMessageId, a[1]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && c.messageId === d.lastUpdateMessageId && c.attachmentFbid === a[1] && (b.i64.eq(c.attachmentType, b.i64.cast([0, 7])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 0]))) && c.hasMedia === !1 && c.hasXma === !0 && b.i64.eq(c.ephemeralMediaState, void 0)
                }), function(a) {
                    return a["delete"]()
                }))
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxDeletePollAttachmentStoredProcedure";
    e.exports = a
}), null);
__d("LSHasMatchingAttachmentCTA", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(e) {
            return b.sequence([function(d) {
                return b.count(b.filter(b.db.table(19).fetch([
                    [
                        [a[0]]
                    ], "fk_attachments"
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[0]) && c.attachmentFbid === a[1]
                })).then(function(a) {
                    return c[0] = a
                })
            }, function(a) {
                return d[0] = b.i64.gt(c[0], b.i64.cast([0, 0]))
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxHasMatchingAttachmentCTAStoredProcedure";
    e.exports = a
}), null);
__d("LSHasPollAttachmentNewerThan", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(e) {
            return b.sequence([function(d) {
                return b.count(b.filter(b.db.table(16).fetch(), function(c) {
                    return c.attachmentFbid === a[0] && b.i64.gt(c.timestampMs, a[1])
                })).then(function(a) {
                    return c[0] = a
                })
            }, function(a) {
                return b.i64.gt(c[0], b.i64.cast([0, 0])) ? c[1] = !0 : c[1] = !1, d[0] = c[1]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxHasPollAttachmentNewerThanStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateExtraAttachmentColumns", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(16).fetch([
                [
                    [a[0], a[2], a[3]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[0]) && b.i64.eq(b.i64.cast([0, 0]), a[1]) && c.messageId === a[2] && c.attachmentFbid === a[3]
            }), function(b) {
                var c = b.update;
                b.item;
                return c({
                    listItemAccessibilityText1: a[4],
                    listItemAccessibilityText2: a[5],
                    listItemAccessibilityText3: a[6],
                    subtitleIconUrl: a[17],
                    attachmentLoggingType: a[18],
                    preheaderText: a[19],
                    shouldAutoplayVideo: a[20],
                    previewUrlLarge: a[21],
                    previewWidthLarge: a[24],
                    previewHeightLarge: a[25],
                    avatarViewUrlList: a[10],
                    avatarViewUrlExpirationTimestampList: a[11],
                    avatarViewUrlFallbackList: a[12],
                    avatarViewTitleList: a[13],
                    avatarViewSize: a[14],
                    avatarCount: a[15],
                    avatarViewContextText: a[16]
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateExtraAttachmentColumnsStoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyPollExists", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(f) {
            return c.sequence([function(e) {
                return a[5] === !0 ? c.sequence([function(e) {
                    return c.db.table(223).fetch([
                        [
                            [a[1]]
                        ]
                    ]).next().then(function(e, f) {
                        var g = e.done;
                        e = e.value;
                        return g ? c.sequence([function(b) {
                            return c.db.table(9).fetch([
                                [
                                    [a[0]]
                                ]
                            ]).next().then(function(b, e) {
                                var a = b.done;
                                b = b.value;
                                return a ? d[5] = c.i64.cast([0, 1]) : (e = b.item, d[10] = e.syncGroup, c.i64.neq(d[10], void 0) ? d[9] = d[10] : d[9] = c.i64.cast([0, 1]), d[5] = d[9])
                            })
                        }, function(e) {
                            return d[7] = new c.Map(), d[7].set("thread_key", a[0]), d[7].set("poll_id", a[1]), d[7].set("sync_group", d[5]), d[7].set("is_cm_poll", !0), d[8] = c.toJSON(d[7]), c.storedProcedure(b("LSIssueNewTask"), "poll_point_query", c.i64.cast([0, 170]), d[8], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
                        }, function(a) {
                            return d[1] = !1
                        }]) : (f = e.item, c.sequence([function(b) {
                            return c.i64.gt(a[3], f.lastUpdateMessageTimestampMs) ? c.forEach(c.db.table(223).fetch([
                                [
                                    [a[1]]
                                ]
                            ]), function(b) {
                                var c = b.update;
                                b.item;
                                return c({
                                    lastUpdateMessageId: a[2],
                                    lastUpdateMessageTimestampMs: a[3],
                                    lastUpdateMessageEventType: a[4]
                                })
                            }) : c.resolve()
                        }, function(a) {
                            return d[1] = !0
                        }]))
                    })
                }, function(e) {
                    return c.db.table(38).fetch([
                        [
                            [a[1]]
                        ]
                    ]).next().then(function(e, f) {
                        var g = e.done;
                        e = e.value;
                        return g ? c.sequence([function(b) {
                            return c.forEach(c.filter(c.db.table(38).fetch([
                                [
                                    [a[1]]
                                ]
                            ]), function(b) {
                                return c.i64.eq(b.pollId, a[1]) && c.i64.lt(b.authorityLevel, c.i64.cast([0, 40]))
                            }), function(a) {
                                return a["delete"]()
                            })
                        }, function(b) {
                            return c.db.table(38).add({
                                pollId: a[1],
                                authorityLevel: c.i64.cast([0, 40]),
                                threadKey: a[0],
                                lastUpdateMessageId: a[2],
                                lastUpdateMessageTimestampMs: a[3],
                                lastUpdateMessageEventType: a[4]
                            })
                        }, function(b) {
                            return c.db.table(9).fetch([
                                [
                                    [a[0]]
                                ]
                            ]).next().then(function(b, e) {
                                var a = b.done;
                                b = b.value;
                                return a ? d[5] = c.i64.cast([0, 1]) : (e = b.item, d[10] = e.syncGroup, c.i64.neq(d[10], void 0) ? d[9] = d[10] : d[9] = c.i64.cast([0, 1]), d[5] = d[9])
                            })
                        }, function(e) {
                            return d[7] = new c.Map(), d[7].set("thread_key", a[0]), d[7].set("poll_id", a[1]), d[7].set("sync_group", d[5]), d[7].set("is_cm_poll", a[5]), d[8] = c.toJSON(d[7]), c.storedProcedure(b("LSIssueNewTask"), "poll_point_query", c.i64.cast([0, 170]), d[8], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
                        }, function(a) {
                            return d[3] = !1
                        }]) : (f = e.item, c.sequence([function(b) {
                            return c.i64.gt(a[3], f.lastUpdateMessageTimestampMs) ? c.forEach(c.db.table(38).fetch([
                                [
                                    [a[1]]
                                ]
                            ]), function(b) {
                                var c = b.update;
                                b.item;
                                return c({
                                    lastUpdateMessageId: a[2],
                                    lastUpdateMessageTimestampMs: a[3],
                                    lastUpdateMessageEventType: a[4]
                                })
                            }) : c.resolve()
                        }, function(a) {
                            return d[3] = c.i64.eq(f.authorityLevel, c.i64.cast([0, 80]))
                        }]))
                    })
                }, function(a) {
                    return d[0] = d[1] || d[3]
                }]) : c.sequence([function(e) {
                    return c.db.table(38).fetch([
                        [
                            [a[1]]
                        ]
                    ]).next().then(function(e, f) {
                        var g = e.done;
                        e = e.value;
                        return g ? c.sequence([function(b) {
                            return c.forEach(c.filter(c.db.table(38).fetch([
                                [
                                    [a[1]]
                                ]
                            ]), function(b) {
                                return c.i64.eq(b.pollId, a[1]) && c.i64.lt(b.authorityLevel, c.i64.cast([0, 40]))
                            }), function(a) {
                                return a["delete"]()
                            })
                        }, function(b) {
                            return c.db.table(38).add({
                                pollId: a[1],
                                authorityLevel: c.i64.cast([0, 40]),
                                threadKey: a[0],
                                lastUpdateMessageId: a[2],
                                lastUpdateMessageTimestampMs: a[3],
                                lastUpdateMessageEventType: a[4]
                            })
                        }, function(b) {
                            return c.db.table(9).fetch([
                                [
                                    [a[0]]
                                ]
                            ]).next().then(function(b, e) {
                                var a = b.done;
                                b = b.value;
                                return a ? d[3] = c.i64.cast([0, 1]) : (e = b.item, d[8] = e.syncGroup, c.i64.neq(d[8], void 0) ? d[7] = d[8] : d[7] = c.i64.cast([0, 1]), d[3] = d[7])
                            })
                        }, function(e) {
                            return d[5] = new c.Map(), d[5].set("thread_key", a[0]), d[5].set("poll_id", a[1]), d[5].set("sync_group", d[3]), d[5].set("is_cm_poll", a[5]), d[6] = c.toJSON(d[5]), c.storedProcedure(b("LSIssueNewTask"), "poll_point_query", c.i64.cast([0, 170]), d[6], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
                        }, function(a) {
                            return d[1] = !1
                        }]) : (f = e.item, c.sequence([function(b) {
                            return c.i64.gt(a[3], f.lastUpdateMessageTimestampMs) ? c.forEach(c.db.table(38).fetch([
                                [
                                    [a[1]]
                                ]
                            ]), function(b) {
                                var c = b.update;
                                b.item;
                                return c({
                                    lastUpdateMessageId: a[2],
                                    lastUpdateMessageTimestampMs: a[3],
                                    lastUpdateMessageEventType: a[4]
                                })
                            }) : c.resolve()
                        }, function(a) {
                            return d[1] = c.i64.eq(f.authorityLevel, c.i64.cast([0, 80]))
                        }]))
                    })
                }, function(a) {
                    return d[0] = d[1]
                }])
            }, function(a) {
                return e[0] = d[0]
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxVerifyPollExistsStoredProcedure";
    e.exports = a
}), null);