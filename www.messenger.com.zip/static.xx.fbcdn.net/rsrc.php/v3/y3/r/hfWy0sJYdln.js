; /*FB_PKG_DELIM*/

__d("WebrtcSignalingCommonTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    c = (a = b("$InternalEnum"))({
        DEFAULT_AUDIO: 0,
        DEFAULT_VIDEO: 1,
        SCREEN_AUDIO: 2,
        SCREEN_VIDEO: 3,
        CUSTOM_VIDEO: 4,
        CUSTOM_AUDIO: 5
    });
    d = a({
        OLD_CLIENT_PLATFORM_STACK: 0,
        RSYS_X: 1,
        IG_OLD_STACK: 2,
        MLITE_OLD_STACK: 3,
        SCOTCH: 4,
        ZENON: 5
    });
    f = a({
        NONE: 0,
        AVATAR: 1,
        AUGMENTED_CALLING: 2,
        SCENE_COMPOSITION: 3,
        STEREO_VIDEO: 4,
        SHARED_STATE: 5
    });
    b = a({
        NONE: 0,
        AMBISONIC: 1,
        CONVERSATION_BOT: 2
    });
    e.exports = {
        ClientStack: d,
        CustomAudioContentType: b,
        CustomVideoContentType: f,
        TrackLabel: c
    }
}), null);
__d("MultiwaySharedSerializers", ["MultiwaySharedTypes", "ThriftTypes", "WebrtcSignalingCommonTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        return {
            cluster: "",
            nonce: ""
        }
    }

    function b() {
        return {
            cluster: "",
            conferenceName: "",
            nonce: "",
            userId: "",
            clientSessionId: ""
        }
    }

    function e() {
        return {
            userId: "",
            deviceId: "",
            appId: "",
            appVersion: "",
            appBuildNumber: ""
        }
    }

    function f() {
        return {
            mode: d("MultiwaySharedTypes").E2eeMode.cast(0),
            preventSfuMode: !1,
            infraMandatedExpStatus: d("MultiwaySharedTypes").E2eeInfraMandatedExpStatus.cast(0)
        }
    }

    function i() {
        return {
            semantics: "",
            ssrcs: []
        }
    }

    function j() {
        return {
            type: d("MultiwaySharedTypes").MediaType.cast(0),
            id: "",
            ssrcs: [],
            enabled: !1,
            customVideoContentType: d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0),
            customAudioContentType: d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(0)
        }
    }

    function k() {
        return {
            protocol: d("MultiwaySharedTypes").ProxygenCandidateProtocol.cast(0),
            vipAddress: "",
            port: 0
        }
    }

    function l() {
        return {
            candidates: [],
            edgeRegion: ""
        }
    }

    function m() {
        return {
            vipTypeAllocationsMap: {}
        }
    }

    function n() {
        return {
            parameters: {},
            conditionFbid: "0",
            exposureHasBeenLogged: !1,
            canExposureLog: !1,
            universeShortName: "",
            userFbid: "0",
            unitId: ""
        }
    }

    function o() {
        return {
            experiments: {},
            userFbid: "0"
        }
    }

    function p() {
        return {
            conditionFbid: "0",
            userFbid: "0",
            universeName: "",
            unitId: ""
        }
    }

    function q() {
        return {
            enabled: !1,
            customVideoContentType: d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0),
            customAudioContentType: d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(0)
        }
    }

    function r() {
        return {
            tracks: {}
        }
    }

    function s() {
        return {
            videoQuality: d("MultiwaySharedTypes").VideoQuality.cast(0)
        }
    }

    function t() {
        return {
            cname: "",
            type: d("MultiwaySharedTypes").SubscriptionType.cast(0)
        }
    }

    function u() {
        return {
            restrictiveLogging: !0,
            verboseLogging: !1
        }
    }

    function v() {
        return {
            userId: "",
            streamId: "",
            streamType: 0,
            renderWidth: 0,
            renderHeight: 0
        }
    }

    function w() {
        return {}
    }

    function x() {
        return {}
    }

    function y() {
        return {}
    }

    function z() {
        return {
            host: Uint8Array.of(),
            port: 0
        }
    }

    function A() {
        return {}
    }

    function B(a, b) {
        b.writeStructBegin("ServerInfo");
        b.writeFieldBegin({
            fname: "cluster",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.cluster != null) b.writeString(a.cluster);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        a.conferenceName_deprecated != null && (b.writeFieldBegin({
            fname: "conferenceName_deprecated",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.conferenceName_deprecated), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "nonce",
            ftype: h.STRING,
            fid: 3
        });
        if (a.nonce != null) b.writeString(a.nonce);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        a.conferenceId != null && (b.writeFieldBegin({
            fname: "conferenceId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 4
        }), b.writeI64(BigInt(a.conferenceId)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function C(a, b) {
        b.writeStructBegin("ClientSessionInfo");
        b.writeFieldBegin({
            fname: "cluster",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.cluster != null) b.writeString(a.cluster);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "conferenceName",
            ftype: h.STRING,
            fid: 2
        });
        if (a.conferenceName != null) b.writeString(a.conferenceName);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "nonce",
            ftype: h.STRING,
            fid: 3
        });
        if (a.nonce != null) b.writeString(a.nonce);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "userId",
            ftype: h.STRING,
            fid: 4
        });
        if (a.userId != null) b.writeString(a.userId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "clientSessionId",
            ftype: h.STRING,
            fid: 5
        });
        if (a.clientSessionId != null) b.writeString(a.clientSessionId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function D(a, b) {
        b.writeStructBegin("Endpoint");
        b.writeFieldBegin({
            fname: "userId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.userId != null) b.writeString(a.userId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "deviceId",
            ftype: h.STRING,
            fid: 2
        });
        if (a.deviceId != null) b.writeString(a.deviceId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "appId",
            ftype: h.STRING,
            fid: 3
        });
        if (a.appId != null) b.writeString(a.appId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "appVersion",
            ftype: h.STRING,
            fid: 4
        });
        if (a.appVersion != null) b.writeString(a.appVersion);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "appBuildNumber",
            ftype: h.STRING,
            fid: 5
        });
        if (a.appBuildNumber != null) b.writeString(a.appBuildNumber);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        a.clientStackInfo != null && (b.writeFieldBegin({
            fname: "clientStackInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 6
        }), b.writeString(a.clientStackInfo), b.writeFieldEnd());
        a.familyDeviceId != null && (b.writeFieldBegin({
            fname: "familyDeviceId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 7
        }), b.writeString(a.familyDeviceId), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function E(a, b) {
        b.writeStructBegin("E2eeEnforcement");
        b.writeFieldBegin({
            fname: "mode",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.mode != null) {
            var e;
            b.writeI32((e = a.mode) != null ? e : 0)
        } else {
            e = d("MultiwaySharedTypes").E2eeMode.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "preventSfuMode",
            ftype: h.BOOL,
            fid: 2
        });
        if (a.preventSfuMode != null) b.writeBool(a.preventSfuMode);
        else {
            e = !1;
            b.writeBool(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "infraMandatedExpStatus",
            ftype: h.I32,
            fid: 3
        });
        if (a.infraMandatedExpStatus != null) {
            b.writeI32((e = a.infraMandatedExpStatus) != null ? e : 0)
        } else {
            a = d("MultiwaySharedTypes").E2eeInfraMandatedExpStatus.cast(0);
            b.writeI32((e = a) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function F(a, b) {
        b.writeStructBegin("SsrcGroup");
        b.writeFieldBegin({
            fname: "semantics",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.semantics != null) b.writeString(a.semantics);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "ssrcs",
            ftype: h.LIST,
            fid: 2
        });
        if (a.ssrcs != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).I64,
                size: a.ssrcs.length
            });
            for (var d = a.ssrcs, a = Array.isArray(d), e = 0, d = a ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (a) {
                    if (e >= d.length) break;
                    f = d[e++]
                } else {
                    e = d.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                b.writeI64(BigInt(f))
            }
            b.writeListEnd()
        } else {
            f = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).I64,
                size: f.length
            });
            for (e = 0; e < f.length; e++) {
                a = f[e];
                b.writeI64(BigInt(a))
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function G(a, b) {
        b.writeStructBegin("Media");
        b.writeFieldBegin({
            fname: "type",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.type != null) {
            var e;
            b.writeI32((e = a.type) != null ? e : 0)
        } else {
            e = d("MultiwaySharedTypes").MediaType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "id",
            ftype: h.STRING,
            fid: 2
        });
        if (a.id != null) b.writeString(a.id);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "ssrcs",
            ftype: h.LIST,
            fid: 3
        });
        if (a.ssrcs != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).I64,
                size: a.ssrcs.length
            });
            for (var e = a.ssrcs, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                b.writeI64(BigInt(i))
            }
            b.writeListEnd()
        } else {
            i = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).I64,
                size: i.length
            });
            for (g = 0; g < i.length; g++) {
                f = i[g];
                b.writeI64(BigInt(f))
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "enabled",
            ftype: h.BOOL,
            fid: 4
        });
        if (a.enabled != null) b.writeBool(a.enabled);
        else {
            e = !1;
            b.writeBool(e)
        }
        b.writeFieldEnd();
        if (a.pausedDownlink != null) {
            b.writeFieldBegin({
                fname: "pausedDownlink",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 5
            });
            b.writeI32((f = a.pausedDownlink) != null ? f : 0);
            b.writeFieldEnd()
        }
        if (a.pausedUplink != null) {
            b.writeFieldBegin({
                fname: "pausedUplink",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 6
            });
            b.writeI32((i = a.pausedUplink) != null ? i : 0);
            b.writeFieldEnd()
        }
        a.owner != null && (b.writeFieldBegin({
            fname: "owner",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 7
        }), b.writeString(a.owner), b.writeFieldEnd());
        if (a.label != null) {
            b.writeFieldBegin({
                fname: "label",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 8
            });
            b.writeI32((g = a.label) != null ? g : 0);
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "customVideoContentType",
            ftype: h.I32,
            fid: 9
        });
        if (a.customVideoContentType != null) {
            b.writeI32((e = a.customVideoContentType) != null ? e : 0)
        } else {
            f = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0);
            b.writeI32((i = f) != null ? i : 0)
        }
        b.writeFieldEnd();
        a.name != null && (b.writeFieldBegin({
            fname: "name",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 10
        }), b.writeString(a.name), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "customAudioContentType",
            ftype: h.I32,
            fid: 11
        });
        if (a.customAudioContentType != null) {
            b.writeI32((g = a.customAudioContentType) != null ? g : 0)
        } else {
            e = d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(0);
            b.writeI32((f = e) != null ? f : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function H(a, b) {
        b.writeStructBegin("ProxygenCandidate");
        b.writeFieldBegin({
            fname: "protocol",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.protocol != null) {
            var e;
            b.writeI32((e = a.protocol) != null ? e : 0)
        } else {
            e = d("MultiwaySharedTypes").ProxygenCandidateProtocol.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "vipAddress",
            ftype: h.STRING,
            fid: 2
        });
        if (a.vipAddress != null) b.writeString(a.vipAddress);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "port",
            ftype: h.I32,
            fid: 3
        });
        if (a.port != null) b.writeI32(a.port);
        else {
            e = 0;
            b.writeI32(e)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function I(a, b) {
        b.writeStructBegin("ProxygenAllocation");
        b.writeFieldBegin({
            fname: "candidates",
            ftype: (h || (h = c("ThriftTypes"))).LIST,
            fid: 1
        });
        if (a.candidates != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.candidates.length
            });
            for (var d = a.candidates, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                H(g, b)
            }
            b.writeListEnd()
        } else {
            g = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: g.length
            });
            for (f = 0; f < g.length; f++) {
                e = g[f];
                H(e, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "edgeRegion",
            ftype: h.STRING,
            fid: 2
        });
        if (a.edgeRegion != null) b.writeString(a.edgeRegion);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function J(a, b) {
        b.writeStructBegin("ProxygenAllocationResult");
        b.writeFieldBegin({
            fname: "vipTypeAllocationsMap",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 3
        });
        if (a.vipTypeAllocationsMap != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.LIST,
                size: Object.keys(a.vipTypeAllocationsMap).length
            });
            a = Object.entries(a.vipTypeAllocationsMap);
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = e[0];
                e = e[1];
                b.writeI32((f = Number(f)) != null ? f : 0);
                b.writeListBegin({
                    etype: (h || (h = c("ThriftTypes"))).STRUCT,
                    size: e.length
                });
                for (var f = e, e = Array.isArray(f), g = 0, f = e ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var i;
                    if (e) {
                        if (g >= f.length) break;
                        i = f[g++]
                    } else {
                        g = f.next();
                        if (g.done) break;
                        i = g.value
                    }
                    i = i;
                    I(i, b)
                }
                b.writeListEnd()
            }
            b.writeMapEnd()
        } else {
            i = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.LIST,
                size: Object.keys(i).length
            });
            g = Object.entries(i);
            for (e = 0; e < g.length; e++) {
                f = g[e];
                a = f[0];
                d = f[1];
                b.writeI32((i = Number(a)) != null ? i : 0);
                b.writeListBegin({
                    etype: (h || (h = c("ThriftTypes"))).STRUCT,
                    size: d.length
                });
                for (f = d, a = Array.isArray(f), i = 0, f = a ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    if (a) {
                        if (i >= f.length) break;
                        d = f[i++]
                    } else {
                        i = f.next();
                        if (i.done) break;
                        d = i.value
                    }
                    d = d;
                    I(d, b)
                }
                b.writeListEnd()
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function K(a, b) {
        b.writeStructBegin("QuickExperiment");
        b.writeFieldBegin({
            fname: "parameters",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.parameters != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.parameters).length
            });
            var d = Object.entries(a.parameters);
            for (var e = 0; e < d.length; e++) {
                var f = d[e],
                    g = f[0];
                f = f[1];
                b.writeString(g);
                S(f, b)
            }
            b.writeMapEnd()
        } else {
            g = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(g).length
            });
            f = Object.entries(g);
            for (d = 0; d < f.length; d++) {
                e = f[d];
                g = e[0];
                e = e[1];
                b.writeString(g);
                S(e, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "conditionFbid",
            ftype: h.I64,
            fid: 2
        });
        if (a.conditionFbid != null) b.writeI64(BigInt(a.conditionFbid));
        else {
            g = "0";
            b.writeI64(BigInt(g))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "exposureHasBeenLogged",
            ftype: h.BOOL,
            fid: 3
        });
        if (a.exposureHasBeenLogged != null) b.writeBool(a.exposureHasBeenLogged);
        else {
            e = !1;
            b.writeBool(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "canExposureLog",
            ftype: h.BOOL,
            fid: 4
        });
        if (a.canExposureLog != null) b.writeBool(a.canExposureLog);
        else {
            f = !1;
            b.writeBool(f)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "universeShortName",
            ftype: h.STRING,
            fid: 5
        });
        if (a.universeShortName != null) b.writeString(a.universeShortName);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "userFbid",
            ftype: h.I64,
            fid: 6
        });
        if (a.userFbid != null) b.writeI64(BigInt(a.userFbid));
        else {
            g = "0";
            b.writeI64(BigInt(g))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "unitId",
            ftype: h.STRING,
            fid: 7
        });
        if (a.unitId != null) b.writeString(a.unitId);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function L(a, b) {
        b.writeStructBegin("QuickExperimentResult");
        b.writeFieldBegin({
            fname: "experiments",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.experiments != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.experiments).length
            });
            var d = Object.entries(a.experiments);
            for (var e = 0; e < d.length; e++) {
                var f = d[e],
                    g = f[0];
                f = f[1];
                b.writeString(g);
                K(f, b)
            }
            b.writeMapEnd()
        } else {
            g = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(g).length
            });
            f = Object.entries(g);
            for (d = 0; d < f.length; d++) {
                e = f[d];
                g = e[0];
                e = e[1];
                b.writeString(g);
                K(e, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "userFbid",
            ftype: h.I64,
            fid: 2
        });
        if (a.userFbid != null) b.writeI64(BigInt(a.userFbid));
        else {
            g = "0";
            b.writeI64(BigInt(g))
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function M(a, b) {
        b.writeStructBegin("QuickExperimentExposureLoggingEvent");
        b.writeFieldBegin({
            fname: "conditionFbid",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.conditionFbid != null) b.writeI64(BigInt(a.conditionFbid));
        else {
            var d = "0";
            b.writeI64(BigInt(d))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "userFbid",
            ftype: h.I64,
            fid: 2
        });
        if (a.userFbid != null) b.writeI64(BigInt(a.userFbid));
        else {
            d = "0";
            b.writeI64(BigInt(d))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "universeName",
            ftype: h.STRING,
            fid: 3
        });
        if (a.universeName != null) b.writeString(a.universeName);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "unitId",
            ftype: h.STRING,
            fid: 4
        });
        if (a.unitId != null) b.writeString(a.unitId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function N(a, b) {
        b.writeStructBegin("ClientTrackInfo");
        b.writeFieldBegin({
            fname: "enabled",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 1
        });
        if (a.enabled != null) b.writeBool(a.enabled);
        else {
            var e = !1;
            b.writeBool(e)
        }
        b.writeFieldEnd();
        if (a.pausedUplink != null) {
            b.writeFieldBegin({
                fname: "pausedUplink",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 2
            });
            b.writeI32((e = a.pausedUplink) != null ? e : 0);
            b.writeFieldEnd()
        }
        if (a.pausedDownlink != null) {
            b.writeFieldBegin({
                fname: "pausedDownlink",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 3
            });
            b.writeI32((e = a.pausedDownlink) != null ? e : 0);
            b.writeFieldEnd()
        }
        a.owner != null && (b.writeFieldBegin({
            fname: "owner",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.owner), b.writeFieldEnd());
        if (a.label != null) {
            b.writeFieldBegin({
                fname: "label",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 5
            });
            b.writeI32((e = a.label) != null ? e : 0);
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "customVideoContentType",
            ftype: h.I32,
            fid: 6
        });
        if (a.customVideoContentType != null) {
            b.writeI32((e = a.customVideoContentType) != null ? e : 0)
        } else {
            e = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.name != null && (b.writeFieldBegin({
            fname: "name",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 7
        }), b.writeString(a.name), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "customAudioContentType",
            ftype: h.I32,
            fid: 8
        });
        if (a.customAudioContentType != null) {
            b.writeI32((e = a.customAudioContentType) != null ? e : 0)
        } else {
            e = d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.nodeId != null && (b.writeFieldBegin({
            fname: "nodeId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 9
        }), b.writeI64(BigInt(a.nodeId)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function O(a, b) {
        b.writeStructBegin("ClientMediaStatus");
        b.writeFieldBegin({
            fname: "tracks",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.tracks != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.tracks).length
            });
            a = Object.entries(a.tracks);
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = e[0];
                e = e[1];
                b.writeString(f);
                N(e, b)
            }
            b.writeMapEnd()
        } else {
            f = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(f).length
            });
            e = Object.entries(f);
            for (a = 0; a < e.length; a++) {
                d = e[a];
                f = d[0];
                d = d[1];
                b.writeString(f);
                N(d, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function P(a, b) {
        b.writeStructBegin("SubscriptionOptions");
        b.writeFieldBegin({
            fname: "videoQuality",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.videoQuality != null) {
            var e;
            b.writeI32((e = a.videoQuality) != null ? e : 0)
        } else {
            e = d("MultiwaySharedTypes").VideoQuality.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.qualityIndex != null && (b.writeFieldBegin({
            fname: "qualityIndex",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        }), b.writeI32(a.qualityIndex), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function aa(a, b) {
        b.writeStructBegin("Subscription");
        b.writeFieldBegin({
            fname: "cname",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.cname != null) b.writeString(a.cname);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.options != null && (b.writeFieldBegin({
            fname: "options",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), P(a.options, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "type",
            ftype: h.I32,
            fid: 3
        });
        if (a.type != null) {
            b.writeI32((e = a.type) != null ? e : 0)
        } else {
            e = d("MultiwaySharedTypes").SubscriptionType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.trackId != null && (b.writeFieldBegin({
            fname: "trackId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.trackId), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ba(a, b) {
        b.writeStructBegin("LoggingOptions");
        b.writeFieldBegin({
            fname: "restrictiveLogging",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 1
        });
        if (a.restrictiveLogging != null) b.writeBool(a.restrictiveLogging);
        else {
            var d = !0;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "verboseLogging",
            ftype: h.BOOL,
            fid: 2
        });
        if (a.verboseLogging != null) b.writeBool(a.verboseLogging);
        else {
            d = !1;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ca(a, b) {
        b.writeStructBegin("ResolutionData");
        b.writeFieldBegin({
            fname: "userId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.userId != null) b.writeString(a.userId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "streamId",
            ftype: h.STRING,
            fid: 2
        });
        if (a.streamId != null) b.writeString(a.streamId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "streamType",
            ftype: h.I32,
            fid: 3
        });
        if (a.streamType != null) b.writeI32(a.streamType);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "renderWidth",
            ftype: h.I32,
            fid: 4
        });
        if (a.renderWidth != null) b.writeI32(a.renderWidth);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "renderHeight",
            ftype: h.I32,
            fid: 5
        });
        if (a.renderHeight != null) b.writeI32(a.renderHeight);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function Q(a, b) {
        b.writeStructBegin("TurnInfo"), a.ipv4 != null && (b.writeFieldBegin({
            fname: "ipv4",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeBinary(a.ipv4), b.writeFieldEnd()), a.ipv6 != null && (b.writeFieldBegin({
            fname: "ipv6",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeBinary(a.ipv6), b.writeFieldEnd()), a.udpPort != null && (b.writeFieldBegin({
            fname: "udpPort",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 3
        }), b.writeI32(a.udpPort), b.writeFieldEnd()), a.tcpPort != null && (b.writeFieldBegin({
            fname: "tcpPort",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 4
        }), b.writeI32(a.tcpPort), b.writeFieldEnd()), a.sslTcpPort != null && (b.writeFieldBegin({
            fname: "sslTcpPort",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 5
        }), b.writeI32(a.sslTcpPort), b.writeFieldEnd()), a.portInfoIdx != null && (b.writeFieldBegin({
            fname: "portInfoIdx",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 6
        }), b.writeI32(a.portInfoIdx), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function R(a, b) {
        b.writeStructBegin("EdgerayInfo");
        if (a.edgerayType != null) {
            var d;
            b.writeFieldBegin({
                fname: "edgerayType",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 1
            });
            b.writeI32((d = a.edgerayType) != null ? d : 0);
            b.writeFieldEnd()
        }
        a.ipv4 != null && (b.writeFieldBegin({
            fname: "ipv4",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeBinary(a.ipv4), b.writeFieldEnd());
        a.ipv6 != null && (b.writeFieldBegin({
            fname: "ipv6",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        }), b.writeBinary(a.ipv6), b.writeFieldEnd());
        a.token != null && (b.writeFieldBegin({
            fname: "token",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeBinary(a.token), b.writeFieldEnd());
        a.tokenIdx != null && (b.writeFieldBegin({
            fname: "tokenIdx",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 5
        }), b.writeI32(a.tokenIdx), b.writeFieldEnd());
        a.secret != null && (b.writeFieldBegin({
            fname: "secret",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 6
        }), b.writeBinary(a.secret), b.writeFieldEnd());
        a.secretIdx != null && (b.writeFieldBegin({
            fname: "secretIdx",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 7
        }), b.writeI32(a.secretIdx), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function da(a, b) {
        b.writeStructBegin("RelayInfo");
        if (a.turns != null) {
            b.writeFieldBegin({
                fname: "turns",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 1
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.turns.length
            });
            for (var d = a.turns, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                Q(g, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.edgerays != null) {
            b.writeFieldBegin({
                fname: "edgerays",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 2
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.edgerays.length
            });
            for (g = a.edgerays, f = Array.isArray(g), e = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (e >= g.length) break;
                    d = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    d = e.value
                }
                d = d;
                R(d, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.turnUsername != null && (b.writeFieldBegin({
            fname: "turnUsername",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        }), b.writeString(a.turnUsername), b.writeFieldEnd());
        a.turnPassword != null && (b.writeFieldBegin({
            fname: "turnPassword",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.turnPassword), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ea(a, b) {
        b.writeStructBegin("TSocketAddress");
        b.writeFieldBegin({
            fname: "host",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.host != null) b.writeBinary(a.host);
        else {
            var d = Uint8Array.of();
            b.writeBinary(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "port",
            ftype: h.I16,
            fid: 2
        });
        if (a.port != null) b.writeI16(a.port);
        else {
            d = 0;
            b.writeI16(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function S(a, b) {
        b.writeStructBegin("QuickExperimentValue");
        if (a.intValue != null) {
            b.writeFieldBegin({
                fname: "intValue",
                ftype: (h || (h = c("ThriftTypes"))).I64,
                fid: 1
            });
            b.writeI64(BigInt(a.intValue));
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.stringValue != null) {
            b.writeFieldBegin({
                fname: "stringValue",
                ftype: (h || (h = c("ThriftTypes"))).STRING,
                fid: 2
            });
            b.writeString(a.stringValue);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function fa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.cluster = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.conferenceName_deprecated = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.nonce = a.readString() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.conferenceId = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.cluster === void 0 && (b.cluster = "");
        b.nonce === void 0 && (b.nonce = "");
        return b
    }

    function ga(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.cluster = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.conferenceName = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.nonce = a.readString() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.userId = a.readString() : a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.clientSessionId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.cluster === void 0 && (b.cluster = "");
        b.conferenceName === void 0 && (b.conferenceName = "");
        b.nonce === void 0 && (b.nonce = "");
        b.userId === void 0 && (b.userId = "");
        b.clientSessionId === void 0 && (b.clientSessionId = "");
        return b
    }

    function ha(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.userId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.deviceId = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.appId = a.readString() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.appVersion = a.readString() : a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.appBuildNumber = a.readString() : a.skip(e);
                    break;
                case 6:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.clientStackInfo = a.readString() : a.skip(e);
                    break;
                case 7:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.familyDeviceId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.userId === void 0 && (b.userId = "");
        b.deviceId === void 0 && (b.deviceId = "");
        b.appId === void 0 && (b.appId = "");
        b.appVersion === void 0 && (b.appVersion = "");
        b.appBuildNumber === void 0 && (b.appBuildNumber = "");
        return b
    }

    function ia(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.mode = d("MultiwaySharedTypes").E2eeMode.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.preventSfuMode = a.readBool() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.infraMandatedExpStatus = d("MultiwaySharedTypes").E2eeInfraMandatedExpStatus.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.mode === void 0 && (b.mode = d("MultiwaySharedTypes").E2eeMode.cast(0));
        b.preventSfuMode === void 0 && (b.preventSfuMode = !1);
        b.infraMandatedExpStatus === void 0 && (b.infraMandatedExpStatus = d("MultiwaySharedTypes").E2eeInfraMandatedExpStatus.cast(0));
        return b
    }

    function ja(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.semantics = a.readString() : a.skip(e);
                    break;
                case 2:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.ssrcs = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readI64().toString();
                            b.ssrcs.push(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.semantics === void 0 && (b.semantics = "");
        b.ssrcs === void 0 && (b.ssrcs = []);
        return b
    }

    function ka(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.type = d("MultiwaySharedTypes").MediaType.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.id = a.readString() : a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.ssrcs = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readI64().toString();
                            b.ssrcs.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.enabled = a.readBool() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.pausedDownlink = d("MultiwaySharedTypes").MediaPauseStatus.cast(a.readI32()) : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.pausedUplink = d("MultiwaySharedTypes").MediaPauseStatus.cast(a.readI32()) : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.owner = a.readString() : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.label = d("WebrtcSignalingCommonTypes").TrackLabel.cast(a.readI32()) : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.customVideoContentType = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(a.readI32()) : a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.name = a.readString() : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.customAudioContentType = d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.type === void 0 && (b.type = d("MultiwaySharedTypes").MediaType.cast(0));
        b.id === void 0 && (b.id = "");
        b.ssrcs === void 0 && (b.ssrcs = []);
        b.enabled === void 0 && (b.enabled = !1);
        b.customVideoContentType === void 0 && (b.customVideoContentType = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0));
        b.customAudioContentType === void 0 && (b.customAudioContentType = d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(0));
        return b
    }

    function T(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.protocol = d("MultiwaySharedTypes").ProxygenCandidateProtocol.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.vipAddress = a.readString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.port = a.readI32() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.protocol === void 0 && (b.protocol = d("MultiwaySharedTypes").ProxygenCandidateProtocol.cast(0));
        b.vipAddress === void 0 && (b.vipAddress = "");
        b.port === void 0 && (b.port = 0);
        return b
    }

    function U(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.candidates = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = T(a);
                            b.candidates.push(g)
                        }
                    } else a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.edgeRegion = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.candidates === void 0 && (b.candidates = []);
        b.edgeRegion === void 0 && (b.edgeRegion = "");
        return b
    }

    function la(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.vipTypeAllocationsMap = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("MultiwaySharedTypes").ProxygenVipType.cast(a.readI32()),
                                j = [],
                                k = a.readListBegin();
                            for (var l = 0; l < k.size; l++) {
                                var m = U(a);
                                j.push(m)
                            }
                            i != null && (b.vipTypeAllocationsMap[i] = j)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.vipTypeAllocationsMap === void 0 && (b.vipTypeAllocationsMap = {});
        return b
    }

    function V(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).MAP) {
                        b.parameters = {};
                        d = a.readMapBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString(),
                                i = $(a);
                            b.parameters[g] = i
                        }
                    } else a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.conditionFbid = a.readI64().toString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.exposureHasBeenLogged = a.readBool() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.canExposureLog = a.readBool() : a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.universeShortName = a.readString() : a.skip(e);
                    break;
                case 6:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.userFbid = a.readI64().toString() : a.skip(e);
                    break;
                case 7:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.unitId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.parameters === void 0 && (b.parameters = {});
        b.conditionFbid === void 0 && (b.conditionFbid = "0");
        b.exposureHasBeenLogged === void 0 && (b.exposureHasBeenLogged = !1);
        b.canExposureLog === void 0 && (b.canExposureLog = !1);
        b.universeShortName === void 0 && (b.universeShortName = "");
        b.userFbid === void 0 && (b.userFbid = "0");
        b.unitId === void 0 && (b.unitId = "");
        return b
    }

    function ma(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).MAP) {
                        b.experiments = {};
                        d = a.readMapBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString(),
                                i = V(a);
                            b.experiments[g] = i
                        }
                    } else a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.userFbid = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.experiments === void 0 && (b.experiments = {});
        b.userFbid === void 0 && (b.userFbid = "0");
        return b
    }

    function na(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.conditionFbid = a.readI64().toString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.userFbid = a.readI64().toString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.universeName = a.readString() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.unitId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.conditionFbid === void 0 && (b.conditionFbid = "0");
        b.userFbid === void 0 && (b.userFbid = "0");
        b.universeName === void 0 && (b.universeName = "");
        b.unitId === void 0 && (b.unitId = "");
        return b
    }

    function W(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.enabled = a.readBool() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.pausedUplink = d("MultiwaySharedTypes").MediaPauseStatus.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.pausedDownlink = d("MultiwaySharedTypes").MediaPauseStatus.cast(a.readI32()) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.owner = a.readString() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.label = d("WebrtcSignalingCommonTypes").TrackLabel.cast(a.readI32()) : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.customVideoContentType = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(a.readI32()) : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.name = a.readString() : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.customAudioContentType = d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(a.readI32()) : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.nodeId = a.readI64().toString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.enabled === void 0 && (b.enabled = !1);
        b.customVideoContentType === void 0 && (b.customVideoContentType = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0));
        b.customAudioContentType === void 0 && (b.customAudioContentType = d("WebrtcSignalingCommonTypes").CustomAudioContentType.cast(0));
        return b
    }

    function oa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).MAP) {
                        b.tracks = {};
                        d = a.readMapBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString(),
                                i = W(a);
                            b.tracks[g] = i
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.tracks === void 0 && (b.tracks = {});
        return b
    }

    function X(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.videoQuality = d("MultiwaySharedTypes").VideoQuality.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.qualityIndex = a.readI32() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.videoQuality === void 0 && (b.videoQuality = d("MultiwaySharedTypes").VideoQuality.cast(0));
        return b
    }

    function pa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.cname = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.options = X(a) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.type = d("MultiwaySharedTypes").SubscriptionType.cast(a.readI32()) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.trackId = a.readString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.cname === void 0 && (b.cname = "");
        b.type === void 0 && (b.type = d("MultiwaySharedTypes").SubscriptionType.cast(0));
        return b
    }

    function qa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.restrictiveLogging = a.readBool() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.verboseLogging = a.readBool() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.restrictiveLogging === void 0 && (b.restrictiveLogging = !0);
        b.verboseLogging === void 0 && (b.verboseLogging = !1);
        return b
    }

    function ra(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.userId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.streamId = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.streamType = a.readI32() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.renderWidth = a.readI32() : a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.renderHeight = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.userId === void 0 && (b.userId = "");
        b.streamId === void 0 && (b.streamId = "");
        b.streamType === void 0 && (b.streamType = 0);
        b.renderWidth === void 0 && (b.renderWidth = 0);
        b.renderHeight === void 0 && (b.renderHeight = 0);
        return b
    }

    function Y(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.ipv4 = a.readBinary() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.ipv6 = a.readBinary() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.udpPort = a.readI32() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.tcpPort = a.readI32() : a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.sslTcpPort = a.readI32() : a.skip(e);
                    break;
                case 6:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.portInfoIdx = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Z(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.edgerayType = d("MultiwaySharedTypes").EdgerayType.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.ipv4 = a.readBinary() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.ipv6 = a.readBinary() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.token = a.readBinary() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.tokenIdx = a.readI32() : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.secret = a.readBinary() : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.secretIdx = a.readI32() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function sa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.turns = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = Y(a);
                            b.turns.push(g)
                        }
                    } else a.skip(e);
                    break;
                case 2:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.edgerays = [];
                        g = a.readListBegin();
                        for (f = 0; f < g.size; f++) {
                            d = Z(a);
                            b.edgerays.push(d)
                        }
                    } else a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.turnUsername = a.readString() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.turnPassword = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function ta(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.host = a.readBinary() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I16 ? b.port = a.readI16() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.host === void 0 && (b.host = Uint8Array.of());
        b.port === void 0 && (b.port = 0);
        return b
    }

    function $(a) {
        var b, d = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).I64)
                        if (b == null) d.intValue = a.readI64().toString(), b = "intValue";
                        else throw new Error("more than one field have been deserialized in union type: QuickExperimentValue; current field: intValue, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).STRING)
                        if (b == null) d.stringValue = a.readString(), b = "stringValue";
                        else throw new Error("more than one field have been deserialized in union type: QuickExperimentValue; current field: stringValue, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return d
    }
    g.ServerInfo$DefaultConstructor = a;
    g.ClientSessionInfo$DefaultConstructor = b;
    g.Endpoint$DefaultConstructor = e;
    g.E2eeEnforcement$DefaultConstructor = f;
    g.SsrcGroup$DefaultConstructor = i;
    g.Media$DefaultConstructor = j;
    g.ProxygenCandidate$DefaultConstructor = k;
    g.ProxygenAllocation$DefaultConstructor = l;
    g.ProxygenAllocationResult$DefaultConstructor = m;
    g.QuickExperiment$DefaultConstructor = n;
    g.QuickExperimentResult$DefaultConstructor = o;
    g.QuickExperimentExposureLoggingEvent$DefaultConstructor = p;
    g.ClientTrackInfo$DefaultConstructor = q;
    g.ClientMediaStatus$DefaultConstructor = r;
    g.SubscriptionOptions$DefaultConstructor = s;
    g.Subscription$DefaultConstructor = t;
    g.LoggingOptions$DefaultConstructor = u;
    g.ResolutionData$DefaultConstructor = v;
    g.TurnInfo$DefaultConstructor = w;
    g.EdgerayInfo$DefaultConstructor = x;
    g.RelayInfo$DefaultConstructor = y;
    g.TSocketAddress$DefaultConstructor = z;
    g.QuickExperimentValue$DefaultConstructor = A;
    g.serializeServerInfo = B;
    g.serializeClientSessionInfo = C;
    g.serializeEndpoint = D;
    g.serializeE2eeEnforcement = E;
    g.serializeSsrcGroup = F;
    g.serializeMedia = G;
    g.serializeProxygenCandidate = H;
    g.serializeProxygenAllocation = I;
    g.serializeProxygenAllocationResult = J;
    g.serializeQuickExperiment = K;
    g.serializeQuickExperimentResult = L;
    g.serializeQuickExperimentExposureLoggingEvent = M;
    g.serializeClientTrackInfo = N;
    g.serializeClientMediaStatus = O;
    g.serializeSubscriptionOptions = P;
    g.serializeSubscription = aa;
    g.serializeLoggingOptions = ba;
    g.serializeResolutionData = ca;
    g.serializeTurnInfo = Q;
    g.serializeEdgerayInfo = R;
    g.serializeRelayInfo = da;
    g.serializeTSocketAddress = ea;
    g.serializeQuickExperimentValue = S;
    g.deserializeServerInfo = fa;
    g.deserializeClientSessionInfo = ga;
    g.deserializeEndpoint = ha;
    g.deserializeE2eeEnforcement = ia;
    g.deserializeSsrcGroup = ja;
    g.deserializeMedia = ka;
    g.deserializeProxygenCandidate = T;
    g.deserializeProxygenAllocation = U;
    g.deserializeProxygenAllocationResult = la;
    g.deserializeQuickExperiment = V;
    g.deserializeQuickExperimentResult = ma;
    g.deserializeQuickExperimentExposureLoggingEvent = na;
    g.deserializeClientTrackInfo = W;
    g.deserializeClientMediaStatus = oa;
    g.deserializeSubscriptionOptions = X;
    g.deserializeSubscription = pa;
    g.deserializeLoggingOptions = qa;
    g.deserializeResolutionData = ra;
    g.deserializeTurnInfo = Y;
    g.deserializeEdgerayInfo = Z;
    g.deserializeRelayInfo = sa;
    g.deserializeTSocketAddress = ta;
    g.deserializeQuickExperimentValue = $
}), 98);
__d("WebrtcSignalingCommonSerializers", ["ThriftTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        return {
            topic: "",
            data: Uint8Array.of()
        }
    }

    function b(a, b) {
        b.writeStructBegin("GenericDataMessage");
        b.writeFieldBegin({
            fname: "topic",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.topic != null) b.writeString(a.topic);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "data",
            ftype: h.STRING,
            fid: 2
        });
        if (a.data != null) b.writeBinary(a.data);
        else {
            d = Uint8Array.of();
            b.writeBinary(d)
        }
        b.writeFieldEnd();
        a.e2eEncryptedData != null && (b.writeFieldBegin({
            fname: "e2eEncryptedData",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        }), b.writeBinary(a.e2eEncryptedData), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function d(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.topic = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.data = a.readBinary() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.e2eEncryptedData = a.readBinary() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.topic === void 0 && (b.topic = "");
        b.data === void 0 && (b.data = Uint8Array.of());
        return b
    }
    g.GenericDataMessage$DefaultConstructor = a;
    g.serializeGenericDataMessage = b;
    g.deserializeGenericDataMessage = d
}), 98);
__d("DataMessageSerializers", ["MultiwaySharedSerializers", "MultiwaySharedTypes", "ThriftTypes", "WebrtcSignalingCommonSerializers"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        return {
            topic_DEPRECATED: ""
        }
    }

    function a() {
        return {
            userId: ""
        }
    }

    function b() {
        return {
            userId: "",
            cname: "",
            trackIds: [],
            transactionId: "0"
        }
    }

    function e() {
        return {
            cname: "",
            quality_DEPRECATED: d("MultiwaySharedTypes").VideoQuality.cast(0)
        }
    }

    function f() {
        return {
            userId: "",
            bottleneckBps: 0
        }
    }

    function j() {
        return {
            bottleneckUplinksByLayer: {}
        }
    }

    function k() {
        return {
            duplicationAmount: 0,
            delayMs: 0
        }
    }

    function l() {
        return {}
    }

    function m() {
        return {}
    }

    function n() {
        return {
            primarySpeakerUserId: "",
            transactionId: "0"
        }
    }

    function o() {
        return {}
    }

    function p() {
        return {
            signalingMessagePayload: Uint8Array.of()
        }
    }

    function q() {
        return {
            signalingMessagePayload: Uint8Array.of()
        }
    }

    function r() {
        return {
            subscriptionMessagePayload: []
        }
    }

    function s() {
        return {}
    }

    function t() {
        return {}
    }

    function u() {
        return {
            nodeIdToUserIdMap: {},
            nodeIdToServiceTypeMap: {}
        }
    }

    function v() {
        return {}
    }

    function w() {
        return {
            header: i()
        }
    }

    function x(a, b) {
        b.writeStructBegin("DataHeader");
        a.sender != null && (b.writeFieldBegin({
            fname: "sender",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.sender), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "topic_DEPRECATED",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        });
        if (a.topic_DEPRECATED != null) b.writeString(a.topic_DEPRECATED);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        if (a.recipients != null) {
            b.writeFieldBegin({
                fname: "recipients",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 3
            });
            b.writeSetBegin({
                etype: h.STRING,
                size: a.recipients.size
            });
            for (var d = a.recipients, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        if (a.serviceSender != null) {
            b.writeFieldBegin({
                fname: "serviceSender",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 4
            });
            b.writeI32((g = a.serviceSender) != null ? g : 0);
            b.writeFieldEnd()
        }
        if (a.serviceRecipients != null) {
            b.writeFieldBegin({
                fname: "serviceRecipients",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 5
            });
            b.writeSetBegin({
                etype: h.I32,
                size: a.serviceRecipients.size
            });
            for (f = a.serviceRecipients, e = Array.isArray(f), d = 0, f = e ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (d >= f.length) break;
                    g = f[d++]
                } else {
                    d = f.next();
                    if (d.done) break;
                    g = d.value
                }
                g = g;
                b.writeI32((g = g) != null ? g : 0)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        a.shouldSendToAllUsers != null && (b.writeFieldBegin({
            fname: "shouldSendToAllUsers",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 6
        }), b.writeBool(a.shouldSendToAllUsers), b.writeFieldEnd());
        a.senderE2eeId != null && (b.writeFieldBegin({
            fname: "senderE2eeId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 7
        }), b.writeBinary(a.senderE2eeId), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function y(a, b) {
        b.writeStructBegin("SpeakerDetail");
        b.writeFieldBegin({
            fname: "userId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.userId != null) b.writeString(a.userId);
        else {
            a = "";
            b.writeString(a)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function z(a, b) {
        b.writeStructBegin("DominantSpeakerNotification");
        b.writeFieldBegin({
            fname: "userId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.userId != null) b.writeString(a.userId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "cname",
            ftype: h.STRING,
            fid: 2
        });
        if (a.cname != null) b.writeString(a.cname);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "trackIds",
            ftype: h.LIST,
            fid: 4
        });
        if (a.trackIds != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: a.trackIds.length
            });
            for (var d = a.trackIds, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeListEnd()
        } else {
            g = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: g.length
            });
            for (f = 0; f < g.length; f++) {
                e = g[f];
                b.writeString(e)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "transactionId",
            ftype: h.I64,
            fid: 5
        });
        if (a.transactionId != null) b.writeI64(BigInt(a.transactionId));
        else {
            d = "0";
            b.writeI64(BigInt(d))
        }
        b.writeFieldEnd();
        if (a.dominantSpeakers != null) {
            b.writeFieldBegin({
                fname: "dominantSpeakers",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 6
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.dominantSpeakers.length
            });
            for (e = a.dominantSpeakers, g = Array.isArray(e), f = 0, e = g ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (g) {
                    if (f >= e.length) break;
                    d = e[f++]
                } else {
                    f = e.next();
                    if (f.done) break;
                    d = f.value
                }
                a = d;
                y(a, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function A(a, b) {
        b.writeStructBegin("VideoUploadRequest");
        b.writeFieldBegin({
            fname: "cname",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.cname != null) b.writeString(a.cname);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "quality_DEPRECATED",
            ftype: h.I32,
            fid: 2
        });
        if (a.quality_DEPRECATED != null) {
            b.writeI32((e = a.quality_DEPRECATED) != null ? e : 0)
        } else {
            e = d("MultiwaySharedTypes").VideoQuality.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.qualityMask != null && (b.writeFieldBegin({
            fname: "qualityMask",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 3
        }), b.writeI32(a.qualityMask), b.writeFieldEnd());
        if (a.perSsrcTargetBitrateBpsMap != null) {
            b.writeFieldBegin({
                fname: "perSsrcTargetBitrateBpsMap",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 4
            });
            b.writeMapBegin({
                ktype: h.I64,
                vtype: h.I64,
                size: Object.keys(a.perSsrcTargetBitrateBpsMap).length
            });
            e = Object.entries(a.perSsrcTargetBitrateBpsMap);
            for (a = 0; a < e.length; a++) {
                var f = e[a],
                    g = f[0];
                f = f[1];
                b.writeI64(BigInt(g));
                b.writeI64(BigInt(f))
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function B(a, b) {
        b.writeStructBegin("ReceiverBottleneck");
        b.writeFieldBegin({
            fname: "userId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.userId != null) b.writeString(a.userId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "bottleneckBps",
            ftype: h.I32,
            fid: 2
        });
        if (a.bottleneckBps != null) b.writeI32(a.bottleneckBps);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function C(a, b) {
        b.writeStructBegin("BweDebugInfo");
        b.writeFieldBegin({
            fname: "bottleneckUplinksByLayer",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.bottleneckUplinksByLayer != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.STRUCT,
                size: Object.keys(a.bottleneckUplinksByLayer).length
            });
            a = Object.entries(a.bottleneckUplinksByLayer);
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = e[0];
                e = e[1];
                b.writeI32(Number(f));
                B(e, b)
            }
            b.writeMapEnd()
        } else {
            f = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.STRUCT,
                size: Object.keys(f).length
            });
            e = Object.entries(f);
            for (a = 0; a < e.length; a++) {
                d = e[a];
                f = d[0];
                d = d[1];
                b.writeI32(Number(f));
                B(d, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function D(a, b) {
        b.writeStructBegin("AudioDuplicationDebugInfo");
        b.writeFieldBegin({
            fname: "duplicationAmount",
            ftype: (h || (h = c("ThriftTypes"))).I16,
            fid: 1
        });
        if (a.duplicationAmount != null) b.writeI16(a.duplicationAmount);
        else {
            var d = 0;
            b.writeI16(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "delayMs",
            ftype: h.I16,
            fid: 2
        });
        if (a.delayMs != null) b.writeI16(a.delayMs);
        else {
            d = 0;
            b.writeI16(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function E(a, b) {
        b.writeStructBegin("ReceiveTrackDebugInfo"), a.trackId != null && (b.writeFieldBegin({
            fname: "trackId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.trackId), b.writeFieldEnd()), a.numSimulcastLayersSupported != null && (b.writeFieldBegin({
            fname: "numSimulcastLayersSupported",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        }), b.writeI32(a.numSimulcastLayersSupported), b.writeFieldEnd()), a.numSimulcastLayersAllocated != null && (b.writeFieldBegin({
            fname: "numSimulcastLayersAllocated",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 3
        }), b.writeI32(a.numSimulcastLayersAllocated), b.writeFieldEnd()), a.spatialLayerIndex != null && (b.writeFieldBegin({
            fname: "spatialLayerIndex",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 4
        }), b.writeI32(a.spatialLayerIndex), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function F(a, b) {
        b.writeStructBegin("DebugInfo");
        a.audioDuplicationDebugInfo != null && (b.writeFieldBegin({
            fname: "audioDuplicationDebugInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), D(a.audioDuplicationDebugInfo, b), b.writeFieldEnd());
        if (a.receiveTrackDebugInfo != null) {
            b.writeFieldBegin({
                fname: "receiveTrackDebugInfo",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 2
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.receiveTrackDebugInfo.length
            });
            for (var a = a.receiveTrackDebugInfo, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                E(f, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function G(a, b) {
        b.writeStructBegin("DominantSpeakerInfo");
        b.writeFieldBegin({
            fname: "primarySpeakerUserId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.primarySpeakerUserId != null) b.writeString(a.primarySpeakerUserId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "transactionId",
            ftype: h.I64,
            fid: 2
        });
        if (a.transactionId != null) b.writeI64(BigInt(a.transactionId));
        else {
            d = "0";
            b.writeI64(BigInt(d))
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function H(a, b) {
        b.writeStructBegin("VideoUploadInfo");
        a.qualityMask != null && (b.writeFieldBegin({
            fname: "qualityMask",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        }), b.writeI32(a.qualityMask), b.writeFieldEnd());
        if (a.perSsrcTargetBitrateBpsMap != null) {
            b.writeFieldBegin({
                fname: "perSsrcTargetBitrateBpsMap",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 2
            });
            b.writeMapBegin({
                ktype: h.I64,
                vtype: h.I64,
                size: Object.keys(a.perSsrcTargetBitrateBpsMap).length
            });
            a = Object.entries(a.perSsrcTargetBitrateBpsMap);
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = e[0];
                e = e[1];
                b.writeI64(BigInt(f));
                b.writeI64(BigInt(e))
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function I(a, b) {
        b.writeStructBegin("SignalingMessageToClient");
        b.writeFieldBegin({
            fname: "signalingMessagePayload",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.signalingMessagePayload != null) b.writeBinary(a.signalingMessagePayload);
        else {
            var d = Uint8Array.of();
            b.writeBinary(d)
        }
        b.writeFieldEnd();
        a.version != null && (b.writeFieldBegin({
            fname: "version",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 2
        }), b.writeI64(BigInt(a.version)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function J(a, b) {
        b.writeStructBegin("SignalingMessageFromClient");
        b.writeFieldBegin({
            fname: "signalingMessagePayload",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.signalingMessagePayload != null) b.writeBinary(a.signalingMessagePayload);
        else {
            var d = Uint8Array.of();
            b.writeBinary(d)
        }
        b.writeFieldEnd();
        a.version != null && (b.writeFieldBegin({
            fname: "version",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 2
        }), b.writeI64(BigInt(a.version)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function K(a, b) {
        b.writeStructBegin("SubscriptionMessageFromClient");
        b.writeFieldBegin({
            fname: "subscriptionMessagePayload",
            ftype: (h || (h = c("ThriftTypes"))).LIST,
            fid: 1
        });
        if (a.subscriptionMessagePayload != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.subscriptionMessagePayload.length
            });
            for (var a = a.subscriptionMessagePayload, e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= a.length) break;
                    g = a[f++]
                } else {
                    f = a.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                d("MultiwaySharedSerializers").serializeSubscription(g, b)
            }
            b.writeListEnd()
        } else {
            g = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: g.length
            });
            for (f = 0; f < g.length; f++) {
                e = g[f];
                d("MultiwaySharedSerializers").serializeSubscription(e, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function L(a, b) {
        b.writeStructBegin("RenderResolutionMessageFromClient");
        if (a.renderResolutionMap != null) {
            b.writeFieldBegin({
                fname: "renderResolutionMap",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 1
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.MAP,
                size: Object.keys(a.renderResolutionMap).length
            });
            a = Object.entries(a.renderResolutionMap);
            for (var e = 0; e < a.length; e++) {
                var f = a[e],
                    g = f[0];
                f = f[1];
                b.writeString(g);
                b.writeMapBegin({
                    ktype: (h || (h = c("ThriftTypes"))).I32,
                    vtype: h.STRUCT,
                    size: Object.keys(f).length
                });
                g = Object.entries(f);
                for (f = 0; f < g.length; f++) {
                    var i = g[f],
                        j = i[0];
                    i = i[1];
                    b.writeI32((j = Number(j)) != null ? j : 0);
                    d("MultiwaySharedSerializers").serializeResolutionData(i, b)
                }
                b.writeMapEnd()
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function aa(a, b) {
        b.writeStructBegin("RenderResolutionMessageToClient");
        if (a.renderResolutionMap != null) {
            b.writeFieldBegin({
                fname: "renderResolutionMap",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 1
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.MAP,
                size: Object.keys(a.renderResolutionMap).length
            });
            a = Object.entries(a.renderResolutionMap);
            for (var e = 0; e < a.length; e++) {
                var f = a[e],
                    g = f[0];
                f = f[1];
                b.writeString(g);
                b.writeMapBegin({
                    ktype: (h || (h = c("ThriftTypes"))).I32,
                    vtype: h.STRUCT,
                    size: Object.keys(f).length
                });
                g = Object.entries(f);
                for (f = 0; f < g.length; f++) {
                    var i = g[f],
                        j = i[0];
                    i = i[1];
                    b.writeI32((j = Number(j)) != null ? j : 0);
                    d("MultiwaySharedSerializers").serializeResolutionData(i, b)
                }
                b.writeMapEnd()
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ba(a, b) {
        b.writeStructBegin("NodeIdNotification");
        b.writeFieldBegin({
            fname: "nodeIdToUserIdMap",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.nodeIdToUserIdMap != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I64,
                vtype: h.I64,
                size: Object.keys(a.nodeIdToUserIdMap).length
            });
            var d = Object.entries(a.nodeIdToUserIdMap);
            for (var e = 0; e < d.length; e++) {
                var f = d[e],
                    g = f[0];
                f = f[1];
                b.writeI64(BigInt(g));
                b.writeI64(BigInt(f))
            }
            b.writeMapEnd()
        } else {
            g = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I64,
                vtype: h.I64,
                size: Object.keys(g).length
            });
            f = Object.entries(g);
            for (d = 0; d < f.length; d++) {
                e = f[d];
                g = e[0];
                e = e[1];
                b.writeI64(BigInt(g));
                b.writeI64(BigInt(e))
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "nodeIdToServiceTypeMap",
            ftype: h.MAP,
            fid: 2
        });
        if (a.nodeIdToServiceTypeMap != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I64,
                vtype: h.I32,
                size: Object.keys(a.nodeIdToServiceTypeMap).length
            });
            g = Object.entries(a.nodeIdToServiceTypeMap);
            for (e = 0; e < g.length; e++) {
                f = g[e];
                d = f[0];
                a = f[1];
                b.writeI64(BigInt(d));
                b.writeI32((f = a) != null ? f : 0)
            }
            b.writeMapEnd()
        } else {
            d = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I64,
                vtype: h.I32,
                size: Object.keys(d).length
            });
            a = Object.entries(d);
            for (f = 0; f < a.length; f++) {
                g = a[f];
                e = g[0];
                d = g[1];
                b.writeI64(BigInt(e));
                b.writeI32((g = d) != null ? g : 0)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function M(a, b) {
        b.writeStructBegin("DataMessageBody"), a.genericMessage != null && (b.writeFieldBegin({
            fname: "genericMessage",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), d("WebrtcSignalingCommonSerializers").serializeGenericDataMessage(a.genericMessage, b), b.writeFieldEnd()), a.dominantSpeakerNotification != null && (b.writeFieldBegin({
            fname: "dominantSpeakerNotification",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), z(a.dominantSpeakerNotification, b), b.writeFieldEnd()), a.videoUploadRequest != null && (b.writeFieldBegin({
            fname: "videoUploadRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 3
        }), A(a.videoUploadRequest, b), b.writeFieldEnd()), a.dominantSpeakerSignalingInfo != null && (b.writeFieldBegin({
            fname: "dominantSpeakerSignalingInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 4
        }), G(a.dominantSpeakerSignalingInfo, b), b.writeFieldEnd()), a.bweDebugInfo != null && (b.writeFieldBegin({
            fname: "bweDebugInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 5
        }), C(a.bweDebugInfo, b), b.writeFieldEnd()), a.debugInfo != null && (b.writeFieldBegin({
            fname: "debugInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 6
        }), F(a.debugInfo, b), b.writeFieldEnd()), a.videoUploadSignalingInfo != null && (b.writeFieldBegin({
            fname: "videoUploadSignalingInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 7
        }), H(a.videoUploadSignalingInfo, b), b.writeFieldEnd()), a.signalingMessageToClient != null && (b.writeFieldBegin({
            fname: "signalingMessageToClient",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 8
        }), I(a.signalingMessageToClient, b), b.writeFieldEnd()), a.signalingMessageFromClient != null && (b.writeFieldBegin({
            fname: "signalingMessageFromClient",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 9
        }), J(a.signalingMessageFromClient, b), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function ca(a, b) {
        b.writeStructBegin("DataMessage");
        b.writeFieldBegin({
            fname: "header",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        });
        if (a.header != null) x(a.header, b);
        else {
            var d = i();
            x(d, b)
        }
        b.writeFieldEnd();
        a.data_DEPRECATED != null && (b.writeFieldBegin({
            fname: "data_DEPRECATED",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeBinary(a.data_DEPRECATED), b.writeFieldEnd());
        a.body != null && (b.writeFieldBegin({
            fname: "body",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 3
        }), M(a.body, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function N(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sender = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.topic_DEPRECATED = a.readString() : a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.recipients = new Set();
                        e = a.readSetBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString();
                            b.recipients.add(i)
                        }
                    } else a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.serviceSender = d("MultiwaySharedTypes").EndpointServiceType.cast(a.readI32()) : a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.serviceRecipients = new Set();
                        i = a.readSetBegin();
                        for (g = 0; g < i.size; g++) {
                            e = d("MultiwaySharedTypes").EndpointServiceType.cast(a.readI32());
                            b.serviceRecipients.add(e)
                        }
                    } else a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.shouldSendToAllUsers = a.readBool() : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.senderE2eeId = a.readBinary() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.topic_DEPRECATED === void 0 && (b.topic_DEPRECATED = "");
        return b
    }

    function O(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.userId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.userId === void 0 && (b.userId = "");
        return b
    }

    function P(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.userId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.cname = a.readString() : a.skip(e);
                    break;
                case 4:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.trackIds = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString();
                            b.trackIds.push(g)
                        }
                    } else a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.transactionId = a.readI64().toString() : a.skip(e);
                    break;
                case 6:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.dominantSpeakers = [];
                        g = a.readListBegin();
                        for (f = 0; f < g.size; f++) {
                            d = O(a);
                            b.dominantSpeakers.push(d)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.userId === void 0 && (b.userId = "");
        b.cname === void 0 && (b.cname = "");
        b.trackIds === void 0 && (b.trackIds = []);
        b.transactionId === void 0 && (b.transactionId = "0");
        return b
    }

    function Q(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.cname = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.quality_DEPRECATED = d("MultiwaySharedTypes").VideoQuality.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.qualityMask = a.readI32() : a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.perSsrcTargetBitrateBpsMap = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readI64().toString(),
                                j = a.readI64().toString();
                            b.perSsrcTargetBitrateBpsMap[i] = j
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.cname === void 0 && (b.cname = "");
        b.quality_DEPRECATED === void 0 && (b.quality_DEPRECATED = d("MultiwaySharedTypes").VideoQuality.cast(0));
        return b
    }

    function R(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.userId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.bottleneckBps = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.userId === void 0 && (b.userId = "");
        b.bottleneckBps === void 0 && (b.bottleneckBps = 0);
        return b
    }

    function S(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).MAP) {
                        b.bottleneckUplinksByLayer = {};
                        d = a.readMapBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readI32(),
                                i = R(a);
                            b.bottleneckUplinksByLayer[g] = i
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.bottleneckUplinksByLayer === void 0 && (b.bottleneckUplinksByLayer = {});
        return b
    }

    function T(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I16 ? b.duplicationAmount = a.readI16() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I16 ? b.delayMs = a.readI16() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.duplicationAmount === void 0 && (b.duplicationAmount = 0);
        b.delayMs === void 0 && (b.delayMs = 0);
        return b
    }

    function U(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.trackId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.numSimulcastLayersSupported = a.readI32() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.numSimulcastLayersAllocated = a.readI32() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.spatialLayerIndex = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function V(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.audioDuplicationDebugInfo = T(a) : a.skip(e);
                    break;
                case 2:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.receiveTrackDebugInfo = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = U(a);
                            b.receiveTrackDebugInfo.push(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function W(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.primarySpeakerUserId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.transactionId = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.primarySpeakerUserId === void 0 && (b.primarySpeakerUserId = "");
        b.transactionId === void 0 && (b.transactionId = "0");
        return b
    }

    function X(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.qualityMask = a.readI32() : a.skip(e);
                    break;
                case 2:
                    if (e === (h || (h = c("ThriftTypes"))).MAP) {
                        b.perSsrcTargetBitrateBpsMap = {};
                        d = a.readMapBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readI64().toString(),
                                i = a.readI64().toString();
                            b.perSsrcTargetBitrateBpsMap[g] = i
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Y(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.signalingMessagePayload = a.readBinary() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.version = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.signalingMessagePayload === void 0 && (b.signalingMessagePayload = Uint8Array.of());
        return b
    }

    function Z(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.signalingMessagePayload = a.readBinary() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.version = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.signalingMessagePayload === void 0 && (b.signalingMessagePayload = Uint8Array.of());
        return b
    }

    function da(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.subscriptionMessagePayload = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("MultiwaySharedSerializers").deserializeSubscription(a);
                            b.subscriptionMessagePayload.push(i)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.subscriptionMessagePayload === void 0 && (b.subscriptionMessagePayload = []);
        return b
    }

    function ea(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.renderResolutionMap = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = {},
                                k = a.readMapBegin();
                            for (var l = 0; l < k.size; l++) {
                                var m = d("MultiwaySharedTypes").RenderedStreamType.cast(a.readI32()),
                                    n = d("MultiwaySharedSerializers").deserializeResolutionData(a);
                                m != null && (j[m] = n)
                            }
                            b.renderResolutionMap[i] = j
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function fa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.renderResolutionMap = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = {},
                                k = a.readMapBegin();
                            for (var l = 0; l < k.size; l++) {
                                var m = d("MultiwaySharedTypes").RenderedStreamType.cast(a.readI32()),
                                    n = d("MultiwaySharedSerializers").deserializeResolutionData(a);
                                m != null && (j[m] = n)
                            }
                            b.renderResolutionMap[i] = j
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function ga(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.nodeIdToUserIdMap = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readI64().toString(),
                                j = a.readI64().toString();
                            b.nodeIdToUserIdMap[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.nodeIdToServiceTypeMap = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = a.readI64().toString();
                            e = d("MultiwaySharedTypes").EndpointServiceType.cast(a.readI32());
                            b.nodeIdToServiceTypeMap[g] = e
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.nodeIdToUserIdMap === void 0 && (b.nodeIdToUserIdMap = {});
        b.nodeIdToServiceTypeMap === void 0 && (b.nodeIdToServiceTypeMap = {});
        return b
    }

    function $(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.genericMessage = d("WebrtcSignalingCommonSerializers").deserializeGenericDataMessage(a) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.dominantSpeakerNotification = P(a) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.videoUploadRequest = Q(a) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.dominantSpeakerSignalingInfo = W(a) : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.bweDebugInfo = S(a) : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.debugInfo = V(a) : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.videoUploadSignalingInfo = X(a) : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.signalingMessageToClient = Y(a) : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.signalingMessageFromClient = Z(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function ha(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.header = N(a) : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.data_DEPRECATED = a.readBinary() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.body = $(a) : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.header === void 0 && (b.header = i());
        return b
    }
    g.DataHeader$DefaultConstructor = i;
    g.SpeakerDetail$DefaultConstructor = a;
    g.DominantSpeakerNotification$DefaultConstructor = b;
    g.VideoUploadRequest$DefaultConstructor = e;
    g.ReceiverBottleneck$DefaultConstructor = f;
    g.BweDebugInfo$DefaultConstructor = j;
    g.AudioDuplicationDebugInfo$DefaultConstructor = k;
    g.ReceiveTrackDebugInfo$DefaultConstructor = l;
    g.DebugInfo$DefaultConstructor = m;
    g.DominantSpeakerInfo$DefaultConstructor = n;
    g.VideoUploadInfo$DefaultConstructor = o;
    g.SignalingMessageToClient$DefaultConstructor = p;
    g.SignalingMessageFromClient$DefaultConstructor = q;
    g.SubscriptionMessageFromClient$DefaultConstructor = r;
    g.RenderResolutionMessageFromClient$DefaultConstructor = s;
    g.RenderResolutionMessageToClient$DefaultConstructor = t;
    g.NodeIdNotification$DefaultConstructor = u;
    g.DataMessageBody$DefaultConstructor = v;
    g.DataMessage$DefaultConstructor = w;
    g.serializeDataHeader = x;
    g.serializeSpeakerDetail = y;
    g.serializeDominantSpeakerNotification = z;
    g.serializeVideoUploadRequest = A;
    g.serializeReceiverBottleneck = B;
    g.serializeBweDebugInfo = C;
    g.serializeAudioDuplicationDebugInfo = D;
    g.serializeReceiveTrackDebugInfo = E;
    g.serializeDebugInfo = F;
    g.serializeDominantSpeakerInfo = G;
    g.serializeVideoUploadInfo = H;
    g.serializeSignalingMessageToClient = I;
    g.serializeSignalingMessageFromClient = J;
    g.serializeSubscriptionMessageFromClient = K;
    g.serializeRenderResolutionMessageFromClient = L;
    g.serializeRenderResolutionMessageToClient = aa;
    g.serializeNodeIdNotification = ba;
    g.serializeDataMessageBody = M;
    g.serializeDataMessage = ca;
    g.deserializeDataHeader = N;
    g.deserializeSpeakerDetail = O;
    g.deserializeDominantSpeakerNotification = P;
    g.deserializeVideoUploadRequest = Q;
    g.deserializeReceiverBottleneck = R;
    g.deserializeBweDebugInfo = S;
    g.deserializeAudioDuplicationDebugInfo = T;
    g.deserializeReceiveTrackDebugInfo = U;
    g.deserializeDebugInfo = V;
    g.deserializeDominantSpeakerInfo = W;
    g.deserializeVideoUploadInfo = X;
    g.deserializeSignalingMessageToClient = Y;
    g.deserializeSignalingMessageFromClient = Z;
    g.deserializeSubscriptionMessageFromClient = da;
    g.deserializeRenderResolutionMessageFromClient = ea;
    g.deserializeRenderResolutionMessageToClient = fa;
    g.deserializeNodeIdNotification = ga;
    g.deserializeDataMessageBody = $;
    g.deserializeDataMessage = ha
}), 98);
__d("DataMessageTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        OK: 200,
        NOT_FOUND: 404
    });
    e.exports = {
        DataMessageStatusCode: a
    }
}), null);
__d("MqttThriftHeaderSerializers", ["ThriftTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        return {}
    }

    function b(a, b) {
        b.writeStructBegin("MqttThriftHeader"), a.traceInfo != null && (b.writeFieldBegin({
            fname: "traceInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.traceInfo), b.writeFieldEnd()), a.coreContextRequestId != null && (b.writeFieldBegin({
            fname: "coreContextRequestId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.coreContextRequestId), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function d(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.traceInfo = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.coreContextRequestId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }
    g.MqttThriftHeader$DefaultConstructor = a;
    g.serializeMqttThriftHeader = b;
    g.deserializeMqttThriftHeader = d
}), 98);
__d("StateSyncTopicsConfigTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    c = (a = b("$InternalEnum"))({
        UNKNOWN: 0,
        INTERNAL: 1,
        EXTERNAL: 2
    });
    d = a({
        UNKNOWN: 0,
        PARTICIPANT_JOIN: 100,
        PARTICIPANT_UPDATE: 101,
        PARTICIPANT_LEAVE: 102,
        PARTICIPANT_NEGOTIATED: 103,
        PARTICIPANT_SDP_CHANGED: 104,
        EXTENSION_CREATION: 201,
        EXTENSION_JOIN: 202,
        EXTENSION_UPDATE: 203,
        EXTENSION_LEAVE: 204,
        EXTENSION_REQUEST: 205,
        CONFERENCE_UPDATE: 501,
        DOMINANT_SPEAKER_UPDATE: 1001,
        MEDIA_ASPECT_RATIO_UPDATE: 1002,
        TIMER_FIRED: 1003,
        MEDIA_PATH_CHANGED: 1004,
        PARTICIPANTS_ACKED_MEDIA: 1005
    });
    f = a({
        UNKNOWN: 0,
        ANY_PARTICIPANT_SUBSCRIBED: 1,
        ALWAYS_RESOLVE: 2
    });
    b = a({
        CACHIUS: 1,
        IRIS: 2
    });
    a = a({
        Config_engine: 1,
        E2eeState: 2,
        Media_information: 3,
        Breakout: 4,
        Countdown_timer: 5,
        Effect_match: 6,
        Emoji_reactions: 7,
        Entered_avatars_mode: 8,
        Moderator_controls: 9,
        Polls: 10,
        Raised_hands_queue: 11,
        Xac_calling: 12,
        Action_items: 13,
        Can_you_see_my_screen: 14,
        Collage: 15,
        Companion: 16,
        Coplay: 17,
        Coview: 18,
        Custom_video_capabilities: 19,
        Dropin: 20,
        Dtmf: 21,
        E2ee_v2_msg: 22,
        Effect_sync: 23,
        Et_pluto_activity: 24,
        Et_pluto_session: 25,
        Et_test_activity: 26,
        Et_test_session: 27,
        Et_tubi_activity: 28,
        Et_tubi_session: 29,
        External_resolution_enabled: 30,
        Hyperspace_copresence_state: 31,
        Hyperspace_mic_state: 32,
        Intenticons: 33,
        Live_stream: 34,
        Live_stream_app_message: 35,
        Max_video_subscriptions: 36,
        Media_sync: 37,
        Media_sync_autoplay: 38,
        Meeting_assistant: 39,
        Meeting_transcription: 40,
        Morpheo_grid: 41,
        Multipeer_ar: 42,
        Number_of_people: 43,
        Opaque_blob: 44,
        Photo_booth: 45,
        Qna: 46,
        Quizzes: 47,
        Reactions: 48,
        Role_assignments: 49,
        Room_features_availability: 50,
        Rooms_notes: 51,
        Screenshare_floor_control: 52,
        Screenshare_single_floor_control: 53,
        Sctp_negotiation: 54,
        Sideband: 55,
        Simple: 56,
        Simple_external: 57,
        Simple_pass_through: 58,
        Simple_passthrough: 59,
        Snippets: 60,
        Sound_effects: 61,
        Whiteboard: 62,
        Whiteboard_messenger: 63,
        Workroom: 64,
        Workrooms_ask_everyone_to_open: 65,
        Workrooms_vr: 66,
        Avatar_transport_state: 67,
        Ambisonic: 68,
        Cathode_extension: 69,
        Biz_calling: 70,
        Work_costreaming: 71,
        Conversation_bot: 72,
        Voip_zone: 73,
        Admin_initiated_casting: 74
    });
    e.exports = {
        CryptoAuthVerifierIdentity: b,
        DataSource: d,
        DataSourceCondition: f,
        ResolutionPath: c,
        TopicId: a
    }
}), null);
__d("WebrtcEnumsTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    c = (a = b("$InternalEnum"))({
        OFFER: 0,
        ANSWER: 1,
        ICE_CANDIDATE: 2,
        OK: 3,
        HANG_UP: 4,
        OTHER_DISMISS: 5,
        PRANSWER: 7,
        PING: 8,
        PING_ACK: 9,
        ICE_RESTART_OFFER: 10,
        ICE_RESTART_ANSWER: 11,
        OFFER_ACK: 12,
        ANSWER_ACK: 13,
        NOTIFY_MEDIA_STATE: 14,
        ACK: 15,
        INVALID: 16,
        OFFER_NACK: 17,
        NACK: 18,
        VIDEO_REQUEST: 19,
        SDP_UPDATE: 20,
        SWITCH_TO_MULTIWAY: 28,
        NEGOTIATE: 30,
        PR_OFFER_ACK: 32,
        CLIENT_REPORTED_EVENT: 33
    });
    d = a({
        OFFER: 0,
        ANSWER: 1
    });
    f = a({
        LL_NIL: 0,
        LL_BASIC: 1,
        LL_DEBUG: 2,
        LL_WARNING: 3,
        LL_INFO: 4,
        LL_VERBOSE: 5
    });
    b = a({
        IGNORE_CALL: 0,
        HANGUP_CALL: 1,
        IN_ANOTHER_CALL: 2,
        ACCEPT_AFTER_HANGUP: 3,
        NO_ANSWER_TIMEOUT: 4,
        INCOMING_TIMEOUT: 5,
        OTHER_INSTANCE_HANDLED: 6,
        SIGNALING_MESSAGE_FAILED: 7,
        CONNECTION_DROPPED: 8,
        CLIENT_INTERRUPTED: 9,
        WEBRTC_ERROR: 10,
        CLIENT_ERROR: 11,
        NO_PERMISSION: 12,
        OTHER_NOT_CAPABLE: 13,
        NO_UI_ERROR: 14,
        UNSUPPORTED_VERSION: 15,
        CALLER_NOT_VISIBLE: 16,
        CARRIER_BLOCKED: 17,
        OTHER_CARRIER_BLOCKED: 18,
        CLIENT_ENCRYPTION_ERROR: 19,
        MICROPHONE_PERMISSION_DENIED: 20,
        CAMERA_PERMISSION_DENIED: 21,
        SESSION_MIGRATED: 22,
        RING_MUTED: 23,
        MAX_ALLOWED_PARTICIPANTS_REACHED: 24,
        CALLEE_REQUIRES_MULTIWAY: 25,
        LIVE_NOT_ACKED: 26,
        TX_ACK_TIMEDOUT: 27,
        E2EE_MANDATED_BUT_OFFER_DID_NOT_CONTAIN_E2EE: 28,
        E2EE_MANDATED_BUT_ANSWER_DID_NOT_NEGOTIATE_E2EE: 29,
        ANSWERED_BY_OTHER_USER: 30,
        LONG_LASTING_AUDIO_ISSUE: 31,
        ADMIN_CALLING_OWN_PAGE: 32,
        PAGE_CALLS_BLOCKED: 33
    });
    var g = a({
            UDP: 0,
            TCP: 1,
            SSLTCP: 2
        }),
        h = a({
            HOST: 0,
            SERVER_REFLEXIVE: 1,
            PEER_REFLEXIVE: 2,
            RELAY: 3
        }),
        i = a({
            TCPTYPE_NONE: 0,
            TCPTYPE_PASSIVE: 1,
            TCPTYPE_ACTIVE: 2,
            TCPTYPE_SIMOPEN: 3
        }),
        j = a({
            SENDONLY: 0,
            SENDRECV: 1,
            RECVONLY: 2,
            INACTIVE: 3
        }),
        k = a({
            AUDIO: 0,
            VIDEO: 1,
            DATA: 2
        }),
        l = a({
            AUDIO: 0,
            VIDEO: 1,
            SCREEN: 2
        }),
        m = a({
            AES_CM_128_HMAC_SHA1_80: 0,
            AES_CM_128_HMAC_SHA1_32: 1,
            F8_128_HMAC_SHA1_80: 2,
            AEAD_AES_256_GCM: 8
        }),
        n = a({
            RTP_SAVPF: 0,
            DTLS_SCTP: 1,
            SCTP: 2
        }),
        o = a({
            URN_IETF_PARAMS_RTP_HDREXT_SSRC_AUDIO_LEVEL: 0,
            URN_IETF_PARAMS_RTP_HDREXT_TOFFSET: 1,
            IETF_DRAFT_HOLMER_RMCAT_TRANSPORT_WIDE_CC_01: 2,
            URN_3GPP_VIDEO_ORIENTATION: 3,
            ABS_SEND_TIME: 4,
            PLAYOUT_DELAY: 5,
            VIDEO_CONTENT_TYPE: 6,
            VIDEO_TIMING: 7,
            RTP_MID: 8,
            RTP_STREAM_ID: 9,
            RTP_REPAIRED_STREAM_ID: 10,
            ENCRYPT_EXTENSIONS: 11,
            FRAME_MARKING: 12,
            GENERIC_FRAME_DESCRIPTOR: 13,
            RTP_LOSS_INFO: 14,
            RTP_CONGESTION_INFO: 15,
            RTP_AUDIO_DROP_INFO: 16,
            FRAME_ENCRYPTION_INFO: 17,
            GENERIC_FRAME_DESCRIPTOR_01: 18,
            DEPENDENCY_DESCRIPTOR: 19,
            COLOR_SPACE: 20,
            ABS_CAPTURE_TIME: 21,
            VIDEO_FRAME_TRACKING_ID: 22
        }),
        p = a({
            ISAC: 0,
            SPEEX_ISAC_OBSOLETE: 1,
            SPEEX: 2,
            OPUS: 3,
            PCMU_OBSOLETE: 4,
            PCMA_OBSOLETE: 5,
            CN: 6,
            TELEPHONE_EVENT: 7,
            VP8: 8,
            RED: 9,
            ULPFEC: 10,
            H264: 17,
            ISPX_WB_2: 32,
            GOOGLE_DATA: 33,
            AAC: 36,
            AAC_LD: 37,
            VP9: 96,
            GOOGLE_SCTP_DATA: 97,
            H265: 98,
            RTX: 99,
            FLEXFEC: 100,
            MULTIPLEX: 101,
            VIDEO_DATA: 102,
            AV1: 103
        }),
        q = a({
            SILENCEBIT_OBSOLETE: 0,
            SPEEXUSEJITTERBIT_OBSOLETE: 1,
            USEINBANDFEC: 2,
            USEADAPTIVEFEC_OBSOLETE: 3,
            EXTERNALBWE_OBSOLETE: 4,
            FEC_BEI_OBSOLETE: 5,
            ISPX_ADAPTIVE_FEC: 6,
            CBR: 7,
            USEDTX: 8
        }),
        r = a({
            MINPTIME: 0,
            MAXAVERAGEBITRATE: 1,
            SPROP_STEREO: 2,
            STEREO: 3,
            MAXPTIME: 4,
            PTIME: 5,
            FEC_BEI_OBSOLETE: 6,
            PORT: 7,
            H264PROFILELEVELID: 8,
            PACKETIZATION_MODE: 9,
            LEVEL_ASYMMETRY_ALLOWED: 10,
            APT: 11,
            MAXPLAYBACKRATE: 12,
            REPAIR_WINDOW: 13,
            EMPTY_KEY: 14
        }),
        s = a({
            CR_NONE: 0,
            CR_ACTIVE: 1,
            CR_PASSIVE: 2,
            CR_ACTPASS: 3,
            CR_HOLDCONN: 4
        });
    a = a({
        EVENT_NONE: 0,
        EVENT_MEDIA_CONNECTED: 1
    });
    e.exports = {
        CallEndReason: b,
        ClientReportedEventType: a,
        CodecName: p,
        CodecOption: r,
        CodecOptionBoolean: q,
        ConnectionRole: s,
        CryptoSuite: m,
        ExtmapUris: o,
        IceCandidateProtocolType: h,
        IceCandidateTcpType: i,
        IceCandidateTransport: g,
        MediaProtocol: n,
        MediaType: k,
        PayloadType: c,
        SdpNegotiateType: d,
        SendRecvMode: j,
        StreamType: l,
        UploadLogLevel: f
    }
}), null);
__d("WebrtcSdpSerializers", ["ThriftTypes", "WebrtcEnumsTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        return {}
    }

    function b() {
        return {
            msid: "stream_label"
        }
    }

    function e() {
        return {
            id: ""
        }
    }

    function f() {
        return {
            bwtype: "",
            bw: 0
        }
    }

    function i() {
        return {
            numAudioChannels: 1
        }
    }

    function j() {
        return {
            id: 1,
            extensionAttributes: []
        }
    }

    function k() {
        return {}
    }

    function l() {
        return {
            componentId: 1,
            transport: d("WebrtcEnumsTypes").IceCandidateTransport.cast(0),
            generation: 0
        }
    }

    function m() {
        return {
            port: 1,
            protocol: d("WebrtcEnumsTypes").MediaProtocol.cast(0),
            sendRecvMode: d("WebrtcEnumsTypes").SendRecvMode.cast(1),
            hasRtcpMux: !0
        }
    }

    function n() {
        return {
            supportsMsid: !0
        }
    }

    function o() {
        return {}
    }

    function p(a, b) {
        b.writeStructBegin("SsrcGroup");
        a.semantics != null && (b.writeFieldBegin({
            fname: "semantics",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.semantics), b.writeFieldEnd());
        if (a.ssrcIds != null) {
            b.writeFieldBegin({
                fname: "ssrcIds",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 2
            });
            b.writeListBegin({
                etype: h.I32,
                size: a.ssrcIds.length
            });
            for (var a = a.ssrcIds, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                b.writeI32(f)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function q(a, b) {
        b.writeStructBegin("SsrcObject");
        a.ssrcId != null && (b.writeFieldBegin({
            fname: "ssrcId",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        }), b.writeI32(a.ssrcId), b.writeFieldEnd());
        a.cname != null && (b.writeFieldBegin({
            fname: "cname",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.cname), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "msid",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        });
        if (a.msid != null) b.writeString(a.msid);
        else {
            var d = "stream_label";
            b.writeString(d)
        }
        b.writeFieldEnd();
        a.msidAppData != null && (b.writeFieldBegin({
            fname: "msidAppData",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.msidAppData), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function r(a, b) {
        b.writeStructBegin("RtcpFbVal");
        b.writeFieldBegin({
            fname: "id",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.id != null) b.writeString(a.id);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        a.param != null && (b.writeFieldBegin({
            fname: "param",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.param), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function s(a, b) {
        b.writeStructBegin("Bandwidth");
        b.writeFieldBegin({
            fname: "bwtype",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.bwtype != null) b.writeString(a.bwtype);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "bw",
            ftype: h.I32,
            fid: 2
        });
        if (a.bw != null) b.writeI32(a.bw);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function t(a, b) {
        b.writeStructBegin("CodecDescription");
        a.payloadType != null && (b.writeFieldBegin({
            fname: "payloadType",
            ftype: (h || (h = c("ThriftTypes"))).BYTE,
            fid: 1
        }), b.writeByte(a.payloadType), b.writeFieldEnd());
        if (a.encodingName != null) {
            var d;
            b.writeFieldBegin({
                fname: "encodingName",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 2
            });
            b.writeI32((d = a.encodingName) != null ? d : 0);
            b.writeFieldEnd()
        }
        a.clockRateKhz != null && (b.writeFieldBegin({
            fname: "clockRateKhz",
            ftype: (h || (h = c("ThriftTypes"))).BYTE,
            fid: 3
        }), b.writeByte(a.clockRateKhz), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "numAudioChannels",
            ftype: (h || (h = c("ThriftTypes"))).BYTE,
            fid: 4
        });
        if (a.numAudioChannels != null) b.writeByte(a.numAudioChannels);
        else {
            d = 1;
            b.writeByte(d)
        }
        b.writeFieldEnd();
        if (a.fmtParameters != null) {
            b.writeFieldBegin({
                fname: "fmtParameters",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 5
            });
            b.writeMapBegin({
                ktype: h.I32,
                vtype: h.STRING,
                size: Object.keys(a.fmtParameters).length
            });
            d = Object.entries(a.fmtParameters);
            for (var e = 0; e < d.length; e++) {
                var f = d[e],
                    g = f[0];
                f = f[1];
                b.writeI32((g = Number(g)) != null ? g : 0);
                b.writeString(f)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.enabledOptions != null) {
            b.writeFieldBegin({
                fname: "enabledOptions",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 6
            });
            b.writeSetBegin({
                etype: h.I32,
                size: a.enabledOptions.size
            });
            for (g = a.enabledOptions, f = Array.isArray(g), d = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (d >= g.length) break;
                    e = g[d++]
                } else {
                    d = g.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                b.writeI32((e = e) != null ? e : 0)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        if (a.rtcpFbParameters != null) {
            b.writeFieldBegin({
                fname: "rtcpFbParameters",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 7
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRING,
                size: Object.keys(a.rtcpFbParameters).length
            });
            e = Object.entries(a.rtcpFbParameters);
            for (d = 0; d < e.length; d++) {
                f = e[d];
                g = f[0];
                f = f[1];
                b.writeString(g);
                b.writeString(f)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.rtcpFbParamList != null) {
            b.writeFieldBegin({
                fname: "rtcpFbParamList",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 10
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.rtcpFbParamList.length
            });
            for (g = a.rtcpFbParamList, f = Array.isArray(g), e = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (e >= g.length) break;
                    d = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    d = e.value
                }
                d = d;
                r(d, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.videoWidth != null && (b.writeFieldBegin({
            fname: "videoWidth",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 8
        }), b.writeI32(a.videoWidth), b.writeFieldEnd());
        a.videoHeight != null && (b.writeFieldBegin({
            fname: "videoHeight",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 9
        }), b.writeI32(a.videoHeight), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function u(a, b) {
        b.writeStructBegin("Extmap");
        b.writeFieldBegin({
            fname: "id",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.id != null) b.writeI32(a.id);
        else {
            var d = 1;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        if (a.uri != null) {
            b.writeFieldBegin({
                fname: "uri",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 2
            });
            b.writeI32((d = a.uri) != null ? d : 0);
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "extensionAttributes",
            ftype: h.LIST,
            fid: 3
        });
        if (a.extensionAttributes != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).I32,
                size: a.extensionAttributes.length
            });
            for (var d = a.extensionAttributes, a = Array.isArray(d), e = 0, d = a ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (a) {
                    if (e >= d.length) break;
                    f = d[e++]
                } else {
                    e = d.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                b.writeI32((f = f) != null ? f : 0)
            }
            b.writeListEnd()
        } else {
            f = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).I32,
                size: f.length
            });
            for (e = 0; e < f.length; e++) {
                a = f[e];
                b.writeI32((d = a) != null ? d : 0)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function v(a, b) {
        b.writeStructBegin("CryptoParam");
        a.tag != null && (b.writeFieldBegin({
            fname: "tag",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        }), b.writeI32(a.tag), b.writeFieldEnd());
        if (a.suite != null) {
            var d;
            b.writeFieldBegin({
                fname: "suite",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 2
            });
            b.writeI32((d = a.suite) != null ? d : 0);
            b.writeFieldEnd()
        }
        a.keyParams != null && (b.writeFieldBegin({
            fname: "keyParams",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        }), b.writeString(a.keyParams), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function w(a, b) {
        b.writeStructBegin("IceCandidateSdp");
        a.foundation != null && (b.writeFieldBegin({
            fname: "foundation",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.foundation), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "componentId",
            ftype: (h || (h = c("ThriftTypes"))).BYTE,
            fid: 2
        });
        if (a.componentId != null) b.writeByte(a.componentId);
        else {
            var e = 1;
            b.writeByte(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "transport",
            ftype: h.I32,
            fid: 3
        });
        if (a.transport != null) {
            b.writeI32((e = a.transport) != null ? e : 0)
        } else {
            e = d("WebrtcEnumsTypes").IceCandidateTransport.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.priority != null && (b.writeFieldBegin({
            fname: "priority",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 4
        }), b.writeI32(a.priority), b.writeFieldEnd());
        a.address != null && (b.writeFieldBegin({
            fname: "address",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 5
        }), b.writeString(a.address), b.writeFieldEnd());
        a.port != null && (b.writeFieldBegin({
            fname: "port",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 6
        }), b.writeI32(a.port), b.writeFieldEnd());
        if (a.protocolType != null) {
            b.writeFieldBegin({
                fname: "protocolType",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 7
            });
            b.writeI32((e = a.protocolType) != null ? e : 0);
            b.writeFieldEnd()
        }
        a.relatedAddress != null && (b.writeFieldBegin({
            fname: "relatedAddress",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 8
        }), b.writeString(a.relatedAddress), b.writeFieldEnd());
        a.relatedPort != null && (b.writeFieldBegin({
            fname: "relatedPort",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 9
        }), b.writeI32(a.relatedPort), b.writeFieldEnd());
        a.username != null && (b.writeFieldBegin({
            fname: "username",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 10
        }), b.writeString(a.username), b.writeFieldEnd());
        a.password != null && (b.writeFieldBegin({
            fname: "password",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 11
        }), b.writeString(a.password), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "generation",
            ftype: h.I32,
            fid: 12
        });
        if (a.generation != null) b.writeI32(a.generation);
        else {
            e = 0;
            b.writeI32(e)
        }
        b.writeFieldEnd();
        if (a.tcptype != null) {
            b.writeFieldBegin({
                fname: "tcptype",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 13
            });
            b.writeI32((e = a.tcptype) != null ? e : 0);
            b.writeFieldEnd()
        }
        a.networkId != null && (b.writeFieldBegin({
            fname: "networkId",
            ftype: (h || (h = c("ThriftTypes"))).I16,
            fid: 14
        }), b.writeI16(a.networkId), b.writeFieldEnd());
        a.networkCost != null && (b.writeFieldBegin({
            fname: "networkCost",
            ftype: (h || (h = c("ThriftTypes"))).I16,
            fid: 15
        }), b.writeI16(a.networkCost), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function x(a, b) {
        b.writeStructBegin("MediaDescription");
        if (a.mediaType != null) {
            var e;
            b.writeFieldBegin({
                fname: "mediaType",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 1
            });
            b.writeI32((e = a.mediaType) != null ? e : 0);
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "port",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        });
        if (a.port != null) b.writeI32(a.port);
        else {
            e = 1;
            b.writeI32(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "protocol",
            ftype: h.I32,
            fid: 3
        });
        if (a.protocol != null) {
            b.writeI32((e = a.protocol) != null ? e : 0)
        } else {
            e = d("WebrtcEnumsTypes").MediaProtocol.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.fmt != null && (b.writeFieldBegin({
            fname: "fmt",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 22
        }), b.writeString(a.fmt), b.writeFieldEnd());
        a.mediaIceUserFrag != null && (b.writeFieldBegin({
            fname: "mediaIceUserFrag",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.mediaIceUserFrag), b.writeFieldEnd());
        a.mediaIcePassword != null && (b.writeFieldBegin({
            fname: "mediaIcePassword",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 5
        }), b.writeString(a.mediaIcePassword), b.writeFieldEnd());
        if (a.mediaIceOptions != null) {
            b.writeFieldBegin({
                fname: "mediaIceOptions",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 6
            });
            b.writeListBegin({
                etype: h.STRING,
                size: a.mediaIceOptions.length
            });
            for (var e = a.mediaIceOptions, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                b.writeString(i)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.mediaSslFingerprintHash != null && (b.writeFieldBegin({
            fname: "mediaSslFingerprintHash",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 7
        }), b.writeString(a.mediaSslFingerprintHash), b.writeFieldEnd());
        a.mediaSslFingerprintDigest != null && (b.writeFieldBegin({
            fname: "mediaSslFingerprintDigest",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 8
        }), b.writeString(a.mediaSslFingerprintDigest), b.writeFieldEnd());
        if (a.extmaps != null) {
            b.writeFieldBegin({
                fname: "extmaps",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 9
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.extmaps.length
            });
            for (i = a.extmaps, g = Array.isArray(i), f = 0, i = g ? i : i[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (g) {
                    if (f >= i.length) break;
                    e = i[f++]
                } else {
                    f = i.next();
                    if (f.done) break;
                    e = f.value
                }
                e = e;
                u(e, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "sendRecvMode",
            ftype: h.I32,
            fid: 10
        });
        if (a.sendRecvMode != null) {
            b.writeI32((e = a.sendRecvMode) != null ? e : 0)
        } else {
            f = d("WebrtcEnumsTypes").SendRecvMode.cast(1);
            b.writeI32((g = f) != null ? g : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "hasRtcpMux",
            ftype: h.BOOL,
            fid: 11
        });
        if (a.hasRtcpMux != null) b.writeBool(a.hasRtcpMux);
        else {
            i = !0;
            b.writeBool(i)
        }
        b.writeFieldEnd();
        a.rtcpReducedSize != null && (b.writeFieldBegin({
            fname: "rtcpReducedSize",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 25
        }), b.writeBool(a.rtcpReducedSize), b.writeFieldEnd());
        if (a.cryptoParams != null) {
            b.writeFieldBegin({
                fname: "cryptoParams",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 12
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.cryptoParams.length
            });
            for (e = a.cryptoParams, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                v(i, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.codecs != null) {
            b.writeFieldBegin({
                fname: "codecs",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 13
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.codecs.length
            });
            for (i = a.codecs, g = Array.isArray(i), f = 0, i = g ? i : i[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (g) {
                    if (f >= i.length) break;
                    e = i[f++]
                } else {
                    f = i.next();
                    if (f.done) break;
                    e = f.value
                }
                e = e;
                t(e, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.maxPTime != null && (b.writeFieldBegin({
            fname: "maxPTime",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 14
        }), b.writeI32(a.maxPTime), b.writeFieldEnd());
        a.pTime != null && (b.writeFieldBegin({
            fname: "pTime",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 15
        }), b.writeI32(a.pTime), b.writeFieldEnd());
        if (a.ssrcObjects != null) {
            b.writeFieldBegin({
                fname: "ssrcObjects",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 16
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.ssrcObjects.length
            });
            for (e = a.ssrcObjects, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                q(i, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.candidates != null) {
            b.writeFieldBegin({
                fname: "candidates",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 17
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.candidates.length
            });
            for (i = a.candidates, g = Array.isArray(i), f = 0, i = g ? i : i[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (g) {
                    if (f >= i.length) break;
                    e = i[f++]
                } else {
                    f = i.next();
                    if (f.done) break;
                    e = f.value
                }
                e = e;
                w(e, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.conferenceMode != null && (b.writeFieldBegin({
            fname: "conferenceMode",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 18
        }), b.writeBool(a.conferenceMode), b.writeFieldEnd());
        if (a.ssrcGroups != null) {
            b.writeFieldBegin({
                fname: "ssrcGroups",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 19
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.ssrcGroups.length
            });
            for (e = a.ssrcGroups, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                p(i, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.connectionRole != null) {
            b.writeFieldBegin({
                fname: "connectionRole",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 20
            });
            b.writeI32((i = a.connectionRole) != null ? i : 0);
            b.writeFieldEnd()
        }
        a.mid != null && (b.writeFieldBegin({
            fname: "mid",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 21
        }), b.writeString(a.mid), b.writeFieldEnd());
        a.bandwidth != null && (b.writeFieldBegin({
            fname: "bandwidth",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 23
        }), s(a.bandwidth, b), b.writeFieldEnd());
        a.sctpPort != null && (b.writeFieldBegin({
            fname: "sctpPort",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 24
        }), b.writeI32(a.sctpPort), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function y(a, b) {
        b.writeStructBegin("SessionDescription");
        a.sessionId != null && (b.writeFieldBegin({
            fname: "sessionId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.sessionId), b.writeFieldEnd());
        a.sessionVersion != null && (b.writeFieldBegin({
            fname: "sessionVersion",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.sessionVersion), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "supportsMsid",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 3
        });
        if (a.supportsMsid != null) b.writeBool(a.supportsMsid);
        else {
            var d = !0;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        a.useIceLite != null && (b.writeFieldBegin({
            fname: "useIceLite",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 4
        }), b.writeBool(a.useIceLite), b.writeFieldEnd());
        if (a.features != null) {
            b.writeFieldBegin({
                fname: "features",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 5
            });
            b.writeListBegin({
                etype: h.STRING,
                size: a.features.length
            });
            for (var d = a.features, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.connectionRole != null) {
            b.writeFieldBegin({
                fname: "connectionRole",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 6
            });
            b.writeI32((g = a.connectionRole) != null ? g : 0);
            b.writeFieldEnd()
        }
        a.bandwidth != null && (b.writeFieldBegin({
            fname: "bandwidth",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 7
        }), s(a.bandwidth, b), b.writeFieldEnd());
        if (a.transportBundle != null) {
            b.writeFieldBegin({
                fname: "transportBundle",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 8
            });
            b.writeListBegin({
                etype: h.STRING,
                size: a.transportBundle.length
            });
            for (f = a.transportBundle, e = Array.isArray(f), d = 0, f = e ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (d >= f.length) break;
                    g = f[d++]
                } else {
                    d = f.next();
                    if (d.done) break;
                    g = d.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.commonCryptos != null) {
            b.writeFieldBegin({
                fname: "commonCryptos",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 9
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.commonCryptos.length
            });
            for (g = a.commonCryptos, d = Array.isArray(g), e = 0, g = d ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (d) {
                    if (e >= g.length) break;
                    f = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    f = e.value
                }
                a = f;
                v(a, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function z(a, b) {
        b.writeStructBegin("Sdp");
        a.sessionDescription != null && (b.writeFieldBegin({
            fname: "sessionDescription",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), y(a.sessionDescription, b), b.writeFieldEnd());
        if (a.mediaDescriptions != null) {
            b.writeFieldBegin({
                fname: "mediaDescriptions",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 2
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.mediaDescriptions.length
            });
            for (var a = a.mediaDescriptions, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                x(f, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function A(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.semantics = a.readString() : a.skip(e);
                    break;
                case 2:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.ssrcIds = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readI32();
                            b.ssrcIds.push(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function B(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.ssrcId = a.readI32() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.cname = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.msid = a.readString() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.msidAppData = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.msid === void 0 && (b.msid = "stream_label");
        return b
    }

    function C(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.id = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.param = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.id === void 0 && (b.id = "");
        return b
    }

    function D(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.bwtype = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.bw = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.bwtype === void 0 && (b.bwtype = "");
        b.bw === void 0 && (b.bw = 0);
        return b
    }

    function E(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).BYTE ? b.payloadType = a.readByte() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.encodingName = d("WebrtcEnumsTypes").CodecName.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).BYTE ? b.clockRateKhz = a.readByte() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).BYTE ? b.numAudioChannels = a.readByte() : a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.fmtParameters = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("WebrtcEnumsTypes").CodecOption.cast(a.readI32()),
                                j = a.readString();
                            i != null && (b.fmtParameters[i] = j)
                        }
                    } else a.skip(f);
                    break;
                case 6:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.enabledOptions = new Set();
                        i = a.readSetBegin();
                        for (j = 0; j < i.size; j++) {
                            g = d("WebrtcEnumsTypes").CodecOptionBoolean.cast(a.readI32());
                            b.enabledOptions.add(g)
                        }
                    } else a.skip(f);
                    break;
                case 7:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.rtcpFbParameters = {};
                        e = a.readMapBegin();
                        for (g = 0; g < e.size; g++) {
                            j = a.readString();
                            i = a.readString();
                            b.rtcpFbParameters[j] = i
                        }
                    } else a.skip(f);
                    break;
                case 10:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.rtcpFbParamList = [];
                        j = a.readListBegin();
                        for (i = 0; i < j.size; i++) {
                            g = C(a);
                            b.rtcpFbParamList.push(g)
                        }
                    } else a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.videoWidth = a.readI32() : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.videoHeight = a.readI32() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.numAudioChannels === void 0 && (b.numAudioChannels = 1);
        return b
    }

    function F(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.id = a.readI32() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.uri = d("WebrtcEnumsTypes").ExtmapUris.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.extensionAttributes = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("WebrtcEnumsTypes").ExtmapUris.cast(a.readI32());
                            b.extensionAttributes.push(i)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.id === void 0 && (b.id = 1);
        b.extensionAttributes === void 0 && (b.extensionAttributes = []);
        return b
    }

    function G(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.tag = a.readI32() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.suite = d("WebrtcEnumsTypes").CryptoSuite.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.keyParams = a.readString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function H(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.foundation = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).BYTE ? b.componentId = a.readByte() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.transport = d("WebrtcEnumsTypes").IceCandidateTransport.cast(a.readI32()) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.priority = a.readI32() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.address = a.readString() : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.port = a.readI32() : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.protocolType = d("WebrtcEnumsTypes").IceCandidateProtocolType.cast(a.readI32()) : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.relatedAddress = a.readString() : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.relatedPort = a.readI32() : a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.username = a.readString() : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.password = a.readString() : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.generation = a.readI32() : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.tcptype = d("WebrtcEnumsTypes").IceCandidateTcpType.cast(a.readI32()) : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).I16 ? b.networkId = a.readI16() : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).I16 ? b.networkCost = a.readI16() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.componentId === void 0 && (b.componentId = 1);
        b.transport === void 0 && (b.transport = d("WebrtcEnumsTypes").IceCandidateTransport.cast(0));
        b.generation === void 0 && (b.generation = 0);
        return b
    }

    function I(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.mediaType = d("WebrtcEnumsTypes").MediaType.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.port = a.readI32() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.protocol = d("WebrtcEnumsTypes").MediaProtocol.cast(a.readI32()) : a.skip(f);
                    break;
                case 22:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.fmt = a.readString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.mediaIceUserFrag = a.readString() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.mediaIcePassword = a.readString() : a.skip(f);
                    break;
                case 6:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.mediaIceOptions = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString();
                            b.mediaIceOptions.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.mediaSslFingerprintHash = a.readString() : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.mediaSslFingerprintDigest = a.readString() : a.skip(f);
                    break;
                case 9:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.extmaps = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = F(a);
                            b.extmaps.push(e)
                        }
                    } else a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.sendRecvMode = d("WebrtcEnumsTypes").SendRecvMode.cast(a.readI32()) : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.hasRtcpMux = a.readBool() : a.skip(f);
                    break;
                case 25:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.rtcpReducedSize = a.readBool() : a.skip(f);
                    break;
                case 12:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.cryptoParams = [];
                        e = a.readListBegin();
                        for (g = 0; g < e.size; g++) {
                            i = G(a);
                            b.cryptoParams.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 13:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.codecs = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = E(a);
                            b.codecs.push(e)
                        }
                    } else a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.maxPTime = a.readI32() : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.pTime = a.readI32() : a.skip(f);
                    break;
                case 16:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.ssrcObjects = [];
                        e = a.readListBegin();
                        for (g = 0; g < e.size; g++) {
                            i = B(a);
                            b.ssrcObjects.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 17:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.candidates = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = H(a);
                            b.candidates.push(e)
                        }
                    } else a.skip(f);
                    break;
                case 18:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.conferenceMode = a.readBool() : a.skip(f);
                    break;
                case 19:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.ssrcGroups = [];
                        e = a.readListBegin();
                        for (g = 0; g < e.size; g++) {
                            i = A(a);
                            b.ssrcGroups.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 20:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.connectionRole = d("WebrtcEnumsTypes").ConnectionRole.cast(a.readI32()) : a.skip(f);
                    break;
                case 21:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.mid = a.readString() : a.skip(f);
                    break;
                case 23:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.bandwidth = D(a) : a.skip(f);
                    break;
                case 24:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.sctpPort = a.readI32() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.port === void 0 && (b.port = 1);
        b.protocol === void 0 && (b.protocol = d("WebrtcEnumsTypes").MediaProtocol.cast(0));
        b.sendRecvMode === void 0 && (b.sendRecvMode = d("WebrtcEnumsTypes").SendRecvMode.cast(1));
        b.hasRtcpMux === void 0 && (b.hasRtcpMux = !0);
        return b
    }

    function J(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sessionId = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sessionVersion = a.readString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.supportsMsid = a.readBool() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.useIceLite = a.readBool() : a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.features = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString();
                            b.features.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.connectionRole = d("WebrtcEnumsTypes").ConnectionRole.cast(a.readI32()) : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.bandwidth = D(a) : a.skip(f);
                    break;
                case 8:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.transportBundle = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = a.readString();
                            b.transportBundle.push(e)
                        }
                    } else a.skip(f);
                    break;
                case 9:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.commonCryptos = [];
                        e = a.readListBegin();
                        for (g = 0; g < e.size; g++) {
                            i = G(a);
                            b.commonCryptos.push(i)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.supportsMsid === void 0 && (b.supportsMsid = !0);
        return b
    }

    function K(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.sessionDescription = J(a) : a.skip(e);
                    break;
                case 2:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.mediaDescriptions = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = I(a);
                            b.mediaDescriptions.push(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }
    g.SsrcGroup$DefaultConstructor = a;
    g.SsrcObject$DefaultConstructor = b;
    g.RtcpFbVal$DefaultConstructor = e;
    g.Bandwidth$DefaultConstructor = f;
    g.CodecDescription$DefaultConstructor = i;
    g.Extmap$DefaultConstructor = j;
    g.CryptoParam$DefaultConstructor = k;
    g.IceCandidateSdp$DefaultConstructor = l;
    g.MediaDescription$DefaultConstructor = m;
    g.SessionDescription$DefaultConstructor = n;
    g.Sdp$DefaultConstructor = o;
    g.serializeSsrcGroup = p;
    g.serializeSsrcObject = q;
    g.serializeRtcpFbVal = r;
    g.serializeBandwidth = s;
    g.serializeCodecDescription = t;
    g.serializeExtmap = u;
    g.serializeCryptoParam = v;
    g.serializeIceCandidateSdp = w;
    g.serializeMediaDescription = x;
    g.serializeSessionDescription = y;
    g.serializeSdp = z;
    g.deserializeSsrcGroup = A;
    g.deserializeSsrcObject = B;
    g.deserializeRtcpFbVal = C;
    g.deserializeBandwidth = D;
    g.deserializeCodecDescription = E;
    g.deserializeExtmap = F;
    g.deserializeCryptoParam = G;
    g.deserializeIceCandidateSdp = H;
    g.deserializeMediaDescription = I;
    g.deserializeSessionDescription = J;
    g.deserializeSdp = K
}), 98);
__d("WebrtcPayloadSerializers", ["ThriftTypes", "WebrtcEnumsTypes", "WebrtcSdpSerializers", "WebrtcSignalingCommonSerializers", "WebrtcSignalingCommonTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        return {}
    }

    function b() {
        return {
            customVideoContentType: d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0)
        }
    }

    function e() {
        return {}
    }

    function f() {
        return {
            videoOn: !1,
            audioOn: !0,
            speakerOn: !0
        }
    }

    function i() {
        return {
            smcTier: "",
            region: ""
        }
    }

    function j() {
        return {
            uploadLogLevel: d("WebrtcEnumsTypes").UploadLogLevel.cast(0),
            offeredFbExperiments: "",
            callType: "",
            isLegacyCall: !1
        }
    }

    function aa() {
        return {
            ackMessageId: "0",
            uploadLogLevel: d("WebrtcEnumsTypes").UploadLogLevel.cast(0),
            selectedFbExperiments: ""
        }
    }

    function ba() {
        return {
            errorCode: 0
        }
    }

    function ca() {
        return {
            selectedFbExperiments: "",
            callType: ""
        }
    }

    function da() {
        return {
            ackMessageId: "0"
        }
    }

    function ea() {
        return {
            sdpMediaLineIndex: -1,
            sdpMediaId: ""
        }
    }

    function fa() {
        return {}
    }

    function ga() {
        return {}
    }

    function ha() {
        return {}
    }

    function ia() {
        return {}
    }

    function ja() {
        return {
            ackMessageId: "0"
        }
    }

    function ka() {
        return {}
    }

    function la() {
        return {}
    }

    function ma() {
        return {
            conferenceName: "",
            usersInvited: new Set()
        }
    }

    function na() {
        return {
            sdpNegotiateType: d("WebrtcEnumsTypes").SdpNegotiateType.cast(0)
        }
    }

    function oa() {
        return {
            callType: ""
        }
    }

    function pa() {
        return {}
    }

    function qa() {
        return {
            eventType: d("WebrtcEnumsTypes").ClientReportedEventType.cast(0)
        }
    }

    function ra() {
        return {
            deviceId: "",
            appId: "0"
        }
    }

    function sa() {
        return {
            retryCount: 0,
            pranswerSupported: !0
        }
    }

    function ta() {
        return {}
    }

    function k(a, b) {
        b.writeStructBegin("StreamInfo");
        if (a.type != null) {
            b.writeFieldBegin({
                fname: "type",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 1
            });
            b.writeI32((a = a.type) != null ? a : 0);
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function l(a, b) {
        b.writeStructBegin("TrackInfo");
        if (a.label != null) {
            var e;
            b.writeFieldBegin({
                fname: "label",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 1
            });
            b.writeI32((e = a.label) != null ? e : 0);
            b.writeFieldEnd()
        }
        a.enabled != null && (b.writeFieldBegin({
            fname: "enabled",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 2
        }), b.writeBool(a.enabled), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "customVideoContentType",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 3
        });
        if (a.customVideoContentType != null) {
            b.writeI32((e = a.customVideoContentType) != null ? e : 0)
        } else {
            e = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.name != null && (b.writeFieldBegin({
            fname: "name",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.name), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function m(a, b) {
        b.writeStructBegin("VideoRequestPayload"), a.islocalVideoOn != null && (b.writeFieldBegin({
            fname: "islocalVideoOn",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 1
        }), b.writeBool(a.islocalVideoOn), b.writeFieldEnd()), a.requestRemoteVideoOn != null && (b.writeFieldBegin({
            fname: "requestRemoteVideoOn",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 2
        }), b.writeBool(a.requestRemoteVideoOn), b.writeFieldEnd()), a.ackMessageId != null && (b.writeFieldBegin({
            fname: "ackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 6
        }), b.writeI64(BigInt(a.ackMessageId)), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function n(a, b) {
        b.writeStructBegin("NotifyMediaStatePayload");
        b.writeFieldBegin({
            fname: "videoOn",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 1
        });
        if (a.videoOn != null) b.writeBool(a.videoOn);
        else {
            var d = !1;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "audioOn",
            ftype: h.BOOL,
            fid: 6
        });
        if (a.audioOn != null) b.writeBool(a.audioOn);
        else {
            d = !0;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "speakerOn",
            ftype: h.BOOL,
            fid: 7
        });
        if (a.speakerOn != null) b.writeBool(a.speakerOn);
        else {
            d = !0;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        a.version != null && (b.writeFieldBegin({
            fname: "version",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 8
        }), b.writeI64(BigInt(a.version)), b.writeFieldEnd());
        if (a.trackInfos != null) {
            b.writeFieldBegin({
                fname: "trackInfos",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 9
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.trackInfos).length
            });
            d = Object.entries(a.trackInfos);
            for (a = 0; a < d.length; a++) {
                var e = d[a],
                    f = e[0];
                e = e[1];
                b.writeString(f);
                l(e, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function o(a, b) {
        b.writeStructBegin("P2PSfuAllocation");
        b.writeFieldBegin({
            fname: "smcTier",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.smcTier != null) b.writeString(a.smcTier);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "region",
            ftype: h.STRING,
            fid: 2
        });
        if (a.region != null) b.writeString(a.region);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function p(a, b) {
        b.writeStructBegin("OfferPayload");
        a.sdpThrift != null && (b.writeFieldBegin({
            fname: "sdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), d("WebrtcSdpSerializers").serializeSdp(a.sdpThrift, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "uploadLogLevel",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        });
        if (a.uploadLogLevel != null) {
            var e;
            b.writeI32((e = a.uploadLogLevel) != null ? e : 0)
        } else {
            e = d("WebrtcEnumsTypes").UploadLogLevel.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "offeredFbExperiments",
            ftype: h.STRING,
            fid: 5
        });
        if (a.offeredFbExperiments != null) b.writeString(a.offeredFbExperiments);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.videoRequestPayload != null && (b.writeFieldBegin({
            fname: "videoRequestPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 8
        }), m(a.videoRequestPayload, b), b.writeFieldEnd());
        a.initialMediaState != null && (b.writeFieldBegin({
            fname: "initialMediaState",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 10
        }), n(a.initialMediaState, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "callType",
            ftype: h.STRING,
            fid: 11
        });
        if (a.callType != null) b.writeString(a.callType);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.offerEscalationSupport != null && (b.writeFieldBegin({
            fname: "offerEscalationSupport",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 14
        }), b.writeBool(a.offerEscalationSupport), b.writeFieldEnd());
        a.escalationConferenceName != null && (b.writeFieldBegin({
            fname: "escalationConferenceName",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 15
        }), b.writeString(a.escalationConferenceName), b.writeFieldEnd());
        a.sdpString != null && (b.writeFieldBegin({
            fname: "sdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 16
        }), b.writeString(a.sdpString), b.writeFieldEnd());
        a.userCapabilities != null && (b.writeFieldBegin({
            fname: "userCapabilities",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 17
        }), b.writeBinary(a.userCapabilities), b.writeFieldEnd());
        a.callTrigger != null && (b.writeFieldBegin({
            fname: "callTrigger",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 18
        }), b.writeString(a.callTrigger), b.writeFieldEnd());
        a.sdpNegotiationSupport != null && (b.writeFieldBegin({
            fname: "sdpNegotiationSupport",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 19
        }), b.writeBool(a.sdpNegotiationSupport), b.writeFieldEnd());
        if (a.extraParams != null) {
            b.writeFieldBegin({
                fname: "extraParams",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 20
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.extraParams.length
            });
            for (var e = a.extraParams, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                d("WebrtcSignalingCommonSerializers").serializeGenericDataMessage(i, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.streamInfos_DEPRECATED != null) {
            b.writeFieldBegin({
                fname: "streamInfos_DEPRECATED",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 21
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.streamInfos_DEPRECATED).length
            });
            i = Object.entries(a.streamInfos_DEPRECATED);
            for (g = 0; g < i.length; g++) {
                f = i[g];
                e = f[0];
                f = f[1];
                b.writeString(e);
                k(f, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.collisionContext != null && (b.writeFieldBegin({
            fname: "collisionContext",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 22
        }), b.writeBinary(a.collisionContext), b.writeFieldEnd());
        if (a.trackInfos != null) {
            b.writeFieldBegin({
                fname: "trackInfos",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 23
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.trackInfos).length
            });
            e = Object.entries(a.trackInfos);
            for (f = 0; f < e.length; f++) {
                i = e[f];
                g = i[0];
                i = i[1];
                b.writeString(g);
                l(i, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "isLegacyCall",
            ftype: h.BOOL,
            fid: 24
        });
        if (a.isLegacyCall != null) b.writeBool(a.isLegacyCall);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        a.sfuAllocation != null && (b.writeFieldBegin({
            fname: "sfuAllocation",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 25
        }), o(a.sfuAllocation, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function q(a, b) {
        b.writeStructBegin("OfferAckPayload");
        b.writeFieldBegin({
            fname: "ackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.ackMessageId != null) b.writeI64(BigInt(a.ackMessageId));
        else {
            var e = "0";
            b.writeI64(BigInt(e))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "uploadLogLevel",
            ftype: h.I32,
            fid: 2
        });
        if (a.uploadLogLevel != null) {
            b.writeI32((e = a.uploadLogLevel) != null ? e : 0)
        } else {
            e = d("WebrtcEnumsTypes").UploadLogLevel.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "selectedFbExperiments",
            ftype: h.STRING,
            fid: 3
        });
        if (a.selectedFbExperiments != null) b.writeString(a.selectedFbExperiments);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function r(a, b) {
        b.writeStructBegin("OfferNackPayload");
        a.nackMessageId != null && (b.writeFieldBegin({
            fname: "nackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        }), b.writeI64(BigInt(a.nackMessageId)), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "errorCode",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        });
        if (a.errorCode != null) b.writeI32(a.errorCode);
        else {
            a = 0;
            b.writeI32(a)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function s(a, b) {
        b.writeStructBegin("AnswerPayload");
        a.sdpThrift != null && (b.writeFieldBegin({
            fname: "sdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), d("WebrtcSdpSerializers").serializeSdp(a.sdpThrift, b), b.writeFieldEnd());
        a.videoRequestPayload != null && (b.writeFieldBegin({
            fname: "videoRequestPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 4
        }), m(a.videoRequestPayload, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "selectedFbExperiments",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 6
        });
        if (a.selectedFbExperiments != null) b.writeString(a.selectedFbExperiments);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.initialMediaState != null && (b.writeFieldBegin({
            fname: "initialMediaState",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 7
        }), n(a.initialMediaState, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "callType",
            ftype: h.STRING,
            fid: 8
        });
        if (a.callType != null) b.writeString(a.callType);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.negotiatedEscalationSupport != null && (b.writeFieldBegin({
            fname: "negotiatedEscalationSupport",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 11
        }), b.writeBool(a.negotiatedEscalationSupport), b.writeFieldEnd());
        a.escalationConferenceName != null && (b.writeFieldBegin({
            fname: "escalationConferenceName",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 12
        }), b.writeString(a.escalationConferenceName), b.writeFieldEnd());
        a.sdpString != null && (b.writeFieldBegin({
            fname: "sdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 13
        }), b.writeString(a.sdpString), b.writeFieldEnd());
        a.userCapabilities != null && (b.writeFieldBegin({
            fname: "userCapabilities",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 14
        }), b.writeBinary(a.userCapabilities), b.writeFieldEnd());
        a.sdpNegotiationSupport != null && (b.writeFieldBegin({
            fname: "sdpNegotiationSupport",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 15
        }), b.writeBool(a.sdpNegotiationSupport), b.writeFieldEnd());
        if (a.streamInfos_DEPRECATED != null) {
            b.writeFieldBegin({
                fname: "streamInfos_DEPRECATED",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 16
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.streamInfos_DEPRECATED).length
            });
            e = Object.entries(a.streamInfos_DEPRECATED);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                k(g, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.collisionContext != null && (b.writeFieldBegin({
            fname: "collisionContext",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 18
        }), b.writeBinary(a.collisionContext), b.writeFieldEnd());
        if (a.trackInfos != null) {
            b.writeFieldBegin({
                fname: "trackInfos",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 19
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.trackInfos).length
            });
            i = Object.entries(a.trackInfos);
            for (g = 0; g < i.length; g++) {
                e = i[g];
                f = e[0];
                a = e[1];
                b.writeString(f);
                l(a, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function t(a, b) {
        b.writeStructBegin("AnswerAckPayload");
        b.writeFieldBegin({
            fname: "ackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.ackMessageId != null) b.writeI64(BigInt(a.ackMessageId));
        else {
            a = "0";
            b.writeI64(BigInt(a))
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function u(a, b) {
        b.writeStructBegin("IceCandidatePayload");
        a.sdpThrift != null && (b.writeFieldBegin({
            fname: "sdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), d("WebrtcSdpSerializers").serializeIceCandidateSdp(a.sdpThrift, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "sdpMediaLineIndex",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        });
        if (a.sdpMediaLineIndex != null) b.writeI32(a.sdpMediaLineIndex);
        else {
            var e = -1;
            b.writeI32(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "sdpMediaId",
            ftype: h.STRING,
            fid: 3
        });
        if (a.sdpMediaId != null) b.writeString(a.sdpMediaId);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.sdpString != null && (b.writeFieldBegin({
            fname: "sdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.sdpString), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function v(a, b) {
        b.writeStructBegin("OkPayload"), b.writeFieldStop(), b.writeStructEnd()
    }

    function w(a, b) {
        b.writeStructBegin("HangUpPayload");
        if (a.reason != null) {
            b.writeFieldBegin({
                fname: "reason",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 1
            });
            b.writeI32((a = a.reason) != null ? a : 0);
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function x(a, b) {
        b.writeStructBegin("OtherDismissPayload"), b.writeFieldStop(), b.writeStructEnd()
    }

    function y(a, b) {
        b.writeStructBegin("PranswerPayload");
        a.sdpThrift != null && (b.writeFieldBegin({
            fname: "sdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), d("WebrtcSdpSerializers").serializeSdp(a.sdpThrift, b), b.writeFieldEnd());
        a.sdpString != null && (b.writeFieldBegin({
            fname: "sdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        }), b.writeString(a.sdpString), b.writeFieldEnd());
        a.negotiatedEscalationSupport != null && (b.writeFieldBegin({
            fname: "negotiatedEscalationSupport",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 4
        }), b.writeBool(a.negotiatedEscalationSupport), b.writeFieldEnd());
        a.escalationConferenceName != null && (b.writeFieldBegin({
            fname: "escalationConferenceName",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 5
        }), b.writeString(a.escalationConferenceName), b.writeFieldEnd());
        if (a.streamInfos_DEPRECATED != null) {
            b.writeFieldBegin({
                fname: "streamInfos_DEPRECATED",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 6
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.streamInfos_DEPRECATED).length
            });
            var e = Object.entries(a.streamInfos_DEPRECATED);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                k(g, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.collisionContext != null && (b.writeFieldBegin({
            fname: "collisionContext",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 7
        }), b.writeBinary(a.collisionContext), b.writeFieldEnd());
        if (a.trackInfos != null) {
            b.writeFieldBegin({
                fname: "trackInfos",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 8
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.trackInfos).length
            });
            i = Object.entries(a.trackInfos);
            for (g = 0; g < i.length; g++) {
                e = i[g];
                f = e[0];
                a = e[1];
                b.writeString(f);
                l(a, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function z(a, b) {
        b.writeStructBegin("AckPayload");
        b.writeFieldBegin({
            fname: "ackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.ackMessageId != null) b.writeI64(BigInt(a.ackMessageId));
        else {
            a = "0";
            b.writeI64(BigInt(a))
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function A(a, b) {
        b.writeStructBegin("NackPayload"), a.nackMessageId != null && (b.writeFieldBegin({
            fname: "nackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        }), b.writeI64(BigInt(a.nackMessageId)), b.writeFieldEnd()), a.errorCode != null && (b.writeFieldBegin({
            fname: "errorCode",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        }), b.writeI32(a.errorCode), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function B(a, b) {
        b.writeStructBegin("SdpUpdatePayload");
        a.sdpThrift != null && (b.writeFieldBegin({
            fname: "sdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), d("WebrtcSdpSerializers").serializeSdp(a.sdpThrift, b), b.writeFieldEnd());
        a.ackMessageId != null && (b.writeFieldBegin({
            fname: "ackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 2
        }), b.writeI64(BigInt(a.ackMessageId)), b.writeFieldEnd());
        a.sdpString != null && (b.writeFieldBegin({
            fname: "sdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        }), b.writeString(a.sdpString), b.writeFieldEnd());
        if (a.streamInfos_DEPRECATED != null) {
            b.writeFieldBegin({
                fname: "streamInfos_DEPRECATED",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 4
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.streamInfos_DEPRECATED).length
            });
            var e = Object.entries(a.streamInfos_DEPRECATED);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                k(g, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.trackInfos != null) {
            b.writeFieldBegin({
                fname: "trackInfos",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 5
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.trackInfos).length
            });
            i = Object.entries(a.trackInfos);
            for (g = 0; g < i.length; g++) {
                e = i[g];
                f = e[0];
                a = e[1];
                b.writeString(f);
                l(a, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function C(a, b) {
        b.writeStructBegin("SwitchToMultiwayPayload");
        b.writeFieldBegin({
            fname: "conferenceName",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.conferenceName != null) b.writeString(a.conferenceName);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        a.serverInfoData != null && (b.writeFieldBegin({
            fname: "serverInfoData",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.serverInfoData), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "usersInvited",
            ftype: h.SET,
            fid: 3
        });
        if (a.usersInvited != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: a.usersInvited.size
            });
            for (var d = a.usersInvited, a = Array.isArray(d), e = 0, d = a ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (a) {
                    if (e >= d.length) break;
                    f = d[e++]
                } else {
                    e = d.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                b.writeString(f)
            }
            b.writeSetEnd()
        } else {
            f = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: f.size
            });
            for (e = f, a = Array.isArray(e), d = 0, e = a ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (a) {
                    if (d >= e.length) break;
                    f = e[d++]
                } else {
                    d = e.next();
                    if (d.done) break;
                    f = d.value
                }
                f = f;
                b.writeString(f)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function D(a, b) {
        b.writeStructBegin("SdpNegotiatePayload");
        b.writeFieldBegin({
            fname: "sdpNegotiateType",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.sdpNegotiateType != null) {
            var e;
            b.writeI32((e = a.sdpNegotiateType) != null ? e : 0)
        } else {
            e = d("WebrtcEnumsTypes").SdpNegotiateType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.sdpString != null && (b.writeFieldBegin({
            fname: "sdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.sdpString), b.writeFieldEnd());
        a.sdpThrift != null && (b.writeFieldBegin({
            fname: "sdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 3
        }), d("WebrtcSdpSerializers").serializeSdp(a.sdpThrift, b), b.writeFieldEnd());
        a.ackMessageId != null && (b.writeFieldBegin({
            fname: "ackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 4
        }), b.writeI64(BigInt(a.ackMessageId)), b.writeFieldEnd());
        if (a.streamInfos_DEPRECATED != null) {
            b.writeFieldBegin({
                fname: "streamInfos_DEPRECATED",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 5
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.streamInfos_DEPRECATED).length
            });
            e = Object.entries(a.streamInfos_DEPRECATED);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                k(g, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.trackInfos != null) {
            b.writeFieldBegin({
                fname: "trackInfos",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 6
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.trackInfos).length
            });
            i = Object.entries(a.trackInfos);
            for (g = 0; g < i.length; g++) {
                e = i[g];
                f = e[0];
                a = e[1];
                b.writeString(f);
                l(a, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function E(a, b) {
        b.writeStructBegin("RingPayload");
        a.videoRequestPayload != null && (b.writeFieldBegin({
            fname: "videoRequestPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), m(a.videoRequestPayload, b), b.writeFieldEnd());
        a.initialMediaState != null && (b.writeFieldBegin({
            fname: "initialMediaState",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), n(a.initialMediaState, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "callType",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        });
        if (a.callType != null) b.writeString(a.callType);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        if (a.extraParams != null) {
            b.writeFieldBegin({
                fname: "extraParams",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 4
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.extraParams.length
            });
            for (var e = a.extraParams, a = Array.isArray(e), f = 0, e = a ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (a) {
                    if (f >= e.length) break;
                    g = e[f++]
                } else {
                    f = e.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                d("WebrtcSignalingCommonSerializers").serializeGenericDataMessage(g, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function F(a, b) {
        b.writeStructBegin("PrOfferAckPayload"), a.ackMessageId != null && (b.writeFieldBegin({
            fname: "ackMessageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        }), b.writeI64(BigInt(a.ackMessageId)), b.writeFieldEnd()), a.applyAfterSeconds != null && (b.writeFieldBegin({
            fname: "applyAfterSeconds",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 2
        }), b.writeI64(BigInt(a.applyAfterSeconds)), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function G(a, b) {
        b.writeStructBegin("ClientReportedEventPayload");
        b.writeFieldBegin({
            fname: "eventType",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.eventType != null) {
            b.writeI32((a = a.eventType) != null ? a : 0)
        } else {
            a = d("WebrtcEnumsTypes").ClientReportedEventType.cast(0);
            b.writeI32((a = a) != null ? a : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function H(a, b) {
        b.writeStructBegin("WebrtcMessageEndpoint");
        b.writeFieldBegin({
            fname: "deviceId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.deviceId != null) b.writeString(a.deviceId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "appId",
            ftype: h.I64,
            fid: 2
        });
        if (a.appId != null) b.writeI64(BigInt(a.appId));
        else {
            d = "0";
            b.writeI64(BigInt(d))
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ua(a, b) {
        b.writeStructBegin("WebrtcMessageHeader");
        a.protocolVersion != null && (b.writeFieldBegin({
            fname: "protocolVersion",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        }), b.writeI32(a.protocolVersion), b.writeFieldEnd());
        a.messageId != null && (b.writeFieldBegin({
            fname: "messageId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 2
        }), b.writeI64(BigInt(a.messageId)), b.writeFieldEnd());
        a.callId != null && (b.writeFieldBegin({
            fname: "callId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 3
        }), b.writeI64(BigInt(a.callId)), b.writeFieldEnd());
        a.sender != null && (b.writeFieldBegin({
            fname: "sender",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 4
        }), b.writeI64(BigInt(a.sender)), b.writeFieldEnd());
        a.receiver != null && (b.writeFieldBegin({
            fname: "receiver",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 5
        }), b.writeI64(BigInt(a.receiver)), b.writeFieldEnd());
        a.capabilities != null && (b.writeFieldBegin({
            fname: "capabilities",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 6
        }), b.writeI64(BigInt(a.capabilities)), b.writeFieldEnd());
        if (a.payloadType != null) {
            var d;
            b.writeFieldBegin({
                fname: "payloadType",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 7
            });
            b.writeI32((d = a.payloadType) != null ? d : 0);
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "retryCount",
            ftype: (h || (h = c("ThriftTypes"))).BYTE,
            fid: 8
        });
        if (a.retryCount != null) b.writeByte(a.retryCount);
        else {
            d = 0;
            b.writeByte(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "pranswerSupported",
            ftype: h.BOOL,
            fid: 9
        });
        if (a.pranswerSupported != null) b.writeBool(a.pranswerSupported);
        else {
            d = !0;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        if (a.ackMessageType != null) {
            b.writeFieldBegin({
                fname: "ackMessageType",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 10
            });
            b.writeI32((d = a.ackMessageType) != null ? d : 0);
            b.writeFieldEnd()
        }
        a.source != null && (b.writeFieldBegin({
            fname: "source",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 11
        }), H(a.source, b), b.writeFieldEnd());
        a.destination != null && (b.writeFieldBegin({
            fname: "destination",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 12
        }), H(a.destination, b), b.writeFieldEnd());
        a.rtcHandle != null && (b.writeFieldBegin({
            fname: "rtcHandle",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 13
        }), b.writeString(a.rtcHandle), b.writeFieldEnd());
        if (a.clientStack != null) {
            b.writeFieldBegin({
                fname: "clientStack",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 14
            });
            b.writeI32((d = a.clientStack) != null ? d : 0);
            b.writeFieldEnd()
        }
        a.serverMsgTime != null && (b.writeFieldBegin({
            fname: "serverMsgTime",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 15
        }), b.writeI64(BigInt(a.serverMsgTime)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function va(a, b) {
        b.writeStructBegin("WebrtcMessagePayload");
        a.offerPayload != null && (b.writeFieldBegin({
            fname: "offerPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), p(a.offerPayload, b), b.writeFieldEnd());
        a.offerAckPayload != null && (b.writeFieldBegin({
            fname: "offerAckPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), q(a.offerAckPayload, b), b.writeFieldEnd());
        a.answerPayload != null && (b.writeFieldBegin({
            fname: "answerPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 3
        }), s(a.answerPayload, b), b.writeFieldEnd());
        a.answerAckPayload != null && (b.writeFieldBegin({
            fname: "answerAckPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 4
        }), t(a.answerAckPayload, b), b.writeFieldEnd());
        if (a.iceCandidatePayloads != null) {
            b.writeFieldBegin({
                fname: "iceCandidatePayloads",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 5
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.iceCandidatePayloads.length
            });
            for (var d = a.iceCandidatePayloads, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                u(g, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.okPayload != null && (b.writeFieldBegin({
            fname: "okPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 6
        }), v(a.okPayload, b), b.writeFieldEnd());
        a.hangUpPayload != null && (b.writeFieldBegin({
            fname: "hangUpPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 7
        }), w(a.hangUpPayload, b), b.writeFieldEnd());
        a.otherDismissPayload != null && (b.writeFieldBegin({
            fname: "otherDismissPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 8
        }), x(a.otherDismissPayload, b), b.writeFieldEnd());
        a.pranswerPayload != null && (b.writeFieldBegin({
            fname: "pranswerPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 9
        }), y(a.pranswerPayload, b), b.writeFieldEnd());
        a.notifyMediaStatePayload != null && (b.writeFieldBegin({
            fname: "notifyMediaStatePayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 13
        }), n(a.notifyMediaStatePayload, b), b.writeFieldEnd());
        a.ackPayload != null && (b.writeFieldBegin({
            fname: "ackPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 14
        }), z(a.ackPayload, b), b.writeFieldEnd());
        a.offerNackPayload != null && (b.writeFieldBegin({
            fname: "offerNackPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 15
        }), r(a.offerNackPayload, b), b.writeFieldEnd());
        a.nackPayload != null && (b.writeFieldBegin({
            fname: "nackPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 16
        }), A(a.nackPayload, b), b.writeFieldEnd());
        a.videoRequestPayload != null && (b.writeFieldBegin({
            fname: "videoRequestPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 17
        }), m(a.videoRequestPayload, b), b.writeFieldEnd());
        a.sdpUpdatePayload != null && (b.writeFieldBegin({
            fname: "sdpUpdatePayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 18
        }), B(a.sdpUpdatePayload, b), b.writeFieldEnd());
        a.switchToMultiwayPayload != null && (b.writeFieldBegin({
            fname: "switchToMultiwayPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 24
        }), C(a.switchToMultiwayPayload, b), b.writeFieldEnd());
        a.sdpNegotiatePayload != null && (b.writeFieldBegin({
            fname: "sdpNegotiatePayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 26
        }), D(a.sdpNegotiatePayload, b), b.writeFieldEnd());
        a.ringPayload != null && (b.writeFieldBegin({
            fname: "ringPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 27
        }), E(a.ringPayload, b), b.writeFieldEnd());
        a.prOfferAckPayload != null && (b.writeFieldBegin({
            fname: "prOfferAckPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 28
        }), F(a.prOfferAckPayload, b), b.writeFieldEnd());
        a.clientReportedEventPayload != null && (b.writeFieldBegin({
            fname: "clientReportedEventPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 29
        }), G(a.clientReportedEventPayload, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function I(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.type = d("WebrtcEnumsTypes").StreamType.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function J(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.label = d("WebrtcSignalingCommonTypes").TrackLabel.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.enabled = a.readBool() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.customVideoContentType = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(a.readI32()) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.name = a.readString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.customVideoContentType === void 0 && (b.customVideoContentType = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(0));
        return b
    }

    function K(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.islocalVideoOn = a.readBool() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.requestRemoteVideoOn = a.readBool() : a.skip(e);
                    break;
                case 6:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.ackMessageId = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function L(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.videoOn = a.readBool() : a.skip(e);
                    break;
                case 6:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.audioOn = a.readBool() : a.skip(e);
                    break;
                case 7:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.speakerOn = a.readBool() : a.skip(e);
                    break;
                case 8:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.version = a.readI64().toString() : a.skip(e);
                    break;
                case 9:
                    if (e === (h || (h = c("ThriftTypes"))).MAP) {
                        b.trackInfos = {};
                        d = a.readMapBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString(),
                                i = J(a);
                            b.trackInfos[g] = i
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.videoOn === void 0 && (b.videoOn = !1);
        b.audioOn === void 0 && (b.audioOn = !0);
        b.speakerOn === void 0 && (b.speakerOn = !0);
        return b
    }

    function M(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.smcTier = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.region = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.smcTier === void 0 && (b.smcTier = "");
        b.region === void 0 && (b.region = "");
        return b
    }

    function N(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpThrift = d("WebrtcSdpSerializers").deserializeSdp(a) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.uploadLogLevel = d("WebrtcEnumsTypes").UploadLogLevel.cast(a.readI32()) : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.offeredFbExperiments = a.readString() : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.videoRequestPayload = K(a) : a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.initialMediaState = L(a) : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.callType = a.readString() : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.offerEscalationSupport = a.readBool() : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.escalationConferenceName = a.readString() : a.skip(f);
                    break;
                case 16:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpString = a.readString() : a.skip(f);
                    break;
                case 17:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.userCapabilities = a.readBinary() : a.skip(f);
                    break;
                case 18:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.callTrigger = a.readString() : a.skip(f);
                    break;
                case 19:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.sdpNegotiationSupport = a.readBool() : a.skip(f);
                    break;
                case 20:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.extraParams = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("WebrtcSignalingCommonSerializers").deserializeGenericDataMessage(a);
                            b.extraParams.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 21:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.streamInfos_DEPRECATED = {};
                        i = a.readMapBegin();
                        for (g = 0; g < i.size; g++) {
                            e = a.readString();
                            var j = I(a);
                            b.streamInfos_DEPRECATED[e] = j
                        }
                    } else a.skip(f);
                    break;
                case 22:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.collisionContext = a.readBinary() : a.skip(f);
                    break;
                case 23:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.trackInfos = {};
                        e = a.readMapBegin();
                        for (j = 0; j < e.size; j++) {
                            g = a.readString();
                            i = J(a);
                            b.trackInfos[g] = i
                        }
                    } else a.skip(f);
                    break;
                case 24:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.isLegacyCall = a.readBool() : a.skip(f);
                    break;
                case 25:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sfuAllocation = M(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.uploadLogLevel === void 0 && (b.uploadLogLevel = d("WebrtcEnumsTypes").UploadLogLevel.cast(0));
        b.offeredFbExperiments === void 0 && (b.offeredFbExperiments = "");
        b.callType === void 0 && (b.callType = "");
        b.isLegacyCall === void 0 && (b.isLegacyCall = !1);
        return b
    }

    function O(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.ackMessageId = a.readI64().toString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.uploadLogLevel = d("WebrtcEnumsTypes").UploadLogLevel.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.selectedFbExperiments = a.readString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.ackMessageId === void 0 && (b.ackMessageId = "0");
        b.uploadLogLevel === void 0 && (b.uploadLogLevel = d("WebrtcEnumsTypes").UploadLogLevel.cast(0));
        b.selectedFbExperiments === void 0 && (b.selectedFbExperiments = "");
        return b
    }

    function P(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.nackMessageId = a.readI64().toString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.errorCode = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.errorCode === void 0 && (b.errorCode = 0);
        return b
    }

    function Q(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpThrift = d("WebrtcSdpSerializers").deserializeSdp(a) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.videoRequestPayload = K(a) : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.selectedFbExperiments = a.readString() : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.initialMediaState = L(a) : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.callType = a.readString() : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.negotiatedEscalationSupport = a.readBool() : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.escalationConferenceName = a.readString() : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpString = a.readString() : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.userCapabilities = a.readBinary() : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.sdpNegotiationSupport = a.readBool() : a.skip(f);
                    break;
                case 16:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.streamInfos_DEPRECATED = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = I(a);
                            b.streamInfos_DEPRECATED[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 18:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.collisionContext = a.readBinary() : a.skip(f);
                    break;
                case 19:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.trackInfos = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = a.readString();
                            e = J(a);
                            b.trackInfos[g] = e
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.selectedFbExperiments === void 0 && (b.selectedFbExperiments = "");
        b.callType === void 0 && (b.callType = "");
        return b
    }

    function R(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.ackMessageId = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.ackMessageId === void 0 && (b.ackMessageId = "0");
        return b
    }

    function S(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpThrift = d("WebrtcSdpSerializers").deserializeIceCandidateSdp(a) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.sdpMediaLineIndex = a.readI32() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpMediaId = a.readString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpString = a.readString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.sdpMediaLineIndex === void 0 && (b.sdpMediaLineIndex = -1);
        b.sdpMediaId === void 0 && (b.sdpMediaId = "");
        return b
    }

    function T(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                default: a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function U(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.reason = d("WebrtcEnumsTypes").CallEndReason.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function V(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                default: a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function W(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpThrift = d("WebrtcSdpSerializers").deserializeSdp(a) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpString = a.readString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.negotiatedEscalationSupport = a.readBool() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.escalationConferenceName = a.readString() : a.skip(f);
                    break;
                case 6:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.streamInfos_DEPRECATED = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = I(a);
                            b.streamInfos_DEPRECATED[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.collisionContext = a.readBinary() : a.skip(f);
                    break;
                case 8:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.trackInfos = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = a.readString();
                            e = J(a);
                            b.trackInfos[g] = e
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function X(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.ackMessageId = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.ackMessageId === void 0 && (b.ackMessageId = "0");
        return b
    }

    function Y(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.nackMessageId = a.readI64().toString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.errorCode = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Z(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpThrift = d("WebrtcSdpSerializers").deserializeSdp(a) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.ackMessageId = a.readI64().toString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpString = a.readString() : a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.streamInfos_DEPRECATED = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = I(a);
                            b.streamInfos_DEPRECATED[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.trackInfos = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = a.readString();
                            e = J(a);
                            b.trackInfos[g] = e
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function wa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.conferenceName = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.serverInfoData = a.readString() : a.skip(e);
                    break;
                case 3:
                    if (e === (h || (h = c("ThriftTypes"))).SET) {
                        b.usersInvited = new Set();
                        d = a.readSetBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString();
                            b.usersInvited.add(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.conferenceName === void 0 && (b.conferenceName = "");
        b.usersInvited === void 0 && (b.usersInvited = new Set());
        return b
    }

    function xa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.sdpNegotiateType = d("WebrtcEnumsTypes").SdpNegotiateType.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpString = a.readString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpThrift = d("WebrtcSdpSerializers").deserializeSdp(a) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.ackMessageId = a.readI64().toString() : a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.streamInfos_DEPRECATED = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = I(a);
                            b.streamInfos_DEPRECATED[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 6:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.trackInfos = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = a.readString();
                            e = J(a);
                            b.trackInfos[g] = e
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.sdpNegotiateType === void 0 && (b.sdpNegotiateType = d("WebrtcEnumsTypes").SdpNegotiateType.cast(0));
        return b
    }

    function ya(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.videoRequestPayload = K(a) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.initialMediaState = L(a) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.callType = a.readString() : a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.extraParams = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("WebrtcSignalingCommonSerializers").deserializeGenericDataMessage(a);
                            b.extraParams.push(i)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.callType === void 0 && (b.callType = "");
        return b
    }

    function za(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.ackMessageId = a.readI64().toString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.applyAfterSeconds = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Aa(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.eventType = d("WebrtcEnumsTypes").ClientReportedEventType.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.eventType === void 0 && (b.eventType = d("WebrtcEnumsTypes").ClientReportedEventType.cast(0));
        return b
    }

    function $(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.deviceId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.appId = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.deviceId === void 0 && (b.deviceId = "");
        b.appId === void 0 && (b.appId = "0");
        return b
    }

    function Ba(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.protocolVersion = a.readI32() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.messageId = a.readI64().toString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.callId = a.readI64().toString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.sender = a.readI64().toString() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.receiver = a.readI64().toString() : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.capabilities = a.readI64().toString() : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.payloadType = d("WebrtcEnumsTypes").PayloadType.cast(a.readI32()) : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).BYTE ? b.retryCount = a.readByte() : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.pranswerSupported = a.readBool() : a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.ackMessageType = d("WebrtcEnumsTypes").PayloadType.cast(a.readI32()) : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.source = $(a) : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.destination = $(a) : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.rtcHandle = a.readString() : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.clientStack = d("WebrtcSignalingCommonTypes").ClientStack.cast(a.readI32()) : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.serverMsgTime = a.readI64().toString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.retryCount === void 0 && (b.retryCount = 0);
        b.pranswerSupported === void 0 && (b.pranswerSupported = !0);
        return b
    }

    function Ca(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.offerPayload = N(a) : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.offerAckPayload = O(a) : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.answerPayload = Q(a) : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.answerAckPayload = R(a) : a.skip(e);
                    break;
                case 5:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.iceCandidatePayloads = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = S(a);
                            b.iceCandidatePayloads.push(g)
                        }
                    } else a.skip(e);
                    break;
                case 6:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.okPayload = T(a) : a.skip(e);
                    break;
                case 7:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.hangUpPayload = U(a) : a.skip(e);
                    break;
                case 8:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.otherDismissPayload = V(a) : a.skip(e);
                    break;
                case 9:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.pranswerPayload = W(a) : a.skip(e);
                    break;
                case 13:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.notifyMediaStatePayload = L(a) : a.skip(e);
                    break;
                case 14:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.ackPayload = X(a) : a.skip(e);
                    break;
                case 15:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.offerNackPayload = P(a) : a.skip(e);
                    break;
                case 16:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.nackPayload = Y(a) : a.skip(e);
                    break;
                case 17:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.videoRequestPayload = K(a) : a.skip(e);
                    break;
                case 18:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpUpdatePayload = Z(a) : a.skip(e);
                    break;
                case 24:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.switchToMultiwayPayload = wa(a) : a.skip(e);
                    break;
                case 26:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpNegotiatePayload = xa(a) : a.skip(e);
                    break;
                case 27:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.ringPayload = ya(a) : a.skip(e);
                    break;
                case 28:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.prOfferAckPayload = za(a) : a.skip(e);
                    break;
                case 29:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.clientReportedEventPayload = Aa(a) : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }
    g.StreamInfo$DefaultConstructor = a;
    g.TrackInfo$DefaultConstructor = b;
    g.VideoRequestPayload$DefaultConstructor = e;
    g.NotifyMediaStatePayload$DefaultConstructor = f;
    g.P2PSfuAllocation$DefaultConstructor = i;
    g.OfferPayload$DefaultConstructor = j;
    g.OfferAckPayload$DefaultConstructor = aa;
    g.OfferNackPayload$DefaultConstructor = ba;
    g.AnswerPayload$DefaultConstructor = ca;
    g.AnswerAckPayload$DefaultConstructor = da;
    g.IceCandidatePayload$DefaultConstructor = ea;
    g.OkPayload$DefaultConstructor = fa;
    g.HangUpPayload$DefaultConstructor = ga;
    g.OtherDismissPayload$DefaultConstructor = ha;
    g.PranswerPayload$DefaultConstructor = ia;
    g.AckPayload$DefaultConstructor = ja;
    g.NackPayload$DefaultConstructor = ka;
    g.SdpUpdatePayload$DefaultConstructor = la;
    g.SwitchToMultiwayPayload$DefaultConstructor = ma;
    g.SdpNegotiatePayload$DefaultConstructor = na;
    g.RingPayload$DefaultConstructor = oa;
    g.PrOfferAckPayload$DefaultConstructor = pa;
    g.ClientReportedEventPayload$DefaultConstructor = qa;
    g.WebrtcMessageEndpoint$DefaultConstructor = ra;
    g.WebrtcMessageHeader$DefaultConstructor = sa;
    g.WebrtcMessagePayload$DefaultConstructor = ta;
    g.serializeStreamInfo = k;
    g.serializeTrackInfo = l;
    g.serializeVideoRequestPayload = m;
    g.serializeNotifyMediaStatePayload = n;
    g.serializeP2PSfuAllocation = o;
    g.serializeOfferPayload = p;
    g.serializeOfferAckPayload = q;
    g.serializeOfferNackPayload = r;
    g.serializeAnswerPayload = s;
    g.serializeAnswerAckPayload = t;
    g.serializeIceCandidatePayload = u;
    g.serializeOkPayload = v;
    g.serializeHangUpPayload = w;
    g.serializeOtherDismissPayload = x;
    g.serializePranswerPayload = y;
    g.serializeAckPayload = z;
    g.serializeNackPayload = A;
    g.serializeSdpUpdatePayload = B;
    g.serializeSwitchToMultiwayPayload = C;
    g.serializeSdpNegotiatePayload = D;
    g.serializeRingPayload = E;
    g.serializePrOfferAckPayload = F;
    g.serializeClientReportedEventPayload = G;
    g.serializeWebrtcMessageEndpoint = H;
    g.serializeWebrtcMessageHeader = ua;
    g.serializeWebrtcMessagePayload = va;
    g.deserializeStreamInfo = I;
    g.deserializeTrackInfo = J;
    g.deserializeVideoRequestPayload = K;
    g.deserializeNotifyMediaStatePayload = L;
    g.deserializeP2PSfuAllocation = M;
    g.deserializeOfferPayload = N;
    g.deserializeOfferAckPayload = O;
    g.deserializeOfferNackPayload = P;
    g.deserializeAnswerPayload = Q;
    g.deserializeAnswerAckPayload = R;
    g.deserializeIceCandidatePayload = S;
    g.deserializeOkPayload = T;
    g.deserializeHangUpPayload = U;
    g.deserializeOtherDismissPayload = V;
    g.deserializePranswerPayload = W;
    g.deserializeAckPayload = X;
    g.deserializeNackPayload = Y;
    g.deserializeSdpUpdatePayload = Z;
    g.deserializeSwitchToMultiwayPayload = wa;
    g.deserializeSdpNegotiatePayload = xa;
    g.deserializeRingPayload = ya;
    g.deserializePrOfferAckPayload = za;
    g.deserializeClientReportedEventPayload = Aa;
    g.deserializeWebrtcMessageEndpoint = $;
    g.deserializeWebrtcMessageHeader = Ba;
    g.deserializeWebrtcMessagePayload = Ca
}), 98);
__d("MultiwayCommonSerializers", ["DataMessageSerializers", "DataMessageTypes", "MultiwayCommonTypes", "MultiwaySharedSerializers", "MultiwaySharedTypes", "StateSyncSerializers", "StateSyncTopicsConfigTypes", "StringToUtf8", "ThriftTypes", "Utf8ToString", "WebrtcPayloadSerializers", "WebrtcSdpSerializers", "WebrtcSignalingCommonTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        var a;
        return {
            message: "",
            responseStatusCode: (a = d("MultiwayCommonTypes")).RtcResponseStatusCode.cast(0),
            responseSubCode: a.RtcResponseSubCode.cast(0),
            apiStatusCode: a.RtcApiStatusCode.cast(0),
            rtcLogSeverity: a.RtcLogSeverity.cast(0)
        }
    }

    function i() {
        return {}
    }

    function b() {
        return {
            media: {}
        }
    }

    function e() {
        return {
            body: "",
            msid: "",
            mid: ""
        }
    }

    function f() {
        return {
            sourceKey: "",
            media: [],
            ssrcGroups: []
        }
    }

    function j() {
        return {
            mediaStatus: {}
        }
    }

    function k() {
        return {
            sdpMLineIndex: "0",
            sdpMid: ""
        }
    }

    function l() {
        return {
            stateStore: {},
            stateStoreV2: {}
        }
    }

    function aa() {
        return {
            version: 0
        }
    }

    function ba() {
        return {
            encryptedTopic: "",
            encryptedData: Uint8Array.of(),
            senderId: Uint8Array.of(),
            messageType: d("MultiwayCommonTypes").E2eeDataMessageType.cast(0)
        }
    }

    function ca() {
        return {
            header: d("WebrtcPayloadSerializers").WebrtcMessageHeader$DefaultConstructor(),
            payload: d("WebrtcPayloadSerializers").WebrtcMessagePayload$DefaultConstructor()
        }
    }

    function da() {
        return {
            fromVersion: "0",
            toVersion: "0",
            mediaUpdates: []
        }
    }

    function ea() {
        return {
            currentVersion: "0",
            mediaPath: d("MultiwaySharedTypes").MediaPath.cast(0)
        }
    }

    function fa() {
        return {
            callerUserId: "",
            calleeUserId: "",
            sessionId: ""
        }
    }

    function ga() {
        return {
            fromVersion: "0",
            toVersion: "0",
            mediaUpdates: [],
            renegotiationRequested: !1,
            multipleVideoStreamsAllowed: !1,
            mediaPath: d("MultiwaySharedTypes").MediaPath.cast(0),
            screenShareStreamAllowed: !1
        }
    }

    function ha() {
        return {
            currentVersion: "0"
        }
    }

    function ia() {
        return {}
    }

    function ja() {
        return {
            reason: d("MultiwayCommonTypes").HangupReason.cast(0),
            detailedReasonString: ""
        }
    }

    function ka() {
        return {
            iceCandidateSdps: []
        }
    }

    function la() {
        return {
            reason: d("MultiwayCommonTypes").DismissReason.cast(0),
            detailedReasonString: ""
        }
    }

    function ma() {
        return {
            joinMode: d("MultiwayCommonTypes").JoinMode.cast(0)
        }
    }

    function na() {
        return {
            state: d("MultiwayCommonTypes").ParticipantCallState.cast(0)
        }
    }

    function oa() {
        return {}
    }

    function pa() {
        return {}
    }

    function qa() {
        return {}
    }

    function ra() {
        return {
            version: "0",
            participantStates: {},
            groupsOfUsers: []
        }
    }

    function sa() {
        return {
            currentVersion: "0"
        }
    }

    function ta() {
        return {
            subscriptions: []
        }
    }

    function ua() {
        return {
            message: d("DataMessageSerializers").DataMessage$DefaultConstructor()
        }
    }

    function va() {
        return {
            deliveryResult: {}
        }
    }

    function wa() {
        return {
            usersToInvite: new Set()
        }
    }

    function xa() {
        return {
            smcTier: "",
            region: "",
            isUsfu: !1,
            isEdge: !1
        }
    }

    function ya() {
        return {
            offer: i(),
            deviceCapabilities: new Set()
        }
    }

    function za() {
        return {
            answer: i(),
            mediaStatus: {},
            initiator: "",
            isPendingApproval: !1,
            multipleVideoStreamsAllowed: !1,
            mediaPath: d("MultiwaySharedTypes").MediaPath.cast(0),
            groupsOfUsers: [],
            screenShareStreamAllowed: !1
        }
    }

    function Aa() {
        return {
            deviceCapabilities: new Set()
        }
    }

    function Ba() {
        return {}
    }

    function Ca() {
        return {
            type: d("MultiwayCommonTypes").ClientEventType.cast(0)
        }
    }

    function Da() {
        return {
            clientEvents: []
        }
    }

    function Ea() {
        return {}
    }

    function Fa() {
        return {}
    }

    function Ga() {
        return {
            caller: "",
            otherParticipants: new Set(),
            ringType: d("MultiwayCommonTypes").RingType.cast(0),
            mediaPath: d("MultiwaySharedTypes").MediaPath.cast(0),
            isTransferCall: !1
        }
    }

    function Ha() {
        return {
            deviceStatus: d("MultiwayCommonTypes").DeviceStatus.cast(0)
        }
    }

    function Ia() {
        return {
            usersToRemove: new Set()
        }
    }

    function Ja() {
        return {
            topic: "",
            version: 0,
            topicId: d("StateSyncTopicsConfigTypes").TopicId.cast(0)
        }
    }

    function Ka() {
        return {
            topic: "",
            version: 0
        }
    }

    function La() {
        return {
            syncPayload: l(),
            topic: "",
            version: 0,
            topicId: d("StateSyncTopicsConfigTypes").TopicId.cast(0)
        }
    }

    function Ma() {
        return {
            topic: "",
            version: 0
        }
    }

    function Na() {
        return {
            topic: "",
            version: 0,
            data: Uint8Array.of()
        }
    }

    function Oa() {
        return {
            topic: "",
            version: 0
        }
    }

    function Pa() {
        return {
            approvalStatus: d("MultiwayCommonTypes").ApprovalStatus.cast(0),
            targetUsers: new Set()
        }
    }

    function Qa() {
        return {
            id: ""
        }
    }

    function Ra() {
        return {
            actorId: "",
            baseId: ""
        }
    }

    function m() {
        return {
            type: d("MultiwayCommonTypes").MessageType.cast(0),
            conferenceName: "",
            transactionId: "",
            retryCount: 0
        }
    }

    function n() {
        return {}
    }

    function Sa() {
        return {
            messageHeader: m(),
            messageBody: n()
        }
    }

    function Ta() {
        return {
            users: new Set(),
            allowMultipleJoins: !1,
            dismissOthersOnFirstJoin: !1,
            aliasId: ""
        }
    }

    function Ua() {
        return {}
    }

    function Va(a, b) {
        b.writeStructBegin("RtcException");
        b.writeFieldBegin({
            fname: "message",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.message != null) b.writeString(a.message);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "responseStatusCode",
            ftype: h.I32,
            fid: 2
        });
        if (a.responseStatusCode != null) {
            b.writeI32((e = a.responseStatusCode) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").RtcResponseStatusCode.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "responseSubCode",
            ftype: h.I32,
            fid: 3
        });
        if (a.responseSubCode != null) {
            b.writeI32((e = a.responseSubCode) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").RtcResponseSubCode.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "apiStatusCode",
            ftype: h.I32,
            fid: 4
        });
        if (a.apiStatusCode != null) {
            b.writeI32((e = a.apiStatusCode) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").RtcApiStatusCode.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "rtcLogSeverity",
            ftype: h.I32,
            fid: 5
        });
        if (a.rtcLogSeverity != null) {
            b.writeI32((e = a.rtcLogSeverity) != null ? e : 0)
        } else {
            a = d("MultiwayCommonTypes").RtcLogSeverity.cast(0);
            b.writeI32((e = a) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function o(a, b) {
        b.writeStructBegin("SessionDescription"), a.sdpString != null && (b.writeFieldBegin({
            fname: "sdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.sdpString), b.writeFieldEnd()), a.sdpThrift != null && (b.writeFieldBegin({
            fname: "sdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), d("WebrtcSdpSerializers").serializeSdp(a.sdpThrift, b), b.writeFieldEnd()), a.sdpCompressionVersion != null && (b.writeFieldBegin({
            fname: "sdpCompressionVersion",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 3
        }), b.writeI64(BigInt(a.sdpCompressionVersion)), b.writeFieldEnd()), a.sdpCompressedData != null && (b.writeFieldBegin({
            fname: "sdpCompressedData",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeBinary(a.sdpCompressedData), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function Wa(a, b) {
        b.writeStructBegin("SessionDescriptionUpdate");
        b.writeFieldBegin({
            fname: "media",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.media != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.STRUCT,
                size: Object.keys(a.media).length
            });
            a = Object.entries(a.media);
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = e[0];
                e = e[1];
                b.writeI32(Number(f));
                p(e, b)
            }
            b.writeMapEnd()
        } else {
            f = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.STRUCT,
                size: Object.keys(f).length
            });
            e = Object.entries(f);
            for (a = 0; a < e.length; a++) {
                d = e[a];
                f = d[0];
                d = d[1];
                b.writeI32(Number(f));
                p(d, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function p(a, b) {
        b.writeStructBegin("MediaDescriptionUpdate");
        b.writeFieldBegin({
            fname: "body",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.body != null) b.writeString(a.body);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "msid",
            ftype: h.STRING,
            fid: 2
        });
        if (a.msid != null) b.writeString(a.msid);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "mid",
            ftype: h.STRING,
            fid: 3
        });
        if (a.mid != null) b.writeString(a.mid);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function q(a, b) {
        b.writeStructBegin("ServerMediaUpdate");
        b.writeFieldBegin({
            fname: "sourceKey",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.sourceKey != null) b.writeString(a.sourceKey);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "media",
            ftype: h.LIST,
            fid: 2
        });
        if (a.media != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.media.length
            });
            for (var e = a.media, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                d("MultiwaySharedSerializers").serializeMedia(i, b)
            }
            b.writeListEnd()
        } else {
            i = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: i.length
            });
            for (g = 0; g < i.length; g++) {
                f = i[g];
                d("MultiwaySharedSerializers").serializeMedia(f, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "ssrcGroups",
            ftype: h.LIST,
            fid: 3
        });
        if (a.ssrcGroups != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.ssrcGroups.length
            });
            for (e = a.ssrcGroups, f = Array.isArray(e), i = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (i >= e.length) break;
                    g = e[i++]
                } else {
                    i = e.next();
                    if (i.done) break;
                    g = i.value
                }
                a = g;
                d("MultiwaySharedSerializers").serializeSsrcGroup(a, b)
            }
            b.writeListEnd()
        } else {
            g = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: g.length
            });
            for (a = 0; a < g.length; a++) {
                i = g[a];
                d("MultiwaySharedSerializers").serializeSsrcGroup(i, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function r(a, b) {
        b.writeStructBegin("ClientMediaUpdate");
        b.writeFieldBegin({
            fname: "mediaStatus",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.mediaStatus != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.BOOL,
                size: Object.keys(a.mediaStatus).length
            });
            var e = Object.entries(a.mediaStatus);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                b.writeBool(g)
            }
            b.writeMapEnd()
        } else {
            i = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.BOOL,
                size: Object.keys(i).length
            });
            g = Object.entries(i);
            for (e = 0; e < g.length; e++) {
                f = g[e];
                i = f[0];
                f = f[1];
                b.writeString(i);
                b.writeBool(f)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        a.mediaStatusEx != null && (b.writeFieldBegin({
            fname: "mediaStatusEx",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), d("MultiwaySharedSerializers").serializeClientMediaStatus(a.mediaStatusEx, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function s(a, b) {
        b.writeStructBegin("IceCandidate");
        a.candidateSdpString != null && (b.writeFieldBegin({
            fname: "candidateSdpString",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.candidateSdpString), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "sdpMLineIndex",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 2
        });
        if (a.sdpMLineIndex != null) b.writeI64(BigInt(a.sdpMLineIndex));
        else {
            var e = "0";
            b.writeI64(BigInt(e))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "sdpMid",
            ftype: h.STRING,
            fid: 3
        });
        if (a.sdpMid != null) b.writeString(a.sdpMid);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.candidateSdpThrift != null && (b.writeFieldBegin({
            fname: "candidateSdpThrift",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 4
        }), d("WebrtcSdpSerializers").serializeIceCandidateSdp(a.candidateSdpThrift, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function t(a, b) {
        b.writeStructBegin("SyncPayload");
        b.writeFieldBegin({
            fname: "stateStore",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.stateStore != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStore).length
            });
            var e = Object.entries(a.stateStore);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                d("StateSyncSerializers").serializeState(g, b)
            }
            b.writeMapEnd()
        } else {
            i = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(i).length
            });
            g = Object.entries(i);
            for (e = 0; e < g.length; e++) {
                f = g[e];
                i = f[0];
                f = f[1];
                b.writeString(i);
                d("StateSyncSerializers").serializeState(f, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "stateStoreV2",
            ftype: h.MAP,
            fid: 4
        });
        if (a.stateStoreV2 != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStoreV2).length
            });
            i = Object.entries(a.stateStoreV2);
            for (f = 0; f < i.length; f++) {
                g = i[f];
                e = g[0];
                a = g[1];
                b.writeI32((g = Number(e)) != null ? g : 0);
                d("StateSyncSerializers").serializeState(a, b)
            }
            b.writeMapEnd()
        } else {
            e = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).I32,
                vtype: h.STRUCT,
                size: Object.keys(e).length
            });
            g = Object.entries(e);
            for (a = 0; a < g.length; a++) {
                i = g[a];
                f = i[0];
                e = i[1];
                b.writeI32((i = Number(f)) != null ? i : 0);
                d("StateSyncSerializers").serializeState(e, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function Xa(a, b) {
        b.writeStructBegin("SyncAck");
        b.writeFieldBegin({
            fname: "version",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.version != null) b.writeI32(a.version);
        else {
            a = 0;
            b.writeI32(a)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function Ya(a, b) {
        b.writeStructBegin("E2eeData");
        b.writeFieldBegin({
            fname: "encryptedTopic",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.encryptedTopic != null) b.writeString(a.encryptedTopic);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "encryptedData",
            ftype: h.STRING,
            fid: 2
        });
        if (a.encryptedData != null) b.writeBinary(a.encryptedData);
        else {
            e = Uint8Array.of();
            b.writeBinary(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "senderId",
            ftype: h.STRING,
            fid: 3
        });
        if (a.senderId != null) b.writeBinary(a.senderId);
        else {
            e = Uint8Array.of();
            b.writeBinary(e)
        }
        b.writeFieldEnd();
        if (a.targetIds != null) {
            b.writeFieldBegin({
                fname: "targetIds",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 4
            });
            b.writeSetBegin({
                etype: h.STRING,
                size: a.targetIds.size
            });
            for (var e = a.targetIds, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                b.writeBinary(d("StringToUtf8").StringToUtf8(i))
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "messageType",
            ftype: h.I32,
            fid: 5
        });
        if (a.messageType != null) {
            b.writeI32((i = a.messageType) != null ? i : 0)
        } else {
            g = d("MultiwayCommonTypes").E2eeDataMessageType.cast(0);
            b.writeI32((f = g) != null ? f : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function u(a, b) {
        b.writeStructBegin("P2PMessageRequest");
        b.writeFieldBegin({
            fname: "header",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        });
        if (a.header != null) d("WebrtcPayloadSerializers").serializeWebrtcMessageHeader(a.header, b);
        else {
            var e = d("WebrtcPayloadSerializers").WebrtcMessageHeader$DefaultConstructor();
            d("WebrtcPayloadSerializers").serializeWebrtcMessageHeader(e, b)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "payload",
            ftype: h.STRUCT,
            fid: 2
        });
        if (a.payload != null) d("WebrtcPayloadSerializers").serializeWebrtcMessagePayload(a.payload, b);
        else {
            e = d("WebrtcPayloadSerializers").WebrtcMessagePayload$DefaultConstructor();
            d("WebrtcPayloadSerializers").serializeWebrtcMessagePayload(e, b)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function v(a, b) {
        b.writeStructBegin("ClientMediaUpdateRequest");
        b.writeFieldBegin({
            fname: "fromVersion",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.fromVersion != null) b.writeI64(BigInt(a.fromVersion));
        else {
            var d = "0";
            b.writeI64(BigInt(d))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "toVersion",
            ftype: h.I64,
            fid: 2
        });
        if (a.toVersion != null) b.writeI64(BigInt(a.toVersion));
        else {
            d = "0";
            b.writeI64(BigInt(d))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "mediaUpdates",
            ftype: h.LIST,
            fid: 3
        });
        if (a.mediaUpdates != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.mediaUpdates.length
            });
            for (var d = a.mediaUpdates, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                r(g, b)
            }
            b.writeListEnd()
        } else {
            g = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: g.length
            });
            for (f = 0; f < g.length; f++) {
                e = g[f];
                r(e, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        a.offer != null && (b.writeFieldBegin({
            fname: "offer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 4
        }), o(a.offer, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function w(a, b) {
        b.writeStructBegin("ClientMediaUpdateResponse");
        b.writeFieldBegin({
            fname: "currentVersion",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.currentVersion != null) b.writeI64(BigInt(a.currentVersion));
        else {
            var e = "0";
            b.writeI64(BigInt(e))
        }
        b.writeFieldEnd();
        a.answer != null && (b.writeFieldBegin({
            fname: "answer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), o(a.answer, b), b.writeFieldEnd());
        a.mediaStatus != null && (b.writeFieldBegin({
            fname: "mediaStatus",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 3
        }), d("MultiwaySharedSerializers").serializeClientMediaStatus(a.mediaStatus, b), b.writeFieldEnd());
        a.sdpOriginLocalId != null && (b.writeFieldBegin({
            fname: "sdpOriginLocalId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.sdpOriginLocalId), b.writeFieldEnd());
        a.renegotiationOffer != null && (b.writeFieldBegin({
            fname: "renegotiationOffer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 5
        }), o(a.renegotiationOffer, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "mediaPath",
            ftype: h.I32,
            fid: 6
        });
        if (a.mediaPath != null) {
            b.writeI32((e = a.mediaPath) != null ? e : 0)
        } else {
            e = d("MultiwaySharedTypes").MediaPath.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        if (a.stateStore != null) {
            b.writeFieldBegin({
                fname: "stateStore",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 7
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStore).length
            });
            e = Object.entries(a.stateStore);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                d("StateSyncSerializers").serializeState(g, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.stateStoreV2 != null) {
            b.writeFieldBegin({
                fname: "stateStoreV2",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 8
            });
            b.writeMapBegin({
                ktype: h.I32,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStoreV2).length
            });
            i = Object.entries(a.stateStoreV2);
            for (g = 0; g < i.length; g++) {
                e = i[g];
                f = e[0];
                a = e[1];
                b.writeI32((e = Number(f)) != null ? e : 0);
                d("StateSyncSerializers").serializeState(a, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function Za(a, b) {
        b.writeStructBegin("MultipleRelaysAllocationParameters");
        b.writeFieldBegin({
            fname: "callerUserId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.callerUserId != null) b.writeString(a.callerUserId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "calleeUserId",
            ftype: h.STRING,
            fid: 2
        });
        if (a.calleeUserId != null) b.writeString(a.calleeUserId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "sessionId",
            ftype: h.STRING,
            fid: 3
        });
        if (a.sessionId != null) b.writeString(a.sessionId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function x(a, b) {
        b.writeStructBegin("ServerMediaUpdateRequest");
        b.writeFieldBegin({
            fname: "fromVersion",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.fromVersion != null) b.writeI64(BigInt(a.fromVersion));
        else {
            var e = "0";
            b.writeI64(BigInt(e))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "toVersion",
            ftype: h.I64,
            fid: 2
        });
        if (a.toVersion != null) b.writeI64(BigInt(a.toVersion));
        else {
            e = "0";
            b.writeI64(BigInt(e))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "mediaUpdates",
            ftype: h.LIST,
            fid: 3
        });
        if (a.mediaUpdates != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.mediaUpdates.length
            });
            for (var e = a.mediaUpdates, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                q(i, b)
            }
            b.writeListEnd()
        } else {
            i = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: i.length
            });
            for (g = 0; g < i.length; g++) {
                f = i[g];
                q(f, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        a.offer != null && (b.writeFieldBegin({
            fname: "offer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 4
        }), o(a.offer, b), b.writeFieldEnd());
        if (a.appMessages != null) {
            b.writeFieldBegin({
                fname: "appMessages",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 5
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.appMessages.length
            });
            for (e = a.appMessages, f = Array.isArray(e), i = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (i >= e.length) break;
                    g = e[i++]
                } else {
                    i = e.next();
                    if (i.done) break;
                    g = i.value
                }
                g = g;
                d("DataMessageSerializers").serializeDataMessage(g, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.answer != null && (b.writeFieldBegin({
            fname: "answer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 6
        }), o(a.answer, b), b.writeFieldEnd());
        a.mediaStatus != null && (b.writeFieldBegin({
            fname: "mediaStatus",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 7
        }), d("MultiwaySharedSerializers").serializeClientMediaStatus(a.mediaStatus, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "renegotiationRequested",
            ftype: h.BOOL,
            fid: 8
        });
        if (a.renegotiationRequested != null) b.writeBool(a.renegotiationRequested);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        a.prAnswer != null && (b.writeFieldBegin({
            fname: "prAnswer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 9
        }), o(a.prAnswer, b), b.writeFieldEnd());
        if (a.stateStore != null) {
            b.writeFieldBegin({
                fname: "stateStore",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 10
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStore).length
            });
            i = Object.entries(a.stateStore);
            for (f = 0; f < i.length; f++) {
                e = i[f];
                g = e[0];
                e = e[1];
                b.writeString(g);
                d("StateSyncSerializers").serializeState(e, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.sdpOriginLocalId != null && (b.writeFieldBegin({
            fname: "sdpOriginLocalId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 11
        }), b.writeString(a.sdpOriginLocalId), b.writeFieldEnd());
        a.multipleRelaysParameters != null && (b.writeFieldBegin({
            fname: "multipleRelaysParameters",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 12
        }), Za(a.multipleRelaysParameters, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "multipleVideoStreamsAllowed",
            ftype: h.BOOL,
            fid: 13
        });
        if (a.multipleVideoStreamsAllowed != null) b.writeBool(a.multipleVideoStreamsAllowed);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        a.renegotiationOffer != null && (b.writeFieldBegin({
            fname: "renegotiationOffer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 14
        }), o(a.renegotiationOffer, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "mediaPath",
            ftype: h.I32,
            fid: 15
        });
        if (a.mediaPath != null) {
            b.writeI32((e = a.mediaPath) != null ? e : 0)
        } else {
            i = d("MultiwaySharedTypes").MediaPath.cast(0);
            b.writeI32((f = i) != null ? f : 0)
        }
        b.writeFieldEnd();
        a.update != null && (b.writeFieldBegin({
            fname: "update",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 16
        }), Wa(a.update, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "screenShareStreamAllowed",
            ftype: h.BOOL,
            fid: 17
        });
        if (a.screenShareStreamAllowed != null) b.writeBool(a.screenShareStreamAllowed);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        if (a.stateStoreV2 != null) {
            b.writeFieldBegin({
                fname: "stateStoreV2",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 18
            });
            b.writeMapBegin({
                ktype: h.I32,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStoreV2).length
            });
            e = Object.entries(a.stateStoreV2);
            for (i = 0; i < e.length; i++) {
                f = e[i];
                g = f[0];
                f = f[1];
                b.writeI32((g = Number(g)) != null ? g : 0);
                d("StateSyncSerializers").serializeState(f, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.allowedCustomVideoContentTypes != null) {
            b.writeFieldBegin({
                fname: "allowedCustomVideoContentTypes",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 19
            });
            b.writeSetBegin({
                etype: h.I32,
                size: a.allowedCustomVideoContentTypes.size
            });
            for (g = a.allowedCustomVideoContentTypes, f = Array.isArray(g), e = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (e >= g.length) break;
                    i = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    i = e.value
                }
                i = i;
                b.writeI32((i = i) != null ? i : 0)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        a.relayInfo != null && (b.writeFieldBegin({
            fname: "relayInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 20
        }), d("MultiwaySharedSerializers").serializeRelayInfo(a.relayInfo, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function y(a, b) {
        b.writeStructBegin("ServerMediaUpdateResponse");
        b.writeFieldBegin({
            fname: "currentVersion",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.currentVersion != null) b.writeI64(BigInt(a.currentVersion));
        else {
            var e = "0";
            b.writeI64(BigInt(e))
        }
        b.writeFieldEnd();
        a.answer != null && (b.writeFieldBegin({
            fname: "answer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), o(a.answer, b), b.writeFieldEnd());
        a.mediaStatus != null && (b.writeFieldBegin({
            fname: "mediaStatus",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 3
        }), d("MultiwaySharedSerializers").serializeClientMediaStatus(a.mediaStatus, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function z(a, b) {
        b.writeStructBegin("TransferRequest"), b.writeFieldStop(), b.writeStructEnd()
    }

    function A(a, b) {
        b.writeStructBegin("HangupRequest");
        b.writeFieldBegin({
            fname: "reason",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.reason != null) {
            var e;
            b.writeI32((e = a.reason) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").HangupReason.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "detailedReasonString",
            ftype: h.STRING,
            fid: 2
        });
        if (a.detailedReasonString != null) b.writeString(a.detailedReasonString);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function B(a, b) {
        b.writeStructBegin("IceCandidateRequest");
        b.writeFieldBegin({
            fname: "iceCandidateSdps",
            ftype: (h || (h = c("ThriftTypes"))).LIST,
            fid: 1
        });
        if (a.iceCandidateSdps != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.iceCandidateSdps.length
            });
            for (var a = a.iceCandidateSdps, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                s(f, b)
            }
            b.writeListEnd()
        } else {
            f = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: f.length
            });
            for (e = 0; e < f.length; e++) {
                d = f[e];
                s(d, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function C(a, b) {
        b.writeStructBegin("DismissRequest");
        b.writeFieldBegin({
            fname: "reason",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.reason != null) {
            var e;
            b.writeI32((e = a.reason) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").DismissReason.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "detailedReasonString",
            ftype: h.STRING,
            fid: 2
        });
        if (a.detailedReasonString != null) b.writeString(a.detailedReasonString);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        a.callabilityResultErrorCode != null && (b.writeFieldBegin({
            fname: "callabilityResultErrorCode",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 3
        }), b.writeI64(BigInt(a.callabilityResultErrorCode)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function $a(a, b) {
        b.writeStructBegin("EndpointSettings");
        b.writeFieldBegin({
            fname: "joinMode",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.joinMode != null) {
            b.writeI32((a = a.joinMode) != null ? a : 0)
        } else {
            a = d("MultiwayCommonTypes").JoinMode.cast(0);
            b.writeI32((a = a) != null ? a : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function D(a, b) {
        b.writeStructBegin("ParticipantState");
        b.writeFieldBegin({
            fname: "state",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.state != null) {
            var e;
            b.writeI32((e = a.state) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").ParticipantCallState.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.userCapabilities != null && (b.writeFieldBegin({
            fname: "userCapabilities",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeBinary(a.userCapabilities), b.writeFieldEnd());
        a.sctpNodeId != null && (b.writeFieldBegin({
            fname: "sctpNodeId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 3
        }), b.writeI64(BigInt(a.sctpNodeId)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ab(a, b) {
        b.writeStructBegin("ServerOnlyParticipantState"), a.userCountry != null && (b.writeFieldBegin({
            fname: "userCountry",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.userCountry), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function E(a, b) {
        b.writeStructBegin("UserProfile"), a.name != null && (b.writeFieldBegin({
            fname: "name",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.name), b.writeFieldEnd()), a.profilePictureUri != null && (b.writeFieldBegin({
            fname: "profilePictureUri",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.profilePictureUri), b.writeFieldEnd()), a.aliasId != null && (b.writeFieldBegin({
            fname: "aliasId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 3
        }), b.writeString(a.aliasId), b.writeFieldEnd()), a.thirdPartyId != null && (b.writeFieldBegin({
            fname: "thirdPartyId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.thirdPartyId), b.writeFieldEnd()), a.groupId != null && (b.writeFieldBegin({
            fname: "groupId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 5
        }), b.writeString(a.groupId), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function bb(a, b) {
        b.writeStructBegin("ProductMetadata"), a.callerInfo != null && (b.writeFieldBegin({
            fname: "callerInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), E(a.callerInfo, b), b.writeFieldEnd()), a.liveBroadcastId != null && (b.writeFieldBegin({
            fname: "liveBroadcastId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.liveBroadcastId), b.writeFieldEnd()), a.callingTags != null && (b.writeFieldBegin({
            fname: "callingTags",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 3
        }), b.writeI32(a.callingTags), b.writeFieldEnd()), a.backingIdentifier != null && (b.writeFieldBegin({
            fname: "backingIdentifier",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.backingIdentifier), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function F(a, b) {
        b.writeStructBegin("ConferenceStateRequest");
        b.writeFieldBegin({
            fname: "version",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.version != null) b.writeI64(BigInt(a.version));
        else {
            var e = "0";
            b.writeI64(BigInt(e))
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "participantStates",
            ftype: h.MAP,
            fid: 2
        });
        if (a.participantStates != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.participantStates).length
            });
            e = Object.entries(a.participantStates);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                D(g, b)
            }
            b.writeMapEnd()
        } else {
            i = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.STRUCT,
                size: Object.keys(i).length
            });
            g = Object.entries(i);
            for (e = 0; e < g.length; e++) {
                f = g[e];
                i = f[0];
                f = f[1];
                b.writeString(i);
                D(f, b)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        if (a.userProfiles != null) {
            b.writeFieldBegin({
                fname: "userProfiles",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 3
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.userProfiles).length
            });
            i = Object.entries(a.userProfiles);
            for (f = 0; f < i.length; f++) {
                g = i[f];
                e = g[0];
                g = g[1];
                b.writeString(e);
                E(g, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.appMessages != null) {
            b.writeFieldBegin({
                fname: "appMessages",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 4
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.appMessages.length
            });
            for (e = a.appMessages, g = Array.isArray(e), i = 0, e = g ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (g) {
                    if (i >= e.length) break;
                    f = e[i++]
                } else {
                    i = e.next();
                    if (i.done) break;
                    f = i.value
                }
                f = f;
                d("DataMessageSerializers").serializeDataMessage(f, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldBegin({
            fname: "groupsOfUsers",
            ftype: h.LIST,
            fid: 5
        });
        if (a.groupsOfUsers != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.groupsOfUsers.length
            });
            for (f = a.groupsOfUsers, i = Array.isArray(f), g = 0, f = i ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (i) {
                    if (g >= f.length) break;
                    e = f[g++]
                } else {
                    g = f.next();
                    if (g.done) break;
                    e = g.value
                }
                a = e;
                Y(a, b)
            }
            b.writeListEnd()
        } else {
            e = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: e.length
            });
            for (a = 0; a < e.length; a++) {
                g = e[a];
                Y(g, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function G(a, b) {
        b.writeStructBegin("ConferenceStateResponse");
        b.writeFieldBegin({
            fname: "currentVersion",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 1
        });
        if (a.currentVersion != null) b.writeI64(BigInt(a.currentVersion));
        else {
            a = "0";
            b.writeI64(BigInt(a))
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function H(a, b) {
        b.writeStructBegin("SubscriptionRequest");
        b.writeFieldBegin({
            fname: "subscriptions",
            ftype: (h || (h = c("ThriftTypes"))).LIST,
            fid: 1
        });
        if (a.subscriptions != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.subscriptions.length
            });
            for (var a = a.subscriptions, e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= a.length) break;
                    g = a[f++]
                } else {
                    f = a.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                d("MultiwaySharedSerializers").serializeSubscription(g, b)
            }
            b.writeListEnd()
        } else {
            g = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: g.length
            });
            for (f = 0; f < g.length; f++) {
                e = g[f];
                d("MultiwaySharedSerializers").serializeSubscription(e, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function I(a, b) {
        b.writeStructBegin("DataMessageRequest");
        b.writeFieldBegin({
            fname: "message",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        });
        if (a.message != null) d("DataMessageSerializers").serializeDataMessage(a.message, b);
        else {
            a = d("DataMessageSerializers").DataMessage$DefaultConstructor();
            d("DataMessageSerializers").serializeDataMessage(a, b)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function J(a, b) {
        b.writeStructBegin("DataMessageResponse");
        b.writeFieldBegin({
            fname: "deliveryResult",
            ftype: (h || (h = c("ThriftTypes"))).MAP,
            fid: 1
        });
        if (a.deliveryResult != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.I32,
                size: Object.keys(a.deliveryResult).length
            });
            var d = Object.entries(a.deliveryResult);
            for (var e = 0; e < d.length; e++) {
                var f = d[e],
                    g = f[0];
                f = f[1];
                b.writeString(g);
                b.writeI32((g = f) != null ? g : 0)
            }
            b.writeMapEnd()
        } else {
            f = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.I32,
                size: Object.keys(f).length
            });
            g = Object.entries(f);
            for (d = 0; d < g.length; d++) {
                e = g[d];
                f = e[0];
                e = e[1];
                b.writeString(f);
                b.writeI32((f = e) != null ? f : 0)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        if (a.serviceTypeDeliveryResult != null) {
            b.writeFieldBegin({
                fname: "serviceTypeDeliveryResult",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 2
            });
            b.writeMapBegin({
                ktype: h.I32,
                vtype: h.I32,
                size: Object.keys(a.serviceTypeDeliveryResult).length
            });
            e = Object.entries(a.serviceTypeDeliveryResult);
            for (f = 0; f < e.length; f++) {
                g = e[f];
                d = g[0];
                a = g[1];
                b.writeI32((g = Number(d)) != null ? g : 0);
                b.writeI32((d = a) != null ? d : 0)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function K(a, b) {
        b.writeStructBegin("AddParticipantsRequest");
        b.writeFieldBegin({
            fname: "usersToInvite",
            ftype: (h || (h = c("ThriftTypes"))).SET,
            fid: 1
        });
        if (a.usersToInvite != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: a.usersToInvite.size
            });
            for (var e = a.usersToInvite, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                b.writeString(i)
            }
            b.writeSetEnd()
        } else {
            i = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: i.size
            });
            for (g = i, f = Array.isArray(g), e = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (e >= g.length) break;
                    i = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    i = e.value
                }
                i = i;
                b.writeString(i)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        if (a.appMessages != null) {
            b.writeFieldBegin({
                fname: "appMessages",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 2
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.appMessages.length
            });
            for (i = a.appMessages, e = Array.isArray(i), f = 0, i = e ? i : i[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (f >= i.length) break;
                    g = i[f++]
                } else {
                    f = i.next();
                    if (f.done) break;
                    g = f.value
                }
                a = g;
                d("DataMessageSerializers").serializeDataMessage(a, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function L(a, b) {
        b.writeStructBegin("SfuAllocation");
        b.writeFieldBegin({
            fname: "smcTier",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.smcTier != null) b.writeString(a.smcTier);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "region",
            ftype: h.STRING,
            fid: 2
        });
        if (a.region != null) b.writeString(a.region);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "isUsfu",
            ftype: h.BOOL,
            fid: 3
        });
        if (a.isUsfu != null) b.writeBool(a.isUsfu);
        else {
            d = !1;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "isEdge",
            ftype: h.BOOL,
            fid: 4
        });
        if (a.isEdge != null) b.writeBool(a.isEdge);
        else {
            d = !1;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function M(a, b) {
        b.writeStructBegin("JoinRequest");
        b.writeFieldBegin({
            fname: "offer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        });
        if (a.offer != null) o(a.offer, b);
        else {
            var e = i();
            o(e, b)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "deviceCapabilities",
            ftype: h.SET,
            fid: 2
        });
        if (a.deviceCapabilities != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).I32,
                size: a.deviceCapabilities.size
            });
            for (var e = a.deviceCapabilities, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var j;
                if (f) {
                    if (g >= e.length) break;
                    j = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    j = g.value
                }
                j = j;
                b.writeI32((j = j) != null ? j : 0)
            }
            b.writeSetEnd()
        } else {
            j = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).I32,
                size: j.size
            });
            for (g = j, f = Array.isArray(g), e = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (e >= g.length) break;
                    j = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    j = e.value
                }
                j = j;
                b.writeI32((j = j) != null ? j : 0)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        if (a.usersToCall != null) {
            b.writeFieldBegin({
                fname: "usersToCall",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 3
            });
            b.writeSetBegin({
                etype: h.STRING,
                size: a.usersToCall.size
            });
            for (j = a.usersToCall, e = Array.isArray(j), f = 0, j = e ? j : j[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (f >= j.length) break;
                    g = j[f++]
                } else {
                    f = j.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        if (a.mediaStatus != null) {
            b.writeFieldBegin({
                fname: "mediaStatus",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 4
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.BOOL,
                size: Object.keys(a.mediaStatus).length
            });
            g = Object.entries(a.mediaStatus);
            for (f = 0; f < g.length; f++) {
                e = g[f];
                j = e[0];
                e = e[1];
                b.writeString(j);
                b.writeBool(e)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.userCapabilities != null && (b.writeFieldBegin({
            fname: "userCapabilities",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 5
        }), b.writeBinary(a.userCapabilities), b.writeFieldEnd());
        a.supportedExperiments != null && (b.writeFieldBegin({
            fname: "supportedExperiments",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 6
        }), b.writeString(a.supportedExperiments), b.writeFieldEnd());
        if (a.appMessages != null) {
            b.writeFieldBegin({
                fname: "appMessages",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 9
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.appMessages.length
            });
            for (j = a.appMessages, e = Array.isArray(j), g = 0, j = e ? j : j[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (g >= j.length) break;
                    f = j[g++]
                } else {
                    g = j.next();
                    if (g.done) break;
                    f = g.value
                }
                f = f;
                d("DataMessageSerializers").serializeDataMessage(f, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.userToEscalate != null && (b.writeFieldBegin({
            fname: "userToEscalate",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 10
        }), b.writeString(a.userToEscalate), b.writeFieldEnd());
        a.escalatingCallId != null && (b.writeFieldBegin({
            fname: "escalatingCallId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 11
        }), b.writeI64(BigInt(a.escalatingCallId)), b.writeFieldEnd());
        if (a.conferenceType != null) {
            b.writeFieldBegin({
                fname: "conferenceType",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 12
            });
            b.writeI32((f = a.conferenceType) != null ? f : 0);
            b.writeFieldEnd()
        }
        a.mediaStatusEx != null && (b.writeFieldBegin({
            fname: "mediaStatusEx",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 13
        }), d("MultiwaySharedSerializers").serializeClientMediaStatus(a.mediaStatusEx, b), b.writeFieldEnd());
        a.answer != null && (b.writeFieldBegin({
            fname: "answer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 14
        }), o(a.answer, b), b.writeFieldEnd());
        a.syncPayload != null && (b.writeFieldBegin({
            fname: "syncPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 15
        }), t(a.syncPayload, b), b.writeFieldEnd());
        if (a.usersToApproveFromWaitingRoom != null) {
            b.writeFieldBegin({
                fname: "usersToApproveFromWaitingRoom",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 16
            });
            b.writeSetBegin({
                etype: h.STRING,
                size: a.usersToApproveFromWaitingRoom.size
            });
            for (g = a.usersToApproveFromWaitingRoom, e = Array.isArray(g), j = 0, g = e ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (j >= g.length) break;
                    f = g[j++]
                } else {
                    j = g.next();
                    if (j.done) break;
                    f = j.value
                }
                f = f;
                b.writeString(f)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        a.e2eeEnforcement != null && (b.writeFieldBegin({
            fname: "e2eeEnforcement",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 17
        }), d("MultiwaySharedSerializers").serializeE2eeEnforcement(a.e2eeEnforcement, b), b.writeFieldEnd());
        a.sfuAllocation != null && (b.writeFieldBegin({
            fname: "sfuAllocation",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 18
        }), L(a.sfuAllocation, b), b.writeFieldEnd());
        if (a.clientMediaMode != null) {
            b.writeFieldBegin({
                fname: "clientMediaMode",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 19
            });
            b.writeI32((f = a.clientMediaMode) != null ? f : 0);
            b.writeFieldEnd()
        }
        a.endpointSettings != null && (b.writeFieldBegin({
            fname: "endpointSettings",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 20
        }), $a(a.endpointSettings, b), b.writeFieldEnd());
        a.backupSfuAllocation != null && (b.writeFieldBegin({
            fname: "backupSfuAllocation",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 21
        }), L(a.backupSfuAllocation, b), b.writeFieldEnd());
        if (a.supportedCustomVideoContentTypes != null) {
            b.writeFieldBegin({
                fname: "supportedCustomVideoContentTypes",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 22
            });
            b.writeSetBegin({
                etype: h.I32,
                size: a.supportedCustomVideoContentTypes.size
            });
            for (j = a.supportedCustomVideoContentTypes, e = Array.isArray(j), g = 0, j = e ? j : j[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (g >= j.length) break;
                    f = j[g++]
                } else {
                    g = j.next();
                    if (g.done) break;
                    f = g.value
                }
                f = f;
                b.writeI32((f = f) != null ? f : 0)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        a.configIntegrityOpaqueToken != null && (b.writeFieldBegin({
            fname: "configIntegrityOpaqueToken",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 23
        }), b.writeI32(a.configIntegrityOpaqueToken), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function N(a, b) {
        b.writeStructBegin("JoinResponse");
        b.writeFieldBegin({
            fname: "answer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        });
        if (a.answer != null) o(a.answer, b);
        else {
            var e = i();
            o(e, b)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "mediaStatus",
            ftype: h.MAP,
            fid: 2
        });
        if (a.mediaStatus != null) {
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.BOOL,
                size: Object.keys(a.mediaStatus).length
            });
            e = Object.entries(a.mediaStatus);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    j = g[0];
                g = g[1];
                b.writeString(j);
                b.writeBool(g)
            }
            b.writeMapEnd()
        } else {
            j = {};
            b.writeMapBegin({
                ktype: (h || (h = c("ThriftTypes"))).STRING,
                vtype: h.BOOL,
                size: Object.keys(j).length
            });
            g = Object.entries(j);
            for (e = 0; e < g.length; e++) {
                f = g[e];
                j = f[0];
                f = f[1];
                b.writeString(j);
                b.writeBool(f)
            }
            b.writeMapEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "initiator",
            ftype: h.STRING,
            fid: 3
        });
        if (a.initiator != null) b.writeString(a.initiator);
        else {
            j = "";
            b.writeString(j)
        }
        b.writeFieldEnd();
        a.negotiatedExperiments != null && (b.writeFieldBegin({
            fname: "negotiatedExperiments",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeString(a.negotiatedExperiments), b.writeFieldEnd());
        a.mediaStatusEx != null && (b.writeFieldBegin({
            fname: "mediaStatusEx",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 6
        }), d("MultiwaySharedSerializers").serializeClientMediaStatus(a.mediaStatusEx, b), b.writeFieldEnd());
        if (a.appMessages != null) {
            b.writeFieldBegin({
                fname: "appMessages",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 7
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.appMessages.length
            });
            for (f = a.appMessages, g = Array.isArray(f), e = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (g) {
                    if (e >= f.length) break;
                    j = f[e++]
                } else {
                    e = f.next();
                    if (e.done) break;
                    j = e.value
                }
                j = j;
                d("DataMessageSerializers").serializeDataMessage(j, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        if (a.stateStore != null) {
            b.writeFieldBegin({
                fname: "stateStore",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 8
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStore).length
            });
            j = Object.entries(a.stateStore);
            for (e = 0; e < j.length; e++) {
                g = j[e];
                f = g[0];
                g = g[1];
                b.writeString(f);
                d("StateSyncSerializers").serializeState(g, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.sdpOriginLocalId != null && (b.writeFieldBegin({
            fname: "sdpOriginLocalId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 9
        }), b.writeString(a.sdpOriginLocalId), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "isPendingApproval",
            ftype: h.BOOL,
            fid: 10
        });
        if (a.isPendingApproval != null) b.writeBool(a.isPendingApproval);
        else {
            f = !1;
            b.writeBool(f)
        }
        b.writeFieldEnd();
        a.renegotiationOffer != null && (b.writeFieldBegin({
            fname: "renegotiationOffer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 11
        }), o(a.renegotiationOffer, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "multipleVideoStreamsAllowed",
            ftype: h.BOOL,
            fid: 12
        });
        if (a.multipleVideoStreamsAllowed != null) b.writeBool(a.multipleVideoStreamsAllowed);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "mediaPath",
            ftype: h.I32,
            fid: 13
        });
        if (a.mediaPath != null) {
            b.writeI32((j = a.mediaPath) != null ? j : 0)
        } else {
            e = d("MultiwaySharedTypes").MediaPath.cast(0);
            b.writeI32((f = e) != null ? f : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "groupsOfUsers",
            ftype: h.LIST,
            fid: 14
        });
        if (a.groupsOfUsers != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.groupsOfUsers.length
            });
            for (g = a.groupsOfUsers, j = Array.isArray(g), e = 0, g = j ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (j) {
                    if (e >= g.length) break;
                    f = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                Y(f, b)
            }
            b.writeListEnd()
        } else {
            f = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: f.length
            });
            for (e = 0; e < f.length; e++) {
                j = f[e];
                Y(j, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "screenShareStreamAllowed",
            ftype: h.BOOL,
            fid: 15
        });
        if (a.screenShareStreamAllowed != null) b.writeBool(a.screenShareStreamAllowed);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        a.relayInfo != null && (b.writeFieldBegin({
            fname: "relayInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 16
        }), d("MultiwaySharedSerializers").serializeRelayInfo(a.relayInfo, b), b.writeFieldEnd());
        a.selfSctpNodeId != null && (b.writeFieldBegin({
            fname: "selfSctpNodeId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 17
        }), b.writeI64(BigInt(a.selfSctpNodeId)), b.writeFieldEnd());
        if (a.stateStoreV2 != null) {
            b.writeFieldBegin({
                fname: "stateStoreV2",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 18
            });
            b.writeMapBegin({
                ktype: h.I32,
                vtype: h.STRUCT,
                size: Object.keys(a.stateStoreV2).length
            });
            j = Object.entries(a.stateStoreV2);
            for (f = 0; f < j.length; f++) {
                e = j[f];
                g = e[0];
                e = e[1];
                b.writeI32((g = Number(g)) != null ? g : 0);
                d("StateSyncSerializers").serializeState(e, b)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        if (a.allowedCustomVideoContentTypes != null) {
            b.writeFieldBegin({
                fname: "allowedCustomVideoContentTypes",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 19
            });
            b.writeSetBegin({
                etype: h.I32,
                size: a.allowedCustomVideoContentTypes.size
            });
            for (g = a.allowedCustomVideoContentTypes, e = Array.isArray(g), j = 0, g = e ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (j >= g.length) break;
                    f = g[j++]
                } else {
                    j = g.next();
                    if (j.done) break;
                    f = j.value
                }
                a = f;
                b.writeI32((f = a) != null ? f : 0)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function O(a, b) {
        b.writeStructBegin("ConnectRequest");
        a.sdp != null && (b.writeFieldBegin({
            fname: "sdp",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), o(a.sdp, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "deviceCapabilities",
            ftype: (h || (h = c("ThriftTypes"))).SET,
            fid: 3
        });
        if (a.deviceCapabilities != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).I32,
                size: a.deviceCapabilities.size
            });
            for (var e = a.deviceCapabilities, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                b.writeI32((i = i) != null ? i : 0)
            }
            b.writeSetEnd()
        } else {
            i = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).I32,
                size: i.size
            });
            for (g = i, f = Array.isArray(g), e = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (e >= g.length) break;
                    i = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    i = e.value
                }
                i = i;
                b.writeI32((i = i) != null ? i : 0)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        if (a.supportedCustomVideoContentTypes != null) {
            b.writeFieldBegin({
                fname: "supportedCustomVideoContentTypes",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 5
            });
            b.writeSetBegin({
                etype: h.I32,
                size: a.supportedCustomVideoContentTypes.size
            });
            for (i = a.supportedCustomVideoContentTypes, e = Array.isArray(i), f = 0, i = e ? i : i[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (f >= i.length) break;
                    g = i[f++]
                } else {
                    f = i.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.writeI32((g = g) != null ? g : 0)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        a.prOffer != null && (b.writeFieldBegin({
            fname: "prOffer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 6
        }), o(a.prOffer, b), b.writeFieldEnd());
        a.e2eeEnforcement != null && (b.writeFieldBegin({
            fname: "e2eeEnforcement",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 7
        }), d("MultiwaySharedSerializers").serializeE2eeEnforcement(a.e2eeEnforcement, b), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function P(a, b) {
        b.writeStructBegin("ConnectResponse"), a.sdp != null && (b.writeFieldBegin({
            fname: "sdp",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), o(a.sdp, b), b.writeFieldEnd()), a.sdpOriginLocalId != null && (b.writeFieldBegin({
            fname: "sdpOriginLocalId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.sdpOriginLocalId), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function Q(a, b) {
        b.writeStructBegin("ClientEvent");
        b.writeFieldBegin({
            fname: "type",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.type != null) {
            var e;
            b.writeI32((e = a.type) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").ClientEventType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        a.time != null && (b.writeFieldBegin({
            fname: "time",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 2
        }), b.writeI64(BigInt(a.time)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function R(a, b) {
        b.writeStructBegin("ClientEventRequest");
        b.writeFieldBegin({
            fname: "clientEvents",
            ftype: (h || (h = c("ThriftTypes"))).LIST,
            fid: 1
        });
        if (a.clientEvents != null) {
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: a.clientEvents.length
            });
            for (var a = a.clientEvents, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                Q(f, b)
            }
            b.writeListEnd()
        } else {
            f = [];
            b.writeListBegin({
                etype: (h || (h = c("ThriftTypes"))).STRUCT,
                size: f.length
            });
            for (e = 0; e < f.length; e++) {
                d = f[e];
                Q(d, b)
            }
            b.writeListEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function cb(a, b) {
        b.writeStructBegin("ThreadIdInfo"), a.groupThreadId != null && (b.writeFieldBegin({
            fname: "groupThreadId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        }), b.writeString(a.groupThreadId), b.writeFieldEnd()), a.peerId != null && (b.writeFieldBegin({
            fname: "peerId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        }), b.writeString(a.peerId), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function S(a, b) {
        b.writeStructBegin("ClientEventResponse"), b.writeFieldStop(), b.writeStructEnd()
    }

    function T(a, b) {
        b.writeStructBegin("RingRequest");
        b.writeFieldBegin({
            fname: "caller",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.caller != null) b.writeString(a.caller);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "otherParticipants",
            ftype: h.SET,
            fid: 2
        });
        if (a.otherParticipants != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: a.otherParticipants.size
            });
            for (var e = a.otherParticipants, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (f) {
                    if (g >= e.length) break;
                    i = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    i = g.value
                }
                i = i;
                b.writeString(i)
            }
            b.writeSetEnd()
        } else {
            i = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: i.size
            });
            for (g = i, f = Array.isArray(g), e = 0, g = f ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (f) {
                    if (e >= g.length) break;
                    i = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    i = e.value
                }
                i = i;
                b.writeString(i)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "ringType",
            ftype: h.I32,
            fid: 4
        });
        if (a.ringType != null) {
            b.writeI32((i = a.ringType) != null ? i : 0)
        } else {
            e = d("MultiwayCommonTypes").RingType.cast(0);
            b.writeI32((f = e) != null ? f : 0)
        }
        b.writeFieldEnd();
        a.offeredExperiments != null && (b.writeFieldBegin({
            fname: "offeredExperiments",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 5
        }), b.writeString(a.offeredExperiments), b.writeFieldEnd());
        a.isScheduledCall != null && (b.writeFieldBegin({
            fname: "isScheduledCall",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 6
        }), b.writeBool(a.isScheduledCall), b.writeFieldEnd());
        if (a.appMessages != null) {
            b.writeFieldBegin({
                fname: "appMessages",
                ftype: (h || (h = c("ThriftTypes"))).LIST,
                fid: 8
            });
            b.writeListBegin({
                etype: h.STRUCT,
                size: a.appMessages.length
            });
            for (g = a.appMessages, i = Array.isArray(g), e = 0, g = i ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (i) {
                    if (e >= g.length) break;
                    f = g[e++]
                } else {
                    e = g.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                d("DataMessageSerializers").serializeDataMessage(f, b)
            }
            b.writeListEnd();
            b.writeFieldEnd()
        }
        a.offer != null && (b.writeFieldBegin({
            fname: "offer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 10
        }), o(a.offer, b), b.writeFieldEnd());
        a.mediaStatusEx != null && (b.writeFieldBegin({
            fname: "mediaStatusEx",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 11
        }), d("MultiwaySharedSerializers").serializeClientMediaStatus(a.mediaStatusEx, b), b.writeFieldEnd());
        a.isPreconnectSupported != null && (b.writeFieldBegin({
            fname: "isPreconnectSupported",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 12
        }), b.writeBool(a.isPreconnectSupported), b.writeFieldEnd());
        a.sdpOriginLocalId != null && (b.writeFieldBegin({
            fname: "sdpOriginLocalId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 13
        }), b.writeString(a.sdpOriginLocalId), b.writeFieldEnd());
        a.unifiedOffer != null && (b.writeFieldBegin({
            fname: "unifiedOffer",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 14
        }), o(a.unifiedOffer, b), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "mediaPath",
            ftype: h.I32,
            fid: 15
        });
        if (a.mediaPath != null) {
            b.writeI32((f = a.mediaPath) != null ? f : 0)
        } else {
            e = d("MultiwaySharedTypes").MediaPath.cast(0);
            b.writeI32((i = e) != null ? i : 0)
        }
        b.writeFieldEnd();
        a.e2eeEnforcement != null && (b.writeFieldBegin({
            fname: "e2eeEnforcement",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 16
        }), d("MultiwaySharedSerializers").serializeE2eeEnforcement(a.e2eeEnforcement, b), b.writeFieldEnd());
        a.isLegacyCall != null && (b.writeFieldBegin({
            fname: "isLegacyCall",
            ftype: (h || (h = c("ThriftTypes"))).BOOL,
            fid: 17
        }), b.writeBool(a.isLegacyCall), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "isTransferCall",
            ftype: h.BOOL,
            fid: 18
        });
        if (a.isTransferCall != null) b.writeBool(a.isTransferCall);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        a.relayInfo != null && (b.writeFieldBegin({
            fname: "relayInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 20
        }), d("MultiwaySharedSerializers").serializeRelayInfo(a.relayInfo, b), b.writeFieldEnd());
        if (a.overlayConfigs != null) {
            b.writeFieldBegin({
                fname: "overlayConfigs",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 21
            });
            b.writeMapBegin({
                ktype: h.I32,
                vtype: h.I32,
                size: Object.keys(a.overlayConfigs).length
            });
            f = Object.entries(a.overlayConfigs);
            for (e = 0; e < f.length; e++) {
                i = f[e];
                g = i[0];
                i = i[1];
                b.writeI32(Number(g));
                b.writeI32(i)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.productMetadata != null && (b.writeFieldBegin({
            fname: "productMetadata",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 22
        }), bb(a.productMetadata, b), b.writeFieldEnd());
        a.callerClientSessionId != null && (b.writeFieldBegin({
            fname: "callerClientSessionId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 23
        }), b.writeString(a.callerClientSessionId), b.writeFieldEnd());
        a.threadIdInfo != null && (b.writeFieldBegin({
            fname: "threadIdInfo",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 24
        }), cb(a.threadIdInfo, b), b.writeFieldEnd());
        a.linkUrl != null && (b.writeFieldBegin({
            fname: "linkUrl",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 25
        }), b.writeString(a.linkUrl), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function U(a, b) {
        b.writeStructBegin("RingResponse");
        b.writeFieldBegin({
            fname: "deviceStatus",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        });
        if (a.deviceStatus != null) {
            b.writeI32((a = a.deviceStatus) != null ? a : 0)
        } else {
            a = d("MultiwayCommonTypes").DeviceStatus.cast(0);
            b.writeI32((a = a) != null ? a : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function V(a, b) {
        b.writeStructBegin("RemoveParticipantsRequest");
        b.writeFieldBegin({
            fname: "usersToRemove",
            ftype: (h || (h = c("ThriftTypes"))).SET,
            fid: 1
        });
        if (a.usersToRemove != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: a.usersToRemove.size
            });
            for (var a = a.usersToRemove, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                b.writeString(f)
            }
            b.writeSetEnd()
        } else {
            f = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: f.size
            });
            for (e = f, d = Array.isArray(e), a = 0, e = d ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (d) {
                    if (a >= e.length) break;
                    f = e[a++]
                } else {
                    a = e.next();
                    if (a.done) break;
                    f = a.value
                }
                f = f;
                b.writeString(f)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function W(a, b) {
        b.writeStructBegin("UnsubscribeRequest");
        b.writeFieldBegin({
            fname: "topic",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.topic != null) b.writeString(a.topic);
        else {
            var e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "version",
            ftype: h.I32,
            fid: 2
        });
        if (a.version != null) b.writeI32(a.version);
        else {
            e = 0;
            b.writeI32(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "topicId",
            ftype: h.I32,
            fid: 3
        });
        if (a.topicId != null) {
            b.writeI32((e = a.topicId) != null ? e : 0)
        } else {
            a = d("StateSyncTopicsConfigTypes").TopicId.cast(0);
            b.writeI32((e = a) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function X(a, b) {
        b.writeStructBegin("UnsubscribeResponse");
        b.writeFieldBegin({
            fname: "topic",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.topic != null) b.writeString(a.topic);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "version",
            ftype: h.I32,
            fid: 2
        });
        if (a.version != null) b.writeI32(a.version);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function db(a, b) {
        b.writeStructBegin("UpdateRequest");
        b.writeFieldBegin({
            fname: "syncPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        });
        if (a.syncPayload != null) t(a.syncPayload, b);
        else {
            var e = l();
            t(e, b)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "topic",
            ftype: h.STRING,
            fid: 2
        });
        if (a.topic != null) b.writeString(a.topic);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "version",
            ftype: h.I32,
            fid: 3
        });
        if (a.version != null) b.writeI32(a.version);
        else {
            e = 0;
            b.writeI32(e)
        }
        b.writeFieldEnd();
        a.data != null && (b.writeFieldBegin({
            fname: "data",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 4
        }), b.writeBinary(a.data), b.writeFieldEnd());
        b.writeFieldBegin({
            fname: "topicId",
            ftype: h.I32,
            fid: 5
        });
        if (a.topicId != null) {
            b.writeI32((e = a.topicId) != null ? e : 0)
        } else {
            a = d("StateSyncTopicsConfigTypes").TopicId.cast(0);
            b.writeI32((e = a) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function eb(a, b) {
        b.writeStructBegin("UpdateResponse");
        b.writeFieldBegin({
            fname: "topic",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        });
        if (a.topic != null) b.writeString(a.topic);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "version",
            ftype: h.I32,
            fid: 3
        });
        if (a.version != null) b.writeI32(a.version);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function fb(a, b) {
        b.writeStructBegin("NotifyRequest");
        b.writeFieldBegin({
            fname: "topic",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        });
        if (a.topic != null) b.writeString(a.topic);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "version",
            ftype: h.I32,
            fid: 3
        });
        if (a.version != null) b.writeI32(a.version);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "data",
            ftype: h.STRING,
            fid: 4
        });
        if (a.data != null) b.writeBinary(a.data);
        else {
            d = Uint8Array.of();
            b.writeBinary(d)
        }
        b.writeFieldEnd();
        a.syncPayload != null && (b.writeFieldBegin({
            fname: "syncPayload",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 5
        }), t(a.syncPayload, b), b.writeFieldEnd());
        if (a.topicId != null) {
            b.writeFieldBegin({
                fname: "topicId",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 6
            });
            b.writeI32((d = a.topicId) != null ? d : 0);
            b.writeFieldEnd()
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function gb(a, b) {
        b.writeStructBegin("NotifyResponse");
        b.writeFieldBegin({
            fname: "topic",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 2
        });
        if (a.topic != null) b.writeString(a.topic);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "version",
            ftype: h.I32,
            fid: 3
        });
        if (a.version != null) b.writeI32(a.version);
        else {
            d = 0;
            b.writeI32(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function hb(a, b) {
        b.writeStructBegin("ApprovalRequest");
        b.writeFieldBegin({
            fname: "approvalStatus",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 2
        });
        if (a.approvalStatus != null) {
            var e;
            b.writeI32((e = a.approvalStatus) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").ApprovalStatus.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "targetUsers",
            ftype: h.SET,
            fid: 3
        });
        if (a.targetUsers != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: a.targetUsers.size
            });
            for (var e = a.targetUsers, a = Array.isArray(e), f = 0, e = a ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (a) {
                    if (f >= e.length) break;
                    g = e[f++]
                } else {
                    f = e.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeSetEnd()
        } else {
            g = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: g.size
            });
            for (f = g, a = Array.isArray(f), e = 0, f = a ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (a) {
                    if (e >= f.length) break;
                    g = f[e++]
                } else {
                    e = f.next();
                    if (e.done) break;
                    g = e.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ib(a, b) {
        b.writeStructBegin("RtcSender");
        b.writeFieldBegin({
            fname: "id",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.id != null) b.writeString(a.id);
        else {
            a = "";
            b.writeString(a)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function jb(a, b) {
        b.writeStructBegin("RtcReceiver");
        b.writeFieldBegin({
            fname: "actorId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 1
        });
        if (a.actorId != null) b.writeString(a.actorId);
        else {
            var d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "baseId",
            ftype: h.STRING,
            fid: 2
        });
        if (a.baseId != null) b.writeString(a.baseId);
        else {
            d = "";
            b.writeString(d)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function kb(a, b) {
        b.writeStructBegin("RtcMessageHeader");
        b.writeFieldBegin({
            fname: "type",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 1
        });
        if (a.type != null) {
            var e;
            b.writeI32((e = a.type) != null ? e : 0)
        } else {
            e = d("MultiwayCommonTypes").MessageType.cast(0);
            b.writeI32((e = e) != null ? e : 0)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "conferenceName",
            ftype: h.STRING,
            fid: 2
        });
        if (a.conferenceName != null) b.writeString(a.conferenceName);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "transactionId",
            ftype: h.STRING,
            fid: 3
        });
        if (a.transactionId != null) b.writeString(a.transactionId);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "retryCount",
            ftype: h.I16,
            fid: 4
        });
        if (a.retryCount != null) b.writeI16(a.retryCount);
        else {
            e = 0;
            b.writeI16(e)
        }
        b.writeFieldEnd();
        a.serverInfoData != null && (b.writeFieldBegin({
            fname: "serverInfoData",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 5
        }), b.writeString(a.serverInfoData), b.writeFieldEnd());
        if (a.responseStatusCode != null) {
            b.writeFieldBegin({
                fname: "responseStatusCode",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 6
            });
            b.writeI32((e = a.responseStatusCode) != null ? e : 0);
            b.writeFieldEnd()
        }
        if (a.extensions != null) {
            b.writeFieldBegin({
                fname: "extensions",
                ftype: (h || (h = c("ThriftTypes"))).MAP,
                fid: 7
            });
            b.writeMapBegin({
                ktype: h.STRING,
                vtype: h.STRING,
                size: Object.keys(a.extensions).length
            });
            e = Object.entries(a.extensions);
            for (var f = 0; f < e.length; f++) {
                var g = e[f],
                    i = g[0];
                g = g[1];
                b.writeString(i);
                b.writeString(g)
            }
            b.writeMapEnd();
            b.writeFieldEnd()
        }
        a.sequenceNumber != null && (b.writeFieldBegin({
            fname: "sequenceNumber",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 8
        }), b.writeI64(BigInt(a.sequenceNumber)), b.writeFieldEnd());
        a.clientSessionId != null && (b.writeFieldBegin({
            fname: "clientSessionId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 9
        }), b.writeString(a.clientSessionId), b.writeFieldEnd());
        a.responseStatusMessage != null && (b.writeFieldBegin({
            fname: "responseStatusMessage",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 10
        }), b.writeString(a.responseStatusMessage), b.writeFieldEnd());
        if (a.responseSubCode != null) {
            b.writeFieldBegin({
                fname: "responseSubCode",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 11
            });
            b.writeI32((i = a.responseSubCode) != null ? i : 0);
            b.writeFieldEnd()
        }
        a.collisionKey != null && (b.writeFieldBegin({
            fname: "collisionKey",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 12
        }), b.writeString(a.collisionKey), b.writeFieldEnd());
        if (a.conferenceType != null) {
            b.writeFieldBegin({
                fname: "conferenceType",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 13
            });
            b.writeI32((g = a.conferenceType) != null ? g : 0);
            b.writeFieldEnd()
        }
        a.serverSessionId != null && (b.writeFieldBegin({
            fname: "serverSessionId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 14
        }), b.writeString(a.serverSessionId), b.writeFieldEnd());
        a.rtcHandle != null && (b.writeFieldBegin({
            fname: "rtcHandle",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 15
        }), b.writeString(a.rtcHandle), b.writeFieldEnd());
        a.retryAfterMsec != null && (b.writeFieldBegin({
            fname: "retryAfterMsec",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 16
        }), b.writeI32(a.retryAfterMsec), b.writeFieldEnd());
        a.receiverUserId != null && (b.writeFieldBegin({
            fname: "receiverUserId",
            ftype: (h || (h = c("ThriftTypes"))).STRING,
            fid: 17
        }), b.writeString(a.receiverUserId), b.writeFieldEnd());
        if (a.clientStack != null) {
            b.writeFieldBegin({
                fname: "clientStack",
                ftype: (h || (h = c("ThriftTypes"))).I32,
                fid: 18
            });
            b.writeI32((e = a.clientStack) != null ? e : 0);
            b.writeFieldEnd()
        }
        a.serverMsgTime != null && (b.writeFieldBegin({
            fname: "serverMsgTime",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 19
        }), b.writeI64(BigInt(a.serverMsgTime)), b.writeFieldEnd());
        a.sender != null && (b.writeFieldBegin({
            fname: "sender",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 20
        }), ib(a.sender, b), b.writeFieldEnd());
        a.receiver != null && (b.writeFieldBegin({
            fname: "receiver",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 21
        }), jb(a.receiver, b), b.writeFieldEnd());
        if (a.messageTags != null) {
            b.writeFieldBegin({
                fname: "messageTags",
                ftype: (h || (h = c("ThriftTypes"))).SET,
                fid: 22
            });
            b.writeSetBegin({
                etype: h.I32,
                size: a.messageTags.size
            });
            for (f = a.messageTags, i = Array.isArray(f), g = 0, f = i ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (i) {
                    if (g >= f.length) break;
                    e = f[g++]
                } else {
                    g = f.next();
                    if (g.done) break;
                    e = g.value
                }
                e = e;
                b.writeI32((e = e) != null ? e : 0)
            }
            b.writeSetEnd();
            b.writeFieldEnd()
        }
        a.conferenceId != null && (b.writeFieldBegin({
            fname: "conferenceId",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 23
        }), b.writeI64(BigInt(a.conferenceId)), b.writeFieldEnd());
        a.protocolVersion != null && (b.writeFieldBegin({
            fname: "protocolVersion",
            ftype: (h || (h = c("ThriftTypes"))).I32,
            fid: 24
        }), b.writeI32(a.protocolVersion), b.writeFieldEnd());
        a.bodyCompressionVersion != null && (b.writeFieldBegin({
            fname: "bodyCompressionVersion",
            ftype: (h || (h = c("ThriftTypes"))).I64,
            fid: 25
        }), b.writeI64(BigInt(a.bodyCompressionVersion)), b.writeFieldEnd());
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function lb(a, b) {
        b.writeStructBegin("RtcMessageBody"), a.joinRequest != null && (b.writeFieldBegin({
            fname: "joinRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        }), M(a.joinRequest, b), b.writeFieldEnd()), a.joinResponse != null && (b.writeFieldBegin({
            fname: "joinResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 2
        }), N(a.joinResponse, b), b.writeFieldEnd()), a.serverMediaUpdateRequest != null && (b.writeFieldBegin({
            fname: "serverMediaUpdateRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 3
        }), x(a.serverMediaUpdateRequest, b), b.writeFieldEnd()), a.serverMediaUpdateResponse != null && (b.writeFieldBegin({
            fname: "serverMediaUpdateResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 4
        }), y(a.serverMediaUpdateResponse, b), b.writeFieldEnd()), a.hangupRequest != null && (b.writeFieldBegin({
            fname: "hangupRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 5
        }), A(a.hangupRequest, b), b.writeFieldEnd()), a.iceCandidateRequest != null && (b.writeFieldBegin({
            fname: "iceCandidateRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 6
        }), B(a.iceCandidateRequest, b), b.writeFieldEnd()), a.ringRequest != null && (b.writeFieldBegin({
            fname: "ringRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 8
        }), T(a.ringRequest, b), b.writeFieldEnd()), a.ringResponse != null && (b.writeFieldBegin({
            fname: "ringResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 9
        }), U(a.ringResponse, b), b.writeFieldEnd()), a.dismissRequest != null && (b.writeFieldBegin({
            fname: "dismissRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 10
        }), C(a.dismissRequest, b), b.writeFieldEnd()), a.conferenceStateRequest != null && (b.writeFieldBegin({
            fname: "conferenceStateRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 11
        }), F(a.conferenceStateRequest, b), b.writeFieldEnd()), a.conferenceStateResponse != null && (b.writeFieldBegin({
            fname: "conferenceStateResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 12
        }), G(a.conferenceStateResponse, b), b.writeFieldEnd()), a.addParticipantsRequest != null && (b.writeFieldBegin({
            fname: "addParticipantsRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 13
        }), K(a.addParticipantsRequest, b), b.writeFieldEnd()), a.subscriptionRequest != null && (b.writeFieldBegin({
            fname: "subscriptionRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 14
        }), H(a.subscriptionRequest, b), b.writeFieldEnd()), a.clientMediaUpdateRequest != null && (b.writeFieldBegin({
            fname: "clientMediaUpdateRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 15
        }), v(a.clientMediaUpdateRequest, b), b.writeFieldEnd()), a.clientMediaUpdateResponse != null && (b.writeFieldBegin({
            fname: "clientMediaUpdateResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 16
        }), w(a.clientMediaUpdateResponse, b), b.writeFieldEnd()), a.dataMessageRequest != null && (b.writeFieldBegin({
            fname: "dataMessageRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 17
        }), I(a.dataMessageRequest, b), b.writeFieldEnd()), a.removeParticipantsRequest != null && (b.writeFieldBegin({
            fname: "removeParticipantsRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 18
        }), V(a.removeParticipantsRequest, b), b.writeFieldEnd()), a.dataMessageResponse != null && (b.writeFieldBegin({
            fname: "dataMessageResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 19
        }), J(a.dataMessageResponse, b), b.writeFieldEnd()), a.p2pMessageRequest != null && (b.writeFieldBegin({
            fname: "p2pMessageRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 29
        }), u(a.p2pMessageRequest, b), b.writeFieldEnd()), a.updateRequest != null && (b.writeFieldBegin({
            fname: "updateRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 30
        }), db(a.updateRequest, b), b.writeFieldEnd()), a.updateResponse != null && (b.writeFieldBegin({
            fname: "updateResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 31
        }), eb(a.updateResponse, b), b.writeFieldEnd()), a.notifyRequest != null && (b.writeFieldBegin({
            fname: "notifyRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 32
        }), fb(a.notifyRequest, b), b.writeFieldEnd()), a.notifyResponse != null && (b.writeFieldBegin({
            fname: "notifyResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 33
        }), gb(a.notifyResponse, b), b.writeFieldEnd()), a.connectRequest != null && (b.writeFieldBegin({
            fname: "connectRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 34
        }), O(a.connectRequest, b), b.writeFieldEnd()), a.connectResponse != null && (b.writeFieldBegin({
            fname: "connectResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 35
        }), P(a.connectResponse, b), b.writeFieldEnd()), a.clientEventRequest != null && (b.writeFieldBegin({
            fname: "clientEventRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 36
        }), R(a.clientEventRequest, b), b.writeFieldEnd()), a.clientEventResponse != null && (b.writeFieldBegin({
            fname: "clientEventResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 37
        }), S(a.clientEventResponse, b), b.writeFieldEnd()), a.unsubscribeRequest != null && (b.writeFieldBegin({
            fname: "unsubscribeRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 40
        }), W(a.unsubscribeRequest, b), b.writeFieldEnd()), a.unsubscribeResponse != null && (b.writeFieldBegin({
            fname: "unsubscribeResponse",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 41
        }), X(a.unsubscribeResponse, b), b.writeFieldEnd()), a.approvalRequest != null && (b.writeFieldBegin({
            fname: "approvalRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 42
        }), hb(a.approvalRequest, b), b.writeFieldEnd()), a.transferRequest != null && (b.writeFieldBegin({
            fname: "transferRequest",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 43
        }), z(a.transferRequest, b), b.writeFieldEnd()), b.writeFieldStop(), b.writeStructEnd()
    }

    function mb(a, b) {
        b.writeStructBegin("RtcMultiwayMessage");
        b.writeFieldBegin({
            fname: "messageHeader",
            ftype: (h || (h = c("ThriftTypes"))).STRUCT,
            fid: 1
        });
        if (a.messageHeader != null) kb(a.messageHeader, b);
        else {
            var d = m();
            kb(d, b)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "messageBody",
            ftype: h.STRUCT,
            fid: 2
        });
        if (a.messageBody != null) lb(a.messageBody, b);
        else {
            d = n();
            lb(d, b)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function Y(a, b) {
        b.writeStructBegin("GroupOfUsers");
        b.writeFieldBegin({
            fname: "users",
            ftype: (h || (h = c("ThriftTypes"))).SET,
            fid: 1
        });
        if (a.users != null) {
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: a.users.size
            });
            for (var d = a.users, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeSetEnd()
        } else {
            g = new Set();
            b.writeSetBegin({
                etype: (h || (h = c("ThriftTypes"))).STRING,
                size: g.size
            });
            for (f = g, e = Array.isArray(f), d = 0, f = e ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (e) {
                    if (d >= f.length) break;
                    g = f[d++]
                } else {
                    d = f.next();
                    if (d.done) break;
                    g = d.value
                }
                g = g;
                b.writeString(g)
            }
            b.writeSetEnd()
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "allowMultipleJoins",
            ftype: h.BOOL,
            fid: 2
        });
        if (a.allowMultipleJoins != null) b.writeBool(a.allowMultipleJoins);
        else {
            g = !1;
            b.writeBool(g)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "dismissOthersOnFirstJoin",
            ftype: h.BOOL,
            fid: 3
        });
        if (a.dismissOthersOnFirstJoin != null) b.writeBool(a.dismissOthersOnFirstJoin);
        else {
            d = !1;
            b.writeBool(d)
        }
        b.writeFieldEnd();
        b.writeFieldBegin({
            fname: "aliasId",
            ftype: h.STRING,
            fid: 4
        });
        if (a.aliasId != null) b.writeString(a.aliasId);
        else {
            e = "";
            b.writeString(e)
        }
        b.writeFieldEnd();
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function nb(a, b) {
        b.writeStructBegin("RtcMessageBodyVariant");
        if (a.joinRequest != null) {
            b.writeFieldBegin({
                fname: "joinRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 1
            });
            M(a.joinRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.joinResponse != null) {
            b.writeFieldBegin({
                fname: "joinResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 2
            });
            N(a.joinResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.serverMediaUpdateRequest != null) {
            b.writeFieldBegin({
                fname: "serverMediaUpdateRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 3
            });
            x(a.serverMediaUpdateRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.serverMediaUpdateResponse != null) {
            b.writeFieldBegin({
                fname: "serverMediaUpdateResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 4
            });
            y(a.serverMediaUpdateResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.hangupRequest != null) {
            b.writeFieldBegin({
                fname: "hangupRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 5
            });
            A(a.hangupRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.iceCandidateRequest != null) {
            b.writeFieldBegin({
                fname: "iceCandidateRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 6
            });
            B(a.iceCandidateRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.ringRequest != null) {
            b.writeFieldBegin({
                fname: "ringRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 8
            });
            T(a.ringRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.ringResponse != null) {
            b.writeFieldBegin({
                fname: "ringResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 9
            });
            U(a.ringResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.dismissRequest != null) {
            b.writeFieldBegin({
                fname: "dismissRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 10
            });
            C(a.dismissRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.conferenceStateRequest != null) {
            b.writeFieldBegin({
                fname: "conferenceStateRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 11
            });
            F(a.conferenceStateRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.conferenceStateResponse != null) {
            b.writeFieldBegin({
                fname: "conferenceStateResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 12
            });
            G(a.conferenceStateResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.addParticipantsRequest != null) {
            b.writeFieldBegin({
                fname: "addParticipantsRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 13
            });
            K(a.addParticipantsRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.subscriptionRequest != null) {
            b.writeFieldBegin({
                fname: "subscriptionRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 14
            });
            H(a.subscriptionRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.clientMediaUpdateRequest != null) {
            b.writeFieldBegin({
                fname: "clientMediaUpdateRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 15
            });
            v(a.clientMediaUpdateRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.clientMediaUpdateResponse != null) {
            b.writeFieldBegin({
                fname: "clientMediaUpdateResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 16
            });
            w(a.clientMediaUpdateResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.dataMessageRequest != null) {
            b.writeFieldBegin({
                fname: "dataMessageRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 17
            });
            I(a.dataMessageRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.removeParticipantsRequest != null) {
            b.writeFieldBegin({
                fname: "removeParticipantsRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 18
            });
            V(a.removeParticipantsRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.dataMessageResponse != null) {
            b.writeFieldBegin({
                fname: "dataMessageResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 19
            });
            J(a.dataMessageResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.p2pMessageRequest != null) {
            b.writeFieldBegin({
                fname: "p2pMessageRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 29
            });
            u(a.p2pMessageRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.updateRequest != null) {
            b.writeFieldBegin({
                fname: "updateRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 30
            });
            db(a.updateRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.updateResponse != null) {
            b.writeFieldBegin({
                fname: "updateResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 31
            });
            eb(a.updateResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.notifyRequest != null) {
            b.writeFieldBegin({
                fname: "notifyRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 32
            });
            fb(a.notifyRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.notifyResponse != null) {
            b.writeFieldBegin({
                fname: "notifyResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 33
            });
            gb(a.notifyResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.connectRequest != null) {
            b.writeFieldBegin({
                fname: "connectRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 34
            });
            O(a.connectRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.connectResponse != null) {
            b.writeFieldBegin({
                fname: "connectResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 35
            });
            P(a.connectResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.clientEventRequest != null) {
            b.writeFieldBegin({
                fname: "clientEventRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 36
            });
            R(a.clientEventRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.clientEventResponse != null) {
            b.writeFieldBegin({
                fname: "clientEventResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 37
            });
            S(a.clientEventResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.unsubscribeRequest != null) {
            b.writeFieldBegin({
                fname: "unsubscribeRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 40
            });
            W(a.unsubscribeRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.unsubscribeResponse != null) {
            b.writeFieldBegin({
                fname: "unsubscribeResponse",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 41
            });
            X(a.unsubscribeResponse, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.approvalRequest != null) {
            b.writeFieldBegin({
                fname: "approvalRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 42
            });
            hb(a.approvalRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        if (a.transferRequest != null) {
            b.writeFieldBegin({
                fname: "transferRequest",
                ftype: (h || (h = c("ThriftTypes"))).STRUCT,
                fid: 43
            });
            z(a.transferRequest, b);
            b.writeFieldEnd();
            b.writeFieldStop();
            b.writeStructEnd();
            return
        }
        b.writeFieldStop();
        b.writeStructEnd()
    }

    function ob(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.message = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.responseStatusCode = d("MultiwayCommonTypes").RtcResponseStatusCode.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.responseSubCode = d("MultiwayCommonTypes").RtcResponseSubCode.cast(a.readI32()) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.apiStatusCode = d("MultiwayCommonTypes").RtcApiStatusCode.cast(a.readI32()) : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.rtcLogSeverity = d("MultiwayCommonTypes").RtcLogSeverity.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.message === void 0 && (b.message = "");
        b.responseStatusCode === void 0 && (b.responseStatusCode = d("MultiwayCommonTypes").RtcResponseStatusCode.cast(0));
        b.responseSubCode === void 0 && (b.responseSubCode = d("MultiwayCommonTypes").RtcResponseSubCode.cast(0));
        b.apiStatusCode === void 0 && (b.apiStatusCode = d("MultiwayCommonTypes").RtcApiStatusCode.cast(0));
        b.rtcLogSeverity === void 0 && (b.rtcLogSeverity = d("MultiwayCommonTypes").RtcLogSeverity.cast(0));
        return b
    }

    function Z(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpString = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdpThrift = d("WebrtcSdpSerializers").deserializeSdp(a) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.sdpCompressionVersion = a.readI64().toString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpCompressedData = a.readBinary() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function pb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).MAP) {
                        b.media = {};
                        d = a.readMapBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readI32(),
                                i = qb(a);
                            b.media[g] = i
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.media === void 0 && (b.media = {});
        return b
    }

    function qb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.body = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.msid = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.mid = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.body === void 0 && (b.body = "");
        b.msid === void 0 && (b.msid = "");
        b.mid === void 0 && (b.mid = "");
        return b
    }

    function rb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sourceKey = a.readString() : a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.media = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("MultiwaySharedSerializers").deserializeMedia(a);
                            b.media.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.ssrcGroups = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = d("MultiwaySharedSerializers").deserializeSsrcGroup(a);
                            b.ssrcGroups.push(e)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.sourceKey === void 0 && (b.sourceKey = "");
        b.media === void 0 && (b.media = []);
        b.ssrcGroups === void 0 && (b.ssrcGroups = []);
        return b
    }

    function sb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.mediaStatus = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = a.readBool();
                            b.mediaStatus[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.mediaStatusEx = d("MultiwaySharedSerializers").deserializeClientMediaStatus(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.mediaStatus === void 0 && (b.mediaStatus = {});
        return b
    }

    function tb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.candidateSdpString = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.sdpMLineIndex = a.readI64().toString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpMid = a.readString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.candidateSdpThrift = d("WebrtcSdpSerializers").deserializeIceCandidateSdp(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.sdpMLineIndex === void 0 && (b.sdpMLineIndex = "0");
        b.sdpMid === void 0 && (b.sdpMid = "");
        return b
    }

    function $(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStore = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = d("StateSyncSerializers").deserializeState(a);
                            b.stateStore[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStoreV2 = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = d("StateSyncTopicsConfigTypes").TopicId.cast(a.readI32());
                            e = d("StateSyncSerializers").deserializeState(a);
                            g != null && (b.stateStoreV2[g] = e)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.stateStore === void 0 && (b.stateStore = {});
        b.stateStoreV2 === void 0 && (b.stateStoreV2 = {});
        return b
    }

    function ub(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.version = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.version === void 0 && (b.version = 0);
        return b
    }

    function vb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.encryptedTopic = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.encryptedData = a.readBinary() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.senderId = a.readBinary() : a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.targetIds = new Set();
                        e = a.readSetBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("Utf8ToString").Utf8ToString(a.readBinary());
                            b.targetIds.add(i)
                        }
                    } else a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.messageType = d("MultiwayCommonTypes").E2eeDataMessageType.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.encryptedTopic === void 0 && (b.encryptedTopic = "");
        b.encryptedData === void 0 && (b.encryptedData = Uint8Array.of());
        b.senderId === void 0 && (b.senderId = Uint8Array.of());
        b.messageType === void 0 && (b.messageType = d("MultiwayCommonTypes").E2eeDataMessageType.cast(0));
        return b
    }

    function wb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.header = d("WebrtcPayloadSerializers").deserializeWebrtcMessageHeader(a) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.payload = d("WebrtcPayloadSerializers").deserializeWebrtcMessagePayload(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.header === void 0 && (b.header = d("WebrtcPayloadSerializers").WebrtcMessageHeader$DefaultConstructor());
        b.payload === void 0 && (b.payload = d("WebrtcPayloadSerializers").WebrtcMessagePayload$DefaultConstructor());
        return b
    }

    function xb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.fromVersion = a.readI64().toString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.toVersion = a.readI64().toString() : a.skip(e);
                    break;
                case 3:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.mediaUpdates = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = sb(a);
                            b.mediaUpdates.push(g)
                        }
                    } else a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.offer = Z(a) : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.fromVersion === void 0 && (b.fromVersion = "0");
        b.toVersion === void 0 && (b.toVersion = "0");
        b.mediaUpdates === void 0 && (b.mediaUpdates = []);
        return b
    }

    function yb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.currentVersion = a.readI64().toString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.answer = Z(a) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.mediaStatus = d("MultiwaySharedSerializers").deserializeClientMediaStatus(a) : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpOriginLocalId = a.readString() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.renegotiationOffer = Z(a) : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(a.readI32()) : a.skip(f);
                    break;
                case 7:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStore = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = d("StateSyncSerializers").deserializeState(a);
                            b.stateStore[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 8:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStoreV2 = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = d("StateSyncTopicsConfigTypes").TopicId.cast(a.readI32());
                            e = d("StateSyncSerializers").deserializeState(a);
                            g != null && (b.stateStoreV2[g] = e)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.currentVersion === void 0 && (b.currentVersion = "0");
        b.mediaPath === void 0 && (b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(0));
        return b
    }

    function zb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.callerUserId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.calleeUserId = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.sessionId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.callerUserId === void 0 && (b.callerUserId = "");
        b.calleeUserId === void 0 && (b.calleeUserId = "");
        b.sessionId === void 0 && (b.sessionId = "");
        return b
    }

    function Ab(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.fromVersion = a.readI64().toString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.toVersion = a.readI64().toString() : a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.mediaUpdates = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = rb(a);
                            b.mediaUpdates.push(i)
                        }
                    } else a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.offer = Z(a) : a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.appMessages = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = d("DataMessageSerializers").deserializeDataMessage(a);
                            b.appMessages.push(e)
                        }
                    } else a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.answer = Z(a) : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.mediaStatus = d("MultiwaySharedSerializers").deserializeClientMediaStatus(a) : a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.renegotiationRequested = a.readBool() : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.prAnswer = Z(a) : a.skip(f);
                    break;
                case 10:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStore = {};
                        e = a.readMapBegin();
                        for (g = 0; g < e.size; g++) {
                            i = a.readString();
                            var j = d("StateSyncSerializers").deserializeState(a);
                            b.stateStore[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpOriginLocalId = a.readString() : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.multipleRelaysParameters = zb(a) : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.multipleVideoStreamsAllowed = a.readBool() : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.renegotiationOffer = Z(a) : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(a.readI32()) : a.skip(f);
                    break;
                case 16:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.update = pb(a) : a.skip(f);
                    break;
                case 17:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.screenShareStreamAllowed = a.readBool() : a.skip(f);
                    break;
                case 18:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStoreV2 = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = d("StateSyncTopicsConfigTypes").TopicId.cast(a.readI32());
                            e = d("StateSyncSerializers").deserializeState(a);
                            g != null && (b.stateStoreV2[g] = e)
                        }
                    } else a.skip(f);
                    break;
                case 19:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.allowedCustomVideoContentTypes = new Set();
                        g = a.readSetBegin();
                        for (e = 0; e < g.size; e++) {
                            j = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(a.readI32());
                            b.allowedCustomVideoContentTypes.add(j)
                        }
                    } else a.skip(f);
                    break;
                case 20:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.relayInfo = d("MultiwaySharedSerializers").deserializeRelayInfo(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.fromVersion === void 0 && (b.fromVersion = "0");
        b.toVersion === void 0 && (b.toVersion = "0");
        b.mediaUpdates === void 0 && (b.mediaUpdates = []);
        b.renegotiationRequested === void 0 && (b.renegotiationRequested = !1);
        b.multipleVideoStreamsAllowed === void 0 && (b.multipleVideoStreamsAllowed = !1);
        b.mediaPath === void 0 && (b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(0));
        b.screenShareStreamAllowed === void 0 && (b.screenShareStreamAllowed = !1);
        return b
    }

    function Bb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.currentVersion = a.readI64().toString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.answer = Z(a) : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.mediaStatus = d("MultiwaySharedSerializers").deserializeClientMediaStatus(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.currentVersion === void 0 && (b.currentVersion = "0");
        return b
    }

    function Cb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                default: a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Db(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.reason = d("MultiwayCommonTypes").HangupReason.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.detailedReasonString = a.readString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.reason === void 0 && (b.reason = d("MultiwayCommonTypes").HangupReason.cast(0));
        b.detailedReasonString === void 0 && (b.detailedReasonString = "");
        return b
    }

    function Eb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.iceCandidateSdps = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = tb(a);
                            b.iceCandidateSdps.push(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.iceCandidateSdps === void 0 && (b.iceCandidateSdps = []);
        return b
    }

    function Fb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.reason = d("MultiwayCommonTypes").DismissReason.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.detailedReasonString = a.readString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.callabilityResultErrorCode = a.readI64().toString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.reason === void 0 && (b.reason = d("MultiwayCommonTypes").DismissReason.cast(0));
        b.detailedReasonString === void 0 && (b.detailedReasonString = "");
        return b
    }

    function Gb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.joinMode = d("MultiwayCommonTypes").JoinMode.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.joinMode === void 0 && (b.joinMode = d("MultiwayCommonTypes").JoinMode.cast(0));
        return b
    }

    function Hb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.state = d("MultiwayCommonTypes").ParticipantCallState.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.userCapabilities = a.readBinary() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.sctpNodeId = a.readI64().toString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.state === void 0 && (b.state = d("MultiwayCommonTypes").ParticipantCallState.cast(0));
        return b
    }

    function Ib(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.userCountry = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Jb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.name = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.profilePictureUri = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.aliasId = a.readString() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.thirdPartyId = a.readString() : a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.groupId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Kb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.callerInfo = Jb(a) : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.liveBroadcastId = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.callingTags = a.readI32() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.backingIdentifier = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Lb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.version = a.readI64().toString() : a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.participantStates = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = Hb(a);
                            b.participantStates[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.userProfiles = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = a.readString();
                            e = Jb(a);
                            b.userProfiles[g] = e
                        }
                    } else a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.appMessages = [];
                        g = a.readListBegin();
                        for (e = 0; e < g.size; e++) {
                            j = d("DataMessageSerializers").deserializeDataMessage(a);
                            b.appMessages.push(j)
                        }
                    } else a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.groupsOfUsers = [];
                        i = a.readListBegin();
                        for (j = 0; j < i.size; j++) {
                            e = oc(a);
                            b.groupsOfUsers.push(e)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.version === void 0 && (b.version = "0");
        b.participantStates === void 0 && (b.participantStates = {});
        b.groupsOfUsers === void 0 && (b.groupsOfUsers = []);
        return b
    }

    function Mb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).I64 ? b.currentVersion = a.readI64().toString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.currentVersion === void 0 && (b.currentVersion = "0");
        return b
    }

    function Nb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.subscriptions = [];
                        e = a.readListBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("MultiwaySharedSerializers").deserializeSubscription(a);
                            b.subscriptions.push(i)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.subscriptions === void 0 && (b.subscriptions = []);
        return b
    }

    function Ob(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.message = d("DataMessageSerializers").deserializeDataMessage(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.message === void 0 && (b.message = d("DataMessageSerializers").DataMessage$DefaultConstructor());
        return b
    }

    function Pb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.deliveryResult = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = d("DataMessageTypes").DataMessageStatusCode.cast(a.readI32());
                            b.deliveryResult[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.serviceTypeDeliveryResult = {};
                        i = a.readMapBegin();
                        for (j = 0; j < i.size; j++) {
                            g = d("MultiwaySharedTypes").EndpointServiceType.cast(a.readI32());
                            e = d("DataMessageTypes").DataMessageStatusCode.cast(a.readI32());
                            g != null && (b.serviceTypeDeliveryResult[g] = e)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.deliveryResult === void 0 && (b.deliveryResult = {});
        return b
    }

    function Qb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.usersToInvite = new Set();
                        e = a.readSetBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString();
                            b.usersToInvite.add(i)
                        }
                    } else a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.appMessages = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = d("DataMessageSerializers").deserializeDataMessage(a);
                            b.appMessages.push(e)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.usersToInvite === void 0 && (b.usersToInvite = new Set());
        return b
    }

    function Rb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.smcTier = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.region = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.isUsfu = a.readBool() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.isEdge = a.readBool() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.smcTier === void 0 && (b.smcTier = "");
        b.region === void 0 && (b.region = "");
        b.isUsfu === void 0 && (b.isUsfu = !1);
        b.isEdge === void 0 && (b.isEdge = !1);
        return b
    }

    function Sb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.offer = Z(a) : a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.deviceCapabilities = new Set();
                        e = a.readSetBegin();
                        for (var g = 0; g < e.size; g++) {
                            var j = d("MultiwayCommonTypes").Capability.cast(a.readI32());
                            b.deviceCapabilities.add(j)
                        }
                    } else a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.usersToCall = new Set();
                        j = a.readSetBegin();
                        for (g = 0; g < j.size; g++) {
                            e = a.readString();
                            b.usersToCall.add(e)
                        }
                    } else a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.mediaStatus = {};
                        e = a.readMapBegin();
                        for (g = 0; g < e.size; g++) {
                            j = a.readString();
                            var k = a.readBool();
                            b.mediaStatus[j] = k
                        }
                    } else a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.userCapabilities = a.readBinary() : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.supportedExperiments = a.readString() : a.skip(f);
                    break;
                case 9:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.appMessages = [];
                        j = a.readListBegin();
                        for (k = 0; k < j.size; k++) {
                            g = d("DataMessageSerializers").deserializeDataMessage(a);
                            b.appMessages.push(g)
                        }
                    } else a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.userToEscalate = a.readString() : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.escalatingCallId = a.readI64().toString() : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.conferenceType = d("MultiwaySharedTypes").ConferenceType.cast(a.readI32()) : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.mediaStatusEx = d("MultiwaySharedSerializers").deserializeClientMediaStatus(a) : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.answer = Z(a) : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.syncPayload = $(a) : a.skip(f);
                    break;
                case 16:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.usersToApproveFromWaitingRoom = new Set();
                        e = a.readSetBegin();
                        for (g = 0; g < e.size; g++) {
                            k = a.readString();
                            b.usersToApproveFromWaitingRoom.add(k)
                        }
                    } else a.skip(f);
                    break;
                case 17:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.e2eeEnforcement = d("MultiwaySharedSerializers").deserializeE2eeEnforcement(a) : a.skip(f);
                    break;
                case 18:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sfuAllocation = Rb(a) : a.skip(f);
                    break;
                case 19:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.clientMediaMode = d("MultiwaySharedTypes").MediaPath.cast(a.readI32()) : a.skip(f);
                    break;
                case 20:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.endpointSettings = Gb(a) : a.skip(f);
                    break;
                case 21:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.backupSfuAllocation = Rb(a) : a.skip(f);
                    break;
                case 22:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.supportedCustomVideoContentTypes = new Set();
                        j = a.readSetBegin();
                        for (k = 0; k < j.size; k++) {
                            g = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(a.readI32());
                            b.supportedCustomVideoContentTypes.add(g)
                        }
                    } else a.skip(f);
                    break;
                case 23:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.configIntegrityOpaqueToken = a.readI32() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.offer === void 0 && (b.offer = i());
        b.deviceCapabilities === void 0 && (b.deviceCapabilities = new Set());
        return b
    }

    function Tb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.answer = Z(a) : a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.mediaStatus = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var j = a.readString(),
                                k = a.readBool();
                            b.mediaStatus[j] = k
                        }
                    } else a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.initiator = a.readString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.negotiatedExperiments = a.readString() : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.mediaStatusEx = d("MultiwaySharedSerializers").deserializeClientMediaStatus(a) : a.skip(f);
                    break;
                case 7:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.appMessages = [];
                        j = a.readListBegin();
                        for (k = 0; k < j.size; k++) {
                            g = d("DataMessageSerializers").deserializeDataMessage(a);
                            b.appMessages.push(g)
                        }
                    } else a.skip(f);
                    break;
                case 8:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStore = {};
                        e = a.readMapBegin();
                        for (g = 0; g < e.size; g++) {
                            k = a.readString();
                            j = d("StateSyncSerializers").deserializeState(a);
                            b.stateStore[k] = j
                        }
                    } else a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpOriginLocalId = a.readString() : a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.isPendingApproval = a.readBool() : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.renegotiationOffer = Z(a) : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.multipleVideoStreamsAllowed = a.readBool() : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(a.readI32()) : a.skip(f);
                    break;
                case 14:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.groupsOfUsers = [];
                        k = a.readListBegin();
                        for (j = 0; j < k.size; j++) {
                            g = oc(a);
                            b.groupsOfUsers.push(g)
                        }
                    } else a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.screenShareStreamAllowed = a.readBool() : a.skip(f);
                    break;
                case 16:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.relayInfo = d("MultiwaySharedSerializers").deserializeRelayInfo(a) : a.skip(f);
                    break;
                case 17:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.selfSctpNodeId = a.readI64().toString() : a.skip(f);
                    break;
                case 18:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.stateStoreV2 = {};
                        e = a.readMapBegin();
                        for (g = 0; g < e.size; g++) {
                            j = d("StateSyncTopicsConfigTypes").TopicId.cast(a.readI32());
                            k = d("StateSyncSerializers").deserializeState(a);
                            j != null && (b.stateStoreV2[j] = k)
                        }
                    } else a.skip(f);
                    break;
                case 19:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.allowedCustomVideoContentTypes = new Set();
                        j = a.readSetBegin();
                        for (k = 0; k < j.size; k++) {
                            g = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(a.readI32());
                            b.allowedCustomVideoContentTypes.add(g)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.answer === void 0 && (b.answer = i());
        b.mediaStatus === void 0 && (b.mediaStatus = {});
        b.initiator === void 0 && (b.initiator = "");
        b.isPendingApproval === void 0 && (b.isPendingApproval = !1);
        b.multipleVideoStreamsAllowed === void 0 && (b.multipleVideoStreamsAllowed = !1);
        b.mediaPath === void 0 && (b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(0));
        b.groupsOfUsers === void 0 && (b.groupsOfUsers = []);
        b.screenShareStreamAllowed === void 0 && (b.screenShareStreamAllowed = !1);
        return b
    }

    function Ub(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdp = Z(a) : a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.deviceCapabilities = new Set();
                        e = a.readSetBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = d("MultiwayCommonTypes").Capability.cast(a.readI32());
                            b.deviceCapabilities.add(i)
                        }
                    } else a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.supportedCustomVideoContentTypes = new Set();
                        i = a.readSetBegin();
                        for (g = 0; g < i.size; g++) {
                            e = d("WebrtcSignalingCommonTypes").CustomVideoContentType.cast(a.readI32());
                            b.supportedCustomVideoContentTypes.add(e)
                        }
                    } else a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.prOffer = Z(a) : a.skip(f);
                    break;
                case 7:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.e2eeEnforcement = d("MultiwaySharedSerializers").deserializeE2eeEnforcement(a) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.deviceCapabilities === void 0 && (b.deviceCapabilities = new Set());
        return b
    }

    function Vb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.sdp = Z(a) : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.sdpOriginLocalId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Wb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.type = d("MultiwayCommonTypes").ClientEventType.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.time = a.readI64().toString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.type === void 0 && (b.type = d("MultiwayCommonTypes").ClientEventType.cast(0));
        return b
    }

    function Xb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).LIST) {
                        b.clientEvents = [];
                        d = a.readListBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = Wb(a);
                            b.clientEvents.push(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.clientEvents === void 0 && (b.clientEvents = []);
        return b
    }

    function Yb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.groupThreadId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.peerId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function Zb(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                default: a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function $b(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.caller = a.readString() : a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.otherParticipants = new Set();
                        e = a.readSetBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString();
                            b.otherParticipants.add(i)
                        }
                    } else a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.ringType = d("MultiwayCommonTypes").RingType.cast(a.readI32()) : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.offeredExperiments = a.readString() : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.isScheduledCall = a.readBool() : a.skip(f);
                    break;
                case 8:
                    if (f === (h || (h = c("ThriftTypes"))).LIST) {
                        b.appMessages = [];
                        i = a.readListBegin();
                        for (g = 0; g < i.size; g++) {
                            e = d("DataMessageSerializers").deserializeDataMessage(a);
                            b.appMessages.push(e)
                        }
                    } else a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.offer = Z(a) : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.mediaStatusEx = d("MultiwaySharedSerializers").deserializeClientMediaStatus(a) : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.isPreconnectSupported = a.readBool() : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.sdpOriginLocalId = a.readString() : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.unifiedOffer = Z(a) : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(a.readI32()) : a.skip(f);
                    break;
                case 16:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.e2eeEnforcement = d("MultiwaySharedSerializers").deserializeE2eeEnforcement(a) : a.skip(f);
                    break;
                case 17:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.isLegacyCall = a.readBool() : a.skip(f);
                    break;
                case 18:
                    f === (h || (h = c("ThriftTypes"))).BOOL ? b.isTransferCall = a.readBool() : a.skip(f);
                    break;
                case 20:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.relayInfo = d("MultiwaySharedSerializers").deserializeRelayInfo(a) : a.skip(f);
                    break;
                case 21:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.overlayConfigs = {};
                        e = a.readMapBegin();
                        for (g = 0; g < e.size; g++) {
                            i = a.readI32();
                            var j = a.readI32();
                            b.overlayConfigs[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 22:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.productMetadata = Kb(a) : a.skip(f);
                    break;
                case 23:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.callerClientSessionId = a.readString() : a.skip(f);
                    break;
                case 24:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.threadIdInfo = Yb(a) : a.skip(f);
                    break;
                case 25:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.linkUrl = a.readString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.caller === void 0 && (b.caller = "");
        b.otherParticipants === void 0 && (b.otherParticipants = new Set());
        b.ringType === void 0 && (b.ringType = d("MultiwayCommonTypes").RingType.cast(0));
        b.mediaPath === void 0 && (b.mediaPath = d("MultiwaySharedTypes").MediaPath.cast(0));
        b.isTransferCall === void 0 && (b.isTransferCall = !1);
        return b
    }

    function ac(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.deviceStatus = d("MultiwayCommonTypes").DeviceStatus.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.deviceStatus === void 0 && (b.deviceStatus = d("MultiwayCommonTypes").DeviceStatus.cast(0));
        return b
    }

    function bc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).SET) {
                        b.usersToRemove = new Set();
                        d = a.readSetBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString();
                            b.usersToRemove.add(g)
                        }
                    } else a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.usersToRemove === void 0 && (b.usersToRemove = new Set());
        return b
    }

    function cc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.topic = a.readString() : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.version = a.readI32() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.topicId = d("StateSyncTopicsConfigTypes").TopicId.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.topic === void 0 && (b.topic = "");
        b.version === void 0 && (b.version = 0);
        b.topicId === void 0 && (b.topicId = d("StateSyncTopicsConfigTypes").TopicId.cast(0));
        return b
    }

    function dc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.topic = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.version = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.topic === void 0 && (b.topic = "");
        b.version === void 0 && (b.version = 0);
        return b
    }

    function ec(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.syncPayload = $(a) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.topic = a.readString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.version = a.readI32() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.data = a.readBinary() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.topicId = d("StateSyncTopicsConfigTypes").TopicId.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.syncPayload === void 0 && (b.syncPayload = l());
        b.topic === void 0 && (b.topic = "");
        b.version === void 0 && (b.version = 0);
        b.topicId === void 0 && (b.topicId = d("StateSyncTopicsConfigTypes").TopicId.cast(0));
        return b
    }

    function fc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.topic = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.version = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.topic === void 0 && (b.topic = "");
        b.version === void 0 && (b.version = 0);
        return b
    }

    function gc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.topic = a.readString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.version = a.readI32() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.data = a.readBinary() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.syncPayload = $(a) : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.topicId = d("StateSyncTopicsConfigTypes").TopicId.cast(a.readI32()) : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.topic === void 0 && (b.topic = "");
        b.version === void 0 && (b.version = 0);
        b.data === void 0 && (b.data = Uint8Array.of());
        return b
    }

    function hc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.topic = a.readString() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).I32 ? b.version = a.readI32() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.topic === void 0 && (b.topic = "");
        b.version === void 0 && (b.version = 0);
        return b
    }

    function ic(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 2:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.approvalStatus = d("MultiwayCommonTypes").ApprovalStatus.cast(a.readI32()) : a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.targetUsers = new Set();
                        e = a.readSetBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString();
                            b.targetUsers.add(i)
                        }
                    } else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.approvalStatus === void 0 && (b.approvalStatus = d("MultiwayCommonTypes").ApprovalStatus.cast(0));
        b.targetUsers === void 0 && (b.targetUsers = new Set());
        return b
    }

    function jc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.id = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.id === void 0 && (b.id = "");
        return b
    }

    function kc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.actorId = a.readString() : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.baseId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.actorId === void 0 && (b.actorId = "");
        b.baseId === void 0 && (b.baseId = "");
        return b
    }

    function lc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.type = d("MultiwayCommonTypes").MessageType.cast(a.readI32()) : a.skip(f);
                    break;
                case 2:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.conferenceName = a.readString() : a.skip(f);
                    break;
                case 3:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.transactionId = a.readString() : a.skip(f);
                    break;
                case 4:
                    f === (h || (h = c("ThriftTypes"))).I16 ? b.retryCount = a.readI16() : a.skip(f);
                    break;
                case 5:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.serverInfoData = a.readString() : a.skip(f);
                    break;
                case 6:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.responseStatusCode = d("MultiwayCommonTypes").RtcResponseStatusCode.cast(a.readI32()) : a.skip(f);
                    break;
                case 7:
                    if (f === (h || (h = c("ThriftTypes"))).MAP) {
                        b.extensions = {};
                        e = a.readMapBegin();
                        for (var g = 0; g < e.size; g++) {
                            var i = a.readString(),
                                j = a.readString();
                            b.extensions[i] = j
                        }
                    } else a.skip(f);
                    break;
                case 8:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.sequenceNumber = a.readI64().toString() : a.skip(f);
                    break;
                case 9:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.clientSessionId = a.readString() : a.skip(f);
                    break;
                case 10:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.responseStatusMessage = a.readString() : a.skip(f);
                    break;
                case 11:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.responseSubCode = d("MultiwayCommonTypes").RtcResponseSubCode.cast(a.readI32()) : a.skip(f);
                    break;
                case 12:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.collisionKey = a.readString() : a.skip(f);
                    break;
                case 13:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.conferenceType = d("MultiwaySharedTypes").ConferenceType.cast(a.readI32()) : a.skip(f);
                    break;
                case 14:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.serverSessionId = a.readString() : a.skip(f);
                    break;
                case 15:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.rtcHandle = a.readString() : a.skip(f);
                    break;
                case 16:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.retryAfterMsec = a.readI32() : a.skip(f);
                    break;
                case 17:
                    f === (h || (h = c("ThriftTypes"))).STRING ? b.receiverUserId = a.readString() : a.skip(f);
                    break;
                case 18:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.clientStack = d("WebrtcSignalingCommonTypes").ClientStack.cast(a.readI32()) : a.skip(f);
                    break;
                case 19:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.serverMsgTime = a.readI64().toString() : a.skip(f);
                    break;
                case 20:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.sender = jc(a) : a.skip(f);
                    break;
                case 21:
                    f === (h || (h = c("ThriftTypes"))).STRUCT ? b.receiver = kc(a) : a.skip(f);
                    break;
                case 22:
                    if (f === (h || (h = c("ThriftTypes"))).SET) {
                        b.messageTags = new Set();
                        i = a.readSetBegin();
                        for (j = 0; j < i.size; j++) {
                            g = d("MultiwayCommonTypes").MessageTag.cast(a.readI32());
                            b.messageTags.add(g)
                        }
                    } else a.skip(f);
                    break;
                case 23:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.conferenceId = a.readI64().toString() : a.skip(f);
                    break;
                case 24:
                    f === (h || (h = c("ThriftTypes"))).I32 ? b.protocolVersion = a.readI32() : a.skip(f);
                    break;
                case 25:
                    f === (h || (h = c("ThriftTypes"))).I64 ? b.bodyCompressionVersion = a.readI64().toString() : a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.type === void 0 && (b.type = d("MultiwayCommonTypes").MessageType.cast(0));
        b.conferenceName === void 0 && (b.conferenceName = "");
        b.transactionId === void 0 && (b.transactionId = "");
        b.retryCount === void 0 && (b.retryCount = 0);
        return b
    }

    function mc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.joinRequest = Sb(a) : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.joinResponse = Tb(a) : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.serverMediaUpdateRequest = Ab(a) : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.serverMediaUpdateResponse = Bb(a) : a.skip(e);
                    break;
                case 5:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.hangupRequest = Db(a) : a.skip(e);
                    break;
                case 6:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.iceCandidateRequest = Eb(a) : a.skip(e);
                    break;
                case 8:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.ringRequest = $b(a) : a.skip(e);
                    break;
                case 9:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.ringResponse = ac(a) : a.skip(e);
                    break;
                case 10:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.dismissRequest = Fb(a) : a.skip(e);
                    break;
                case 11:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.conferenceStateRequest = Lb(a) : a.skip(e);
                    break;
                case 12:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.conferenceStateResponse = Mb(a) : a.skip(e);
                    break;
                case 13:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.addParticipantsRequest = Qb(a) : a.skip(e);
                    break;
                case 14:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.subscriptionRequest = Nb(a) : a.skip(e);
                    break;
                case 15:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.clientMediaUpdateRequest = xb(a) : a.skip(e);
                    break;
                case 16:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.clientMediaUpdateResponse = yb(a) : a.skip(e);
                    break;
                case 17:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.dataMessageRequest = Ob(a) : a.skip(e);
                    break;
                case 18:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.removeParticipantsRequest = bc(a) : a.skip(e);
                    break;
                case 19:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.dataMessageResponse = Pb(a) : a.skip(e);
                    break;
                case 29:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.p2pMessageRequest = wb(a) : a.skip(e);
                    break;
                case 30:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.updateRequest = ec(a) : a.skip(e);
                    break;
                case 31:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.updateResponse = fc(a) : a.skip(e);
                    break;
                case 32:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.notifyRequest = gc(a) : a.skip(e);
                    break;
                case 33:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.notifyResponse = hc(a) : a.skip(e);
                    break;
                case 34:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.connectRequest = Ub(a) : a.skip(e);
                    break;
                case 35:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.connectResponse = Vb(a) : a.skip(e);
                    break;
                case 36:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.clientEventRequest = Xb(a) : a.skip(e);
                    break;
                case 37:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.clientEventResponse = Zb(a) : a.skip(e);
                    break;
                case 40:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.unsubscribeRequest = cc(a) : a.skip(e);
                    break;
                case 41:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.unsubscribeResponse = dc(a) : a.skip(e);
                    break;
                case 42:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.approvalRequest = ic(a) : a.skip(e);
                    break;
                case 43:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.transferRequest = Cb(a) : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return b
    }

    function nc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.messageHeader = lc(a) : a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).STRUCT ? b.messageBody = mc(a) : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.messageHeader === void 0 && (b.messageHeader = m());
        b.messageBody === void 0 && (b.messageBody = n());
        return b
    }

    function oc(a) {
        var b = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (d) {
                case 1:
                    if (e === (h || (h = c("ThriftTypes"))).SET) {
                        b.users = new Set();
                        d = a.readSetBegin();
                        for (var f = 0; f < d.size; f++) {
                            var g = a.readString();
                            b.users.add(g)
                        }
                    } else a.skip(e);
                    break;
                case 2:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.allowMultipleJoins = a.readBool() : a.skip(e);
                    break;
                case 3:
                    e === (h || (h = c("ThriftTypes"))).BOOL ? b.dismissOthersOnFirstJoin = a.readBool() : a.skip(e);
                    break;
                case 4:
                    e === (h || (h = c("ThriftTypes"))).STRING ? b.aliasId = a.readString() : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        b.users === void 0 && (b.users = new Set());
        b.allowMultipleJoins === void 0 && (b.allowMultipleJoins = !1);
        b.dismissOthersOnFirstJoin === void 0 && (b.dismissOthersOnFirstJoin = !1);
        b.aliasId === void 0 && (b.aliasId = "");
        return b
    }

    function pc(a) {
        var b, d = {};
        a.readStructBegin();
        while (!0) {
            var e = a.readFieldBegin(),
                f = e.ftype;
            e = e.fid;
            if (f === (h || (h = c("ThriftTypes"))).STOP) break;
            switch (e) {
                case 1:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.joinRequest = Sb(a), b = "joinRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: joinRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 2:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.joinResponse = Tb(a), b = "joinResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: joinResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 3:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.serverMediaUpdateRequest = Ab(a), b = "serverMediaUpdateRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: serverMediaUpdateRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 4:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.serverMediaUpdateResponse = Bb(a), b = "serverMediaUpdateResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: serverMediaUpdateResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 5:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.hangupRequest = Db(a), b = "hangupRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: hangupRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 6:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.iceCandidateRequest = Eb(a), b = "iceCandidateRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: iceCandidateRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 8:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.ringRequest = $b(a), b = "ringRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: ringRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 9:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.ringResponse = ac(a), b = "ringResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: ringResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 10:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.dismissRequest = Fb(a), b = "dismissRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: dismissRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 11:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.conferenceStateRequest = Lb(a), b = "conferenceStateRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: conferenceStateRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 12:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.conferenceStateResponse = Mb(a), b = "conferenceStateResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: conferenceStateResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 13:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.addParticipantsRequest = Qb(a), b = "addParticipantsRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: addParticipantsRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 14:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.subscriptionRequest = Nb(a), b = "subscriptionRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: subscriptionRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 15:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.clientMediaUpdateRequest = xb(a), b = "clientMediaUpdateRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: clientMediaUpdateRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 16:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.clientMediaUpdateResponse = yb(a), b = "clientMediaUpdateResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: clientMediaUpdateResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 17:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.dataMessageRequest = Ob(a), b = "dataMessageRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: dataMessageRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 18:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.removeParticipantsRequest = bc(a), b = "removeParticipantsRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: removeParticipantsRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 19:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.dataMessageResponse = Pb(a), b = "dataMessageResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: dataMessageResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 29:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.p2pMessageRequest = wb(a), b = "p2pMessageRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: p2pMessageRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 30:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.updateRequest = ec(a), b = "updateRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: updateRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 31:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.updateResponse = fc(a), b = "updateResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: updateResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 32:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.notifyRequest = gc(a), b = "notifyRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: notifyRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 33:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.notifyResponse = hc(a), b = "notifyResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: notifyResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 34:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.connectRequest = Ub(a), b = "connectRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: connectRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 35:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.connectResponse = Vb(a), b = "connectResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: connectResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 36:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.clientEventRequest = Xb(a), b = "clientEventRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: clientEventRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 37:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.clientEventResponse = Zb(a), b = "clientEventResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: clientEventResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 40:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.unsubscribeRequest = cc(a), b = "unsubscribeRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: unsubscribeRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 41:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.unsubscribeResponse = dc(a), b = "unsubscribeResponse";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: unsubscribeResponse, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 42:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.approvalRequest = ic(a), b = "approvalRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: approvalRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                case 43:
                    if (f === (h || (h = c("ThriftTypes"))).STRUCT)
                        if (b == null) d.transferRequest = Cb(a), b = "transferRequest";
                        else throw new Error("more than one field have been deserialized in union type: RtcMessageBodyVariant; current field: transferRequest, previous deserialized field: " + b);
                    else a.skip(f);
                    break;
                default:
                    a.skip(f)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        return d
    }
    g.RtcException$DefaultConstructor = a;
    g.SessionDescription$DefaultConstructor = i;
    g.SessionDescriptionUpdate$DefaultConstructor = b;
    g.MediaDescriptionUpdate$DefaultConstructor = e;
    g.ServerMediaUpdate$DefaultConstructor = f;
    g.ClientMediaUpdate$DefaultConstructor = j;
    g.IceCandidate$DefaultConstructor = k;
    g.SyncPayload$DefaultConstructor = l;
    g.SyncAck$DefaultConstructor = aa;
    g.E2eeData$DefaultConstructor = ba;
    g.P2PMessageRequest$DefaultConstructor = ca;
    g.ClientMediaUpdateRequest$DefaultConstructor = da;
    g.ClientMediaUpdateResponse$DefaultConstructor = ea;
    g.MultipleRelaysAllocationParameters$DefaultConstructor = fa;
    g.ServerMediaUpdateRequest$DefaultConstructor = ga;
    g.ServerMediaUpdateResponse$DefaultConstructor = ha;
    g.TransferRequest$DefaultConstructor = ia;
    g.HangupRequest$DefaultConstructor = ja;
    g.IceCandidateRequest$DefaultConstructor = ka;
    g.DismissRequest$DefaultConstructor = la;
    g.EndpointSettings$DefaultConstructor = ma;
    g.ParticipantState$DefaultConstructor = na;
    g.ServerOnlyParticipantState$DefaultConstructor = oa;
    g.UserProfile$DefaultConstructor = pa;
    g.ProductMetadata$DefaultConstructor = qa;
    g.ConferenceStateRequest$DefaultConstructor = ra;
    g.ConferenceStateResponse$DefaultConstructor = sa;
    g.SubscriptionRequest$DefaultConstructor = ta;
    g.DataMessageRequest$DefaultConstructor = ua;
    g.DataMessageResponse$DefaultConstructor = va;
    g.AddParticipantsRequest$DefaultConstructor = wa;
    g.SfuAllocation$DefaultConstructor = xa;
    g.JoinRequest$DefaultConstructor = ya;
    g.JoinResponse$DefaultConstructor = za;
    g.ConnectRequest$DefaultConstructor = Aa;
    g.ConnectResponse$DefaultConstructor = Ba;
    g.ClientEvent$DefaultConstructor = Ca;
    g.ClientEventRequest$DefaultConstructor = Da;
    g.ThreadIdInfo$DefaultConstructor = Ea;
    g.ClientEventResponse$DefaultConstructor = Fa;
    g.RingRequest$DefaultConstructor = Ga;
    g.RingResponse$DefaultConstructor = Ha;
    g.RemoveParticipantsRequest$DefaultConstructor = Ia;
    g.UnsubscribeRequest$DefaultConstructor = Ja;
    g.UnsubscribeResponse$DefaultConstructor = Ka;
    g.UpdateRequest$DefaultConstructor = La;
    g.UpdateResponse$DefaultConstructor = Ma;
    g.NotifyRequest$DefaultConstructor = Na;
    g.NotifyResponse$DefaultConstructor = Oa;
    g.ApprovalRequest$DefaultConstructor = Pa;
    g.RtcSender$DefaultConstructor = Qa;
    g.RtcReceiver$DefaultConstructor = Ra;
    g.RtcMessageHeader$DefaultConstructor = m;
    g.RtcMessageBody$DefaultConstructor = n;
    g.RtcMultiwayMessage$DefaultConstructor = Sa;
    g.GroupOfUsers$DefaultConstructor = Ta;
    g.RtcMessageBodyVariant$DefaultConstructor = Ua;
    g.serializeRtcException = Va;
    g.serializeSessionDescription = o;
    g.serializeSessionDescriptionUpdate = Wa;
    g.serializeMediaDescriptionUpdate = p;
    g.serializeServerMediaUpdate = q;
    g.serializeClientMediaUpdate = r;
    g.serializeIceCandidate = s;
    g.serializeSyncPayload = t;
    g.serializeSyncAck = Xa;
    g.serializeE2eeData = Ya;
    g.serializeP2PMessageRequest = u;
    g.serializeClientMediaUpdateRequest = v;
    g.serializeClientMediaUpdateResponse = w;
    g.serializeMultipleRelaysAllocationParameters = Za;
    g.serializeServerMediaUpdateRequest = x;
    g.serializeServerMediaUpdateResponse = y;
    g.serializeTransferRequest = z;
    g.serializeHangupRequest = A;
    g.serializeIceCandidateRequest = B;
    g.serializeDismissRequest = C;
    g.serializeEndpointSettings = $a;
    g.serializeParticipantState = D;
    g.serializeServerOnlyParticipantState = ab;
    g.serializeUserProfile = E;
    g.serializeProductMetadata = bb;
    g.serializeConferenceStateRequest = F;
    g.serializeConferenceStateResponse = G;
    g.serializeSubscriptionRequest = H;
    g.serializeDataMessageRequest = I;
    g.serializeDataMessageResponse = J;
    g.serializeAddParticipantsRequest = K;
    g.serializeSfuAllocation = L;
    g.serializeJoinRequest = M;
    g.serializeJoinResponse = N;
    g.serializeConnectRequest = O;
    g.serializeConnectResponse = P;
    g.serializeClientEvent = Q;
    g.serializeClientEventRequest = R;
    g.serializeThreadIdInfo = cb;
    g.serializeClientEventResponse = S;
    g.serializeRingRequest = T;
    g.serializeRingResponse = U;
    g.serializeRemoveParticipantsRequest = V;
    g.serializeUnsubscribeRequest = W;
    g.serializeUnsubscribeResponse = X;
    g.serializeUpdateRequest = db;
    g.serializeUpdateResponse = eb;
    g.serializeNotifyRequest = fb;
    g.serializeNotifyResponse = gb;
    g.serializeApprovalRequest = hb;
    g.serializeRtcSender = ib;
    g.serializeRtcReceiver = jb;
    g.serializeRtcMessageHeader = kb;
    g.serializeRtcMessageBody = lb;
    g.serializeRtcMultiwayMessage = mb;
    g.serializeGroupOfUsers = Y;
    g.serializeRtcMessageBodyVariant = nb;
    g.deserializeRtcException = ob;
    g.deserializeSessionDescription = Z;
    g.deserializeSessionDescriptionUpdate = pb;
    g.deserializeMediaDescriptionUpdate = qb;
    g.deserializeServerMediaUpdate = rb;
    g.deserializeClientMediaUpdate = sb;
    g.deserializeIceCandidate = tb;
    g.deserializeSyncPayload = $;
    g.deserializeSyncAck = ub;
    g.deserializeE2eeData = vb;
    g.deserializeP2PMessageRequest = wb;
    g.deserializeClientMediaUpdateRequest = xb;
    g.deserializeClientMediaUpdateResponse = yb;
    g.deserializeMultipleRelaysAllocationParameters = zb;
    g.deserializeServerMediaUpdateRequest = Ab;
    g.deserializeServerMediaUpdateResponse = Bb;
    g.deserializeTransferRequest = Cb;
    g.deserializeHangupRequest = Db;
    g.deserializeIceCandidateRequest = Eb;
    g.deserializeDismissRequest = Fb;
    g.deserializeEndpointSettings = Gb;
    g.deserializeParticipantState = Hb;
    g.deserializeServerOnlyParticipantState = Ib;
    g.deserializeUserProfile = Jb;
    g.deserializeProductMetadata = Kb;
    g.deserializeConferenceStateRequest = Lb;
    g.deserializeConferenceStateResponse = Mb;
    g.deserializeSubscriptionRequest = Nb;
    g.deserializeDataMessageRequest = Ob;
    g.deserializeDataMessageResponse = Pb;
    g.deserializeAddParticipantsRequest = Qb;
    g.deserializeSfuAllocation = Rb;
    g.deserializeJoinRequest = Sb;
    g.deserializeJoinResponse = Tb;
    g.deserializeConnectRequest = Ub;
    g.deserializeConnectResponse = Vb;
    g.deserializeClientEvent = Wb;
    g.deserializeClientEventRequest = Xb;
    g.deserializeThreadIdInfo = Yb;
    g.deserializeClientEventResponse = Zb;
    g.deserializeRingRequest = $b;
    g.deserializeRingResponse = ac;
    g.deserializeRemoveParticipantsRequest = bc;
    g.deserializeUnsubscribeRequest = cc;
    g.deserializeUnsubscribeResponse = dc;
    g.deserializeUpdateRequest = ec;
    g.deserializeUpdateResponse = fc;
    g.deserializeNotifyRequest = gc;
    g.deserializeNotifyResponse = hc;
    g.deserializeApprovalRequest = ic;
    g.deserializeRtcSender = jc;
    g.deserializeRtcReceiver = kc;
    g.deserializeRtcMessageHeader = lc;
    g.deserializeRtcMessageBody = mc;
    g.deserializeRtcMultiwayMessage = nc;
    g.deserializeGroupOfUsers = oc;
    g.deserializeRtcMessageBodyVariant = pc
}), 98);
__d("OverlayConfigConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        OverlayConfigNumParameters: 4640,
        OverlayConfigNotPresentFlagValue: -1
    };
    b = a;
    f["default"] = b
}), 66);
__d("OverlayConfigLayerSource", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = Object.freeze({
        UNKNOWN: 0,
        DEFAULT: 1,
        MOBILECONFIG: 2,
        APP_CRUCIBLE: 3,
        APP_JNI: 4,
        UNITTEST_CONFIG: 5,
        SERVER: 6,
        PLACEHOLDER: 7,
        LS_MOBILECONFIG: 8,
        APP_LS: 9,
        APP_JS: 10,
        BROWSER: 11,
        APP_OVRRTC: 12,
        APP_IG: 13,
        MLITE4A_LEGACY_QE: 14,
        APP_MLITE4A: 15,
        APP_PORTAL: 16,
        IG_LAUNCHER: 17,
        APP_ARCHON: 18,
        APP_WS: 19,
        APP_NOX: 20,
        APP_WEARABLE_MSNGR: 21,
        APP_WEARABLE_IG: 22,
        APP_ORCA_RSYS: 23,
        APP_WILDE: 24,
        APP_MKIOS: 25,
        APP_MK4A: 26,
        DYNAMIC: 27,
        SDK_DEFAULT: 28,
        APP_FB4A: 29,
        APP_RSYS_SDK_SAMPLE: 30,
        APP_BIZAPP: 31,
        APP_WORKCHAT: 32,
        APP_ARCHON_LOCAL_OVERRIDES: 33,
        APP_CATHODE: 34,
        APP_WR4I: 35,
        APP_WR4A: 36,
        APP_METACAM: 37,
        HORIZON_EMERGENCY: 38,
        APP_SOCIALPLATFORM: 39,
        APP_TWILIGHT: 40,
        APP_AR_CALLING_LOCAL_OVERRIDES: 41,
        APP_TWILIGHT_CASTING: 42,
        TWILIGHT_EMERGENCY: 43,
        METACAM_EMERGENCY: 44,
        CALL_SCOPED: 45
    });
    b = a;
    f["default"] = b
}), 66);
__d("OverlayConfigServerLayer", ["OverlayConfigConstants", "OverlayConfigLayerSource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        a.createFromHeader = function(b) {
            try {
                b = b == null ? void 0 : (b = b.extensions) == null ? void 0 : b.oc1_json;
                if (b == null) return null;
                b = JSON.parse(b);
                b = b == null ? void 0 : b.values;
                return b == null ? null : new a(b)
            } catch (a) {
                return null
            }
        };

        function a(a) {
            this.$1 = a
        }
        var b = a.prototype;
        b.getLayerSource = function() {
            return c("OverlayConfigLayerSource").SERVER
        };
        b.getValue = function(a) {
            a = this.$1[String(a)];
            return a != null ? a : c("OverlayConfigConstants").OverlayConfigNotPresentFlagValue
        };
        b.logExposure = function(a) {};
        return a
    }();
    g["default"] = a
}), 98);
__d("ZenonIceStatsParser", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.split("\r\n");
        a.forEach(function(a) {
            g(a) && b.push({
                gen: h(a),
                type: i(a)
            })
        });
        return b
    }

    function g(a) {
        return a.indexOf("candidate:") > -1
    }

    function h(a) {
        var b = 0;
        a = a.match(/generation (\d+)/);
        a && (b = parseInt(a[1], 10));
        return b
    }

    function i(a) {
        a = a.match(/typ (host|relay|srflx|prflx)/);
        if (a) return a[1];
        else return "unknown"
    }
    f.extractIceInfo = a
}), 66);
__d("ZenonEndCallReason", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        BREAKOUT_SESSION_SWITCH_ROOM: "BreakoutSessionSwitchRoom",
        CALL_END_ACCEPT_AFTER_HANG_UP: "CallEndAcceptAfterHangUp",
        CALLER_NOT_VISIBLE: "CallerNotVisible",
        CAMERA_PERMISSION_DENIED: "CameraPermissionDenied",
        CARRIER_BLOCKED: "CarrierBlocked",
        CLIENT_ENCRYPTION_ERROR: "ClientEncryptionError",
        CLIENT_ERROR: "ClientError",
        CLIENT_INTERRUPTED: "ClientInterrupted",
        CONNECTION_DROPPED: "ConnectionDropped",
        END_TO_END_ENCRYPTION_INVARIANT_VIOLATED: "EndToEndEncryptionInvariantViolated",
        HANGUP_CALL: "HangupCall",
        IGNORE_CALL: "IgnoreCall",
        IN_ANOTHER_CALL: "InAnotherCall",
        INACTIVE_TIMEOUT: "InactiveTimeout",
        INCOMING_TIMEOUT: "IncomingTimeout",
        MAX_ALLOWED_PARTICIPANTS_REACHED: "MaxAllowedParticipantsReached",
        MICROPHONE_PERMISSION_DENIED: "MicrophonePermissionDenied",
        NO_ANSWER_TIMEOUT: "NoAnswerTimeout",
        NO_PERMISSION: "NoPermission",
        NO_UI_SHOWN: "NoUIShown",
        OTHER_CARRIER_BLOCKED: "OtherCarrierBlocked",
        OTHER_INSTANCE_HANDLED: "OtherInstanceHandled",
        OTHER_NOT_CAPABLE: "OtherNotCapable",
        PRODUCT_SERVER_DEFINED_END_REASON: "ProductServerDefinedEndReason",
        REMOVED_BY_PARTICIPANT: "RemovedByParticipant",
        RING_MUTED: "RingMuted",
        SESSION_MIGRATED: "SessionMigrated",
        SIGNALING_MESSAGE_FAILED: "SignalingMessageFailed",
        TX_ACK_TIMEOUT: "TxAckTimeout",
        UNEXPECTED_END_OF_CALL: "UnexpectedEndOfCall",
        UNKNOWN: "Unknown",
        VERSION_UNSUPPORTED: "VersionUnsupported",
        WEBRTC_ERROR: "WebRTCError"
    });
    c = a;
    f["default"] = c
}), 66);
__d("ZenonIncomingRingSDKTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["Hangup", "OtherDismiss"]);
    f.ZenonCancelReason = a
}), 66);
__d("ZenonMediaError", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["ConnectionClosed", "IceDisconnected", "IceFailure", "SetLocalSdpFailed", "SetRemoteSdpFailed", "RollbackSdpFailed", "UnknownError"]);
    f.ZenonMediaError = a
}), 66);
__d("ZenonDismissReason", ["$InternalEnum", "FBLogger", "ZenonIncomingRingSDKTypes", "ZenonMWMessageTypes", "ZenonMediaError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = b("$InternalEnum")({
        IgnoreCall: 0,
        HangupCall: 1,
        InAnotherCall: 2,
        AcceptAfterHangUp: 3,
        NoAnswerTimeout: 4,
        IncomingTimeout: 5,
        OtherInstanceHandled: 6,
        SignalingMessageFailed: 7,
        ConnectionDropped: 8,
        ClientInterrupted: 9,
        WebRTCError: 10,
        ClientError: 11,
        NoPermission: 12,
        OtherNotCapable: 13,
        NoUIShown: 14,
        VersionUnsupported: 15,
        CallerNotVisible: 16,
        CarrierBlocked: 17,
        OtherCarrierBlocked: 18,
        ClientEncryptionError: 19,
        MicrophonePermissionDenied: 20,
        CameraPermissionDenied: 21,
        SessionMigrated: 22,
        RingMuted: 23,
        JoinApprovalDenied: 24,
        RejectedByCallee: 25,
        CallEndedByProduct: 26,
        CallEnded: 27,
        AnsweredOnAnotherDevice: 28,
        RejectedOnAnotherDevice: 29,
        CallCollision: 30,
        MaxAllowedParticipantsReached: 31,
        UnexpectedEndOfCall: 32,
        TxAckTimeout: 33,
        EndToEndEncryptionInvariantViolated: 34,
        ProductServerDefinedEndReason: 35,
        RemovedByParticipant: 39,
        AnsweredByOtherUser: 40
    });

    function a(a) {
        switch (a) {
            case "BreakoutSessionSwitchRoom":
                return i.HangupCall;
            case "CallEndAcceptAfterHangUp":
                return i.AcceptAfterHangUp;
            case "CallerNotVisible":
                return i.CallerNotVisible;
            case "CarrierBlocked":
                return i.CarrierBlocked;
            case "ClientEncryptionError":
                return i.ClientEncryptionError;
            case "ClientError":
                return i.ClientError;
            case "ClientInterrupted":
                return i.ClientInterrupted;
            case "ConnectionDropped":
                return i.ConnectionDropped;
            case "HangupCall":
                return i.HangupCall;
            case "IgnoreCall":
                return i.IgnoreCall;
            case "InAnotherCall":
                return i.InAnotherCall;
            case "EndToEndEncryptionInvariantViolated":
                return i.EndToEndEncryptionInvariantViolated;
            case "InactiveTimeout":
                return i.CallEnded;
            case "IncomingTimeout":
                return i.IncomingTimeout;
            case "MaxAllowedParticipantsReached":
                return i.MaxAllowedParticipantsReached;
            case "NoAnswerTimeout":
                return i.NoAnswerTimeout;
            case "NoPermission":
                return i.NoPermission;
            case "NoUIShown":
                return i.NoUIShown;
            case "OtherCarrierBlocked":
                return i.OtherCarrierBlocked;
            case "OtherInstanceHandled":
                return i.OtherInstanceHandled;
            case "OtherNotCapable":
                return i.OtherNotCapable;
            case "SignalingMessageFailed":
                return i.SignalingMessageFailed;
            case "UnexpectedEndOfCall":
                return i.UnexpectedEndOfCall;
            case "Unknown":
                return i.CallEnded;
            case "VersionUnsupported":
                return i.VersionUnsupported;
            case "WebRTCError":
                return i.WebRTCError;
            case "MicrophonePermissionDenied":
                return i.MicrophonePermissionDenied;
            case "CameraPermissionDenied":
                return i.CameraPermissionDenied;
            case "SessionMigrated":
                return i.SessionMigrated;
            case "RingMuted":
                return i.RingMuted;
            case "TxAckTimeout":
                return i.TxAckTimeout;
            case "ProductServerDefinedEndReason":
                return i.ProductServerDefinedEndReason;
            case "RemovedByParticipant":
                return i.RemovedByParticipant
        }
    }

    function e(a) {
        switch (a) {
            case i.CallEnded:
            case i.CallEndedByProduct:
            case i.HangupCall:
                return "HangupCall";
            case i.IgnoreCall:
            case i.JoinApprovalDenied:
            case i.RejectedByCallee:
                return "IgnoreCall";
            case i.InAnotherCall:
                return "InAnotherCall";
            case i.AcceptAfterHangUp:
                return "CallEndAcceptAfterHangUp";
            case i.NoAnswerTimeout:
                return "NoAnswerTimeout";
            case i.IncomingTimeout:
                return "IncomingTimeout";
            case i.AnsweredOnAnotherDevice:
            case i.CallCollision:
            case i.RejectedOnAnotherDevice:
            case i.OtherInstanceHandled:
            case i.AnsweredByOtherUser:
                return "OtherInstanceHandled";
            case i.SignalingMessageFailed:
                return "SignalingMessageFailed";
            case i.ConnectionDropped:
                return "ConnectionDropped";
            case i.ClientInterrupted:
                return "ClientInterrupted";
            case i.WebRTCError:
                return "WebRTCError";
            case i.ClientError:
                return "ClientError";
            case i.NoPermission:
                return "NoPermission";
            case i.OtherNotCapable:
                return "OtherNotCapable";
            case i.NoUIShown:
                return "NoUIShown";
            case i.VersionUnsupported:
                return "VersionUnsupported";
            case i.CallerNotVisible:
                return "CallerNotVisible";
            case i.CarrierBlocked:
                return "CarrierBlocked";
            case i.OtherCarrierBlocked:
                return "OtherCarrierBlocked";
            case i.ClientEncryptionError:
                return "ClientEncryptionError";
            case i.UnexpectedEndOfCall:
                return "UnexpectedEndOfCall";
            case i.MaxAllowedParticipantsReached:
                return "MaxAllowedParticipantsReached";
            case i.MicrophonePermissionDenied:
                return "MicrophonePermissionDenied";
            case i.CameraPermissionDenied:
                return "CameraPermissionDenied";
            case i.SessionMigrated:
                return "SessionMigrated";
            case i.RingMuted:
                return "RingMuted";
            case i.TxAckTimeout:
                return "TxAckTimeout";
            case i.EndToEndEncryptionInvariantViolated:
                return "EndToEndEncryptionInvariantViolated";
            case i.ProductServerDefinedEndReason:
                return "ProductServerDefinedEndReason";
            case i.RemovedByParticipant:
                return "RemovedByParticipant"
        }
        c("FBLogger")("rtc_www").mustfix("Unknown dismiss reason: %s", a);
        return "Unknown"
    }

    function f(a) {
        switch (a) {
            case i.OtherInstanceHandled:
            case i.AnsweredOnAnotherDevice:
            case i.AnsweredByOtherUser:
            case i.RejectedOnAnotherDevice:
                return d("ZenonIncomingRingSDKTypes").ZenonCancelReason.OtherDismiss;
            default:
                return d("ZenonIncomingRingSDKTypes").ZenonCancelReason.Hangup
        }
    }

    function j(a) {
        switch (a) {
            case d("ZenonMediaError").ZenonMediaError.IceDisconnected:
                return i.ConnectionDropped;
            case d("ZenonMediaError").ZenonMediaError.ConnectionClosed:
                return i.HangupCall;
            case d("ZenonMediaError").ZenonMediaError.IceFailure:
            case d("ZenonMediaError").ZenonMediaError.SetLocalSdpFailed:
            case d("ZenonMediaError").ZenonMediaError.SetRemoteSdpFailed:
            case d("ZenonMediaError").ZenonMediaError.RollbackSdpFailed:
                return i.WebRTCError;
            case d("ZenonMediaError").ZenonMediaError.UnknownError:
                return i.UnexpectedEndOfCall
        }
    }

    function k(a) {
        return l[a]
    }
    var l = Object.freeze((b = {}, b[(h = d("ZenonMWMessageTypes")).ZenonMWDismissReason.CALL_ENDED] = i.CallEnded, b[h.ZenonMWDismissReason.ANSWERED_ON_ANOTHER_DEVICE] = i.AnsweredOnAnotherDevice, b[h.ZenonMWDismissReason.ANSWERED_BY_OTHER_USER] = i.AnsweredByOtherUser, b[h.ZenonMWDismissReason.IN_ANOTHER_CALL] = i.InAnotherCall, b[h.ZenonMWDismissReason.CONNECTION_DROPPED] = i.ConnectionDropped, b[h.ZenonMWDismissReason.REJECTED_ON_ANOTHER_DEVICE] = i.RejectedOnAnotherDevice, b[h.ZenonMWDismissReason.REJECTED_BY_CALLEE] = i.RejectedByCallee, b[h.ZenonMWDismissReason.CALL_ENDED_BY_PRODUCT] = i.CallEndedByProduct, b[h.ZenonMWDismissReason.INTERNAL_ERROR] = i.SignalingMessageFailed, b[h.ZenonMWDismissReason.REMOVED_BY_PARTICIPANT] = i.RemovedByParticipant, b[h.ZenonMWDismissReason.TX_ACK_TIMEDOUT] = i.TxAckTimeout, b));
    g.ZenonDismissReason = i;
    g.endCallToDismissReason = a;
    g.dismissToEndCallReason = e;
    g.dismissReasonToCancelReason = f;
    g.mediaErrorToDismissReason = j;
    g.mwDismissToDmissReason = k
}), 98);
__d("ZenonCallsModelTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    c = (a = b("$InternalEnum")).Mirrored(["Disconnected", "Precontacting", "Contacting", "Ringing", "PendingApproval", "Approved", "FailedApproval", "Connecting", "Connected", "Reconnecting", "ProvisionalRinging"]);
    d = a.Mirrored(["Facebook", "Instagram", "Messenger", "Guest", "WhatsApp", "Workplace"]);
    e = a.Mirrored(["New", "Connecting", "PendingApproval", "Connected", "Terminating", "Terminated"]);
    b = a.Mirrored(["Unknown", "CallsBlocked", "PageAdminPressedDecline"]);
    a = a.Mirrored(["None", "PendingPeerFeedback", "Declined", "RemoteDeclined", "LocalDeclined", "Cancelled", "TimedOut", "Accepted", "InitiatedFromPeer"]);
    f.ZenonCallParticipantState = c;
    f.ZenonCallParticipantType = d;
    f.ZenonCallState = e;
    f.ZenonEndCallSubreason = b;
    f.ZenonVideoEscalationStatus = a
}), 66);
__d("ZenonParticipantState", ["$InternalEnum", "ZenonCallsModelTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = b("$InternalEnum")({
        UNKNOWN: 0,
        ADDING: 1,
        CONTACTING: 2,
        RINGING: 3,
        ACCEPTING: 4,
        PRECONNECTING: 5,
        CONNECTING: 6,
        CONNECTED: 7,
        REMOVING: 8,
        DISCONNECTED: 9,
        NO_ANSWER: 10,
        REJECTED: 11,
        UNREACHABLE: 12,
        CONNECTION_DROPPED: 13,
        PARTICIPANT_LIMIT_REACHED: 14,
        IN_ANOTHER_CALL: 15,
        RING_TYPE_UNSUPPORTED: 16,
        PENDING_APPROVAL: 17,
        APPROVING: 18,
        DENYING: 19,
        APPROVED: 20,
        FAILED_APPROVAL: 21,
        HANGUP_IN_WAITING_ROOM: 22,
        RECONNECTING: 23
    });

    function a(a) {
        if (a == null) return d("ZenonCallsModelTypes").ZenonCallParticipantState.Disconnected;
        switch (a) {
            case h.CONTACTING:
            case h.PRECONNECTING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Contacting;
            case h.RINGING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Ringing;
            case h.CONNECTING:
            case h.RECONNECTING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Connecting;
            case h.CONNECTED:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Connected;
            case h.PENDING_APPROVAL:
            case h.APPROVING:
            case h.DENYING:
            case h.ACCEPTING:
            case h.ADDING:
            case h.REMOVING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.PendingApproval;
            case h.APPROVED:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Approved;
            case h.FAILED_APPROVAL:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.FailedApproval;
            case h.HANGUP_IN_WAITING_ROOM:
            case h.UNKNOWN:
            case h.DISCONNECTED:
            case h.NO_ANSWER:
            case h.REJECTED:
            case h.UNREACHABLE:
            case h.CONNECTION_DROPPED:
            case h.PARTICIPANT_LIMIT_REACHED:
            case h.IN_ANOTHER_CALL:
            case h.RING_TYPE_UNSUPPORTED:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Disconnected
        }
        return d("ZenonCallsModelTypes").ZenonCallParticipantState.Disconnected
    }
    g.ZenonParticipantState = h;
    g.toCallParticipantState = a
}), 98);
__d("ZenonScreenShare", ["UserAgent", "ZenonAppProvider", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a.length === 1 && ((a = a[0]) == null ? void 0 : a.contentType) === "screen"
    }

    function h() {
        return !c("UserAgent").isBrowser("Safari")
    }

    function i() {
        return d("ZenonAppProvider").isOculusCastingSite() && c("justknobx")._("1977") ? !1 : !0
    }

    function b() {
        return !h() || !i()
    }
    g.isScreenSharingTrack = a;
    g.screenShareWithReplaceTrack = b
}), 98);
__d("ZenonStateSyncPayloadSerializer", ["RequestStreamBodyUtils", "ZenonAppProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return d("ZenonAppProvider").isInstagramApp() ? d("RequestStreamBodyUtils").stringToUint8Array(a) : d("RequestStreamBodyUtils").base64ToUint8Array(a)
    }
    g.stateSyncStringToUint8Array = a
}), 98);
__d("addDevTierOverridesToHeaderExtensions", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = {
            multiwayCoreTier: "",
            multiwayWwwTier: ""
        };
        if (!c("gkx")("25224")) return b;
        b.multiwayWwwTier = h(a, "multiway_www_tier");
        b.multiwayCoreTier = h(a, "multiway_core_tier");
        return b
    }

    function h(a, b) {
        b = b + "=";
        a = a.split(b);
        return a[1] ? a.pop().split("&").shift() : ""
    }
    g["default"] = a
}), 98);
__d("ZenonMWTranslatorUtils", ["ChannelClientID", "CurrentUser", "IGDWebUtils", "OverlayConfigServerLayer", "RequestStreamBodyUtils", "RpWebMqttEnabledAppIds", "ZenonDismissReason", "ZenonMWMessageTypes", "ZenonParticipantState", "ZenonScreenShare", "ZenonSignalingProtocol", "ZenonSignalingTypes", "ZenonStateSyncPayloadSerializer", "addDevTierOverridesToHeaderExtensions", "err", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = "signalingDominantSpeakerUpdate",
        l = "signalingVideoUploadUpdate",
        m = "E2eeState",
        n = new Set(c("RpWebMqttEnabledAppIds").APP_IDS);

    function a(a, b, e, f) {
        e === void 0 && (e = !1), a && Object.keys(a).forEach(function(g) {
            if (g === m && f && c("justknobx")._("1893")) return;
            var h = a[g],
                i = h.data;
            h = h.version;
            if (i != null) {
                i = {
                    data: d("ZenonStateSyncPayloadSerializer").stateSyncStringToUint8Array(i),
                    eventName: "stateSyncNotifyRequest",
                    responseRequired: e,
                    topic: g,
                    version: h
                };
                b.push(i)
            }
        })
    }

    function b(a) {
        var b;
        if (a) {
            a = a[m];
            (a == null ? void 0 : a.data) != null && (b = d("ZenonStateSyncPayloadSerializer").stateSyncStringToUint8Array(a.data));
            return b
        }
    }

    function e(a, b, d) {
        var e = {
            appId: t(),
            deviceId: c("ChannelClientID").getID(),
            userId: b.userInfo.userID
        };
        b = z(b, a);
        return {
            endpoint: e,
            jsonPayload: {
                body: d,
                header: b
            }
        }
    }

    function f(a, b, d, e, f) {
        var g = {
            appId: t(),
            deviceId: c("ChannelClientID").getID(),
            userId: b.userInfo.userID
        };
        b = A(b, a, e, f);
        return {
            endpoint: g,
            jsonPayload: {
                body: d,
                header: b
            }
        }
    }

    function o(a) {
        a = d("ZenonDismissReason").mwDismissToDmissReason(a);
        return (a = a) != null ? a : d("ZenonDismissReason").ZenonDismissReason.CallEnded
    }

    function p(a) {
        a = N[a];
        return (a = a) != null ? a : d("ZenonMWMessageTypes").ZenonMWParticipantCallState.UNKNOWN
    }

    function q(a) {
        var b = null;
        a != null && a.forEach(function(a) {
            a = (a = a.body) == null ? void 0 : a.genericMessage;
            if (a != null && a.topic === "collision_context_payload") {
                a = a.data;
                if (a != null) {
                    var c;
                    a = JSON.parse(a);
                    b = {
                        groupThreadID: (c = a.group_thread_id) != null ? c : null,
                        peerID: (c = a.peer_id) != null ? c : null,
                        serverInfoData: (c = a.server_info_data) != null ? c : null
                    }
                }
            }
        });
        return b
    }

    function r(a) {
        a = (a = a.message.body) != null ? a : {};
        var b = a.dominantSpeakerSignalingInfo,
            c = a.genericMessage;
        a = a.videoUploadSignalingInfo;
        if (c) try {
                return atob(c.data)
            } catch (a) {
                return c.data
            } else if (b) return JSON.stringify(b);
            else if (a) return JSON.stringify(a);
        return null
    }

    function s(a) {
        a = (a = a.message.body) != null ? a : {};
        var b = a.dominantSpeakerSignalingInfo,
            c = a.genericMessage;
        a = a.videoUploadSignalingInfo;
        if (c) return c.topic;
        else if (b) return k;
        else if (a) return l;
        return null
    }

    function t() {
        var a = c("CurrentUser").getAppID();
        if (a != null && d("IGDWebUtils").isInstagramWebSupportedApp(Number(a))) return a;
        a = (a = a) != null ? a : 219994525426954..toString();
        return n.has(Number(a)) ? a : 219994525426954..toString()
    }

    function u(a) {
        a = a && a.length > 0 ? a.find(function(a) {
            return ((a = a.body) == null ? void 0 : (a = a.genericMessage) == null ? void 0 : a.topic) === "room_metadata"
        }) : null;
        if (a) {
            var b;
            b = (b = a.body) == null ? void 0 : (b = b.genericMessage) == null ? void 0 : b.data;
            if (b != null) {
                b = JSON.parse(b);
                a = (a = a.header) == null ? void 0 : a.sender;
                if (b.link_hash != null && b.room_name != null && a != null) return {
                    linkHash: b.link_hash,
                    profileURL: b.profile_url,
                    ringSubtitle: b.ring_subtitle,
                    roomName: b.room_name,
                    sender: a
                }
            }
        }
        return null
    }

    function v(a, b) {
        b = c("OverlayConfigServerLayer").createFromHeader(b);
        if (b) {
            b = {
                eventName: "overlayConfigServerUpdateRequest",
                serverLayer: b
            };
            a.push(b)
        }
    }

    function w(a) {
        return a.reduce(function(a, b) {
            var c;
            c = (c = b.body) == null ? void 0 : (c = c.genericMessage) == null ? void 0 : c.topic;
            b = (b = b.body) == null ? void 0 : (b = b.genericMessage) == null ? void 0 : b.data;
            c != null && b != null && (a[c] = b);
            return a
        }, {})
    }

    function x(a) {
        var b = a.clientSessionId,
            d = a.conferenceName,
            e = a.receiver,
            f = a.receiverUserId,
            g = a.sequenceNumber,
            h = a.serverInfoData,
            i = a.transactionId;
        if (f == null) throw c("err")("Incoming MW messages should have receiverUserId populated.");
        b = b;
        var j = {
            userID: "2"
        };
        e = {
            actorID: (e = e == null ? void 0 : e.actorId) != null ? e : null,
            messageID: i,
            messageTags: (e = a.messageTags) != null ? e : [],
            protocol: c("ZenonSignalingProtocol").MW,
            remoteInfo: j,
            retryCount: a.retryCount,
            roomInfo: {
                name: d
            },
            sequenceNumber: g,
            signalingID: b,
            userInfo: {
                userID: (i = f) != null ? i : "1"
            }
        };
        h != null && (e.remoteSignalingID = h);
        return e
    }

    function y(a, b) {
        return Object.keys(a).map(function(c) {
            var d = a[c];
            return {
                body: {
                    genericMessage: {
                        data: d,
                        topic: c
                    }
                },
                header: {
                    recipients: b,
                    topic_DEPRECATED: c
                }
            }
        })
    }

    function z(a, b) {
        var e = a.messageID,
            f = a.messageTags,
            g = a.remoteSignalingID,
            h = a.roomInfo,
            i = a.signalingID,
            j = c("addDevTierOverridesToHeaderExtensions")(window.location.href);
        h = {
            clientStack: d("ZenonMWMessageTypes").ZenonMWClientStack.ZENON,
            conferenceName: h.name,
            messageTags: f,
            retryCount: a.retryCount,
            sequenceNumber: a.sequenceNumber,
            transactionId: e,
            type: b
        };
        (j.multiwayCoreTier !== "" || j.multiwayWwwTier !== "") && (h.extensions = j);
        i != null && (h.clientSessionId = i);
        g != null && (h.serverInfoData = g);
        a.actorID != null && (h.sender = {
            id: a.actorID
        });
        return h
    }

    function A(a, b, c, e) {
        a = z(a, b);
        a.responseStatusCode = (b = c) != null ? b : d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.OK;
        e != null && (a.responseSubCode = e);
        return a
    }

    function B(a) {
        var b = {
                tracks: {}
            },
            c = !d("ZenonScreenShare").screenShareWithReplaceTrack();
        a.tracks.forEach(function(a) {
            var d = {
                    enabled: a.enabled,
                    name: a.name,
                    owner: a.participantID
                },
                e = c ? K(a.type) : null;
            e != null && (d.label = e);
            b.tracks[a.trackID] = d
        });
        return b
    }

    function C(a) {
        if (a == null) return null;
        switch (a) {
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_AUDIO:
                return "audio";
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_VIDEO:
                return "video";
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_AUDIO:
                return "screen_audio";
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_VIDEO:
                return "screen"
        }
    }

    function D(a) {
        a = M[a];
        return (a = a) != null ? a : d("ZenonMWMessageTypes").ZenonMWDeviceStatus.OK
    }

    function E(a) {
        switch (a) {
            case d("ZenonDismissReason").ZenonDismissReason.IgnoreCall:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.IGNORE_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.HangupCall:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.HANGUP_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.NoAnswerTimeout:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.NO_ANSWER_TIMEOUT;
            case d("ZenonDismissReason").ZenonDismissReason.ClientError:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.CLIENT_ERROR;
            case d("ZenonDismissReason").ZenonDismissReason.InAnotherCall:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.IN_ANOTHER_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.ClientInterrupted:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.CLIENT_INTERRUPTED;
            case d("ZenonDismissReason").ZenonDismissReason.SessionMigrated:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.SESSION_MIGRATED;
            default:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.HANGUP_CALL
        }
    }

    function F(a) {
        var b = {};
        a.tracks.forEach(function(a) {
            b[a.trackID] = a.enabled
        });
        return b
    }

    function G(a) {
        var b = {},
            c = !d("ZenonScreenShare").screenShareWithReplaceTrack();
        a.tracks.forEach(function(a) {
            var d = {
                    enabled: a.enabled
                },
                e = c ? K(a.type) : null;
            e != null && (d.label = e);
            b[a.trackID] = d
        });
        return {
            tracks: b
        }
    }

    function H(a) {
        return O[a]
    }

    function I(a) {
        return a == null ? null : P[a]
    }

    function J(a) {
        var b = {};
        a.forEach(function(a, c) {
            b[c] = {
                data: a.data ? d("RequestStreamBodyUtils").uint8ArrayToBase64(a.data) : void 0,
                version: a.version
            }
        });
        return b
    }

    function K(a) {
        switch (a) {
            case "audio":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_AUDIO;
            case "video":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_VIDEO;
            case "screen":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_VIDEO;
            case "screen_audio":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_AUDIO;
            default:
                return null
        }
    }

    function L(a, b, c) {
        c === void 0 && (c = 0);
        var d = {
            fromVersion: b,
            tracks: [],
            version: c
        };
        a != null && Object.keys(a.tracks).forEach(function(b) {
            var c = a.tracks[b];
            b = {
                enabled: c.enabled,
                name: c.name,
                participantID: c.owner,
                trackID: b,
                type: C(c.label)
            };
            d.tracks.push(b)
        });
        return d
    }
    var M = {
            IN_ANOTHER_CALL: (i = d("ZenonMWMessageTypes")).ZenonMWDeviceStatus.IN_ANOTHER_CALL,
            NOT_SUPPORTED: i.ZenonMWDeviceStatus.NOT_SUPPORTED,
            OK: i.ZenonMWDeviceStatus.OK
        },
        N = Object.freeze((h = {}, h[i.ZenonMWParticipantCallState.UNKNOWN] = (j = d("ZenonParticipantState")).ZenonParticipantState.UNKNOWN, h[i.ZenonMWParticipantCallState.DISCONNECTED] = j.ZenonParticipantState.DISCONNECTED, h[i.ZenonMWParticipantCallState.NO_ANSWER] = j.ZenonParticipantState.NO_ANSWER, h[i.ZenonMWParticipantCallState.REJECTED] = j.ZenonParticipantState.REJECTED, h[i.ZenonMWParticipantCallState.UNREACHABLE] = j.ZenonParticipantState.UNREACHABLE, h[i.ZenonMWParticipantCallState.CONNECTION_DROPPED] = j.ZenonParticipantState.CONNECTION_DROPPED, h[i.ZenonMWParticipantCallState.CONTACTING] = j.ZenonParticipantState.CONTACTING, h[i.ZenonMWParticipantCallState.RINGING] = j.ZenonParticipantState.RINGING, h[i.ZenonMWParticipantCallState.CONNECTING] = j.ZenonParticipantState.CONNECTING, h[i.ZenonMWParticipantCallState.CONNECTED] = j.ZenonParticipantState.CONNECTED, h[i.ZenonMWParticipantCallState.PARTICIPANT_LIMIT_REACHED] = j.ZenonParticipantState.PARTICIPANT_LIMIT_REACHED, h[i.ZenonMWParticipantCallState.IN_ANOTHER_CALL] = j.ZenonParticipantState.IN_ANOTHER_CALL, h[i.ZenonMWParticipantCallState.RING_TYPE_UNSUPPORTED] = j.ZenonParticipantState.RING_TYPE_UNSUPPORTED, h[i.ZenonMWParticipantCallState.PENDING_APPROVAL] = j.ZenonParticipantState.PENDING_APPROVAL, h[i.ZenonMWParticipantCallState.APPROVED] = j.ZenonParticipantState.APPROVED, h[i.ZenonMWParticipantCallState.FAILED_APPROVAL] = j.ZenonParticipantState.FAILED_APPROVAL, h[i.ZenonMWParticipantCallState.UNCALLABLE] = j.ZenonParticipantState.UNREACHABLE, h[i.ZenonMWParticipantCallState.HANGUP_IN_WAITING_ROOM] = j.ZenonParticipantState.HANGUP_IN_WAITING_ROOM, h)),
        O = Object.freeze((j = {}, j[(h = d("ZenonSignalingTypes")).ZenonSignalingStatusCode.OK] = i.ZenonMWResponseStatusCode.OK, j[h.ZenonSignalingStatusCode.REJECTED_FROM_VERSION_DOES_NOT_MATCH] = i.ZenonMWResponseStatusCode.CONDITIONAL_REQUEST_FAILED, j[h.ZenonSignalingStatusCode.METHOD_NOT_ALLOWED] = i.ZenonMWResponseStatusCode.METHOD_NOT_ALLOWED, j)),
        P = Object.freeze((j = {}, j[h.ZenonSignalingStatusSubCode.CLIENT_TERMINATED] = i.ZenonMWResponseSubCode.CLIENT_TERMINATED, j));
    g.E2EE_STATE_SYNC_TOPIC = m;
    g.addStateStoreSignalingEvents = a;
    g.fetchE2eeServerState = b;
    g.createMWRequest = e;
    g.createMWResponse = f;
    g.fromMWDismissReason = o;
    g.fromMWParticipantState = p;
    g.getCollisionContextFromAppMessages = q;
    g.getGenericDataMessageData = r;
    g.getGenericDataMessageTopic = s;
    g.getMWAppID = t;
    g.getRoomMetadataFromAppMessages = u;
    g.maybeAddOverlayConfigServerUpdateRequest = v;
    g.mwAppMessagesToSignalingAppMessages = w;
    g.mwMessageHeaderToSignalingMessageHeader = x;
    g.signalingMessageAppMessagesToMWAppMessages = y;
    g.toMWClientMediaStatus = B;
    g.toMWClientTrackContentType = C;
    g.toMWDeviceStatus = D;
    g.toMWHangupReason = E;
    g.toMWMediaStatus = F;
    g.toMWMediaStatusEx = G;
    g.toMWResponseStatusCode = H;
    g.toMWResponseStatusSubCode = I;
    g.toMWSyncStateStore = J;
    g.toMWTrackLabel = K;
    g.toZenonMediaStates = L
}), 98);
__d("ZenonMWCommonUtils", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = a.split("\n");
        if (a.length < 2) throw c("unrecoverableViolation")("Expected SDP string with two or more lines, but got " + a.length, "rtc_www");
        a = a[1].trim();
        a = a.split(" ");
        if (a.length < 3) throw c("unrecoverableViolation")("Session line should have at least 3 tokens, but got " + a.length, "rtc_www");
        a = parseInt(a[2], 10);
        if (isNaN(a)) throw c("unrecoverableViolation")("SDP version could not be parsed as number.", "rtc_www");
        return a
    }

    function b(a) {
        return a.includes("BUNDLE 0")
    }
    g.getSdpVersion = a;
    g.isUnifiedPlan = b
}), 98);
__d("ZenonJoiningContext", [], (function(a, b, c, d, e, f) {
    "use strict";
    b = "joining_context";

    function a(a) {
        var b = a.callablePostID,
            c = a.callingTags,
            d = a.callTrigger,
            e = a.conferenceName,
            f = a.groupThreadID,
            g = a.igThreadID,
            h = a.immersiveModeDoorID,
            i = a.isMetaAiCall,
            j = a.linkUrl,
            k = a.liveBroadcastID,
            l = a.meetingID,
            m = a.peerID,
            n = a.rtcDoorID;
        a = a.serverInfoData;
        return {
            call_trigger: d,
            callable_post_id: b,
            calling_tags: c,
            conference_name: e,
            group_thread_id: f,
            ig_thread_id: g,
            immersive_mode_door_id: h,
            is_meta_ai_call: i,
            link_url: j,
            live_broadcast_id: k,
            meeting_id: l,
            peer_id: m,
            rtc_door_id: n,
            server_info_data: a
        }
    }
    f.JOINING_CONTEXT_TOPIC = b;
    f.convertCollisionToJoiningContext = a
}), 66);
__d("ZenonBrowsers", ["UserAgent", "UserAgentData"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        return c("UserAgent").isBrowser("Chrome")
    }

    function i() {
        return !!navigator.webkitGetUserMedia
    }

    function a() {
        return c("UserAgent").isBrowser("Edge (Chromium Based)") || c("UserAgent").isBrowser("Edge PWA (Chromium Based)")
    }

    function j() {
        return c("UserAgent").isBrowser("Safari")
    }

    function k() {
        return c("UserAgent").isBrowser("Firefox")
    }

    function b() {
        return c("UserAgent").isBrowser("Opera")
    }

    function l() {
        return c("UserAgent").isBrowser("Mobile Safari")
    }

    function m() {
        return c("UserAgent").isBrowser("Oculus Browser")
    }

    function n() {
        return c("UserAgent").isBrowser("Samsung Browser")
    }

    function d() {
        return l() || c("UserAgent").isPlatform("Android") || n()
    }

    function o() {
        return c("UserAgent").isPlatform("Android") || c("UserAgent").isPlatform("iOS")
    }

    function p() {
        if (k()) {
            var a;
            return (a = c("UserAgentData").browserVersion) != null ? a : 0
        }
        if (i()) {
            a = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
            return a != null ? parseInt(a[2], 10) : 999
        }
        return 0
    }

    function q() {
        return c("UserAgent").isBrowser("FBLite") || c("UserAgent").isBrowser("Facebook for Android")
    }

    function e(a) {
        if (!q()) return !1;
        var b = p();
        return b >= a
    }

    function f() {
        return k()
    }

    function r() {
        return k() || j() || c("UserAgent").isBrowser("Chrome >= 97")
    }

    function s() {
        return !o() && (c("UserAgent").isBrowser("Chrome >= 51") || c("UserAgent").isBrowser("Opera >= 36"))
    }

    function t() {
        return c("UserAgent").isBrowser("Firefox < 60") || c("UserAgent").isBrowser("Edge")
    }

    function u() {
        return !m()
    }

    function v() {
        return !m()
    }

    function w() {
        return !l() && !j() && !((i() || h()) && p() < 80) && !(k() && p() < 70)
    }

    function x() {
        return (i() || h()) && p() >= 77 || c("UserAgent").isBrowser("Firefox >= 70") || c("UserAgent").isBrowser("Safari >= 14.1")
    }

    function y() {
        return c("UserAgent").isBrowser("Chrome >= 89") || c("UserAgent").isBrowser("Opera >= 75") || c("UserAgent").isBrowser("Edge (Chromium Based) >= 89") || c("UserAgent").isBrowser("Edge PWA (Chromium Based) >= 89")
    }
    g.isChrome = h;
    g.isChromium = i;
    g.isChromiumBasedEdge = a;
    g.isDesktopSafari = j;
    g.isFirefox = k;
    g.isOpera = b;
    g.isMobileSafari = l;
    g.isOculusBrowser = m;
    g.isSamsung = n;
    g.isSupportedMobileBrowser = d;
    g.isMobileDevice = o;
    g.webrtcVersion = p;
    g.isFBWebview = q;
    g.isFBWebviewWithChromeMinVersion = e;
    g.noTransceiverForNegotiations = f;
    g.onlySupportsUnifiedPlan = r;
    g.isVideoFilterEffectSupported = s;
    g.videoEscalationByUnmuteWorkaround = t;
    g.supportsMWAVEscalation = u;
    g.supportsVideoCalls = v;
    g.supportsRollback = w;
    g.supportsIceRestart = x;
    g.isVideoLayersAllocationSupported = y
}), 98);
__d("ZenonMWJoinUtils", ["ZenonBrowsers", "ZenonIGMediaUtil", "gkx", "shouldUseSFUMediaPath"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return d("ZenonBrowsers").isFirefox() && a !== "answer" ? !1 : !c("ZenonIGMediaUtil").shouldUseSFUOnly()
    }

    function b() {
        return c("shouldUseSFUMediaPath")(!1) ? !1 : c("gkx")("25223")
    }
    g.canUseMwpp = a;
    g.canDeescalate = b
}), 98);
__d("ZenonMWThriftTranslatorUtils", ["MultiwayCommonTypes", "MultiwaySharedTypes", "OverlayConfigServerLayer", "RequestStreamBodyUtils", "WebrtcSignalingCommonTypes", "ZenonDismissReason", "ZenonMWMessageTypes", "ZenonMWThriftMessageTagUtils", "ZenonParticipantState", "ZenonScreenShare", "ZenonSignalingProtocol", "ZenonSignalingTypes", "addDevTierOverridesToHeaderExtensions", "err", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = "signalingDominantSpeakerUpdate",
        l = "signalingVideoUploadUpdate",
        m = "E2eeState";

    function a(a, b, d, e) {
        d === void 0 && (d = !1), a && Object.keys(a).forEach(function(f) {
            if (f === m && e && c("justknobx")._("1893")) return;
            var g = a[f],
                h = g.data;
            g = g.version;
            if (h != null) {
                h = {
                    data: h,
                    eventName: "stateSyncNotifyRequest",
                    responseRequired: d,
                    topic: f,
                    version: g
                };
                b.push(h)
            }
        })
    }

    function b(a) {
        if (a) {
            a = a[m];
            return a == null ? void 0 : a.data
        }
    }

    function e(a) {
        if (a == null) return d("ZenonMWMessageTypes").ZenonMWMediaPath.UNKNOWN;
        switch (a) {
            case d("MultiwaySharedTypes").MediaPath.SFU:
                return d("ZenonMWMessageTypes").ZenonMWMediaPath.SFU;
            case d("MultiwaySharedTypes").MediaPath.P2P:
                return d("ZenonMWMessageTypes").ZenonMWMediaPath.P2P;
            default:
                return d("ZenonMWMessageTypes").ZenonMWMediaPath.UNKNOWN
        }
    }

    function f(a) {
        if (a == null) return d("ZenonParticipantState").ZenonParticipantState.UNKNOWN;
        switch (a) {
            case d("MultiwayCommonTypes").ParticipantCallState.DISCONNECTED:
                return d("ZenonParticipantState").ZenonParticipantState.DISCONNECTED;
            case d("MultiwayCommonTypes").ParticipantCallState.NO_ANSWER:
                return d("ZenonParticipantState").ZenonParticipantState.NO_ANSWER;
            case d("MultiwayCommonTypes").ParticipantCallState.REJECTED:
                return d("ZenonParticipantState").ZenonParticipantState.REJECTED;
            case d("MultiwayCommonTypes").ParticipantCallState.UNREACHABLE:
            case d("MultiwayCommonTypes").ParticipantCallState.UNCALLABLE:
                return d("ZenonParticipantState").ZenonParticipantState.UNREACHABLE;
            case d("MultiwayCommonTypes").ParticipantCallState.CONNECTION_DROPPED:
                return d("ZenonParticipantState").ZenonParticipantState.CONNECTION_DROPPED;
            case d("MultiwayCommonTypes").ParticipantCallState.CONTACTING:
                return d("ZenonParticipantState").ZenonParticipantState.CONTACTING;
            case d("MultiwayCommonTypes").ParticipantCallState.RINGING:
                return d("ZenonParticipantState").ZenonParticipantState.RINGING;
            case d("MultiwayCommonTypes").ParticipantCallState.CONNECTING:
                return d("ZenonParticipantState").ZenonParticipantState.CONNECTING;
            case d("MultiwayCommonTypes").ParticipantCallState.CONNECTED:
                return d("ZenonParticipantState").ZenonParticipantState.CONNECTED;
            case d("MultiwayCommonTypes").ParticipantCallState.PARTICIPANT_LIMIT_REACHED:
                return d("ZenonParticipantState").ZenonParticipantState.PARTICIPANT_LIMIT_REACHED;
            case d("MultiwayCommonTypes").ParticipantCallState.IN_ANOTHER_CALL:
                return d("ZenonParticipantState").ZenonParticipantState.IN_ANOTHER_CALL;
            case d("MultiwayCommonTypes").ParticipantCallState.RING_TYPE_UNSUPPORTED:
                return d("ZenonParticipantState").ZenonParticipantState.RING_TYPE_UNSUPPORTED;
            case d("MultiwayCommonTypes").ParticipantCallState.PENDING_APPROVAL:
                return d("ZenonParticipantState").ZenonParticipantState.PENDING_APPROVAL;
            case d("MultiwayCommonTypes").ParticipantCallState.APPROVED:
                return d("ZenonParticipantState").ZenonParticipantState.APPROVED;
            case d("MultiwayCommonTypes").ParticipantCallState.FAILED_APPROVAL:
                return d("ZenonParticipantState").ZenonParticipantState.FAILED_APPROVAL;
            case d("MultiwayCommonTypes").ParticipantCallState.HANGUP_IN_WAITING_ROOM:
                return d("ZenonParticipantState").ZenonParticipantState.HANGUP_IN_WAITING_ROOM;
            default:
                return d("ZenonParticipantState").ZenonParticipantState.UNKNOWN
        }
    }

    function n(a) {
        var b = null;
        a != null && a.forEach(function(a) {
            a = (a = a.body) == null ? void 0 : a.genericMessage;
            if (a != null && a.topic === "collision_context_payload") {
                a = a.data;
                if (a != null) {
                    var c;
                    a = JSON.parse(d("RequestStreamBodyUtils").uint8ArrayToString(a));
                    b = {
                        groupThreadID: (c = a.group_thread_id) != null ? c : null,
                        peerID: (c = a.peer_id) != null ? c : null,
                        serverInfoData: (c = a.server_info_data) != null ? c : null
                    }
                }
            }
        });
        return b
    }

    function o(a) {
        a = a && a.length > 0 ? a.find(function(a) {
            return ((a = a.body) == null ? void 0 : (a = a.genericMessage) == null ? void 0 : a.topic) === "room_metadata"
        }) : null;
        if (a) {
            var b;
            b = (b = a.body) == null ? void 0 : (b = b.genericMessage) == null ? void 0 : b.data;
            if (b != null) {
                b = JSON.parse(d("RequestStreamBodyUtils").uint8ArrayToString(b));
                a = (a = a.header) == null ? void 0 : a.sender;
                if (b.link_hash != null && b.room_name != null && a != null) return {
                    linkHash: b.link_hash,
                    profileURL: b.profile_url,
                    ringSubtitle: b.ring_subtitle,
                    roomName: b.room_name,
                    sender: a
                }
            }
        }
        return null
    }

    function p(a) {
        return a.reduce(function(a, b) {
            var c;
            c = (c = b.body) == null ? void 0 : (c = c.genericMessage) == null ? void 0 : c.topic;
            b = (b = b.body) == null ? void 0 : (b = b.genericMessage) == null ? void 0 : b.data;
            c != null && b != null && (a[c] = d("RequestStreamBodyUtils").uint8ArrayToString(b));
            return a
        }, {})
    }

    function q(a) {
        switch (a) {
            case d("ZenonMWMessageTypes").ZenonMWMediaPath.SFU:
                return d("MultiwaySharedTypes").MediaPath.SFU;
            case d("ZenonMWMessageTypes").ZenonMWMediaPath.P2P:
                return d("MultiwaySharedTypes").MediaPath.P2P;
            default:
                return d("MultiwaySharedTypes").MediaPath.UNKNOWN
        }
    }

    function r(a, b, c) {
        c === void 0 && (c = 0);
        var d = {
            fromVersion: b,
            tracks: [],
            version: c
        };
        a != null && Object.keys(a.tracks).forEach(function(b) {
            var c, e = a.tracks[b];
            c = {
                enabled: e.enabled,
                name: (c = e.name) != null ? c : "",
                participantID: (c = e.owner) != null ? c : "0",
                trackID: b,
                type: s(e.label)
            };
            d.tracks.push(c)
        });
        return d
    }

    function s(a) {
        if (a == null) return null;
        switch (a) {
            case d("WebrtcSignalingCommonTypes").TrackLabel.DEFAULT_AUDIO:
                return "audio";
            case d("WebrtcSignalingCommonTypes").TrackLabel.DEFAULT_VIDEO:
                return "video";
            case d("WebrtcSignalingCommonTypes").TrackLabel.SCREEN_AUDIO:
                return "screen_audio";
            case d("WebrtcSignalingCommonTypes").TrackLabel.SCREEN_VIDEO:
                return "screen";
            default:
                return null
        }
    }

    function t(a, b) {
        b = c("OverlayConfigServerLayer").createFromHeader(b);
        if (b) {
            b = {
                eventName: "overlayConfigServerUpdateRequest",
                serverLayer: b
            };
            a.push(b)
        }
    }

    function u(a) {
        var b = a.header,
            c = a.rtcMessageBody;
        a = a.type;
        b = z(b, a);
        a = {
            messageBody: c,
            messageHeader: b
        };
        return a
    }

    function v(a) {
        var b = a.header,
            c = a.rtcMessageBody,
            d = a.statusCode,
            e = a.subCode;
        a = a.type;
        b = G(b, a, d, e);
        a = {
            messageBody: c,
            messageHeader: b
        };
        return a
    }
    var w = {
        IN_ANOTHER_CALL: (i = d("MultiwayCommonTypes")).DeviceStatus.IN_ANOTHER_CALL,
        NO_OP: null,
        NOT_SUPPORTED: i.DeviceStatus.NOT_SUPPORTED,
        OK: i.DeviceStatus.OK
    };

    function x(a, b) {
        return Object.keys(a).map(function(c) {
            var e = a[c];
            return {
                body: {
                    genericMessage: {
                        data: d("RequestStreamBodyUtils").stringToUint8Array(e),
                        topic: c
                    }
                },
                header: {
                    recipients: new Set(b),
                    topic_DEPRECATED: c
                }
            }
        })
    }

    function y(a) {
        var b = a.clientSessionId,
            e = a.conferenceName,
            f = a.receiver,
            g = a.receiverUserId,
            h = a.sequenceNumber,
            i = a.serverInfoData,
            j = a.transactionId;
        if (g == null) throw c("err")("Incoming Thrift MW messages should have receiverUserId populated.");
        b = b;
        var k = {
            userID: "2"
        };
        j = {
            actorID: (f = f == null ? void 0 : f.actorId) != null ? f : null,
            messageID: j,
            messageTags: d("ZenonMWThriftMessageTagUtils").fromThriftMessageTags(a.messageTags),
            protocol: c("ZenonSignalingProtocol").MW,
            remoteInfo: k,
            retryCount: a.retryCount,
            roomInfo: {
                name: e
            },
            sequenceNumber: Number(h),
            signalingID: b,
            userInfo: {
                userID: (f = g) != null ? f : "1"
            }
        };
        i != null && (j.remoteSignalingID = i);
        return j
    }

    function z(a, b) {
        var e = a.messageID,
            f = a.messageTags,
            g = a.remoteSignalingID,
            h = a.roomInfo,
            i = a.signalingID,
            j = c("addDevTierOverridesToHeaderExtensions")(window.location.href);
        f = {
            clientStack: d("WebrtcSignalingCommonTypes").ClientStack.ZENON,
            conferenceName: (h = h.name) != null ? h : "",
            messageTags: new Set(f == null ? void 0 : f.map(function(a) {
                return d("ZenonMWThriftMessageTagUtils").toThriftMessageTag(a)
            })),
            retryCount: a.retryCount,
            sequenceNumber: (h = a.sequenceNumber) == null ? void 0 : h.toString(),
            transactionId: e,
            type: b
        };
        (j.multiwayCoreTier !== "" || j.multiwayWwwTier !== "") && (f.extensions = j);
        i != null && (f.clientSessionId = i);
        g != null && (f.serverInfoData = g);
        a.actorID != null && (f.sender = {
            id: a.actorID
        });
        return f
    }

    function A(a) {
        switch (a) {
            case d("ZenonDismissReason").ZenonDismissReason.IgnoreCall:
                return d("MultiwayCommonTypes").HangupReason.IGNORE_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.HangupCall:
                return d("MultiwayCommonTypes").HangupReason.HANGUP_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.NoAnswerTimeout:
                return d("MultiwayCommonTypes").HangupReason.NO_ANSWER_TIMEOUT;
            case d("ZenonDismissReason").ZenonDismissReason.ClientError:
                return d("MultiwayCommonTypes").HangupReason.CLIENT_ERROR;
            case d("ZenonDismissReason").ZenonDismissReason.InAnotherCall:
                return d("MultiwayCommonTypes").HangupReason.IN_ANOTHER_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.ClientInterrupted:
                return d("MultiwayCommonTypes").HangupReason.CLIENT_INTERRUPTED;
            case d("ZenonDismissReason").ZenonDismissReason.SessionMigrated:
                return d("MultiwayCommonTypes").HangupReason.SESSION_MIGRATED;
            default:
                return d("MultiwayCommonTypes").HangupReason.HANGUP_CALL
        }
    }

    function B(a) {
        a = (a = a.message.body) != null ? a : {};
        var b = a.dominantSpeakerSignalingInfo,
            c = a.genericMessage;
        a = a.videoUploadSignalingInfo;
        if (c) return d("RequestStreamBodyUtils").uint8ArrayToString(c.data);
        else if (b) return JSON.stringify(b);
        else if (a) return JSON.stringify(a);
        return null
    }

    function C(a) {
        a = (a = a.message.body) != null ? a : {};
        var b = a.dominantSpeakerSignalingInfo,
            c = a.genericMessage;
        a = a.videoUploadSignalingInfo;
        if (c) return c.topic;
        else if (b) return k;
        else if (a) return l;
        return null
    }

    function D(a) {
        if (a == null) return null;
        if (a === 1) return d("MultiwaySharedTypes").EndpointServiceType.COMPOSITING_SERVICE;
        else return d("MultiwaySharedTypes").EndpointServiceType.UNKNOWN
    }

    function E(a) {
        a = F(a);
        return (a = a) != null ? a : d("ZenonDismissReason").ZenonDismissReason.CallEnded
    }

    function F(a) {
        if (a == null) return null;
        switch (a) {
            case d("MultiwayCommonTypes").DismissReason.CALL_ENDED:
                return d("ZenonDismissReason").ZenonDismissReason.CallEnded;
            case d("MultiwayCommonTypes").DismissReason.ANSWERED_ON_ANOTHER_DEVICE:
                return d("ZenonDismissReason").ZenonDismissReason.AnsweredOnAnotherDevice;
            case d("MultiwayCommonTypes").DismissReason.ANSWERED_BY_OTHER_USER:
                return d("ZenonDismissReason").ZenonDismissReason.AnsweredByOtherUser;
            case d("MultiwayCommonTypes").DismissReason.IN_ANOTHER_CALL:
                return d("ZenonDismissReason").ZenonDismissReason.InAnotherCall;
            case d("MultiwayCommonTypes").DismissReason.CONNECTION_DROPPED:
                return d("ZenonDismissReason").ZenonDismissReason.ConnectionDropped;
            case d("MultiwayCommonTypes").DismissReason.PRIMARY_ENDPOINT_HANGUP:
                return d("ZenonDismissReason").ZenonDismissReason.HangupCall;
            case d("MultiwayCommonTypes").DismissReason.REJECTED_ON_ANOTHER_DEVICE:
                return d("ZenonDismissReason").ZenonDismissReason.RejectedOnAnotherDevice;
            case d("MultiwayCommonTypes").DismissReason.REMOVED_BY_PARTICIPANT:
                return d("ZenonDismissReason").ZenonDismissReason.RemovedByParticipant;
            case d("MultiwayCommonTypes").DismissReason.REJECTED_BY_CALLEE:
                return d("ZenonDismissReason").ZenonDismissReason.RejectedByCallee;
            case d("MultiwayCommonTypes").DismissReason.INTERNAL_ERROR:
                return d("ZenonDismissReason").ZenonDismissReason.SignalingMessageFailed;
            case d("MultiwayCommonTypes").DismissReason.CALL_ENDED_BY_PRODUCT:
                return d("ZenonDismissReason").ZenonDismissReason.CallEndedByProduct;
            case d("MultiwayCommonTypes").DismissReason.TX_ACK_TIMEDOUT:
                return d("ZenonDismissReason").ZenonDismissReason.TxAckTimeout;
            default:
                return null
        }
    }

    function G(a, b, c, e) {
        a = z(a, b);
        a.responseStatusCode = (b = c) != null ? b : d("MultiwayCommonTypes").RtcResponseStatusCode.OK;
        a.responseSubCode = e;
        return a
    }

    function H(a) {
        var b = {},
            c = !d("ZenonScreenShare").screenShareWithReplaceTrack();
        a.tracks.forEach(function(a) {
            var e = {
                    customAudioContentType: d("WebrtcSignalingCommonTypes").CustomAudioContentType.NONE,
                    customVideoContentType: d("WebrtcSignalingCommonTypes").CustomVideoContentType.NONE,
                    enabled: a.enabled
                },
                f = c ? N(a.type) : null;
            f != null && (e.label = f);
            b[a.trackID] = e
        });
        return {
            tracks: b
        }
    }

    function I(a) {
        a = w[a];
        return (a = a) != null ? a : d("MultiwayCommonTypes").DeviceStatus.OK
    }

    function J(a) {
        var b = {};
        a.tracks.forEach(function(a) {
            b[a.trackID] = a.enabled
        });
        return b
    }

    function K(a) {
        return P[a]
    }

    function L(a) {
        return a == null ? null : Q[a]
    }

    function M(a) {
        var b = {};
        a.forEach(function(a, c) {
            b[c] = {
                data: a.data,
                version: a.version
            }
        });
        return b
    }

    function N(a) {
        switch (a) {
            case "audio":
                return d("WebrtcSignalingCommonTypes").TrackLabel.DEFAULT_AUDIO;
            case "video":
                return d("WebrtcSignalingCommonTypes").TrackLabel.DEFAULT_VIDEO;
            case "screen":
                return d("WebrtcSignalingCommonTypes").TrackLabel.SCREEN_VIDEO;
            case "screen_audio":
                return d("WebrtcSignalingCommonTypes").TrackLabel.SCREEN_AUDIO;
            default:
                return null
        }
    }

    function O(a) {
        if (a === d("MultiwaySharedTypes").EndpointServiceType.COMPOSITING_SERVICE) return 1;
        else return 0
    }
    var P = Object.freeze((h = {}, h[(j = d("ZenonSignalingTypes")).ZenonSignalingStatusCode.OK] = i.RtcResponseStatusCode.OK, h[j.ZenonSignalingStatusCode.REJECTED_FROM_VERSION_DOES_NOT_MATCH] = i.RtcResponseStatusCode.CONDITIONAL_REQUEST_FAILED, h[j.ZenonSignalingStatusCode.METHOD_NOT_ALLOWED] = i.RtcResponseStatusCode.METHOD_NOT_ALLOWED, h)),
        Q = Object.freeze((h = {}, h[j.ZenonSignalingStatusSubCode.CLIENT_TERMINATED] = i.RtcResponseSubCode.CLIENT_TERMINATED, h));
    g.addThriftStateStoreSignalingEvents = a;
    g.fetchE2eeServerState = b;
    g.fromThriftMediaPath = e;
    g.fromThriftParticipantState = f;
    g.getCollisionContextFromThriftAppMessages = n;
    g.getRoomMetadataFromThriftAppMessages = o;
    g.mwThriftAppMessagesToSignalingAppMessages = p;
    g.toThriftMediaPath = q;
    g.toZenonMediaStatesFromThrift = r;
    g.toMWClientTrackContentTypeFromThrift = s;
    g.maybeAddOverlayConfigServerUpdateRequestFromThrift = t;
    g.createMWThriftRequest = u;
    g.createMWThriftResponse = v;
    g.signalingMessageAppMessagesToThriftMWAppMessages = x;
    g.mwThriftMessageHeaderToSignalingMessageHeader = y;
    g.toMWThriftHangupReason = A;
    g.getGenericMWThriftDataMessageData = B;
    g.getGenericMWThriftDataMessageTopic = C;
    g.toThriftServiceRecipient = D;
    g.fromMWThriftDismissReason = E;
    g.toThriftMWMediaStatusEx = H;
    g.toMWThriftDeviceStatus = I;
    g.toMWThriftMediaStatus = J;
    g.toMWThriftResponseStatusCode = K;
    g.toMWThriftResponseStatusSubCode = L;
    g.toThriftMWSyncStateStore = M;
    g.toMWThriftTrackLabel = N;
    g.toServiceRecipientType = O
}), 98);
__d("ZenonMWThriftMessageDebugLogger", ["Log", "LogHistory", "MultiwayCommonTypes", "ODS", "RequestStreamBodyUtils", "RpWebStateMachineLoggingBlocklist", "ZenonAuditedCheckpointLogId", "ZenonIceStatsParser", "ZenonInfraActionsLogger", "ZenonMWThriftMessageMap", "ZenonMWThriftTranslatorUtils", "formatDate", "isEmployeeTestUserZenonLogging"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function() {
        function a() {
            this.$1 = d("LogHistory").getInstance("webrtc"), this.$2 = new Set(c("RpWebStateMachineLoggingBlocklist").MESSAGE_TYPES)
        }
        var b = a.prototype;
        b.$3 = function(a, b, d) {
            b === void 0 && (b = !0);
            var e = c("formatDate")(new Date(), "[H:i:s:X]", {
                skipPatternLocalization: !0
            });
            this.$1.log("Console", e + " " + a);
            b && c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "[ZP] " + a,
                messageID: d
            })
        };
        b.$4 = function(a) {
            a = a.messageHeader.responseStatusCode;
            return a != null
        };
        b.logMWThriftMessage = function(a, b, e) {
            this.$5(a, b, e);
            if (!c("isEmployeeTestUserZenonLogging")()) return;
            var f = e.messageHeader,
                g = d("ZenonMWThriftMessageMap").messageTypeToString(e.messageHeader.type),
                h = this.$4(e) ? "RESPONSE" : "REQUEST";
            e = this.$6(e);
            a = "[ms] " + a + " [" + b + "] " + g + " " + h + " [retryCount: " + f.retryCount + (e != null ? " details: " + e : "") + "]";
            this.$2.has(g) || this.$3(a, !0, f.transactionId)
        };
        b.$5 = function(a, b, c) {
            a = this.$7(a, b, c);
            a !== null && (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_signaling", a)
        };
        b.$7 = function(a, b, c) {
            var e = c.messageBody,
                f = c.messageHeader,
                g = "";
            if (f.type != null) switch (f.type) {
                case d("MultiwayCommonTypes").MessageType.DATA_MESSAGE:
                    if (e.dataMessageRequest) {
                        g = (e = d("ZenonMWThriftTranslatorUtils").getGenericMWThriftDataMessageTopic(e.dataMessageRequest)) != null ? e : "undefined"
                    }
                    break;
                default:
                    break
            }
            e = this.$4(c) ? "RESPONSE" : "REQUEST";
            c = d("ZenonMWThriftMessageMap").messageTypeToString(f.type);
            if (g === "") return a + "-" + b + "-" + c + "-" + e;
            else return a + "-" + b + "-" + c + "-" + e + "-" + g
        };
        b.$6 = function(a) {
            var b = a.messageHeader;
            if (d("MultiwayCommonTypes").MessageType == null || b.type == null) return null;
            switch (b.type) {
                case d("MultiwayCommonTypes").MessageType.JOIN:
                    return this.$8(a);
                case d("MultiwayCommonTypes").MessageType.SERVER_MEDIA_UPDATE:
                    return this.$9(a);
                case d("MultiwayCommonTypes").MessageType.CLIENT_MEDIA_UPDATE:
                    return this.$10(a);
                case d("MultiwayCommonTypes").MessageType.SUBSCRIPTION:
                    return this.$11(a);
                case d("MultiwayCommonTypes").MessageType.ICE_CANDIDATE:
                    return this.$12(a);
                default:
                    return null
            }
        };
        b.$8 = function(a) {
            var b = a.messageBody,
                c = a.messageHeader;
            if (this.$4(a)) {
                return JSON.stringify({
                    hasAnswer: ((a = b.joinResponse) == null ? void 0 : a.answer) != null,
                    hasRenegotiationOffer: ((a = b.joinResponse) == null ? void 0 : a.renegotiationOffer) != null,
                    isPendingApproval: (a = b.joinResponse) == null ? void 0 : a.isPendingApproval,
                    multipleVideoStreamsAllowed: (a = b.joinResponse) == null ? void 0 : a.multipleVideoStreamsAllowed,
                    statusCode: c.responseStatusCode,
                    subCode: c.responseSubCode
                })
            }
            return JSON.stringify({
                deviceCapabilities: (a = b.joinRequest) == null ? void 0 : a.deviceCapabilities,
                sdpType: ((c = b.joinRequest) == null ? void 0 : c.offer) != null ? "offer" : ((a = b.joinRequest) == null ? void 0 : a.answer) != null ? "answer" : "null",
                userCapabilities: ((c = b.joinRequest) == null ? void 0 : c.userCapabilities) ? d("RequestStreamBodyUtils").uint8ArrayToString(b.joinRequest.userCapabilities) : ""
            })
        };
        b.$9 = function(a) {
            var b = a.messageBody,
                c = a.messageHeader;
            if (this.$4(a)) {
                return JSON.stringify({
                    currentVersion: (a = b.serverMediaUpdateResponse) == null ? void 0 : a.currentVersion,
                    hasAnswer: ((a = b.serverMediaUpdateResponse) == null ? void 0 : a.answer) != null,
                    statusCode: c.responseStatusCode,
                    subCode: c.responseSubCode
                })
            }
            return JSON.stringify({
                fromVersion: (a = b.serverMediaUpdateRequest) == null ? void 0 : a.fromVersion,
                messageTags: c.messageTags,
                renegotiationRequested: (c = (a = b.serverMediaUpdateRequest) == null ? void 0 : a.renegotiationRequested) != null ? c : !1,
                sdpType: ((a = b.serverMediaUpdateRequest) == null ? void 0 : a.offer) ? "offer" : ((c = b.serverMediaUpdateRequest) == null ? void 0 : c.answer) ? "answer" : ((a = b.serverMediaUpdateRequest) == null ? void 0 : a.update) ? "delta" : "empty",
                toVersion: (a = (c = b.serverMediaUpdateRequest) == null ? void 0 : c.toVersion) != null ? a : ""
            })
        };
        b.$10 = function(a) {
            var b = a.messageBody,
                c = a.messageHeader;
            if (this.$4(a)) {
                return JSON.stringify({
                    currentVersion: (a = (a = b.clientMediaUpdateResponse) == null ? void 0 : a.currentVersion) != null ? a : "",
                    statusCode: c.responseStatusCode,
                    subCode: c.responseSubCode
                })
            }
            return JSON.stringify({
                fromVersion: (c = (a = b.clientMediaUpdateRequest) == null ? void 0 : a.fromVersion) != null ? c : "",
                toVersion: (c = (a = b.clientMediaUpdateRequest) == null ? void 0 : a.toVersion) != null ? c : ""
            })
        };
        b.$11 = function(a) {
            var b = a.messageBody;
            return this.$4(a) ? null : JSON.stringify({
                subscriptions: (b = (a = b.subscriptionRequest) == null ? void 0 : a.subscriptions) != null ? b : ""
            })
        };
        b.$12 = function(a) {
            var b = a.messageBody;
            if (this.$4(a)) return null;
            b = (a = b.iceCandidateRequest) == null ? void 0 : a.iceCandidateSdps.map(function(a) {
                a = a.candidateSdpString;
                if (a != null) return d("ZenonIceStatsParser").extractIceInfo(a)
            });
            return JSON.stringify({
                iceCandidates: b
            })
        };
        b.logSendMultiwayThriftMessageFailure = function(a, b) {
            (h || (h = d("ODS"))).bumpEntityKey(4083, "zenon_multiway", "send_message_failure"), h.flush(), c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                checkpoint: "Failed to send MW Thrift message of type " + b + ". Error msg: " + a + ":"
            })
        };
        return a
    }();
    b = new a();
    g["default"] = b
}), 98);
__d("ZenonMWThriftMessageSerializer", ["CompactSerializer", "MqttThriftHeaderSerializers", "MultiwayCommonSerializers", "TCompactProtocol", "TReadBuffer"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b === void 0 && (b = !1);
        var c = d("CompactSerializer").serialize(a.messageHeader, d("MultiwayCommonSerializers").serializeRtcMessageHeader);
        a = d("CompactSerializer").serialize(a.messageBody, d("MultiwayCommonSerializers").serializeRtcMessageBody);
        if (b) {
            b = new Uint8Array(c.length + a.length);
            b.set(c);
            b.set(a, c.length);
            return b
        }
        b = {};
        b = d("CompactSerializer").serialize(b, d("MqttThriftHeaderSerializers").serializeMqttThriftHeader);
        var e = new Uint8Array(b.length + c.length + a.length);
        e.set(b);
        e.set(c, b.length);
        e.set(a, b.length + c.length);
        return e
    }

    function b(a, b) {
        b === void 0 && (b = !1);
        a = new(c("TReadBuffer"))(a);
        a = new(c("TCompactProtocol"))(a);
        b || d("MqttThriftHeaderSerializers").deserializeMqttThriftHeader(a);
        b = d("MultiwayCommonSerializers").deserializeRtcMessageHeader(a);
        a = d("MultiwayCommonSerializers").deserializeRtcMessageBody(a);
        return {
            messageBody: a,
            messageHeader: b
        }
    }
    g.serializeMWThriftMessage = a;
    g.deserializeMWThriftMessage = b
}), 98);
__d("ZenonMWThriftAddParticipantsTranslator", ["MultiwayCommonTypes", "RequestStreamBodyUtils", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "new_room_context";

    function a(a, b) {
        var c = {
            usersToInvite: new Set(b.participants)
        };
        if (b.groupThreadId != null) {
            b = {
                calling_tags: 2,
                group_thread_id: b.groupThreadId
            };
            if (b) {
                b = [{
                    body: {
                        genericMessage: {
                            data: d("RequestStreamBodyUtils").stringToUint8Array(JSON.stringify(b)),
                            topic: h
                        }
                    },
                    header: {
                        topic_DEPRECATED: h
                    }
                }];
                c.appMessages = b
            }
        }
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                addParticipantsRequest: c
            },
            type: d("MultiwayCommonTypes").MessageType.ADD_PARTICIPANTS
        })
    }
    g.NEW_ROOM_CONTEXT = h;
    g.toThriftAddParticipantsRequest = a
}), 98);
__d("ZenonMWThriftApprovalTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = b.approvalStatus;
        b = b.targetUsers;
        c = {
            approvalStatus: c === 0 ? d("MultiwayCommonTypes").ApprovalStatus.DENIED : d("MultiwayCommonTypes").ApprovalStatus.APPROVED,
            targetUsers: new Set(b)
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                approvalRequest: c
            },
            type: d("MultiwayCommonTypes").MessageType.APPROVAL
        })
    }
    g.toThriftApprovalRequest = a
}), 98);
__d("ZenonMWThriftClientEventTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = {
            clientEvents: [{
                type: b.clientEventType === 0 ? d("MultiwayCommonTypes").ClientEventType.UNKNOWN : d("MultiwayCommonTypes").ClientEventType.MEDIA_CONNECTED
            }]
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                clientEventRequest: b
            },
            type: d("MultiwayCommonTypes").MessageType.CLIENT_EVENT
        })
    }
    g.toThriftClientEventRequest = a
}), 98);
__d("ZenonMWThriftClientMediaUpdateTranslator", ["MultiwayCommonTypes", "ZenonMWCommonUtils", "ZenonMWThriftResponseStatusCodeUtils", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            c = a.messageBody;
        a = a.messageHeader;
        c = c.clientMediaUpdateResponse;
        var e = a.responseStatusCode,
            f = a.responseSubCode,
            g = a.retryAfterMsec;
        if (c) {
            var h = c.answer,
                i = c.mediaStatus,
                j = h != null && i != null;
            d("ZenonMWThriftTranslatorUtils").addThriftStateStoreSignalingEvents(c.stateStore, b, !1, j);
            var k = d("ZenonMWThriftTranslatorUtils").fetchE2eeServerState(c.stateStore);
            if (j) {
                h = (j = h == null ? void 0 : h.sdpString) != null ? j : "";
                j = d("ZenonMWThriftTranslatorUtils").toZenonMediaStatesFromThrift(i);
                i = {
                    ackMessageId: a.transactionId,
                    eventName: "localSdpResponse",
                    hasAnswerInJoinResponse: !1,
                    source: "clientMediaUpdate"
                };
                var l = c.renegotiationOffer,
                    m = null;
                l != null && l.sdpString != null && (m = {
                    sdp: l.sdpString,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(l.sdpString)
                });
                l = {
                    e2eeServerState: k,
                    eventName: "remoteSdpRequest",
                    mediaPath: d("ZenonMWThriftTranslatorUtils").fromThriftMediaPath(c.mediaPath),
                    mediaStates: j,
                    negotiateType: !1,
                    renegotiationOffer: m,
                    sdp: {
                        sdp: h,
                        type: "answer",
                        version: d("ZenonMWCommonUtils").getSdpVersion(h)
                    },
                    sdpOriginLocalId: c.sdpOriginLocalId,
                    source: "clientMediaUpdateResponse"
                };
                b.push(i);
                b.push(l)
            }
            j = {
                ackMessageId: a.transactionId,
                acknowledgedVersion: Number(c.currentVersion),
                eventName: "mediaUpdateResponse",
                retryAfter: (k = g) != null ? k : 0
            };
            e != null && (j.responseStatusCode = d("ZenonMWThriftResponseStatusCodeUtils").getResponseStatusCodeFromThrift(e));
            f != null && (j.responseSubCode = d("ZenonMWThriftResponseStatusCodeUtils").getResponseSubCodeFromThrift(f));
            b.push(j)
        }
        return b
    }

    function b(a, b, c) {
        b = {
            fromVersion: String(b.version),
            mediaUpdates: [{
                mediaStatus: d("ZenonMWThriftTranslatorUtils").toMWThriftMediaStatus(b),
                mediaStatusEx: d("ZenonMWThriftTranslatorUtils").toThriftMWMediaStatusEx(b)
            }],
            toVersion: String(b.version)
        };
        c !== void 0 && (b.offer = {
            sdpString: c.sdp
        });
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                clientMediaUpdateRequest: b
            },
            type: d("MultiwayCommonTypes").MessageType.CLIENT_MEDIA_UPDATE
        })
    }
    g.fromThriftClientMediaUpdateResponse = a;
    g.toThriftClientMediaUpdateRequest = b
}), 98);
__d("ZenonMWThriftConferenceStateTranslator", ["MultiwayCommonTypes", "RequestStreamBodyUtils", "ZenonMWMessageTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            c = a.messageBody.conferenceStateRequest;
        if (c) {
            var e = c.appMessages,
                f = c.participantStates,
                g = {
                    eventName: "participantUpdateRequest",
                    participantStates: new Map(),
                    sctpUserIdNodeIdMap: new Map(),
                    versionId: +c.version
                },
                h = {
                    actorRepresentatives: new Map(),
                    eventName: "clientInfoRequest",
                    mediaPath: d("ZenonMWMessageTypes").ZenonMWMediaPath.UNKNOWN,
                    userCapabilities: new Map()
                };
            Object.keys(f).forEach(function(a) {
                var b = f[a],
                    c = b.sctpNodeId,
                    e = b.state;
                b = b.userCapabilities;
                g.participantStates.set(a, d("ZenonMWThriftTranslatorUtils").fromThriftParticipantState(e));
                c != null && g.sctpUserIdNodeIdMap.set(a, +c);
                h.userCapabilities.set(a, b ? d("RequestStreamBodyUtils").uint8ArrayToString(b) : "")
            });
            b.push(g);
            b.push(h);
            c = d("ZenonMWThriftTranslatorUtils").getCollisionContextFromThriftAppMessages(e);
            if (c) {
                c.serverInfoData = a.messageHeader.serverInfoData;
                e = {
                    context: c,
                    eventName: "roomContextUpdateRequest"
                };
                b.push(e)
            }
        }
        return b
    }

    function b(a, b) {
        b = {
            currentVersion: String(b.requestVersionId)
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: a,
            rtcMessageBody: {
                conferenceStateResponse: b
            },
            type: d("MultiwayCommonTypes").MessageType.CONFERENCE_STATE
        })
    }
    g.fromThriftConferenceStateRequest = a;
    g.toThriftConferenceStateResponse = b
}), 98);
__d("ZenonMWThriftDataMessageTranslator", ["MultiwayCommonTypes", "RequestStreamBodyUtils", "ZenonActorHooks", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.messageBody.dataMessageRequest;
        if (a) {
            var c = a.message.header,
                e = d("ZenonMWThriftTranslatorUtils").getGenericMWThriftDataMessageData(a);
            a = d("ZenonMWThriftTranslatorUtils").getGenericMWThriftDataMessageTopic(a);
            var f = h(c.serviceRecipients);
            if (e != null && a != null) {
                c = {
                    data: e,
                    eventName: "genericDataMessageRequest",
                    recipientIDs: Array.from((e = c.recipients) != null ? e : []),
                    serviceRecipients: f,
                    topic: a
                };
                b.push(c)
            }
        }
        return b
    }

    function b(a, b) {
        var c = {
                data: d("RequestStreamBodyUtils").stringToUint8Array(b.data),
                topic: b.topic
            },
            e = new Set(b.serviceRecipients.map(d("ZenonMWThriftTranslatorUtils").toThriftServiceRecipient));
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                dataMessageRequest: {
                    message: {
                        body: {
                            genericMessage: c
                        },
                        header: {
                            recipients: new Set(b.recipientIDs),
                            sender: d("ZenonActorHooks").ZenonActor.getID(),
                            serviceRecipients: e,
                            topic_DEPRECATED: ""
                        }
                    }
                }
            },
            type: d("MultiwayCommonTypes").MessageType.DATA_MESSAGE
        })
    }

    function c(a) {
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: a,
            rtcMessageBody: {
                dataMessageResponse: {
                    deliveryResult: {}
                }
            },
            type: d("MultiwayCommonTypes").MessageType.DATA_MESSAGE
        })
    }

    function h(a) {
        var b = [];
        a == null ? void 0 : a.forEach(function(a) {
            return b.push(d("ZenonMWThriftTranslatorUtils").toServiceRecipientType(a))
        });
        return b
    }
    g.fromThriftDataMessageRequest = a;
    g.toThriftDataMessageRequest = b;
    g.toThriftDataMessageResponse = c
}), 98);
__d("ZenonMWThriftDismissTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.messageBody.dismissRequest;
        if (a) {
            var c = a.detailedReasonString;
            a = a.reason;
            a = {
                eventName: "terminateRequest",
                fromJoinResponse: !1,
                reason: d("ZenonMWThriftTranslatorUtils").fromMWThriftDismissReason(a),
                shouldInformPeer: !0,
                subreason: c
            };
            b.push(a)
        }
        return b
    }

    function b(a) {
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: a,
            rtcMessageBody: {},
            type: d("MultiwayCommonTypes").MessageType.DISMISS
        })
    }
    g.fromThriftDismissRequest = a;
    g.toThriftDismissResponse = b
}), 98);
__d("ZenonMWThriftHangupTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.messageHeader;
        a = {
            ackMessageId: a.transactionId,
            eventName: "hangupResponse"
        };
        b.push(a);
        return b
    }

    function b(a, b) {
        b = b.reason;
        b = {
            detailedReasonString: "",
            reason: d("ZenonMWThriftTranslatorUtils").toMWThriftHangupReason(b)
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                hangupRequest: b
            },
            type: d("MultiwayCommonTypes").MessageType.HANGUP
        })
    }
    g.fromThriftHangupResponse = a;
    g.toThriftHangupRequest = b
}), 98);
__d("ZenonMWThriftIceCandidateTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.messageBody.iceCandidateRequest;
        if (a) {
            a = {
                eventName: "iceCandidateRequest",
                iceCandidates: a.iceCandidateSdps.map(function(a) {
                    var b;
                    return {
                        candidateSdpString: (b = a.candidateSdpString) != null ? b : "",
                        sdpMid: a.sdpMid,
                        sdpMLineIndex: parseInt(a.sdpMLineIndex, 10)
                    }
                })
            };
            b.push(a)
        }
        return b
    }

    function b(a) {
        var b = [];
        a = a.messageHeader;
        a = {
            ackMessageId: a.transactionId,
            eventName: "iceCandidateResponse"
        };
        b.push(a);
        return b
    }

    function c(a) {
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: a,
            rtcMessageBody: {},
            type: d("MultiwayCommonTypes").MessageType.ICE_CANDIDATE
        })
    }

    function e(a, b) {
        b = b.iceCandidates;
        b = b.map(function(a) {
            return {
                candidateSdpString: a.candidateSdpString,
                sdpMid: a.sdpMid,
                sdpMLineIndex: a.sdpMLineIndex.toString()
            }
        });
        b = {
            iceCandidateSdps: b
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                iceCandidateRequest: b
            },
            type: d("MultiwayCommonTypes").MessageType.ICE_CANDIDATE
        })
    }
    g.fromThriftIceCandidateRequest = a;
    g.fromThriftIceCandidateResponse = b;
    g.toThriftIceCandidateResponse = c;
    g.toThriftIceCandidateRequest = e
}), 98);
__d("ZenonMWThriftJoinTranslator", ["MultiwayCommonTypes", "MultiwaySharedTypes", "RequestStreamBodyUtils", "RoboticsPermission", "ZenonAuditedCheckpointLogId", "ZenonDismissReason", "ZenonInfraActionsLogger", "ZenonJoiningContext", "ZenonMWCommonUtils", "ZenonMWJoinUtils", "ZenonMWThriftTranslatorUtils", "ZenonScreenShare", "gkx", "justknobx", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            e = a.messageHeader,
            f = e.responseStatusCode,
            g = e.responseSubCode;
        if (f && f !== d("MultiwayCommonTypes").RtcResponseStatusCode.OK) {
            var i;
            g = "JOIN response status code: " + String(f) + " subcode " + String((g = g) != null ? g : "[undefined]");
            c("ZenonInfraActionsLogger").logError({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                callType: "mw",
                checkpoint: "[ZP] Got non-OK " + g,
                errorDomain: "ZenonMWThriftMessageTranslator.fromThriftJoinResponse"
            });
            i = {
                detailedReasonFromMW: (i = e.responseStatusMessage) != null ? i : "",
                eventName: "terminateRequest",
                fromJoinResponse: !0,
                reason: h(f, e.responseSubCode),
                shouldInformPeer: !1,
                subreason: g
            };
            b.push(i);
            return b
        }
        f = a.messageBody.joinResponse;
        if (!f) return b;
        a = (i = (g = f.answer) == null ? void 0 : g.sdpString) != null ? i : "";
        g = a !== "";
        d("ZenonMWThriftTranslatorUtils").addThriftStateStoreSignalingEvents(f.stateStore, b, !1, g);
        d("ZenonMWThriftTranslatorUtils").maybeAddOverlayConfigServerUpdateRequestFromThrift(b, e);
        i = d("ZenonMWThriftTranslatorUtils").fetchE2eeServerState(f.stateStore);
        e = {
            ackMessageId: e.transactionId,
            eventName: "localSdpResponse",
            hasAnswerInJoinResponse: g,
            source: "joinResponse"
        };
        b.push(e);
        if (g) {
            e = {
                sdp: a,
                type: "answer",
                version: d("ZenonMWCommonUtils").getSdpVersion(a)
            };
            g = d("ZenonMWThriftTranslatorUtils").toZenonMediaStatesFromThrift(f.mediaStatusEx);
            a = f.renegotiationOffer;
            var j = null;
            a != null && a.sdpString != null && (j = {
                sdp: a.sdpString,
                type: "offer",
                version: d("ZenonMWCommonUtils").getSdpVersion(a.sdpString)
            });
            a = {
                e2eeServerState: i,
                eventName: "remoteSdpRequest",
                mediaPath: d("ZenonMWThriftTranslatorUtils").fromThriftMediaPath(f.mediaPath),
                mediaStates: g,
                negotiateType: !1,
                renegotiationOffer: j,
                sdp: e,
                sdpOriginLocalId: f.sdpOriginLocalId,
                source: "joinResponse"
            };
            b.push(a)
        }
        i = {
            capabilities: {
                addParticipantEnabled: !0,
                cowatchEnabled: !0,
                cowatchGroupEnabled: !0,
                multipleVideoStreamsAllowed: f.multipleVideoStreamsAllowed
            },
            eventName: "capabilitiesRequest"
        };
        b.push(i);
        if (f.isPendingApproval) {
            g = {
                eventName: "pendingApprovalRequest"
            };
            b.push(g)
        }
        j = f.groupsOfUsers;
        var k = new Map();
        j.forEach(function(a) {
            var b = a.aliasId;
            a = a.users;
            b != null && a.forEach(function(a) {
                k.set(a, b)
            })
        });
        e = {
            actorRepresentatives: k,
            eventName: "clientInfoRequest",
            mediaPath: d("ZenonMWThriftTranslatorUtils").fromThriftMediaPath(f.mediaPath),
            userCapabilities: new Map()
        };
        b.push(e);
        return b
    }

    function b(a, b, e, f) {
        var g = b.initialSyncStates,
            h = b.isSecondaryJoinRole,
            j = b.userCapabilities;
        j = {
            clientMediaMode: e.mediaMode === "p2p" ? d("MultiwaySharedTypes").MediaPath.P2P : d("MultiwaySharedTypes").MediaPath.SFU,
            deviceCapabilities: new Set([d("MultiwayCommonTypes").Capability.SUPPORT_NEW_PARTICIPANT_STATES, d("MultiwayCommonTypes").Capability.REQUIRE_FULL_SDP_IN_SMU, d("MultiwayCommonTypes").Capability.SUPPORT_SDP_RENEGOTIATION, d("MultiwayCommonTypes").Capability.REQUIRE_FULL_SDP_IN_SMU_OPTIMIZED].concat(c("justknobx")._("1853") ? [d("MultiwayCommonTypes").Capability.SUPPORT_DELTA_SMU] : [], c("gkx")("25225") ? [d("MultiwayCommonTypes").Capability.SUPPORT_PRECONNECT] : [])),
            mediaStatus: d("ZenonMWThriftTranslatorUtils").toMWThriftMediaStatus(e.mediaStates),
            mediaStatusEx: d("ZenonMWThriftTranslatorUtils").toThriftMWMediaStatusEx(e.mediaStates),
            offer: {},
            syncPayload: g ? {
                stateStore: d("ZenonMWThriftTranslatorUtils").toThriftMWSyncStateStore(g),
                stateStoreV2: {}
            } : void 0,
            userCapabilities: d("RequestStreamBodyUtils").stringToUint8Array((g = j.get(a.userInfo.userID)) != null ? g : "")
        };
        h != null && (j.endpointSettings = {
            joinMode: h ? d("MultiwayCommonTypes").JoinMode.SECONDARY : d("MultiwayCommonTypes").JoinMode.PRIMARY
        });
        g = b.isE2eeMandated === !0;
        j.e2eeEnforcement = {
            infraMandatedExpStatus: b.e2eeInfraMandatedExpStatus,
            mode: g ? d("MultiwaySharedTypes").E2eeMode.E2EE_MANDATED : d("MultiwaySharedTypes").E2eeMode.E2EE_NOT_MANDATED,
            preventSfuMode: !1
        };
        e.sdp.type === "offer" && (j.offer = {
            sdpString: e.sdp.sdp
        });
        d("ZenonMWJoinUtils").canUseMwpp(e.sdp.type) && (j.deviceCapabilities.add(d("MultiwayCommonTypes").Capability.SUPPORT_MWPP), e.sdp.type === "answer" && (j.answer = {
            sdpString: e.sdp.sdp
        }), d("ZenonMWJoinUtils").canDeescalate() && j.deviceCapabilities.add(d("MultiwayCommonTypes").Capability.SUPPORT_MWPP_DEESCALATION));
        (!d("ZenonScreenShare").screenShareWithReplaceTrack() || c("RoboticsPermission").is_authorized_robot) && j.deviceCapabilities.add(d("MultiwayCommonTypes").Capability.SUPPORT_MULTIPLE_VIDEO_STREAMS);
        h = f == null ? void 0 : f.otherParticipants;
        h && (j.usersToCall = new Set(h));
        b = [];
        e = (e = f == null ? void 0 : f.roomInfo.context) != null ? e : a.roomInfo.context;
        if (e != null) {
            var k = d("ZenonJoiningContext").convertCollisionToJoiningContext(e);
            g && (k.calling_tags = 2);
            b = [].concat(b, [{
                body: {
                    genericMessage: {
                        data: d("RequestStreamBodyUtils").stringToUint8Array(JSON.stringify(k)),
                        topic: d("ZenonJoiningContext").JOINING_CONTEXT_TOPIC
                    }
                },
                header: {
                    topic_DEPRECATED: d("ZenonJoiningContext").JOINING_CONTEXT_TOPIC
                }
            }])
        }(f == null ? void 0 : f.appMessages) != null && (b = [].concat(b, d("ZenonMWThriftTranslatorUtils").signalingMessageAppMessagesToThriftMWAppMessages(f.appMessages, h)));
        j.appMessages = b;
        g = d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                joinRequest: j
            },
            type: d("MultiwayCommonTypes").MessageType.JOIN
        });
        e && e.serverInfoData != null && (g.messageHeader.serverInfoData = e.serverInfoData);
        i(e, g.messageHeader) && (g.messageHeader.conferenceType = d("MultiwaySharedTypes").ConferenceType.ROOM);
        return g
    }

    function h(a, b) {
        if (b === d("MultiwayCommonTypes").RtcResponseSubCode.EXCEEDED_MAX_ALLOWED_PARTICIPANTS) return d("ZenonDismissReason").ZenonDismissReason.MaxAllowedParticipantsReached;
        if (b === d("MultiwayCommonTypes").RtcResponseSubCode.PRODUCT_SERVER_DEFINED_END_REASON) return d("ZenonDismissReason").ZenonDismissReason.ProductServerDefinedEndReason;
        switch (a) {
            case d("MultiwayCommonTypes").RtcResponseStatusCode.METHOD_NOT_ALLOWED:
            case d("MultiwayCommonTypes").RtcResponseStatusCode.UNAUTHORIZED:
                return d("ZenonDismissReason").ZenonDismissReason.NoPermission;
            case d("MultiwayCommonTypes").RtcResponseStatusCode.SERVICE_UNAVAILABLE:
                return d("ZenonDismissReason").ZenonDismissReason.SignalingMessageFailed;
            case d("MultiwayCommonTypes").RtcResponseStatusCode.OK:
                throw c("unrecoverableViolation")("Response status code is OK; should not return a dismiss reason", "rtc_www");
            default:
                c("ZenonInfraActionsLogger").logError({
                    auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                    callType: "mw",
                    error: "[ZP] Got unexpected JOIN response status: " + String(a) + " subcode " + String((a = b) != null ? a : "[undefined]"),
                    errorDomain: "fromMWThriftJoinResponseStatusToDismissReason"
                });
                return d("ZenonDismissReason").ZenonDismissReason.UnexpectedEndOfCall
        }
    }

    function i(a, b) {
        return ((a == null ? void 0 : a.peerID) != null || (a == null ? void 0 : a.groupThreadID) != null) && b.conferenceName === ""
    }
    g.fromThriftJoinResponse = a;
    g.toThriftJoinRequest = b
}), 98);
__d("ZenonMWThriftPingTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.messageHeader;
        a = {
            ackMessageId: a.transactionId,
            eventName: "pingResponse"
        };
        b.push(a);
        return b
    }

    function b(a) {
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {},
            type: d("MultiwayCommonTypes").MessageType.PING
        })
    }
    g.fromThriftPingResponse = a;
    g.toThriftPingRequest = b
}), 98);
__d("ZenonMWThriftRemoveParticipantsTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = {
            usersToRemove: new Set(b.participants)
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                removeParticipantsRequest: b
            },
            type: d("MultiwayCommonTypes").MessageType.REMOVE_PARTICIPANTS
        })
    }
    g.toThriftRemoveParticipantsRequest = a
}), 98);
__d("ZenonMWThriftRingTranslator", ["MultiwayCommonTypes", "MultiwaySharedTypes", "ZenonMWCommonUtils", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, c) {
        if (b) return {
            groupThreadID: b.groupThreadId,
            peerID: b.peerId,
            serverInfoData: c
        };
        b = d("ZenonMWThriftTranslatorUtils").getCollisionContextFromThriftAppMessages(a);
        b && (b.serverInfoData = c);
        return (a = b) != null ? a : {
            groupThreadID: null,
            peerID: null,
            serverInfoData: c
        }
    }

    function a(a, b) {
        var c = [],
            e = a.messageBody;
        a = a.messageHeader;
        e = e.ringRequest;
        if (e) {
            var f = e.appMessages,
                g = e.caller,
                i = e.e2eeEnforcement,
                j = e.otherParticipants,
                k = e.ringType,
                l = e.sdpOriginLocalId,
                m = e.threadIdInfo;
            g = g;
            k = k === d("MultiwayCommonTypes").RingType.PEER_VIDEO_CALL || k === d("MultiwayCommonTypes").RingType.GROUP_VIDEO_CALL || k === d("MultiwayCommonTypes").RingType.LIVE_STREAM || k === d("MultiwayCommonTypes").RingType.PEER_ESCALATED_AUDIO_CALL;
            var n = a.conferenceName;
            a = a.serverInfoData;
            m = h(f, m, a);
            var o = d("ZenonMWThriftTranslatorUtils").getRoomMetadataFromThriftAppMessages(f);
            g = {
                actorID: b.actorID,
                e2eeInfraMandatedExpStatus: i == null ? void 0 : i.infraMandatedExpStatus,
                eventName: "inviteRequest",
                inviterID: g,
                isE2eeMandated: (i == null ? void 0 : i.mode) === d("MultiwaySharedTypes").E2eeMode.E2EE_MANDATED,
                isRemoteOfferer: !1,
                otherParticipants: Array.from(j),
                requestingVideo: k,
                roomInfo: babelHelpers["extends"]({
                    context: m,
                    name: n
                }, o == null ? {} : {
                    room: o,
                    sender: o.sender
                }),
                userID: b.userInfo.userID
            };
            a != null && (g.serverInfoData = a);
            f != null && (g.appMessages = d("ZenonMWThriftTranslatorUtils").mwThriftAppMessagesToSignalingAppMessages(f));
            c.push(g);
            k = (j = (i = e.offer) == null ? void 0 : i.sdpString) != null ? j : "";
            n = (m = e.mediaStatusEx) != null ? m : null;
            if (k !== "" && n != null) {
                o = {
                    sdp: k,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(k)
                };
                b = d("ZenonMWThriftTranslatorUtils").toZenonMediaStatesFromThrift(n);
                a = {
                    eventName: "remoteSdpRequest",
                    mediaPath: d("ZenonMWThriftTranslatorUtils").fromThriftMediaPath(e.mediaPath),
                    mediaStates: b,
                    negotiateType: !1,
                    sdp: o,
                    sdpOriginLocalId: l,
                    source: "ringRequest"
                };
                c.push(a)
            }
        }
        return c
    }

    function b(a, b) {
        b = b.status;
        b === "IN_ANOTHER_CALL" && (a.signalingID = null);
        b = d("ZenonMWThriftTranslatorUtils").toMWThriftDeviceStatus(b);
        b = {
            deviceStatus: b
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: a,
            rtcMessageBody: {
                ringResponse: b
            },
            type: d("MultiwayCommonTypes").MessageType.RING
        })
    }
    g.fromThriftRingRequest = a;
    g.toThriftRingResponse = b
}), 98);
__d("ZenonMWThriftServerMediaUpdateTranslator", ["FBLogger", "MultiwayCommonTypes", "ZenonAuditedCheckpointLogId", "ZenonInfraActionsLogger", "ZenonMWCommonUtils", "ZenonMWThriftMessageReliabilityLogger", "ZenonMWThriftMessageTagUtils", "ZenonMWThriftTranslatorUtils", "ZenonScreenShare", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            e = a.messageBody.serverMediaUpdateRequest,
            f = a.messageHeader,
            g = f.messageTags,
            i = f.transactionId;
        if (!e) return b;
        var j = e.answer,
            k = e.fromVersion,
            l = e.mediaPath,
            m = e.mediaStatus,
            n = e.multipleVideoStreamsAllowed,
            o = e.offer,
            p = e.prAnswer,
            q = e.renegotiationRequested,
            r = e.sdpOriginLocalId,
            s = e.stateStore,
            t = e.toVersion;
        e = e.update;
        o = (o = o == null ? void 0 : o.sdpString) != null ? o : "";
        j = (j = j == null ? void 0 : j.sdpString) != null ? j : "";
        p = (p = p == null ? void 0 : p.sdpString) != null ? p : "";
        k = +k;
        t = +t;
        l = d("ZenonMWThriftTranslatorUtils").fromThriftMediaPath(l);
        g = d("ZenonMWThriftMessageTagUtils").fromThriftMessageTags(g);
        var u = function() {
                d("ZenonMWThriftMessageReliabilityLogger").logProcessedMessage(a)
            },
            v = o !== "",
            w = j !== "",
            x = c("gkx")("25225") && p !== "",
            y = e !== null;
        y = v || w || x || y;
        d("ZenonMWThriftTranslatorUtils").addThriftStateStoreSignalingEvents(s, b, !1, y);
        y = d("ZenonMWThriftTranslatorUtils").fetchE2eeServerState(s);
        if (q) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 1: renegotationRequested"
            });
            q = {
                ackMessageId: i,
                eventName: "initiateRenegotiationRequest",
                fromVersion: k,
                hasRemoteOffer: o !== "",
                mediaPath: l,
                messageTags: (s = g) != null ? s : [],
                onProcessed: u,
                version: t
            };
            b.push(q);
            if (v) {
                s = h(i, k, l, m, {
                    sdp: o,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(o)
                }, r, u, g, y);
                b.push(s)
            }
        } else if (w) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 2: answer SDP"
            });
            q = h(i, k, l, m, {
                sdp: j,
                type: "answer",
                version: d("ZenonMWCommonUtils").getSdpVersion(j)
            }, r, u, g, y);
            if (q.sdp.sdp != null && d("ZenonMWCommonUtils").isUnifiedPlan(q.sdp.sdp)) {
                s = {
                    sdp: j,
                    type: "offer",
                    version: d("ZenonMWCommonUtils").getSdpVersion(j)
                };
                q.renegotiationOffer = s
            }
            b.push(q)
        } else if (v) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 3: offer SDP"
            });
            w = h(i, k, l, m, {
                sdp: o,
                type: "offer",
                version: d("ZenonMWCommonUtils").getSdpVersion(o)
            }, r, u, g, y);
            b.push(w)
        } else if (e) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 4: delta SDP"
            });
            j = h(i, k, l, m, {
                type: "offer",
                update: e,
                version: t
            }, r, u, g, y);
            b.push(j)
        } else if (x) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 5: prAnswer SDP"
            });
            s = h(i, k, l, m, {
                sdp: p,
                type: "pranswer",
                version: d("ZenonMWCommonUtils").getSdpVersion(p)
            }, r, u, g, y);
            b.push(s)
        } else if (m) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                checkpoint: "SMU type 6: media update"
            });
            v = {
                ackMessageId: i,
                eventName: "mediaUpdateRequest",
                mediaStates: d("ZenonMWThriftTranslatorUtils").toZenonMediaStatesFromThrift(m, k, t),
                messageTags: (q = g) != null ? q : [],
                onProcessed: u
            };
            b.push(v)
        } else {
            o = "Warning: unsupported SMU type. TXID: " + i;
            c("FBLogger")("rpweb").warn(o);
            c("ZenonInfraActionsLogger").logError({
                auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__ERROR,
                error: o,
                errorDomain: "ZenonMWThriftServerMediaUpdateTranslator"
            })
        }
        d("ZenonMWThriftTranslatorUtils").maybeAddOverlayConfigServerUpdateRequestFromThrift(b, f);
        e = {
            capabilities: {
                multipleVideoStreamsAllowed: n
            },
            eventName: "capabilitiesRequest",
            messageTags: (w = g) != null ? w : []
        };
        b.push(e);
        return b
    }

    function h(a, b, c, e, f, g, h, i, j) {
        return {
            ackMessageId: a,
            e2eeServerState: j,
            eventName: "remoteSdpRequest",
            fromVersion: b,
            mediaPath: c,
            mediaStates: d("ZenonMWThriftTranslatorUtils").toZenonMediaStatesFromThrift(e),
            messageTags: (a = i) != null ? a : [],
            negotiateType: !1,
            onProcessed: h,
            sdp: f,
            sdpOriginLocalId: g,
            source: "serverMediaUpdateRequest"
        }
    }

    function b(a, b, c, e) {
        return i({
            acknowledgedVersion: b.acknowledgedVersion,
            answer: e,
            header: a,
            mediaStates: c,
            statusCode: d("ZenonMWThriftTranslatorUtils").toMWThriftResponseStatusCode(b.statusCode),
            subCode: (e = d("ZenonMWThriftTranslatorUtils").toMWThriftResponseStatusSubCode(b.subCode)) != null ? e : void 0
        })
    }

    function e(a, b) {
        return i({
            acknowledgedVersion: b.acknowledgedVersion,
            header: a,
            statusCode: d("ZenonMWThriftTranslatorUtils").toMWThriftResponseStatusCode(b.statusCode),
            subCode: (a = d("ZenonMWThriftTranslatorUtils").toMWThriftResponseStatusSubCode(b.subCode)) != null ? a : void 0
        })
    }

    function f(a, b) {
        return i({
            acknowledgedVersion: b.acknowledgedVersion,
            header: a,
            statusCode: (a = d("MultiwayCommonTypes").RtcResponseStatusCode.cast(b.responseStatusCode)) != null ? a : d("MultiwayCommonTypes").RtcResponseStatusCode.CONDITIONAL_REQUEST_FAILED,
            subCode: d("MultiwayCommonTypes").RtcResponseSubCode.cast(b.responseSubCode)
        })
    }

    function i(a) {
        var b = a.acknowledgedVersion,
            c = a.answer,
            e = a.header,
            f = a.mediaStates,
            g = a.statusCode;
        a = a.subCode;
        b = {
            currentVersion: String(b)
        };
        f && (b.mediaStatus = j(f));
        c && (b.answer = {
            sdpString: c.sdp
        });
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: e,
            rtcMessageBody: {
                serverMediaUpdateResponse: b
            },
            statusCode: g,
            subCode: a,
            type: d("MultiwayCommonTypes").MessageType.SERVER_MEDIA_UPDATE
        })
    }

    function j(a) {
        var b = {
                tracks: {}
            },
            c = !d("ZenonScreenShare").screenShareWithReplaceTrack();
        a.tracks.forEach(function(a) {
            var e = {
                    customAudioContentType: void 0,
                    customVideoContentType: void 0,
                    enabled: a.enabled,
                    name: a.name,
                    owner: a.participantID
                },
                f = c ? d("ZenonMWThriftTranslatorUtils").toMWThriftTrackLabel(a.type) : null;
            f != null && (e.label = f);
            b.tracks[a.trackID] = e
        });
        return b
    }
    g.fromThriftServerMediaUpdateRequest = a;
    g.toThriftServerMediaUpdateResponse = b;
    g.toThriftServerMediaUpdateRenegotiationResponse = e;
    g.toThriftServerMediaUpdateNoSdpResponse = f
}), 98);
__d("ZenonMWThriftStateSyncTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.messageBody.updateResponse;
        a = a.messageHeader.transactionId;
        if (!b) return [];
        var c = b.topic;
        b = b.version;
        a = {
            ackMessageId: a,
            eventName: "stateSyncUpdateResponse",
            topic: c,
            version: b
        };
        return [a]
    }

    function b(a) {
        a = a.messageBody.notifyRequest;
        if (!a) return [];
        var b = [];
        if (a.syncPayload != null) d("ZenonMWThriftTranslatorUtils").addThriftStateStoreSignalingEvents(a.syncPayload.stateStore, b, !0, !1);
        else {
            var c = a.data,
                e = a.topic;
            a = a.version;
            c = {
                data: c,
                eventName: "stateSyncNotifyRequest",
                responseRequired: !0,
                topic: e,
                version: a
            };
            b.push(c)
        }
        return b
    }

    function c(a) {
        var b = a.messageBody.unsubscribeResponse;
        a = a.messageHeader.transactionId;
        if (!b) return [];
        var c = b.topic;
        b = b.version;
        a = {
            ackMessageId: a,
            eventName: "stateSyncUnsubscribeResponse",
            topic: c,
            version: b
        };
        return [a]
    }

    function e(a, b) {
        var c = b.data,
            e = b.topic;
        b = b.version;
        c = {
            data: c,
            syncPayload: {
                stateStore: {},
                stateStoreV2: {}
            },
            topic: e,
            topicId: null,
            version: b
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                updateRequest: c
            },
            type: d("MultiwayCommonTypes").MessageType.UPDATE
        })
    }

    function f(a, b) {
        var c = b.topic;
        b = b.version;
        c = {
            topic: c,
            version: b
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: a,
            rtcMessageBody: {
                notifyResponse: c
            },
            type: d("MultiwayCommonTypes").MessageType.NOTIFY
        })
    }

    function h(a, b) {
        var c = b.topic;
        b = b.version;
        c = {
            topic: c,
            topicId: null,
            version: b
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                unsubscribeRequest: c
            },
            type: d("MultiwayCommonTypes").MessageType.UNSUBSCRIBE
        })
    }
    g.fromThriftUpdateResponse = a;
    g.fromThriftNotifyRequest = b;
    g.fromThriftUnsubscribeResponse = c;
    g.toThriftUpdateRequest = e;
    g.toThriftNotifyResponse = f;
    g.toThriftUnsubscribeRequest = h
}), 98);
__d("ZenonMWThriftSubscriptionTranslator", ["MultiwayCommonTypes", "MultiwaySharedTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = b.subscriptions;
        b = {
            subscriptions: b.map(function(a) {
                var b;
                return {
                    cname: "",
                    options: {
                        videoQuality: d("MultiwaySharedTypes").VideoQuality.cast((b = a.options) == null ? void 0 : b.videoQuality)
                    },
                    trackId: a.trackId,
                    type: d("MultiwaySharedTypes").SubscriptionType.cast(a.type)
                }
            })
        };
        return d("ZenonMWThriftTranslatorUtils").createMWThriftRequest({
            header: a,
            rtcMessageBody: {
                subscriptionRequest: b
            },
            type: d("MultiwayCommonTypes").MessageType.SUBSCRIPTION
        })
    }
    g.toThriftSubscriptionRequest = a
}), 98);
__d("ZenonMWThriftWakeupTranslator", ["MultiwayCommonTypes", "ZenonMWThriftTranslatorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.messageHeader;
        a = {
            ackMessageId: a.transactionId,
            eventName: "wakeupRequest"
        };
        b.push(a);
        return b
    }

    function b(a) {
        return d("ZenonMWThriftTranslatorUtils").createMWThriftResponse({
            header: a,
            rtcMessageBody: {},
            type: d("MultiwayCommonTypes").MessageType.WAKEUP
        })
    }
    g.fromThriftWakeupRequest = a;
    g.toThriftWakeupResponse = b
}), 98);
__d("ZenonMWThriftMessageTranslator", ["FBLogger", "MultiwayCommonTypes", "ZenonActorHooks", "ZenonMWThriftAddParticipantsTranslator", "ZenonMWThriftApprovalTranslator", "ZenonMWThriftClientEventTranslator", "ZenonMWThriftClientMediaUpdateTranslator", "ZenonMWThriftConferenceStateTranslator", "ZenonMWThriftDataMessageTranslator", "ZenonMWThriftDismissTranslator", "ZenonMWThriftHangupTranslator", "ZenonMWThriftIceCandidateTranslator", "ZenonMWThriftJoinTranslator", "ZenonMWThriftPingTranslator", "ZenonMWThriftRemoveParticipantsTranslator", "ZenonMWThriftRingTranslator", "ZenonMWThriftServerMediaUpdateTranslator", "ZenonMWThriftStateSyncTranslator", "ZenonMWThriftSubscriptionTranslator", "ZenonMWThriftTranslatorUtils", "ZenonMWThriftWakeupTranslator", "ZenonSignalingMessage", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.getHeader();
        a = a.getEvents();
        if (a.length === 0) throw c("unrecoverableViolation")("Unexpected Translation: called toMWThriftMessage with empty signaling events", "rtc_www");
        else {
            var e = a[0];
            switch (e.eventName) {
                case "addParticipantsRequest":
                    return d("ZenonMWThriftAddParticipantsTranslator").toThriftAddParticipantsRequest(b, e);
                case "clientEventRequest":
                    return d("ZenonMWThriftClientEventTranslator").toThriftClientEventRequest(b, e);
                case "clientInfoRequest":
                    if (a.length >= 2 && a[1].eventName === "localSdpRequest" && (a[1].sdp.type === "offer" || a[1].sdp.type === "answer")) return d("ZenonMWThriftJoinTranslator").toThriftJoinRequest(b, e, a[1]);
                    break;
                case "dismissResponse":
                    return d("ZenonMWThriftDismissTranslator").toThriftDismissResponse(b);
                case "genericDataMessageRequest":
                    return d("ZenonMWThriftDataMessageTranslator").toThriftDataMessageRequest(b, e);
                case "genericDataMessageResponse":
                    return d("ZenonMWThriftDataMessageTranslator").toThriftDataMessageResponse(b);
                case "terminateRequest":
                    return d("ZenonMWThriftHangupTranslator").toThriftHangupRequest(b, e);
                case "initiateRenegotiationResponse":
                    if (a.length >= 3 && a[1].eventName === "remoteSdpResponse" && a[2].eventName === "localSdpRequest" && a[2].sdp.type === "answer") return d("ZenonMWThriftServerMediaUpdateTranslator").toThriftServerMediaUpdateResponse(b, a[1], a[2].mediaStates, a[2].sdp);
                    else return d("ZenonMWThriftServerMediaUpdateTranslator").toThriftServerMediaUpdateRenegotiationResponse(b, e);
                case "inviteRequest":
                    if (a.length >= 3 && a[1].eventName === "clientInfoRequest" && a[2].eventName === "localSdpRequest" && a[2].sdp.type === "offer") return d("ZenonMWThriftJoinTranslator").toThriftJoinRequest(b, a[1], a[2], e);
                    break;
                case "inviteResponse":
                    return d("ZenonMWThriftRingTranslator").toThriftRingResponse(b, e);
                case "iceCandidateRequest":
                    return d("ZenonMWThriftIceCandidateTranslator").toThriftIceCandidateRequest(b, e);
                case "iceCandidateResponse":
                    return d("ZenonMWThriftIceCandidateTranslator").toThriftIceCandidateResponse(b);
                case "participantUpdateResponse":
                    return d("ZenonMWThriftConferenceStateTranslator").toThriftConferenceStateResponse(b, e);
                case "localSdpRequest":
                    return d("ZenonMWThriftClientMediaUpdateTranslator").toThriftClientMediaUpdateRequest(b, e.mediaStates, e.sdp);
                case "mediaUpdateRequest":
                    return d("ZenonMWThriftClientMediaUpdateTranslator").toThriftClientMediaUpdateRequest(b, e.mediaStates);
                case "mediaUpdateResponse":
                    return d("ZenonMWThriftServerMediaUpdateTranslator").toThriftServerMediaUpdateNoSdpResponse(b, e);
                case "pingRequest":
                    return d("ZenonMWThriftPingTranslator").toThriftPingRequest(b);
                case "remoteSdpResponse":
                    return e.type === "offer" && (a.length >= 2 && a[1].eventName === "localSdpRequest" && a[1].sdp.type === "answer") ? a[1].mediaMode !== "p2p" ? d("ZenonMWThriftServerMediaUpdateTranslator").toThriftServerMediaUpdateResponse(b, e, a[1].mediaStates) : d("ZenonMWThriftServerMediaUpdateTranslator").toThriftServerMediaUpdateResponse(b, e, a[1].mediaStates, a[1].sdp) : d("ZenonMWThriftServerMediaUpdateTranslator").toThriftServerMediaUpdateResponse(b, e);
                case "removeParticipantsRequest":
                    return d("ZenonMWThriftRemoveParticipantsTranslator").toThriftRemoveParticipantsRequest(b, e);
                case "subscriptionRequest":
                    return d("ZenonMWThriftSubscriptionTranslator").toThriftSubscriptionRequest(b, e);
                case "stateSyncNotifyResponse":
                    return d("ZenonMWThriftStateSyncTranslator").toThriftNotifyResponse(b, e);
                case "stateSyncUpdateRequest":
                    return d("ZenonMWThriftStateSyncTranslator").toThriftUpdateRequest(b, e);
                case "stateSyncUnsubscribeRequest":
                    return d("ZenonMWThriftStateSyncTranslator").toThriftUnsubscribeRequest(b, e);
                case "usersApprovalRequest":
                    return d("ZenonMWThriftApprovalTranslator").toThriftApprovalRequest(b, e);
                case "wakeupResponse":
                    return d("ZenonMWThriftWakeupTranslator").toThriftWakeupResponse(b)
            }
        }
        return null
    }

    function b(a) {
        var b = a.messageHeader;
        if (!h(b)) {
            c("FBLogger")("rtc_www").info("Ignoring Thrift MW message; receiver does not match self ID", "rtc_www");
            return null
        }
        var e = b.type,
            f = b.responseStatusCode == null;
        b = d("ZenonMWThriftTranslatorUtils").mwThriftMessageHeaderToSignalingMessageHeader(b);
        var g = [];
        if (e == null) return new(c("ZenonSignalingMessage"))(b, g);
        switch (e) {
            case d("MultiwayCommonTypes").MessageType.RING:
                f && (g = d("ZenonMWThriftRingTranslator").fromThriftRingRequest(a, b));
                break;
            case d("MultiwayCommonTypes").MessageType.JOIN:
                f || (g = d("ZenonMWThriftJoinTranslator").fromThriftJoinResponse(a));
                break;
            case d("MultiwayCommonTypes").MessageType.CONFERENCE_STATE:
                f && (g = d("ZenonMWThriftConferenceStateTranslator").fromThriftConferenceStateRequest(a));
                break;
            case d("MultiwayCommonTypes").MessageType.CLIENT_MEDIA_UPDATE:
                f || (g = d("ZenonMWThriftClientMediaUpdateTranslator").fromThriftClientMediaUpdateResponse(a));
                break;
            case d("MultiwayCommonTypes").MessageType.HANGUP:
                f || (g = d("ZenonMWThriftHangupTranslator").fromThriftHangupResponse(a));
                break;
            case d("MultiwayCommonTypes").MessageType.PING:
                f || (g = d("ZenonMWThriftPingTranslator").fromThriftPingResponse(a));
                break;
            case d("MultiwayCommonTypes").MessageType.ICE_CANDIDATE:
                !f ? g = d("ZenonMWThriftIceCandidateTranslator").fromThriftIceCandidateResponse(a) : g = d("ZenonMWThriftIceCandidateTranslator").fromThriftIceCandidateRequest(a);
                break;
            case d("MultiwayCommonTypes").MessageType.DATA_MESSAGE:
                f && (g = d("ZenonMWThriftDataMessageTranslator").fromThriftDataMessageRequest(a));
                break;
            case d("MultiwayCommonTypes").MessageType.DISMISS:
                f && (g = d("ZenonMWThriftDismissTranslator").fromThriftDismissRequest(a));
                break;
            case d("MultiwayCommonTypes").MessageType.SERVER_MEDIA_UPDATE:
                f && (g = d("ZenonMWThriftServerMediaUpdateTranslator").fromThriftServerMediaUpdateRequest(a));
                break;
            case d("MultiwayCommonTypes").MessageType.NOTIFY:
                f && (g = d("ZenonMWThriftStateSyncTranslator").fromThriftNotifyRequest(a));
                break;
            case d("MultiwayCommonTypes").MessageType.UPDATE:
                f || (g = d("ZenonMWThriftStateSyncTranslator").fromThriftUpdateResponse(a));
                break;
            case d("MultiwayCommonTypes").MessageType.UNSUBSCRIBE:
                f || (g = d("ZenonMWThriftStateSyncTranslator").fromThriftUnsubscribeResponse(a));
                break;
            case d("MultiwayCommonTypes").MessageType.WAKEUP:
                f && (g = d("ZenonMWThriftWakeupTranslator").fromThriftWakeupRequest(a));
                break;
            default:
                break
        }
        return new(c("ZenonSignalingMessage"))(b, g)
    }

    function h(a) {
        return d("ZenonActorHooks").ZenonActor.isInstagramUser() || d("ZenonActorHooks").ZenonActor.isOculusUser() || a.receiverUserId == null || a.receiverUserId === d("ZenonActorHooks").ZenonActor.getID() || ((a = a.receiver) == null ? void 0 : a.baseId) === d("ZenonActorHooks").ZenonActor.getAccountID()
    }
    g.toMWThriftMessage = a;
    g.toSignalingMessage = b
}), 98);
__d("RTWebSignalingListener", ["FBLogger", "ZenonMWMessageDebugLogger", "ZenonMWMessageReliabilityLogger", "ZenonMWMessageTranslator", "ZenonMWThriftMessageDebugLogger", "ZenonMWThriftMessageReliabilityLogger", "ZenonMWThriftMessageSerializer", "ZenonMWThriftMessageTranslator", "getZenonMqttChannel", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = c("getZenonMqttChannel")()
        }
        var b = a.prototype;
        b.setLoggingEventHandler = function(a) {
            this.$2 = a
        };
        b.subscribe = function(a, b) {
            var e = this;
            this.$1.subscribe("/rtc_multi", function(b) {
                try {
                    b = JSON.parse(b);
                    d("ZenonMWMessageReliabilityLogger").logReceivedMessage(b);
                    c("ZenonMWMessageDebugLogger").logMWMessage("RECEIVED", "MQTT", b);
                    e.$2 && e.$2({
                        mwMessage: b,
                        name: "mwMessageRecv"
                    });
                    var f = d("ZenonMWMessageTranslator").toSignalingMessage(b);
                    d("ZenonMWMessageReliabilityLogger").logMessageAfterTranslation(b);
                    if (f == null) return;
                    d("ZenonMWMessageReliabilityLogger").logMessageAfterNullCheck(b);
                    a(f);
                    d("ZenonMWMessageReliabilityLogger").logProcessingMessage(b)
                } catch (a) {
                    c("FBLogger")("rpweb").catching(a).warn("Error receiving MQTT message from /rtc_multi topic")
                }
            });
            this.$1.subscribeBinary("/t_rtc_multi", function(f) {
                try {
                    f = d("ZenonMWThriftMessageSerializer").deserializeMWThriftMessage(f);
                    c("ZenonMWThriftMessageDebugLogger").logMWThriftMessage("RECEIVED", "MQTT Thrift", f);
                    d("ZenonMWThriftMessageReliabilityLogger").logReceivedMessage(f);
                    e.$2 && e.$2({
                        mwThriftMessage: f,
                        name: "mwThriftMessageRecv"
                    });
                    var g = d("ZenonMWThriftMessageTranslator").toSignalingMessage(f);
                    d("ZenonMWThriftMessageReliabilityLogger").logMessageAfterTranslation(f);
                    if (g == null) return;
                    d("ZenonMWThriftMessageReliabilityLogger").logMessageAfterNullCheck(f);
                    b && e.$3(f, g, b);
                    a(g);
                    d("ZenonMWThriftMessageReliabilityLogger").logProcessingMessage(f)
                } catch (a) {
                    c("FBLogger")("rpweb").catching(a).warn("Error receiving binary MQTT message from /t_rtc_multi topic")
                }
            })
        };
        b.unsubscribe = function() {
            this.$1.unsubscribeAll("/rtc_multi"), this.$1.unsubscribeAll("/t_rtc_multi")
        };
        b.$4 = function(a, b, d) {
            try {
                d(a, b)
            } catch (a) {
                c("recoverableViolation")("Signaling messages should be json parsable. error:" + a, "rtweb")
            }
        };
        b.$3 = function(a, b, d) {
            try {
                d(a, b)
            } catch (a) {
                c("recoverableViolation")("Signaling messages should be json parsable. error:" + a, "rtweb")
            }
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("ZenonLoggingEventTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["Send", "Receive"]);
    c = b("$InternalEnum")({
        Primary: "primary",
        Secondary: "secondary"
    });
    d = "rtc_www";
    f.ZenonUpdateIceInfoDirection = a;
    f.ZenonJoinMode = c;
    f.tslogSource = d
}), 66);
__d("ZenonMWThriftMessageLogger", ["MultiwayCommonTypes", "ZenonLoggingEventTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Set(),
        i = new Set();

    function a(a, b) {
        var c = a.messageHeader;
        a = a.messageBody;
        if (h.has(c.transactionId) || c.type == null) return;
        switch (c.type) {
            case d("MultiwayCommonTypes").MessageType.JOIN:
                a.joinRequest && j(a.joinRequest, b);
                break;
            case d("MultiwayCommonTypes").MessageType.ICE_CANDIDATE:
                a.iceCandidateRequest && l(a.iceCandidateRequest, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send);
                break;
            case d("MultiwayCommonTypes").MessageType.CLIENT_MEDIA_UPDATE:
                a.clientMediaUpdateRequest && m(a.clientMediaUpdateRequest, b);
                break;
            case d("MultiwayCommonTypes").MessageType.SERVER_MEDIA_UPDATE:
                a.serverMediaUpdateResponse && p(a.serverMediaUpdateResponse, b);
                break;
            default:
                break
        }
        h.add(c.transactionId)
    }

    function b(a, b) {
        var c = a.messageHeader;
        a = a.messageBody;
        if (i.has(c.transactionId) || c.type == null) return;
        switch (c.type) {
            case d("MultiwayCommonTypes").MessageType.JOIN:
                a.joinResponse && k(a.joinResponse, b);
                break;
            case d("MultiwayCommonTypes").MessageType.ICE_CANDIDATE:
                a.iceCandidateRequest && l(a.iceCandidateRequest, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Receive);
                break;
            case d("MultiwayCommonTypes").MessageType.CLIENT_MEDIA_UPDATE:
                a.clientMediaUpdateResponse && n(a.clientMediaUpdateResponse, b);
                break;
            case d("MultiwayCommonTypes").MessageType.SERVER_MEDIA_UPDATE:
                a.serverMediaUpdateRequest && o(a.serverMediaUpdateRequest, b);
                break;
            default:
                break
        }
        i.add(c.transactionId)
    }

    function j(a, b) {
        var c = a.answer;
        a = a.offer;
        b({
            name: "inviteSent"
        });
        q(a, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send);
        c && q(c, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send)
    }

    function k(a, b) {
        a = a.answer;
        a && q(a, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Receive)
    }

    function l(a, b, c) {
        a = a.iceCandidateSdps;
        a.forEach(function(a) {
            a.candidateSdpString != null && b({
                direction: c,
                name: "updateIceInfo",
                sdpString: a.candidateSdpString
            })
        })
    }

    function m(a, b) {
        a = a.offer;
        a && q(a, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send)
    }

    function n(a, b) {
        a = a.answer;
        a && q(a, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Receive)
    }

    function o(a, b) {
        var c = a.answer;
        a = a.offer;
        a && q(a, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Receive);
        c && q(c, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Receive)
    }

    function p(a, b) {
        a = a.answer;
        a && q(a, b, d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send)
    }

    function q(a, b, c) {
        a.sdpString != null && b({
            direction: c,
            name: "updateIceInfo",
            sdpString: a.sdpString
        })
    }
    g.logSentMessage = a;
    g.logReceivedMessage = b
}), 98);
__d("ZenonMWThriftSendMessageMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7737191816373891"
}), null);
__d("ZenonMWThriftSendMessageMutation.graphql", ["ZenonMWThriftSendMessageMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "data",
                    variableName: "input"
                }],
                concreteType: "RtcWebSendMultiwayThriftSignalingMessageResponsePayload",
                kind: "LinkedField",
                name: "rtc_web_send_multiway_thrift_signaling_message",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "response",
                    storageKey: null
                }],
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "ZenonMWThriftSendMessageMutation",
                selections: c,
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "ZenonMWThriftSendMessageMutation",
                selections: c
            },
            params: {
                id: b("ZenonMWThriftSendMessageMutation_facebookRelayOperation"),
                metadata: {},
                name: "ZenonMWThriftSendMessageMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("ZenonMWThriftSendMessageMutation", ["CometRelayErrorHandling", "Promise", "RequestStreamBodyUtils", "ZenonMWThriftMessageSerializer", "ZenonMWThriftSendMessageMutation.graphql", "asyncToGeneratorRuntime", "cr:1012418", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j(a, e, f) {
        return new(i || (i = b("Promise")))(function(g, i) {
            b("cr:1012418").commitMutation(f, {
                mutation: h !== void 0 ? h : h = b("ZenonMWThriftSendMessageMutation.graphql"),
                onCompleted: function(a) {
                    return g(a)
                },
                onError: function(a) {
                    c("gkx")("20935") && d("CometRelayErrorHandling").markErrorAsHandled(a);
                    return i(a)
                },
                variables: {
                    input: {
                        endpoint: JSON.stringify(a),
                        message: d("RequestStreamBodyUtils").uint8ArrayToBase64(d("ZenonMWThriftMessageSerializer").serializeMWThriftMessage(e, !0))
                    }
                }
            })
        })
    }

    function k(a) {
        a = a.rtc_web_send_multiway_thrift_signaling_message;
        if (a != null && a.response != null) {
            a = d("RequestStreamBodyUtils").base64ToUint8Array(a.response);
            a = d("ZenonMWThriftMessageSerializer").deserializeMWThriftMessage(a, !0);
            var b = a.messageBody;
            a = a.messageHeader;
            return {
                body: b,
                header: a
            }
        }
        return {
            body: null,
            header: null
        }
    }

    function a(a, b, c) {
        return l.apply(this, arguments)
    }

    function l() {
        l = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            a = (yield j(a, b, c));
            return k(a)
        });
        return l.apply(this, arguments)
    }
    g.sendMessage = a
}), 98);
__d("ZenonValidateMWThriftMessage", ["FBLogger", "MultiwayCommonTypes", "ZenonInfraActionsLogger", "ZenonMWThriftMessageMap"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.messageHeader.type,
            e = d("ZenonMWThriftMessageMap").messageTypeToString(b);
        if (a.messageHeader.serverInfoData == null && b != null && b !== d("MultiwayCommonTypes").MessageType.JOIN) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                checkpoint: "[ZP][DROP] No remoteSignalingID in message: " + e
            });
            c("FBLogger")("rtc_www").warn("[ZP][DROP] No remoteSignalingID in message: " + e);
            return !1
        }
        return !0
    }
    g["default"] = a
}), 98);
__d("ZenonGraphQLMWThriftMessageSender", ["ChannelClientID", "MultiwayCommonTypes", "Promise", "RpZenonBinaryThriftSignalingSitevarConfig", "ZenonActorHooks", "ZenonAuditedCheckpointLogId", "ZenonInfraActionsLogger", "ZenonMWThriftMessageDebugLogger", "ZenonMWThriftMessageLogger", "ZenonMWThriftMessageMap", "ZenonMWThriftMessageReliabilityLogger", "ZenonMWThriftMessageTranslator", "ZenonMWThriftSendMessageMutation", "ZenonMWTranslatorUtils", "ZenonValidateMWThriftMessage", "asyncToGeneratorRuntime", "err", "filterNulls", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function() {
        function a(a) {
            this.$3 = a;
            a = c("RpZenonBinaryThriftSignalingSitevarConfig").supported_message_types_mqtt.map(function(a) {
                return d("ZenonMWThriftMessageMap").messageTypeFromString(a)
            });
            this.$4 = new Set(c("filterNulls")(a))
        }
        var e = a.prototype;
        e.handleResponse = function(a) {
            var b = this.$1;
            if (b == null) throw c("unrecoverableViolation")("Should never have null message receiver", "rtc_www");
            var e = a.header || null;
            a = a.body || null;
            if (e != null && a != null) {
                a = {
                    messageBody: a,
                    messageHeader: e
                };
                c("ZenonMWThriftMessageDebugLogger").logMWThriftMessage("RECEIVED", "GraphQL Thrift", a);
                d("ZenonMWThriftMessageReliabilityLogger").logReceivedMessage(a);
                this.$2 && this.$2({
                    mwThriftMessage: a,
                    name: "mwThriftMessageRecv"
                });
                e = d("ZenonMWThriftMessageTranslator").toSignalingMessage(a);
                if (e == null) return;
                b(e);
                d("ZenonMWThriftMessageReliabilityLogger").logProcessingMessage(a)
            }
        };
        e.$5 = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
                d("ZenonMWThriftMessageReliabilityLogger").logSendingMessage(b);
                c("ZenonMWThriftMessageDebugLogger").logMWThriftMessage("SENDING", "GraphQL Thrift", b);
                this.$2 && d("ZenonMWThriftMessageLogger").logSentMessage(b, this.$2);
                try {
                    a = (yield d("ZenonMWThriftSendMessageMutation").sendMessage(a, b, this.$3));
                    d("ZenonMWThriftMessageReliabilityLogger").logSentMessage(b);
                    this.$2 && this.$2({
                        mwThriftMessage: b,
                        name: "mwThriftMessageSent"
                    });
                    this.handleResponse(a)
                } catch (e) {
                    a = e != null ? e.toString() : "Message Send Error";
                    d("ZenonMWThriftMessageReliabilityLogger").logSendMessageFailed(b, "[GraphQL Thrift] " + a);
                    b = d("ZenonMWThriftMessageMap").messageTypeToString(b.messageHeader.type);
                    c("ZenonMWThriftMessageDebugLogger").logSendMultiwayThriftMessageFailure(a, b);
                    e != null && c("ZenonInfraActionsLogger").logCheckpoint({
                        auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__PLATFORM,
                        checkpoint: "Failed to send MW Thrift message of type " + b + ". Stack Trace: " + e.stack + "."
                    })
                }
            });

            function e(b, c) {
                return a.apply(this, arguments)
            }
            return e
        }();
        e.sendMessage = function(a) {
            var e = d("ZenonMWThriftMessageTranslator").toMWThriftMessage(a);
            if (!e || !c("ZenonValidateMWThriftMessage")(e)) return (h || (h = b("Promise"))).reject(c("err")("Invalid MW Thrift message"));
            if (e.messageHeader.type != null && !this.$4.has(e.messageHeader.type)) return (h || (h = b("Promise"))).resolve();
            var f = e.messageHeader.type;
            a = {
                appId: d("ZenonMWTranslatorUtils").getMWAppID(),
                deviceId: c("ChannelClientID").getID(),
                userId: a.getHeader().userInfo.userID
            };
            return a.userId !== d("ZenonActorHooks").ZenonActor.getAccountID() || f !== d("MultiwayCommonTypes").MessageType.DATA_MESSAGE ? this.$5(a, e) : (h || (h = b("Promise"))).reject(c("err")("GraphQL only sends DATA_MESSAGE for Page users"))
        };
        e.setMessageReceiver = function(a) {
            this.$1 = a
        };
        e.setLoggingEventHandler = function(a) {
            this.$2 = a
        };
        return a
    }();
    g["default"] = a
}), 98);