; /*FB_PKG_DELIM*/

__d("EBAPISharedUtils", ["EBAPIQPLPoints", "LSDeleteAndReenrollDeviceStateStoredProcedure", "LSFactory", "LSIntEnum", "LSMEBDeviceReenrollmentReason", "WALogger", "asyncToGeneratorRuntime", "handleRestoreMessagesGraphQLResponse"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] backup_id is null during graphQL restore"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] message range info is not complete - cannot proceed with graphQL restore"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] message range info is null - cannot proceed with graphQL restore"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Deleting mailbox - unable to restore"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] GQL worker range restore query returned null for message response"]);
        m = function() {
            return a
        };
        return a
    }

    function a(a, b, c, d, e, f, g, h, i, j) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e, g, n, o, p, q, r, s) {
            var t;
            d("EBAPIQPLPoints").ebAPIAddQPLPoint(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.GRAPHQL_QUERY_END, void 0, n);
            if (a == null || (a == null ? void 0 : (t = a.viewer) == null ? void 0 : (t = t.encrypted_backup) == null ? void 0 : t.mailbox) == null) {
                d("EBAPIQPLPoints").ebAPIEndFailure(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.INVALID_GRAPHQL_RESPONSE, n);
                return {
                    response: "invalid-graphql-response",
                    success: !1
                }
            }
            a = a == null ? void 0 : (t = a.viewer) == null ? void 0 : (a = t.encrypted_backup) == null ? void 0 : (t = a.mailbox) == null ? void 0 : t.messages;
            if (a == null) {
                d("WALogger").ERROR(m());
                d("EBAPIQPLPoints").ebAPIEndFailure(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.INVALID_GRAPHQL_RESPONSE, n);
                return {
                    response: "invalid-graphql-response",
                    success: !1
                }
            }
            t = a;
            if (t == null) {
                d("EBAPIQPLPoints").ebAPIEndFailure(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.INVALID_GRAPHQL_RESPONSE, n);
                return {
                    response: "invalid-graphql-response",
                    success: !1
                }
            }
            a = t.backup_id;
            var u = t.encrypted_messages,
                v = t.epoch_derivation_set,
                w = t.message_range_info;
            t = t.should_delete_mailbox;
            if (t === !0) {
                d("WALogger").WARN(l());
                d("EBAPIQPLPoints").ebAPIEndFailure(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.DELETE_MAILBOX, n);
                yield g.runInTransaction(function(a) {
                    return c("LSDeleteAndReenrollDeviceStateStoredProcedure")(c("LSFactory")(a), {
                        reenrollmentReason: (h || (h = d("LSIntEnum"))).ofNumber(c("LSMEBDeviceReenrollmentReason").RESTORE_FAILED_WITH_NO_DEVICE_FOUND),
                        targetDeviceId: o
                    })
                }, "readwrite", void 0, void 0, f.id + ":110");
                return {
                    response: "delete-mailbox",
                    success: !1
                }
            }
            d("EBAPIQPLPoints").ebAPIAddQPLPoint(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.DERIVE_AND_STORE_EPOCHS_START, void 0, n);
            yield d("handleRestoreMessagesGraphQLResponse").deriveAndStoreEpochs(v, g, o, r, b);
            d("EBAPIQPLPoints").ebAPIAddQPLPoint(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.DERIVE_AND_STORE_EPOCHS_END, void 0, n);
            if (w == null) {
                d("WALogger").ERROR(k());
                d("EBAPIQPLPoints").ebAPIEndFailure(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.INVALID_GRAPHQL_RESPONSE, n);
                return {
                    response: "invalid-graphql-response",
                    success: !1
                }
            }
            t = w.has_more_after;
            v = w.has_more_before;
            var x = w.next_message_timestamp_ms_after,
                y = w.next_message_timestamp_ms_before;
            if (v == null || t == null || x == null || y == null) {
                d("WALogger").ERROR(j());
                d("EBAPIQPLPoints").ebAPIEndFailure(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.INVALID_GRAPHQL_RESPONSE, n);
                return {
                    response: "invalid-graphql-response",
                    success: !1
                }
            }
            a == null && (d("WALogger").WARN(i()), d("EBAPIQPLPoints").ebAPIAddQPLPoint(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.BACKUP_ID_NULL, void 0, n));
            d("EBAPIQPLPoints").ebAPIAddQPLPoint(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.PROCESS_AND_DECRYPT_MESSAGES_START, void 0, n);
            v = (yield d("handleRestoreMessagesGraphQLResponse").processEncryptedMessagesForSearch({
                backupId: a,
                encryptedMessages: u,
                messageRangeInfo: w,
                runningInWorker: b,
                sortOrderMs: s,
                source: q,
                storage: g,
                threadId: p,
                traceId: r
            }));
            d("EBAPIQPLPoints").ebAPIAddQPLPoint(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.PROCESS_AND_DECRYPT_MESSAGES_END, void 0, n);
            if (v == null) {
                d("EBAPIQPLPoints").ebAPIEndFailure(b, e, d("EBAPIQPLPoints").EBMessageRestoreQueryQPLPoints.EMPTY_DECRYPTION_RESPONSE, n);
                return {
                    response: "empty-decryption-response",
                    success: !1
                }
            }
            d("EBAPIQPLPoints").ebAPIEndSuccess(b, e, n, {
                bool: {
                    isEcho: (v == null ? void 0 : v.echoMessages) ? (v == null ? void 0 : v.echoMessages.length) > 0 : !1,
                    isProtobuf: (v == null ? void 0 : v.protobufMessages) ? (v == null ? void 0 : v.protobufMessages.length) > 0 : !1
                }
            });
            return {
                response: v,
                success: !0
            }
        });
        return n.apply(this, arguments)
    }
    g.constructEBRestoreResponse = a
}), 98);
__d("MAWAsArmadilloApplication", ["MAWMsgType", "MAWXMAEncodeUtils", "WAArmadilloApplication.pb", "WAGlobals", "WAJids", "WATimeUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.XMA:
                if ((b == null ? void 0 : b.xma) == null) throw c("err")("XMA content should have XMA payload");
                return d("MAWXMAEncodeUtils").encodeXMA(a, b);
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                return h(a, e);
            case d("MAWMsgType").MSG_TYPE.RAVEN_ACTION:
                return i(a);
            default:
                throw c("err")(a.type + " should not be handled as ArmadilloApplication")
        }
    }

    function h(a, b) {
        var c;
        if (a.type !== d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE || ((c = a.quote) == null ? void 0 : c.content) == null || b == null) return null;
        c = a.quote.content;
        var e = d("WAJids").interpretAndValidateJid(b),
            f = d("WAJids").isAuthorMe(a.author) ? d("WAGlobals").getMyUserJid() : a.author,
            g = d("WAJids").isAuthorMe(c.author) ? d("WAGlobals").getMyUserJid() : c.author;

        function h() {
            if (e.jidType === "msgrUser") return g;
            return e.jidType === "group" ? e.groupJid : null
        }

        function i() {
            if (f === g) return null;
            return e.jidType === "group" ? g : null
        }
        b = h();
        h = i();
        if (b == null) return null;
        if (a) return {
            payload: {
                content: {
                    bumpExistingMessage: {
                        key: {
                            fromMe: f === g,
                            id: c.externalId,
                            participant: h,
                            remoteJid: b
                        }
                    }
                }
            }
        }
    }

    function i(a) {
        var b = a.ravenActionToMsgExternalId;
        if (b == null) throw c("err")("msg ravenActionToMsgExternalId is null in encodeRavenActionMessage");
        var e = Number(a.actionType),
            f;
        if (e === 0) f = d("WAArmadilloApplication.pb").ARMADILLO_CONTENT_RAVEN_ACTION_NOTIF_MESSAGE_ACTION_TYPE.PLAYED;
        else if (e === 1) f = d("WAArmadilloApplication.pb").ARMADILLO_CONTENT_RAVEN_ACTION_NOTIF_MESSAGE_ACTION_TYPE.SCREENSHOT;
        else if (e === 2) f = d("WAArmadilloApplication.pb").ARMADILLO_CONTENT_RAVEN_ACTION_NOTIF_MESSAGE_ACTION_TYPE.FORCE_DISABLE;
        else throw c("err")("msg actionType is not in enum in encodeRavenActionMessage");
        e = a.actionTimestamp;
        e == null && (e = d("WATimeUtils").castMilliSecondsToUnixTime(Date.now()));
        a = {
            actionTimestamp: e,
            actionType: f,
            key: {
                id: b
            }
        };
        return {
            payload: {
                content: {
                    ravenActionNotifMessage: a
                }
            }
        }
    }
    g.asArmadilloApplication = a
}), 98);
__d("validateMAWMediaAndComposeEntryForProtoMsg", ["WAMediaUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        if (b == null) throw c("err")("DbMedia is null in validateMediaAndComposeEntryForProtoMsg");
        var e = null;
        if (a != null && b.mediaId != null) {
            if (!b.msgIds.includes(a)) throw c("err")("the media (" + b.mediaId + ") is not linked to the msg (" + a + ")");
            e = b.mediaEntries.get(a)
        } else e = b.mediaEntry;
        if (e == null) throw c("err")("media entry not found in validateMediaAndComposeEntryForProtoMsg");
        a = b.plaintextHash;
        var f = d("WAMediaUtils").mediaEntryDataToRawData(a, e);
        a = ["fileSha256", "mediaKey", "fileEncSha256", "directPath", "mediaKeyTimestamp"];
        e = a.filter(function(a) {
            return f[a] == null
        });
        if (e.length > 0) throw c("err")("missing fields in mediaEntryData: " + e.toString());
        return [b, f]
    }
    g["default"] = a
}), 98);
__d("MAWAsConsumerApplication", ["I64", "LSIntEnum", "MAWDbMedia", "MAWJids", "MAWMsgType", "MAWVault", "WAAssertUnreachable", "WAConsumerApplication.pb", "WAGlobals", "WAJids", "WAMediaTransport.pb", "encodeMAWDocumentFileMessage", "encodeProtobuf", "err", "gkx", "validateMAWMediaAndComposeEntryForProtoMsg"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = "image/jpeg",
        k = "video/mp4",
        l = "audio/wav",
        m = "audio/ogg",
        n = "image/gif",
        o = "image/webp",
        p = c("gkx")("4644") ? "application/octet-stream" : "application/pdf",
        q = new ArrayBuffer(0);

    function a(a, b, e) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
                return s(a);
            case d("MAWMsgType").MSG_TYPE.IMAGE:
                return t(a, b);
            case d("MAWMsgType").MSG_TYPE.VIDEO:
                return A(a, b);
            case d("MAWMsgType").MSG_TYPE.PTT:
                return D(a, b);
            case d("MAWMsgType").MSG_TYPE.REVOKED:
                return G(a.revokedExternalId);
            case d("MAWMsgType").MSG_TYPE.GIF:
                return A(a, b);
            case d("MAWMsgType").MSG_TYPE.STICKER:
                return x(a, b);
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                return c("encodeMAWDocumentFileMessage")(a, b);
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE:
            case d("MAWMsgType").MSG_TYPE.SK_DISTRIBUTION:
                return null;
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
                throw c("err")("Implemented ephemeral setting message in MAWAsConsumerApplication");
            case d("MAWMsgType").MSG_TYPE.XMA:
                throw c("err")("XMA content message is not consumer application. It should be addressed as ArmadilloApplication");
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME:
                throw c("err")("We do not support converting to protoMsg with " + a.type + " type", "maw_db");
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.RAVEN_ACTION:
                throw c("err")("Raven content message is not consumer application. It should be addressed as ArmadilloApplication");
            case d("MAWMsgType").MSG_TYPE.EDIT_ACTION:
                throw c("err")("We do not support editing messages right now since the sending flow is not implemented yet. ");
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
                return H(a, e);
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                throw c("err")("Sending bump messages is not supported yet.");
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                throw c("err")("Sending receiver fetch messages is not supported yet.");
            default:
                return c("WAAssertUnreachable")(a.type)
        }
    }

    function b(a, b) {
        if (b == null) return r(a);
        else switch (b.mediaType) {
            case d("MAWDbMedia").MEDIA_TYPE.IMAGE:
                return u(a.msgId, b);
            case d("MAWDbMedia").MEDIA_TYPE.VIDEO:
                return B(a.msgId, b);
            case d("MAWDbMedia").MEDIA_TYPE.PTT:
                return E(a.msgId, b);
            case d("MAWDbMedia").MEDIA_TYPE.GIF:
                return B(a.msgId, b);
            case d("MAWDbMedia").MEDIA_TYPE.STICKER:
                return y(a.msgId, b);
            default:
                return null
        }
    }

    function r(a) {
        var b = null;
        if (a.type === d("MAWMsgType").MSG_TYPE.REVOKED && a.msgContent != null && a.msgContent.content != null) b = a.msgContent.content;
        else if (a.type === d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME && a.msgContent != null) b = a.msgContent;
        else return null;
        return {
            payload: {
                content: {
                    messageText: {
                        mentionedJid: [],
                        text: d("MAWVault").unvault(b)
                    }
                }
            }
        }
    }

    function s(a) {
        var b = {
            payload: {
                content: {
                    messageText: {
                        mentionedJid: a.msgContent.mentionedJids,
                        text: d("MAWVault").unvault(a.msgContent.content)
                    }
                }
            }
        };
        if (a.specialTextSize != null) {
            a = a.specialTextSize === 1 ? d("WAConsumerApplication.pb").CONSUMER_APPLICATION_METADATA_SPECIAL_TEXT_SIZE.SMALL : a.specialTextSize === 2 ? d("WAConsumerApplication.pb").CONSUMER_APPLICATION_METADATA_SPECIAL_TEXT_SIZE.MEDIUM : d("WAConsumerApplication.pb").CONSUMER_APPLICATION_METADATA_SPECIAL_TEXT_SIZE.LARGE;
            b.metadata = {
                specialTextSize: a
            }
        }
        return b
    }

    function t(a, b) {
        return u(a.msgId, b)
    }

    function u(a, b) {
        a = c("validateMAWMediaAndComposeEntryForProtoMsg")(a, b);
        b = a[0];
        a = a[1];
        return w(b, a)
    }

    function v(a, b) {
        var c;
        a = {
            ancillary: {
                height: (c = a.validatedImageInfo) == null ? void 0 : c.height,
                scanLengths: ((c = b.progressiveJpegDetails) == null ? void 0 : c.scanLengths) || [],
                scansSidecar: (c = b.progressiveJpegDetails) == null ? void 0 : c.sidecar,
                width: (c = a.validatedImageInfo) == null ? void 0 : c.width
            },
            integral: {
                transport: {
                    ancillary: {
                        fileLength: a.size,
                        mimetype: j,
                        objectId: b.objectId,
                        thumbnail: {
                            downloadableThumbnail: b.downloadableThumbnail,
                            jpegThumbnail: void 0,
                            thumbnailHeight: (c = a.validatedImageInfo) == null ? void 0 : c.jpegThumbnailHeight,
                            thumbnailWidth: (c = a.validatedImageInfo) == null ? void 0 : c.jpegThumbnailWidth
                        }
                    },
                    integral: {
                        directPath: b.directPath,
                        fileEncSha256: b.fileEncSha256,
                        fileSha256: b.fileSha256,
                        mediaKey: b.mediaKey,
                        mediaKeyTimestamp: b.mediaKeyTimestamp
                    }
                }
            }
        };
        return d("encodeProtobuf").encodeProtobuf(d("WAMediaTransport.pb").ImageTransportSpec, a).readBuffer()
    }

    function w(a, b) {
        a = v(a, b);
        return {
            payload: {
                content: {
                    imageMessage: {
                        caption: {
                            mentionedJid: []
                        },
                        image: {
                            payload: a,
                            version: 1
                        }
                    }
                }
            }
        }
    }

    function e(a) {
        return {
            payload: {
                content: {
                    editMessage: {
                        key: {
                            fromMe: !0,
                            id: a.originalMsgExternalId,
                            remoteJid: a.threadJid
                        },
                        message: {
                            mentionedJid: a.msgContent.mentionedJids,
                            text: d("MAWVault").unvault(a.msgContent.content)
                        },
                        timestampMs: a.editTs * 1e3
                    }
                }
            }
        }
    }

    function x(a, b) {
        return y(a.msgId, b)
    }

    function y(a, b) {
        a = c("validateMAWMediaAndComposeEntryForProtoMsg")(a, b);
        b = a[0];
        a = a[1];
        return z(b, a)
    }

    function z(a, b) {
        var c;
        a = {
            ancillary: {
                height: (c = a.validatedImageInfo) == null ? void 0 : c.height,
                width: (c = a.validatedImageInfo) == null ? void 0 : c.width
            },
            integral: {
                transport: {
                    ancillary: {
                        fileLength: a.size,
                        mimetype: o,
                        objectId: b.objectId,
                        thumbnail: {
                            thumbnailHeight: (c = a.validatedImageInfo) == null ? void 0 : c.jpegThumbnailHeight,
                            thumbnailWidth: (c = a.validatedImageInfo) == null ? void 0 : c.jpegThumbnailWidth
                        }
                    },
                    integral: {
                        directPath: b.directPath,
                        fileEncSha256: b.fileEncSha256,
                        fileSha256: b.fileSha256,
                        mediaKey: b.mediaKey,
                        mediaKeyTimestamp: b.mediaKeyTimestamp
                    }
                }
            }
        };
        c = d("encodeProtobuf").encodeProtobuf(d("WAMediaTransport.pb").StickerTransportSpec, a);
        return {
            payload: {
                content: {
                    stickerMessage: {
                        sticker: {
                            payload: c.readBuffer(),
                            version: 1
                        }
                    }
                }
            }
        }
    }

    function A(a, b) {
        return B(a.msgId, b)
    }

    function B(a, b) {
        a = c("validateMAWMediaAndComposeEntryForProtoMsg")(a, b);
        b = a[0];
        a = a[1];
        return C(b, a)
    }

    function C(a, b) {
        var c, e = a.mediaType === d("MAWDbMedia").MEDIA_TYPE.GIF,
            f = e ? a.validatedImageInfo : a.validatedVideoInfo;
        c = {
            ancillary: {
                gifPlayback: e,
                height: f == null ? void 0 : f.height,
                seconds: e ? void 0 : (c = a.validatedVideoInfo) == null ? void 0 : c.duration,
                sidecar: b.sidecar,
                width: f == null ? void 0 : f.width
            },
            integral: {
                transport: {
                    ancillary: {
                        fileLength: a.size,
                        mimetype: e ? n : k,
                        objectId: b.objectId,
                        thumbnail: e ? {
                            thumbnailHeight: f == null ? void 0 : f.jpegThumbnailHeight,
                            thumbnailWidth: f == null ? void 0 : f.jpegThumbnailWidth
                        } : {
                            downloadableThumbnail: b.downloadableThumbnail,
                            jpegThumbnail: void 0,
                            thumbnailHeight: f == null ? void 0 : f.jpegThumbnailHeight,
                            thumbnailWidth: f == null ? void 0 : f.jpegThumbnailWidth
                        }
                    },
                    integral: {
                        directPath: b.directPath,
                        fileEncSha256: b.fileEncSha256,
                        fileSha256: b.fileSha256,
                        mediaKey: b.mediaKey,
                        mediaKeyTimestamp: b.mediaKeyTimestamp
                    }
                }
            }
        };
        a = d("encodeProtobuf").encodeProtobuf(d("WAMediaTransport.pb").VideoTransportSpec, c);
        return {
            payload: {
                content: {
                    videoMessage: {
                        caption: {
                            mentionedJid: []
                        },
                        video: {
                            payload: a.readBuffer(),
                            version: 1
                        }
                    }
                }
            }
        }
    }

    function D(a, b) {
        return E(a.msgId, b)
    }

    function E(a, b) {
        a = c("validateMAWMediaAndComposeEntryForProtoMsg")(a, b);
        b = a[0];
        a = a[1];
        return F(b, a)
    }

    function F(a, b) {
        var e;
        e = {
            ancillary: {
                seconds: (e = a.validatedAudioInfo) == null ? void 0 : e.duration
            },
            integral: {
                audioFormat: c("gkx")("3532") ? d("WAMediaTransport.pb").AUDIO_TRANSPORT_INTEGRAL_AUDIO_FORMAT.OPUS : void 0,
                transport: {
                    ancillary: {
                        fileLength: a.size,
                        mimetype: c("gkx")("3532") ? m : l,
                        objectId: b.objectId,
                        thumbnail: {
                            jpegThumbnail: q
                        }
                    },
                    integral: {
                        directPath: b.directPath,
                        fileEncSha256: b.fileEncSha256,
                        fileSha256: b.fileSha256,
                        mediaKey: b.mediaKey,
                        mediaKeyTimestamp: b.mediaKeyTimestamp
                    }
                }
            }
        };
        a = d("encodeProtobuf").encodeProtobuf(d("WAMediaTransport.pb").AudioTransportSpec, e);
        return {
            payload: {
                content: {
                    audioMessage: {
                        audio: {
                            payload: a.readBuffer(),
                            version: 1
                        },
                        ptt: !0
                    }
                }
            }
        }
    }

    function G(a) {
        return {
            payload: {
                applicationData: {
                    revoke: {
                        key: {
                            fromMe: !0,
                            id: a
                        }
                    }
                }
            }
        }
    }

    function f(a) {
        function b() {
            var b = d("WAJids").isAuthorMe(a.author) ? d("WAGlobals").getMyUserJid() : a.author,
                c = d("WAJids").isAuthorMe(a.reactToAuthor) ? d("WAGlobals").getMyUserJid() : a.reactToAuthor;
            return b === c ? !0 : !1
        }
        b = b();
        var c = d("WAJids").interpretAsGroupJid(a.threadJid) != null;
        c = {
            groupingKey: a.groupingKey == null ? void 0 : a.groupingKey,
            key: {
                fromMe: b,
                id: a.reactToExternalId,
                participant: c && !b ? a.reactToAuthor : void 0,
                remoteJid: a.threadJid
            },
            senderTimestampMs: a.ts * 1e3,
            text: a.reaction == null ? void 0 : a.reaction
        };
        return {
            payload: {
                content: {
                    reactionMessage: c
                }
            }
        }
    }

    function H(a, b) {
        if (a.threadJid == null) throw c("err")("msg threadJid is null in encodeGroupInviteMessage");
        if (b == null) throw c("err")("DbGroupInvite is null in encodeGroupInviteMessage");
        var e = d("WAJids").interpretAsGroupJid(a.threadJid);
        if (e == null) throw c("err")("groupJid is null in encodeGroupInviteMessage");
        return {
            payload: {
                content: {
                    groupInviteMessage: {
                        groupJid: e,
                        groupName: a.groupName,
                        inviteCode: b.inviteCode,
                        inviteExpiration: b.inviteExpirationTs
                    }
                }
            }
        }
    }

    function I(a) {
        return (h || (h = d("I64"))).equal(a.displayedContentTypes, (i || (i = d("LSIntEnum"))).ofNumber(1)) || (h || (h = d("I64"))).equal(a.displayedContentTypes, (i || (i = d("LSIntEnum"))).ofNumber(256)) || a.textHasLinks || a.isUnsent ? J(a) : null
    }

    function J(a) {
        var b;
        b = (b = a.mentionIds) == null ? void 0 : (b = b.split(",")) == null ? void 0 : b.map(d("MAWJids").toUserJid);
        return {
            payload: {
                content: {
                    messageText: {
                        mentionedJid: (b = b) != null ? b : [],
                        text: a.text
                    }
                }
            }
        }
    }
    g.IMAGE_MIME_TYPE = j;
    g.VIDEO_MIME_TYPE = k;
    g.AUDIO_WAV_MIME_TYPE = l;
    g.AUDIO_OGG_MIME_TYPE = m;
    g.GIF_MIME_TYPE = n;
    g.STICKER_MIME_TYPE = o;
    g.FILE_MIME_TYPE = p;
    g.emptyAudioFileArrayBuffer = q;
    g.asConsumerApplication = a;
    g.deletedMsgAsConsumerApplicationForSpamReporting = b;
    g.encodeValidatedMediaToImageTransport = v;
    g.encodeEditMessage = e;
    g.encodeReactionMessage = f;
    g.asConsumerApplicationLSDb = I
}), 98);
__d("encodeMAWDocumentFileMessage", ["MAWAsConsumerApplication", "WAMediaTransport.pb", "encodeProtobuf", "validateMAWMediaAndComposeEntryForProtoMsg"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return h(a.msgId, b)
    }

    function h(a, b) {
        a = c("validateMAWMediaAndComposeEntryForProtoMsg")(a, b);
        b = a[0];
        a = a[1];
        return i(b, a)
    }

    function i(a, b) {
        b = {
            ancillary: {},
            integral: {
                transport: {
                    ancillary: {
                        fileLength: a.size,
                        mimetype: d("MAWAsConsumerApplication").FILE_MIME_TYPE,
                        objectId: b.objectId,
                        thumbnail: {
                            jpegThumbnail: new ArrayBuffer(1),
                            thumbnailHeight: 1,
                            thumbnailWidth: 1
                        }
                    },
                    integral: {
                        directPath: b.directPath,
                        fileEncSha256: b.fileEncSha256,
                        fileSha256: b.fileSha256,
                        mediaKey: b.mediaKey,
                        mediaKeyTimestamp: b.mediaKeyTimestamp
                    }
                }
            }
        };
        b = d("encodeProtobuf").encodeProtobuf(d("WAMediaTransport.pb").DocumentTransportSpec, b);
        return {
            payload: {
                content: {
                    documentMessage: {
                        document: {
                            payload: b.readBuffer(),
                            version: 1
                        },
                        fileName: (b = a.validatedDocumentFileInfo) == null ? void 0 : b.filename
                    }
                }
            }
        }
    }
    g["default"] = a
}), 98);
__d("WAMsgIdToMessageKey", ["WAGlobals", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.author,
            c = a.externalId;
        a = a.chat;
        var e = d("WAJids").isAuthorMe(b),
            f = d("WAJids").interpretAsGroupJid(a);
        b = e ? d("WAGlobals").getMyUserJid() : b;
        a = a;
        f = f != null ? b : void 0;
        return {
            fromMe: e,
            id: c,
            remoteJid: a,
            participant: f
        }
    }
    g.msgIdToMessageKey = a
}), 98);
__d("WAAsConsumerApplication", ["WAAssertUnreachable", "WAConsumerApplication.pb", "WAMsgIdToMessageKey", "WAMsgType", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = "image/jpeg";
    e = "video/mp4";
    f = "audio/wav";
    var h = "image/gif",
        i = "image/webp";

    function a(a) {
        switch (a.type) {
            case d("WAMsgType").MSG_TYPE.TEXT:
                return j(a);
            case d("WAMsgType").MSG_TYPE.REACTION:
                return k(a);
            case d("WAMsgType").MSG_TYPE.REVOKED:
                return l(a);
            default:
                return c("WAAssertUnreachable")(a.type)
        }
    }

    function j(a) {
        var b = {
            payload: {
                content: {
                    messageText: {
                        mentionedJid: [],
                        text: a.msgContent.content
                    }
                }
            }
        };
        if (a.specialTextSize != null) {
            a = a.specialTextSize === 1 ? d("WAConsumerApplication.pb").CONSUMER_APPLICATION_METADATA_SPECIAL_TEXT_SIZE.SMALL : a.specialTextSize === 2 ? d("WAConsumerApplication.pb").CONSUMER_APPLICATION_METADATA_SPECIAL_TEXT_SIZE.MEDIUM : d("WAConsumerApplication.pb").CONSUMER_APPLICATION_METADATA_SPECIAL_TEXT_SIZE.LARGE;
            b.metadata = {
                specialTextSize: a
            }
        }
        return b
    }

    function k(a) {
        if (a.reactToMsgId == null) throw c("err")("cannot send reaction that reacts to no message");
        var b = d("WAMsgIdToMessageKey").msgIdToMessageKey(a.reactToMsgId);
        b = {
            groupingKey: a.groupingKey == null ? void 0 : a.groupingKey,
            key: b,
            senderTimestampMs: a.ts,
            text: a.reaction == null ? void 0 : a.reaction
        };
        return {
            payload: {
                content: {
                    reactionMessage: b
                }
            }
        }
    }

    function l(a) {
        a = {
            remoteJid: a.id.chat,
            fromMe: !0,
            id: a.revokedExternalId
        };
        return {
            payload: {
                applicationData: {
                    revoke: {
                        key: a
                    }
                }
            }
        }
    }
    g.IMAGE_MIME_TYPE = b;
    g.VIDEO_MIME_TYPE = e;
    g.AUDIO_MIME_TYPE = f;
    g.GIF_MIME_TYPE = h;
    g.STICKER_MIME_TYPE = i;
    g.asConsumerApplication = a;
    g.encodeTextMessage = j;
    g.encodeReactionMessage = k
}), 98);
__d("WAFrankingTypes", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }

    function b(a) {
        return a
    }
    f.castToFrankingTag = a;
    f.castToFrankingKey = b
}), 66);
__d("WAFranking", ["$InternalEnum", "WACryptoDependencies", "WACryptoHmac", "WACryptoUtils", "WAFrankingTypes", "WAGlobals", "WAPREList", "WAPREMetrics", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 32,
        i = 0,
        j = b("$InternalEnum").Mirrored(["KEEP", "DROP"]);

    function a() {
        var a = new Uint8Array(h);
        d("WACryptoDependencies").getCrypto().getRandomValues(a);
        return d("WAFrankingTypes").castToFrankingKey(a)
    }

    function c(a) {
        return (a = a) != null ? a : i
    }

    function e(a, b) {
        return d("WACryptoHmac").hmacSha256(a, b).then(function(a) {
            return d("WAFrankingTypes").castToFrankingTag(new Uint8Array(a))
        })
    }

    function k(a, c, e, f) {
        var g;
        return b("regeneratorRuntime").async(function(h) {
            while (1) switch (h.prev = h.next) {
                case 0:
                    h.t0 = f;
                    h.next = h.t0 === void 0 ? 3 : h.t0 === 0 ? 3 : 7;
                    break;
                case 3:
                    h.next = 5;
                    return b("regeneratorRuntime").awrap(d("WACryptoHmac").hmacSha256(c, a));
                case 5:
                    g = h.sent;
                    return h.abrupt("return", d("WACryptoUtils").uint8ArraysEqual(new Uint8Array(g), e));
                case 7:
                    return h.abrupt("return", !0);
                case 8:
                case "end":
                    return h.stop()
            }
        }, null, this)
    }

    function f(a, c) {
        var e, f, g, h, i, l, m, n;
        return b("regeneratorRuntime").async(function(o) {
            while (1) switch (o.prev = o.next) {
                case 0:
                    if (!(!d("WAGlobals").getConfig().isFrankingEnabled() || a.version === "v3" && a.type === "instamadillo")) {
                        o.next = 2;
                        break
                    }
                    return o.abrupt("return", {
                        decision: j.KEEP,
                        updatedReportingMeta: c
                    });
                case 2:
                    g = d("WAGlobals").getConfig().isFrankingDropOnInvalid();
                    if (!((c == null ? void 0 : c.frankingTag) != null && ((e = a.metadata) == null ? void 0 : e.frankingKey) == null)) {
                        o.next = 7;
                        break
                    }
                    c.frankingTag = null;
                    c.reportingTag = null;
                    return o.abrupt("return", {
                        decision: j.KEEP,
                        updatedReportingMeta: c
                    });
                case 7:
                    if (!((c == null ? void 0 : c.frankingTag) != null && a.version === "v3" && a.type === "subprotocol" && ((f = a.metadata) == null ? void 0 : f.frankingKey) != null && a.frankingContent != null)) {
                        o.next = 24;
                        break
                    }
                    h = c.frankingTag;
                    i = a.frankingContent, l = a.metadata.frankingVersion;
                    m = d("WAFrankingTypes").castToFrankingKey(new Uint8Array(a.metadata.frankingKey));
                    n = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.FRANKING_VALIDATION);
                    if (!(m == null)) {
                        o.next = 15;
                        break
                    }
                    n.endFail("tagButNoKey");
                    return o.abrupt("return", g ? {
                        decision: j.DROP,
                        updatedReportingMeta: c
                    } : {
                        decision: j.KEEP,
                        updatedReportingMeta: c
                    });
                case 15:
                    o.next = 17;
                    return b("regeneratorRuntime").awrap(k(new Uint8Array(i), m, h, l));
                case 17:
                    if (o.sent) {
                        o.next = 20;
                        break
                    }
                    n.endFail("tagMismatch");
                    return o.abrupt("return", g ? {
                        decision: j.DROP,
                        updatedReportingMeta: c
                    } : {
                        decision: j.KEEP,
                        updatedReportingMeta: c
                    });
                case 20:
                    c.frankingKey = m;
                    c.reportingContent = i;
                    n.endSuccess();
                    return o.abrupt("return", {
                        decision: j.KEEP,
                        updatedReportingMeta: c
                    });
                case 24:
                    return o.abrupt("return", d("WAGlobals").getConfig().isFrankingDropOnMissing() ? {
                        decision: j.DROP,
                        updatedReportingMeta: c
                    } : {
                        decision: j.KEEP,
                        updatedReportingMeta: c
                    });
                case 25:
                case "end":
                    return o.stop()
            }
        }, null, this)
    }
    g.FrankingDecision = j;
    g.createFrankingKey = a;
    g.getFrankingVersion = c;
    g.genFrankingTag = e;
    g.validateFrankingTag = k;
    g.handleAndValidateFrankingFromIncomingMsg = f
}), 98);
__d("WAAsMessageApplication", ["WAAsConsumerApplication", "WAConsumerApplication.pb", "WAFranking", "WAMsgApplication.pb", "encodeProtobuf"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b;
        switch (a.type) {
            default: b = d("WAAsConsumerApplication").asConsumerApplication(a)
        }
        var c = a.forwardingScore != null ? a.forwardingScore : 0;
        a = a.isForwarded != null ? a.isForwarded : !1;
        c = {
            metadata: {
                chatEphemeralSetting: null,
                forwardingScore: c,
                frankingKey: d("WAFranking").createFrankingKey(),
                frankingVersion: d("WAFranking").getFrankingVersion(),
                isForwarded: a,
                quotedMessage: null
            }
        };
        if (b != null) {
            a = d("encodeProtobuf").encodeProtobuf(d("WAConsumerApplication.pb").ConsumerApplicationSpec, b);
            c.payload = {
                subProtocol: {
                    consumerMessage: {
                        payload: a.readBuffer(),
                        version: 1
                    }
                }
            }
        }
        return d("encodeProtobuf").encodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, c).readByteArray()
    }

    function b(a) {
        return a
    }
    g.asMessageApplication = a;
    g.castToMessageApplicationBytes = b
}), 98);
__d("MAWAsMessageApplication", ["I64", "LSIntEnum", "LSMessageReplySourceTypeV2", "MAWAsArmadilloApplication", "MAWAsConsumerApplication", "MAWJids", "MAWMsgType", "WAArmadilloApplication.pb", "WAAsMessageApplication", "WAConsumerApplication.pb", "WAFranking", "WAGlobals", "WAJids", "WAMsgApplication.pb", "encodeProtobuf"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function a(a, b, c, e, f) {
        return d("WAAsMessageApplication").castToMessageApplicationBytes(d("encodeProtobuf").encodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, j(a, b, c, e, f)).readByteArray())
    }

    function j(a, b, c, e, f) {
        var g, h;
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.RAVEN_ACTION:
                g = d("MAWAsArmadilloApplication").asArmadilloApplication(a);
                break;
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                g = d("MAWAsArmadilloApplication").asArmadilloApplication(a, void 0, f);
                break;
            case d("MAWMsgType").MSG_TYPE.XMA:
                g = d("MAWAsArmadilloApplication").asArmadilloApplication(a, e);
                break;
            default:
                h = d("MAWAsConsumerApplication").asConsumerApplication(a, b, c)
        }
        var i, j;
        f = a.forwardingScore != null ? a.forwardingScore : 0;
        e = a.isForwarded != null ? a.isForwarded : !1;
        if (a.quote != null) {
            b = a.quote;
            i = {
                participant: b.content.author === d("WAJids").AUTHOR_ME ? d("WAGlobals").getMyDeviceJid() : b.content.author,
                stanzaId: b.content.externalId
            }
        }
        if (a.ephemeralSetting) {
            c = a.ephemeralSetting;
            a.type === d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE ? j = {
                ephemeralExpiration: c.ephemeralExpirationInSec,
                isEphemeralSettingReset: a.isEphemeralSettingReset
            } : j = {
                ephemeralExpiration: c.ephemeralExpirationInSec,
                ephemeralSettingTimestamp: c.ephemeralLastUpdatedOrSetTimestamp * 1e3
            }
        }
        b = {
            metadata: {
                chatEphemeralSetting: j,
                forwardingScore: f,
                frankingKey: n(a.reportingMeta),
                frankingVersion: d("WAFranking").getFrankingVersion(),
                groupId: a.groupId,
                groupIndex: a.groupIndex,
                groupSize: a.groupSize,
                isForwarded: e,
                quotedMessage: i
            }
        };
        if (h != null) {
            c = d("encodeProtobuf").encodeProtobuf(d("WAConsumerApplication.pb").ConsumerApplicationSpec, h);
            b.payload = {
                subProtocol: {
                    consumerMessage: {
                        payload: c.readBuffer(),
                        version: 1
                    }
                }
            }
        } else if (g != null) {
            f = d("encodeProtobuf").encodeProtobuf(d("WAArmadilloApplication.pb").ArmadilloSpec, g);
            b.payload = {
                subProtocol: {
                    armadillo: {
                        payload: f.readBuffer(),
                        version: 1
                    }
                }
            }
        }
        return b
    }

    function b(a) {
        var b = d("MAWAsConsumerApplication").asConsumerApplicationLSDb(a),
            e, f, g = a.isForwarded != null ? a.isForwarded : !1,
            j = g ? 1 : 0;
        a.replySourceTypeV2 && !(h || (h = d("I64"))).equal(a.replySourceTypeV2, (i || (i = d("LSIntEnum"))).ofNumber(c("LSMessageReplySourceTypeV2").NONE)) && a.replyToUserId != null && (e = {
            participant: a.replyToUserId === d("WAJids").AUTHOR_ME ? d("WAGlobals").getMyDeviceJid() : d("MAWJids").toUserJid((h || (h = d("I64"))).to_string(a.replyToUserId)),
            stanzaId: a.messageId
        });
        j = {
            metadata: {
                chatEphemeralSetting: f,
                forwardingScore: j,
                frankingKey: d("WAFranking").createFrankingKey(),
                frankingVersion: d("WAFranking").getFrankingVersion(),
                groupId: (j = a == null ? void 0 : a.groupId) != null ? j : void 0,
                groupIndex: a.groupIndex != null ? (h || (h = d("I64"))).to_float(a.groupIndex) : void 0,
                groupSize: a.groupSize != null ? (h || (h = d("I64"))).to_float(a.groupSize) : void 0,
                isForwarded: g,
                quotedMessage: e
            }
        };
        if (b != null) {
            a = d("encodeProtobuf").encodeProtobuf(d("WAConsumerApplication.pb").ConsumerApplicationSpec, b);
            j.payload = {
                subProtocol: {
                    consumerMessage: {
                        payload: a.readBuffer(),
                        version: 1
                    }
                }
            }
        }
        return j
    }

    function e(a) {
        return d("WAAsMessageApplication").castToMessageApplicationBytes(d("encodeProtobuf").encodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, k(a)).readByteArray())
    }

    function k(a) {
        a = d("MAWAsConsumerApplication").encodeReactionMessage(a);
        a = d("encodeProtobuf").encodeProtobuf(d("WAConsumerApplication.pb").ConsumerApplicationSpec, a);
        return {
            metadata: {
                frankingKey: d("WAFranking").createFrankingKey(),
                frankingVersion: d("WAFranking").getFrankingVersion()
            },
            payload: {
                subProtocol: {
                    consumerMessage: {
                        payload: a.readBuffer(),
                        version: 1
                    }
                }
            }
        }
    }

    function f(a) {
        return d("WAAsMessageApplication").castToMessageApplicationBytes(d("encodeProtobuf").encodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, l(a)).readByteArray())
    }

    function l(a) {
        a = d("MAWAsConsumerApplication").encodeEditMessage(a);
        a = d("encodeProtobuf").encodeProtobuf(d("WAConsumerApplication.pb").ConsumerApplicationSpec, a);
        return {
            metadata: {
                frankingKey: d("WAFranking").createFrankingKey(),
                frankingVersion: d("WAFranking").getFrankingVersion()
            },
            payload: {
                subProtocol: {
                    consumerMessage: {
                        payload: a.readBuffer(),
                        version: 1
                    }
                }
            }
        }
    }

    function m(a, b) {
        var c;
        b = d("MAWAsConsumerApplication").deletedMsgAsConsumerApplicationForSpamReporting(a, b);
        if (b == null) return null;
        b = d("encodeProtobuf").encodeProtobuf(d("WAConsumerApplication.pb").ConsumerApplicationSpec, b);
        return {
            metadata: {
                frankingKey: n(a.reportingMeta),
                frankingVersion: ((c = a.reportingMeta) == null ? void 0 : c.frankingVersion) != null ? (c = a.reportingMeta) == null ? void 0 : c.frankingVersion : d("WAFranking").getFrankingVersion()
            },
            payload: {
                subProtocol: {
                    consumerMessage: {
                        payload: b.readBuffer(),
                        version: 1
                    }
                }
            }
        }
    }

    function n(a) {
        if ((a == null ? void 0 : a.frankingKey) != null) return a.frankingKey;
        else return d("WAFranking").createFrankingKey()
    }
    g.encodeMessageApplication = a;
    g.asMessageApplication = j;
    g.asMessageApplicationLSDb = b;
    g.encodeReactionMessageApplication = e;
    g.asReactionMessageApplication = k;
    g.encodeEditMessageApplication = f;
    g.asEditMessageApplication = l;
    g.deletedMsgAsMessageApplicationForSpamReporting = m
}), 98);
__d("MAWXMAEncodeUtils", ["MAWAsConsumerApplication", "MAWAsMessageApplication", "MAWMsgType", "MAWParseSubprotocolVersionConsts", "MAWVault", "WALogger", "WAMsgApplication.pb", "encodeProtobuf", "validateMAWMediaAndComposeEntryForProtoMsg"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Non-text associated message for the XMA content is not supported"]);
        h = function() {
            return a
        };
        return a
    }

    function i(a, b, e) {
        a = c("validateMAWMediaAndComposeEntryForProtoMsg")(a, b);
        b = a[0];
        a = a[1];
        return {
            payload: d("MAWAsConsumerApplication").encodeValidatedMediaToImageTransport(b, a),
            version: e
        }
    }

    function a(a, b) {
        var c, e = a.msgContent,
            f = a.msgId;
        a = e || {};
        e = a.content;
        a = a.mentionedJids;
        var g = b.associatedMessage,
            j = b.favicon,
            k = b.header,
            l = b.previews;
        b = b.xma;
        var m = null;
        if (g != null)
            if (g.type !== d("MAWMsgType").MSG_TYPE.TEXT) d("WALogger").ERROR(h());
            else {
                g = d("MAWAsMessageApplication").asMessageApplication(g);
                g = d("encodeProtobuf").encodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, g);
                m = {
                    payload: g.readBuffer(),
                    version: d("MAWParseSubprotocolVersionConsts").ASSOCIATED_MESSAGE_SUBPROTOCOL_VERSION
                }
            }
        g = k != null && f != null ? i(f, k, d("MAWParseSubprotocolVersionConsts").XMA_HEADER_SUBPROTOCOL_VERSION) : null;
        k = j != null && f != null ? i(f, j, d("MAWParseSubprotocolVersionConsts").XMA_FAVICON_SUBPROTOCOL_VERSION) : null;
        j = l != null && f != null ? l.map(function(a) {
            return i(f, a, d("MAWParseSubprotocolVersionConsts").XMA_PREVIEW_SUBPROTOCOL_VERSION)
        }) : null;
        l = b.defaultCTA == null ? void 0 : [b.defaultCTA].concat(b.ctas).filter(Boolean);
        return {
            payload: {
                content: {
                    extendedContentMessage: {
                        associatedMessage: (c = m) != null ? c : void 0,
                        ctas: l,
                        favicon: (c = k) != null ? c : void 0,
                        headerImage: (l = g) != null ? l : void 0,
                        headerTitle: b.headerTitle,
                        maxSubtitleNumOfLines: b.maxSubtitleNumOfLines,
                        maxTitleNumOfLines: b.maxTitleNumOfLines,
                        mentionedJid: a,
                        messageText: e == null ? void 0 : d("MAWVault").unvault(e),
                        overlayDescription: b.overlayDescription,
                        overlayIconGlyph: b.overlayIconGlyph,
                        overlayTitle: b.overlayTitle,
                        previews: (k = j) != null ? k : [],
                        sentWithMessageId: m ? b.externalId : void 0,
                        subtitleText: b.subtitleText,
                        targetExpiringAtSec: b.targetExpiringAtSec,
                        targetId: b.targetId,
                        targetType: b.targetType,
                        targetUsername: b.targetUsername,
                        titleText: b.titleText,
                        xmaLayoutType: b.xmaLayoutType
                    }
                }
            }
        }
    }
    g.encodeXMA = a
}), 98);
__d("MAWBridgeXMA", ["MAWBridgeUIEventDataValidation", "MAWDbMedia", "WALogger", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["MAWBridge - createBridgeXMA received unexpected media type - ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i(a) {
        if (a == null) return void 0;
        switch (a) {
            case "Image":
            case "Sticker":
                return "image/png";
            case "Gif":
                return "image/gif";
            case "Video":
                return "video/mp4";
            case "Ptt":
                return "audio/wav"
        }
    }

    function a(a, b, e) {
        var f = b.contentRef,
            g = b.ctas,
            j = b.defaultCTA,
            k = b.defaultPreviewMediaId,
            l = b.defaultPreviewMediaPlaintextHash,
            m = b.faviconMediaId,
            n = b.faviconPlaintextHash,
            o = b.headerMediaId,
            p = b.headerMediaPlaintextHash,
            q = b.headerTitle,
            r = b.maxSubtitleNumOfLines,
            s = b.maxTitleNumOfLines,
            t = b.msgId,
            u = b.offlineAttachmentId,
            v = b.overlayIconGlyph,
            w = b.overlayTitle,
            x = b.subtitleText,
            y = b.targetId,
            z = b.targetType,
            A = b.targetUsername,
            B = b.threadJid,
            C = b.titleText,
            D = b.xmaId;
        b = b.xmaLayoutType;
        a != null && a.mediaType !== d("MAWDbMedia").IMAGE && d("WALogger").WARN(h(), a.mediaType);
        y != null && d("MAWBridgeUIEventDataValidation").stringToI64Opt(y);
        return {
            contentRef: f,
            ctas: g,
            defaultCTA: j,
            defaultPreviewMediaId: k,
            defaultPreviewMediaPlaintextHash: l,
            duration: null,
            faviconMediaId: m,
            faviconPlaintextHash: n,
            filesize: a == null ? void 0 : a.size,
            hasMedia: c("gkx")("821") ? e : void 0,
            headerMediaId: o,
            headerMediaPlaintextHash: p,
            headerTitle: q,
            maxSubtitleNumOfLines: r,
            maxTitleNumOfLines: s,
            mediaType: a == null ? void 0 : a.mediaType,
            msgId: t,
            offlineAttachmentId: u,
            overlayIconGlyph: v,
            overlayTitle: w,
            playableUrlMimeType: i(a == null ? void 0 : a.mediaType),
            previewHeight: a == null ? void 0 : (f = a.validatedImageInfo) == null ? void 0 : f.jpegThumbnailHeight,
            previewHeightLarge: a == null ? void 0 : (g = a.validatedImageInfo) == null ? void 0 : g.height,
            previewUrlMimeType: i(a == null ? void 0 : a.mediaType),
            previewWidth: a == null ? void 0 : (j = a.validatedImageInfo) == null ? void 0 : j.jpegThumbnailWidth,
            previewWidthLarge: a == null ? void 0 : (k = a.validatedImageInfo) == null ? void 0 : k.width,
            subtitleText: x,
            targetId: y,
            targetType: z,
            targetUsername: A,
            threadJid: B,
            titleText: C,
            ts: a == null ? void 0 : a.ts,
            xmaId: D,
            xmaLayoutType: b
        }
    }

    function b(a, b) {
        var c = a.msgId;
        a = a.threadJid;
        return {
            msgId: c,
            threadJid: a,
            xmaId: b
        }
    }

    function e(a, b) {
        var c = a.msgId;
        a = a.threadJid;
        return {
            msgId: c,
            threadJid: a,
            xmaId: b
        }
    }
    g.createBridgeXMA = a;
    g.createBridgeXMAShareExpired = b;
    g.createBridgeXMAShareTombstoned = e
}), 98);
__d("MAWUnsafeCoerce", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f.unsafeCoerce = a
}), 66);
__d("MAWBulkEditMsgsTxns", ["FBLogger", "MAWAckLevel", "MAWBridgeMsg", "MAWBridgeTypesCreators", "MAWDbEditMsgHistory", "MAWDbEditMsgHistoryTxns", "MAWDbMsgTxns", "MAWDexieTable", "MAWIndexedDb", "MAWJidUtils", "MAWLoadReplyMediaTxns", "MAWThreadSnippetForTextMsg", "MAWThreadUpdateMiddlewareGKUtil", "MAWUnsafeCoerce", "MAWUserJidWrapper", "WAJids", "WAMsgMap", "WAMsgType", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, e) {
        var f = [];
        for (var g = 0; g < a.length; g++) {
            var h = a[g],
                i = d("MAWJidUtils").maybeToProtocolMsgId(h.author, h.threadJid, h.originalMsgExternalId);
            if (i != null) {
                i = (i = e.get(i)) == null ? void 0 : i.msgId;
                i != null ? f.push(babelHelpers["extends"]({}, h, {
                    editMsgHistoryId: d("MAWDbEditMsgHistory").convertToEditMsgHistoryId64(b[g]),
                    originalMsgId: i
                })) : c("FBLogger")("messenger_e2ee_web").warn("[edit messagehistory] Failed to get the original msgId for a msg that has been edited.")
            }
        }
        d("MAWIndexedDb").afterTransaction({
            tag: "EditMsgHistoryAdded",
            value: f
        })
    }

    function a(a, b) {
        var c = new Set(),
            e = [];
        b.forEach(function(a) {
            var b = a.chatJid;
            a = a.msg;
            c.add(b);
            e.push(a.originalMsgExternalId)
        });
        return d("MAWDexieTable").dexieAll([a.messages.where("externalId").anyOf(e).toArray(), a.messages.where("quoteExternalId").anyOf(e).toArray(), a.editMsgHistory.where("originalMsgExternalId").anyOf(e).toArray(), a.threads.where("jid").anyOf(Array.from(c)).toArray()]).then(function(a) {
            var b = a[0],
                c = a[1],
                d = a[2];
            a = a[3];
            return {
                editMsgHistory: d,
                originalMsgs: b,
                quoteMessages: c,
                threads: a
            }
        })
    }

    function i(a, b, e) {
        var f = new Map();
        b.values().forEach(function(a) {
            var b;
            b = (b = a.threadJid) != null ? b : d("WAJids").unsafeCoerceToChatJid("");
            if (f.has(b)) {
                var c;
                (c = f.get(b)) == null ? void 0 : c.push(a)
            } else f.set(b, [a])
        });
        b = e.map(function(b) {
            return d("MAWDbMsgTxns").getThreadNewestMessageId(a, b.jid).then(function(a) {
                return {
                    editedMsgsInThread: f.get(b.jid),
                    newestMsgId: a,
                    thread: b
                }
            })
        });
        return d("MAWDexieTable").dexieAll(b).then(function(a) {
            a.forEach(function(a) {
                var b = a.editedMsgsInThread,
                    e = a.newestMsgId;
                a = a.thread;
                if (a == null || b == null) return;
                b = b.filter(function(a) {
                    return a.msgId === e
                })[0];
                if (b != null && !d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type)) {
                    var f = b.author;
                    if (f === "@system") throw c("err")("[edit message] author should not be @system.");
                    f = d("WAJids").userIdFromJid(f === "@me" ? d("MAWUserJidWrapper").getMyUserJid() : f);
                    b = c("MAWThreadSnippetForTextMsg")(b, f, d("WAJids").interpretAsGroupJid(a.jid) != null);
                    var g = b.snippetParams;
                    b = b.snippetType;
                    d("MAWIndexedDb").afterTransaction({
                        tag: "ThreadUpdated",
                        value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                            snippetParams: g,
                            snippetSenderContactId: f,
                            snippetType: b,
                            threadJid: a.jid
                        })
                    })
                }
            })
        })
    }

    function b(a, b, e) {
        var f = e.editMsgHistory,
            g = e.originalMsgs,
            j = e.quoteMessages,
            l = e.threads,
            m = g.reduce(function(a, b) {
                var c = d("MAWJidUtils").toProtocolMsgId(b);
                return c == null ? a : a.set(c, b)
            }, new(d("WAMsgMap").MsgMap)());
        e = f.reduce(function(a, b) {
            var c = d("MAWJidUtils").toProtocolMsgId(b);
            return c == null ? a : a.set(c, b)
        }, new(d("WAMsgMap").MsgMap)());
        g = k(b, {
            messageHistoriesToEdit: e,
            messagesToEdit: m
        });
        var n = g[0],
            o = g[1],
            p = g[2];
        return d("MAWDbEditMsgHistoryTxns").bulkAddEditMsgHistory(a, n, !1).then(function(b) {
            h(n, b, m);
            var e = new(d("WAMsgMap").MsgMap)();
            o.entries().forEach(function(a) {
                var b = a[0];
                a = a[1];
                var f = m.get(b);
                if (f == null) {
                    c("FBLogger")("messenger_e2ee_web").warn("Cannot find the original msg for the edit action.");
                    return
                }
                if (f.type !== d("WAMsgType").MSG_TYPE.TEXT && f.type !== d("WAMsgType").MSG_TYPE.CIPHERTEXT) throw c("err")("Only text or cipher text can be edited. Original msg type: %s", f.type);
                f = babelHelpers["extends"]({}, f, {
                    editCount: ((f = f.editCount) != null ? f : 0) + ((f = p.get(b)) != null ? f : 0),
                    msgContent: a.editMsgContent,
                    type: d("WAMsgType").MSG_TYPE.TEXT
                });
                e.set(b, f)
            });
            return i(a, e, l).then(function() {
                var b = j.map(function(a) {
                    var b = a.quote,
                        f = a.quoteExternalId,
                        g = a.threadJid;
                    if (b == null) {
                        c("FBLogger")("messenger_e2ee_web").warn("[edit message] Failed to get the quoted content for a msg that has been quoted.", a.externalId);
                        return
                    }
                    g = d("MAWJidUtils").maybeToProtocolMsgId(b.content.author, g, f);
                    if (g == null) return;
                    f = e.get(g);
                    if (f == null) return;
                    return babelHelpers["extends"]({}, a, {
                        quote: babelHelpers["extends"]({}, b, {
                            content: babelHelpers["extends"]({}, b.content, {
                                msgContent: babelHelpers["extends"]({}, f.msgContent)
                            })
                        })
                    })
                }).filter(Boolean);
                return a.messages.bulkPut(e.values().concat(b)).then(function() {
                    e.values().forEach(function(b) {
                        return d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, b).then(function(a) {
                            d("MAWIndexedDb").afterTransaction({
                                tag: "MsgUpdated",
                                value: d("MAWBridgeMsg").createBridgeMsg(b, void 0, a)
                            })
                        })
                    })
                }).then(function() {
                    b.forEach(function(a) {
                        d("MAWIndexedDb").afterTransaction({
                            tag: "MsgUpdated",
                            value: d("MAWBridgeMsg").createBridgeMsg(a)
                        })
                    })
                })
            })
        })
    }

    function j(a, b) {
        var e;
        switch (a.type) {
            case d("WAMsgType").MSG_TYPE.TEXT:
            case d("WAMsgType").MSG_TYPE.EDIT_ACTION:
                return {
                    author: a.author,
                    editExternalId: a.externalId,
                    editTs: (e = a.serverTs) != null ? e : a.ts,
                    msgContent: (e = a.editMsgContent) != null ? e : d("MAWUnsafeCoerce").unsafeCoerce(a.msgContent),
                    originalMsgExternalId: (e = a.originalMsgExternalId) != null ? e : a.externalId,
                    sendStatus: d("MAWAckLevel").ACK.sent,
                    specialTextSize: a.specialTextSize,
                    threadJid: b
                };
            case d("WAMsgType").MSG_TYPE.CIPHERTEXT:
                return {
                    author: a.author,
                    editExternalId: a.externalId,
                    editTs: (e = a.serverTs) != null ? e : a.ts,
                    msgContent: {
                        content: ""
                    },
                    originalMsgExternalId: a.externalId,
                    sendStatus: d("MAWAckLevel").ACK.sent,
                    specialTextSize: a.specialTextSize,
                    threadJid: b
                };
            default:
                a.type;
                throw c("err")("MAWBulkEditMsgsTxns::getMessageHistory: Unexpected msg type")
        }
    }

    function k(a, b) {
        var e = b.messageHistoriesToEdit,
            f = b.messagesToEdit,
            g = [],
            h = new(d("WAMsgMap").MsgMap)(),
            i = new(d("WAMsgMap").MsgMap)();
        a.forEach(function(a) {
            var b = a.chatJid;
            a = a.msg;
            var k = d("MAWJidUtils").maybeToProtocolMsgId(a.author, b, a.originalMsgExternalId);
            if (k == null) throw c("err")("[protocolMsgId] Cannot get the protocol id for the edit action. isAuthorSystem = %s; chatJid = %s; externalId = %s", d("WAJids").isAuthorSystem(a.author), !!b, !!a.originalMsgExternalId);
            var l = d("MAWJidUtils").maybeToProtocolMsgId(a.author, b, a.externalId);
            if (l == null) throw c("err")("[editMsgProtocolMsgId] Cannot get the protocol id for the edit action. isAuthorSystem = %s; chatJid = %s; externalId = %s", d("WAJids").isAuthorSystem(a.author), !!b, !!a.externalId);
            if (e.get(l) == null) {
                g.push(j(a, b));
                l = (l = i.get(k)) != null ? l : 0;
                var m = f.get(k);
                i.set(k, l + 1);
                if (e.get(k) == null && l === 0 && m != null) {
                    if (m.type !== d("WAMsgType").MSG_TYPE.TEXT && m.type !== d("WAMsgType").MSG_TYPE.CIPHERTEXT) throw c("err")("Only text or cipher text can be edited. Original msg type: %s", m.type);
                    g.push(j(m, b))
                }
            }
            l = h.get(k);
            m = l == null ? void 0 : l.serverTs;
            b = a == null ? void 0 : a.serverTs;
            (m == null || b == null || m < b) && h.set(k, a)
        });
        return [g, h, i]
    }
    g.prepareDataForMessageEdit = a;
    g.bulkEditMsgs = b;
    g.getMessageHistory = j
}), 98);
__d("MAWDbReactionUtils", ["MAWBridgeTypesCreators", "MAWIndexedDb"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.author,
            c = a.reaction,
            e = a.reactToMsgId,
            f = a.threadJid;
        a = a.ts;
        if (e == null) return;
        d("MAWIndexedDb").afterTransaction(c == null ? {
            tag: "DeleteReaction",
            value: d("MAWBridgeTypesCreators").createBridgeDeleteReaction({
                author: b,
                chatJid: f,
                reactToMsgId: e
            })
        } : {
            tag: "UpsertReaction",
            value: d("MAWBridgeTypesCreators").createBridgeUpsertReaction({
                author: b,
                chatJid: f,
                reaction: c || "",
                reactToMsgId: e,
                ts: a
            })
        })
    }
    g.dispatchReaction = a
}), 98);
__d("MAWBulkPutReactionsWithThreadUpdateTxn", ["MAWBridgeBuildThreadSnippet", "MAWBridgeTypesCreators", "MAWBridgeUIEventDataValidation", "MAWDbReaction", "MAWDbReactionUtils", "MAWDbReactionsTxns", "MAWDexieTable", "MAWJidUtils", "MAWThreadSnippetBuildTxns", "MAWTransactor", "Promise", "WAArrayGroupBy", "WAJids", "WAMsgMap", "asyncToGeneratorRuntime", "cr:3061", "emptyFunction", "err", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a) {
        return a.reduce(function(a, b) {
            var c = d("MAWJidUtils").maybeToProtocolMsgId(b.author, b.threadJid, b.reactToExternalId);
            if (c == null) return a;
            a.set(c, d("MAWDbReactionsTxns").coerceToReaction(b));
            return a
        }, new(d("WAMsgMap").MsgMap)()).values()
    }

    function a(a, e, f, g) {
        if (e.length === 0) return d("MAWDexieTable").dexieResolve();
        e = i(e);
        var j = e.map(function(a) {
            var b = f.get(a.threadJid);
            if (b == null) throw c("err")("Should not have got here - expect thread to exist for flow");
            c("qex")._("1215") !== !0 && g !== !0 && d("MAWDbReactionUtils").dispatchReaction(a);
            return a
        });
        e = d("WAArrayGroupBy").groupBy(j, function(a) {
            a = a.threadJid;
            return a
        });
        e = e.map(function(b) {
            var c = b[0];
            b = b[1];
            c = f.get(c);
            if (c == null || b.length === 0) return null;
            var e = null;
            for (var g = b.length - 1; g >= 0; g--) {
                e = d("MAWDbReaction").castToIncomingDbReaction(b[g]);
                if (e != null) break
            }
            g = b.filter(function(a) {
                return a.reaction == null
            });
            b = d("WAJids").interpretAsGroupJid(c.jid) != null;
            return d("MAWThreadSnippetBuildTxns").getThreadChangesetForReactionChanges(a, c, {
                newestReaction: e,
                reactionsToClear: g
            }, b)
        }).filter(Boolean);
        return d("MAWDexieTable").dexieAll(e).then(function(e) {
            return d("MAWDexieTable").dexieAll([a.threads.bulkPut(e.map(function(a) {
                a = a.thread;
                return a
            })), a.reactions.bulkPut(j)]).then(function() {
                if (c("qex")._("1215") === !0 && b("cr:3061") != null) return d("MAWTransactor").runInLSDB(function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                        yield(h || (h = b("Promise"))).all(e.map(function() {
                            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(c) {
                                var e = c.newestReaction;
                                c = c.thread;
                                var f = (yield b("cr:3061").getOrCreateOptimisticThreadKey(a, c.jid));
                                f = (yield a.threads.get(f));
                                if (f != null && e != null && c.snippetMsg != null && e.author != null) {
                                    var g = d("WAJids").interpretAsGroupJid(c.jid) != null;
                                    e = d("MAWThreadSnippetBuildTxns").getReactionSnippetParams(e.author, e.reaction, g);
                                    g = e.snippetParams;
                                    var h = e.snippetSenderContactId;
                                    e = e.snippetType;
                                    g = d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                                        snippetParams: g,
                                        snippetSenderContactId: h,
                                        snippetType: e,
                                        threadJid: c.jid
                                    });
                                    h = d("MAWBridgeBuildThreadSnippet").buildBridgeThreadSnippet(g, f.snippet);
                                    yield a.threads.put(babelHelpers["extends"]({}, f, {
                                        snippet: h,
                                        snippetSenderContactId: g.snippetSenderContactId != null ? d("MAWBridgeUIEventDataValidation").stringToI64Opt(g.snippetSenderContactId) : void 0
                                    }))
                                }
                            });
                            return function(a) {
                                return c.apply(this, arguments)
                            }
                        }()))
                    });
                    return function(b) {
                        return a.apply(this, arguments)
                    }
                }())
            }).then(c("emptyFunction"))
        })
    }
    g.bulkPutReactionsWithThreadUpdates = a
}), 98);
__d("MAWBulkWriteReactionsTxns", ["FBLogger", "LSMEBTaskCreationSource", "MAWAuthor", "MAWBridgeEventTransmitter", "MAWBulkPutReactionsWithThreadUpdateTxn", "MAWDbMsg", "MAWDbReaction", "MAWDbReactionsTxns", "MAWDexieTable", "MAWEncryptedBackupCacheManager", "MAWODSProxy", "WAArrayGroupBy", "WAJids", "WAOdsEnums", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var e = [],
            f = [];
        b.forEach(function(a) {
            var b = a.chatJid;
            a = a.unstoredReaction;
            a = a.reactToExternalId;
            e.push(b);
            f.push(a)
        });
        return d("MAWDexieTable").dexieAll([a.threads.where("jid").anyOf(e).toArray(), a.messages.where("externalId").anyOf(f).toArray(), a.reactions.where("reactToExternalId").anyOf(f).toArray()]).then(function(e) {
            var f = e[0],
                g = e[1];
            e = e[2];
            var i = new Map(f.map(function(a) {
                    return [a.jid, a]
                })),
                j = new Map(d("WAArrayGroupBy").groupBy(g, function(a) {
                    return a.externalId
                })),
                k = new Map(d("WAArrayGroupBy").groupBy(e, function(a) {
                    return a.reactToExternalId
                })),
                l = [];
            g = f.map(function(b) {
                return d("MAWDbReactionsTxns").getNextReactionIdNumberForThread(a, b).then(function(a) {
                    return [b.jid, a]
                })
            });
            return d("MAWDexieTable").dexieAll(g).then(function(a) {
                var e = new Map(a);
                b.forEach(function(a) {
                    var b = a.chatJid;
                    a = a.unstoredReaction;
                    var f = a.author,
                        g = a.externalId,
                        m = a.groupingKey,
                        n = a.reaction,
                        o = a.reactToAuthor,
                        p = a.reactToExternalId,
                        q = a.senderTimestampMs,
                        r = a.ts;
                    b = i.get(b);
                    if (b == null) return "missing_thread";
                    var s = e.get(b.jid);
                    if (s == null) throw c("err")("nextInChatReactionId should not be null");
                    e.set(b.jid, s + 1);
                    var t = k.get(a.reactToExternalId) || [];
                    t = d("MAWDbReaction").findMatchingReaction(t, b.jid, f);
                    if (t != null && d("MAWDbReaction").getReactionTimeMs(t) > d("MAWDbReaction").getReactionTimeMs(a)) return "newer_reaction_exists";
                    var u = d("MAWAuthor").getAuthorUserJid(o),
                        v = j.get(a.reactToExternalId);
                    if (v == null && !d("MAWEncryptedBackupCacheManager").peekRestoreCache(a.reactToExternalId)) {
                        var w = d("WAJids").threadIdForChatJid(b.jid);
                        d("MAWEncryptedBackupCacheManager").addMsgEntryToReuploadCache(b.jid, a.reactToExternalId);
                        d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(a.reactToExternalId, w, void 0, c("LSMEBTaskCreationSource").EB_POINT_QUERY_IN_ACT_REACTIONS, b.jid)
                    }
                    a = h(b, u, v);
                    u = d("MAWDbReaction").formatReactionForDb(b.jid, g, d("MAWDbMsg").craftReactionId(b.chatId, s), p, n, m, o, a == null ? void 0 : a.msgId, r, (w = f) != null ? w : d("WAJids").AUTHOR_ME, t == null ? void 0 : t.rowId, void 0, q);
                    l.push(u)
                });
                return {
                    chatJidToDbThread: i,
                    unstoredDbReactionsForInsertion: l
                }
            })
        })
    }

    function h(a, b, e) {
        e = (e = e == null ? void 0 : e.filter(function(c) {
            return c.threadJid === a.jid && b === d("MAWAuthor").getAuthorUserJid(c.author)
        })) != null ? e : [];
        e.length > 1 && (c("FBLogger")("maw_mutation_validator").warn("%s matching duplicate messages found for a reaction", e.length), d("MAWODSProxy").odsBumpEntityKey({
            entity: d("WAOdsEnums").Entity.MAW_MUTATION_VALIDATOR,
            key: "match_reaction_to_message.invalid"
        }));
        return e[0]
    }

    function b(a, b, c) {
        var e = b.chatJidToDbThread;
        b = b.unstoredDbReactionsForInsertion;
        return d("MAWBulkPutReactionsWithThreadUpdateTxn").bulkPutReactionsWithThreadUpdates(a, b, e, c)
    }
    g.prepareReactionsData = a;
    g.bulkWriteReactions = b
}), 98);
__d("MAWCastToServerMediaType", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case "document":
            case "image":
            case "xma-image":
            case "video":
            case "ptt":
            case "gif":
            case "sticker":
                return a;
            default:
                return null
        }
    }
    f.castToServerMediaType = a
}), 66);
__d("MAWCiphertextRecoveryLogging", ["FBLogger", "MAWMsgType", "ODS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b) {
        var c = new Set(a.filter(function(a) {
            return a.type === d("MAWMsgType").MSG_TYPE.CIPHERTEXT
        }).map(function(a) {
            return a.externalId
        }));
        a = b.filter(function(a) {
            return a.type !== d("MAWMsgType").MSG_TYPE.CIPHERTEXT && c.has(a.externalId)
        });
        if (a.length === 0) return;
        i(a.length)
    }

    function i(a) {
        a === void 0 && (a = 1), (h || (h = d("ODS"))).bumpEntityKey(3185, "mwchat_ciphertext_recovered_by_eb", "Ciphertext recovered by EB", a), c("FBLogger")("mwchat_ciphertext_recovered_by_eb").info("Ciphertext recovered by EB, count: %s", a)
    }
    g.compareAndLogCiphertextRecoveredByEB = a;
    g.logCiphertextRecoveredByEB = i
}), 98);
__d("MAWConvertXMAGatingTypeToExtendedContentOverlayIconGlyph", ["EchoMessageXMAFieldUtils", "WAArmadilloXMA.pb", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid xmaGatingType: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case d("EchoMessageXMAFieldUtils").XMAGatingType.INFO:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.INFO;
            case d("EchoMessageXMAFieldUtils").XMAGatingType.EYE_OFF:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.EYE_OFF;
            case d("EchoMessageXMAFieldUtils").XMAGatingType.NEWS_OFF:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.NEWS_OFF;
            case d("EchoMessageXMAFieldUtils").XMAGatingType.WARNING:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.WARNING;
            case d("EchoMessageXMAFieldUtils").XMAGatingType.PRIVATE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.PRIVATE;
            case d("EchoMessageXMAFieldUtils").XMAGatingType.NONE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.NONE;
            default:
                d("WALogger").ERROR(h(), a);
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_OVERLAY_ICON_GLYPH.NONE
        }
    }
    g.convertXMAGatingTypeToExtendedContentOverlayIconGlyph = a
}), 98);
__d("MAWConvertXMALayoutTypeToExtendedContentXMLLayoutType", ["EchoMessageXMAFieldUtils", "WAArmadilloXMA.pb", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid xmaLayoutType: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case d("EchoMessageXMAFieldUtils").XMALayoutType.SINGLE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_XMA_LAYOUT_TYPE.SINGLE;
            case d("EchoMessageXMAFieldUtils").XMALayoutType.PORTRAIT:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_XMA_LAYOUT_TYPE.PORTRAIT;
            default:
                d("WALogger").ERROR(h(), a);
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_XMA_LAYOUT_TYPE.SINGLE
        }
    }
    g.convertXMALayoutTypeToExtendedContentXMLLayoutType = a
}), 98);
__d("MAWConvertXMATargetTypeToExtendedContentTargetType", ["EchoMessageXMAFieldUtils", "WAArmadilloXMA.pb", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a valid xmaTargetType: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        switch (a) {
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_PHOTO_MENTION:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_MENTION;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_SINGLE_IMAGE_POST_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_SINGLE_IMAGE_POST_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_MULTIPOST_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_MULTIPOST_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_SINGLE_VIDEO_POST_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_SINGLE_VIDEO_POST_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_PHOTO_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_VIDEO_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_VIDEO_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_CLIPS_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_CLIPS_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_IGTV_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_IGTV_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_SHOP_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_SHOP_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_PROFILE_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_PROFILE_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_PHOTO_HIGHLIGHT_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_HIGHLIGHT_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_VIDEO_HIGHLIGHT_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_VIDEO_HIGHLIGHT_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_REPLY:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_REPLY;
            case d("EchoMessageXMAFieldUtils").XMAContentType.IG_STORY_REACTION:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_REACTION;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_FEED_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_FEED_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_STORY_REPLY:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_REPLY;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_STORY_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_STORY_MENTION:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_MENTION;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_FEED_VIDEO_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_FEED_VIDEO_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_GAMING_CUSTOM_UPDATE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_GAMING_CUSTOM_UPDATE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_PRODUCER_STORY_REPLY:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_PRODUCER_STORY_REPLY;
            case d("EchoMessageXMAFieldUtils").XMAContentType.MSG_EXTERNAL_LINK_SHARE:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_EXTERNAL_LINK_SHARE;
            case d("EchoMessageXMAFieldUtils").XMAContentType.RTC_AUDIO_CALL:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_AUDIO_CALL;
            case d("EchoMessageXMAFieldUtils").XMAContentType.RTC_VIDEO_CALL:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_VIDEO_CALL;
            case d("EchoMessageXMAFieldUtils").XMAContentType.RTC_MISSED_AUDIO_CALL:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_MISSED_AUDIO_CALL;
            case d("EchoMessageXMAFieldUtils").XMAContentType.RTC_MISSED_VIDEO_CALL:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_MISSED_VIDEO_CALL;
            case d("EchoMessageXMAFieldUtils").XMAContentType.RTC_GROUP_AUDIO_CALL:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_GROUP_AUDIO_CALL;
            case d("EchoMessageXMAFieldUtils").XMAContentType.RTC_GROUP_VIDEO_CALL:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_GROUP_VIDEO_CALL;
            case d("EchoMessageXMAFieldUtils").XMAContentType.FB_EVENT:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_EVENT;
            case d("EchoMessageXMAFieldUtils").XMAContentType.MSG_RECEIVER_FETCH:
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_RECEIVER_FETCH;
            default:
                d("WALogger").ERROR(h(), a);
                return d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_EXTERNAL_LINK_SHARE
        }
    }
    g.convertXMATargetTypeToExtendedContentTargetType = a
}), 98);
__d("MAWJobPersistenceAccessorsApi", ["MAWJobActionsV2", "MAWJobsIndexedDb", "MAWTransactionMode"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a, b, c;
        return {
            deletePersistedJob: (a = d("MAWJobsIndexedDb")).makeJobsTransactor("jobs", (b = d("MAWTransactionMode")).READWRITE, "deletePersistedJob")((c = d("MAWJobActionsV2")).deletePersistedJob),
            loadAllJobs: a.makeJobsTransactor("jobs", b.READONLY, "loadAllJobs")(c.readAllPersistedJobs),
            maybeCreateJob: a.makeJobsTransactor("jobs", b.READWRITE, "maybeCreateJob")(c.maybeCreateJob),
            readPersistedJob: a.makeJobsTransactor("jobs", b.READONLY, "readPersistedJob")(c.readPersistedJob),
            updatePersistedJob: a.makeJobsTransactor("jobs", b.READWRITE, "updatePersistedJob")(c.updatePersistedJob)
        }
    }
    g.getJobPersistenceAccessors = a
}), 98);
__d("WAJobRequirement", ["Promise", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["JobRequirement[", "] blocker errored ", ""]);
        i = function() {
            return a
        };
        return a
    }
    c = function() {
        function a(a) {
            var c = this;
            this.$1 = (h || (h = b("Promise"))).resolve();
            this.$2 = !0;
            this.$3 = null;
            this.$4 = function() {
                var a = c.$3;
                if (a != null) {
                    c.$3 = null;
                    return (h || (h = b("Promise"))).all(a).then(c.$4)
                }
                c.$2 = !0
            };
            this.name = a
        }
        var c = a.prototype;
        c.addBlocker = function(a) {
            var c = this;
            a = a["catch"](function(a) {
                d("WALogger").ERROR(i(), c.name, a).sendLogs("job-blocker-rejected")
            });
            if (this.$2) this.$2 = !1, this.$1 = (h || (h = b("Promise"))).all([this.$1, a]).then(this.$4);
            else {
                var e = this.$3;
                e != null ? e.push(a) : this.$3 = [a]
            }
        };
        c.waitUntilSatisfied = function() {
            return this.$1
        };
        c.isSatisfied = function() {
            return this.$2
        };
        c.isSatisfiable = function() {
            return !0
        };
        return a
    }();
    e = function(a) {
        babelHelpers.inheritsLoose(c, a);

        function c(c) {
            c = a.call(this, c) || this;
            a.prototype.addBlocker.call(babelHelpers.assertThisInitialized(c), new(h || (h = b("Promise")))(function() {}));
            return c
        }
        var d = c.prototype;
        d.addBlocker = function() {};
        d.isSatisfiable = function() {
            return !1
        };
        return c
    }(c);

    function a(a, c) {
        var d = a.filter(function(a) {
            return !a.isSatisfiable()
        });
        if (d.length > 0) {
            var e = d.map(function(a) {
                return a.name
            });
            return function(a) {
                c == null ? void 0 : c("unsatisfiable", e, a);
                return d[0].waitUntilSatisfied()
            }
        }
        var f = a.map(function() {
                return (h || (h = b("Promise"))).resolve()
            }),
            g = (h || (h = b("Promise"))).resolve(),
            i = null,
            j = function c() {
                if (f.every(function(b, c) {
                        return b === a[c].waitUntilSatisfied()
                    })) {
                    i = null;
                    return
                }
                var d = [],
                    e = a.map(function(a) {
                        var b = a.waitUntilSatisfied();
                        a.isSatisfied() || (d.push(a.name), b.then(function() {
                            var b = d.indexOf(a.name);
                            d.splice(b, 1)
                        }));
                        return b
                    });
                f = e;
                i = d;
                return (h || (h = b("Promise"))).all(e).then(c)
            };
        return function(a) {
            if (i == null) {
                var b = j();
                b != null && (g = g.then(function() {
                    return b
                }))
            }
            c == null ? void 0 : c(i == null ? "satisfied" : "unsatisfied", i, a);
            return g
        }
    }
    g.JobRequirement = c;
    g.UnsatisfiableJobRequirement = e;
    g.joinRequirements = a
}), 98);
__d("WAJobPriorityBucket", ["WAJobOrchestratorTypes", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Assertion failed::markJobTaskDone found jobId: ", " in scheduled tasks"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Assertion failed::markJobTaskPending found jobId: ", " in pending tasks"]);
        i = function() {
            return a
        };
        return a
    }
    a = function() {
        function a(a) {
            this.tasks = [];
            this.pendingTasks = [];
            this.lastJobStartedTimestampMs = null;
            this.jobMaxConcurrency = (a = a.jobMaxConcurrencyMap) != null ? a : {}
        }
        var b = a.prototype;
        b.updateConfig = function(a) {
            this.jobMaxConcurrency = (a = a.jobMaxConcurrencyMap) != null ? a : {}
        };
        b.getStats = function() {
            return [].concat(this.tasks, this.pendingTasks).reduce(function(a, b) {
                var c;
                c = (c = a[b.jobName]) != null ? c : 0;
                a[b.jobName] = c + 1;
                return a
            }, {})
        };
        b.next = function() {
            var a = this;
            if (this.tasks.length === 0) return null;
            var b = this.pendingTasks.reduce(function(a, b) {
                    var c;
                    c = (c = a.get(b.jobName)) != null ? c : 0;
                    a.set(b.jobName, c + 1);
                    return a
                }, new Map()),
                c = this.tasks.filter(function(c) {
                    var e;
                    return ((e = b.get(c.jobName)) != null ? e : 0) < ((e = a.jobMaxConcurrency[c.jobName]) != null ? e : d("WAJobOrchestratorTypes").DEFAULT_CONCURRENCY)
                });
            return c.length > 0 ? [c[0]] : null
        };
        b.add = function(a, b, c, d) {
            c = {
                jobId: c,
                jobInfo: b,
                jobName: a,
                run: d
            };
            this.tasks.push(c);
            return c
        };
        b.markJobTaskPending = function(a) {
            this.pendingTasks.includes(function(b) {
                return b.jobId === a.jobId
            }) && d("WALogger").ERROR(i(), a.jobId).sendLogs("JobOrchestrator::markJobTaskPending"), this.lastJobStartedTimestampMs = Date.now(), this.pendingTasks.push(a), this.tasks = this.tasks.filter(function(b) {
                return b.jobId !== a.jobId
            })
        };
        b.markJobTaskDone = function(a) {
            this.pendingTasks = this.pendingTasks.filter(function(b) {
                return b.jobId !== a
            }), this.tasks.includes(function(b) {
                return b.jobId === a
            }) && d("WALogger").ERROR(h(), a).sendLogs("JobOrchestrator::markJobTaskDone")
        };
        b.count = function() {
            return this.tasks.length
        };
        b.pendingCount = function() {
            return this.pendingTasks.length
        };
        b.clearWaitingTasks = function() {
            this.tasks = []
        };
        b.clear = function() {
            this.tasks = [], this.pendingTasks = []
        };
        b.getLastJobStartedTimestamp = function() {
            return this.lastJobStartedTimestampMs
        };
        return a
    }();
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.next = function() {
            var a = this,
                b, c;
            if (this.tasks.length === 0) return null;
            var d = this.pendingTasks.reduce(function(a, b) {
                    var c;
                    c = (c = a.get(b.jobName)) != null ? c : 0;
                    a.set(b.jobName, c + 1);
                    return a
                }, new Map()),
                e = this.tasks.filter(function(b) {
                    var c;
                    return ((c = d.get(b.jobName)) != null ? c : 0) < ((c = a.jobMaxConcurrency[b.jobName]) != null ? c : 1)
                });
            if (e.length === 0) return null;
            b = (b = this.jobMaxConcurrency[e[0].jobName]) != null ? b : 1;
            c = (c = d.get(e[0].jobName)) != null ? c : 0;
            if (b > 1 && c < b) {
                var f = e.filter(function(a) {
                    return a.jobName === e[0].jobName
                });
                b = Math.min(f.length, b - c);
                return f.slice(0, b)
            }
            return [e[0]]
        };
        return b
    }(a);
    g.BaseJobBucket = a;
    g.LowJobBucket = b
}), 98);
__d("WAMetrics", ["Promise", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        var a = d("WATimeUtils").performanceAbsoluteNow();
        return new(h || (h = b("Promise")))(function(b) {
            setTimeout(function() {
                b(d("WATimeUtils").performanceAbsoluteNow() - a)
            }, 0)
        })
    }
    g.getEventLoopDelay = a
}), 98);
__d("WAConcurrentBucketJobQueue", ["Promise", "WABase64", "WACustomError", "WAJobOrchestratorTypes", "WAJobPriorityBucket", "WALogger", "WAMetrics", "WANullthrows", "WAPromiseTimeout", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[job-orchestator]: ", " exceeding the timeout, release the thread."]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[job-orchestator]: updated WAConcurrentBucketJobQueue config"]);
        j = function() {
            return a
        };
        return a
    }
    var k = 30,
        l = new Map([
            [d("WAJobOrchestratorTypes").JOB_PRIORITY.HIGH, 5],
            [d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW, 1]
        ]);
    a = function() {
        function a() {
            this.$1 = !1, this.$2 = 0, this.$3 = 0, this.$4 = 0, this.$5 = new Map(), this.$6 = new Map(), this.$7 = new Map(), this.$9 = 0
        }
        var e = a.prototype;
        e.init = function(a, b) {
            var e, f, g;
            if (this.$1) throw c("err")("WAConcurrentBucketJobQueue has already initialized");
            this.$4 = (e = a == null ? void 0 : a.bestEffortWaitTimeoutSec) != null ? e : k;
            this.$2 = a.maxConcurrency;
            this.$3 = a.maxConcurrency;
            this.$8 = b;
            this.$7 = this.$11(a == null ? void 0 : a.jobPrioritiesQuota);
            this.$6 = new Map(this.$7);
            this.$5 = new Map();
            this.$9 = Date.now();
            b = new(d("WAJobPriorityBucket").BaseJobBucket)({
                jobMaxConcurrencyMap: (e = a.maxConcurrencyPerJob) != null ? e : {}
            });
            e = new(d("WAJobPriorityBucket").LowJobBucket)({
                jobMaxConcurrencyMap: (e = a.maxConcurrencyPerJob) != null ? e : {}
            });
            f = new(d("WAJobPriorityBucket").LowJobBucket)({
                jobMaxConcurrencyMap: (f = a.maxConcurrencyPerJob) != null ? f : {}
            });
            g = new(d("WAJobPriorityBucket").BaseJobBucket)({
                jobMaxConcurrencyMap: (g = a.maxConcurrencyPerJob) != null ? g : {}
            });
            a = new(d("WAJobPriorityBucket").BaseJobBucket)({
                jobMaxConcurrencyMap: (a = a.maxConcurrencyPerJob) != null ? a : {}
            });
            this.$5.set(d("WAJobOrchestratorTypes").JOB_PRIORITY.UI_ACTION, b);
            this.$5.set(d("WAJobOrchestratorTypes").JOB_PRIORITY.HIGH, b);
            this.$5.set(d("WAJobOrchestratorTypes").JOB_PRIORITY.OFFLINE, g);
            this.$5.set(d("WAJobOrchestratorTypes").JOB_PRIORITY.HISTORY_SYNC, a);
            this.$5.set(d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW, e);
            this.$5.set(d("WAJobOrchestratorTypes").JOB_PRIORITY.BEST_EFFORT, f);
            this.$1 = !0
        };
        e.updateConfig = function(a) {
            this.$3 += a.maxConcurrency - this.$2, this.$2 = a.maxConcurrency, this.$5.forEach(function(b) {
                return b.updateConfig({
                    jobMaxConcurrencyMap: (b = a.maxConcurrencyPerJob) != null ? b : {}
                })
            }), this.$7 = this.$11(a == null ? void 0 : a.jobPrioritiesQuota), d("WALogger").LOG(j())
        };
        e.isInitialized = function() {
            return this.$1
        };
        e.clearQueue = function() {
            if (!this.$1) throw c("err")("WAConcurrentBucketJobQueue not initialized");
            this.$5.forEach(function(a) {
                return a.clear()
            })
        };
        e.clearQueueByPriority = function(a) {
            if (!this.$1) throw c("err")("WAConcurrentBucketJobQueue not initialized");
            (a = this.$5.get(a)) == null ? void 0 : a.clearWaitingTasks()
        };
        e.getIntStats = function() {
            var a = this,
                b = function(b) {
                    var c;
                    b = a.$5.get(b);
                    return ((c = b == null ? void 0 : b.count()) != null ? c : 0) + ((c = b == null ? void 0 : b.pendingCount()) != null ? c : 0)
                };
            return {
                highPriorityBucketSize: b(d("WAJobOrchestratorTypes").JOB_PRIORITY.HIGH),
                lowPriorityBucketSize: b(d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW),
                bestEffortPriorityBucketSize: b(d("WAJobOrchestratorTypes").JOB_PRIORITY.BEST_EFFORT)
            }
        };
        e.getStringStats = function() {
            var a = this,
                b = function(b) {
                    var c = (b = (b = a.$5.get(b)) == null ? void 0 : b.getStats()) != null ? b : {};
                    b = Object.keys(c).reduce(function(a, b) {
                        var d = a[0];
                        a = a[1];
                        var e = c[b];
                        return e > d ? [e, b] : [d, a]
                    }, [0, null]);
                    b = b[1];
                    return b
                };
            return {
                highPriorityMaxJob: b(d("WAJobOrchestratorTypes").JOB_PRIORITY.HIGH),
                lowPriorityMaxJob: b(d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW),
                bestEffortPriorityMaxJob: b(d("WAJobOrchestratorTypes").JOB_PRIORITY.BEST_EFFORT)
            }
        };
        e.enqueue = function(a, e, f, g) {
            var i, j = this;
            if (!this.$1) return (h || (h = b("Promise"))).reject(c("err")("WAConcurrentBucketJobQueue not initialized"));
            var k, l, m = new(h || (h = b("Promise")))(function(a, b) {
                    k = a, l = b
                }),
                n = babelHelpers["extends"]({
                    priority: d("WAJobOrchestratorTypes").DEFAULT_JOB_PRIORITY
                }, f),
                o = this.getJobBucketByType(n.priority);
            if (!o) return (h || (h = b("Promise"))).reject(c("err")("WAConcurrentBucketJobQueue no bucket for job with name " + a + " was found."));
            void d("WAMetrics").getEventLoopDelay().then(function(a) {
                (g == null ? void 0 : g.isActive()) && (g == null ? void 0 : g.addPoint("measure_event_loop_delay", {
                    "int": {
                        eventLoopDelay: a
                    }
                }))
            });
            g == null ? void 0 : g.addPoint("scheduling_job", {
                string: babelHelpers["extends"]({}, this.getStringStats(), {
                    priority: n.priority
                }),
                "int": babelHelpers["extends"]({}, this.getIntStats(), {
                    maxTimeoutMs: (i = f == null ? void 0 : f.maxTimeoutMs) != null ? i : 0
                })
            });
            var p = n.priority + "-" + a + "-" + ((i = f == null ? void 0 : f.jobId) != null ? i : d("WABase64").randomBase64(8));
            i = o.add(a, n, p, function() {
                var a;
                return b("regeneratorRuntime").async(function(c) {
                    while (1) switch (c.prev = c.next) {
                        case 0:
                            c.prev = 0;
                            j.$8.logJobStarted(p);
                            c.next = 4;
                            return b("regeneratorRuntime").awrap(j.$12(e(), f == null ? void 0 : f.maxTimeoutMs));
                        case 4:
                            a = c.sent;
                            j.$8.logJobCompleted(p);
                            k(a);
                            c.next = 13;
                            break;
                        case 9:
                            c.prev = 9, c.t0 = c["catch"](0), c.t0 instanceof d("WACustomError").TimeoutError ? j.$8.logJobTimeout(p) : j.$8.logJobError(p), l(c.t0);
                        case 13:
                        case "end":
                            return c.stop()
                    }
                }, null, this, [
                    [0, 9]
                ])
            });
            this.$8.logJobCreated({
                jobId: p,
                jobName: a,
                jobPriority: n.priority,
                pendingJobsCount: o.count()
            });
            f && f.priority === d("WAJobOrchestratorTypes").JOB_PRIORITY.UI_ACTION && void this.$13(i);
            this.$14();
            return m
        };
        e.getAvailableThreadsCount = function() {
            return this.$3
        };
        e.getJobQuotaConfig = function() {
            return this.$7
        };
        e.getRemainingJobCountMap = function() {
            return this.$6
        };
        e.getJobBucketByType = function(a) {
            return this.$5.get(a)
        };
        e.getSnapshot = function(a) {
            a = this.getJobBucketByType(a);
            return !a ? null : a.getStats()
        };
        e.$11 = function(a) {
            var b;
            !a ? b = new Map(l) : b = new Map(a);
            b.set(d("WAJobOrchestratorTypes").JOB_PRIORITY.BEST_EFFORT, 0);
            return b
        };
        e.$15 = function(a) {
            return (a = this.$6.get(a)) != null ? a : 0
        };
        e.$16 = function() {
            this.$6 = new Map(this.$7)
        };
        e.$17 = function(a) {
            var b = this;
            a === void 0 && (a = !0);
            var c = 0,
                e = null,
                f = 0;
            this.$5.forEach(function(a, d) {
                c += a == null ? void 0 : a.count();
                f += b.$15(d);
                if (e != null) return;
                a.count() > 0 && b.$15(d) > 0 && (e = a)
            });
            var g = e == null || f === 0;
            g && this.$16();
            if (this.$18(c, g)) return this.getJobBucketByType(d("WAJobOrchestratorTypes").JOB_PRIORITY.BEST_EFFORT);
            return e == null && a ? this.$17(!1) : e
        };
        e.$18 = function(a, b) {
            var c = this;

            function e(a, b) {
                var c = Date.now();
                return a > c ? !1 : c - a < b * 1e3
            }

            function f(a, b) {
                a = Math.ceil(a - Date.now()) + b * 1e3;
                return a > 0 ? a : 0
            }
            var g = this.getJobBucketByType(d("WAJobOrchestratorTypes").JOB_PRIORITY.BEST_EFFORT);
            a = a - ((a = g == null ? void 0 : g.count()) != null ? a : 0);
            var h = g == null ? void 0 : g.getLastJobStartedTimestamp();
            if ((g == null ? void 0 : g.count()) === 0) return !1;
            if (h == null && e(this.$9, this.$4)) {
                if (this.$10 == null) {
                    g = f(this.$9, this.$4);
                    this.$10 = setTimeout(function() {
                        c.$14(), c.$10 = null
                    }, g)
                }
                return !1
            }
            return a > 0 && h != null && e(h, this.$4) ? !1 : b
        };
        e.$19 = function(a) {
            a = this.$20(a);
            return c("WANullthrows")(this.$5.get(a))
        };
        e.$20 = function(a) {
            var b = a.split("-")[0];
            b = d("WAJobOrchestratorTypes").JOB_PRIORITY.cast(b);
            if (!b) throw c("err")("ConcurrentBucketQueue cannot extract known job priority type from id: " + a);
            return b
        };
        e.$21 = function(a) {
            a = this.$20(a);
            this.$15(a) > 0 ? this.$6.set(a, this.$15(a) - 1) : this.$6.set(a, 0)
        };
        e.$14 = function() {
            var a = this;
            while (this.$3 > 0) {
                var b = this.$17();
                b = b == null ? void 0 : b.next();
                if (b == null) break;
                b.forEach(function(b) {
                    a.$21(b.jobId), void a.$13(b)
                })
            }
        };
        e.$12 = function(a, b) {
            return b !== void 0 ? d("WAPromiseTimeout").promiseTimeout(a, b) : a
        };
        e.$13 = function(a) {
            var c = this,
                e, f, g, h, j;
            return b("regeneratorRuntime").async(function(k) {
                while (1) switch (k.prev = k.next) {
                    case 0:
                        e = this.$19(a.jobId);
                        this.$3--;
                        e.markJobTaskPending(a);
                        f = a.run, g = a.jobId, h = a.jobName;
                        k.prev = 4;
                        k.next = 7;
                        return b("regeneratorRuntime").awrap(this.$12(f(), ((j = a.jobInfo) == null ? void 0 : j.maxTimeoutMs) === void 0 ? d("WAJobOrchestratorTypes").DEFAULT_JOB_TIMEOUT_MS : void 0));
                    case 7:
                        k.next = 17;
                        break;
                    case 9:
                        k.prev = 9;
                        k.t0 = k["catch"](4);
                        if (!(k.t0 instanceof d("WACustomError").TimeoutError)) {
                            k.next = 16;
                            break
                        }
                        this.$8.logJobTimeout(g);
                        d("WALogger").LOG(i(), h);
                        k.next = 17;
                        break;
                    case 16:
                        throw k.t0;
                    case 17:
                        k.prev = 17;
                        this.$3++;
                        e.markJobTaskDone(g);
                        this.$3 > 0 && setTimeout(function() {
                            return c.$14()
                        }, 0);
                        return k.finish(17);
                    case 22:
                    case "end":
                        return k.stop()
                }
            }, null, this, [
                [4, 9, 17, 22]
            ])
        };
        return a
    }();
    g.WAConcurrentBucketJobQueue = a
}), 98);
__d("WAConcurrentPreemptiveJobQueue", ["Promise", "WACustomError", "WAHex", "WAJobOrchestratorTypes", "WALogger", "WAPromiseTimeout", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Assertion failed::markJobTaskDone found jobId: ", " in scheduled tasks"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Assertion failed::markJobTaskPending found jobId: ", " in pending tasks"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[job-orchestator]: ", " exceeding the timeout, release the thread."]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[job-orchestator]: updated ConcurrentPreemptiveJobQueue config"]);
        l = function() {
            return a
        };
        return a
    }
    a = function() {
        function a() {
            this.$1 = !1, this.$2 = 0, this.$3 = 0, this.$4 = {}, this.$5 = [], this.$6 = []
        }
        var e = a.prototype;
        e.init = function(a, b) {
            if (this.$1) throw c("err")("ConcurrentPreemptiveJobQueue has already initialized");
            this.$2 = a.maxConcurrency;
            this.$3 = a.maxConcurrency;
            this.$4 = (a = a.maxConcurrencyPerJob) != null ? a : {};
            this.$7 = b;
            this.$1 = !0
        };
        e.updateConfig = function(a) {
            this.$3 += a.maxConcurrency - this.$2;
            this.$2 = a.maxConcurrency;
            this.$4 = (a = a.maxConcurrencyPerJob) != null ? a : {};
            d("WALogger").LOG(l())
        };
        e.isInitialized = function() {
            return this.$1
        };
        e.clearQueueByPriority = function(a) {
            if (!this.$1) throw c("err")("ConcurrentPreemptiveJobQueue not initialized");
            this.$5 = this.$5.filter(function(b) {
                return ((b = b.jobInfo) == null ? void 0 : b.priority) !== a
            })
        };
        e.clearQueue = function() {
            if (!this.$1) throw c("err")("ConcurrentPreemptiveJobQueue not initialized");
            this.$5 = [];
            this.$6 = []
        };
        e.enqueue = function(a, e, f) {
            var g, i = this;
            if (!this.$1) return (h || (h = b("Promise"))).reject(c("err")("ConcurrentPreemptiveJobQueue not initialized"));
            var j, k, l = new(h || (h = b("Promise")))(function(a, b) {
                    j = a, k = b
                }),
                m = babelHelpers["extends"]({
                    priority: d("WAJobOrchestratorTypes").DEFAULT_JOB_PRIORITY
                }, f),
                n = (g = f == null ? void 0 : f.jobId) != null ? g : d("WAHex").randomHex(8).substr(0, 64);
            g = this.$8(a, m, n, function() {
                var a;
                return b("regeneratorRuntime").async(function(c) {
                    while (1) switch (c.prev = c.next) {
                        case 0:
                            c.prev = 0;
                            i.$7.logJobStarted(n);
                            c.next = 4;
                            return b("regeneratorRuntime").awrap(i.$9(e(), f == null ? void 0 : f.maxTimeoutMs));
                        case 4:
                            a = c.sent;
                            i.$7.logJobCompleted(n);
                            j(a);
                            c.next = 13;
                            break;
                        case 9:
                            c.prev = 9, c.t0 = c["catch"](0), c.t0 instanceof d("WACustomError").TimeoutError ? i.$7.logJobTimeout(n) : i.$7.logJobError(n), k(c.t0);
                        case 13:
                        case "end":
                            return c.stop()
                    }
                }, null, this, [
                    [0, 9]
                ])
            });
            f && f.priority === d("WAJobOrchestratorTypes").JOB_PRIORITY.UI_ACTION && this.$10(g);
            this.$11();
            return l
        };
        e.getAvailableThreadsCount = function() {
            return this.$3
        };
        e.getJobMaxConcurrency = function() {
            return this.$4
        };
        e.getSnapshot = function(a) {};
        e.$11 = function() {
            while (this.$3 > 0) {
                var a = this.$12();
                if (a == null) break;
                this.$10(a)
            }
        };
        e.$9 = function(a, b) {
            return b !== void 0 ? d("WAPromiseTimeout").promiseTimeout(a, b) : a
        };
        e.$10 = function(a) {
            var c = this,
                e, f, g, h;
            return b("regeneratorRuntime").async(function(i) {
                while (1) switch (i.prev = i.next) {
                    case 0:
                        this.$3--;
                        this.$13(a);
                        e = a.run, f = a.jobId, g = a.jobName;
                        i.prev = 3;
                        i.next = 6;
                        return b("regeneratorRuntime").awrap(this.$9(e(), ((h = a.jobInfo) == null ? void 0 : h.maxTimeoutMs) === void 0 ? d("WAJobOrchestratorTypes").DEFAULT_JOB_TIMEOUT_MS : void 0));
                    case 6:
                        i.next = 16;
                        break;
                    case 8:
                        i.prev = 8;
                        i.t0 = i["catch"](3);
                        if (!(i.t0 instanceof d("WACustomError").TimeoutError)) {
                            i.next = 15;
                            break
                        }
                        this.$7.logJobTimeout(f);
                        d("WALogger").LOG(k(), g);
                        i.next = 16;
                        break;
                    case 15:
                        throw i.t0;
                    case 16:
                        i.prev = 16;
                        this.$3++;
                        this.$14(f);
                        setTimeout(function() {
                            return c.$11()
                        }, 0);
                        return i.finish(16);
                    case 21:
                    case "end":
                        return i.stop()
                }
            }, null, this, [
                [3, 8, 16, 21]
            ])
        };
        e.$8 = function(a, b, c, d) {
            d = {
                jobId: c,
                jobInfo: b,
                jobName: a,
                run: d
            };
            this.$7.logJobCreated({
                jobId: c,
                jobName: a,
                jobPriority: b.priority,
                pendingJobsCount: this.$5.length
            });
            this.$5.push(d);
            return d
        };
        e.$13 = function(a) {
            this.$6.includes(function(b) {
                return b.jobId === a.jobId
            }) && d("WALogger").ERROR(j(), a.jobId).sendLogs("JobOrchestrator::markJobTaskPending"), this.$6.push(a), this.$5 = this.$5.filter(function(b) {
                return b.jobId !== a.jobId
            })
        };
        e.$14 = function(a) {
            this.$6 = this.$6.filter(function(b) {
                return b.jobId !== a
            }), this.$5.includes(function(b) {
                return b.jobId === a
            }) && d("WALogger").ERROR(i(), a).sendLogs("JobOrchestrator::markJobTaskDone")
        };
        e.$12 = function() {
            var a = this;
            if (this.$5.length === 0) return null;
            var b = this.$6.reduce(function(a, b) {
                    var c;
                    c = (c = a.get(b.jobName)) != null ? c : 0;
                    a.set(b.jobName, c + 1);
                    return a
                }, new Map()),
                c = this.$5.filter(function(c) {
                    var d;
                    return ((d = b.get(c.jobName)) != null ? d : 0) < ((d = a.$4[c.jobName]) != null ? d : 1)
                });
            return c[0]
        };
        return a
    }();
    g.WAConcurrentPreemptiveJobQueue = a
}), 98);
__d("WADefaultJobNoQueue", ["WAHex", "WAJobOrchestratorTypes", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$2 = !1
        }
        var e = a.prototype;
        e.init = function(a, b) {
            if (this.$2) throw c("err")("DefaultNoQueue has already initialized");
            this.$1 = b;
            this.$2 = !0
        };
        e.updateConfig = function(a) {};
        e.isInitialized = function() {
            return this.$2
        };
        e.clearQueue = function() {};
        e.clearQueueByPriority = function(a) {};
        e.getSnapshot = function() {
            throw c("err")("getSnapshot is not implemented for DefaultNoQueue")
        };
        e.enqueue = function(a, c, e) {
            var f, g, h, i;
            return b("regeneratorRuntime").async(function(j) {
                while (1) switch (j.prev = j.next) {
                    case 0:
                        h = (f = e == null ? void 0 : e.jobId) != null ? f : d("WAHex").randomHex(8).substr(0, 64);
                        this.$1.logJobCreated({
                            jobId: h,
                            jobName: a,
                            jobPriority: (g = e == null ? void 0 : e.priority) != null ? g : d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW,
                            pendingJobsCount: 0
                        });
                        j.prev = 2;
                        this.$1.logJobStarted(h);
                        j.next = 6;
                        return b("regeneratorRuntime").awrap(c());
                    case 6:
                        i = j.sent;
                        this.$1.logJobCompleted(h);
                        return j.abrupt("return", i);
                    case 11:
                        j.prev = 11;
                        j.t0 = j["catch"](2);
                        this.$1.logJobError(h);
                        throw j.t0;
                    case 15:
                    case "end":
                        return j.stop()
                }
            }, null, this, [
                [2, 11]
            ])
        };
        return a
    }();
    g.WADefaultJobNoQueue = a
}), 98);
__d("WAOrchestratorJobStatsLogger", ["WAGlobals", "WAPREList", "WAPREMetrics"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function() {
        function a(a, b, c) {
            this.jobName = a, this.pendingJobsCount = c, this.jobPriority = b
        }
        var b = a.prototype;
        b.logJobAdded = function() {
            this.webcJobAddedT = Date.now(), this.eventFlow = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.WA_JOBS_ORCHESTRATOR, {
                string: {
                    name: this.jobName,
                    jobPriority: this.jobPriority,
                    orchestratorVersion: d("WAGlobals").getConfig().orchestratorVersion()
                },
                "int": {
                    pendingJobsCount: this.pendingJobsCount,
                    addedAt: this.webcJobAddedT
                }
            })
        };
        b.logJobStarted = function() {
            this.webcJobStartedT = Date.now(), this.eventFlow.addPoint("start_job", {
                "int": {
                    startedAt: this.webcJobStartedT
                }
            })
        };
        b.logJobCompleted = function(a) {
            this.webcJobCompletedT = Date.now();
            this.jobResultType = a;
            var b = {
                "int": {
                    pendingJobsCount: this.pendingJobsCount,
                    completedAt: this.webcJobCompletedT
                }
            };
            a === "completed" ? this.eventFlow.endSuccess(b) : this.eventFlow.endFail(a, b)
        };
        return a
    }();
    a = function() {
        function a() {
            this.$1 = new Map()
        }
        var b = a.prototype;
        b.logJobCreated = function(a) {
            var b = a.jobName,
                c = a.jobId,
                d = a.jobPriority;
            a = a.pendingJobsCount;
            b = new h(b, d, a);
            b.logJobAdded();
            this.$1.set(c, b)
        };
        b.logJobStarted = function(a) {
            a = this.$1.get(a);
            a == null ? void 0 : a.logJobStarted()
        };
        b.logJobCompleted = function(a) {
            this.$2(a, "completed")
        };
        b.logJobError = function(a) {
            this.$2(a, "error")
        };
        b.logJobTimeout = function(a) {
            this.$2(a, "timeout")
        };
        b.logJobAborted = function(a) {
            this.$2(a, "aborted")
        };
        b.$2 = function(a, b) {
            var c = this.$1.get(a);
            c == null ? void 0 : c.logJobCompleted(b);
            this.$1["delete"](a)
        };
        return a
    }();
    g.JobInfoEvent = h;
    g.JobStatsLogger = a
}), 98);
__d("WAOrchestrator", ["WAConcurrentBucketJobQueue", "WAConcurrentPreemptiveJobQueue", "WADefaultJobNoQueue", "WAGlobals", "WAJobOrchestratorTypes", "WAOrchestratorJobStatsLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = {
                maxConcurrency: 1
            },
            b = "default",
            c = {},
            e = a,
            f = new(d("WAOrchestratorJobStatsLogger").JobStatsLogger)();
        return function(g, j) {
            var k;
            g === void 0 && (g = !1);
            g = g ? b : d("WAGlobals").getConfig().orchestratorVersion();
            k = (k = i()) != null ? k : a;
            var l;
            j == null ? void 0 : j.addPoint("get_orchestrator", {
                string: {
                    orchestrator: g
                },
                "int": {
                    maxConcurrency: k.maxConcurrency,
                    highPriorityQuota: (j = (j = k.jobPrioritiesQuota) == null ? void 0 : j.get(d("WAJobOrchestratorTypes").JOB_PRIORITY.HIGH)) != null ? j : 0,
                    lowPriorityQuota: (j = (j = k.jobPrioritiesQuota) == null ? void 0 : j.get(d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW)) != null ? j : 0
                }
            });
            if (c[g]) {
                h(e, k) && (e = k, c[g].updateConfig(k));
                return c[g]
            }
            switch (g) {
                case "preemptive":
                    l = new(d("WAConcurrentPreemptiveJobQueue").WAConcurrentPreemptiveJobQueue)();
                    break;
                case "bucket":
                    l = new(d("WAConcurrentBucketJobQueue").WAConcurrentBucketJobQueue)();
                    break;
                default:
                    l = new(d("WADefaultJobNoQueue").WADefaultJobNoQueue)();
                    break
            }
            l.init(k, f);
            c[g] = l;
            e = k;
            return l
        }
    }

    function h(a, b) {
        var c;
        if (a.maxConcurrency !== b.maxConcurrency) return !0;
        if (((c = a.jobPrioritiesQuota) == null ? void 0 : c.size) !== ((c = b.jobPrioritiesQuota) == null ? void 0 : c.size)) return !0;
        return Object.keys((c = a.maxConcurrencyPerJob) != null ? c : {}).length !== Object.keys((c = b.maxConcurrencyPerJob) != null ? c : {}).length ? !0 : JSON.stringify(a) !== JSON.stringify(b)
    }

    function i() {
        var a = {
            jobPrioritiesQuota: new Map([
                [d("WAJobOrchestratorTypes").JOB_PRIORITY.HIGH, 5],
                [d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW, 1]
            ]),
            maxConcurrency: 5,
            maxConcurrencyPerJob: {}
        };
        return a
    }
    g.getInstanceDelegate = a
}), 98);
__d("WAPersistedJobManager", ["Promise", "WAJobRequirement", "WALogger", "WAPromiseBackoffs", "WATimeUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " waiting on ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " halting because of ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["waitUntilCompletedNonPersisted not implemented in PersistedJobManager"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["fireAndForgetNonPersisted not implemented in PersistedJobManager"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " has been loaded and is marked as deprecated"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["addPersistedJobImplementation called twice for ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["onJobStarted for ", " threw exception ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": ", " step not found"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " failed with error ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["onJobFinished for ", " threw exception ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": finished job"]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": Unhandled exception: ", ""]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": Unhandled exception. Tried ", " times"]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": RetryOnBackoff"]);
        v = function() {
            return a
        };
        return a
    }

    function w() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": requires page"]);
        w = function() {
            return a
        };
        return a
    }

    function x() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": delaying until ", ""]);
        x = function() {
            return a
        };
        return a
    }

    function y() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": trim wait from ", " to ", ""]);
        y = function() {
            return a
        };
        return a
    }

    function z() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No implementation for ", ".", ""]);
        z = function() {
            return a
        };
        return a
    }

    function A() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": removing completed, expired job from db"]);
        A = function() {
            return a
        };
        return a
    }

    function B() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": skew detected, adjusting accordingly"]);
        B = function() {
            return a
        };
        return a
    }

    function C() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Running deprecated job ", ""]);
        C = function() {
            return a
        };
        return a
    }

    function D() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No implementation for deprecated ", ", job deleted"]);
        D = function() {
            return a
        };
        return a
    }

    function E() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No implementation for ", ". Maybe it should have been put to the deprecated list?"]);
        E = function() {
            return a
        };
        return a
    }

    function F() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": InterruptJob"]);
        F = function() {
            return a
        };
        return a
    }

    function G() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running step"]);
        G = function() {
            return a
        };
        return a
    }

    function H() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Persisted job missing for given ID"]);
        H = function() {
            return a
        };
        return a
    }

    function I() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No entry for job ", ""]);
        I = function() {
            return a
        };
        return a
    }

    function J() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": restarting"]);
        J = function() {
            return a
        };
        return a
    }

    function K() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": stuck on the step ", ", aborting the job"]);
        K = function() {
            return a
        };
        return a
    }
    var L = 1,
        M = function() {
            function a(a) {
                this.feature = a
            }
            var b = a.prototype;
            b.toString = function() {
                return "RequiresPage: " + this.feature
            };
            return a
        }(),
        N = function() {
            function a(a) {
                this.backoffOptions = a
            }
            var b = a.prototype;
            b.toString = function() {
                return "RetryOnBackoff"
            };
            return a
        }();
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    var O = function(a) {
            this.result = a
        },
        P = "$unstarted",
        Q = "$finished";
    c = function() {
        function a(a) {
            var c = this,
                e = a.isRestartAfterCrash,
                f = a.accessors,
                g = a.unfinishedJobEntries,
                i = new Map();
            g = g.then(function(a) {
                var g = [],
                    j = [];
                a.forEach(function(a) {
                    a.stepHardStartCountAfterTimeout >= 5 ? g.push(a) : j.push(a)
                });
                return (h || (h = b("Promise"))).all(g.map(function(a) {
                    d("WALogger").ERROR(K(), S(a), a.step).devConsole(R(a)).sendLogs("job-stuck-" + a.type);
                    return f.deletePersistedJob(a.jobId)
                })).then(function() {
                    j.forEach(function(a) {
                        if (i.has(a.jobId)) return;
                        d("WALogger").LOG(J(), R(a));
                        i.set(a.jobId, c.$1(a, e))
                    })
                })
            });
            this.implementationLoaders = new Map();
            this.implementations = new Map();
            this.stepBlockers = new WeakMap();
            this.accessors = f;
            this.activeJobs = i;
            this.initialJobsPromise = g;
            this.listeners = a.listeners;
            this.deprecatedJobs = a.deprecatedJobs
        }
        var c = a.prototype;
        c.loadAndRunJobFromId = function(a) {
            var b = this.activeJobs.get(a);
            if (b != null) return b;
            b = this.$2(a);
            this.activeJobs.set(a, b);
            return b
        };
        c.$2 = function(a) {
            var c, e, f;
            return b("regeneratorRuntime").async(function(g) {
                while (1) switch (g.prev = g.next) {
                    case 0:
                        c = this.initialJobsPromise, e = this.accessors;
                        g.next = 3;
                        return b("regeneratorRuntime").awrap(c);
                    case 3:
                        g.next = 5;
                        return b("regeneratorRuntime").awrap(e.readPersistedJob(a));
                    case 5:
                        f = g.sent;
                        if (f) {
                            g.next = 10;
                            break
                        }
                        d("WALogger").DEV(I(), a);
                        d("WALogger").WARN(H());
                        return g.abrupt("return", null);
                    case 10:
                        return g.abrupt("return", this.$1(f, !1));
                    case 11:
                    case "end":
                        return g.stop()
                }
            }, null, this)
        };
        c.$3 = function(a) {
            var b = this.implementations,
                c = this.implementationLoaders,
                d = b.get(a);
            if (d) return d;
            d = c.get(a);
            if (!d) return null;
            c = d();
            b.set(a, c);
            return c
        };
        c.$4 = function(a, c) {
            if (c == null || c.length === 0) return (h || (h = b("Promise"))).resolve();
            var e = this.stepBlockers,
                f = e.get(c);
            f == null && (f = d("WAJobRequirement").joinRequirements(c.map(function(a) {
                return a()
            }), U), e.set(c, f));
            return f(a)
        };
        c.$5 = function(a, b, c, e) {
            var f = this;
            c === void 0 && (c = !1);
            var g = a.step,
                h = b.findIndex(function(a) {
                    return a.stepName === g
                }),
                i = b[h].info(a.current, a.original, V(a, c)),
                j = i.requirements,
                k = i.code;
            i = this.$4(a, j);
            e && (i = i.then(e));
            return i.then(function() {
                d("WALogger").LOG(G(), T(a));
                return k(a.current, a.original, V(a, c))
            }).then(function(e) {
                if (e instanceof O) {
                    d("WALogger").LOG(F(), T(a));
                    return e.result
                }
                var g = h + 1;
                if (g >= b.length) return e;
                g = b[g];
                a.step = g.stepName;
                a.current = e;
                a.stepHardStartCountAfterTimeout = 0;
                a.stepFirstStartTime = d("WATimeUtils").unixTime();
                a.stepUnexpectedErrorCount = 0;
                a.waitUntil = null;
                a.backedOffCount = 0;
                return f.accessors.updatePersistedJob(a).then(function() {
                    return f.$5(a, b, c)
                })
            })
        };
        c.$1 = function(a, c) {
            var e, f = this,
                g, i, j, k, l, m, n, F, G, H, I, J, K, O, S, U;
            return b("regeneratorRuntime").async(function(W) {
                while (1) switch (W.prev = W.next) {
                    case 0:
                        g = this.accessors, i = this.activeJobs, j = this.deprecatedJobs, k = this.listeners, l = k.onJobFinished, m = k.onJobStarted;
                        W.next = 3;
                        return b("regeneratorRuntime").awrap(this.$3(a.type));
                    case 3:
                        n = W.sent;
                        F = j[a.type];
                        if (n) {
                            W.next = 21;
                            break
                        }
                        if (F) {
                            W.next = 13;
                            break
                        }
                        d("WALogger").ERROR(E(), a.type).sendLogs("missing-job-implementation");
                        W.next = 10;
                        return b("regeneratorRuntime").awrap(g.deletePersistedJob(a.jobId));
                    case 10:
                        return W.abrupt("return", null);
                    case 13:
                        if (!(F === "NOOP")) {
                            W.next = 18;
                            break
                        }
                        d("WALogger").WARN(D(), a.type);
                        W.next = 17;
                        return b("regeneratorRuntime").awrap(g.deletePersistedJob(a.jobId));
                    case 17:
                        return W.abrupt("return", null);
                    case 18:
                        W.next = 20;
                        return b("regeneratorRuntime").awrap(F());
                    case 20:
                        n = W.sent;
                    case 21:
                        G = n;
                        F && d("WALogger").LOG(C(), a.type);
                        H = (e = a.stepFirstStartTime) != null ? e : d("WATimeUtils").unixTime();
                        a.stepFirstStartTime = H;
                        a.stepUnexpectedErrorCount = a.stepUnexpectedErrorCount || 0;
                        a.backedOffCount = a.backedOffCount || 0;
                        if (!(a.step === Q)) {
                            W.next = 44;
                            break
                        }
                        I = a.waitUntil;
                        J = d("WATimeUtils").secondsUntil(H);
                        if (!(I != null && d("WATimeUtils").isInFuture(I) && J > 0)) {
                            W.next = 38;
                            break
                        }
                        d("WALogger").LOG(B(), R(a));
                        I = d("WATimeUtils").castToUnixTime(I - J);
                        if (!d("WATimeUtils").isInFuture(I)) {
                            W.next = 38;
                            break
                        }
                        a.stepFirstStartTime = d("WATimeUtils").castToUnixTime(H - J);
                        a.waitUntil = I;
                        W.next = 38;
                        return b("regeneratorRuntime").awrap(this.accessors.updatePersistedJob(a));
                    case 38:
                        if (!(I == null || !d("WATimeUtils").isInFuture(I))) {
                            W.next = 42;
                            break
                        }
                        d("WALogger").LOG(A(), R(a));
                        W.next = 42;
                        return b("regeneratorRuntime").awrap(g.deletePersistedJob(a.jobId));
                    case 42:
                        i["delete"](a.jobId);
                        return W.abrupt("return", a.current);
                    case 44:
                        K = a.step !== P ? n.find(function(b) {
                            return b.stepName === a.step
                        }) : n[0];
                        if (K) {
                            W.next = 50;
                            break
                        }
                        d("WALogger").ERROR(z(), a.type, a.step).sendLogs("missing-job-step");
                        W.next = 49;
                        return b("regeneratorRuntime").awrap(g.deletePersistedJob(a.jobId));
                    case 49:
                        return W.abrupt("return", null);
                    case 50:
                        a.step = K.stepName;
                        O = function e() {
                            var g = a.waitUntil,
                                i = (h || (h = b("Promise"))).resolve();
                            if (g != null) {
                                var j = d("WATimeUtils").futureUnixTime(d("WATimeUtils").DAY_SECONDS);
                                g > j ? (d("WALogger").LOG(y(), T(a), g, j), a.waitUntil = j, i = f.accessors.updatePersistedJob(a).then(function() {
                                    return d("WATimeUtils").delayUntil(j)
                                })) : (d("WALogger").LOG(x(), T(a), g), i = d("WATimeUtils").delayUntil(g))
                            }
                            return i.then(function() {
                                var g = function() {
                                    a.waitUntil = null;
                                    d("WATimeUtils").happenedWithin(H, d("WATimeUtils").DAY_SECONDS) || a.stepHardStartCountAfterTimeout++;
                                    return f.accessors.updatePersistedJob(a)
                                };
                                return f.$5(a, G, c, g)["catch"](function(c) {
                                    if (c instanceof M) {
                                        d("WALogger").LOG(w(), T(a));
                                        a.stepHardStartCountAfterTimeout > 0 && (--a.stepHardStartCountAfterTimeout, f.accessors.updatePersistedJob(a));
                                        return new(h || (h = b("Promise")))(function() {})
                                    } else if (c instanceof N) {
                                        d("WALogger").LOG(v(), T(a));
                                        var g = d("WAPromiseBackoffs").getDelay(++a.backedOffCount, c.backoffOptions);
                                        a.waitUntil = d("WATimeUtils").futureUnixTime(Math.ceil(g / 1e3));
                                        a.stepHardStartCountAfterTimeout > 0 && --a.stepHardStartCountAfterTimeout;
                                        return f.accessors.updatePersistedJob(a).then(e)
                                    } else if (a.stepUnexpectedErrorCount < L) {
                                        d("WALogger").WARN(u(), T(a), a.stepUnexpectedErrorCount);
                                        d("WALogger").WARN(t(), T(a), c);
                                        a.stepUnexpectedErrorCount++;
                                        return f.accessors.updatePersistedJob(a).then(e)
                                    }
                                    throw c
                                })
                            })
                        };
                        S = O();
                        U = S.then(function(c) {
                            var e;
                            return b("regeneratorRuntime").async(function(h) {
                                while (1) switch (h.prev = h.next) {
                                    case 0:
                                        d("WALogger").LOG(s(), T(a));
                                        e = null;
                                        try {
                                            e = l(a.jobId, a.type, a.original, c)
                                        } catch (b) {
                                            d("WALogger").ERROR(r(), a.type, b).sendLogs("onJobFinished-threw")
                                        }
                                        if (!(e != null && e > 0)) {
                                            h.next = 12;
                                            break
                                        }
                                        a.waitUntil = d("WATimeUtils").futureUnixTime(Math.ceil(e / 1e3));
                                        a.step = Q;
                                        a.current = c;
                                        a.stepFirstStartTime = d("WATimeUtils").unixTime();
                                        h.next = 10;
                                        return b("regeneratorRuntime").awrap(f.accessors.updatePersistedJob(a));
                                    case 10:
                                        h.next = 15;
                                        break;
                                    case 12:
                                        h.next = 14;
                                        return b("regeneratorRuntime").awrap(g.deletePersistedJob(a.jobId));
                                    case 14:
                                        i["delete"](a.jobId);
                                    case 15:
                                    case "end":
                                        return h.stop()
                                }
                            }, null, this)
                        }, function(e) {
                            var f, h;
                            return b("regeneratorRuntime").async(function(j) {
                                while (1) switch (j.prev = j.next) {
                                    case 0:
                                        d("WALogger").ERROR(q(), a.type, e).sendLogs("job-threw-exception-" + a.type);
                                        f = G.find(function(b) {
                                            return b.stepName === a.step
                                        });
                                        if (f) {
                                            j.next = 6;
                                            break
                                        }
                                        d("WALogger").ERROR(p(), a.type, a.step);
                                        j.next = 10;
                                        break;
                                    case 6:
                                        h = f.info(a.current, a.original, V(a, c));
                                        if (!(h.stopRetryIf != null)) {
                                            j.next = 10;
                                            break
                                        }
                                        j.next = 10;
                                        return b("regeneratorRuntime").awrap(h.stopRetryIf.onStopRetry(a.current, a.original, V(a, c)));
                                    case 10:
                                        j.next = 12;
                                        return b("regeneratorRuntime").awrap(g.deletePersistedJob(a.jobId));
                                    case 12:
                                        i["delete"](a.jobId);
                                    case 13:
                                    case "end":
                                        return j.stop()
                                }
                            }, null, this)
                        });
                        try {
                            m(a.jobId, a.type, a.original)
                        } catch (b) {
                            d("WALogger").ERROR(o(), a.type, b).sendLogs("onJobStarted-threw")
                        }
                        return W.abrupt("return", U.then(function() {
                            return S
                        }));
                    case 56:
                    case "end":
                        return W.stop()
                }
            }, null, this)
        };
        c.addPersistedJobImplementation = function(a, b) {
            var c = this.implementationLoaders,
                e = this.deprecatedJobs;
            if (c.has(a)) {
                d("WALogger").ERROR(n(), a).sendLogs("repeat-job-loader");
                return
            }
            e && e[a] && d("WALogger").DEV(m(), a);
            c.set(a, b)
        };
        c.fireAndForget = function(a) {
            var b = this;
            this.accessors.maybeCreateJob(a).then(function(a) {
                a = a.id;
                return b.loadAndRunJobFromId(a)
            })
        };
        c.waitUntilPersisted = function(a) {
            var b = this;
            return this.accessors.maybeCreateJob(a).then(function(a) {
                a = a.id;
                b.loadAndRunJobFromId(a)
            })
        };
        c.waitUntilCompleted = function(a) {
            var b = this;
            return this.accessors.maybeCreateJob(a).then(function(a) {
                a = a.id;
                return b.loadAndRunJobFromId(a)
            })
        };
        c.fireAndForgetNonPersisted = function(a) {
            d("WALogger").LOG(l())
        };
        c.waitUntilCompletedNonPersisted = function(a) {
            return (h || (h = b("Promise"))).resolve(function() {
                return d("WALogger").LOG(k())
            })
        };
        return a
    }();

    function R(a) {
        return "Job[" + a.jobId + "] (" + a.type + ")"
    }

    function S(a) {
        return "[Job " + a.type + "] "
    }

    function T(a) {
        return "Job[" + a.jobId + "] (" + a.type + "." + a.step + ")"
    }

    function U(a, b, c) {
        a === "unsatisfiable" ? d("WALogger").LOG(j(), T(c), b) : a === "unsatisfied" ? d("WALogger").LOG(i(), T(c), b) : a
    }

    function V(a, b) {
        b === void 0 && (b = !1);
        return {
            jobStartTime: a.startTime,
            afterCrash: b,
            interruptJob: W
        }
    }

    function W(a) {
        return new O(a)
    }
    g.RequiresPage = M;
    g.RetryOnBackoff = N;
    g.NonRetryableError = a;
    g.InterruptJob = O;
    g.UNSTARTED_JOB = P;
    g.FINISHED_JOB = Q;
    g.PersistedJobManager = c
}), 98);
__d("WaJobInMemoryAccessors", ["Promise", "WAHex", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        var a = -1,
            c = new Map();
        return {
            deletePersistedJob: function(a) {
                return (h || (h = b("Promise"))).resolve(c["delete"](a))
            },
            loadAllJobs: function() {
                return (h || (h = b("Promise"))).resolve(Array.from(c.values()))
            },
            maybeCreateJob: function(e) {
                var f, g = JSON.stringify([e.type, (f = e.uniqKey) != null ? f : d("WAHex").randomHex(32)]),
                    i = {
                        backedOffCount: 0,
                        current: e.args,
                        original: e.args,
                        startTime: d("WATimeUtils").unixTime(),
                        step: "$unstarted",
                        stepFirstStartTime: null,
                        stepHardStartCountAfterTimeout: 0,
                        stepUnexpectedErrorCount: 0,
                        type: e.type,
                        uniqKey: g,
                        version: e.version,
                        waitUntil: null,
                        scheduleConfig: e.scheduleConfig
                    };
                f = function() {
                    var d = a--,
                        e = babelHelpers["extends"]({}, i, {
                            jobId: d
                        });
                    c.set(d, e);
                    return (h || (h = b("Promise"))).resolve({
                        id: d,
                        newlyCreated: !0
                    })
                };
                if (e.uniqKey != null) {
                    e = Array.from(c.values()).filter(function(a) {
                        return a.uniqKey === g
                    });
                    if (e.length === 0) return f();
                    var j = null;
                    e.forEach(function(a) {
                        a.step !== "$finished" ? j = a : c["delete"](a.jobId)
                    });
                    return j != null ? (h || (h = b("Promise"))).resolve({
                        id: j.jobId,
                        newlyCreated: !1
                    }) : f()
                }
                return f()
            },
            readPersistedJob: function(a) {
                a = c.get(a);
                return (h || (h = b("Promise"))).resolve(a && babelHelpers["extends"]({}, a))
            },
            updatePersistedJob: function(a) {
                return (h || (h = b("Promise"))).resolve(c.set(a.jobId, babelHelpers["extends"]({}, a)))
            }
        }
    }
    g.getJobInMemoryAccessors = a
}), 98);
__d("WAPersistedJobManagerV2", ["Promise", "WAGlobals", "WAJids", "WAJobOrchestratorTypes", "WAJobRequirement", "WALogger", "WAOrchestrator", "WAPREList", "WAPREMetrics", "WAPersistedJobManager", "WAPromiseBackoffs", "WAResolvable", "WATimeUtils", "WaJobInMemoryAccessors", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " waiting on ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " halting because of ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running in persisted mode"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running in forced non-persisted mode"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running in persisted mode"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running in forced non-persisted mode"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running in persisted mode"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running in forced non-persisted mode"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " has been loaded and is marked as deprecated"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["addPersistedJobImplementation called twice for ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["onJobStarted for ", " threw exception ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": ", " step not found"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " failed with error ", ""]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["onJobFinished for ", " threw exception ", ""]);
        v = function() {
            return a
        };
        return a
    }

    function w() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": finished job"]);
        w = function() {
            return a
        };
        return a
    }

    function x() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": Unhandled exception: ", ""]);
        x = function() {
            return a
        };
        return a
    }

    function y() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": Unhandled exception. Tried ", " times"]);
        y = function() {
            return a
        };
        return a
    }

    function z() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": RetryOnBackoff"]);
        z = function() {
            return a
        };
        return a
    }

    function A() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": delaying until ", ""]);
        A = function() {
            return a
        };
        return a
    }

    function B() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": trim wait from ", " to ", ""]);
        B = function() {
            return a
        };
        return a
    }

    function C() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No implementation for ", ".", ""]);
        C = function() {
            return a
        };
        return a
    }

    function D() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": removing completed, expired job from db"]);
        D = function() {
            return a
        };
        return a
    }

    function E() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": skew detected, adjusting accordingly"]);
        E = function() {
            return a
        };
        return a
    }

    function F() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Running deprecated job ", ""]);
        F = function() {
            return a
        };
        return a
    }

    function G() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No implementation for deprecated ", ", job deleted"]);
        G = function() {
            return a
        };
        return a
    }

    function H() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No implementation for ", ". Maybe it should have been put to the deprecated list?"]);
        H = function() {
            return a
        };
        return a
    }

    function I() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": InterruptJob"]);
        I = function() {
            return a
        };
        return a
    }

    function J() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": running step"]);
        J = function() {
            return a
        };
        return a
    }

    function K() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Persisted job missing for given ID"]);
        K = function() {
            return a
        };
        return a
    }

    function L() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[JOB MANAGER] Restarting job with the same id"]);
        L = function() {
            return a
        };
        return a
    }

    function M() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ": stuck on the step ", ", aborting the job"]);
        M = function() {
            return a
        };
        return a
    }
    var N = 1;

    function O(a) {
        var b = a.code,
            c = a.annotations;
        c = c === void 0 ? {} : c;
        a = a.eventFlow;
        var d = a === void 0 ? P(c) : a;
        return b(d).then(function(a) {
            d.endSuccess();
            return a
        })["catch"](function(a) {
            d.endFail("error", {
                string: {
                    error: "" + a
                }
            });
            throw a
        })
    }

    function P(a) {
        a === void 0 && (a = {});
        return d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.WA_JOB_MANAGER, babelHelpers["extends"]({}, a, {
            string: babelHelpers["extends"]({}, (a = (a = a) == null ? void 0 : a.string) != null ? a : {}, {
                userHash: d("WAGlobals").getDependencies().isEmployee() && d("WAGlobals").getDependencies().isUseridAnnotationEnabled() ? d("WAJids").extractUserId(d("WAGlobals").getMyUserJid()).slice(-5) : null
            })
        }))
    }
    a = function() {
        function a(a) {
            var c = this;
            this.$1 = [];
            var e = a.isRestartAfterCrash,
                f = a.accessors,
                g = a.unfinishedJobEntries,
                i = a.ignoreForceNonPersistedJobList;
            this.getOrchestratorDelegate = d("WAOrchestrator").getInstanceDelegate();
            this.activeJobs = new Map();
            this.implementationLoaders = new Map();
            this.implementations = new Map();
            this.stepBlockers = new WeakMap();
            this.accessors = f;
            this.isRestartAfterCrash = e || !1;
            this.listeners = a.listeners;
            this.deprecatedJobs = a.deprecatedJobs;
            this.inMemoryAccessors = d("WaJobInMemoryAccessors").getJobInMemoryAccessors();
            this.offlineQueueMode = !0;
            this.$1 = i;
            a.offlineQueueCompletePromise != null ? a.offlineQueueCompletePromise["finally"](function() {
                c.offlineQueueMode = !1
            }) : this.offlineQueueMode = !1;
            this.initialJobsPromise = g.then(function(a) {
                var e = [],
                    f = [];
                a.forEach(function(a) {
                    a.stepHardStartCountAfterTimeout >= 5 ? e.push(a) : f.push(a)
                });
                return (h || (h = b("Promise"))).all(e.map(function(a) {
                    d("WALogger").ERROR(M(), R(a), a.step).devConsole(Q(a)).sendLogs("job-stuck-" + a.type);
                    return c.accessors.deletePersistedJob(a.jobId)
                })).then(function() {
                    f.forEach(function(a) {
                        var b = c.$2(a.jobId);
                        if (b.alreadyActive === !0) {
                            d("WALogger").ERROR(L());
                            return
                        }
                        b.deferred.resolve(O({
                            code: function(b) {
                                return c.$3(a, c.accessors, {
                                    eventFlow: b
                                })
                            },
                            annotations: {
                                string: {
                                    name: a.type
                                },
                                bool: {
                                    offlineQueueMode: c.offlineQueueMode
                                }
                            }
                        }))
                    })
                })
            })
        }
        var e = a.prototype;
        e.$4 = function(a, e, f) {
            var g, h, i;
            return b("regeneratorRuntime").async(function(j) {
                while (1) switch (j.prev = j.next) {
                    case 0:
                        f === void 0 && (f = {});
                        h = this.$2(a);
                        (g = f.eventFlow) == null ? void 0 : g.addPoint("start_load_and_run", {
                            bool: {
                                skipped: h.alreadyActive
                            }
                        });
                        if (!(h.alreadyActive === !0)) {
                            j.next = 5;
                            break
                        }
                        return j.abrupt("return", h.deferred);
                    case 5:
                        j.next = 7;
                        return b("regeneratorRuntime").awrap(e.readPersistedJob(a));
                    case 7:
                        i = j.sent;
                        if (!(i == null)) {
                            j.next = 11;
                            break
                        }
                        d("WALogger").ERROR(K()).sendLogs("missing-job-entry");
                        throw c("err")("Persisted job missing for given ID " + a);
                    case 11:
                        h.deferred.resolve(this.$3(i, e, f));
                        return j.abrupt("return", h.deferred.promise);
                    case 13:
                    case "end":
                        return j.stop()
                }
            }, null, this)
        };
        e.$3 = function(a, b, c) {
            var e;
            c === void 0 && (c = {});
            (e = c.eventFlow) == null ? void 0 : e.addPoint("enqueueing_job", {
                string: {
                    name: a.type
                }
            });
            return this.getOrchestratorDelegate(((e = a.scheduleConfig) == null ? void 0 : e.priority) === d("WAJobOrchestratorTypes").JOB_PRIORITY.SKIP, c.eventFlow).enqueue(a.type, this.$5(a, b, c), a.scheduleConfig, c.eventFlow)
        };
        e.$6 = function(a, b, c) {
            var d = this;
            c === void 0 && (c = {});
            return b.maybeCreateJob(a).then(function(a) {
                var e;
                a = a.id;
                (e = c.eventFlow) == null ? void 0 : e.addPoint("job_persisted", {
                    "int": {
                        jobId: a
                    },
                    bool: {
                        nonPersisted: b === d.inMemoryAccessors
                    }
                });
                return a
            })
        };
        e.$2 = function(a) {
            var b = this.activeJobs.get(a);
            if (b != null) return {
                alreadyActive: !0,
                deferred: b
            };
            b = new(d("WAResolvable").Resolvable)();
            this.activeJobs.set(a, b.promise);
            return {
                alreadyActive: !1,
                deferred: b
            }
        };
        e.$5 = function(a, b, c) {
            var d = this;
            return function() {
                return d.$7(a, b, c)
            }
        };
        e.$8 = function(a) {
            var b = this.implementations,
                c = this.implementationLoaders,
                d = b.get(a);
            if (d) return d;
            d = c.get(a);
            if (!d) return null;
            c = d();
            b.set(a, c);
            return c
        };
        e.$9 = function(a, c) {
            if (c == null || c.length === 0) return (h || (h = b("Promise"))).resolve();
            var e = this.stepBlockers,
                f = e.get(c);
            f == null && (f = d("WAJobRequirement").joinRequirements(c.map(function(a) {
                return a()
            }), T), e.set(c, f));
            return f(a)
        };
        e.$10 = function(a, b, c, e, f) {
            var g, h = this;
            f === void 0 && (f = {});
            var i = a.step;
            (g = f.eventFlow) == null ? void 0 : g.addPoint("start_step");
            var j = b.findIndex(function(a) {
                return a.stepName === i
            });
            g = b[j].info(a.current, a.original, U(a, this.isRestartAfterCrash));
            var k = g.requirements,
                l = g.code;
            g = this.$9(a, k);
            e && (g = g.then(e));
            return g.then(function() {
                var b;
                d("WALogger").LOG(J(), S(a));
                (b = f.eventFlow) == null ? void 0 : b.addPoint("run_step");
                return l(a.current, a.original, U(a, h.isRestartAfterCrash, f.eventFlow))
            }).then(function(e) {
                var g;
                (g = f.eventFlow) == null ? void 0 : g.addPoint("step_is_complete");
                if (e instanceof d("WAPersistedJobManager").InterruptJob) {
                    d("WALogger").LOG(I(), S(a));
                    return e.result
                }
                g = j + 1;
                if (g >= b.length) return e;
                g = b[g];
                a.step = g.stepName;
                a.current = e;
                a.stepHardStartCountAfterTimeout = 0;
                a.stepFirstStartTime = d("WATimeUtils").unixTime();
                a.stepUnexpectedErrorCount = 0;
                a.waitUntil = null;
                a.backedOffCount = 0;
                return c.updatePersistedJob(a).then(function() {
                    return h.$10(a, b, c, void 0, f)
                })
            })
        };
        e.$7 = function(a, c, e) {
            var f, g, i = this,
                j, k, l, m, n, o, p, q, r, I, J, K, L, M, O;
            return b("regeneratorRuntime").async(function(P) {
                while (1) switch (P.prev = P.next) {
                    case 0:
                        e === void 0 && (e = {});
                        j = this.activeJobs, k = this.deprecatedJobs, l = this.listeners, m = l.onJobFinished, n = l.onJobStarted;
                        (f = e.eventFlow) == null ? void 0 : f.addPoint("run_job");
                        P.next = 5;
                        return b("regeneratorRuntime").awrap(this.$8(a.type));
                    case 5:
                        o = P.sent;
                        p = k[a.type];
                        if (o) {
                            P.next = 23;
                            break
                        }
                        if (p) {
                            P.next = 15;
                            break
                        }
                        d("WALogger").ERROR(H(), a.type).sendLogs("missing-job-implementation");
                        P.next = 12;
                        return b("regeneratorRuntime").awrap(c.deletePersistedJob(a.jobId));
                    case 12:
                        return P.abrupt("return", null);
                    case 15:
                        if (!(p === "NOOP")) {
                            P.next = 20;
                            break
                        }
                        d("WALogger").WARN(G(), a.type);
                        P.next = 19;
                        return b("regeneratorRuntime").awrap(c.deletePersistedJob(a.jobId));
                    case 19:
                        return P.abrupt("return", null);
                    case 20:
                        P.next = 22;
                        return b("regeneratorRuntime").awrap(p());
                    case 22:
                        o = P.sent;
                    case 23:
                        q = o;
                        p && d("WALogger").LOG(F(), a.type);
                        r = (g = a.stepFirstStartTime) != null ? g : d("WATimeUtils").unixTime();
                        a.stepFirstStartTime = r;
                        a.stepUnexpectedErrorCount = a.stepUnexpectedErrorCount || 0;
                        a.backedOffCount = a.backedOffCount || 0;
                        if (!(a.step === d("WAPersistedJobManager").FINISHED_JOB)) {
                            P.next = 46;
                            break
                        }
                        I = a.waitUntil;
                        J = d("WATimeUtils").secondsUntil(r);
                        if (!(I != null && d("WATimeUtils").isInFuture(I) && J > 0)) {
                            P.next = 40;
                            break
                        }
                        d("WALogger").LOG(E(), Q(a));
                        I = d("WATimeUtils").castToUnixTime(I - J);
                        if (!d("WATimeUtils").isInFuture(I)) {
                            P.next = 40;
                            break
                        }
                        a.stepFirstStartTime = d("WATimeUtils").castToUnixTime(r - J);
                        a.waitUntil = I;
                        P.next = 40;
                        return b("regeneratorRuntime").awrap(c.updatePersistedJob(a));
                    case 40:
                        if (!(I == null || !d("WATimeUtils").isInFuture(I))) {
                            P.next = 44;
                            break
                        }
                        d("WALogger").LOG(D(), Q(a));
                        P.next = 44;
                        return b("regeneratorRuntime").awrap(c.deletePersistedJob(a.jobId));
                    case 44:
                        j["delete"](a.jobId);
                        return P.abrupt("return", a.current);
                    case 46:
                        K = a.step !== d("WAPersistedJobManager").UNSTARTED_JOB ? o.find(function(b) {
                            return b.stepName === a.step
                        }) : o[0];
                        if (K) {
                            P.next = 52;
                            break
                        }
                        d("WALogger").ERROR(C(), a.type, a.step).sendLogs("missing-job-step");
                        P.next = 51;
                        return b("regeneratorRuntime").awrap(c.deletePersistedJob(a.jobId));
                    case 51:
                        return P.abrupt("return", null);
                    case 52:
                        a.step = K.stepName;
                        L = function f() {
                            var g = a.waitUntil,
                                j = (h || (h = b("Promise"))).resolve();
                            if (g != null) {
                                var k = d("WATimeUtils").futureUnixTime(d("WATimeUtils").DAY_SECONDS);
                                g > k ? (d("WALogger").LOG(B(), S(a), g, k), a.waitUntil = k, j = c.updatePersistedJob(a).then(function() {
                                    return d("WATimeUtils").delayUntil(k)
                                })) : (d("WALogger").LOG(A(), S(a), g), j = d("WATimeUtils").delayUntil(g))
                            }
                            return j.then(function() {
                                var b = function() {
                                    a.waitUntil = null;
                                    d("WATimeUtils").happenedWithin(r, d("WATimeUtils").DAY_SECONDS) || a.stepHardStartCountAfterTimeout++;
                                    return c.updatePersistedJob(a)
                                };
                                return i.$10(a, q, c, b, e)["catch"](function(b) {
                                    if (b instanceof d("WAPersistedJobManager").RetryOnBackoff) {
                                        var g;
                                        d("WALogger").LOG(z(), S(a));
                                        (g = e.eventFlow) == null ? void 0 : g.addPoint("retry_on_backoff");
                                        g = d("WAPromiseBackoffs").getDelay(++a.backedOffCount, b.backoffOptions);
                                        a.waitUntil = d("WATimeUtils").futureUnixTime(Math.ceil(g / 1e3));
                                        a.stepHardStartCountAfterTimeout > 0 && --a.stepHardStartCountAfterTimeout;
                                        return c.updatePersistedJob(a).then(f)
                                    } else {
                                        if (!(b instanceof d("WAPersistedJobManager").NonRetryableError) && a.stepUnexpectedErrorCount < N) {
                                            (g = e.eventFlow) == null ? void 0 : g.addPoint("retry_on_unexpected_error");
                                            d("WALogger").WARN(y(), S(a), a.stepUnexpectedErrorCount);
                                            d("WALogger").WARN(x(), S(a), b);
                                            a.stepUnexpectedErrorCount++;
                                            return c.updatePersistedJob(a).then(f)
                                        }
                                        throw b
                                    }
                                })
                            })
                        };
                        M = L();
                        O = M.then(function(e) {
                            var f;
                            return b("regeneratorRuntime").async(function(g) {
                                while (1) switch (g.prev = g.next) {
                                    case 0:
                                        d("WALogger").LOG(w(), S(a));
                                        f = null;
                                        try {
                                            f = m(a.jobId, a.type, a.original, e)
                                        } catch (b) {
                                            d("WALogger").ERROR(v(), a.type, b).sendLogs("onJobFinished-threw")
                                        }
                                        if (!(f != null && f > 0)) {
                                            g.next = 12;
                                            break
                                        }
                                        a.waitUntil = d("WATimeUtils").futureUnixTime(Math.ceil(f / 1e3));
                                        a.step = d("WAPersistedJobManager").FINISHED_JOB;
                                        a.current = e;
                                        a.stepFirstStartTime = d("WATimeUtils").unixTime();
                                        g.next = 10;
                                        return b("regeneratorRuntime").awrap(c.updatePersistedJob(a));
                                    case 10:
                                        g.next = 15;
                                        break;
                                    case 12:
                                        g.next = 14;
                                        return b("regeneratorRuntime").awrap(c.deletePersistedJob(a.jobId));
                                    case 14:
                                        j["delete"](a.jobId);
                                    case 15:
                                    case "end":
                                        return g.stop()
                                }
                            }, null, this)
                        }, function(e) {
                            var f, g;
                            return b("regeneratorRuntime").async(function(h) {
                                while (1) switch (h.prev = h.next) {
                                    case 0:
                                        d("WALogger").ERROR(u(), a.type, e).sendLogs("job-threw-exception-" + a.type);
                                        f = q.find(function(b) {
                                            return b.stepName === a.step
                                        });
                                        if (f) {
                                            h.next = 6;
                                            break
                                        }
                                        d("WALogger").ERROR(t(), a.type, a.step);
                                        h.next = 10;
                                        break;
                                    case 6:
                                        g = f.info(a.current, a.original, U(a, i.isRestartAfterCrash));
                                        if (!(g.stopRetryIf != null)) {
                                            h.next = 10;
                                            break
                                        }
                                        h.next = 10;
                                        return b("regeneratorRuntime").awrap(g.stopRetryIf.onStopRetry(a.current, a.original, U(a, i.isRestartAfterCrash)));
                                    case 10:
                                        h.next = 12;
                                        return b("regeneratorRuntime").awrap(c.deletePersistedJob(a.jobId));
                                    case 12:
                                        j["delete"](a.jobId);
                                    case 13:
                                    case "end":
                                        return h.stop()
                                }
                            }, null, this)
                        });
                        try {
                            n(a.jobId, a.type, a.original)
                        } catch (b) {
                            d("WALogger").ERROR(s(), a.type, b).sendLogs("onJobStarted-threw")
                        }
                        return P.abrupt("return", O.then(function() {
                            return M
                        }));
                    case 58:
                    case "end":
                        return P.stop()
                }
            }, null, this)
        };
        e.addPersistedJobImplementation = function(a, b) {
            var c = this.implementationLoaders,
                e = this.deprecatedJobs;
            if (c.has(a)) {
                d("WALogger").ERROR(r(), a).sendLogs("repeat-job-loader");
                return
            }
            e && e[a] && d("WALogger").DEV(q(), a);
            c.set(a, b)
        };
        e.fireAndForget = function(a) {
            var c = this;
            if (this.$1.indexOf(a.type) === -1) {
                d("WALogger").LOG(p(), a.type);
                this.fireAndForgetNonPersisted(a);
                return
            }
            d("WALogger").LOG(o(), a.type);
            O({
                code: function(d) {
                    var e;
                    return b("regeneratorRuntime").async(function(f) {
                        while (1) switch (f.prev = f.next) {
                            case 0:
                                e = {
                                    eventFlow: d
                                };
                                f.next = 3;
                                return b("regeneratorRuntime").awrap(c.initialJobsPromise);
                            case 3:
                                d.addPoint("initial_jobs_promise_fulfilled");
                                return f.abrupt("return", c.$6(a, c.accessors, e).then(function(a) {
                                    return c.$4(a, c.accessors, e)
                                }));
                            case 5:
                            case "end":
                                return f.stop()
                        }
                    }, null, this)
                },
                annotations: {
                    string: {
                        name: a.type
                    },
                    bool: {
                        offlineQueueMode: this.offlineQueueMode
                    }
                }
            })
        };
        e.waitUntilPersisted = function(a) {
            var c = this,
                e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        if (!(this.$1.indexOf(a.type) === -1)) {
                            f.next = 4;
                            break
                        }
                        d("WALogger").LOG(n(), a.type);
                        this.fireAndForgetNonPersisted(a);
                        return f.abrupt("return", (h || (h = b("Promise"))).resolve());
                    case 4:
                        d("WALogger").LOG(m(), a.type);
                        e = P({
                            string: {
                                name: a.type
                            },
                            bool: {
                                offlineQueueMode: this.offlineQueueMode
                            }
                        });
                        f.next = 8;
                        return b("regeneratorRuntime").awrap(this.initialJobsPromise);
                    case 8:
                        e.addPoint("initial_jobs_promise_fulfilled");
                        return f.abrupt("return", this.$6(a, this.accessors, {
                            eventFlow: e
                        }).then(function(a) {
                            O({
                                code: function(b) {
                                    b = {
                                        eventFlow: b
                                    };
                                    return c.$4(a, c.accessors, b)
                                },
                                eventFlow: e
                            })
                        })["catch"](function(a) {
                            e.endFail("error", {
                                string: {
                                    error: "" + a
                                }
                            });
                            throw a
                        }));
                    case 10:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        };
        e.waitUntilCompleted = function(a) {
            var c = this;
            if (this.$1.indexOf(a.type) === -1) {
                d("WALogger").LOG(l(), a.type);
                return this.waitUntilCompletedNonPersisted(a)
            }
            d("WALogger").LOG(k(), a.type);
            return O({
                code: function(d) {
                    var e;
                    return b("regeneratorRuntime").async(function(f) {
                        while (1) switch (f.prev = f.next) {
                            case 0:
                                e = {
                                    eventFlow: d
                                };
                                f.next = 3;
                                return b("regeneratorRuntime").awrap(c.initialJobsPromise);
                            case 3:
                                d.addPoint("initial_jobs_promise_fulfilled");
                                return f.abrupt("return", c.$6(a, c.accessors, e).then(function(a) {
                                    return c.$4(a, c.accessors, e)
                                }));
                            case 5:
                            case "end":
                                return f.stop()
                        }
                    }, null, this)
                },
                annotations: {
                    string: {
                        name: a.type
                    },
                    bool: {
                        offlineQueueMode: this.offlineQueueMode
                    }
                }
            })
        };
        e.fireAndForgetNonPersisted = function(a) {
            var c = this;
            O({
                code: function(d) {
                    var e;
                    return b("regeneratorRuntime").async(function(f) {
                        while (1) switch (f.prev = f.next) {
                            case 0:
                                e = {
                                    eventFlow: d
                                };
                                f.next = 3;
                                return b("regeneratorRuntime").awrap(c.initialJobsPromise);
                            case 3:
                                d.addPoint("initial_jobs_promise_fulfilled");
                                return f.abrupt("return", c.$6(a, c.inMemoryAccessors, e).then(function(a) {
                                    return c.$4(a, c.inMemoryAccessors, e)
                                }));
                            case 5:
                            case "end":
                                return f.stop()
                        }
                    }, null, this)
                },
                annotations: {
                    string: {
                        name: a.type
                    },
                    bool: {
                        offlineQueueMode: this.offlineQueueMode
                    }
                }
            })
        };
        e.waitUntilCompletedNonPersisted = function(a) {
            var c = this;
            return O({
                code: function(d) {
                    var e;
                    return b("regeneratorRuntime").async(function(f) {
                        while (1) switch (f.prev = f.next) {
                            case 0:
                                e = {
                                    eventFlow: d
                                };
                                f.next = 3;
                                return b("regeneratorRuntime").awrap(c.initialJobsPromise);
                            case 3:
                                d.addPoint("initial_jobs_promise_fulfilled");
                                return f.abrupt("return", c.$6(a, c.inMemoryAccessors, e).then(function(a) {
                                    return c.$4(a, c.inMemoryAccessors, e)
                                }));
                            case 5:
                            case "end":
                                return f.stop()
                        }
                    }, null, this)
                },
                annotations: {
                    string: {
                        name: a.type
                    },
                    bool: {
                        offlineQueueMode: this.offlineQueueMode
                    }
                }
            })
        };
        return a
    }();

    function Q(a) {
        return "Job[" + a.jobId + "] (" + a.type + ")"
    }

    function R(a) {
        return "[Job " + a.type + "] "
    }

    function S(a) {
        return "Job[" + a.jobId + "] (" + a.type + "." + a.step + ")"
    }

    function T(a, b, c) {
        a === "unsatisfiable" ? d("WALogger").LOG(j(), S(c), b) : a === "unsatisfied" ? d("WALogger").LOG(i(), S(c), b) : a
    }

    function U(a, b, c) {
        b === void 0 && (b = !1);
        return {
            jobStartTime: a.startTime,
            afterCrash: b,
            interruptJob: V,
            eventFlow: c
        }
    }

    function V(a) {
        return new(d("WAPersistedJobManager").InterruptJob)(a)
    }
    g.PersistedJobManager = a
}), 98);
__d("WAWaitForComms", ["WAResolvable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new(d("WAResolvable").Resolvable)();

    function a() {
        return h.promise
    }

    function b() {
        h.isSettled && (h = new(d("WAResolvable").Resolvable)())
    }

    function c() {
        h.resolve()
    }

    function e() {
        return !h.resolveWasCalled()
    }

    function f(a) {
        return h.reject(a)
    }
    g.waitForComms = a;
    g.commsConnectionLost = b;
    g.unblockComms = c;
    g.isStillWaitingForComms = e;
    g.failComms = f
}), 98);
__d("MAWJobManager", ["MAWBridge", "MAWDefinePersistedJob", "MAWJobPersistenceAccessorsApi", "WAPersistedJobManagerV2", "WAWaitForComms", "WAWaitForUserUnblocked", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new(d("WAPersistedJobManagerV2").PersistedJobManager)({
        accessors: d("MAWJobPersistenceAccessorsApi").getJobPersistenceAccessors(),
        deprecatedJobs: {
            removeCurrentDevice: "NOOP"
        },
        ignoreForceNonPersistedJobList: ["sendMsg", "sendReactionMsg", "sendMediaMsg", "sendWrittenMsg", "linkReactionsToMsgs", "downloadAndHandleMedia"],
        isRestartAfterCrash: !1,
        listeners: {
            onJobFinished: function(a, b, c, e) {
                d("MAWBridge").getBridge().fireAndForget("event", "onJobFinished", {
                    id: a,
                    originalArgs: c,
                    result: e,
                    type: b
                }, !0);
                return null
            },
            onJobStarted: c("emptyFunction")
        },
        offlineQueueCompletePromise: d("WAWaitForUserUnblocked").waitForUserUnblocked(),
        unfinishedJobEntries: d("WAWaitForComms").waitForComms().then(function() {
            return d("MAWJobPersistenceAccessorsApi").getJobPersistenceAccessors().loadAllJobs()
        })
    });

    function a() {
        return d("MAWDefinePersistedJob").persistedJobsApi
    }

    function b() {
        return h
    }
    g.getPersistedJobsApi = a;
    g.getJobManager = b
}), 98);
__d("WAJobBuilder", ["Promise", "WAPersistedJobManager", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = function() {
        function a(a) {
            this.steps = a
        }
        var b = a.prototype;
        b.step = function(a, b) {
            return this.$1(a, typeof b === "function" ? {
                code: b
            } : b)
        };
        b.$1 = function(b, c) {
            var e = c.stopRetryIf,
                f = c.requirements;
            c = c.code;
            f = k(f, c, e);
            if (e) {
                var g = e.timePassedSeconds;
                c = e.appCrashed;
                var h = e.onStopRetry;
                h = k(null, l(h), e);
                g != null && (f = j(function(a, b, c) {
                    a = c.jobStartTime;
                    return d("WATimeUtils").happenedWithin(a, g)
                }, f, h));
                c && (f = j(function(a, b, c) {
                    a = c.afterCrash;
                    return !a
                }, f, h))
            }
            return new a([].concat(this.steps, [{
                stepName: b,
                info: f
            }]))
        };
        b.finalStep = function(a, b) {
            var c = this.step(a, b);
            return {
                end: function() {
                    return c.steps
                }
            }
        };
        return a
    }();

    function a() {
        return new i([])
    }

    function j(a, b, c) {
        return function(d, e, f) {
            return a(d, e, f) ? b(d, e, f) : c(d, e, f)
        }
    }

    function k(a, b, c) {
        var d = {
            requirements: a,
            code: b,
            stopRetryIf: c
        };
        return function() {
            return d
        }
    }

    function l(a) {
        return function(c, e, f) {
            return (h || (h = b("Promise"))).resolve(a(c, e, f)).then(function(a) {
                return a instanceof d("WAPersistedJobManager").InterruptJob ? a : new(d("WAPersistedJobManager").InterruptJob)(a)
            })
        }
    }
    g.JobBuilder = i;
    g.definePersistedJob = a
}), 98);
__d("MAWDefinePersistedJob", ["MAWJobManager", "Promise", "WAJobBuilder"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    e = {
        definePersistedJob: function() {
            return d("WAJobBuilder").definePersistedJob()
        }
    };

    function a(a) {
        var c = d("MAWJobManager").getJobManager();
        Object.keys(a).forEach(function(d) {
            var e = a[d];
            c.addPersistedJobImplementation(d, function() {
                return (h || (h = b("Promise"))).resolve(e)
            })
        })
    }

    function c(a) {
        var b = d("MAWJobManager").getJobManager();
        Object.keys(a).forEach(function(c) {
            var d = a[c];
            b.addPersistedJobImplementation(c, d)
        })
    }
    g.persistedJobsApi = e;
    g.setMsgrJobImplementations = a;
    g.setMsgrDeferredJobImplementations = c
}), 98);
__d("MAWDexieCastToPromise", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a) {
        return (g || (g = b("Promise"))).resolve(a)
    }

    function c(a) {
        return a
    }
    f.dexieCastToPromise = a;
    f.promiseCastToDexiePromise_I_KNOW_WHAT_I_AM_DOING = c
}), 66);
__d("MAWDownloadManager", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = 1e4;
    a = function() {
        function a() {
            this.$1 = [], this.$2 = new Map()
        }
        var b = a.prototype;
        b.setToDownloadManager = function(a, b) {
            this.$3(), this.$2.set(a, b), this.$1.push(a)
        };
        b.getFromDownloadManager = function(a) {
            return this.$2.get(a)
        };
        b.removeFromMediaDownloadManager = function(a) {
            this.$2["delete"](a);
            var b = this.$1.filter(function(b) {
                return b !== a
            });
            this.setDownloadManagerQueue(b)
        };
        b.setDownloadManagerQueue = function(a) {
            this.$1 = a
        };
        b.$3 = function() {
            if (this.$1.length >= g) {
                var a = this.$1.shift();
                this.$2["delete"](a)
            }
        };
        return a
    }();
    f.DownloadManager = a
}), 66);
__d("MAWOptimisticUploadManager", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = new Map();

    function a() {
        return g
    }

    function b() {
        g.clear()
    }
    f.getOptimisticUploadManager = a;
    f.clearOptimisticUploadManager = b
}), 66);
__d("MAWGetMediaPlaintextApi", ["MAWIndexedDb", "MAWMediaUtils", "MAWOptimisticUploadManager", "MAWTransactionMode", "Promise", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media blob does not exist for the given hashedPlaintextHash"]);
        i = function() {
            return a
        };
        return a
    }
    a = function(a) {
        var c = d("MAWOptimisticUploadManager").getOptimisticUploadManager();
        c = c.get(a);
        if (c == null) return j(a);
        else return (h || (h = b("Promise"))).resolve(c.file)
    };

    function j(a) {
        return d("MAWIndexedDb").makeMsgrTransactor({
            chunk: d("MAWTransactionMode").READONLY
        }, "getMediaPlaintextFromDb", function(a) {
            return function(b) {
                b = d("MAWMediaUtils").genHMACPlaintextHash(b);
                return a.chunk.where("hashedPlaintextHash").equals(b).first().then(function(a) {
                    if (!a) {
                        d("WALogger").WARN(i());
                        return null
                    }
                    return new Blob([a.blobData], {
                        type: a.mimetype
                    })
                })
            }
        })(a)
    }
    g.getMediaPlaintext = a
}), 98);
__d("MAWGetMsgForProtocolMsgIdTxn", ["MAWDbMsgTxns", "MAWIndexedDb", "MAWTransactionMode", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("MAWIndexedDb").makeMsgrTransactor({
        messages: d("MAWTransactionMode").READONLY,
        threads: d("MAWTransactionMode").READONLY
    }, "getMsgForProtocolMsgIdTxn", function(a) {
        return function(b) {
            return d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, b).then(function(a) {
                return a != null ? d("WAResultOrError").makeResult(a) : d("WAResultOrError").makeError("message-not-found")
            })
        }
    });
    g.getMsgForProtocolMsgIdTxn = a
}), 98);
__d("MAWHandleXmaTransactionUtil", ["FBLogger", "MAWBridgeXMA", "MAWDbChunkTxns", "MAWDexieCastToPromise", "MAWIndexedDb", "MAWMediaGalleryM2Utils", "MAWTransactionMode", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return h.apply(this, arguments)
    }

    function h() {
        h = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            var c = !1;
            a != null && b.defaultPreviewMediaId === a.mediaId && (c = (yield l(a)));
            return d("MAWBridgeXMA").createBridgeXMA(a, b, c)
        });
        return h.apply(this, arguments)
    }

    function e(a, b, c) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e) {
            a = (yield j(a, b, e));
            d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled({
                isSilent: !0
            }) && c("FBLogger")("messenger_e2ee_web").info("Calling into NewXMA from %s", "MAWHandleXmaTransactionUtil");
            d("MAWIndexedDb").afterTransaction({
                tag: "NewXMA",
                value: a
            })
        });
        return i.apply(this, arguments)
    }

    function j(a, b, c) {
        return k.apply(this, arguments)
    }

    function k() {
        k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            var e = !1;
            a != null && (e = (yield d("MAWDexieCastToPromise").dexieCastToPromise(d("MAWDbChunkTxns").hasMediaChunk(c, a.hashedPlaintextHash))));
            return d("MAWBridgeXMA").createBridgeXMA(a, b, e)
        });
        return k.apply(this, arguments)
    }
    var l = d("MAWIndexedDb").makeMsgrTransactor({
        chunk: d("MAWTransactionMode").READONLY
    }, "MAWHandleXmaTransactionUtil.hasMediaChunkTransaction", function(a) {
        return function(b) {
            return d("MAWDbChunkTxns").hasMediaChunk(a, b.hashedPlaintextHash)
        }
    });
    g.checkMediaChunkTransactionAndCreatedBridgeXma = a;
    g.checkMediaChunkAndHandleXmaAfterTransaction = e;
    g.checkMediaChunkAndCreatedBridgeXma = j
}), 98);
__d("MAWMediaAfterTxns", ["MAWBridgeTypesCreators", "MAWDbMedia", "MAWDexieCastToPromise", "MAWIndexedDb", "MAWMediaUtils", "MAWRavenUtils", "gkx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f, g, i) {
        c("promiseDone")(d("MAWDexieCastToPromise").dexieCastToPromise(f.messages.where("msgId").anyOf(b.msgIds).toArray().then(function(j) {
            var k = a.threadJid;
            j = d("MAWBridgeTypesCreators").getMsgIdsFilteredByJid(j, k);
            k = a.ravenEphemeralType != null && a.ravenEphemeralMediaState != null ? d("MAWBridgeTypesCreators").createBridgeMedia({
                chatJid: k,
                filteredMsgIds: j,
                hasMediaForUI: e,
                media: b,
                ravenSettings: d("MAWRavenUtils").deriveRavenSettings(a.ravenEphemeralType, a.ravenEphemeralMediaState),
                sortOrderMs: a.sortOrderMs,
                transportKey: i
            }) : d("MAWBridgeTypesCreators").createBridgeMedia({
                chatJid: k,
                filteredMsgIds: j,
                hasMediaForUI: e,
                media: b,
                sortOrderMs: a.sortOrderMs,
                transportKey: i
            });
            c("gkx")("2616") === !0 ? h(f, babelHelpers["extends"]({}, k, {
                skipShouldUpdateHasMore: g
            })) : d("MAWIndexedDb").afterTransaction({
                tag: "NewMedia",
                value: k
            })
        })))
    }

    function h(a, b, e) {
        if (!i(b)) return d("MAWIndexedDb").afterTransaction({
            tag: "NewMedia",
            value: b
        });
        c("promiseDone")(d("MAWDexieCastToPromise").dexieCastToPromise(d("MAWMediaUtils").getBridgeMediaAnnotatedForDisplay(a, b, e).then(function(a) {
            d("MAWIndexedDb").afterTransaction({
                tag: "NewMedia",
                value: a
            })
        })))
    }

    function i(a) {
        if (a.ephemeralMediaState != null || a.ephemeralMediaViewMode != null) return !1;
        switch (a.mediaType) {
            case d("MAWDbMedia").MEDIA_TYPE.IMAGE:
            case d("MAWDbMedia").MEDIA_TYPE.VIDEO:
            case d("MAWDbMedia").MEDIA_TYPE.GIF:
            case d("MAWDbMedia").MEDIA_TYPE.DOCUMENT_FILE:
                return !0;
            default:
                return !1
        }
    }
    g.handleNewMediaAfterTxn = a;
    g.handleNewMediaAfterTxnWithBridgeMedia = h
}), 98);
__d("MAWMediaDownloadManager", ["MAWDownloadManager"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new(d("MAWDownloadManager").DownloadManager)(),
        i = new(d("MAWDownloadManager").DownloadManager)();

    function a(a, b) {
        h.setToDownloadManager(a, b)
    }

    function b(a) {
        return h.getFromDownloadManager(a)
    }

    function c(a) {
        h.removeFromMediaDownloadManager(a)
    }

    function e(a, b) {
        i.setToDownloadManager(a, b)
    }

    function f(a) {
        return i.getFromDownloadManager(a)
    }

    function j(a) {
        i.removeFromMediaDownloadManager(a)
    }
    g.setToMediaDownloadManager = a;
    g.getFromMediaDownloadManager = b;
    g.removeFromMediaDownloadManager = c;
    g.setToMediaPlaintextDownloadManager = e;
    g.getFromMediaPlaintextDownloadManager = f;
    g.removeFromMediaPlaintextDownloadManager = j
}), 98);
__d("MAWHandleMediaDownloadApi", ["MAWBridgeMsg", "MAWBridgeTypesCreators", "MAWDbChunkTxns", "MAWDbMedia", "MAWDbMediaTxns", "MAWDbMsgTxns", "MAWDbXMATxns", "MAWDexieTable", "MAWGetMsgQuoteTxn", "MAWHandleXmaTransactionUtil", "MAWIndexedDb", "MAWLoadReplyMediaTxns", "MAWLoggerUtils", "MAWMediaAfterTxns", "MAWMediaDownloadManager", "MAWMediaUtils", "MAWMsgType", "MAWTransactionMode", "MAWXMAUtils", "Promise", "WAArmadilloXMA.pb", "WAResultOrError", "WATagsLogger", "gkx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media is null when storing downloaded blob"]);
        i = function() {
            return a
        };
        return a
    }
    var j = d("WATagsLogger").TAGS([d("MAWLoggerUtils").Tag.MediaDownload, d("MAWLoggerUtils").Tag.MessageReceive]);
    e = d("MAWIndexedDb").makeMsgrTransactor({
        chunk: (a = d("MAWTransactionMode")).READWRITE,
        media: a.READWRITE,
        messages: a.READONLY,
        receiverFetchInfo: a.READONLY,
        threads: a.READONLY,
        xma: a.READONLY
    }, "handleMediaDownload", function(a) {
        return function(e, f, g, m, n) {
            var o = d("MAWMediaUtils").genHMACPlaintextHash(e);
            return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, m), a.media.where("hashedPlaintextHash").equals(o).first(), d("MAWDbChunkTxns").getOrCreateMediaChunk(a, e, g, f)]).then(function(m) {
                var o = m[0],
                    p = m[1];
                m[2];
                if (p == null) {
                    j.ERROR(i());
                    return d("WAResultOrError").makeError("missing-media-on-save")
                }
                var q;
                m = !1;
                q = d("MAWMediaDownloadManager").getFromMediaPlaintextDownloadManager(e);
                q == null && !c("gkx")("6417") && (q = d("MAWMediaDownloadManager").getFromMediaDownloadManager(p.mediaId), m = !0);
                q != null && (q((h || (h = b("Promise"))).resolve(new Blob([g], {
                    type: f
                }))), d("MAWMediaDownloadManager").removeFromMediaPlaintextDownloadManager(e), m && d("MAWMediaDownloadManager").removeFromMediaDownloadManager(p.mediaId));
                return k(a, o).then(function(b) {
                    if (!b) return a.messages.where("msgId").anyOf(p.msgIds).toArray().then(function(b) {
                        a.threads.where("jid").anyOf(b.map(function(a) {
                            return a.threadJid
                        })).toArray().then(function(e) {
                            e.forEach(function(e) {
                                if (e != null) {
                                    e = d("MAWBridgeTypesCreators").createBridgeMedia({
                                        chatJid: e.jid,
                                        filteredMsgIds: d("MAWBridgeTypesCreators").getMsgIdsFilteredByJid(b, e.jid),
                                        hasMediaForUI: !0,
                                        media: p,
                                        sortOrderMs: o == null ? void 0 : o.sortOrderMs
                                    });
                                    c("gkx")("2616") === !0 ? d("MAWMediaAfterTxns").handleNewMediaAfterTxnWithBridgeMedia(a, e, b) : d("MAWIndexedDb").afterTransaction({
                                        tag: "NewMedia",
                                        value: e
                                    })
                                }
                            })
                        });
                        return b
                    }).then(function(b) {
                        return l(a, b)
                    });
                    else if (c("gkx")("821")) return a.messages.where("msgId").anyOf(p.msgIds).toArray().then(function(b) {
                        a.threads.where("jid").anyOf(b.map(function(a) {
                            return a.threadJid
                        })).toArray().then(function(e) {
                            e.forEach(function(e) {
                                if (e != null) return d("MAWDbXMATxns").getXMAFromMsgs(a, b).then(function(b) {
                                    return d("MAWDexieTable").dexieAll(b.map(function(b) {
                                        if (d("MAWXMAUtils").isXMAStoryReply(b.targetType)) return;
                                        if (b.defaultPreviewMediaId !== p.mediaId) return;
                                        c("promiseDone")(d("MAWHandleXmaTransactionUtil").checkMediaChunkAndHandleXmaAfterTransaction(p, b, a))
                                    }))
                                })
                            })
                        });
                        return b
                    }).then(function(b) {
                        return l(a, b)
                    })
                }).then(function() {
                    var b;
                    b = (p.mediaType === d("MAWDbMedia").MEDIA_TYPE.VIDEO || p.mediaType === d("MAWDbMedia").MEDIA_TYPE.PTT) && c("gkx")("7129") ? {
                        audioAvgBitsPerSecond: n == null ? void 0 : (b = n.audioStreamReport) == null ? void 0 : b.avgBitsPerSecond,
                        audioNumberOfChannels: n == null ? void 0 : (b = n.audioStreamReport) == null ? void 0 : b.numberOfChannels,
                        audioSamplingRate: n == null ? void 0 : (b = n.audioStreamReport) == null ? void 0 : b.samplingRate,
                        audioStreamType: n == null ? void 0 : (b = n.audioStreamReport) == null ? void 0 : b.streamType,
                        mimetype: n == null ? void 0 : n.mimeType,
                        videoAvgBitsPerSecond: n == null ? void 0 : (b = n.videoStreamReport) == null ? void 0 : b.avgBitsPerSecond,
                        videoCalculatedFps: n == null ? void 0 : (b = n.videoStreamReport) == null ? void 0 : b.calculatedFps,
                        videoDuration: n == null ? void 0 : (b = n.videoStreamReport) == null ? void 0 : b.duration,
                        videoHeight: n == null ? void 0 : (b = n.videoStreamReport) == null ? void 0 : b.videoHeight,
                        videoNominalFps: n == null ? void 0 : (b = n.videoStreamReport) == null ? void 0 : b.nominalFps,
                        videoStreamType: n == null ? void 0 : (b = n.videoStreamReport) == null ? void 0 : b.streamType,
                        videoWidth: n == null ? void 0 : (b = n.videoStreamReport) == null ? void 0 : b.videoWidth
                    } : void 0;
                    d("MAWDbMediaTxns").updateMedia(a, p, {
                        size: g.byteLength,
                        validatedResult: b
                    })
                }).then(function() {
                    return d("WAResultOrError").makeResult()
                })
            })
        }
    });

    function k(a, b) {
        var c;
        if (b == null) return d("MAWDexieTable").dexieResolve(!1);
        if (b.type === d("MAWMsgType").MSG_TYPE.XMA) return d("MAWDexieTable").dexieResolve(!0);
        return ((c = b.quote) == null ? void 0 : c.content.xmaMessageType) === d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_REPLY ? d("MAWDexieTable").dexieResolve(b.type === d("MAWMsgType").MSG_TYPE.TEXT) : d("MAWDbXMATxns").maybeGetXMAFromAssociatedMsgId(a, b.msgId).then(function(a) {
            return a != null
        })
    }

    function l(a, b) {
        return d("MAWGetMsgQuoteTxn").maybeBatchGetMsgsByQuoteExternalId(a, b.map(function(a) {
            return a.externalId
        })).then(function(b) {
            return b.map(function(b) {
                return d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, b).then(function(a) {
                    d("MAWIndexedDb").afterTransaction({
                        tag: "MsgUpdated",
                        value: d("MAWBridgeMsg").createBridgeMsg(b, void 0, a, "EncryptedBackups")
                    })
                })
            })
        })
    }
    g.handleMediaDownload = e
}), 98);
__d("MAWMediaPreviewDownloadManager", ["WAResolvable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 1e4,
        i = [],
        j = new Map();

    function a(a) {
        if (j.has(a)) return;
        l();
        var b = new(d("WAResolvable").Resolvable)();
        j.set(a, b);
        i.push(a)
    }

    function b(a, b) {
        var c = j.get(a);
        if (c == null) return;
        c.reject(b);
        k(a)
    }

    function c(a) {
        return j.get(a)
    }

    function k(a) {
        j["delete"](a)
    }

    function l() {
        if (i.length >= h) {
            var a = i.shift();
            a != null && j["delete"](a)
        }
    }

    function e() {
        i = [], j.clear()
    }
    g.markMediaPreviewAsDownloading = a;
    g.markMediaPreviewAsFailed = b;
    g.getMediaPreviewDownloadingResolvable = c;
    g.removeMediaPreviewDownloadingResolvable = k;
    g.clear = e
}), 98);
__d("MAWHandleMediaPreviewBeforeDownloadApi", ["MAWMediaPreviewDownloadManager", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a) {
        d("MAWMediaPreviewDownloadManager").markMediaPreviewAsDownloading(a);
        return (h || (h = b("Promise"))).resolve()
    };
    g.handleMediaPreviewBeforeDownload = a
}), 98);
__d("MAWMediaDownloadStatusForUI", ["MAWBridge", "MAWGetIsMediaDownloadStatusEnabled", "MAWLoggerUtils", "MAWMediaDownloadStatus", "WATagsLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getStatusTypeFromWAAPIDownloadMediaError: Unknown error type ", ""]);
        h = function() {
            return a
        };
        return a
    }
    var i = d("WATagsLogger").TAGS([d("MAWLoggerUtils").Tag.MediaDownload, d("MAWLoggerUtils").Tag.MessageReceive]);

    function a(a) {
        var b = a.details,
            c = a.hash,
            e = a.status,
            f = a.type;
        a = a.validationResult;
        if (!d("MAWGetIsMediaDownloadStatusEnabled").getIsMediaDownloadStatusEnabled()) return;
        j({
            details: b,
            hash: c,
            status: e,
            type: f,
            validationResult: a
        })
    }

    function j(a) {
        var b = a.details,
            c = a.hash,
            e = a.status,
            f = a.type;
        a = a.validationResult;
        d("MAWBridge").getBridge().fireAndForget("event", "updateMediaStatus", {
            details: b,
            key: c,
            status: e,
            type: f,
            validationResult: a
        })
    }

    function b(a) {
        switch (a) {
            case "disconnected":
            case "backoff":
            case "body-network-error":
            case "no-host":
            case "download-throttled":
            case "max-attempts-exceeded":
            case "runtime-error":
            case "access-expired":
            case "http-fetch-exception":
            case "unspecified-http-error":
            case "server-timeout":
                return c("MAWMediaDownloadStatus").MANUAL_RETRYABLE_FAILURE;
            case "request-error":
            case "media-not-found":
            case "media-entry-invalid":
            case "decryption-error":
            case "enc-hash-mismatch":
            case "hash-mismatch":
            case "ciphertext-hash-mismatch":
            case "signature-expired":
                return c("MAWMediaDownloadStatus").NOT_MANUAL_RETRYABLE_FAILURE;
            default:
                a;
                i.ERROR(h(), a);
                return c("MAWMediaDownloadStatus").MANUAL_RETRYABLE_FAILURE
        }
    }
    g.sendMediaDownloadStatusToUI = a;
    g.getStatusFromWAAPIDownloadMediaError = b
}), 98);
__d("MAWHandleMediaPreviewDownloadApi", ["MAWBridgeTypesCreators", "MAWDbMediaTxns", "MAWDbMsgTxns", "MAWDexieTable", "MAWIndexedDb", "MAWLoggerUtils", "MAWMediaAfterTxns", "MAWMediaDownloadStatus", "MAWMediaDownloadStatusForUI", "MAWMediaPreviewDownloadManager", "MAWTransactionMode", "WACryptoSha256", "WAHashUtils", "WALoggerTag", "WAResultOrError", "WATagsLogger", "asyncToGeneratorRuntime", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Main media for preview is null. Type: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Handling preview for main hash ", "... preview hash ", "..."]);
        i = function() {
            return a
        };
        return a
    }
    var j = d("WATagsLogger").TAGS([d("MAWLoggerUtils").Tag.MediaDownload, d("MAWLoggerUtils").Tag.MessageReceive, c("WALoggerTag").MediaPreview]);
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e, f) {
            var g = d("WAHashUtils").toPlaintextHash(yield d("WACryptoSha256").sha256(b));
            d("MAWMediaDownloadStatusForUI").sendMediaDownloadStatusToUI({
                details: "handle_media_download",
                hash: a,
                status: c("MAWMediaDownloadStatus").DOWNLOADING,
                type: "preview"
            });
            var h = d("MAWMediaPreviewDownloadManager").getMediaPreviewDownloadingResolvable(a);
            h != null && (h.resolve(new Blob([b], {
                type: "image/jpeg"
            })), d("MAWMediaPreviewDownloadManager").removeMediaPreviewDownloadingResolvable(a));
            return k(a, g, b, e, f)
        });
        return function(b, c, d, e) {
            return a.apply(this, arguments)
        }
    }();
    var k = d("MAWIndexedDb").makeMsgrTransactor({
        chunk: (e = d("MAWTransactionMode")).READWRITE,
        media: e.READWRITE,
        messages: e.READONLY,
        threads: e.READONLY
    }, "handleMediaPreviewDownload", function(a) {
        return function(b, e, f, g, k) {
            return d("MAWDexieTable").dexieAll([d("MAWDbMediaTxns").maybeGetMediaFromPlaintextHash(a, b), d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, k)]).then(function(k) {
                var l = k[0],
                    m = k[1];
                j.LOG(i(), d("WAHashUtils").sanitisePlaintextHash(b), d("WAHashUtils").sanitisePlaintextHash(e));
                if (l == null) {
                    d("MAWMediaDownloadStatusForUI").sendMediaDownloadStatusToUI({
                        details: "missing_media_on_save",
                        hash: b,
                        status: c("MAWMediaDownloadStatus").MANUAL_RETRYABLE_FAILURE,
                        type: "preview"
                    });
                    j.WARN(h(), g);
                    return d("WAResultOrError").makeError("missing-media-on-save")
                }
                switch (g) {
                    case "image":
                        a.media.update(l.mediaId, babelHelpers["extends"]({}, l, {
                            validatedImageInfo: babelHelpers["extends"]({}, l.validatedImageInfo, {
                                jpegThumbnail: f
                            })
                        }));
                        break;
                    case "video":
                        a.media.update(l.mediaId, babelHelpers["extends"]({}, l, {
                            validatedVideoInfo: babelHelpers["extends"]({}, l.validatedVideoInfo, {
                                jpegThumbnail: f
                            })
                        }));
                        break;
                    default:
                        g;
                        break
                }
                d("MAWMediaDownloadStatusForUI").sendMediaDownloadStatusToUI({
                    details: "handle_media_download_success",
                    hash: b,
                    status: c("MAWMediaDownloadStatus").SUCCESS,
                    type: "preview"
                });
                return a.messages.where("msgId").anyOf(l.msgIds).toArray().then(function(b) {
                    return a.threads.where("jid").anyOf(b.map(function(a) {
                        return a.threadJid
                    })).toArray().then(function(e) {
                        e.forEach(function(e) {
                            if (e != null) {
                                e = d("MAWBridgeTypesCreators").createBridgeMedia({
                                    chatJid: e.jid,
                                    filteredMsgIds: d("MAWBridgeTypesCreators").getMsgIdsFilteredByJid(b, e.jid),
                                    hasMediaForUI: !0,
                                    media: l,
                                    sortOrderMs: m == null ? void 0 : m.sortOrderMs
                                });
                                c("gkx")("2616") === !0 ? d("MAWMediaAfterTxns").handleNewMediaAfterTxnWithBridgeMedia(a, e, b) : d("MAWIndexedDb").afterTransaction({
                                    tag: "NewMedia",
                                    value: e
                                })
                            }
                        });
                        return d("WAResultOrError").makeResult()
                    })
                })
            })
        }
    });
    g.handleMediaPreviewDownload = a
}), 98);
__d("MAWHandleMediaPreviewDownloadAsFailedApi", ["MAWMediaPreviewDownloadManager", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a, c) {
        d("MAWMediaPreviewDownloadManager").markMediaPreviewAsFailed(a, c);
        return (h || (h = b("Promise"))).resolve()
    };
    g.handleMediaPreviewDownloadFailed = a
}), 98);
__d("MAWMediaBackupTxns", ["MAWDbMediaTxns", "MAWDexieTable", "Promise", "WALogger", "emptyFunction", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] fbid already exists for objectId"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] mediaId or msgId cannot differ for an objectId in mediaBackup"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] ObjectId already shared by different msgId"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] fbid already exists for objectId"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] mediaId or msgId cannot differ for an objectId in mediaBackup"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to add mediaBackup entry: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to add mediaBackup entry. Will attempt a retry. Error: ", ""]);
        o = function() {
            return a
        };
        return a
    }
    var p = 1;

    function q(a, b, e, f, g, h) {
        h === void 0 && (h = 0);
        return f == null ? d("MAWDexieTable").dexieResolve() : d("MAWDbMediaTxns").maybeGetMediaBackupRowFromObjectId(a, f).then(function(i) {
            if (i == null) {
                var j = {
                    mediaId: b,
                    msgId: e,
                    objectId: f
                };
                g != null && (j = babelHelpers["extends"]({}, j, {
                    fbid: g
                }));
                return a.mediaBackup.add(j).then(function(a) {
                    return babelHelpers["extends"]({}, j, {
                        mediaBackupId: a
                    })
                })["catch"](function(i) {
                    if (i.name === "ConstraintError") {
                        if (h < p) {
                            d("WALogger").WARN(o(), i);
                            return q(a, b, e, f, g, h + 1)
                        }
                        throw c("err")("Failed to add mediaBackup entry. Original error: %s, %s", i.name, i.message)
                    }
                    d("WALogger").ERROR(n(), i);
                    throw i
                })
            } else if (i.mediaId !== b || i.msgId !== e) {
                d("WALogger").ERROR(m());
                return i
            } else {
                if (i.fbid == null && g != null) {
                    var k = babelHelpers["extends"]({}, i, {
                        fbid: g
                    });
                    return a.mediaBackup.put(k).then(function(a) {
                        return k
                    })
                } else d("WALogger").WARN(l());
                return i
            }
        })
    }

    function a(a, e) {
        if (e == null) return d("MAWDexieTable").dexieResolve();
        var f = [];
        e.forEach(function(a) {
            a = a.objectId;
            a != null && f.push(a)
        });
        return d("MAWDbMediaTxns").maybeGetMediaBackupRowsFromObjectIds(a, f).then(function(f) {
            var g = new Map(),
                l = [];
            e.forEach(function(a) {
                var b = a.objectId;
                if (b != null) {
                    var c = f.get(b);
                    if (c == null) {
                        var e = {
                                mediaId: a.mediaId,
                                msgId: a.msgId,
                                objectId: b
                            },
                            h = a.fbid;
                        e = babelHelpers["extends"]({}, e, {
                            fbid: h
                        });
                        g.get(b) != null && ((h = g.get(b)) == null ? void 0 : h.msgId) !== a.msgId && d("WALogger").ERROR(k());
                        g.set(b, e)
                    } else {
                        c.mediaId !== a.mediaId && d("WALogger").ERROR(j());
                        h = a.fbid;
                        if (c.fbid == null && h != null) {
                            b = babelHelpers["extends"]({}, c, {
                                fbid: h
                            });
                            l.push(b)
                        } else d("WALogger").WARN(i())
                    }
                }
            });
            return (h || (h = b("Promise"))).all([a.mediaBackup.bulkAdd([].concat(Array.from(g.values()))), a.mediaBackup.bulkPut(l)]).then(c("emptyFunction"))
        }).then(c("emptyFunction"))
    }
    g.linkMediaBackup = q;
    g.bulkLinkMediaBackup = a
}), 98);
__d("WASortedLists", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return []
    }

    function b() {
        return []
    }

    function c(a, b) {
        return a.filter(b)
    }

    function d(a, b) {
        return l(a.map(b))
    }

    function e(a, b) {
        var c = a.length === b.length;
        for (var d = 0; c && d < a.length; d++) a[d] !== b[d] && (c = !1);
        return c
    }

    function g(a, b) {
        for (var c = 0; c < a.length; c++)
            if (a[c] === b) return a;
        return a.concat([b]).sort()
    }

    function h(a, b) {
        if (a.length < b.length) return !1;
        var c = !0;
        for (var d = 0, e = 0; c && e < b.length; e++)
            do c = a[d] === b[e]; while (!c && ++d < a.length);
        return c
    }

    function i(a, b) {
        var c = [];
        for (var d = 0, e = 0; d < a.length; d++) {
            var f = a[d];
            while (e < b.length && f > b[e]) e++;
            (e === b.length || f < b[e]) && c.push(f)
        }
        return c
    }

    function j(a, b) {
        var c = [],
            d = 0,
            e = 0;
        while (d < a.length && e < b.length) {
            var f = a[d],
                g = b[e];
            f < g ? d++ : f === g ? (c.push(f), d++, e++) : e++
        }
        return c
    }

    function k(a, b) {
        var c = [],
            d = 0,
            e = 0;
        while (d < a.length && e < b.length) a[d] < b[e] ? c.push(a[d++]) : a[d] === b[e] ? (c.push(a[d++]), e++) : c.push(b[e++]);
        while (d < a.length) c.push(a[d++]);
        while (e < b.length) c.push(b[e++]);
        return c
    }

    function l(a) {
        return m(a.slice().sort())
    }

    function m(a) {
        var b = !1;
        for (var c = 0; c < a.length - 1; c++) a[c] === a[c + 1] && (b = !0);
        if (!b) return a;
        c = [];
        for (b = 0; b < a.length - 1; b++) a[b] !== a[b + 1] && c.push(a[b]);
        c.push(a[a.length - 1]);
        return c
    }

    function n(a) {
        return Array.from(a).sort()
    }

    function o(a) {
        return a.slice().sort()
    }

    function p(a, b, c) {
        var d = null;
        for (var e = 0; !d && e < a.length; e++) a[e] === b && (d = a.slice(), d[e] = c, d = m(d.sort()));
        return d || a
    }

    function q(a) {
        return [a]
    }

    function r(a) {
        return a.length < 1
    }

    function s(a, b, c) {
        return a.slice(b, c)
    }
    f.emptySet = a;
    f.emptyList = b;
    f.filter = c;
    f.map = d;
    f.areEqual = e;
    f.addToSet = g;
    f.contains = h;
    f.subtract = i;
    f.intersect = j;
    f.joinUniq = k;
    f.sortAndDedupe = l;
    f.asSortedSet = n;
    f.sort = o;
    f.swapIn = p;
    f.singleElement = q;
    f.isEmpty = r;
    f.slice = s
}), 66);
__d("MAWMediaManagementTxns", ["FBLogger", "MAWBridgeTypesCreators", "MAWBridgeUpload", "MAWCastToMsgrServerMediaType", "MAWConfig", "MAWDbChunkTxns", "MAWDbMediaTxns", "MAWDbMsgTxns", "MAWDexieCastToPromise", "MAWDexieTable", "MAWIndexedDb", "MAWMediaAfterTxns", "MAWMediaBackupTxns", "MAWMediaGalleryM2Utils", "MAWMediaUtils", "MAWMsgType", "MAWODSProxy", "MAWSupportedDocumentTypes", "MAWWriteMsgTxns", "WAErrorMessage", "WAHashUtils", "WAJids", "WALogger", "WAMediaUtils", "WAOdsEnums", "WASortedLists", "WATagsLogger", "WATimeUtils", "emptyFunction", "err", "gkx", "isInstamadilloEB", "justknobx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] mediaBackup entry already exists for objectId ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Same FBId assigned for different mediaIds. fbId: ", " - shared by hashedPlaintextHashes: ", " ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Same objectId assigned for different mediaIds. objectId: ", " shared by  hashedPlaintextHashes: ", " ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web][updateMediaWithEncodedMediaEntryData] media entry is missing, can't upate media with encoded data"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] media entry is missing, can't update media info"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media failed to link. Possible duplicate? Will attempt a retry. For plaintextHash: ", ", hashedPlaintextHash: ", ". Error: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media failed to link after retry. Error: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media failed to link after retry. For plaintextHash: ", ", hashedPlaintextHash: ", ". Error: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media found after retry for plaintextHash: ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing mandatory args for incoming media msg"]);
        q = function() {
            return a
        };
        return a
    }
    var r = d("WATagsLogger").TAGS(["MAWMediaManagementTxns"]),
        s = c("gkx")("23924");

    function a(a, b, c, e) {
        var f = c == null || b.type === d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE && (s || !d("MAWSupportedDocumentTypes").isAllowedType((c = c.validatedDocumentFileInfo) == null ? void 0 : c.filename));
        return d("MAWWriteMsgTxns").prepareMsgWriteData(a, b, e).then(function(a) {
            return babelHelpers["extends"]({}, a, {
                shouldDropDocument: f
            })
        })
    }

    function b(a, b, e, f, g, h, i) {
        g === void 0 && (g = !1);
        h === void 0 && (h = !1);
        var j = {
                validatedAudioInfo: b.validatedAudioInfo,
                validatedDocumentFileInfo: b.validatedDocumentFileInfo,
                validatedImageInfo: b.validatedImageInfo,
                validatedVideoInfo: b.validatedVideoInfo
            },
            k = d("MAWMediaUtils").genHMACPlaintextHash(b.plaintextHash),
            l = d("WAMediaUtils").decodeMediaEntryData(b.mediaEntry),
            m = l.objectId != null ? d("WAMediaUtils").stringToDeliveryObjectId(l.objectId) : null;
        return d("MAWDexieTable").dexieAll([t(a, e, b.plaintextHash, b.mediaType, b.size, b.mediaEntry, j, m, void 0, g), d("MAWDbChunkTxns").hasMediaChunk(a, k)]).then(function(b) {
            var c = b[0];
            b = b[1];
            e.type !== d("MAWMsgType").MSG_TYPE.REVOKED && !g && d("MAWMediaAfterTxns").handleNewMediaAfterTxn(e, c, b, a, void 0, i);
            return c
        }).then(function(a) {
            if (c("gkx")("2453")) return a;
            var b = d("MAWCastToMsgrServerMediaType").castToMsgrServerMediaType(l.serverMediaType, g),
                i = l.mediaKeyTimestamp;
            if (d("MAWMsgType").isMAWSupportedMediaType(e.type) && !c("isInstamadilloEB")() && !h) {
                var j = e.threadJid;
                f === "wa" && m != null && b != null && j != null && i != null ? d("MAWIndexedDb").afterTransaction({
                    tag: "UploadAttachment",
                    value: d("MAWBridgeUpload").createBridgeUploadAttachment(m, b, e.externalId, d("MAWConfig").getConfig().productTypeForEBAttachments, d("WAJids").threadIdForChatJid(j), j, i)
                }) : d("WALogger").WARN(q())
            }
            return a
        })
    }

    function t(a, b, c, e, f, g, h, i, j, k) {
        k === void 0 && (k = !1);
        return u(a, b, c, e, f, g, h, i, j, k).then(function(c) {
            var e = k ? d("MAWDexieTable").dexieResolve() : d("MAWDbMsgTxns").updateMediaId(a, b, c.mediaId, c.plaintextHash);
            return e.then(function() {
                return d("MAWMediaBackupTxns").linkMediaBackup(a, c.mediaId, b.msgId, i, j).then(function() {
                    return c
                })
            })
        })
    }

    function u(a, b, e, f, g, h, i, j, k, l, q) {
        l === void 0 && (l = !1);
        q === void 0 && (q = 0);
        return d("MAWDbMediaTxns").maybeGetMediaFromPlaintextHash(a, e).then(function(s) {
            var t = new Map(s == null ? void 0 : s.mediaEntries),
                v = y(h, j, k);
            v != null && t.set(b.msgId, v);
            if (s) {
                q > 0 && r.LOG(p(), d("WAHashUtils").sanitisePlaintextHash(e));
                s.msgIds || c("FBLogger")("messenger_e2ee_web").mustfix("Media missing msgIds: media type=%s", s.mediaType);
                s.mediaType || c("FBLogger")("messenger_e2ee_web").mustfix("Media missing mediaType: type=%s ; msg type=%s", f, b.type);
                var w = babelHelpers["extends"]({}, s, i, {
                    mediaEntries: t,
                    mediaType: (v = s.mediaType) != null ? v : f,
                    msgIds: d("WASortedLists").addToSet(s.msgIds || d("WASortedLists").emptySet(), b.msgId)
                });
                return a.media.put(w).then(function() {
                    return w
                })
            } else {
                var x = d("MAWMediaUtils").genHMACPlaintextHash(e),
                    z = babelHelpers["extends"]({
                        fbid: (v = k) != null ? v : void 0,
                        hashedPlaintextHash: x,
                        mediaEntries: t,
                        mediaType: f,
                        msgIds: d("WASortedLists").singleElement(b.msgId),
                        objectId: (s = j) != null ? s : void 0,
                        plaintextHash: e,
                        size: g,
                        ts: d("WATimeUtils").unixTime()
                    }, i);
                return a.media.add(z).then(function(a) {
                    return babelHelpers["extends"]({}, z, {
                        mediaId: a
                    })
                })["catch"](function(c) {
                    var p = d("WAErrorMessage").maybeGetMessageFromError(c);
                    if (q > 0) {
                        r.WARN(o(), d("WAHashUtils").sanitisePlaintextHash(e), x, p);
                        r.ERROR(n(), p);
                        throw c
                    } else {
                        r.WARN(m(), d("WAHashUtils").sanitisePlaintextHash(e), x, p);
                        d("MAWODSProxy").odsBumpEntityKey({
                            amount: 1,
                            entity: d("WAOdsEnums").Entity.MAW_MEDIA_DB_DUPLICATE_MEDIA,
                            key: "retry"
                        });
                        return u(a, b, e, f, g, h, i, j, k, l, q + 1)
                    }
                })
            }
        })
    }
    var v = function(a, b, e, f, g, h, i, j, k) {
            k === void 0 && (k = !1);
            return d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, b).then(function(b) {
                if (b == null) throw c("err")("Do not have the media message in db when attachHashToMediaMsg");
                else return t(a, b, e, h, i, void 0, j, f, g, k)
            })
        },
        w = function(a, b, e) {
            return d("MAWDbMediaTxns").maybeGetMediaFromHashedPlaintextHash(a, b).then(function(b) {
                if (b != null) {
                    var d = babelHelpers["extends"]({}, b);
                    e.validatedAudioInfo != null && (d.validatedAudioInfo = babelHelpers["extends"]({}, b.validatedAudioInfo, e.validatedAudioInfo));
                    e.validatedVideoInfo != null && (d.validatedVideoInfo = babelHelpers["extends"]({}, b.validatedVideoInfo, e.validatedVideoInfo));
                    e.validatedImageInfo != null && (d.validatedImageInfo = babelHelpers["extends"]({}, b.validatedImageInfo, e.validatedImageInfo));
                    e.validatedDocumentFileInfo != null && (d.validatedDocumentFileInfo = babelHelpers["extends"]({}, b.validatedDocumentFileInfo, e.validatedDocumentFileInfo));
                    return a.media.update(d.mediaId, d).then(c("emptyFunction"))
                } else r.WARN(l())
            })
        },
        x = function(a, b, c, e) {
            return d("MAWDbMediaTxns").maybeGetMediaFromHashedPlaintextHash(a, b).then(function(b) {
                if (b != null) {
                    var f = e ? b.mediaEntries.set(c, e) : b.mediaEntries;
                    b = babelHelpers["extends"]({}, b, {
                        mediaEntries: f
                    });
                    return a.media.update(b.mediaId, b)
                } else {
                    r.ERROR(k());
                    return d("MAWDexieTable").dexieResolve()
                }
            })
        };

    function e(a, b, c, e, f, g, h, i, j, k) {
        k === void 0 && (k = !1);
        return d("MAWDexieTable").dexieAll([v(a, b, e, f, g, h, j.size, i, k), d("MAWDbChunkTxns").getOrCreateMediaChunk(a, e, c, j.type)]).then(function(a) {
            a = a[0];
            return a
        })
    }

    function y(a, b, c) {
        var e;
        a = a;
        a != null && b != null && (e = d("WAMediaUtils").decodeMediaEntryData(a), a = d("WAMediaUtils").encodeMediaEntryWithUpdatedObjectId(e, b));
        a != null && c != null && (e = d("WAMediaUtils").decodeMediaEntryData(a), a = d("WAMediaUtils").encodeMediaEntryWithUpdatedFbid(e, c));
        return a
    }

    function f(a, b, c) {
        var e = new Map();
        a.mediaEntries.forEach(function(a, f) {
            var g = d("WAMediaUtils").decodeMediaEntryData(a);
            g = g.objectId === b ? d("WAMediaUtils").encodeMediaEntryWithUpdatedFbid(g, c) : a;
            e.set(f, g)
        });
        return e
    }

    function z(a, b, c, e, f) {
        var g = new Map();
        b.forEach(function(a) {
            var b;
            b = (b = g.get(a.hashedPlaintextHash)) != null ? b : [];
            b.push(a);
            g.set(a.hashedPlaintextHash, b)
        });
        return d("MAWDbMediaTxns").maybeBulkGetMediaFromHashedPlaintextHash(a, [].concat(Array.from(g.keys()))).then(function(h) {
            var i = new Map(h.map(function(a) {
                    return [a.hashedPlaintextHash, a]
                })),
                j = new Map();
            b.forEach(function(a) {
                var b = i.get(a.hashedPlaintextHash);
                if (a == null) return;
                var c = y(a == null ? void 0 : a.entry, a == null ? void 0 : a.objectId, a == null ? void 0 : a.fbId);
                if (b) {
                    var e = c ? b.mediaEntries.set(a.msgId, c) : b.mediaEntries;
                    e = babelHelpers["extends"]({}, b, {
                        mediaEntries: e,
                        msgIds: d("WASortedLists").addToSet(b.msgIds, a.msgId)
                    });
                    i.set(a.hashedPlaintextHash, e)
                } else H(j, a, c)
            });
            var k = new Map(),
                l = new Map();
            h = Array.from(j.values()).filter(function(a) {
                return A(a, k, l)
            });
            return d("MAWDexieTable").dexieAll([a.media.bulkAdd(h), a.media.bulkPut(Array.from(i.values()))]).then(function() {
                return B(a, [].concat(Array.from(g.keys())), g, c, e, f)
            })
        })
    }

    function A(a, b, c) {
        if (a.objectId != null) {
            var d = b.get(a.objectId);
            if (d != null && d !== a.hashedPlaintextHash) {
                r.ERROR(j(), a.objectId, d, a.hashedPlaintextHash);
                return !1
            }
        }
        if (a.fbid != null) {
            d = c.get(a.fbid);
            if (d != null && d !== a.hashedPlaintextHash) {
                r.ERROR(i(), a.fbid, d, a.hashedPlaintextHash);
                return !1
            }
        }
        a.objectId != null && b.set(a.objectId, a.hashedPlaintextHash);
        a.fbid != null && c.set(a.fbid, a.hashedPlaintextHash);
        return !0
    }

    function B(a, b, e, f, g, h) {
        return d("MAWDbMediaTxns").maybeBulkGetMediaFromHashedPlaintextHash(a, b).then(function(b) {
            return d("MAWDexieTable").dexieAll([E(a, b, e), d("MAWMediaBackupTxns").bulkLinkMediaBackup(a, F(b, e))]).then(function() {
                if (c("justknobx")._("3060") && h === !0 && d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled()) return b;
                C(b, e, f, a, g);
                return b
            })
        })
    }

    function C(a, b, e, f, g) {
        a.forEach(function(a) {
            var h = b.get(a.hashedPlaintextHash);
            h != null && !D(h) && c("promiseDone")(d("MAWDexieCastToPromise").dexieCastToPromise(f.messages.where("msgId").anyOf(a.msgIds).toArray().then(function(b) {
                b = d("MAWBridgeTypesCreators").createBridgeMedia({
                    chatJid: e,
                    filteredMsgIds: d("MAWBridgeTypesCreators").getMsgIdsFilteredByJid(b, e),
                    hasMediaForUI: !1,
                    media: a,
                    transportKey: g
                });
                c("gkx")("2616") === !0 ? d("MAWMediaAfterTxns").handleNewMediaAfterTxnWithBridgeMedia(f, b) : d("MAWIndexedDb").afterTransaction({
                    tag: "NewMedia",
                    value: b
                })
            })))
        })
    }

    function D(a) {
        return a.reduce(function(a, b) {
            return a || b.isXMAShare
        }, !1)
    }

    function E(a, b, c) {
        b = b.reduce(function(a, b) {
            var d;
            (d = c.get(b.hashedPlaintextHash)) == null ? void 0 : d.filter(function(a) {
                return a != null && !a.isXMAShare
            }).forEach(function(c) {
                return a.set(c.msgId, b.mediaId)
            });
            return a
        }, new Map());
        return d("MAWDbMsgTxns").bulkUpdateMediaId(a, b)
    }

    function F(a, b) {
        var c = new Map();
        a.forEach(function(a) {
            var d;
            d = (d = b.get(a.hashedPlaintextHash)) != null ? d : [];
            d.forEach(function(b) {
                c.has(b.objectId) ? r.WARN(h(), b.objectId) : b.objectId != null && c.set(b.objectId, {
                    fbid: b.fbId,
                    mediaId: a.mediaId,
                    msgId: b.msgId,
                    objectId: b.objectId
                })
            })
        });
        return Array.from(c.values())
    }

    function G(a, b) {
        var c;
        a = a ? new Map([
            [b.msgId, a]
        ]) : new Map();
        return babelHelpers["extends"]({
            fbid: (c = b.fbId) != null ? c : void 0,
            hashedPlaintextHash: b.hashedPlaintextHash,
            mediaEntries: a,
            mediaType: b.mediaType,
            msgIds: d("WASortedLists").singleElement(b.msgId),
            objectId: (c = b.objectId) != null ? c : void 0,
            plaintextHash: b.plaintextHash,
            size: b.size,
            ts: d("WATimeUtils").unixTime()
        }, b.mediaInfo)
    }

    function H(a, b, c) {
        var d = a.get(b.hashedPlaintextHash);
        d == null ? a.set(b.hashedPlaintextHash, G(c, b)) : (c != null && d.mediaEntries.set(b.msgId, c), d.msgIds.push(b.msgId))
    }
    g.prepareMediaWriteData = a;
    g.handleUnstoredDbMedia = b;
    g.linkMedia = t;
    g.createOrUpdateMediaRow = u;
    g.attachHashToMediaMsg = v;
    g.updateMediaEntryWithValidatedMediaInfo = w;
    g.updateMediaWithEncodedMediaEntryData = x;
    g.attachHashAndSaveMedia = e;
    g.updateBackupFbidInMediaEntries = f;
    g.bulkLinkMedia = z;
    g.linkMessageAndMediaBackupForMediaList = B
}), 98);
__d("MAWMediaRetryInfo", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = new Map();

    function a(a, b) {
        g.set(a, b)
    }

    function b(a) {
        return g.get(a)
    }

    function c(a) {
        g.has(a) && g["delete"](a)
    }
    f.setRetriedMediaInfo = a;
    f.getRetriedMediaInfo = b;
    f.clearRetriedMediaInfo = c
}), 66);
__d("MAWUpdateMediaEntryForMsgApi", ["FBLogger", "MAWBridgeUpload", "MAWCastToMsgrServerMediaType", "MAWCastToServerMediaType", "MAWConfig", "MAWDbMediaTxns", "MAWDbMsgTxns", "MAWDexieTable", "MAWIndexedDb", "MAWMediaBackupTxns", "MAWOptimisticUploadManager", "MAWTransactionMode", "WAJids", "WALogger", "WAMediaUtils", "err", "gkx", "isInstamadilloEB"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing required arguments for media backup"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Nothing to update if updatedMediaEntry is null"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " msgId does not exist within media entries"]);
        j = function() {
            return a
        };
        return a
    }
    var k = d("MAWIndexedDb").makeMsgrTransactor({
        media: (a = d("MAWTransactionMode")).READWRITE,
        mediaBackup: a.READWRITE,
        messages: a.READONLY,
        threads: a.READONLY
    }, "updateMediaEntryForMsg", function(a) {
        return function(b, e, f, g, k) {
            var l = d("MAWCastToServerMediaType").castToServerMediaType(k);
            if (!l) {
                c("FBLogger")("labyrinth_web", "unsupported_media").mustfix("unsupported media type");
                throw c("err")("Media type unsupported: " + ((l = k) != null ? l : ""))
            }
            return d("MAWDexieTable").dexieAll([d("MAWDbMediaTxns").maybeGetMediaFromPlaintextHash(a, b), d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, e)]).then(function(b) {
                var l = b[0],
                    m = b[1];
                if (!m) throw c("err")("Message does not exist for the given protocolMsgId");
                if (!l) throw c("err")("Media does not exist for the given hashedPlaintextHash");
                if (!l.msgIds.includes(m.msgId)) {
                    d("WALogger").LOG(j(), m.msgId);
                    return
                }
                b = l.mediaEntries;
                var n = b.get(m.msgId);
                n = f(n);
                if (n == null) {
                    d("WALogger").LOG(i());
                    return
                }
                b = babelHelpers["extends"]({}, l, {
                    mediaEntries: b.set(m.msgId, n)
                });
                g != null && (b = babelHelpers["extends"]({}, b, {
                    objectId: d("WAMediaUtils").stringToDeliveryObjectId(g)
                }));
                var o = d("WAMediaUtils").decodeMediaEntryData(n);
                return a.media.put(b).then(function(b) {
                    return g != null ? d("MAWMediaBackupTxns").linkMediaBackup(a, l.mediaId, m.msgId, d("WAMediaUtils").stringToDeliveryObjectId(g)) : d("MAWDexieTable").dexieResolve()
                }).then(function() {
                    if (!c("gkx")("2453")) {
                        var a = d("MAWCastToMsgrServerMediaType").castToMsgrServerMediaType(k),
                            b = o.mediaKeyTimestamp;
                        g != null && a != null && b != null && !c("isInstamadilloEB")() ? d("MAWIndexedDb").afterTransaction({
                            tag: "UploadAttachment",
                            value: d("MAWBridgeUpload").createBridgeUploadAttachment(g, a, e.externalId, d("MAWConfig").getConfig().productTypeForEBAttachments, d("WAJids").threadIdForChatJid(e.chat), m.threadJid, b)
                        }) : d("WALogger").WARN(h())
                    }
                })
            })
        }
    });
    b = function(a, b, c, d, e) {
        l(a, c);
        return k(a, b, c, d, e)
    };

    function l(a, b) {
        var c = d("MAWOptimisticUploadManager").getOptimisticUploadManager(),
            e = c.get(a);
        if (e == null) return;
        b = b();
        if (b == null) return;
        c.set(a, babelHelpers["extends"]({}, e, {
            mediaEntry: b
        }))
    }
    g.updateMediaEntryForMsg = b
}), 98);
__d("WAGetAgeBucketForMediaKeyTimestamp", ["WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a == null) return "Missing";
        if (d("WATimeUtils").isInFuture(a)) switch (!0) {
            case d("WATimeUtils").happenedWithin(a, 1 * d("WATimeUtils").DAY_SECONDS):
                return "< 1 day in future";
            case d("WATimeUtils").happenedWithin(a, 7 * d("WATimeUtils").DAY_SECONDS):
                return "1-7 days in future";
            default:
                return "> 7 days in future"
        }
        switch (!0) {
            case d("WATimeUtils").happenedWithin(a, 1 * d("WATimeUtils").DAY_SECONDS):
                return "< 1 day";
            case d("WATimeUtils").happenedWithin(a, 7 * d("WATimeUtils").DAY_SECONDS):
                return "1-7 days";
            case d("WATimeUtils").happenedWithin(a, 14 * d("WATimeUtils").DAY_SECONDS):
                return "7-14 days";
            case d("WATimeUtils").happenedWithin(a, 21 * d("WATimeUtils").DAY_SECONDS):
                return "14-21 days";
            case d("WATimeUtils").happenedWithin(a, 30 * d("WATimeUtils").DAY_SECONDS):
                return "21-30 days";
            case d("WATimeUtils").happenedWithin(a, 40 * d("WATimeUtils").DAY_SECONDS):
                return "30-40 days";
            case d("WATimeUtils").happenedWithin(a, 50 * d("WATimeUtils").DAY_SECONDS):
                return "40-50 days";
            case d("WATimeUtils").happenedWithin(a, 60 * d("WATimeUtils").DAY_SECONDS):
                return "50-60 days";
            default:
                return "> 60 days"
        }
    }
    g.getAgeBucketForMediaKeyTimestamp = a
}), 98);
__d("WAIsMediaExpiredError", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        switch (a) {
            case "signature-expired":
                return !0;
            case "hash-mismatch":
            case "ciphertext-hash-mismatch":
            case "enc-hash-mismatch":
            case "decryption-error":
            case "max-attempts-exceeded":
            case "request-error":
            case "download-throttled":
            case "media-not-found":
            case "media-entry-invalid":
            case "no-host":
            case "backoff":
            case "body-network-error":
            case "disconnected":
            case "runtime-error":
            case "access-expired":
            case "http-fetch-exception":
            case "unspecified-http-error":
            case "server-timeout":
                return !1;
            default:
                a;
                return !0
        }
    };
    f.isMediaExpiredError = a
}), 66);
__d("WAStartMediaDownloadQplFlow", ["WAGetPlatformFromStanzaId", "WAGetStorageQplAnnotations", "WAJids", "WAMediaUtils", "WAPREList", "WAPREMetrics"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.downloadEntry,
            c = a.msgType,
            e = a.triggerUIView;
        a = a.protocolMsgId;
        var f = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.MEDIA_DOWNLOAD, {
            bool: {
                isTransformStreamSupported: d("WAMediaUtils").isTransformStreamSupported()
            },
            string: {
                chat_type: d("WAJids").switchOnMsgrChatJidType(a.chat, {
                    group: function() {
                        return "group"
                    },
                    user: function() {
                        return "user"
                    }
                }),
                downloadEntry: b,
                e2eePlatform: d("WAGetPlatformFromStanzaId").getPlatformFromStanzaId(a.externalId),
                msgType: c,
                trigger_ui_view: e
            }
        }, void 0, d("WAPREMetrics").QPL_MEDIA_DOWNLOAD_TIMEOUT_IN_MS);
        void d("WAGetStorageQplAnnotations").getStorageQplAnnotations().then(function(a) {
            f.addAnnotations(a)
        });
        return babelHelpers["extends"]({}, f, {
            downloadEntry: b,
            triggerUIView: e
        })
    }
    g.startMediaDownloadQplFlow = a
}), 98);
__d("MAWHandleEchoMediaMsgsRestoreV2", ["EchoMessage", "EchoMessageMediaFieldUtils", "MAWAsConsumerApplication", "MAWBridge", "MAWBridgeTypesCreators", "MAWCastToMsgrServerMediaType", "MAWConfig", "MAWDbChunkTxns", "MAWDbMediaTxns", "MAWDbMsg", "MAWDbMsgTxns", "MAWFrontendMediaUtils", "MAWGetMediaPlaintextApi", "MAWGetMsgForProtocolMsgIdTxn", "MAWHandleMediaDownloadApi", "MAWHandleMediaPreviewBeforeDownloadApi", "MAWHandleMediaPreviewDownloadApi", "MAWHandleMediaPreviewDownloadAsFailedApi", "MAWIndexedDb", "MAWJids", "MAWJobDefinitions", "MAWJobManager", "MAWMediaDownloadStatus", "MAWMediaDownloadStatusForUI", "MAWMediaGalleryM2Utils", "MAWMediaManagementTxns", "MAWMediaRetryInfo", "MAWMediaUtils", "MAWSupportedDocumentTypes", "MAWTransactionMode", "MAWUpdateMediaEntryForMsgApi", "Promise", "WAAPI", "WAArmadilloXMA.pb", "WABase64", "WAGetAgeBucketForMediaKeyTimestamp", "WAGetStorageQplAnnotations", "WAGlobals", "WAHashUtils", "WAIsMediaExpiredError", "WAJids", "WAJobOrchestratorTypes", "WALogger", "WAMediaUtils", "WAStartMediaDownloadQplFlow", "WATagsLogger", "WATimeUtils", "asyncToGeneratorRuntime", "cr:10071", "gkx", "justknobx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["resign cdn url start [sproc]. hash: ", ". msgId: ", ". traceId: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["resign cdn url gql error: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["resign cdn url gql success. hash: ", ". externalId ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["resign cdn url gql failed: ", ". hash: ", ". externalId ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["resign cdn url start [gql]. hash: ", ". msgId: ", ". traceId: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["start restore media from backup. hash: ", ". msgId: ", ". traceId: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Skipping media restore for expirable XMA. externalId ", ". xmamessageType: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot find the media entry for message with mediaKey ", ", msg id: ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot find the media entry for message with mediaKey ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] media for message: ", " is already downloaded on the device"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Unable to construct downloadableThumbnail from previewMediaData: ", ", msg id: ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Encrypted hash cannot be null for non-XMA attachments, msg id: ", ""]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot download media - document extension is disallowed, msg id: ", ""]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot download media - media content type null, msg id: ", ""]);
        v = function() {
            return a
        };
        return a
    }

    function w() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] media entry is missing from index db. It is required to retry download by resigning cdn url: externalId: ", ". traceId: ", ""]);
        w = function() {
            return a
        };
        return a
    }

    function x() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["start resign cdn url through sproc"]);
        x = function() {
            return a
        };
        return a
    }

    function y() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] media download failed with error: ", " ", " when downloading. Message timestamp: ", ". traceId: ", ""]);
        y = function() {
            return a
        };
        return a
    }

    function z() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Retry download media as signature has expired and should be renewed. externalId ", ". traceId: ", ""]);
        z = function() {
            return a
        };
        return a
    }

    function A() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] media download complete. externalId ", ". traceId: ", ""]);
        A = function() {
            return a
        };
        return a
    }

    function B() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] downloading media from MI directly. externalId ", "."]);
        B = function() {
            return a
        };
        return a
    }

    function C() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] start media download from whatsapp infra. traceId: ", ""]);
        C = function() {
            return a
        };
        return a
    }

    function D() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Encrypted hash is null - unable to download thumbnail"]);
        D = function() {
            return a
        };
        return a
    }

    function E(a) {
        var c = I(a);
        return c.then(function(c) {
            var d = new Map();
            a.forEach(function(a) {
                var b = c.get(a);
                b = b == null ? void 0 : b.blobData;
                d.set(a, b)
            });
            return (h || (h = b("Promise"))).resolve(d)
        })
    }

    function F(a) {
        switch (a) {
            case d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.IMAGE_JPEG:
                return "image/jpeg";
            case d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.IMAGE_PNG:
                return "image/png";
            case d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.STICKER:
                return "image/webp";
            case d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.GIF:
                return "image/gif";
            case d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.AUDIO_MP4:
                return "audio/mp4";
            case d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.AUDIO_WAV:
                return "audio/wav";
            case d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.XMA:
                return "xma"
        }
    }

    function a(a, b, c) {
        return G.apply(this, arguments)
    }

    function G() {
        G = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f) {
            if (a.length === 0) return (h || (h = b("Promise"))).resolve();
            var g = [],
                i = [],
                j = new Map(),
                k = new Map();
            a.map(function(a) {
                var c = a.mediaData,
                    e = a.messageTimestamp,
                    f = K(c.plaintextHash),
                    l = c.attachmentObjectId,
                    m = c.attachmentType,
                    n = c.backupEntFbid,
                    o = c.directPath,
                    p = c.filename,
                    q = c.height,
                    r = c.mediaContentType,
                    w = c.mediaKeyTimestamp,
                    x = c.mediaPlayableDuration,
                    y = c.previewContentHeight,
                    z = c.previewContentType,
                    A = c.previewContentWidth,
                    B = c.size;
                c = c.width;
                var C = d("WAHashUtils").stringToPlaintextHash(f),
                    D = d("MAWMediaUtils").genHMACPlaintextHash(C);
                i.push(D);
                r = r != null ? d("MAWFrontendMediaUtils").getMediaTypeAndServerMediaTypeFromBlob(r, a.isXMA) : z != null ? d("MAWFrontendMediaUtils").getMediaTypeAndServerMediaTypeFromBlob(F(z)) : null;
                if (r == null) {
                    d("WALogger").ERROR(v(), a.externalId);
                    return (h || (h = b("Promise"))).resolve()
                }
                if (m === d("EchoMessageMediaFieldUtils").AttachmentType.DOCUMENT && !d("MAWSupportedDocumentTypes").isAllowedType(p)) {
                    d("WALogger").LOG(u(), a.externalId);
                    return (h || (h = b("Promise"))).resolve()
                }
                z = a.mediaData.encryptedHash;
                if (z == null && !a.isXMA) {
                    d("WALogger").ERROR(t(), a.externalId);
                    return (h || (h = b("Promise"))).resolve()
                }
                m = r.mediaType;
                r = r.serverMediaType;
                l = d("WAMediaUtils").stringToDeliveryObjectId(l);
                n = n != null ? d("WAMediaUtils").stringToBackupEntFbid(n) : void 0;
                var E = a.threadJId,
                    G = L({
                        filename: p,
                        height: q,
                        mediaPlayableDuration: x,
                        mediaType: m,
                        previewContentHeight: y,
                        previewContentWidth: A,
                        width: c
                    });
                k.set(l, {
                    filename: p,
                    height: q,
                    mediaPlayableDuration: x,
                    mediaType: m,
                    messageTimestamp: e,
                    plaintextHash: C,
                    previewContentHeight: y,
                    previewContentWidth: A,
                    serverMediaType: r,
                    threadJId: E,
                    width: c
                });
                q = null;
                if (a.previewMediaData != null) try {
                    q = N(a.previewMediaData)
                } catch (b) {
                    d("WALogger").ERROR(s(), b, a.externalId)
                }
                if (z != null) {
                    x = M(f, z, a.mediaData.mediaKey, o, w, r, p, n, l, q, B);
                    g.push({
                        entry: x,
                        fbId: n,
                        hashedPlaintextHash: D,
                        isXMAShare: a.isXMA,
                        mediaInfo: G,
                        mediaType: m,
                        msgId: a.msgId,
                        objectId: l,
                        plaintextHash: C,
                        size: (e = B) != null ? e : 0
                    })
                }
                A = (y = j.get(D)) != null ? y : [];
                A.push(a);
                j.set(D, A)
            });
            var l = (yield H(g, e, f));
            a = (yield E(i));
            var m = [];
            a.forEach(function(a, b) {
                var h = j.get(b);
                h == null ? void 0 : h.forEach(function(h) {
                    if (h == null) return;
                    if (a != null) {
                        d("WALogger").LOG(r(), h.externalId);
                        var i = l.find(function(a) {
                            return a.plaintextHash === h.mediaData.plaintextHash
                        });
                        if (i == null) {
                            d("WALogger").LOG(q(), h.mediaData.mediaKey);
                            return
                        }
                        return J(i.msgIds).then(function(a) {
                            if (c("gkx")("5301")) {
                                var b = a.filter(function(a) {
                                    return d("MAWDbMsg").isMediaMsg(a)
                                });
                                if (b.length > 0) {
                                    var f = d("MAWBridgeTypesCreators").createBridgeMedia({
                                        chatJid: h.threadJId,
                                        filteredMsgIds: d("MAWBridgeTypesCreators").getMsgIdsFilteredByJid(b, e),
                                        hasMediaForUI: !0,
                                        media: i,
                                        transportKey: "EncryptedBackups"
                                    });
                                    c("justknobx")._("1254") && d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled({
                                        isSilent: !0
                                    }) ? b = d("MAWMediaUtils").annotateBridgeMediaForDisplay(f, b) : b = f;
                                    d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
                                        events: [{
                                            tag: "NewMedia",
                                            value: b
                                        }]
                                    })
                                }
                            } else d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
                                events: [{
                                    tag: "NewMedia",
                                    value: d("MAWBridgeTypesCreators").createBridgeMedia({
                                        chatJid: h.threadJId,
                                        filteredMsgIds: d("MAWBridgeTypesCreators").getMsgIdsFilteredByJid(a, e),
                                        hasMediaForUI: !0,
                                        media: i,
                                        transportKey: "EncryptedBackups"
                                    })
                                }]
                            })
                        })
                    }
                    var j = k.get(d("WAMediaUtils").stringToDeliveryObjectId(h.mediaData.attachmentObjectId));
                    if (h == null || j == null) return;
                    var n = j.filename,
                        o = j.height,
                        s = j.mediaPlayableDuration,
                        t = j.mediaType,
                        u = j.messageTimestamp,
                        v = j.plaintextHash,
                        w = j.previewContentHeight,
                        x = j.previewContentWidth,
                        y = j.serverMediaType,
                        z = j.threadJId;
                    j = j.width;
                    var A = d("WAJids").extractUserId(d("MAWJids").toUserJid(h.threadJId));
                    y = d("MAWCastToMsgrServerMediaType").castToMsgrServerMediaType(y, h.isXMA);
                    if (y != null) {
                        y = {
                            attachmentObjectId: d("WAMediaUtils").stringToDeliveryObjectId(h.mediaData.attachmentObjectId),
                            mediaType: y,
                            messageId: h.externalId,
                            messageTimeStamp: h.messageTimestamp,
                            msgId: h.msgId,
                            plaintextHash: v,
                            productType: d("MAWConfig").getConfig().productTypeForEBAttachments,
                            threadId: A,
                            threadJid: z
                        };
                        A = g.find(function(a) {
                            return a.hashedPlaintextHash === b
                        });
                        A = A == null ? void 0 : A.entry;
                        if (A == null) {
                            d("WALogger").ERROR(p(), h.mediaData.mediaKey, h.externalId);
                            return
                        }
                        if (f === !0 && c("qex")._("1483") === !0) return;
                        var B = d("WAStartMediaDownloadQplFlow").startMediaDownloadQplFlow({
                            downloadEntry: "downloadMediaAndWriteToMediaStore",
                            msgType: null,
                            protocolMsgId: {
                                author: h.author,
                                chat: h.threadJId,
                                externalId: h.externalId
                            },
                            triggerUIView: null
                        });
                        m.push(O({
                            author: h.author,
                            directPath: h.mediaData.directPath,
                            echoMsg: h.echoMsg,
                            externalId: h.externalId,
                            filename: n,
                            hashedPlaintextHash: b,
                            height: o,
                            isXMA: h.isXMA,
                            mediaPlayableDuration: s,
                            mediaType: t,
                            messageTimestamp: u,
                            plaintextHash: v,
                            previewContentHeight: w,
                            previewContentWidth: x,
                            threadJId: z,
                            width: j
                        }, void 0, y, void 0, d("WAMediaUtils").decodeMediaEntryData(A), B))
                    }
                })
            });
            yield(h || (h = b("Promise"))).all(m)
        });
        return G.apply(this, arguments)
    }
    var H = (e = d("MAWIndexedDb")).makeMsgrTransactor({
            media: (f = d("MAWTransactionMode")).READWRITE,
            mediaBackup: f.READWRITE,
            messages: f.READWRITE
        }, "restoreLinkMedias", function(a) {
            return function(b, c, e) {
                return d("MAWMediaManagementTxns").bulkLinkMedia(a, b, c, "EncryptedBackups", e)
            }
        }),
        I = e.makeMsgrTransactor({
            chunk: f.READONLY
        }, "getChunksByHash", function(a) {
            return function(b) {
                return d("MAWDbChunkTxns").maybeBulkGetChunksFromHash(a, b)
            }
        }),
        J = e.makeMsgrTransactor({
            messages: f.READONLY
        }, "getMessagesForMsgIds", function(a) {
            return function(b) {
                return a.messages.where("msgId").anyOf(b).toArray()
            }
        });

    function K(a) {
        if (a.endsWith("=")) {
            var b = "";
            for (var c = 0; c < a.length; c++) {
                var d = a.charAt(c);
                if (d === "=") return b;
                b += d
            }
        }
        return a
    }

    function L(a) {
        var b = a.height,
            c = a.mediaType,
            e = a.width,
            f = a.previewContentHeight,
            g = a.previewContentWidth,
            h = a.mediaPlayableDuration;
        a = a.filename;
        return {
            validatedAudioInfo: c === "Ptt" && h != null ? {
                duration: R(h),
                mimetype: d("MAWAsConsumerApplication").AUDIO_WAV_MIME_TYPE,
                played: !1
            } : null,
            validatedDocumentFileInfo: c === "DocumentFile" ? {
                filename: a,
                mimetype: d("MAWAsConsumerApplication").FILE_MIME_TYPE
            } : null,
            validatedImageInfo: c === "Image" ? {
                height: b,
                jpegThumbnailHeight: f,
                jpegThumbnailWidth: g,
                width: e
            } : c === "Gif" || c === "Sticker" ? {
                height: b,
                jpegThumbnailHeight: b,
                jpegThumbnailWidth: e,
                width: e
            } : null,
            validatedVideoInfo: c === "Video" ? {
                duration: h,
                height: b,
                jpegThumbnailHeight: f,
                jpegThumbnailWidth: g,
                mimetype: d("MAWAsConsumerApplication").VIDEO_MIME_TYPE,
                width: e
            } : null
        }
    }

    function M(a, b, c, e, f, g, h, i, j, k, l) {
        a = d("WABase64").decodeB64UrlSafe(a, !0);
        b = d("WABase64").decodeB64UrlSafe(b, !0);
        c = c != null ? d("WABase64").decodeB64UrlSafe(c, !0) : void 0;
        return d("WAMediaUtils").rawDataToMediaEntry({
            directPath: e,
            downloadableThumbnail: k != null ? k : void 0,
            fbid: i != null ? i : void 0,
            fileEncSha256: b,
            filename: h,
            fileSha256: a,
            mediaKey: c,
            mediaKeyTimestamp: f != null ? d("WATimeUtils").castToUnixTime(f) : void 0,
            objectId: j != null ? j : void 0,
            serverMediaType: g,
            size: l != null ? l : void 0
        })
    }

    function N(a) {
        var b = a.attachmentObjectId,
            c = a.directPath,
            e = a.encryptedHash,
            f = a.mediaKey,
            g = a.mediaKeyTimestamp;
        a = a.plaintextHash;
        if (e == null) {
            d("WALogger").ERROR(D());
            return
        } else {
            g = g != null ? d("WATimeUtils").castToUnixTime(g) : void 0;
            f = f != null ? d("WAMediaUtils").castToMediaKey(d("WABase64").decodeB64UrlSafe(f, !0)) : void 0;
            a = d("WABase64").decodeB64UrlSafe(a, !0);
            e = d("WABase64").decodeB64UrlSafe(e, !0);
            return {
                directPath: c,
                fileEncSha256: e,
                fileSha256: a,
                mediaKey: f,
                mediaKeyTimestamp: g,
                objectId: b
            }
        }
    }
    var O = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e, f, g, h) {
                d("WALogger").LOG(C(), b);
                var i = a.author,
                    j = a.externalId,
                    k = a.filename,
                    l = a.hashedPlaintextHash,
                    m = a.height,
                    n = a.mediaPlayableDuration,
                    o = a.mediaType,
                    p = a.messageTimestamp,
                    q = a.plaintextHash,
                    r = a.previewContentHeight,
                    s = a.previewContentWidth,
                    t = a.threadJId,
                    u = a.width;
                i = {
                    author: i,
                    chat: t,
                    externalId: j
                };
                var v = (t = h) != null ? t : d("WAStartMediaDownloadQplFlow").startMediaDownloadQplFlow({
                    downloadEntry: "handleEchoMediaMsgsRestore",
                    msgType: null,
                    protocolMsgId: i,
                    triggerUIView: null
                });
                d("MAWMediaDownloadStatusForUI").sendMediaDownloadStatusToUI({
                    details: "handle_echo_media_msgs_restore",
                    hash: q,
                    status: c("MAWMediaDownloadStatus").DOWNLOADING,
                    type: "main"
                });
                t = ((t = (h = d("MAWMediaRetryInfo").getRetriedMediaInfo(j)) == null ? void 0 : h.isXMA) != null ? t : !1) || ((h = a == null ? void 0 : a.isXMA) != null ? h : !1);
                h = ((h = d("MAWMediaRetryInfo").getRetriedMediaInfo(j)) == null ? void 0 : (h = h.echoMsg) == null ? void 0 : h.serializationOrigin) || (a == null ? void 0 : (h = a.echoMsg) == null ? void 0 : h.serializationOrigin) || d("EchoMessage").EchoSerializationOriginType.UNKNOWN;
                var w = c("gkx")("23960");
                v.addPoint("download_media_start", {
                    bool: {
                        isEBDownloadEnforced: e == null && w,
                        isRetryFromMI: e == null,
                        isXMA: t,
                        pathMismatch: f !== g.directPath
                    },
                    "int": {
                        mediaEntrySize: g.size
                    },
                    string: {
                        oldDirectPath: (t = a == null ? void 0 : a.oldDirectPath) != null ? t : "",
                        origin: h,
                        restorationCdnUrl: (t = f) != null ? t : ""
                    }
                });
                void d("WAGetStorageQplAnnotations").getStorageQplAnnotations().then(function(a) {
                    v.addAnnotations(a)
                });
                if (e != null && w) {
                    d("WALogger").LOG(B(), i.externalId);
                    return T({
                        decodedMediaEntry: g,
                        isEBDownloadEnforced: w,
                        mediaDownloadRequest: a,
                        protocolMsgId: i,
                        retryPayload: e
                    })
                }
                h = d("WAGlobals").getConfig().uiLayoutTriggeredMediaDownload() ? yield c("WAAPI").cachedDownloadFullMediaOnly({
                    downloadMediaMetric: v,
                    getMediaPlaintext: d("MAWGetMediaPlaintextApi").getMediaPlaintext,
                    hash: q,
                    mediaEntry: g,
                    protocolMsgId: i,
                    updateMediaEntryForMsg: d("MAWUpdateMediaEntryForMsgApi").updateMediaEntryForMsg
                }): yield c("WAAPI").downloadMedia({
                    downloadMediaMetric: v,
                    getMediaPlaintext: d("MAWGetMediaPlaintextApi").getMediaPlaintext,
                    handleMediaPreviewBeforeDownload: d("MAWHandleMediaPreviewBeforeDownloadApi").handleMediaPreviewBeforeDownload,
                    handleMediaPreviewDownload: d("MAWHandleMediaPreviewDownloadApi").handleMediaPreviewDownload,
                    handleMediaPreviewDownloadFailed: d("MAWHandleMediaPreviewDownloadAsFailedApi").handleMediaPreviewDownloadFailed,
                    hash: q,
                    mediaEntry: g,
                    protocolMsgId: i,
                    updateMediaEntryForMsg: d("MAWUpdateMediaEntryForMsgApi").updateMediaEntryForMsg
                });
                if (h.success) {
                    v.addPoint("download_media_end");
                    t = h.value;
                    w = t.mimeType;
                    t = t.plaintext;
                    yield d("MAWHandleMediaDownloadApi").handleMediaDownload(q, w, t, i);
                    d("MAWMediaRetryInfo").clearRetriedMediaInfo(j);
                    w = L({
                        filename: k,
                        height: m,
                        mediaPlayableDuration: n,
                        mediaType: o,
                        previewContentHeight: r,
                        previewContentWidth: s,
                        width: u
                    });
                    yield Q(l, w);
                    d("WALogger").LOG(A(), i.externalId, b);
                    v.endSuccess();
                    d("MAWMediaDownloadStatusForUI").sendMediaDownloadStatusToUI({
                        details: "handle_echo_media_msgs_restore_success",
                        hash: q,
                        status: c("MAWMediaDownloadStatus").SUCCESS,
                        type: "main"
                    })
                } else {
                    v.endFail("download_media_fail");
                    t = h.error;
                    if (d("WAIsMediaExpiredError").isMediaExpiredError(t) && e) v.addPoint("eb_resign_requested"), v.endSuccess(), d("WALogger").WARN(z(), i.externalId, b), yield T({
                        decodedMediaEntry: g,
                        isEBDownloadEnforced: !1,
                        mediaDownloadRequest: a,
                        protocolMsgId: i,
                        retryPayload: e
                    });
                    else {
                        d("WALogger").ERROR(y(), j, t, p, b);
                        v.endFail(t);
                        m = {
                            string: {
                                directPath: g.directPath,
                                error: "media_download_failure",
                                restorationCdnUrl: (k = f) != null ? k : ""
                            }
                        };
                        v.endFail("media_download_failure", m);
                        d("MAWMediaRetryInfo").clearRetriedMediaInfo(j);
                        d("MAWMediaDownloadStatusForUI").sendMediaDownloadStatusToUI({
                            details: t,
                            hash: q,
                            status: d("MAWMediaDownloadStatusForUI").getStatusFromWAAPIDownloadMediaError(t),
                            type: "main"
                        })
                    }
                }
            });
            return function(b, c, d, e, f, g) {
                return a.apply(this, arguments)
            }
        }(),
        P = e.makeMsgrTransactor({
            media: f.READONLY,
            mediaBackup: f.READONLY,
            messages: f.READONLY
        }, "invokeRestoreAccessCheckSprocToDownloadAttachment", function(a) {
            return function(b, e, f) {
                var g = d("WAMediaUtils").stringToDeliveryObjectId(e.attachmentObjectId);
                g = c("gkx")("4663") ? d("MAWDbMediaTxns").maybeGetMediaFromPlaintextHash(a, e.plaintextHash) : d("MAWDbMediaTxns").maybeGetMediaFromObjectId(a, g);
                return g.then(function(c) {
                    if (c) {
                        d("WATagsLogger").TAGS(["labyrinth_web", "media_restore", "" + f.getFlowDetails().instanceKey]).LOG(x());
                        var g = V(c, e.attachmentObjectId);
                        return d("MAWDbMsgTxns").getMsgsByMsgIds(a, g).then(function(a) {
                            var g, h = a.find(function(a) {
                                return a.externalId === b
                            });
                            f.addPoint("resign_cdn_url_bridge_call", {
                                bool: {
                                    isForwarded: (g = h == null ? void 0 : h.isForwarded) != null ? g : !1
                                },
                                "int": {
                                    duplicateMsgsCount: a.length,
                                    msgXMAType: h == null ? void 0 : h.xmaMessageType,
                                    totalMediaEntries: c.mediaEntries.size
                                },
                                int_array: {
                                    duplicateXMATypes: a.map(function(a) {
                                        return (a = a.xmaMessageType) != null ? a : 0
                                    })
                                },
                                string: {
                                    msgType: h == null ? void 0 : h.type
                                },
                                string_array: {
                                    duplicateMsgs: a.map(function(a) {
                                        return a.externalId
                                    }),
                                    duplicateMsgTypes: a.map(function(a) {
                                        return a.type
                                    })
                                }
                            });
                            d("MAWIndexedDb").afterTransaction({
                                tag: "ResignAttachmentCDNUrl",
                                value: {
                                    deliveryObjectId: e.attachmentObjectId,
                                    mediaType: e.mediaType,
                                    messageId: b,
                                    msgId: e.msgId,
                                    plaintextHash: e.plaintextHash,
                                    productType: d("MAWConfig").getConfig().productTypeForEBAttachments,
                                    sortOrder: e.messageTimeStamp,
                                    threadId: e.threadId,
                                    threadJid: e.threadJid,
                                    traceId: f.getFlowDetails().instanceKey
                                }
                            })
                        })
                    } else d("WALogger").ERROR(w(), b, f.getFlowDetails().instanceKey), f.endFail("missing-media")
                })
            }
        }),
        Q = e.makeMsgrTransactor({
            media: f.READWRITE,
            messages: f.READWRITE
        }, "updateMediaWithDownloadedChunkBlob", function(a) {
            return function(b, c) {
                return d("MAWMediaManagementTxns").updateMediaEntryWithValidatedMediaInfo(a, b, c)
            }
        });

    function R(a) {
        var b = Math.floor(a / 1e3);
        if (b > 0) return b;
        else return a
    }

    function S(a) {
        return a == null ? !1 : a === d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_REPLY || a === d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_MENTION
    }

    function T(a) {
        return U.apply(this, arguments)
    }

    function U() {
        U = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var c = a.decodedMediaEntry,
                e = a.isEBDownloadEnforced,
                f = a.mediaDownloadRequest,
                g = a.protocolMsgId,
                p = a.retryPayload;
            a = (yield d("MAWGetMsgForProtocolMsgIdTxn").getMsgForProtocolMsgIdTxn(g));
            if (a.success === !0 && S(a.value.xmaMessageType)) {
                d("WALogger").LOG(o(), g.externalId, a.value.xmaMessageType);
                return (h || (h = b("Promise"))).resolve()
            }
            var q = g.externalId;
            d("MAWMediaRetryInfo").setRetriedMediaInfo(g.externalId, f);
            f = ((a = c.mediaKeyTimestamp) != null ? a : 0) > 1725105600;
            a = {
                bool: {
                    is_after_S441705_fix: f,
                    isEBDownloadEnforced: e
                },
                "int": {
                    mediaKeyTimestamp: c.mediaKeyTimestamp
                },
                string: {
                    externalId: q,
                    mediaKeyAge: d("WAGetAgeBucketForMediaKeyTimestamp").getAgeBucketForMediaKeyTimestamp(c.mediaKeyTimestamp),
                    mediaType: p.mediaType,
                    objectId: p.attachmentObjectId,
                    restoreEntry: "EB",
                    restoreMethod: b("cr:10071") == null ? "sproc" : "gql"
                }
            };
            var r = d("WAStartMediaDownloadQplFlow").startMediaDownloadQplFlow({
                downloadEntry: "restoreMediaFromBackup",
                msgType: null,
                protocolMsgId: g,
                triggerUIView: null
            });
            r.addAnnotations(a);
            d("WALogger").LOG(n(), d("WAHashUtils").sanitisePlaintextHash(p.plaintextHash), q, r.getFlowDetails().instanceKey);
            if (b("cr:10071") != null) {
                d("WALogger").LOG(m(), d("WAHashUtils").sanitisePlaintextHash(p.plaintextHash), q, r.getFlowDetails().instanceKey);
                return b("cr:10071").eblsResignCdnUrlWithGraphQL({
                    chatJid: g.chat,
                    deliveryObjectId: p.attachmentObjectId,
                    externalId: q,
                    mediaType: p.mediaType,
                    sortOrderMs: p.messageTimeStamp
                }).then(function(a) {
                    if (a.success === !1) {
                        d("WALogger").LOG(l(), a.error, d("WAHashUtils").sanitisePlaintextHash(p.plaintextHash), q);
                        r.endFail(a.error);
                        return
                    }
                    d("WALogger").LOG(k(), d("WAHashUtils").sanitisePlaintextHash(p.plaintextHash), q);
                    a = d("MAWJobDefinitions").createStartJobInfo("downloadAndRestoreMedia", {
                        deliveryObjectId: p.attachmentObjectId,
                        msgId: p.msgId,
                        plaintextHash: p.plaintextHash,
                        restorationCdnUrl: a.value,
                        scheduleConfig: {
                            priority: d("WAJobOrchestratorTypes").JOB_PRIORITY.LOW
                        },
                        traceId: r.getFlowDetails().instanceKey
                    });
                    return d("MAWJobManager").getJobManager().fireAndForget(a)
                })["catch"](function(a) {
                    d("WALogger").ERROR(j(), a), r.endFail("runtime-error", {
                        string: {
                            restoreError: a.toString()
                        }
                    })
                })
            }
            d("WALogger").LOG(i(), d("WAHashUtils").sanitisePlaintextHash(p.plaintextHash), q, r.getFlowDetails().instanceKey);
            return P(q, p, r)
        });
        return U.apply(this, arguments)
    }

    function V(a, b) {
        var c = [];
        (a = a.mediaEntries) == null ? void 0 : a.forEach(function(a, e) {
            a = d("WAMediaUtils").decodeMediaEntryData(a);
            a.objectId === b && c.push(e)
        });
        return c
    }
    g.downloadMediaAndWriteToMediaStore = a;
    g.getBase64WithoutPadding = K;
    g.getMediaInfo = L;
    g.constructMediaEntry = M;
    g.constructRawDownloadableThumbnail = N;
    g.handleDownloadMedia = O;
    g.invokeRestoreAccessCheckSprocToDownloadAttachment = P
}), 98);
__d("MAWHandleEchoMsgsRestoreApiUtils", ["$InternalEnum", "EchoMessage", "EchoMessageMediaFieldUtils", "MAWAckLevel", "MAWConvertXMATargetTypeToExtendedContentTargetType", "MAWEBRestoreTrackingUtils", "MAWJids", "MAWMsgType", "MAWRepliesRestoreUtils", "WAJids", "WAStanzaUtils", "WATagsLogger", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Message content is empty for the message: ", ", type: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Author info is missing from msg: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] thread has unsupported message type: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] thread has unsupported message content type: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] thread has unsupported message content type: ", ", xContentType: ", ",\n      subcontent type: ", " ,\n      origin: ", ""]);
        l = function() {
            return a
        };
        return a
    }
    c = b("$InternalEnum")({
        INITIAL_RESTORE: "initial_restore",
        POINT_RESTORE: "point_restore",
        PAGINATED_RESTORE: "paginated_restore"
    });

    function m(a, b) {
        var c, e = a.contentType;
        switch (e) {
            case d("EchoMessage").EchoMessageContentType.TEXT:
                return a.xContentType === d("EchoMessage").EchoXMessageContentType.BUMP ? d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE : d("MAWMsgType").MSG_TYPE.TEXT;
            case d("EchoMessage").EchoMessageContentType.MEDIA:
                return a.receiverFetchId != null && a.receiverFetchData != null ? d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH : n(a);
            case d("EchoMessage").EchoMessageContentType.PLACEHOLDER:
                if (a.contentSubtype === d("EchoMessage").EchoMessageContentSubtype.UNSEND) return d("MAWMsgType").MSG_TYPE.REVOKED;
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (c = b) != null ? c : ""]).ERROR(l(), d("EchoMessage").EchoMessageContentType.getName(e), a.xContentType != null ? d("EchoMessage").EchoXMessageContentType.getName(a.xContentType) : "unknown", d("EchoMessage").EchoMessageContentSubtype.getName(a.contentSubtype), a.serializationOrigin != null ? d("EchoMessage").EchoSerializationOriginType.getName(a.serializationOrigin) : "unknown");
                break;
            case d("EchoMessage").EchoMessageContentType.XMA:
                return d("MAWMsgType").MSG_TYPE.XMA;
            case d("EchoMessage").EchoMessageContentType.DECRYPTION_FAILURE:
                return d("MAWMsgType").MSG_TYPE.CIPHERTEXT;
            default:
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (c = b) != null ? c : ""]).ERROR(k(), d("EchoMessage").EchoMessageContentType.getName(e))
        }
        return null
    }

    function n(a, b) {
        a = a.mediaData;
        if (a != null) {
            switch (a.attachmentType) {
                case d("EchoMessageMediaFieldUtils").AttachmentType.IMAGE:
                    return d("MAWMsgType").MSG_TYPE.IMAGE;
                case d("EchoMessageMediaFieldUtils").AttachmentType.STICKER:
                    return d("MAWMsgType").MSG_TYPE.STICKER;
                case d("EchoMessageMediaFieldUtils").AttachmentType.VIDEO:
                    return d("MAWMsgType").MSG_TYPE.VIDEO;
                case d("EchoMessageMediaFieldUtils").AttachmentType.GIF:
                    return d("MAWMsgType").MSG_TYPE.GIF;
                case d("EchoMessageMediaFieldUtils").AttachmentType.PTT:
                    return d("MAWMsgType").MSG_TYPE.PTT;
                case d("EchoMessageMediaFieldUtils").AttachmentType.XMA:
                    return d("MAWMsgType").MSG_TYPE.XMA;
                case d("EchoMessageMediaFieldUtils").AttachmentType.DOCUMENT:
                    return d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE
            }
            d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (b = b) != null ? b : ""]).ERROR(j(), d("EchoMessageMediaFieldUtils").AttachmentType.getName(a.attachmentType))
        }
        return null
    }

    function a(a, b, c, e, f, g) {
        var h = a.from;
        if (h == null) {
            var j;
            d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (j = f) != null ? j : ""]).ERROR(i(), e);
            return null
        }
        j = m(a, f);
        if (j == null || a.isTombstoned != null && a.isTombstoned) return null;
        switch (j) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
                return u(a, b, c, h, j, e, f, g);
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                return o(a, b, c, h, j, e);
            case d("MAWMsgType").MSG_TYPE.XMA:
                return q(a, b, c, h, j, e);
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                return x(a, b, c, h, j, e);
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return r(a, b, c, h, j, e)
        }
        return null
    }

    function o(a, b, c, d, e, f) {
        a = v(a, b, c, d, e, f);
        return p(e, a)
    }

    function p(a, b) {
        switch (a) {
            case d("MAWMsgType").MSG_TYPE.IMAGE:
                return babelHelpers["extends"]({}, b, {
                    type: d("MAWMsgType").MSG_TYPE.IMAGE
                });
            case d("MAWMsgType").MSG_TYPE.STICKER:
                return babelHelpers["extends"]({}, b, {
                    type: d("MAWMsgType").MSG_TYPE.STICKER
                });
            case d("MAWMsgType").MSG_TYPE.VIDEO:
                return babelHelpers["extends"]({}, b, {
                    type: d("MAWMsgType").MSG_TYPE.VIDEO
                });
            case d("MAWMsgType").MSG_TYPE.GIF:
                return babelHelpers["extends"]({}, b, {
                    type: d("MAWMsgType").MSG_TYPE.GIF
                });
            case d("MAWMsgType").MSG_TYPE.PTT:
                return babelHelpers["extends"]({}, b, {
                    type: d("MAWMsgType").MSG_TYPE.PTT
                });
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                return babelHelpers["extends"]({}, b, {
                    type: d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE
                })
        }
    }

    function q(a, b, c, e, f, g) {
        b = v(a, b, c, e, f, g);
        c = a.text;
        if (a.xmaData != null && a.xmaData.xmaTargetType != null) {
            e = babelHelpers["extends"]({}, b, {
                type: d("MAWMsgType").MSG_TYPE.XMA,
                xmaMessageType: d("MAWConvertXMATargetTypeToExtendedContentTargetType").convertXMATargetTypeToExtendedContentTargetType(a.xmaData.xmaTargetType)
            });
            c != null && (e.msgContent = {
                content: c
            });
            return e
        }
        return null
    }

    function r(a, b, c, e, f, g) {
        b = v(a, b, c, e, f, g);
        if (a.receiverFetchData != null) {
            c = babelHelpers["extends"]({}, b, {
                receiverFetchId: a.receiverFetchId,
                type: d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH
            });
            return c
        }
        return null
    }

    function s(a) {
        if (a == null) return void 0;
        else switch (a) {
            case d("EchoMessage").MessageTextSize.SMALL:
                return 1;
            case d("EchoMessage").MessageTextSize.MEDIUM:
                return 2;
            case d("EchoMessage").MessageTextSize.LARGE:
                return 3;
            default:
                return void 0
        }
    }

    function t(a) {
        if (a.text == null) return null;
        return a.editHistory.length === 0 ? a.text : a.editHistory.sort(function(a, b) {
            return a.timestamp - b.timestamp
        })[0].text
    }

    function u(a, b, c, e, f, g, i, j) {
        j = j === "first_edit_content" ? t(a) : a.text;
        if (j == null) {
            var k;
            d("MAWEBRestoreTrackingUtils").addQPLRestorePointWithAnnotationsWorker({
                annotations: {
                    string: {
                        empty_content_msg_type: f
                    }
                },
                pointName: "unstored_text_message_empty",
                traceId: i
            });
            d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (k = i) != null ? k : ""]).ERROR(h(), g, f);
            return null
        }
        k = v(a, b, c, e, f, g, i);
        if (f === d("MAWMsgType").MSG_TYPE.REVOKED) {
            j != null && (k.msgContent = {
                content: j
            });
            a.revokeSentTimestampMs != null && (k.originalTs = d("WATimeUtils").castToUnixTime(a.revokeSentTimestampMs));
            return babelHelpers["extends"]({}, k, {
                revokedExternalId: d("WAStanzaUtils").toStanzaId("0"),
                type: d("MAWMsgType").MSG_TYPE.REVOKED,
                unsendMsgContentDeleteTs: a.revokeUnsentTimestampMS != null ? d("WATimeUtils").castToUnixTime(a.revokeUnsentTimestampMS) : k.ts
            })
        } else if (f === d("MAWMsgType").MSG_TYPE.CIPHERTEXT) return babelHelpers["extends"]({}, k, {
            msgContent: {
                content: j
            },
            specialTextSize: s(a.textSize),
            type: d("MAWMsgType").MSG_TYPE.CIPHERTEXT
        });
        else {
            b = babelHelpers["extends"]({}, k, {
                msgContent: {
                    content: j
                },
                specialTextSize: s(a.textSize),
                type: d("MAWMsgType").MSG_TYPE.TEXT
            });
            return babelHelpers["extends"]({}, b, {
                editCount: Math.max(a.editHistory.length - 1, 0),
                groupId: a.groupId,
                groupIndex: a.groupIndex,
                groupSize: a.groupSize
            })
        }
    }

    function v(a, b, c, e, f, g, h) {
        h = w(e, c);
        e = {
            ack: h === d("WAJids").AUTHOR_ME ? d("MAWAckLevel").ACK.sent : d("MAWAckLevel").ACK.received,
            altIndex: void 0,
            author: h,
            externalId: g,
            groupId: a.groupId,
            groupIndex: a.groupIndex,
            groupSize: a.groupSize,
            isForwarded: a.isForwarded,
            sortOrderMs: a.sortOrderMs,
            threadJid: b,
            ts: d("WATimeUtils").castToUnixTime(a.displayTimestampMs / 1e3),
            type: f
        };
        a.authoritativeTimestampMs != null ? e.serverTs = d("WATimeUtils").castToUnixTime(a.authoritativeTimestampMs / 1e3) : e.serverTs = d("WATimeUtils").castToUnixTime(a.sortOrderMs / 1e3);
        if (a.quoteData != null) {
            h = d("MAWRepliesRestoreUtils").getQuoteDataFromEchoMessage(a, c);
            h != null && (e.quote = h, e.quoteExternalId = h.content.externalId)
        }
        return e
    }

    function w(a, b) {
        a = d("MAWJids").toUserJid(a.localKey);
        return a === b ? d("WAJids").AUTHOR_ME : a
    }

    function x(a, b, c, e, f, g) {
        a = v(a, b, c, e, f, g);
        return babelHelpers["extends"]({}, a, {
            type: d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE
        })
    }
    g.MAWRestoreType = c;
    g.getDbMsgTypeFromEchoMessage = m;
    g.getUnstoredDbMessageFromEchoMessage = a;
    g.resolveAuthorFromEchoAddress = w
}), 98);
__d("MAWRepliesRestoreUtils", ["EchoEncodingUtils", "FBLogger", "MAWBridgeMsg", "MAWDexieTable", "MAWGetMsgQuoteTxn", "MAWHandleEchoMsgsRestoreApiUtils", "MAWIndexedDb", "MAWLoadReplyMediaTxns", "MAWMsgType", "MAWTransactionMode", "MAWUpdateQuotedMsgTxns", "WALogger", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Quote data is missing for message: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        if (b == null || !d("MAWMsgType").isQuotedMsgType(b.type)) return a;
        else {
            b = {
                author: b.author,
                externalId: b.externalId,
                ts: b.ts,
                type: b.type
            };
            b = {
                content: b,
                remoteJid: null
            };
            return babelHelpers["extends"]({}, a, {
                quote: b
            })
        }
    }

    function b(a, b) {
        if (a.quoteData != null && a.quoteData.quoteMessageId != null && a.quoteData.quoteMessageSender != null) {
            b = {
                author: d("MAWHandleEchoMsgsRestoreApiUtils").resolveAuthorFromEchoAddress(a.quoteData.quoteMessageSender, b),
                externalId: (b = a.quoteData) == null ? void 0 : b.quoteMessageId,
                ts: a.displayTimestampMs,
                type: c("gkx")("458") ? (b = d("EchoEncodingUtils").convertXMessageContentTypeToDbMsgType(a.xContentType)) != null ? b : d("MAWMsgType").MSG_TYPE.TEXT : d("MAWMsgType").MSG_TYPE.TEXT
            };
            return {
                content: b,
                remoteJid: null
            }
        } else d("WALogger").ERROR(h(), a.messageId);
        return null
    }
    f = d("MAWIndexedDb").makeMsgrTransactor({
        chunk: (e = d("MAWTransactionMode")).READONLY,
        media: e.READONLY,
        messages: e.READWRITE,
        threads: e.READWRITE,
        xma: e.READONLY
    }, "updateQuoteDataForReplyMessages", function(a) {
        return function(b, c, e) {
            c == null ? void 0 : c.addPoint("replies_restore_start");
            b = b.restoredMsgsData;
            if (b) {
                var f = b.existingMsgs;
                b = b.newlyAddedMsgs;
                b = b.concat(f);
                return d("MAWDexieTable").dexieAll(b.map(function(b) {
                    return d("MAWUpdateQuotedMsgTxns").associateQuotedMessage(a, b.threadJid, b).then(function(a) {
                        var c = [];
                        b.quoteExternalId != null && c.push(b);
                        a != null && c.push.apply(c, a);
                        return c
                    })
                })).then(function(b) {
                    b = b.flat();
                    return i(a, b, e)
                }).then(function(a) {
                    c == null ? void 0 : c.addPoint("replies_restore_end", {
                        "int": {
                            replies: a
                        }
                    });
                    return a
                })
            }
            return d("MAWDexieTable").dexieResolve(0)
        }
    });

    function i(a, b, e) {
        return d("MAWDexieTable").dexieAll(b.map(function(b) {
            var e = j(b);
            if (b.threadJid != null) return d("MAWGetMsgQuoteTxn").enhanceMsgWithQuoteInfo(a, e, b.threadJid).then(function(a) {
                return babelHelpers["extends"]({}, a, {
                    msgId: b.msgId,
                    originalTs: b.originalTs,
                    rowId: b.rowId,
                    threadJid: b.threadJid,
                    unsendMsgContentDeleteTs: b.unsendMsgContentDeleteTs
                })
            });
            else c("FBLogger")("labyrinth_web", "thread_id_absent").mustfix("Reply restore: threadId cannot be null for a restored msg")
        })).then(function(a) {
            return a.filter(Boolean).filter(function(a) {
                return a.quote != null
            })
        }).then(function(b) {
            return a.messages.bulkPut(b).then(function(c) {
                return b.map(function(b) {
                    return d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, b).then(function(a) {
                        if (e === !0) return;
                        d("MAWIndexedDb").afterTransaction({
                            tag: "MsgUpdated",
                            value: d("MAWBridgeMsg").createBridgeMsg(b, void 0, a, "EncryptedBackups")
                        })
                    })
                })
            }).then(function(a) {
                return (a = b == null ? void 0 : b.length) != null ? a : 0
            })
        })
    }

    function j(a) {
        a.msgId;
        a.originalTs;
        a.rowId;
        a.threadJid;
        a.unsendMsgContentDeleteTs;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["msgId", "originalTs", "rowId", "threadJid", "unsendMsgContentDeleteTs"]);
        return a
    }
    g.addQuoteDataToReplyMessage = a;
    g.getQuoteDataFromEchoMessage = b;
    g.updateQuoteDataForReplyMessages = f;
    g.enhanceAndPersistReplyMessagesWithQuoteData = i
}), 98);
__d("MAWHandleEchoReactionsRestore", ["MAWAckLevel", "MAWAuthor", "MAWBulkWriteReactionsTxns", "MAWHandleEchoMsgsRestoreApiUtils", "MAWIndexedDb", "MAWTransactionMode", "Promise", "WAJids", "WALogger", "WAStanzaUtils", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] reaction fields in backup data uneven in length"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] reactToAuthor field is null"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] reaction external id missing"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] reaction string is not a single character"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot have reactions empty author"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot have reactions for system author"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] echo document is absent for a restored msg"]);
        o = function() {
            return a
        };
        return a
    }

    function a(a, c, d, e) {
        d == null ? void 0 : d.addPoint("reactions_restore_start");
        var f = a.echoMsgMap,
            g = a.restoredMsgsData,
            i = 0;
        if (g) {
            a = g.existingMsgs;
            var j = g.newlyAddedMsgs;
            j = j.concat(a);
            var k = g.threadJid;
            a = j.filter(function(a) {
                var b = f.get(a.externalId);
                return q(f, a) && b != null && r(b)
            });
            if (a.length === 0) return (h || (h = b("Promise"))).resolve();
            var l = a.flatMap(function(a) {
                var b = f.get(a.externalId);
                a = u(g.threadJid, c, a.externalId, a.msgId, a.author, b);
                return a.map(function(a) {
                    return {
                        chatJid: k,
                        unstoredReaction: a
                    }
                })
            });
            return l.length === 0 ? (h || (h = b("Promise"))).resolve() : p(l, e).then(function(a) {
                i += l.length, d == null ? void 0 : d.addPoint("reactions_restore_end", {
                    "int": {
                        reactions: i
                    }
                })
            })
        }
        return (h || (h = b("Promise"))).resolve()
    }
    var p = d("MAWIndexedDb").makeMsgrTransactor({
        groupInfo: (c = d("MAWTransactionMode")).READWRITE,
        messages: c.READWRITE,
        reactions: c.READWRITE,
        threads: c.READWRITE
    }, "restoreWriteReactionsToDb", function(a) {
        return function(b, c) {
            return d("MAWBulkWriteReactionsTxns").prepareReactionsData(a, b).then(function(b) {
                return d("MAWBulkWriteReactionsTxns").bulkWriteReactions(a, b, c)
            })
        }
    });

    function q(a, b) {
        a = a.get(b.externalId);
        if (a == null) {
            d("WALogger").ERROR(o());
            return !1
        }
        if (d("WAJids").isAuthorSystem(b.author)) {
            d("WALogger").ERROR(n());
            return !1
        }
        if (d("MAWAuthor").getAuthorUserJid(b.author) == null) {
            d("WALogger").ERROR(m());
            return !1
        }
        return !0
    }

    function r(a) {
        return a.reactions != null && a.reactions.length !== 0 && a.reactionXOfflineThreadingIds != null && a.reactionXOfflineThreadingIds.length !== 0 && a.reactionAuthoritativeTimestampMs != null && a.reactionAuthoritativeTimestampMs.length !== 0
    }

    function s(a, b, c) {
        if ((a == null ? void 0 : a.length) === 0) {
            d("WALogger").ERROR(l());
            return !1
        }
        if (b == null) {
            d("WALogger").ERROR(k());
            return !1
        }
        if (c == null) {
            d("WALogger").ERROR(j());
            return !1
        }
        return !0
    }

    function t(a, b, c) {
        return (a || []).map(function(a, e) {
            if (c == null || b == null || (c == null ? void 0 : c.length) <= e || (b == null ? void 0 : b.length) <= e) {
                d("WALogger").WARN(i());
                return []
            }
            return [a, b[e], c[e]]
        })
    }

    function u(a, b, c, e, f, g) {
        var h = d("MAWAuthor").getAuthorUserJid(f);
        if (g == null || h == null) return [];
        var i = g.reactionAuthoritativeTimestampMs;
        i = i === void 0 ? [] : i;
        var j = g.reactionXOfflineThreadingIds;
        j = j === void 0 ? [] : j;
        g = g.reactions;
        return t(g, j, i).filter(function(a) {
            var b = a[0];
            a = a[1];
            return a != null && s(b.displayName, a.displayName, d("MAWAuthor").getAuthorUserJid(f))
        }).map(function(f) {
            var g = f[0],
                i = f[1];
            f = f[2];
            var j = g.displayName;
            g = d("MAWHandleEchoMsgsRestoreApiUtils").resolveAuthorFromEchoAddress(g, b);
            g = {
                ack: g === d("WAJids").AUTHOR_ME ? d("MAWAckLevel").ACK.sent : d("MAWAckLevel").ACK.received,
                author: g,
                externalId: d("WAStanzaUtils").toStanzaId(i.displayName || ""),
                groupingKey: j,
                reaction: j,
                reactToAuthor: h,
                reactToExternalId: c,
                senderTimestampMs: null,
                threadJid: a,
                ts: d("WATimeUtils").castToUnixTime(Number(f.displayName) / 1e3)
            };
            return e != null ? babelHelpers["extends"]({}, g, {
                reactToMsgId: e
            }) : g
        })
    }
    g.writeEchoReactionsToReactionsStore = a;
    g.getReactionsForReactionStore = u
}), 98);
__d("MAWHandleEchoXMARestoreV2", ["EchoMessage", "FBLogger", "LSDataTraceCheckPoint", "LSIntEnum", "MAWBridge", "MAWBridgeXMA", "MAWConvertXMAGatingTypeToExtendedContentOverlayIconGlyph", "MAWConvertXMALayoutTypeToExtendedContentXMLLayoutType", "MAWConvertXMATargetTypeToExtendedContentTargetType", "MAWDbMediaTxns", "MAWDbMsg", "MAWHandleEchoMediaMsgsRestoreV2", "MAWHandleXmaTransactionUtil", "MAWIndexedDb", "MAWMediaGalleryM2Utils", "MAWODSProxy", "MAWParseXMAProtocol", "MAWTraceUtils", "MAWTransactionMode", "Promise", "WAArmadilloXMA.pb", "WAHashUtils", "WALogger", "WAMediaUtils", "WAOdsEnums", "WATimeUtils", "asyncToGeneratorRuntime", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] invalid CTA observed while restoring XMA. Echo message origin ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] threadJid field is not present in the restoredMsg. Echo message origin ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] xmaLayoutType field is not present in the echo doc. Echo message origin ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] xmaGatingType field is not present in the echo doc. Echo message origin ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] xmaTargetType field is not present in the echo doc. Echo message origin ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] xmaDefaultCTA field is not present in the echo doc. Echo message origin ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] xmaData is missing in the echo doc. Echo message origin ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web][getMediaForXMAByObjectIds] mediaEntry is null for media restore"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] msgContent is null for external link share XMA on Restore. Echo message origin ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] dbXMA is null. EchoMessage origin ", ""]);
        s = function() {
            return a
        };
        return a
    }
    a = function(a, e, f, g) {
        e == null ? void 0 : e.addPoint("xma_restore_start");
        d("MAWTraceUtils").recordCheckpointForTrace(f, (i || (i = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_XMA_RESTORE_STARTED), [], !1);
        var j = a.restoredMsgsData;
        if (j) {
            var k = j.newlyAddedMsgs;
            k = k.concat(j.existingMsgs);
            var l = [];
            k.map(function(b) {
                var c = b.externalId;
                c = a.echoMsgMap.get(c);
                c != null && (c.contentType === d("EchoMessage").EchoMessageContentType.XMA && l.push(b))
            });
            return l.length === 0 ? (h || (h = b("Promise"))).resolve() : t(l, a.echoMsgMap, f, g).then(function(a) {
                e == null ? void 0 : e.addPoint("xma_restore_end", {
                    "int": {
                        xma: a.length
                    }
                });
                d("MAWTraceUtils").recordCheckpointForTrace(f, (i || (i = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_XMA_RESTORE_ENDED), [], !1);
                return (h || (h = b("Promise"))).resolve()
            })
        }
        e == null ? void 0 : e.addPoint("xma_restore_end", {
            "int": {
                xma: 0
            }
        });
        return (h || (h = b("Promise"))).resolve()
    };

    function t(a, e, f, g) {
        var h = new Map(),
            j = new Map();
        a.forEach(function(a) {
            var b, c = e.get(a.externalId);
            b = c == null ? void 0 : (b = c.mediaData) == null ? void 0 : b.attachmentObjectId;
            b != null && h.set(d("WAMediaUtils").stringToDeliveryObjectId(b), a);
            c = c == null ? void 0 : (b = c.mediaData) == null ? void 0 : b.plaintextHash;
            if (c != null) {
                b = d("WAHashUtils").stringToPlaintextHash(d("MAWHandleEchoMediaMsgsRestoreV2").getBase64WithoutPadding(c));
                c = j.get(b);
                j.set(b, c != null ? [].concat(c, [a.msgId]) : [a.msgId])
            }
        });
        var k = Array.from(h.keys()),
            l = new Map();
        return u(k, j).then(function(j) {
            var m = [];
            k.forEach(function(a) {
                var b;
                b = (b = h.get(a)) == null ? void 0 : b.externalId;
                b != null && l.set(b, a)
            });
            a.filter(function(a) {
                return d("MAWDbMsg").isXMAMsg(a)
            }).forEach(function(a) {
                var b = e.get(a.externalId);
                if (b) {
                    var g = l.get(a.externalId),
                        h;
                    if (g != null) {
                        g = j.get(g);
                        g != null && (h = g.mediaId)
                    }
                    g = b.serializationOrigin;
                    g == null && (g = d("EchoMessage").EchoSerializationOriginType.UNKNOWN);
                    b = w(a, b, h, g);
                    b == null ? (d("WALogger").ERROR(s(), g), d("MAWTraceUtils").recordCheckpointForTrace(f, (i || (i = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_XMA_RESTORE_DBXMA_NULL), [], !1)) : (b.targetType === d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_EXTERNAL_LINK_SHARE && a.msgContent == null && (d("WALogger").WARN(r(), g), d("MAWODSProxy").odsBumpEntityKey({
                        entity: d("WAOdsEnums").Entity.EB_RESTORE,
                        key: "missing_msg_content_external_link_xma"
                    })), m.push(b))
                }
            });
            return v(m).then(function(a) {
                if (a.length > 0) {
                    a.map(function() {
                        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                            var b = l.get(a.externalId);
                            if (g !== !0) {
                                var e;
                                b != null && (e = j.get(b));
                                c("gkx")("821") ? b = (yield d("MAWHandleXmaTransactionUtil").checkMediaChunkTransactionAndCreatedBridgeXma(e, a)) : b = d("MAWBridgeXMA").createBridgeXMA(e, a, !1);
                                d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled({
                                    isSilent: !0
                                }) && c("FBLogger")("messenger_e2ee_web").info("Calling into NewXMA from %s", "MAWHandleEchoXMARestoreV2");
                                d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
                                    events: [{
                                        tag: "NewXMA",
                                        value: b
                                    }]
                                })
                            }
                        });
                        return function(b) {
                            return a.apply(this, arguments)
                        }
                    }());
                    return a
                }
                return a
            })
        })
    }
    var u = d("MAWIndexedDb").makeMsgrTransactor({
            media: d("MAWTransactionMode").READONLY,
            mediaBackup: d("MAWTransactionMode").READONLY
        }, "restoreGetMediaForXMAByObjectIds", function(a) {
            return function(b, e) {
                if (c("gkx")("4663")) {
                    var f = Array.from(e.keys());
                    return d("MAWDbMediaTxns").maybeBulkGetMediaFromPlaintextHash(a, f).then(function(a) {
                        var b = new Map();
                        a.forEach(function(a) {
                            var c = e.get(a.plaintextHash);
                            c == null ? void 0 : c.forEach(function(c) {
                                c = a == null ? void 0 : a.mediaEntries.get(c);
                                if (a != null && c != null) {
                                    c = d("WAMediaUtils").decodeMediaEntryData(c);
                                    c.objectId != null && b.set(d("WAMediaUtils").stringToDeliveryObjectId(c.objectId), a)
                                } else d("WALogger").ERROR(q())
                            })
                        });
                        return b
                    })
                }
                return d("MAWDbMediaTxns").maybeGetMediaBackupRowsFromObjectIds(a, b).then(function(b) {
                    var c = Array.from(b.values()).map(function(a) {
                        return a.mediaId
                    });
                    return a.media.bulkGet(c).then(function(a) {
                        var c = new Map();
                        a != null && a.forEach(function(a) {
                            a != null && c.set(a.mediaId, a)
                        });
                        var d = new Map();
                        b.forEach(function(a, b) {
                            a = c.get(a.mediaId);
                            a != null && d.set(b, a)
                        });
                        return d
                    })
                })
            }
        }),
        v = d("MAWIndexedDb").makeMsgrTransactor({
            xma: d("MAWTransactionMode").READWRITE
        }, "restoreWriteXMAsToDb", function(a) {
            return function(b) {
                return a.xma.bulkAdd(b, {
                    allKeys: !0
                }).then(function(a) {
                    return a.map(function(a, c) {
                        return babelHelpers["extends"]({}, b[c], {
                            xmaId: a
                        })
                    })
                })
            }
        });

    function w(a, b, c, e) {
        var f;
        if (b.xmaData == null) {
            d("WALogger").ERROR(p(), e);
            return null
        }
        var g;
        if (b.xmaData.xmaDefaultCTA != null) {
            var h;
            g = x((h = b.xmaData) == null ? void 0 : h.xmaDefaultCTA)
        } else d("WALogger").WARN(o(), e);
        if (((h = b.xmaData) == null ? void 0 : h.xmaTargetType) != null) h = d("MAWConvertXMATargetTypeToExtendedContentTargetType").convertXMATargetTypeToExtendedContentTargetType(b.xmaData.xmaTargetType);
        else {
            d("WALogger").ERROR(n(), e);
            return null
        }
        var i;
        ((f = b.xmaData) == null ? void 0 : f.xmaGatingType) != null ? i = d("MAWConvertXMAGatingTypeToExtendedContentOverlayIconGlyph").convertXMAGatingTypeToExtendedContentOverlayIconGlyph(b.xmaData.xmaGatingType) : d("WALogger").WARN(m(), e);
        var q;
        ((f = b.xmaData) == null ? void 0 : f.xmaLayoutType) != null ? q = d("MAWConvertXMALayoutTypeToExtendedContentXMLLayoutType").convertXMALayoutTypeToExtendedContentXMLLayoutType(b.xmaData.xmaLayoutType) : d("WALogger").WARN(l(), e);
        if (a.threadJid != null) f = a.threadJid;
        else {
            d("WALogger").ERROR(k(), e);
            return null
        }
        if (g != null && !d("MAWParseXMAProtocol").isValidCTA(g, h, !0)) {
            d("WALogger").ERROR(j(), e);
            return null
        }
        var r;
        ((e = b.xmaData) == null ? void 0 : e.xmaContentRef) != null && (r = b.xmaData.xmaContentRef);
        return {
            author: a.author,
            contentRef: r,
            ctas: [],
            defaultCTA: g,
            defaultPreviewMediaId: (e = c) != null ? e : void 0,
            externalId: a.externalId,
            headerTitle: b == null ? void 0 : (e = b.xmaData) == null ? void 0 : e.xmaHeaderTitle,
            isTombstoned: b == null ? void 0 : (e = b.xmaData) == null ? void 0 : e.xmaIsTombstoned,
            maxSubtitleNumOfLines: b == null ? void 0 : (e = b.xmaData) == null ? void 0 : e.xmaMaxSubtitleNumLines,
            maxTitleNumOfLines: b == null ? void 0 : (e = b.xmaData) == null ? void 0 : e.xmaMaxTitleNumLines,
            msgId: a.msgId,
            overlayIconGlyph: i,
            overlayTitle: b == null ? void 0 : (e = b.xmaData) == null ? void 0 : e.xmaHeaderSubtitle,
            previewMediaIds: c != null ? [c] : [],
            subtitleText: b == null ? void 0 : (a = b.xmaData) == null ? void 0 : a.xmaSubtitleText,
            targetExpiringAtSec: ((e = b.xmaData) == null ? void 0 : e.xmaTargetExpiry) != null ? d("WATimeUtils").castToUnixTime(Number((c = b.xmaData) == null ? void 0 : c.xmaTargetExpiry)) : void 0,
            targetId: b == null ? void 0 : (a = b.xmaData) == null ? void 0 : a.xmaTargetId,
            targetType: h,
            targetUsername: b == null ? void 0 : (e = b.xmaData) == null ? void 0 : e.xmaTargetUsername,
            threadJid: f,
            titleText: (c = b.xmaData) == null ? void 0 : c.xmaTitleText,
            xmaLayoutType: q
        }
    }

    function x(a) {
        return {
            actionUrl: a,
            buttonType: d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_CTA_BUTTON_TYPE.OPEN_NATIVE,
            nativeUrl: a
        }
    }
    g.writeXMAToXMAStore = a;
    g.getMediaForXMAByObjectIds = u;
    g.writeXMAsToDb = v;
    g.getDefaultCTA = x
}), 98);
__d("MessageBackupSupplementalKeyGenerator", ["$InternalEnum", "MAWJids", "WAGlobals", "WAJids", "WAStanzaUtils", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = b("$InternalEnum")({
            REACTION: "reaction",
            EDIT: "edit",
            RAVEN_ACTION_MESSAGE: "raven_action_message"
        }),
        i = ":";

    function a(a, b) {
        return "" + a + i + b
    }

    function c(a) {
        return a.split(i)[1]
    }

    function j(a, b) {
        b = b.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
        b = new RegExp("^" + b, "i");
        return b.test(a)
    }

    function e(a) {
        return j(a, h.REACTION)
    }

    function f(a) {
        return j(a, h.EDIT)
    }

    function k(a) {
        return j(a, h.RAVEN_ACTION_MESSAGE)
    }

    function l(a) {
        a = a.split(i);
        if (a.length < 2 || a.length > 3) return {
            type: "unknown"
        };
        var b = a[0],
            c = a[1];
        if (b === h.REACTION) return {
            senderJid: d("MAWJids").toUserJid(c),
            type: "reaction"
        };
        a = a.length === 3 ? d("WATimeUtils").castToUnixTime(Number(a[2])) : null;
        if (a == null) return {
            type: "unknown"
        };
        if (b === h.EDIT) return {
            externalId: d("WAStanzaUtils").toStanzaId(c),
            ts: a,
            type: "edit"
        };
        return b === h.RAVEN_ACTION_MESSAGE ? {
            senderId: c,
            ts: a,
            type: "raven_action_message"
        } : {
            type: "unknown"
        }
    }

    function m(a) {
        switch (a.type) {
            case "edit":
                return "" + h.EDIT + i + a.externalId + i + a.ts.toString();
            case "reaction":
                return "" + h.REACTION + i + d("WAJids").extractUserId(a.senderJid);
            case "raven_action_message":
                return "" + h.RAVEN_ACTION_MESSAGE + i + a.senderId + i + a.ts.toString()
        }
    }

    function n(a) {
        var b;
        if (d("WAJids").isAuthorMe(a)) b = d("WAGlobals").getMyUserJid();
        else {
            a = d("WAJids").interpretAndValidateJid(a);
            if (a.jidType === "msgrUser") b = a.userJid;
            else return null
        }
        a = d("WAJids").userIdFromJid(b);
        return "" + h.REACTION + i + a
    }
    g.SupplementalKeyPrefix = h;
    g.SUPPLEMENTAL_KEY_DELIMITER = i;
    g.createMessageSupplementalKey = a;
    g.getSupplementalSenderId = c;
    g.isSupplementalProtobufAReaction = e;
    g.isSupplementalProtobufAnEdit = f;
    g.isSupplementalProtobufARavenAction = k;
    g.parseIdentifierString = l;
    g.toIdentifierString = m;
    g.createReactionSupplementalKey = n
}), 98);
__d("WAMapContentTypeToFbType", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case "text":
                return "text";
            case "media":
                return "media";
            case "reaction":
                return "reaction";
            case "live_location":
            case "pay":
            case "product_list":
            case "poll_creation":
            case "poll_vote":
            case "scheduled_call":
                return "text";
            default:
                return "text"
        }
    }
    f.mapContentTypeToFbType = a
}), 66);
__d("WAProtocolQueue", ["WAGlobals", "WAJids", "WALogger", "WAMapContentTypeToFbType", "WAPersistedQueue", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Protocol Queue is already initialized"]);
        h = function() {
            return a
        };
        return a
    }
    var i = 5e3,
        j = null;

    function a(a) {
        if (j != null) {
            d("WALogger").WARN(h());
            return j
        }
        a = d("WAPersistedQueue").initPersistedQueue("stanzaQueue", a, {
            cacheSize: null,
            maxDelay: i
        });
        j = a;
        return j
    }

    function b() {
        if (!j) throw c("err")("Protocol queue not initialized");
        return j
    }

    function e(a) {
        return {
            flush: function() {
                return a.commit()
            }
        }
    }

    function f(a) {
        return a.map(function(a) {
            return a.type === "message" ? k(a) : babelHelpers["extends"]({}, a)
        })
    }

    function k(a) {
        switch (a.subtype) {
            case "unavailable":
                var b = a,
                    c = d("WAJids").extractUserJid(b.from);
                c = {
                    id: {
                        author: d("WAGlobals").getMyUserJid() === c ? "@me" : c,
                        chat: b.jid,
                        externalId: b.stanzaId
                    },
                    ts: b.serverTs,
                    type: "UnavailableMsg"
                };
                return {
                    incomingType: "wa",
                    jid: b.jid,
                    message: {
                        decrypted: c,
                        details: {
                            count: null,
                            externalId: b.stanzaId,
                            folder: b.fbFolderId,
                            from: d("WAJids").switchOnMsgrChatJidType(b.jid, {
                                group: function(a) {
                                    return {
                                        author: b.from,
                                        chat: a,
                                        groupJid: a,
                                        type: "group"
                                    }
                                },
                                user: function(a) {
                                    return {
                                        author: b.from,
                                        chat: a,
                                        deviceJid: b.from,
                                        type: "device"
                                    }
                                }
                            }),
                            hideDecryptionFailure: !1,
                            isInstamadillo: !1,
                            offline: b.offline,
                            recipient: b.recipient,
                            reportingMeta: b.reportingMeta,
                            retryCount: b.retryCount,
                            ts: b.serverTs,
                            type: d("WAMapContentTypeToFbType").mapContentTypeToFbType(b.contentType)
                        }
                    },
                    priority: b.priority,
                    stanzaId: b.stanzaId,
                    stanzaQueueId: a.stanzaQueueId,
                    type: b.type
                };
            case "armadillo":
                var e = a;
                c = d("WAJids").extractUserJid(e.from);
                c = {
                    device: {
                        id: d("WAJids").extractDeviceId(e.from),
                        identity: e.remoteIdentity
                    },
                    folder: e.fbFolderId,
                    id: {
                        author: d("WAGlobals").getMyUserJid() === c ? "@me" : c,
                        chat: e.jid,
                        externalId: e.stanzaId
                    },
                    msg: e.message,
                    recipientsCount: null,
                    reportingMeta: e.reportingMeta,
                    ts: e.serverTs,
                    type: "IncomingMsg"
                };
                return {
                    incomingType: a.incomingType,
                    jid: e.jid,
                    message: {
                        decrypted: c,
                        details: {
                            count: null,
                            externalId: e.stanzaId,
                            folder: e.fbFolderId,
                            from: d("WAJids").switchOnMsgrChatJidType(e.jid, {
                                group: function(a) {
                                    return {
                                        author: e.from,
                                        chat: a,
                                        groupJid: a,
                                        type: "group"
                                    }
                                },
                                user: function(a) {
                                    return {
                                        author: e.from,
                                        chat: a,
                                        deviceJid: e.from,
                                        type: "device"
                                    }
                                }
                            }),
                            hideDecryptionFailure: !1,
                            isInstamadillo: !1,
                            offline: e.offline,
                            recipient: e.recipient,
                            reportingMeta: e.reportingMeta,
                            retryCount: e.retryCount,
                            ts: e.serverTs,
                            type: d("WAMapContentTypeToFbType").mapContentTypeToFbType(e.contentType)
                        }
                    },
                    priority: e.priority,
                    stanzaId: e.stanzaId,
                    stanzaQueueId: a.stanzaQueueId,
                    type: e.type,
                    ebTimestampMs: e.ebTimestampMs
                };
            case "instamadillo":
                var f = a;
                c = d("WAJids").extractUserJid(f.from);
                c = {
                    device: {
                        id: d("WAJids").extractDeviceId(f.from),
                        identity: f.remoteIdentity
                    },
                    folder: f.fbFolderId,
                    id: {
                        author: d("WAGlobals").getMyUserJid() === c ? "@me" : c,
                        chat: f.jid,
                        externalId: f.stanzaId
                    },
                    msg: f.message,
                    recipientsCount: null,
                    reportingMeta: f.reportingMeta,
                    ts: f.serverTs,
                    type: "InstamadilloMsg"
                };
                return {
                    incomingType: "wa",
                    jid: f.jid,
                    message: {
                        decrypted: c,
                        details: {
                            count: null,
                            externalId: f.stanzaId,
                            folder: f.fbFolderId,
                            from: d("WAJids").switchOnMsgrChatJidType(f.jid, {
                                group: function(a) {
                                    return {
                                        author: f.from,
                                        chat: a,
                                        groupJid: a,
                                        type: "group"
                                    }
                                },
                                user: function(a) {
                                    return {
                                        author: f.from,
                                        chat: a,
                                        deviceJid: f.from,
                                        type: "device"
                                    }
                                }
                            }),
                            hideDecryptionFailure: !1,
                            isInstamadillo: !0,
                            offline: f.offline,
                            recipient: f.recipient,
                            reportingMeta: f.reportingMeta,
                            retryCount: f.retryCount,
                            ts: f.serverTs,
                            type: d("WAMapContentTypeToFbType").mapContentTypeToFbType(f.contentType)
                        }
                    },
                    priority: f.priority,
                    stanzaId: f.stanzaId,
                    stanzaQueueId: a.stanzaQueueId,
                    type: f.type
                };
            case "ciphertext":
                var g = a;
                c = d("WAJids").extractUserJid(g.from);
                c = {
                    createPlaceholder: g.contentType !== "reaction",
                    id: {
                        author: d("WAGlobals").getMyUserJid() === c ? "@me" : c,
                        chat: g.jid,
                        externalId: g.stanzaId
                    },
                    ts: g.serverTs,
                    type: "IncomingCiphertextMsg"
                };
                return {
                    incomingType: "wa",
                    jid: g.jid,
                    message: {
                        decrypted: c,
                        details: {
                            count: null,
                            type: d("WAMapContentTypeToFbType").mapContentTypeToFbType(g.contentType),
                            externalId: g.stanzaId,
                            folder: g.fbFolderId,
                            from: d("WAJids").switchOnMsgrChatJidType(g.jid, {
                                group: function(a) {
                                    return {
                                        author: g.from,
                                        chat: a,
                                        groupJid: a,
                                        type: "group"
                                    }
                                },
                                user: function(a) {
                                    return {
                                        author: g.from,
                                        chat: a,
                                        deviceJid: g.from,
                                        type: "device"
                                    }
                                }
                            }),
                            hideDecryptionFailure: !1,
                            isInstamadillo: !1,
                            offline: g.offline,
                            recipient: g.recipient,
                            reportingMeta: g.reportingMeta,
                            retryCount: g.retryCount,
                            ts: g.serverTs
                        }
                    },
                    priority: g.priority,
                    stanzaId: g.stanzaId,
                    stanzaQueueId: a.stanzaQueueId,
                    type: g.type
                };
            default:
                a;
                return babelHelpers["extends"]({}, a)
        }
    }
    var l = 9,
        m = 5,
        n = 2;

    function o(a) {
        return a
    }

    function p(a) {
        return a
    }

    function q(a) {
        return a
    }
    g.initProtocolQueue = a;
    g.protocolQueue = b;
    g.protocolQueueFlushable = e;
    g.mapProtocolEntriesV2toV1 = f;
    g.mapProcolQueueMessageV2toV1 = k;
    g.WAProtocolQueuePriorityHigh = l;
    g.WAProtocolQueuePriorityLow = m;
    g.WAProtocolQueuePriorityBackground = n;
    g.appdataApplicationProtocol = o;
    g.extractSubProtocolFromAppdataProtocol = p;
    g.numberToStanzaQueueId = q
}), 98);
__d("MAWHandleEBRestoreWithHIM", ["EBAPIWorkerCheck", "EchoMessage", "EncryptedBackupsUploadEntity", "FBLogger", "MAWAckLevel", "MAWAsMessageApplication", "MAWBulkEditMsgsTxns", "MAWConvertXMAGatingTypeToExtendedContentOverlayIconGlyph", "MAWConvertXMALayoutTypeToExtendedContentXMLLayoutType", "MAWConvertXMATargetTypeToExtendedContentTargetType", "MAWFrontendMediaUtils", "MAWHandleEchoMediaMsgsRestoreV2", "MAWHandleEchoMsgsRestoreApiUtils", "MAWHandleEchoReactionsRestore", "MAWHandleEchoXMARestoreV2", "MAWJids", "MAWMsgType", "MAWParseXMAProtocol", "MAWUnsafeCoerce", "MAWUserJidWrapper", "MessageBackupSupplementalKeyGenerator", "WAGlobals", "WAHashUtils", "WAJids", "WALogger", "WALongInt", "WAProtocolQueue", "WASortedLists", "WAStanzaUtils", "WATimeUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to create reaction supplemental key"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Exception when trying to convert echo message to protobuf: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to convert Echo Message to UnstoredDbMsg"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] One of the mandatory fields is null for Echo message"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to decode echo message: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] threadJid field is not present in the restoredMsg. Echo message origin ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] xmaTargetType field is not present in the echo doc. Echo message origin ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Unable to construct downloadableThumbnail from previewMediaData: ", ", msg id: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p(a, b) {
        if (a === "@me" || a === "@system") return b;
        else return a
    }

    function q(a, b, c, e, f) {
        var g = [];
        if (a.reactionXOfflineThreadingIds != null)
            for (var h = 0; h < a.reactionXOfflineThreadingIds.length; ++h) {
                var i = d("MAWHandleEchoReactionsRestore").getReactionsForReactionStore(b, c, e, null, f, a);
                i = i.map(function(a) {
                    return {
                        decodedMsg: {
                            unstoredDbMedia: void 0,
                            unstoredDbMsg: void 0,
                            unstoredDbReaction: a,
                            unstoredDbReceiverFetchInfo: void 0
                        },
                        stanza: t(a.externalId, a.ts, p(a.author, c), b, "reaction")
                    }
                });
                g.push.apply(g, i)
            }
        return g
    }

    function r(a, b, c, e) {
        return e ? e.map(function(e) {
            var f = e.messageId;
            return f != null ? {
                decodedMsg: {
                    unstoredDbEditActionMsg: {
                        ack: d("MAWAckLevel").ACK.sent,
                        author: c,
                        editMsgContent: {
                            content: e.text
                        },
                        externalId: d("WAStanzaUtils").toStanzaId(f),
                        originalMsgExternalId: a,
                        serverTs: d("WATimeUtils").castToUnixTime(e.timestamp),
                        ts: d("WATimeUtils").castToUnixTime(e.timestamp),
                        type: d("MAWMsgType").MSG_TYPE.EDIT_ACTION
                    },
                    unstoredDbMedia: void 0,
                    unstoredDbMsg: void 0,
                    unstoredDbReaction: void 0
                },
                stanza: t(d("WAStanzaUtils").toStanzaId(f), d("WATimeUtils").castToUnixTime(e.timestamp), c, b, "text")
            } : null
        }).filter(Boolean) : []
    }

    function a(a, b) {
        return a.map(x).filter(Boolean).map(function(a) {
            return s(a, b)
        })
    }

    function s(a, b) {
        var e, f = d("MAWUserJidWrapper").getMyUserJid(),
            g = a.from,
            h = d("MAWHandleEchoMsgsRestoreApiUtils").getDbMsgTypeFromEchoMessage(a);
        if (g == null || h == null) return [];
        h = a.xOfflineThreadingId;
        if (h == null) {
            c("FBLogger")("labyrinth_web").warn("xOfflineThreadingId is null for Echo message");
            return []
        }
        h = d("WAStanzaUtils").toStanzaId(h);
        e = d("WATimeUtils").castToUnixTime(((e = a.authoritativeTimestampMs) != null ? e : a.sortOrderMs) / 1e3);
        g = d("MAWJids").toUserJid(g.localKey);
        var i = w(a, b, f, h, "echo_content");
        if (i == null) return [];
        f = q(a, b, f, h, g);
        var j = a.contentType === d("EchoMessage").EchoMessageContentType.TEXT || a.contentType === d("EchoMessage").EchoMessageContentType.PLACEHOLDER ? "text" : "media";
        a = r(h, b, g, a.editHistory);
        return [{
            decodedMsg: i,
            stanza: t(h, e, g, b, j)
        }].concat(f, a)
    }

    function t(a, b, c, e, f) {
        var g = {
            icdc: null,
            metadata: null,
            protobuf: new Uint8Array(0),
            subprotocol: new Uint8Array(0),
            subprotocolType: "consumerMessage",
            type: "subprotocol",
            version: "v3"
        };
        g = {
            device: {
                id: d("WAJids").DEFAULT_DEVICE_ID,
                identity: null
            },
            folder: null,
            id: {
                author: c,
                chat: e,
                externalId: a
            },
            msg: g,
            recipientsCount: null,
            reportingMeta: null,
            ts: b,
            type: "IncomingMsg"
        };
        return {
            incomingType: "ebrestore",
            jid: e,
            message: {
                decrypted: g,
                details: {
                    count: 0,
                    externalId: a,
                    folder: void 0,
                    from: d("WAJids").switchOnMsgrChatJidType(e, {
                        group: function(a) {
                            return {
                                author: d("WAJids").defaultDeviceJidForUser(c),
                                chat: a,
                                groupJid: a,
                                type: "group"
                            }
                        },
                        user: function(a) {
                            return {
                                author: d("WAJids").defaultDeviceJidForUser(c),
                                chat: a,
                                deviceJid: d("WAJids").defaultDeviceJidForUser(c),
                                type: "device"
                            }
                        }
                    }),
                    hideDecryptionFailure: !0,
                    isInstamadillo: !1,
                    offline: null,
                    recipient: null,
                    reportingMeta: null,
                    retryCount: 0,
                    ts: b,
                    type: f
                }
            },
            priority: d("WAProtocolQueue").WAProtocolQueuePriorityLow,
            stanzaId: a,
            stanzaQueueId: d("MAWUnsafeCoerce").unsafeCoerce(-1),
            type: "message"
        }
    }

    function u(a) {
        if (a.mediaData == null) return null;
        var b = a.previewMediaData,
            c = a.sortOrderMs,
            e = a.xOfflineThreadingId;
        a = a.mediaData;
        var f = a.attachmentObjectId,
            g = a.backupEntFbid,
            h = a.directPath,
            i = a.encryptedHash,
            j = a.filename,
            k = a.height,
            l = a.mediaContentType,
            m = a.mediaKey,
            n = a.mediaKeyTimestamp,
            p = a.mediaPlayableDuration,
            q = a.plaintextHash,
            r = a.previewContentHeight,
            s = a.previewContentWidth,
            t = a.size;
        a = a.width;
        l = d("MAWFrontendMediaUtils").getMediaTypeAndServerMediaTypeFromBlob(l || "");
        var u = l.mediaType;
        l = l.serverMediaType;
        var v = d("WAHashUtils").stringToPlaintextHash(d("MAWHandleEchoMediaMsgsRestoreV2").getBase64WithoutPadding(q)),
            w = null;
        if (b != null) try {
            w = d("MAWHandleEchoMediaMsgsRestoreV2").constructRawDownloadableThumbnail(b)
        } catch (a) {
            d("WALogger").WARN(o(), a, e)
        }
        e = d("MAWHandleEchoMediaMsgsRestoreV2").constructMediaEntry(v, (b = i) != null ? b : "", m, h, n, l, j, g, f, w, t);
        v = d("MAWHandleEchoMediaMsgsRestoreV2").getMediaInfo({
            filename: j,
            height: k,
            mediaPlayableDuration: p,
            mediaType: u,
            previewContentHeight: r,
            previewContentWidth: s,
            width: a
        });
        i = v.validatedAudioInfo;
        b = v.validatedDocumentFileInfo;
        m = v.validatedImageInfo;
        h = v.validatedVideoInfo;
        return {
            mediaEntry: e,
            mediaType: u,
            msgIds: d("WASortedLists").asSortedSet(new Set()),
            plaintextHash: d("WAHashUtils").stringToPlaintextHash(q),
            size: t || 0,
            ts: n != null ? d("WATimeUtils").castToUnixTime(n) : d("WATimeUtils").castMilliSecondsToUnixTime(c),
            validatedAudioInfo: i,
            validatedDocumentFileInfo: b,
            validatedImageInfo: m,
            validatedVideoInfo: h
        }
    }

    function v(a, b) {
        if (a.xmaData == null || a.from == null || a.xOfflineThreadingId == null) return null;
        var c = a.from,
            e = a.serializationOrigin,
            f = a.xmaData;
        a = a.xOfflineThreadingId;
        if (f.xmaTargetType == null) return null;
        var g = f.xmaContentRef,
            h = f.xmaDefaultCTA,
            i = f.xmaGatingType,
            j = f.xmaHeaderSubtitle,
            k = f.xmaHeaderTitle,
            l = f.xmaIsTombstoned,
            o = f.xmaLayoutType,
            p = f.xmaMaxSubtitleNumLines,
            q = f.xmaMaxTitleNumLines,
            r = f.xmaSubtitleText,
            s = f.xmaTargetExpiry,
            t = f.xmaTargetId,
            u = f.xmaTargetType,
            v = f.xmaTargetUsername;
        f = f.xmaTitleText;
        if (u != null) u = d("MAWConvertXMATargetTypeToExtendedContentTargetType").convertXMATargetTypeToExtendedContentTargetType(u);
        else {
            d("WALogger").ERROR(n(), e);
            return null
        }
        var w;
        h != null && (w = d("MAWHandleEchoXMARestoreV2").getDefaultCTA(h));
        if (w != null && !d("MAWParseXMAProtocol").isValidCTA(w, u, !0)) {
            d("WALogger").ERROR(m(), e);
            return null
        }
        var x;
        i != null && (x = d("MAWConvertXMAGatingTypeToExtendedContentOverlayIconGlyph").convertXMAGatingTypeToExtendedContentOverlayIconGlyph(i));
        var y;
        s != null && (y = d("WATimeUtils").castToUnixTime(s));
        var z;
        o != null && (z = d("MAWConvertXMALayoutTypeToExtendedContentXMLLayoutType").convertXMALayoutTypeToExtendedContentXMLLayoutType(o));
        return {
            unstoredDbXMA: {
                author: d("MAWJids").toUserJid(c.localKey),
                contentRef: g,
                ctas: [],
                defaultCTA: w,
                externalId: d("WAStanzaUtils").toStanzaId(a),
                headerTitle: k,
                isTombstoned: l,
                maxSubtitleNumOfLines: p,
                maxTitleNumOfLines: q,
                overlayDescription: j,
                overlayIconGlyph: x,
                overlayTitle: k,
                subtitleText: r,
                targetExpiringAtSec: y,
                targetId: t,
                targetType: u,
                targetUsername: v,
                threadJid: b,
                titleText: f,
                xmaLayoutType: z
            }
        }
    }

    function w(a, b, c, e, f) {
        c = d("MAWHandleEchoMsgsRestoreApiUtils").getUnstoredDbMessageFromEchoMessage(a, b, c, e, void 0, f);
        if (c == null) return null;
        c.originalTs;
        c.threadJid;
        c.unsendMsgContentDeleteTs;
        e = babelHelpers.objectWithoutPropertiesLoose(c, ["originalTs", "threadJid", "unsendMsgContentDeleteTs"]);
        e.sortOrderMs = a.sortOrderMs;
        f = {
            unstoredDbMedia: u(a),
            unstoredDbMsg: e,
            unstoredDbReaction: void 0,
            unstoredDbReceiverFetchInfo: void 0
        };
        c = v(a, b);
        return c == null ? f : babelHelpers["extends"]({}, f, {
            unstoredXMA: c
        })
    }

    function x(a) {
        try {
            return d("EchoMessage").decodeEchoMessage(a)
        } catch (a) {
            d("WALogger").ERROR(l(), a);
            return null
        }
    }

    function b(a, b) {
        if (!d("EBAPIWorkerCheck").runningInWorker) throw c("err")("convertEchoMessagesToEBProtobufs should be called from the worker thread");
        return a.map(x).filter(Boolean).map(function(a) {
            return y(a, b)
        }).filter(Boolean)
    }

    function y(a, b) {
        var c = d("WAGlobals").getMyUserJid(),
            e = a.from,
            f = a.sortOrderMs,
            g = a.xOfflineThreadingId,
            l = d("WATimeUtils").castToMillisTime(f);
        if (g == null || e == null) {
            d("WALogger").ERROR(k());
            return null
        }
        var m = d("MAWJids").toUserJid(e.localKey),
            n = d("WAStanzaUtils").toStanzaId(g);
        f = w(a, b, c, n, "first_edit_content");
        if ((f == null ? void 0 : f.unstoredDbMsg) == null) {
            d("WALogger").ERROR(j());
            return null
        }
        var o = f.unstoredDbMedia,
            p = f.unstoredDbMsg;
        e = f.unstoredXMA;
        var s = {
                author: m,
                chat: b,
                externalId: n
            },
            t;
        (e == null ? void 0 : e.unstoredDbXMA) != null && (t = {
            associatedMessage: null,
            defaultPreview: null,
            favicon: null,
            header: null,
            previews: null,
            xma: e.unstoredDbXMA
        });
        var u = {
            frankingKey: null,
            frankingTag: null,
            frankingVersion: null,
            reportingContent: null,
            reportingTag: null
        };

        function v() {
            try {
                return {
                    decryptedProtobuf: d("EncryptedBackupsUploadEntity").getEbBackupMessageBytesBuffer(d("EncryptedBackupsUploadEntity").encodeBackupMessage({
                        messageApplication: d("MAWAsMessageApplication").encodeMessageApplication(p, o, null, t, b),
                        msgId: s,
                        reportingMeta: u,
                        sortOrderMs: l
                    })),
                    protobufTimestampMS: l
                }
            } catch (a) {
                d("WALogger").WARN(i(), a);
                return null
            }
        }
        g = v();
        if (g == null) return null;
        var x = new Map();
        r(n, b, m, a.editHistory).map(function(a) {
            return (a = a.decodedMsg) == null ? void 0 : a.unstoredDbEditActionMsg
        }).filter(Boolean).filter(function(a) {
            return a.externalId !== a.originalMsgExternalId
        }).filter(Boolean).map(function(a) {
            return d("MAWBulkEditMsgsTxns").getMessageHistory(a, b)
        }).forEach(function(a, c) {
            var e = a.editExternalId,
                f = a.editTs;
            e = ((e = e) != null ? e : c) + ":" + f.toString();
            x.set(d("MessageBackupSupplementalKeyGenerator").createMessageSupplementalKey(d("MessageBackupSupplementalKeyGenerator").SupplementalKeyPrefix.EDIT, e), {
                decryptedProtobuf: d("EncryptedBackupsUploadEntity").getEbBackupMessageBytesBuffer(d("EncryptedBackupsUploadEntity").encodeBackupMessage({
                    messageApplication: d("MAWAsMessageApplication").encodeEditMessageApplication(a),
                    msgId: {
                        author: m,
                        chat: b,
                        externalId: n
                    },
                    reportingMeta: u,
                    sortOrderMs: d("WATimeUtils").castUnixTimeToMillisTime(a.editTs)
                })),
                protobufTimestampMS: d("WATimeUtils").castUnixTimeToMillisTime(f)
            })
        });
        q(a, b, c, n, m).map(function(a) {
            return (a = a.decodedMsg) == null ? void 0 : a.unstoredDbReaction
        }).filter(Boolean).forEach(function(a) {
            var c = a.author,
                e = a.senderTimestampMs,
                f = a.ts;
            e = e != null ? d("WATimeUtils").castToMillisTime(d("WALongInt").numberOrThrowIfTooLarge(e)) : d("WATimeUtils").castUnixTimeToMillisTime(f);
            f = d("MessageBackupSupplementalKeyGenerator").createReactionSupplementalKey(c);
            if (f == null) {
                d("WALogger").ERROR(h());
                return
            }
            x.set(f, {
                decryptedProtobuf: d("EncryptedBackupsUploadEntity").getEbBackupMessageBytesBuffer(d("EncryptedBackupsUploadEntity").encodeBackupMessage({
                    messageApplication: d("MAWAsMessageApplication").encodeReactionMessageApplication(a),
                    msgId: {
                        author: m,
                        chat: b,
                        externalId: n
                    },
                    reportingMeta: u,
                    sortOrderMs: e
                })),
                protobufTimestampMS: e
            })
        });
        return {
            otid: n,
            supplementalProtobufs: x,
            toplevelProtobuf: g
        }
    }
    g.convertEchoMessages = a;
    g.safeDecodeEchoMessage = x;
    g.convertEchoMessagesToEBProtobufs = b
}), 98);
__d("MAWHandlePointRestoredMsgV2", ["EBUploadMessages", "MAWEBUploadTrackingUtils", "MAWEncryptedBackupCacheManager", "MAWGetMsgQuoteTxn", "Promise", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Completed handling of point restored message"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Completed handling of point restored message"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Started handling of point restored message"]);
        k = function() {
            return a
        };
        return a
    }

    function a(a) {
        d("WALogger").LOG(k());
        a = a.restoredMsgsData;
        if (a) {
            var c = a.existingMsgs;
            a = a.newlyAddedMsgs;
            a = a.concat(c);
            var e = [],
                f = new Map(),
                g = [],
                l = new Map();
            a.filter(function(a) {
                return d("MAWEncryptedBackupCacheManager").checkForMsgEntryInReuploadCache(a.threadJid, a.externalId)
            }).forEach(function(a) {
                e.push(a);
                g.push(a.externalId);
                var b = d("MAWEBUploadTrackingUtils").genInstanceKeyOnly();
                l.set(a.externalId, b);
                d("MAWEBUploadTrackingUtils").startUploadTracking(a.externalId, a.type, "pointrestore", b)
            });
            c = d("MAWGetMsgQuoteTxn").maybeBatchGetMsgsByQuoteExternalIdWithTransaction(g);
            return c.then(function(a) {
                a.forEach(function(a) {
                    var b = a.quoteExternalId;
                    b != null && f.set(b, a)
                });
                return e.length > 0 ? d("EBUploadMessages").uploadUniqueMessage(e, f, void 0, void 0, l, void 0, "point_restore").then(function(a) {
                    e.forEach(function(a) {
                        d("MAWEncryptedBackupCacheManager").removeMsgEntryFromReuploadCache(a.threadJid, a.externalId)
                    })
                }) : (h || (h = b("Promise"))).resolve()
            }).then(function(a) {
                d("WALogger").LOG(j())
            })
        }
        d("WALogger").LOG(i());
        return (h || (h = b("Promise"))).resolve()
    }
    g.uploadPointRestoredMessageIfRequired = a
}), 98);
__d("MAWRestoreMsgsUiUpdator", ["MAWBridgeEventTransmitter", "MAWDbMsg", "MAWDbThread", "MAWDexieTable", "MAWFolderTypes", "MAWThreadSnippetBuildTxns", "emptyFunction", "gkx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f, g, j, l, m, n, o, p, q, r) {
        j = h(a, j, e, f, g, m, n);
        return j.then(function(c) {
            if (n == null || l) {
                var e = k(c);
                e && d("MAWBridgeEventTransmitter").updateThreadOutsideTxn(c.cannotReplyReason, d("MAWFolderTypes").FOLDER_ID.INBOX, c.jid);
                return i(a, b, c, o, p, q, n).then(function() {
                    return c
                })
            }
            return c
        }).then(function(b) {
            return d("MAWThreadSnippetBuildTxns").refreshThreadSnippet(a, b, r)
        }).then(c("emptyFunction"))
    }

    function h(a, b, c, e, f, g, h) {
        var i = babelHelpers["extends"]({}, b, {
            lastReadMsg: g,
            lastReadMsgTs: f,
            newestMsg: c,
            newestMsgTs: e,
            oldestMsg: h,
            threadOrder: d("MAWDbThread").craftThreadOrder(e, b.jid)
        });
        return a.threads.put(i).then(function() {
            return i
        })
    }

    function i(a, b, e, f, g, h, i) {
        var k = b.map(function(a) {
                return a
            }).reverse(),
            l = e.jid;
        if (f != null) {
            b = d("MAWDbMsg").toMsgId(f);
            if (b != null) return a.messages.get({
                msgId: b
            }).then(function(b) {
                if (b != null) {
                    b = b.sortOrderMs;
                    var f;
                    c("gkx")("23906") || c("qex")._("1016") ? f = d("MAWDexieTable").dexieResolve(0) : f = a.messages.where(["threadJid", "sortOrderMs"]).between([l, k[0].sortOrderMs], [l, b], !1, !1).count();
                    return f.then(function(a) {
                        a === 0 && (j(k, g, e), d("MAWBridgeEventTransmitter").issueMsgLoadedEventAfterTxn(e.jid, k, i === null, h, !1))
                    })
                }
            })
        }
        d("MAWBridgeEventTransmitter").issueMsgLoadedEventAfterTxn(e.jid, k, i === null, h, !1);
        return d("MAWDexieTable").dexieResolve()
    }

    function j(a, b, c) {
        var e = b == null ? void 0 : b.sortOrderMs,
            f = a[a.length - 1],
            g = f.sortOrderMs;
        b != null && f != null && e != null && g != null && e < g && (a.push(b), d("MAWBridgeEventTransmitter").deleteMessageRangesV2AfterTxn(b.msgId, d("MAWDbMsg").getSortOrderWithFallback(b), c.jid))
    }

    function k(a) {
        return a.archived === !0 && a.cannotReplyReason !== "viewer_not_subscribed"
    }
    g.updateThreadAndMessages = a;
    g.shouldThreadBeUnarchived = k
}), 98);
__d("MAWRestoreMsgsTxns", ["ArmadilloDataTraceType", "FBLogger", "LSMEBTaskCreationSource", "MAWBridgeEventTransmitter", "MAWBridgeTypesCreators", "MAWDbMsg", "MAWDbMsgTxns", "MAWDexieTable", "MAWFTSTxns", "MAWIndexedDb", "MAWLocalizationType", "MAWMessageHasUniqueExternalIdValidator", "MAWMsgType", "MAWQplProxy", "MAWRestoreMsgsUiUpdator", "MAWTimeUtils", "MAWTransactionMode", "WAHashStringToNumber", "WAJids", "WALogger", "WATimeUtils", "emptyFunction", "gkx", "justknobx", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to create restored messages and update thread metadata ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Thread with jid ", " does not exist for restore"]);
        i = function() {
            return a
        };
        return a
    }

    function j(a, b, c) {
        return c != null ? a.messages.where(["threadJid", "sortOrderMs"]).between([b.jid, c.ts], [b.jid, d("MAWDbMsg").MAX_MSG_SORT_ORDER], !1, !0).limit(1).first() : d("MAWDexieTable").dexieResolve()
    }

    function a(a, b, c) {
        return d("MAWDbMsgTxns").maybeGetMsg(a, c).then(function(c) {
            if (c != null) return a.messages.where(["threadJid", "sortOrderMs"]).between([b.jid, c.sortOrderMs], [b.jid, d("MAWDbMsg").MAX_MSG_SORT_ORDER], !1, !0).limit(1).first();
            else return d("MAWDexieTable").dexieResolve()
        })
    }

    function k(a) {
        return a != null && a.type === d("MAWMsgType").MSG_TYPE.ADMIN && (a.msgContent.adminType === d("MAWLocalizationType").LOCALIZATION_TYPE.E2EE_THREAD_DESCRIPTION || a.msgContent.adminType === d("MAWLocalizationType").LOCALIZATION_TYPE.CUTOVER_THREAD_ADMIN_MESSAGE || a.msgContent.adminType === d("MAWLocalizationType").LOCALIZATION_TYPE.CUTOVER_IGD_THREAD_ADMIN_MESSAGE || a.msgContent.adminType === d("MAWLocalizationType").LOCALIZATION_TYPE.DUAL_THREAD_CUTOVER_ADMIN_MESSAGE)
    }
    var l = (e = d("MAWIndexedDb")).makeMsgrTransactor({
        messages: (f = d("MAWTransactionMode")).READONLY
    }, "checkForDecryptionFailuresToPointRestore", function(a) {
        return function() {
            return a.messages.filter(function(a) {
                return a.type === d("MAWMsgType").MSG_TYPE.UNAVAILABLE || a.type === d("MAWMsgType").MSG_TYPE.CIPHERTEXT
            }).toArray().then(function(a) {
                a.forEach(function(a) {
                    a.threadJid != null && d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(a.externalId, d("WAJids").threadIdForChatJid(a.threadJid), void 0, c("LSMEBTaskCreationSource").EB_POINT_QUERY_RETRY_DECRYPTION_FAILURES, a.threadJid)
                })
            })
        }
    });

    function m(a, b, c, e, f, g, h, i, j, k) {
        var l = g.isOldestMsgUpdated,
            m = g.lastReadMsg,
            n = g.lastReadMsgTs,
            p = g.newestMsgId,
            q = g.newestMsgTs;
        g = g.oldestMsgId;
        var r = !0;
        b && (r = o(q, e));
        b = d("MAWDexieTable").dexieResolve();
        r && (f.length > 0 && (b = d("MAWRestoreMsgsUiUpdator").updateThreadAndMessages(a, f, p, q, n, c, l, m, g, h, i, j, k)));
        return b.then(function() {
            return d("MAWDexieTable").dexieResolve()
        })
    }

    function b(a) {
        var b = a.bumpMessageAuthorMap,
            e = a.existingMsgs,
            f = a.hasMoreBefore,
            g = a.instanceKey,
            h = a.isPointRestore,
            i = a.maybeNewestMsg,
            j = a.maybeOldestAdminMsg,
            k = a.maybeOldestMsg,
            l = a.minMsgId,
            m = a.newMsgs,
            n = a.optimisticMsgs,
            o = a.shouldSkipSyncToUI,
            p = a.taskSource;
        a = a.thread;
        p = p === c("LSMEBTaskCreationSource").EB_POINT_QUERY_RETRY_DECRYPTION_FAILURES;
        var q = new Map(),
            r = [];
        e.map(function(a) {
            a.type === d("MAWMsgType").MSG_TYPE.UNAVAILABLE || a.type === d("MAWMsgType").MSG_TYPE.CIPHERTEXT ? r.push(a) : q.set(a.externalId, a)
        });
        var s = [];
        return x(m, e, a.jid, q, i, h, j, k, s, n, g, f, l, p, r, b, o).then(function(a) {
            return a
        })
    }

    function n(a, b, c) {
        a.altIndex !== d("MAWDbMsg").SPAM_ALT_INDEX && a.altIndex !== d("MAWDbMsg").FUTUREPROOF_SPAM_ALT_INDEX && (d("MAWBridgeEventTransmitter").startTraceOutsideTxn(a, b, d("ArmadilloDataTraceType").armadilloMessageSend), d("MAWBridgeEventTransmitter").issueNewMsgUiEventOutsideTxn(a, c))
    }

    function o(a, b) {
        return a == null ? !0 : b.some(function(b) {
            return b.sortOrderMs != null && b.sortOrderMs >= a
        })
    }
    var p = e.makeMsgrTransactor({
            messages: f.READONLY
        }, "getMsgsByProtocolMsgIds", function(a) {
            return function() {
                for (var b = arguments.length, c = new Array(b), e = 0; e < b; e++) c[e] = arguments[e];
                return d("MAWDbMsgTxns").getMsgsByProtocolMsgId.apply(void 0, [a].concat(c))
            }
        }),
        q = e.makeMsgrTransactor({
            messages: f.READONLY
        }, "restoreGetMsg", function(a) {
            return function(b) {
                return d("MAWDbMsgTxns").maybeGetMsg(a, b)
            }
        }),
        r = e.makeMsgrTransactor({
            messages: f.READONLY
        }, "restoreGetThreadNewestMessage", function(a) {
            return function(b) {
                return d("MAWDbMsgTxns").getThreadNewestMessageBySortOrder(a, b.jid)
            }
        }),
        s = e.makeMsgrTransactor({
            messages: f.READONLY
        }, "restoreMaybeGetOldestNonAdminMessage", function(a) {
            return function(b) {
                return d("MAWDbMsgTxns").getThreadOldestMessageBySortOrder(a, b.jid).then(function(c) {
                    if (c == null) return d("MAWDexieTable").dexieResolve({
                        maybeOldestAdminMsg: null,
                        maybeOldestMsg: null
                    });
                    else if (k(c)) return j(a, b, c).then(function(a) {
                        return {
                            maybeOldestAdminMsg: c,
                            maybeOldestMsg: a
                        }
                    });
                    return {
                        maybeOldestAdminMsg: null,
                        maybeOldestMsg: c
                    }
                })
            }
        });

    function t(a, b, e, f, g, h, i, j, l) {
        return d("MAWDexieTable").dexieAll(b.map(function(b) {
            return d("MAWDbMsgTxns").maybeGetMsgByExternalId(a, b.externalId, e.jid, b.author).then(function(a) {
                if (a != null) return;
                a = f.get(b.externalId);
                if (a == null) {
                    a = d("WATimeUtils").castUnixTimeToMillisTime(b.ts);
                    j.newestMsgTs = a > j.newestMsgTs ? a : j.newestMsgTs;
                    var c = d("MAWDbMsg").craftMsgIdV2(e.chatId, j.msgNextInChatMsgId, b);
                    j.msgNextInChatMsgId += 1;
                    (j.oldestMsgId == null || !h && a < j.oldestMsgTs) && (j.isOldestMsgUpdated = !0, j.oldestMsgId = i != null && d("WATimeUtils").castUnixTimeToMillisTime(i.ts) < a ? i.msgId : c, j.oldestMsgTs = i != null && d("WATimeUtils").castUnixTimeToMillisTime(i.ts) < a ? d("WATimeUtils").castUnixTimeToMillisTime(i.ts) : a);
                    (j.newestMsgTs === a || k(g)) && (j.newestMsgId = c);
                    b.author === d("WAJids").AUTHOR_ME && (j.lastReadMsgTs == null || a > j.lastReadMsgTs) && (j.lastReadMsg = c, j.lastReadMsgTs = a);
                    a = babelHelpers["extends"]({}, b, {
                        msgId: c,
                        sortOrderMs: d("MAWDbMsg").getSortOrderWithFallback(b)
                    });
                    l.push(a)
                }
            })
        })).then(c("emptyFunction"))
    }

    function u(a, b) {
        return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").getThreadNewestMessageId(a, b.jid), d("MAWDbMsgTxns").getThreadNewestMessageTs(a, b), d("MAWDbMsgTxns").getNextMsgIdNumberForThread(a, b)]).then(function(a) {
            var b = a[0],
                c = a[1];
            a = a[2];
            return {
                newestMsgId: b,
                newestMsgTs: c,
                nextInChatMsgId: a
            }
        })
    }

    function v(a, b, e, f, g, h, i, j, k, l, m) {
        return t(a, b, e, f, g, h, i, j, k).then(function(b) {
            if (l != null)
                for (b = 0; b < k.length; b++) {
                    var g = k[b],
                        i = g.externalId;
                    i = l.get(i);
                    i != null && (g.ts = d("WATimeUtils").castMilliSecondsToUnixTime(i.ts))
                }
            d("MAWMessageHasUniqueExternalIdValidator").logMessageAddSource(k.map(function(a) {
                return a.externalId
            }), "MAWRestoreMsgsTxns.js::createRestoredMessages", {
                isPointRestore: h == null ? void 0 : h.toString()
            });
            var j = c("justknobx")._("3227") ? k.map(function(a) {
                return babelHelpers["extends"]({}, a, {
                    source: m === !0 ? "media_restore" : "eb_restore"
                })
            }) : k;
            return d("MAWDexieTable").dexieAll([a.messages.bulkAdd(j, {
                allKeys: !0
            }).then(function(a) {
                return a.map(function(a, b) {
                    return babelHelpers["extends"]({}, j[b], {
                        rowId: a
                    })
                })
            }), m !== !0 && c("justknobx")._("3227") ? a.messages.bulkPut(Array.from(f.values()).map(function(a) {
                return babelHelpers["extends"]({}, a, {
                    source: "eb_restore"
                })
            })) : d("MAWDexieTable").dexieResolve()]).then(function(b) {
                var c = b[0];
                return a.threads.put(e).then(function() {
                    return c
                })
            })
        })
    }

    function w(a, b, c) {
        b = b.map(function(a) {
            var b = c.find(function(b) {
                return b.externalId === a.externalId
            });
            if (b == null) return null;
            b = babelHelpers["extends"]({
                externalId: b.externalId,
                msgId: b.msgId,
                rowId: b.rowId
            }, a);
            return b
        }).filter(Boolean);
        return a.messages.bulkPut(b).then(function() {})
    }
    var x = e.makeMsgrTransactor({
        ftsBackloggedMessages: f.READWRITE,
        groupInfo: f.READWRITE,
        messages: f.READWRITE,
        threads: f.READWRITE
    }, "createRestoredMessagesAndUpdateThread", function(a) {
        return function(b, e, f, g, j, k, l, o, p, q, r, s, t, x, y, z, A) {
            return a.threads.get({
                jid: f
            }).then(function(r) {
                if (r == null) {
                    d("WALogger").ERROR(i(), f);
                    return d("MAWDexieTable").dexieResolve()
                }
                return u(a, r).then(function(f) {
                    var i = f.newestMsgId,
                        u = f.newestMsgTs;
                    f = f.nextInChatMsgId;
                    var x = {
                        isOldestMsgUpdated: !1,
                        lastReadMsg: r.lastReadMsg,
                        lastReadMsgTs: d("MAWTimeUtils").ensureValidMillisTime(r.lastReadMsgTs),
                        msgNextInChatMsgId: f,
                        newestMsgId: i,
                        newestMsgTs: d("MAWTimeUtils").ensureValidMillisTime(u) || d("WATimeUtils").castToMillisTime(0),
                        oldestMsgId: o == null ? void 0 : o.msgId,
                        oldestMsgTs: d("WATimeUtils").castUnixTimeToMillisTime((f = o == null ? void 0 : o.ts) != null ? f : d("WATimeUtils").castToUnixTime(0))
                    };
                    i = c("gkx")("1689") ? w(a, b, y) : d("MAWDexieTable").dexieResolve();
                    return i.then(function() {
                        return d("MAWDexieTable").dexieAll([v(a, b, r, g, j, k, l, x, p, q, A), d("MAWFTSTxns").maybePutMessagesToBacklog(a, b.map(function(a) {
                            return a.externalId
                        }))]).then(function(b) {
                            b = b[0];
                            if (A !== !0)
                                for (var c = b, f = Array.isArray(c), g = 0, c = f ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                    var h;
                                    if (f) {
                                        if (g >= c.length) break;
                                        h = c[g++]
                                    } else {
                                        g = c.next();
                                        if (g.done) break;
                                        h = g.value
                                    }
                                    h = h;
                                    n(h, r.jid, q)
                                }
                            h = e.concat(b);
                            var i = {
                                existingMsgs: e,
                                newlyAddedMsgs: b,
                                threadJid: r.jid
                            };
                            g = A !== !0 ? m(a, k, r, h, b, x, t, l, s, z) : d("MAWDexieTable").dexieResolve();
                            return g.then(function() {
                                return i
                            })
                        })["catch"](function(a) {
                            d("WALogger").ERROR(h(), a)
                        })
                    })
                })
            })
        }
    });
    g.getNextMsgBasedOnSortOrderMs = a;
    g.isE2eeOrCutoverAdminMsg = k;
    g.checkForDecryptionFailuresToPointRestore = l;
    g.restoreMsgsForThread = b;
    g.getMsgsByProtocolMsgIds = p;
    g.getMsg = q;
    g.maybeGetThreadNewestMessage = r;
    g.maybeGetOldestNonAdminMessage = s;
    g.prepareUnstoredMsgArrayAndUpdateKeyVariables = t
}), 98);
__d("MAWRestoreValidationUtils", ["MAWEBRestoreTrackingUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return a.reduce(function(a, b) {
            if (b.externalId != null) {
                a[b.externalId] = ((b = a[b.externalId]) != null ? b : 0) + 1;
                return a
            }
            return a
        }, {})
    }

    function a(a) {
        var b = a.dbMsgArray,
            c = a.deanonData,
            e = a.echoMsgExternalIds,
            f = a.protobufMsgs,
            g = a.restoreQplFlow;
        a = a.traceId;
        var i = h(b);
        if (f == null && e == null) return;
        b = f != null ? f.map(function(a) {
            return {
                externalId: a.otid
            }
        }) : e != null ? e : [];
        f = h(b);
        e = [];
        b = [];
        var j = [];
        if (c != null) {
            var k = h(c);
            e = Object.keys(i).filter(function(a) {
                return !k[a]
            });
            b = Object.keys(k).filter(function(a) {
                return !i[a]
            });
            j = Object.entries(k).filter(function(a) {
                a[0];
                a = a[1];
                return a > 1
            })
        }
        c = Object.keys(f).filter(function(a) {
            return !i[a]
        });
        var l = Object.entries(i).filter(function(a) {
            a[0];
            a = a[1];
            return a > 1
        });
        f = Object.entries(f).filter(function(a) {
            a[0];
            a = a[1];
            return a > 1
        });
        j = {
            "int": {
                duplicates_in_deanon_reference: j.length,
                duplicates_in_restore_request: f.length,
                duplicates_in_restored_messages: l.length,
                missing_in_deanon_reference: e.length,
                missing_in_restore_request: c.length,
                missing_in_restored_messages: b.length
            }
        };
        g == null ? void 0 : g.addPoint("restore_validation", j);
        d("MAWEBRestoreTrackingUtils").addQPLRestorePointWithAnnotationsWorker({
            annotations: j,
            pointName: "restore_validation",
            traceId: a
        });
        return j
    }
    g.compareRestoredMsgstoDeanonData = a
}), 98);
__d("MAWWriteReceiverFetchTxns", ["FBLogger", "MAWBridgeReceiverFetchInfo", "MAWDbReceiverFetchTxns", "MAWDexieTable", "MAWIndexedDb", "WALogger", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Receiver fetch info not found for receiver fetch id: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b, e) {
        return d("MAWDbReceiverFetchTxns").maybeGetReceiverFetchInfoFromReceiverFetchId(a, e.receiverFetchId).then(function(f) {
            if (f == null) return a.receiverFetchInfo.add(e).then(function() {
                d("MAWIndexedDb").afterTransaction({
                    tag: "NewReceiverFetchInfo",
                    value: d("MAWBridgeReceiverFetchInfo").createBridgeReceiverFetchInfoPayloadFromUnstoredInfo(b, e)
                })
            })["catch"](function(a) {
                c("FBLogger")("messenger_web_media").mustfix("Failed to add receiver fetch info to db, error: %s", a.message)
            });
            else {
                var g = babelHelpers["extends"]({}, f, e);
                return a.receiverFetchInfo.update(e.receiverFetchId, g).then(function() {
                    d("MAWIndexedDb").afterTransaction({
                        tag: "NewReceiverFetchInfo",
                        value: d("MAWBridgeReceiverFetchInfo").createBridgeReceiverFetchInfoPayloadFromDbInfo(b, g)
                    })
                })["catch"](function(a) {
                    c("FBLogger")("messenger_web_media").mustfix("Failed to update receiver fetch info in db, error: %s", a.message)
                })
            }
        })
    }

    function b(a, b, e, f) {
        return d("MAWDbReceiverFetchTxns").maybeGetReceiverFetchInfoFromReceiverFetchId(a, f).then(function(g) {
            if (g == null) {
                d("WALogger").ERROR(h(), f);
                return d("MAWDexieTable").dexieResolve()
            } else {
                g = babelHelpers["extends"]({}, g, {
                    previewUrl: b,
                    previewUrlExpirationTimestampMs: e
                });
                return a.receiverFetchInfo.update(f, g).then(c("emptyFunction"))["catch"](function(a) {
                    c("FBLogger")("messenger_web_media").mustfix("Failed to update receiver fetch info in db, error: %s", a.message)
                })
            }
        })
    }
    g.handleUnstoredReceiverFetchInfo = a;
    g.updateReceiverFetchInfoWithPreviewUrl = b
}), 98);
__d("MAWHandleEchoMsgsRestoreApiV2", ["EchoBackupCompareUtils", "EchoMessage", "LSDataTraceCheckPoint", "LSIntEnum", "LSMEBTaskCreationSource", "MAWAckLevel", "MAWBridgeEventTransmitter", "MAWCiphertextRecoveryLogging", "MAWDbEditMsgHistoryTxns", "MAWDbMsg", "MAWDbThreadTxns", "MAWDexieTable", "MAWEncryptedBackupCacheManager", "MAWHandleEchoMediaMsgsRestoreV2", "MAWHandleEchoMsgsRestoreApiUtils", "MAWHandleEchoReactionsRestore", "MAWHandleEchoXMARestoreV2", "MAWHandlePendingStanzasInRestoreV2", "MAWHandlePointRestoredMsgV2", "MAWIndexedDb", "MAWJids", "MAWMediaGalleryM2Utils", "MAWMsgType", "MAWQplProxy", "MAWRepliesRestoreUtils", "MAWRestoreMsgsTxns", "MAWRestoreValidationUtils", "MAWTraceUtils", "MAWTransactionMode", "MAWWriteReceiverFetchTxns", "Promise", "WAGlobals", "WAJids", "WAResultOrError", "WAStanzaUtils", "WATagsLogger", "WATimeUtils", "asyncToGeneratorRuntime", "gkx", "justknobx", "promiseDone", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Oldest message timestamp: ", " and newest message timestamp: ", " of the batch for thread: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] No more messages to restore for thread: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Ignore duplicate restore request of an existing message"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Message ID must not be null"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to decode the message"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] No messages to be restored for thread: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Not a supported receiver fetch type: ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] timestamp field should not be null as it is required for attachment download retry: ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] timestamp field should not be null as it is required for attachment download retry: ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] from field is missing from media message: ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] from field is missing from media message: ", ""]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Media data is null for the message: ", ""]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Media data is null for the message: ", ""]);
        v = function() {
            return a
        };
        return a
    }

    function w() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Echo message is missing from the map: ", ""]);
        w = function() {
            return a
        };
        return a
    }

    function x() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Echo message is missing from the map: ", ""]);
        x = function() {
            return a
        };
        return a
    }

    function y() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missed restoring optimistic messages for thread: ", " count: ", " }"]);
        y = function() {
            return a
        };
        return a
    }

    function z() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] threadJidPrimaryId ", " missing from index db"]);
        z = function() {
            return a
        };
        return a
    }

    function A() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing thread for thread jid: ", ""]);
        A = function() {
            return a
        };
        return a
    }

    function B() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Error while restoring media/reaction: ", ""]);
        B = function() {
            return a
        };
        return a
    }

    function C() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] handleEchoMsgsRestore v2 completed. newlyAdded: ", " existing: ", " isPointRestore: ", ""]);
        C = function() {
            return a
        };
        return a
    }

    function D() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Error while deleting point restored messages: ", ""]);
        D = function() {
            return a
        };
        return a
    }

    function E() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Message creation complete. MessagesCreated: ", " isPointRestore: ", " startSortKey: ", " taskSource: ", ""]);
        E = function() {
            return a
        };
        return a
    }

    function F() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Low level api handleEchoMsgsRestore v2 initiated restore of ", " messages. isPointRestore: ", " startSortKey: ", " taskSource: ", ""]);
        F = function() {
            return a
        };
        return a
    }
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f, g, j, k, l, m, n, o, p, q, r, s, t) {
            d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (j = l) != null ? j : ""]).LOG(F(), e.length, f, m, p);
            j = f ? d("MAWHandleEchoMsgsRestoreApiUtils").MAWRestoreType.POINT_RESTORE : m != null ? d("MAWHandleEchoMsgsRestoreApiUtils").MAWRestoreType.PAGINATED_RESTORE : d("MAWHandleEchoMsgsRestoreApiUtils").MAWRestoreType.INITIAL_RESTORE;
            j = j;
            var u = q != null ? q : d("MAWQplProxy").startQplUserFlow(c("qpl")._(521486220, "827"), {
                bool: {
                    uploadedFromEBQueue: s
                },
                "int": {
                    messages: e.length
                },
                string: {
                    message_backup_type: "echo",
                    restore_type: j,
                    trace_id: (q = l) != null ? q : ""
                }
            }, void 0, 3e5);
            d("MAWTraceUtils").recordCheckpointForTrace(l, (i || (i = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_ECHO_MESSAGE_RESTORE_BEGIN), [], !1);
            var v = (yield L(a, l)),
                w = {
                    messageIds: [],
                    pendingRestoreSortKeys: []
                };
            if (v) {
                s = G(v, e, f, g, u, k, n, o, l, p, r, t);
                var x = a;
                return s.then(function(g) {
                    var j, k = ((j = g.restoredMsgsData) == null ? void 0 : j.newlyAddedMsgs) ? (j = g.restoredMsgsData) == null ? void 0 : j.newlyAddedMsgs.length : 0;
                    d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (j = l) != null ? j : ""]).LOG(E(), k, f, m, p);
                    O(a, g, n, o);
                    return (h || (h = b("Promise"))).all([M(g, u, c("justknobx")._("3060") && t), N(g, u, l, t), d("MAWHandleEchoReactionsRestore").writeEchoReactionsToReactionsStore(g, d("WAGlobals").getMyUserJid(), u, c("justknobx")._("3060") && t), R(x, g, v == null ? void 0 : v.jid)]).then(function(j) {
                        d("MAWEncryptedBackupCacheManager").setRestoredCacheStatusAsDone(Array.from(g.echoMsgMap.keys()));
                        return (h || (h = b("Promise"))).all([d("MAWRepliesRestoreUtils").updateQuoteDataForReplyMessages(g, u, c("justknobx")._("3060") && t), d("MAWHandleEchoXMARestoreV2").writeXMAToXMAStore(g, u, l, c("justknobx")._("3060") && t), c("gkx")("2251") ? d("MAWHandlePendingStanzasInRestoreV2").applyPendingStanzas(g, f, u) : d("MAWDexieTable").dexieResolve(), c("gkx")("5624") ? S(g, u) : d("MAWDexieTable").dexieResolve()]).then(function() {
                            c("promiseDone")(d("MAWHandlePointRestoredMsgV2").uploadPointRestoredMessageIfRequired(g));
                            var j = g.restoredMsgsData;
                            if (f && j != null) {
                                var m = p === c("LSMEBTaskCreationSource").EB_POINT_QUERY_RETRY_DECRYPTION_FAILURES || c("gkx")("1560") || c("gkx")("4991");
                                m || I(j.newlyAddedMsgs)["catch"](function(a) {
                                    var b;
                                    d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (b = l) != null ? b : ""]).ERROR(D(), a)
                                })
                            }
                            m = g.restoredMsgsData;
                            j = (m == null ? void 0 : m.existingMsgs) ? m == null ? void 0 : m.existingMsgs.length : 0;
                            m = e.length;
                            u.endSuccess({
                                "int": {
                                    existingMsgs: j,
                                    messages_lost: e.length - j - k,
                                    newlyAddedMsgs: k,
                                    restoredMsgs: j + k,
                                    totalMsgsToRestore: m
                                },
                                string: {
                                    threadJidPrimaryId: a
                                }
                            });
                            d("MAWTraceUtils").recordCheckpointForTrace(l, (i || (i = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_RESTORE_MESSAGES_SUCCESS), [], !1);
                            d("MAWTraceUtils").recordCheckpointForTrace(l, i.ofNumber(c("LSDataTraceCheckPoint").FLOW_END_AND_FLUSH), [], !0);
                            g.quotesToBeRestored.forEach(function(a) {
                                w.messageIds.push(a.messageId), w.pendingRestoreSortKeys.push(a.sortOrderMs)
                            });
                            d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (m = l) != null ? m : ""]).LOG(C(), k, j, f);
                            return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult(w))
                        })
                    })["catch"](function(a) {
                        var c;
                        d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (c = l) != null ? c : ""]).ERROR(B(), a);
                        u.endFail("error_in_handle_media_or_reaction");
                        return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult(w))
                    })
                })
            } else {
                u.endFail("missing_thread_for_thread_jid");
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (j = l) != null ? j : ""]).ERROR(A(), a);
                O(a, null, n, o)
            }
            return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult(w))
        });
        return function(b, c, d, e, f, g, h, i, j, k, l, m, n, o, p) {
            return a.apply(this, arguments)
        }
    }();

    function G(a, b, c, d, e, f, g, h, i, j, k, l) {
        return H.apply(this, arguments)
    }

    function H() {
        H = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f, g, i, j, k, l, m, n, o, p) {
            i == null ? void 0 : i.addPoint("message_restore_start");
            var q = new Map(),
                r = [];
            e = (yield J(e, f, a, q, g, i, m));
            var s = e.dbThread,
                t = e.hasMoreBefore,
                u = e.messagesToAdd;
            g = e.quotesToBeRestoredForThread;
            r.push.apply(r, g);
            e = u.map(function(b) {
                return {
                    author: b.author,
                    chat: a.jid,
                    externalId: d("WAStanzaUtils").toStanzaId(b.externalId)
                }
            });
            return (h || (h = b("Promise"))).all([d("MAWRestoreMsgsTxns").maybeGetThreadNewestMessage(a), d("MAWRestoreMsgsTxns").maybeGetOldestNonAdminMessage(a), d("MAWRestoreMsgsTxns").getMsgsByProtocolMsgIds(e)]).then(function(a) {
                var b = a[0],
                    e = a[1],
                    g = e.maybeOldestAdminMsg;
                e = e.maybeOldestMsg;
                a = a[2];
                var h = new Set(a.filter(function(a) {
                        return !c("gkx")("1689") || a.type !== d("MAWMsgType").MSG_TYPE.CIPHERTEXT
                    }).map(function(a) {
                        return a.externalId
                    })),
                    v = u.filter(function(a) {
                        return !h.has(a.externalId)
                    });
                d("MAWCiphertextRecoveryLogging").compareAndLogCiphertextRecoveredByEB(a, u);
                b = {
                    existingMsgs: a,
                    hasMoreBefore: t,
                    instanceKey: k,
                    isPointRestore: f,
                    maybeNewestMsg: b,
                    maybeOldestAdminMsg: g,
                    maybeOldestMsg: e,
                    minMsgId: j,
                    newMsgs: v,
                    optimisticMsgs: l,
                    shouldSkipSyncToUI: c("justknobx")._("3060") && p === !0 && d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled(),
                    taskSource: n,
                    thread: s,
                    traceId: m
                };
                var w = [];
                a.forEach(function(a) {
                    return w.push({
                        externalId: a.externalId
                    })
                });
                v.forEach(function(a) {
                    return w.push({
                        externalId: a.externalId
                    })
                });
                return d("MAWRestoreMsgsTxns").restoreMsgsForThread(b).then(function(a) {
                    var b = [];
                    (a == null ? void 0 : a.existingMsgs) != null && (b = b.concat(a == null ? void 0 : a.existingMsgs));
                    (a == null ? void 0 : a.newlyAddedMsgs) != null && (b = b.concat(a == null ? void 0 : a.newlyAddedMsgs));
                    i == null ? void 0 : i.addPoint("message_restore_end");
                    o != null && !f && d("MAWRestoreValidationUtils").compareRestoredMsgstoDeanonData({
                        dbMsgArray: b,
                        deanonData: o,
                        echoMsgExternalIds: w,
                        protobufMsgs: void 0,
                        restoreQplFlow: i,
                        traceId: m
                    });
                    return {
                        echoMsgMap: q,
                        quotesToBeRestored: r,
                        restoredMsgsData: a,
                        thread: s
                    }
                })
            })
        });
        return H.apply(this, arguments)
    }
    var I = (e = d("MAWIndexedDb")).makeMsgrTransactor({
        messages: (f = d("MAWTransactionMode")).READWRITE
    }, "restoreDeleteMessages", function(a) {
        return function(b) {
            var c = [];
            for (var d = 0; d < b.length; d++) c.push(b[d].rowId);
            return a.messages.bulkDelete(c)
        }
    });

    function J(a, b, c, d, e, f, g) {
        return K.apply(this, arguments)
    }

    function K() {
        K = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e, f, g, h) {
            var i = new Set(),
                p = new Map(),
                q = [];
            if (a == null || a.length === 0) {
                var r;
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (r = h) != null ? r : ""]).WARN(o(), c.jid);
                return {
                    dbThread: c,
                    hasMoreBefore: !1,
                    messagesToAdd: [],
                    quotesToBeRestoredForThread: q
                }
            }
            var s = 0,
                t = [];
            a.forEach(function(a) {
                a = d("EchoMessage").decodeEchoMessage(a);
                if (a == null) {
                    var b;
                    d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (b = h) != null ? b : ""]).ERROR(n());
                    return
                }
                a.contentType === d("EchoMessage").EchoMessageContentType.DECRYPTION_FAILURE && s++;
                b = a.xOfflineThreadingId;
                if (b == null) {
                    var c;
                    d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (c = h) != null ? c : ""]).ERROR(m());
                    return
                }
                if (i.has(b)) {
                    d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (c = h) != null ? c : ""]).WARN(l());
                    return
                }
                i.add(b);
                t.push(a)
            });
            s === a.length && (g == null ? void 0 : g.addPoint("decryption_failure_batch", {
                "int": {
                    decryptionFailuresCount: s
                }
            }));
            t.forEach(function(a) {
                if (a.xOfflineThreadingId == null) return;
                var b = d("WAStanzaUtils").toStanzaId(a.xOfflineThreadingId),
                    f = d("MAWHandleEchoMsgsRestoreApiUtils").getUnstoredDbMessageFromEchoMessage(a, c.jid, d("WAGlobals").getMyUserJid(), b, h, "echo_content");
                if (f != null) {
                    d("MAWEncryptedBackupCacheManager").addMsgEntryToRestoredCache(b, d("EchoBackupCompareUtils").buildEchoDocCacheValue(a));
                    p.set(b, f);
                    e.set(b, a);
                    a = a == null ? void 0 : a.quoteData;
                    if (a != null) {
                        var g = d("WAStanzaUtils").toStanzaId(a.quoteMessageId);
                        if (g != null && !p.has(g)) q.push({
                            messageId: a.quoteMessageId,
                            sortOrderMs: a.quoteSortOrderInMs.toString()
                        });
                        else {
                            a = d("MAWRepliesRestoreUtils").addQuoteDataToReplyMessage(f, p.get(g));
                            p.set(b, a)
                        }
                    }
                }
            });
            r = Array.from(p.values());
            r.sort(function(a, b) {
                return ((a = a.sortOrderMs) != null ? a : 0) - ((a = b.sortOrderMs) != null ? a : 0)
            });
            a = b || f !== !1;
            if (!a) {
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (g = h) != null ? g : ""]).LOG(k(), c.jid)
            }
            if (r.length > 0) {
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (b = h) != null ? b : ""]).LOG(j(), r[0].sortOrderMs, r[r.length - 1].sortOrderMs, c.jid)
            }
            return {
                dbThread: c,
                hasMoreBefore: a,
                messagesToAdd: r,
                quotesToBeRestoredForThread: q
            }
        });
        return K.apply(this, arguments)
    }
    var L = e.makeMsgrTransactor({
            threads: f.READONLY
        }, "restoreGetThread", function(a) {
            return function(b, c) {
                return d("MAWDbThreadTxns").getThreadPrimaryId(a, b).then(function(a) {
                    if (a.success) return a.value;
                    else {
                        d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (a = c) != null ? a : ""]).ERROR(z(), b);
                        return d("MAWDexieTable").dexieResolve()
                    }
                })
            }
        }),
        M = e.makeMsgrTransactor({
            editMsgHistory: f.READWRITE,
            messages: f.READWRITE
        }, "restoreEditMsgHistory", function(a) {
            return function(b, c, e) {
                c == null ? void 0 : c.addPoint("msg_history_start");
                var f = b.restoredMsgsData;
                if (f != null) {
                    var g = f.newlyAddedMsgs.map(function(c) {
                        var e = [],
                            g = c.externalId,
                            h = c.author,
                            i = f.threadJid;
                        c = b.echoMsgMap.get(g);
                        if (c != null) {
                            var j = c.editHistory;
                            return d("MAWDbEditMsgHistoryTxns").getEditHistoryAsEcho(a, g, h, i).then(function(b) {
                                if (b.length >= j.length) return d("MAWDexieTable").dexieResolve([]);
                                j.forEach(function(a) {
                                    return e.push({
                                        author: h,
                                        editExternalId: a.messageId != null ? d("WAStanzaUtils").toStanzaId(a.messageId) : null,
                                        editTs: d("WATimeUtils").castToUnixTime(a.timestamp),
                                        msgContent: {
                                            content: a.text
                                        },
                                        originalMsgExternalId: g,
                                        sendStatus: d("MAWAckLevel").ACK.sent,
                                        threadJid: i
                                    })
                                });
                                b.length > 0 && d("MAWDbEditMsgHistoryTxns").bulkRemoveEditHistory(a, g, h, i);
                                return d("MAWDexieTable").dexieResolve(e)
                            })
                        } else return d("MAWDexieTable").dexieResolve([])
                    });
                    return d("MAWDexieTable").dexieAll(g).then(function(b) {
                        return d("MAWDbEditMsgHistoryTxns").bulkAddEditMsgHistory(a, b.flat(), e != null ? !e : !0).then(function(a) {
                            return c == null ? void 0 : c.addPoint("msg_history_end")
                        })
                    })
                } else {
                    c == null ? void 0 : c.addPoint("msg_history_end");
                    return d("MAWDexieTable").dexieResolve()
                }
            }
        }),
        N = function(a, c, d, e) {
            c == null ? void 0 : c.addPoint("media_restore_start");
            return P(a, d, e).then(function(a) {
                c == null ? void 0 : c.addPoint("media_restore_end", {
                    "int": {
                        media: a
                    }
                });
                return (h || (h = b("Promise"))).resolve()
            })
        };

    function O(a, b, e, f, g) {
        if (e != null && c("gkx")("23961")) {
            var h, i;
            h = (h = b == null ? void 0 : (h = b.restoredMsgsData) == null ? void 0 : h.newlyAddedMsgs.length) != null ? h : 0;
            i = (i = b == null ? void 0 : (i = b.restoredMsgsData) == null ? void 0 : i.existingMsgs.length) != null ? i : 0;
            if (f != null && f.size > 0) {
                var j, k = new Set([].concat((b == null ? void 0 : (j = b.restoredMsgsData) == null ? void 0 : (j = j.newlyAddedMsgs) == null ? void 0 : j.map(function(a) {
                    return a.externalId
                })) || [], (b == null ? void 0 : (j = b.restoredMsgsData) == null ? void 0 : (b = j.existingMsgs) == null ? void 0 : b.map(function(a) {
                    return a.externalId
                })) || []));
                j = Array.from(f.keys()).reduce(function(a, b) {
                    return a + (k.has(b) ? 0 : 1)
                }, 0);
                if (j > 0) {
                    d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (b = g) != null ? b : ""]).WARN(y(), a, j);
                    d("MAWQplProxy").sendQPLFailThroughBridge(c("qpl")._(521482576, "1069"), "optimistic_msgs_missed_restore", {
                        "int": {
                            messages_backend_existing: i,
                            messages_backend_restored: h,
                            missed_message_count: j,
                            optimistic_msgs_count: f.size
                        }
                    }, e)
                } else d("MAWQplProxy").sendQPLSuccessThroughBridge(c("qpl")._(521482576, "1069"), {
                    "int": {
                        messages_backend_existing: i,
                        messages_backend_restored: h,
                        optimistic_msgs_count: f.size
                    }
                }, e)
            } else d("MAWQplProxy").sendQPLSuccessThroughBridge(c("qpl")._(521482576, "1069"), {
                "int": {
                    messages_backend_existing: i,
                    messages_backend_restored: h,
                    optimistic_msgs_count: 0
                }
            }, e)
        }
    }

    function P(a, c, e) {
        var f = a.restoredMsgsData,
            g = 0;
        if (f) {
            var i = f.existingMsgs.filter(function(a) {
                    return d("MAWDbMsg").isMediaMsg(a) && a.mediaId == null
                }),
                j = f.newlyAddedMsgs;
            i = [].concat(i, j);
            var k = f.threadJid,
                l = [];
            i.map(function(b) {
                var e = b.externalId;
                e = a.echoMsgMap.get(e);
                var f = (e == null ? void 0 : e.viewOnce) != null && (e == null ? void 0 : e.viewOnce);
                if (!f && (b.type !== d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH && (e == null ? void 0 : e.contentType) === d("EchoMessage").EchoMessageContentType.MEDIA || (e == null ? void 0 : e.contentType) === d("EchoMessage").EchoMessageContentType.XMA)) {
                    f = Q(k, b, a.echoMsgMap, (e == null ? void 0 : e.contentType) === d("EchoMessage").EchoMessageContentType.XMA, c);
                    f != null && (g += 1, l.push(f))
                }
            });
            return d("MAWHandleEchoMediaMsgsRestoreV2").downloadMediaAndWriteToMediaStore(l, a.thread.jid, e).then(function(a) {
                return g
            })
        }
        return (h || (h = b("Promise"))).resolve(g)
    }

    function Q(a, b, e, f, g) {
        e = e.get(b.externalId);
        if (e == null) {
            if (f) {
                var h;
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "xma", (h = g) != null ? h : ""]).WARN(x(), b.externalId)
            } else {
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "xma", (h = g) != null ? h : ""]).ERROR(w(), b.externalId)
            }
            return null
        }
        h = e.mediaData;
        if (h == null) {
            if (f) {
                var i;
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "media", (i = g) != null ? i : ""]).WARN(v(), e.messageId)
            } else {
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "media", (i = g) != null ? i : ""]).ERROR(u(), e.messageId)
            }
            return null
        }
        i = e.from;
        if (i == null) {
            if (f) {
                var j;
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "media", (j = g) != null ? j : ""]).WARN(t(), e.messageId)
            } else {
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "media", (j = g) != null ? j : ""]).ERROR(s(), e.messageId)
            }
            return null
        }
        j = e.sortOrderMs;
        if (j == null) {
            if (f) {
                var k;
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "media", (k = g) != null ? k : ""]).WARN(r(), e.messageId)
            } else {
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", "media", (k = g) != null ? k : ""]).ERROR(q(), e.messageId)
            }
            return null
        }
        g = d("MAWJids").toUserJid(i.localKey);
        k = g === d("WAGlobals").getMyUserJid() ? d("WAJids").AUTHOR_ME : g;
        i = b.externalId;
        g = b.msgId;
        b = {
            author: k,
            echoMsg: e,
            externalId: i,
            isXMA: f,
            messageTimestamp: j,
            msgId: g,
            threadJId: a
        };
        k = c("gkx")("6038");
        i = Date.now() - j < 1e3 * 60 * 60 * 24 * 30;
        return babelHelpers["extends"]({}, b, {
            mediaData: h,
            previewMediaData: k && i ? e.previewMediaData : null
        })
    }

    function R(a, b, e) {
        a != null && e != null && b.quotesToBeRestored.map(function(b) {
            d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(b.messageId, a, b.sortOrderMs, c("LSMEBTaskCreationSource").POINT_QUERY_FROM_EB, e)
        })
    }

    function S(a, c, e) {
        c == null ? void 0 : c.addPoint("receiver_fetch_restore_start");
        var f = a.restoredMsgsData;
        if (f == null) {
            c == null ? void 0 : c.addPoint("receiver_fetch_restore_end");
            return (h || (h = b("Promise"))).resolve()
        }
        var g = f.newlyAddedMsgs;
        g = g.concat(f.existingMsgs);
        var i = g.filter(function(a) {
            return a.type === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH
        }).map(function(b) {
            var c = b.externalId;
            c = a.echoMsgMap.get(c);
            c = c == null ? void 0 : c.receiverFetchData;
            if (c == null || b.receiverFetchId == null) return null;
            if (c.type !== "sticker") {
                var f;
                d("WATagsLogger").TAGS(["labyrinth_web", "eb_restore", (f = e) != null ? f : ""]).WARN(p(), c.type);
                return null
            }
            f = {
                mimetype: c.mimetype,
                previewHeight: c.previewHeight,
                previewWidth: c.previewWidth,
                receiverFetchId: b.receiverFetchId,
                type: c.type
            };
            return {
                dbMsg: b,
                unstoredDbReceiverFetchInfo: f
            }
        }).filter(Boolean);
        if (i.length > 0) return T(i).then(function(a) {
            c == null ? void 0 : c.addPoint("receiver_fetch_restore_end", {
                "int": {
                    receiver_fetch: i.length
                }
            });
            return (h || (h = b("Promise"))).resolve()
        });
        c == null ? void 0 : c.addPoint("receiver_fetch_restore_end", {
            "int": {
                receiver_fetch: 0
            }
        });
        return (h || (h = b("Promise"))).resolve()
    }
    var T = e.makeMsgrTransactor({
        receiverFetchInfo: f.READWRITE
    }, "restoreWriteReceiverFetchInfosToDb", function(a) {
        return function(b) {
            return d("MAWDexieTable").dexieAll(b.map(function(b) {
                var c = b.dbMsg;
                b = b.unstoredDbReceiverFetchInfo;
                return d("MAWWriteReceiverFetchTxns").handleUnstoredReceiverFetchInfo(a, c, b)
            }))
        }
    });
    g.handleEchoMsgsBulkRestore = a;
    g.deleteMessages = I;
    g.getThread = L;
    g.getMediaMetadataForDownload = Q;
    g.writeReceiverFetchInfosToDb = T
}), 98);
__d("MAWUnstoredQuotedMsgUtils", ["MAWMsgType", "WAJids", "WAMsgType", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        if (a == null) return;
        var b = a.content;
        a = a.remoteJid;
        var e;
        switch (b.type) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
                e = j(b);
                break;
            case d("MAWMsgType").MSG_TYPE.IMAGE:
                e = k(b);
                break;
            case d("MAWMsgType").MSG_TYPE.VIDEO:
                e = l(b);
                break;
            case d("MAWMsgType").MSG_TYPE.PTT:
                e = m(b);
                break;
            case d("MAWMsgType").MSG_TYPE.GIF:
                e = n(b);
                break;
            case d("MAWMsgType").MSG_TYPE.STICKER:
                e = o(b);
                break;
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                e = q(b);
                break;
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
                e = r(b);
                break;
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
                e = s(b);
                break;
            case d("WAMsgType").NOTE_REPLY:
                e = p(b);
                break;
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                e = t(b);
                break;
            default:
                b.type;
                throw c("err")("For flow")
        }
        return {
            content: e,
            remoteJid: a
        }
    }

    function i(a) {
        if (d("WAJids").isAuthorSystem(a.author)) throw c("err")("A system message cannot be quoted");
        return {
            author: a.author,
            externalId: a.externalId,
            ts: a.ts
        }
    }

    function j(a) {
        return babelHelpers["extends"]({}, i(a), {
            msgContent: a.msgContent,
            type: d("MAWMsgType").MSG_TYPE.TEXT
        })
    }

    function k(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.IMAGE
        })
    }

    function l(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.VIDEO
        })
    }

    function m(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.PTT
        })
    }

    function n(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.GIF
        })
    }

    function o(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.STICKER
        })
    }

    function p(a) {
        return babelHelpers["extends"]({}, i(a), {
            expirationTs: a.expirationTs,
            msgContent: a.msgContent,
            type: d("WAMsgType").NOTE_REPLY
        })
    }

    function q(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE
        })
    }

    function r(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.UNAVAILABLE
        })
    }

    function s(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL
        })
    }

    function t(a) {
        return babelHelpers["extends"]({}, i(a), {
            type: d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH
        })
    }

    function a(a) {
        return {
            quote: h(a.quote)
        }
    }
    g.getWithQuoteMsg = a
}), 98);
__d("MAWUnstoredTypedMsgUtils", ["MAWDbMsg", "MAWMsgType", "MAWRavenUtils", "MAWUnstoredQuotedMsgUtils", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return {
            ack: a.ack,
            author: a.id.author,
            externalId: a.id.externalId,
            reportingMeta: a.reportingMeta,
            serverTs: a.serverTs,
            ts: a.ts
        }
    }

    function i(a) {
        return {
            forwardingScore: a.forwardingScore,
            isForwarded: a.isForwarded
        }
    }

    function j(a) {
        return {
            ephemeralSetting: k(a.ephemeralSetting),
            messageDeleteTs: a.deleteTs,
            messageExpirationTs: a.expirationTs
        }
    }

    function k(a) {
        if (a == null) return;
        return {
            ephemeralExpirationInSec: a.expirationTs,
            ephemeralLastUpdatedOrSetTimestamp: a.updatedTs
        }
    }

    function a(a, b) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            msgContent: {
                content: (a = b.sentWithMessage) != null ? a : "",
                mentionedJids: b.mentionedJids
            },
            type: d("MAWMsgType").MSG_TYPE.XMA,
            xmaMessageType: b.targetType
        })
    }

    function b(a) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            editCount: 0,
            msgContent: a.msgContent,
            specialTextSize: a.specialTextSize,
            type: d("MAWMsgType").MSG_TYPE.TEXT
        })
    }

    function c(a) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            plaintextHash: (a = a.mediaId) != null ? a : void 0,
            type: d("MAWMsgType").MSG_TYPE.IMAGE
        })
    }

    function e(a) {
        return babelHelpers["extends"]({}, h(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            ravenEphemeralMediaState: d("MAWRavenUtils").getEphemeralMediaState(a.ravenEphemeralMediaState),
            ravenEphemeralType: a.ravenEphemeralType,
            ravenMediaType: a.ravenMediaType,
            type: d("MAWMsgType").MSG_TYPE.RAVEN
        })
    }

    function f(a) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            plaintextHash: (a = a.mediaId) != null ? a : void 0,
            type: d("MAWMsgType").MSG_TYPE.VIDEO
        })
    }

    function l(a) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            type: d("MAWMsgType").MSG_TYPE.PTT
        })
    }

    function m(a) {
        return {
            adminMsgContent: a.adminMsgContent,
            adminType: a.adminType
        }
    }

    function n(a) {
        return babelHelpers["extends"]({}, h(a), {
            altIndex: void 0,
            author: d("WAJids").AUTHOR_SYSTEM,
            msgContent: m(a.msgContent),
            type: d("MAWMsgType").MSG_TYPE.ADMIN
        })
    }

    function o(a) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            plaintextHash: (a = a.mediaId) != null ? a : void 0,
            type: d("MAWMsgType").MSG_TYPE.GIF
        })
    }

    function p(a) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            plaintextHash: (a = a.mediaId) != null ? a : void 0,
            type: d("MAWMsgType").MSG_TYPE.STICKER
        })
    }

    function q(a) {
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            type: d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE
        })
    }

    function r(a) {
        return babelHelpers["extends"]({}, h(a), {
            altIndex: d("MAWDbMsg").FUTUREPROOF_ALT_INDEX,
            msgContent: a.msgContent,
            type: d("MAWMsgType").MSG_TYPE.FUTUREPROOF
        })
    }

    function s(a) {
        return babelHelpers["extends"]({}, h(a), {
            altIndex: void 0,
            ebTimestampMs: a.ebTimestampMs,
            revokedExternalId: a.revokedExternalId,
            type: d("MAWMsgType").MSG_TYPE.REVOKED
        })
    }

    function t(a) {
        return {
            adminMsgContent: a.adminMsgContent,
            adminType: a.adminType
        }
    }

    function u(a) {
        return babelHelpers["extends"]({}, h(a), {
            altIndex: void 0,
            msgContent: t(a.msgContent),
            type: d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN
        })
    }

    function v(a) {
        return {
            adminMsgContent: a.adminMsgContent,
            adminType: a.adminType,
            screenshotActionType: a.screenshotActionType,
            version: a.version
        }
    }

    function w(a) {
        return babelHelpers["extends"]({}, h(a), {
            altIndex: void 0,
            msgContent: v(a.msgContent),
            type: d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION
        })
    }

    function x(a) {
        return {
            adminType: a.adminType,
            authorName: a.authorName
        }
    }

    function y(a) {
        return babelHelpers["extends"]({}, h(a), {
            altIndex: void 0,
            msgContent: x(a.msgContent),
            type: d("MAWMsgType").MSG_TYPE.ICDC_ALERT
        })
    }

    function z(a) {
        return babelHelpers["extends"]({}, h(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), {
            altIndex: void 0,
            type: d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE
        })
    }

    function A(a, b) {
        b = b.receiverFetchId;
        return babelHelpers["extends"]({}, h(a), i(a), d("MAWUnstoredQuotedMsgUtils").getWithQuoteMsg(a), j(a), {
            altIndex: void 0,
            receiverFetchId: b,
            type: d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH
        })
    }
    g.getXMAMsg = a;
    g.getTextMsg = b;
    g.getImageMsg = c;
    g.getRavenMsg = e;
    g.getVideoMsg = f;
    g.getPttMsg = l;
    g.getAdminMsg = n;
    g.getGifMsg = o;
    g.getStickerMsg = p;
    g.getDocumentFileMsg = q;
    g.getFutureproofMsg = r;
    g.getRevokedMsg = s;
    g.getEphemeralSettingAdminMsg = u;
    g.getEphemeralScreenshotActionMsg = w;
    g.getICDCAlertMsg = y;
    g.getBumpExistingMessageMsg = z;
    g.getReceiverFetchMsg = A
}), 98);
__d("MAWUnstoredMsgUtils", ["MAWMsgType", "MAWUnstoredTypedMsgUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.unstoredMsg,
            e = a.unstoredReceiverFetchInfo;
        a = a.unstoredXMA;
        if (b == null) return null;
        switch (b.type) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
                return d("MAWUnstoredTypedMsgUtils").getTextMsg(b);
            case d("MAWMsgType").MSG_TYPE.IMAGE:
                return d("MAWUnstoredTypedMsgUtils").getImageMsg(b);
            case d("MAWMsgType").MSG_TYPE.VIDEO:
                return d("MAWUnstoredTypedMsgUtils").getVideoMsg(b);
            case d("MAWMsgType").MSG_TYPE.PTT:
                return d("MAWUnstoredTypedMsgUtils").getPttMsg(b);
            case d("MAWMsgType").MSG_TYPE.ADMIN:
                return d("MAWUnstoredTypedMsgUtils").getAdminMsg(b);
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
                return d("MAWUnstoredTypedMsgUtils").getFutureproofMsg(b);
            case d("MAWMsgType").MSG_TYPE.REVOKED:
                return d("MAWUnstoredTypedMsgUtils").getRevokedMsg(b);
            case d("MAWMsgType").MSG_TYPE.GIF:
                return d("MAWUnstoredTypedMsgUtils").getGifMsg(b);
            case d("MAWMsgType").MSG_TYPE.STICKER:
                return d("MAWUnstoredTypedMsgUtils").getStickerMsg(b);
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                return d("MAWUnstoredTypedMsgUtils").getDocumentFileMsg(b);
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
                return d("MAWUnstoredTypedMsgUtils").getEphemeralSettingAdminMsg(b);
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
                return d("MAWUnstoredTypedMsgUtils").getEphemeralScreenshotActionMsg(b);
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
                return d("MAWUnstoredTypedMsgUtils").getICDCAlertMsg(b);
            case d("MAWMsgType").MSG_TYPE.XMA:
                if ((a == null ? void 0 : a.xma) == null) throw c("err")("XMA content cannot be parsed without XMA payload");
                return d("MAWUnstoredTypedMsgUtils").getXMAMsg(b, a == null ? void 0 : a.xma);
            case d("MAWMsgType").MSG_TYPE.RAVEN:
                return d("MAWUnstoredTypedMsgUtils").getRavenMsg(b);
            case d("MAWMsgType").MSG_TYPE.RAVEN_ACTION:
            case d("MAWMsgType").MSG_TYPE.REACTION:
            case d("MAWMsgType").MSG_TYPE.EDIT_ACTION:
                return null;
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                return d("MAWUnstoredTypedMsgUtils").getBumpExistingMessageMsg(b);
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                if (e == null) throw c("err")("Receiver Fetch Info cannot be null for Receiver Fetch Msg");
                return d("MAWUnstoredTypedMsgUtils").getReceiverFetchMsg(b, e);
            case d("MAWMsgType").MSG_TYPE.GROUP_POLL_CREATE:
                throw c("err")("Group polls are not yet supported");
            default:
                b.type;
                return null
        }
    }

    function b(a) {
        if (a == null) return null;
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
                return d("MAWUnstoredTypedMsgUtils").getTextMsg(a);
            case d("MAWMsgType").MSG_TYPE.GIF:
                return d("MAWUnstoredTypedMsgUtils").getGifMsg(a);
            case d("MAWMsgType").MSG_TYPE.STICKER:
                return d("MAWUnstoredTypedMsgUtils").getStickerMsg(a);
            default:
                return null
        }
    }

    function e(a) {
        a = a.unstoredMsg;
        if (!a || a.type !== d("MAWMsgType").MSG_TYPE.REACTION) return null;
        a = a;
        return {
            ack: a.ack,
            author: a.id.author,
            externalId: a.id.externalId,
            groupingKey: a.groupingKey,
            reaction: a.reaction,
            reactToAuthor: a.reactToAuthor,
            reactToExternalId: a.reactToExternalId,
            senderTimestampMs: a.senderTimestampMs,
            threadJid: a.id.chat,
            ts: a.ts
        }
    }

    function f(a) {
        a = a.unstoredMsg;
        if (!a || a.type !== d("MAWMsgType").MSG_TYPE.RAVEN_ACTION) return null;
        a = a;
        return {
            ack: a.ack,
            actionTimestamp: a.actionTimestamp,
            actionType: a.actionType,
            author: a.id.author,
            externalId: a.id.externalId,
            ravenActionToMsgExternalId: a.ravenActionToMsgExternalId,
            ts: a.ts,
            type: a.type
        }
    }

    function h(a) {
        a = a.unstoredIncomingGroupInvite;
        return !a ? null : babelHelpers["extends"]({}, a)
    }

    function i(a) {
        return a == null ? null : {
            ack: a.ack,
            author: a.id.author,
            editMsgContent: a.editMsgContent,
            externalId: a.id.externalId,
            originalMsgExternalId: a.originalMsgExternalId,
            reportingMeta: a.reportingMeta,
            serverTs: a.serverTs,
            specialTextSize: a.specialTextSize,
            ts: a.ts,
            type: a.type
        }
    }

    function j(a) {
        a = a.unstoredReceiverFetchInfo;
        return a == null ? null : babelHelpers["extends"]({}, a, {
            type: "sticker"
        })
    }
    g.getUnstoredMsg = a;
    g.getUnstoredAssociatedMsg = b;
    g.getUnstoredReaction = e;
    g.getUnstoredRavenActionMsg = f;
    g.getGroupInvite = h;
    g.getUnstoredEditActionMsg = i;
    g.getUnstoredReceiverFetchInfo = j
}), 98);
__d("MAWUnstoredMediaUtils", ["MAWUnstoredMsgUtils", "WASortedLists"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return a == null ? null : {
            mediaEntry: a.mediaEntry,
            mediaType: a.mediaType,
            msgIds: d("WASortedLists").emptySet(),
            plaintextHash: a.plaintextHash,
            size: a.size,
            ts: a.ts,
            validatedAudioInfo: a.validatedAudioInfo,
            validatedDocumentFileInfo: a.validatedDocumentFileInfo,
            validatedImageInfo: a.validatedImageInfo,
            validatedVideoInfo: a.validatedVideoInfo
        }
    }

    function a(a) {
        a = a.unstoredXMA;
        if (a == null) return;
        var b = a.unstoredAssociatedMedia,
            c = a.unstoredAssociatedMsg,
            e = a.unstoredFavicon,
            f = a.unstoredHeaderMedia,
            g = a.unstoredPreviews;
        a = a.xma;
        return {
            unstoredAssociatedMedia: (b = h(b)) != null ? b : void 0,
            unstoredAssociatedMsg: (b = d("MAWUnstoredMsgUtils").getUnstoredAssociatedMsg(c)) != null ? b : void 0,
            unstoredDbXMA: {
                author: a.author,
                contentRef: a.contentRef,
                ctas: a.ctas,
                defaultCTA: a.defaultCTA,
                externalId: a.externalId,
                headerTitle: a.headerTitle,
                isTombstoned: a.isTombstoned,
                maxSubtitleNumOfLines: a.maxSubtitleNumOfLines,
                maxTitleNumOfLines: a.maxTitleNumOfLines,
                overlayDescription: a.overlayDescription,
                overlayIconGlyph: a.overlayIconGlyph,
                overlayTitle: a.overlayTitle,
                subtitleText: a.subtitleText,
                targetExpiringAtSec: a.targetExpiringAtSec,
                targetId: a.targetId,
                targetType: a.targetType,
                targetUsername: a.targetUsername,
                threadJid: a.threadJid,
                titleText: a.titleText,
                xmaLayoutType: a.xmaLayoutType
            },
            unstoredFavicon: (c = h(e)) != null ? c : void 0,
            unstoredHeaderMedia: (b = h(f)) != null ? b : void 0,
            unstoredPreviews: g ? g.map(function(a) {
                return h(a)
            }).filter(Boolean) : void 0
        }
    }
    g.getUnstoredMedia = h;
    g.getUnstoredXMA = a
}), 98);
__d("MAWUnstoredContentToUnstoredDbContentUtils", ["MAWUnstoredMediaUtils", "MAWUnstoredMsgUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b, c = (b = d("MAWUnstoredMsgUtils")).getUnstoredMsg(a),
            e = d("MAWUnstoredMediaUtils").getUnstoredMedia(a.unstoredMedia),
            f = b.getUnstoredReaction(a),
            g = b.getUnstoredRavenActionMsg(a),
            h = d("MAWUnstoredMediaUtils").getUnstoredXMA(a),
            i = b.getGroupInvite(a),
            j = b.getUnstoredEditActionMsg(a.unstoredEditMsg);
        b = b.getUnstoredReceiverFetchInfo(a);
        if (i == null) return {
            contentTypeForLogging: a.contentTypeForLogging,
            unstoredDbEditActionMsg: j,
            unstoredDbMedia: e,
            unstoredDbMsg: c,
            unstoredDbRavenActionMsg: g,
            unstoredDbReaction: f,
            unstoredDbReceiverFetchInfo: b,
            unstoredXMA: h,
            xmaTargetTypeForLogging: a.xmaTargetTypeForLogging
        };
        else return {
            contentTypeForLogging: a.contentTypeForLogging,
            unstoredDbEditActionMsg: j,
            unstoredDbMedia: e,
            unstoredDbMsg: c,
            unstoredDbRavenActionMsg: g,
            unstoredDbReaction: f,
            unstoredDbReceiverFetchInfo: b,
            unstoredIncomingDbGroupInvite: i,
            unstoredXMA: h,
            xmaTargetTypeForLogging: a.xmaTargetTypeForLogging
        }
    }
    g.unstoredContentToUnstoredDbContent = a
}), 98);
__d("MAWWriteReactionTxns", ["MAWAckLevel", "MAWAuthor", "MAWDbMsg", "MAWDbReaction", "MAWDbReactionUtils", "MAWDbReactionsTxns", "MAWDexieTable", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f) {
        var g = b.author,
            h = b.externalId,
            i = b.groupingKey,
            j = b.reaction,
            k = b.reactToAuthor,
            l = b.reactToExternalId,
            m = b.senderTimestampMs,
            n = b.ts;
        return d("MAWDexieTable").dexieAll([a.messages.where("externalId").equals(l).toArray(), a.reactions.where("reactToExternalId").equals(l).toArray(), d("MAWDbReactionsTxns").getNextReactionIdNumberForThread(a, e)]).then(function(b) {
            var o = b[0],
                p = b[1];
            b = b[2];
            p = d("MAWDbReaction").findMatchingReaction(p, e.jid, g);
            var q = d("MAWAuthor").getAuthorUserJid(k);
            o = o.find(function(a) {
                return a.threadJid === e.jid && q === d("MAWAuthor").getAuthorUserJid(a.author)
            });
            var r = p == null ? void 0 : p.ack;
            (p == null ? void 0 : p.ack) === d("MAWAckLevel").ACK.partialOptimistic && (r = d("MAWAckLevel").ACK.clock);
            var s = d("MAWDbReaction").formatReactionForDb(e.jid, h, d("MAWDbMsg").craftReactionId(e.chatId, b), l, j, i, k, o == null ? void 0 : o.msgId, n, g, p == null ? void 0 : p.rowId, r, m);
            return d("MAWDbReactionsTxns").putReaction(a, s).then(function(a) {
                a = babelHelpers["extends"]({}, s, {
                    rowId: a
                });
                c("qex")._("1016") !== !0 && f !== !0 && d("MAWDbReactionUtils").dispatchReaction(a);
                return a
            })
        })
    }
    g.writeReaction = a
}), 98);
__d("MAWWriteReactionMsgApi", ["MAWDexieTable", "MAWIndexedDb", "MAWTransactionMode", "MAWWriteReactionTxns", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a, b, c, e, f, g, h) {
        g === void 0 && (g = d("WAJids").AUTHOR_ME);
        var i = e.groupingKey,
            j = e.reaction,
            k = e.reactToAuthor,
            l = e.reactToExternalId;
        e = e.senderTimestampMs;
        var m = {
            author: g,
            externalId: b,
            groupingKey: i,
            reaction: j,
            reactToAuthor: k,
            reactToExternalId: l,
            senderTimestampMs: e,
            ts: f
        };
        return a.threads.get({
            jid: c
        }).then(function(b) {
            return b == null ? "missing_thread" : d("MAWWriteReactionTxns").writeReaction(a, m, b, h)
        }).then(function(a) {
            return a === "missing_thread" ? {
                type: "missing_thread"
            } : {
                msgId: a.reactionId,
                protocolMsgId: {
                    author: g,
                    chat: c,
                    externalId: a.externalId
                },
                type: "not_sent"
            }
        })
    };
    b = d("MAWIndexedDb").makeMsgrTransactor({
        messages: (a = d("MAWTransactionMode")).READONLY,
        reactions: a.READWRITE,
        threads: a.READONLY
    }, "writeReactionMsg", function(a) {
        return function(b, c, e, f, g, i) {
            g === void 0 && (g = d("WAJids").AUTHOR_ME);
            return h(a, b, c, e, f, g, i)
        }
    });
    c = d("MAWIndexedDb").makeMsgrTransactor({
        messages: a.READONLY,
        reactions: a.READWRITE,
        threads: a.READONLY
    }, "bulkWriteReactionMsg", function(a) {
        return function(b, c) {
            return d("MAWDexieTable").dexieAll(b.map(function(b) {
                return h(a, b.externalId, b.chatJid, b.args, b.ts, b.author, c)
            }))
        }
    });
    g.writeReactionMsg = b;
    g.bulkWriteReactionMsg = c
}), 98);
__d("MAWHandleEchoProtobufsRestoreApi", ["EchoMessageMediaFieldUtils", "FBLogger", "LSDataTraceCheckPoint", "LSIntEnum", "LSMEBTaskCreationSource", "MAWBridge", "MAWBridgeEventTransmitter", "MAWBridgeMsg", "MAWBridgeXMA", "MAWDbEditMsgHistoryTxns", "MAWDbMsg", "MAWDbRavenActionTxns", "MAWDexieTable", "MAWEBRestoreTrackingUtils", "MAWHandleEchoMediaMsgsRestoreV2", "MAWHandleEchoMsgsRestoreApiUtils", "MAWHandleEchoMsgsRestoreApiV2", "MAWHandleEchoXMARestoreV2", "MAWHandleXmaTransactionUtil", "MAWIndexedDb", "MAWJids", "MAWLoadReplyMediaTxns", "MAWMediaGalleryM2Utils", "MAWMediaManagementTxns", "MAWMsg", "MAWMsgType", "MAWODSProxy", "MAWQplProxy", "MAWRestoreMsgsTxns", "MAWRestoreValidationUtils", "MAWTraceUtils", "MAWTransactionMode", "MAWUnstoredContentToUnstoredDbContentUtils", "MAWUpdateQuotedMsgTxns", "MAWWriteReactionMsgApi", "MAWWriteReceiverFetchTxns", "MessageBackupSupplementalKeyGenerator", "Promise", "WAAckLevel", "WAArmadilloApplication.pb", "WAArmadilloBackupMessage.pb", "WABase64", "WAConsumerApplication.pb", "WAGlobals", "WAHashUtils", "WAJids", "WALogger", "WAMediaTransport.pb", "WAMediaUtils", "WAMsgApplication.pb", "WAMsgType", "WAOdsEnums", "WAParseConsumerMessageProtocol", "WAParseMediaTransportProtocol", "WAParseMessageApplication", "WAStanzaUtils", "WATimeUtils", "asyncToGeneratorRuntime", "decodeProtobuf", "emptyFunction", "gkx", "justknobx", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Cannot download media - timestamp cannot be null"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] cannot support message type for protobuf restore - reverting to echo restore"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Protobuf restore initiated for ", " messages. isPointRestore: ", " referenceTimestamp: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] No text content found in edit msg"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown supplemental identifier"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Message contains unparseable message application - unable to restore message"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Unable to retrieve decoded protobuf from backup message - unsupported message type"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Decoded raven video unstored message is null - unable to restore"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] No author found for original message that was bumped - unable to restore"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Unable to retrieve revoked message external id"]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[MAWHandleEchoProtobufsRestoreApi] consumerMessage has no sticker receiver fetch info"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Invalid attachment type, cannot restore attachment"]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Unsupported media type, cannot get mimetype for attachment"]);
        v = function() {
            return a
        };
        return a
    }

    function w() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Failed to create db msg from protobuf"]);
        w = function() {
            return a
        };
        return a
    }

    function x() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Missing required fields, unable to create db msg from protobuf for thread jid ", " and otid ", ""]);
        x = function() {
            return a
        };
        return a
    }

    function y() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Missing required author, unable to create db msg from protobuf"]);
        y = function() {
            return a
        };
        return a
    }

    function z() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Missing required message id, unable to create db msg from protobuf"]);
        z = function() {
            return a
        };
        return a
    }

    function A() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Missing required msg type, unable to create db msg from protobuf"]);
        A = function() {
            return a
        };
        return a
    }

    function B() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] Missing required metadata, unable to create db msg from protobuf"]);
        B = function() {
            return a
        };
        return a
    }

    function C() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] No target type found for XMA - unable to extract XMA content for message"]);
        C = function() {
            return a
        };
        return a
    }

    function D() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] XMA data is null - unable to extract XMA content for message"]);
        D = function() {
            return a
        };
        return a
    }

    function E() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] One of the mandatory fields is missing for the group poll creation msg"]);
        E = function() {
            return a
        };
        return a
    }

    function F() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] No raven msg media type found for raven msg"]);
        F = function() {
            return a
        };
        return a
    }

    function G() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] No raven msg ephemeral type found for raven msg"]);
        G = function() {
            return a
        };
        return a
    }

    function H() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] No revoked msg external id found for revoked msg"]);
        H = function() {
            return a
        };
        return a
    }

    function I() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth][web] text content cannot be null for msg type text - unable to restore msg"]);
        I = function() {
            return a
        };
        return a
    }
    var J = (e = d("MAWIndexedDb")).makeMsgrTransactor({
        chunk: (f = d("MAWTransactionMode")).READONLY,
        media: f.READONLY,
        messages: f.READWRITE,
        receiverFetchInfo: f.READONLY,
        xma: f.READONLY
    }, "associateQuotedMessagesForRestoredDbMsgs", function(a) {
        return function(b, c, e) {
            var f = 0;
            return d("MAWDexieTable").dexieAll(b.map(function(b) {
                return d("MAWUpdateQuotedMsgTxns").associateQuotedMessage(a, c, b, !0).then(function(b) {
                    b != null && b.length > 0 && (f += b.length, b.forEach(function(b) {
                        return d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, b).then(function(a) {
                            d("MAWIndexedDb").afterTransaction({
                                tag: "MsgUpdated",
                                value: d("MAWBridgeMsg").createBridgeMsg(b, void 0, a)
                            })
                        })
                    }))
                })
            })).then(function() {
                e == null ? void 0 : e.addPoint("replies_restore_end", {
                    "int": {
                        replies: f
                    }
                });
                return d("MAWDexieTable").dexieResolve()
            })
        }
    });

    function K(a, b, c) {
        c = {
            author: c,
            chat: b,
            externalId: a
        };
        return c
    }

    function L(a, b, c) {
        var e = new Map(),
            f = a.metadata;
        a = a.reactionData;
        if (f != null && a != null) {
            var g = f.senderId,
                h = f.messageId;
            if (g != null && h != null) {
                a.forEach(function(a) {
                    var f = a.ts,
                        i = a.senderId,
                        j = a.reactionExternalId,
                        k = d("WAStanzaUtils").toStanzaId(h);
                    if (i == null || j == null) return;
                    j = d("WAStanzaUtils").toStanzaId(j);
                    i = d("MAWJids").toUserJid(i);
                    var l = d("MAWJids").toUserJid(g);
                    i = i === c ? d("WAJids").AUTHOR_ME : i;
                    l = l === c ? d("WAJids").AUTHOR_ME : l;
                    var m = i === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED;
                    m = {
                        ack: m,
                        chatJid: b,
                        reaction: a.reaction,
                        reactionAuthor: i,
                        reactionExternalId: j,
                        reactToExternalId: k,
                        reactToMsgAuthor: l,
                        ts: f
                    };
                    e.set(j, m)
                });
                return e
            }
        }
    }

    function M(a, b, c, e, f, g, h, i, j, k, l, m, n, o, p, q) {
        if (a === d("MAWMsgType").MSG_TYPE.TEXT)
            if (h == null) {
                d("WALogger").ERROR(I());
                return
            } else {
                h = {
                    ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                    forwardingScore: g,
                    id: e,
                    isForwarded: f,
                    msgContent: {
                        content: h,
                        mentionedJids: i != null ? i.map(d("WAJids").validateUserJid).filter(Boolean) : void 0
                    },
                    ts: b,
                    type: d("MAWMsgType").MSG_TYPE.TEXT
                };
                return h
            }
        else if (a === d("MAWMsgType").MSG_TYPE.VIDEO) {
            i = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                mediaId: void 0,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.VIDEO
            };
            return i
        } else if (a === d("MAWMsgType").MSG_TYPE.GIF) {
            h = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                mediaId: void 0,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.GIF
            };
            return h
        } else if (a === d("MAWMsgType").MSG_TYPE.IMAGE) {
            i = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                mediaId: void 0,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.IMAGE
            };
            return i
        } else if (a === d("MAWMsgType").MSG_TYPE.STICKER) {
            h = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                mediaId: void 0,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.STICKER
            };
            return h
        } else if (a === d("MAWMsgType").MSG_TYPE.PTT) {
            i = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                mediaId: void 0,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.PTT
            };
            return i
        } else if (a === d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE) {
            h = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                mediaId: void 0,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE
            };
            return h
        } else if (a === d("MAWMsgType").MSG_TYPE.XMA) {
            i = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.XMA
            };
            return i
        } else if (a === d("MAWMsgType").MSG_TYPE.REVOKED) {
            if (j == null) {
                d("WALogger").ERROR(H());
                return
            }
            h = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                ebTimestampMs: null,
                id: e,
                msgContent: void 0,
                revokedExternalId: j,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.REVOKED,
                unsendMsgContentDeleteTs: b
            };
            return h
        } else if (a === d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE) {
            i = {
                ack: d("WAAckLevel").ACK.SENT,
                id: e,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE
            };
            return i
        } else if (a === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH) {
            j = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                forwardingScore: g,
                id: e,
                isForwarded: f,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH
            };
            return j
        } else if (a === d("MAWMsgType").MSG_TYPE.RAVEN) {
            if (k == null) {
                d("WALogger").ERROR(G());
                return
            }
            if (l == null) {
                d("WALogger").ERROR(F());
                return
            }
            h = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                id: e,
                mediaId: m,
                ravenEphemeralMediaState: d("MAWMsg").MAWRavenMsgEphemeralMediaState.UNSEEN,
                ravenEphemeralType: k,
                ravenMediaType: l,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.RAVEN
            };
            return h
        } else if (a === d("MAWMsgType").MSG_TYPE.GROUP_POLL_CREATE) {
            if (n == null || o == null || p == null || q == null) {
                d("WALogger").ERROR(E());
                return
            }
            i = {
                ack: c === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED,
                encKey: n,
                id: e,
                name: o,
                options: p,
                selectableOptionsCount: q,
                ts: b,
                type: d("MAWMsgType").MSG_TYPE.GROUP_POLL_CREATE
            };
            return i
        }
    }

    function N(a, b, c, e, f) {
        if (f == null) {
            d("WALogger").ERROR(D());
            return
        }
        var g = f == null ? void 0 : f.ctas.map(function(a) {
                return {
                    actionUrl: a.actionUrl,
                    buttonType: a.buttonType,
                    ctaType: a.ctaType,
                    nativeUrl: a.nativeUrl,
                    title: a.title
                }
            }),
            h = f.targetType;
        if (h == null) {
            d("WALogger").ERROR(C());
            return
        }
        var i;
        f.targetExpiringAtSec != null && typeof f.targetExpiringAtSec === "number" && (i = d("WATimeUtils").castToUnixTime(f.targetExpiringAtSec));
        a = {
            author: a,
            contentRef: f.contentRef,
            ctas: g,
            defaultCTA: g.length > 0 ? g[0] : void 0,
            externalId: b,
            headerTitle: f.headerTitle,
            maxSubtitleNumOfLines: f.maxSubtitleNumOfLines,
            maxTitleNumOfLines: f.maxTitleNumOfLines,
            msgId: c,
            overlayDescription: f.overlayDescription,
            overlayIconGlyph: f.overlayIconGlyph,
            overlayTitle: f.overlayTitle,
            subtitleText: f.subtitleText,
            targetExpiringAtSec: i,
            targetId: f.targetId,
            targetType: h,
            targetUsername: f.targetUsername,
            threadJid: e,
            titleText: f.titleText,
            xmaLayoutType: f.xmaLayoutType
        };
        return a
    }

    function O(a, b, c, e, f) {
        var g, h, i = a.metadata,
            j = a.msgType;
        if (i == null) {
            d("WALogger").ERROR(B());
            return
        }
        if (j == null) {
            d("WALogger").ERROR(A());
            return
        }
        var k = i.messageId;
        i = i.senderId;
        g = (g = a.decodedPayload) == null ? void 0 : g.text;
        h = (h = a.decodedPayload) == null ? void 0 : h.mentionedJid;
        if (k == null) {
            d("WALogger").ERROR(z());
            return
        }
        if (i == null) {
            d("WALogger").ERROR(y());
            return
        }
        var l = d("WATimeUtils").castMilliSecondsToUnixTime(a.sortOrderMs);
        i = d("MAWJids").toUserJid(i);
        var m = d("WAStanzaUtils").toStanzaId(k),
            n = i === c ? d("WAJids").AUTHOR_ME : i,
            o = K(m, b, i);
        if (a.editMsgData.length > 0) {
            var p = l;
            a.editMsgData.forEach(function(a) {
                var b;
                if (a.ts > p && ((b = a.editMsgContent.message) == null ? void 0 : b.text) != null) {
                    p = a.ts;
                    g = (b = a.editMsgContent.message) == null ? void 0 : b.text;
                    h = (b = a.editMsgContent.message) == null ? void 0 : b.mentionedJid
                }
            })
        }
        o = M(j, l, n, o, a.isForwarded, a.forwardingScore, g, h, a.revokedMsgExternalId, a.ravenMsgEphemeralType, a.ravenMsgMediaType, (l = a.ravenUnstoredMedia) == null ? void 0 : l.plaintextHash, (n = a.groupPollInfo) == null ? void 0 : n.encryptionKey, (o = a.groupPollInfo) == null ? void 0 : o.name, (l = a.groupPollInfo) == null ? void 0 : l.options.map(function(a) {
            a = a.optionName;
            return a
        }), (n = a.groupPollInfo) == null ? void 0 : n.selectableOptionsCount);
        if (o == null) {
            d("WALogger").ERROR(x(), b, m);
            return
        }
        var q;
        if (a.xmaData != null && ((l = a.xmaData) == null ? void 0 : l.targetType) != null) {
            l = {
                author: i,
                externalId: m,
                targetType: (n = a.xmaData) == null ? void 0 : n.targetType,
                threadJid: b
            };
            q = {
                unstoredAssociatedMedia: void 0,
                unstoredAssociatedMsg: void 0,
                unstoredFavicon: void 0,
                unstoredHeaderMedia: void 0,
                unstoredPreviews: void 0,
                xma: l
            }
        }
        i = {
            unstoredMedia: void 0,
            unstoredMsg: o,
            unstoredQuotedMedia: void 0,
            unstoredReceiverFetchInfo: a.receiverFetchInfo,
            unstoredXMA: q
        };
        o.type === d("MAWMsgType").MSG_TYPE.RAVEN && a.ravenUnstoredMedia != null && (i.unstoredMedia = a.ravenUnstoredMedia);
        n = d("MAWUnstoredContentToUnstoredDbContentUtils").unstoredContentToUnstoredDbContent(i);
        if (n.unstoredDbMsg != null) {
            b = n.unstoredDbMsg;
            b.sortOrderMs = a.sortOrderMs;
            b.serverTs = d("WATimeUtils").castToUnixTime(a.sortOrderMs / 1e3);
            a.noteReply != null && (b.quote = {
                content: a.noteReply,
                remoteJid: void 0
            });
            l = e.get(k);
            b.author != null && c === b.author && b.author !== d("WAJids").AUTHOR_SYSTEM && (b.author = d("WAJids").AUTHOR_ME);
            l != null && (b.quoteExternalId = d("WAStanzaUtils").toStanzaId(l));
            j === d("MAWMsgType").MSG_TYPE.TEXT && (b.editCount = a.editMsgData.length);
            o = {
                author: b.author,
                stanzaId: m,
                unstoredDbContent: n
            };
            n.unstoredDbMedia != null && f != null && f.set(m, n.unstoredDbMedia);
            return o
        }
        d("WALogger").ERROR(w())
    }

    function P(a) {
        switch (a) {
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE:
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.IMAGE_JPEG;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.GIF:
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.GIF;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.STICKER:
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.STICKER;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.VIDEO:
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.AUDIO_MP4;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.AUDIO:
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.AUDIO_WAV;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.XMA_IMAGE:
                return d("EchoMessageMediaFieldUtils").EchoMessageMediaPreviewType.IMAGE_JPEG;
            default:
                return null
        }
    }

    function Q(a) {
        switch (a) {
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE:
                return d("EchoMessageMediaFieldUtils").AttachmentType.IMAGE;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.GIF:
                return d("EchoMessageMediaFieldUtils").AttachmentType.GIF;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.STICKER:
                return d("EchoMessageMediaFieldUtils").AttachmentType.STICKER;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.VIDEO:
                return d("EchoMessageMediaFieldUtils").AttachmentType.VIDEO;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.AUDIO:
                return d("EchoMessageMediaFieldUtils").AttachmentType.PTT;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.XMA_IMAGE:
                return d("EchoMessageMediaFieldUtils").AttachmentType.XMA;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.DOCUMENT:
                return d("EchoMessageMediaFieldUtils").AttachmentType.DOCUMENT;
            default:
                return null
        }
    }

    function aa() {
        try {
            return WorkerGlobalScope !== void 0 && self instanceof WorkerGlobalScope
        } catch (a) {
            return !1
        }
    }

    function ba(a) {
        var b, e = aa() ? d("WAGlobals").getConfig().isOctetStreamAttachmentMimeTypeEnabled() : c("gkx")("4644");
        switch (a) {
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE:
                b = "image/jpeg";
                break;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.AUDIO:
                b = "audio/wav";
                break;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.VIDEO:
                b = "video/mp4";
                break;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.GIF:
                b = "image/gif";
                break;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.STICKER:
                b = "image/webp";
                break;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.XMA_IMAGE:
                b = "image/jpeg";
                break;
            case d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.DOCUMENT:
                b = e ? "application/octet-stream" : "application/pdf";
                break;
            default:
                d("WALogger").ERROR(v())
        }
        return b
    }

    function R(a, b, c) {
        var e, f, g, h, i, j;
        b = b;
        var k = a.ancillary;
        a = a.integral;
        e = a == null ? void 0 : (e = a.transport) == null ? void 0 : (e = e.integral) == null ? void 0 : e.fileSha256;
        f = a == null ? void 0 : (f = a.transport) == null ? void 0 : (f = f.integral) == null ? void 0 : f.fileEncSha256;
        g = a == null ? void 0 : (g = a.transport) == null ? void 0 : (g = g.integral) == null ? void 0 : g.mediaKey;
        h = (a == null ? void 0 : (h = a.transport) == null ? void 0 : (h = h.integral) == null ? void 0 : h.mediaKeyTimestamp) != null ? typeof(a == null ? void 0 : (h = a.transport) == null ? void 0 : h.integral.mediaKeyTimestamp) === "number" ? a == null ? void 0 : (h = a.transport) == null ? void 0 : h.integral.mediaKeyTimestamp : void 0 : void 0;
        var l = k == null ? void 0 : k.gifPlayback;
        l != null && l && (b = d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.GIF);
        l = a == null ? void 0 : (l = a.transport) == null ? void 0 : (l = l.ancillary) == null ? void 0 : (l = l.thumbnail) == null ? void 0 : l.thumbnailHeight;
        i = a == null ? void 0 : (i = a.transport) == null ? void 0 : (i = i.ancillary) == null ? void 0 : (i = i.thumbnail) == null ? void 0 : i.thumbnailWidth;
        var m = P(b),
            n = Q(b);
        if (n === null) {
            d("WALogger").ERROR(u());
            return
        }
        a = {
            attachmentObjectId: a == null ? void 0 : (j = a.transport) == null ? void 0 : (j = j.ancillary) == null ? void 0 : j.objectId,
            attachmentType: n,
            directPath: a == null ? void 0 : (j = a.transport) == null ? void 0 : (n = j.integral) == null ? void 0 : n.directPath,
            encryptedHash: f != null ? d("WAHashUtils").toPlaintextHash(f) : void 0,
            filename: c,
            height: k == null ? void 0 : k.height,
            mediaKey: g != null ? d("WABase64").encodeB64UrlSafe(g) : void 0,
            mediaKeyTimestamp: h,
            mediaPlayableDuration: k == null ? void 0 : k.seconds,
            plaintextHash: e != null ? d("WAHashUtils").toPlaintextHash(e) : void 0,
            width: k == null ? void 0 : k.width,
            xAttachmentType: b,
            xContentType: "full"
        };
        j = ba(b);
        j != null && (a.mediaContentType = j);
        m != null && (a.previewContentType = m, a.previewContentHeight = l, a.previewContentWidth = i);
        return d("EchoMessageMediaFieldUtils").convertMediaMetadataDetailsToMediaMetadata(a, "protobuf")
    }

    function S(a, b, e) {
        b = R(a, b, e);
        if (b == null) return {
            mediaMetadata: void 0,
            previewMetadata: null
        };
        e = a.integral;
        a = null;
        e = e == null ? void 0 : (e = e.transport) == null ? void 0 : (e = e.ancillary) == null ? void 0 : (e = e.thumbnail) == null ? void 0 : e.downloadableThumbnail;
        if (e != null && c("gkx")("6038")) {
            var f = e.fileSha256,
                g = e.fileEncSha256,
                h = e.mediaKey,
                i = typeof e.mediaKeyTimestamp === "number" ? e.mediaKeyTimestamp : void 0;
            a = {
                attachmentObjectId: e.objectId,
                attachmentType: d("EchoMessageMediaFieldUtils").AttachmentType.IMAGE,
                directPath: e.directPath,
                encryptedHash: g != null ? d("WAHashUtils").toPlaintextHash(g) : void 0,
                filename: void 0,
                height: void 0,
                mediaKey: h != null ? d("WABase64").encodeB64UrlSafe(h) : void 0,
                mediaKeyTimestamp: i,
                mediaPlayableDuration: void 0,
                plaintextHash: f != null ? d("WAHashUtils").toPlaintextHash(f) : void 0,
                width: void 0,
                xAttachmentType: d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.MESSENGER_PREVIEW,
                xContentType: "preview"
            };
            return {
                mediaMetadata: b,
                previewMetadata: d("EchoMessageMediaFieldUtils").convertMediaMetadataDetailsToMediaMetadata(a, "protobuf")
            }
        }
        return {
            mediaMetadata: b,
            previewMetadata: null
        }
    }

    function T(a, b, c, e, f, g) {
        g === void 0 && (g = null), b != null && a != null && (c.push({
            mediaMetadata: b,
            mediaRestoreType: e,
            previewMetadata: g
        }), f.set(d("WAStanzaUtils").toStanzaId(a), c))
    }

    function ca(a) {
        switch (a) {
            case 0:
                return d("MAWMsg").MAWRavenMsgEphemeralType.VIEW_ONCE;
            case 1:
                return d("MAWMsg").MAWRavenMsgEphemeralType.ALLOW_REPLAY;
            case 2:
                return d("MAWMsg").MAWRavenMsgEphemeralType.KEEP_IN_CHAT;
            default:
                return void 0
        }
    }

    function da(a, b, c, e, f, g, h, i, j, k, l) {
        var m, n, o = U(a, g, h, i);
        m = o == null ? void 0 : (m = o.obj.payload) == null ? void 0 : m.content;
        var u = {
                editMsgData: [],
                externalId: e,
                forwardingScore: (n = o == null ? void 0 : (n = o.metadata) == null ? void 0 : n.forwardingScore) != null ? n : 0,
                isForwarded: (n = o == null ? void 0 : (n = o.metadata) == null ? void 0 : n.isForwarded) != null ? n : !1,
                metadata: a.metadata,
                reactionData: [],
                sortOrderMs: b,
                unknownFieldCount: a.$$unknownFieldCount
            },
            v = [];
        if (m != null) {
            if (m.messageText != null) {
                u.msgType = d("MAWMsgType").MSG_TYPE.TEXT;
                u.decodedPayload = m.messageText;
                return u
            } else if (m.extendedContentMessage != null) {
                u.msgType = d("MAWMsgType").MSG_TYPE.XMA;
                u.xmaData = m.extendedContentMessage;
                if (((n = m.extendedContentMessage) == null ? void 0 : n.headerImage) != null) {
                    n = d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAMediaTransport.pb").ImageTransportSpec, (b = m.extendedContentMessage) == null ? void 0 : b.headerImage.payload);
                    b = R(n, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE);
                    T(e, b, v, "xma_header", j)
                }
                if (((n = m.extendedContentMessage) == null ? void 0 : n.favicon) != null) {
                    n = d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAMediaTransport.pb").ImageTransportSpec, (b = m.extendedContentMessage) == null ? void 0 : b.favicon.payload);
                    b = R(n, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE);
                    T(e, b, v, "xma_favicon", j)
                }
                if (((n = m.extendedContentMessage) == null ? void 0 : n.previews) != null) {
                    (b = m.extendedContentMessage) == null ? void 0 : b.previews.forEach(function(a) {
                        a = d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAMediaTransport.pb").ImageTransportSpec, a.payload);
                        a = R(a, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE);
                        u.mediaMetadata = a;
                        T(e, a, v, "xma_preview", j)
                    })
                }
                return u
            } else if (m.audioMessage != null) {
                n = d("decodeProtobuf").decodeProtobuf(d("WAMediaTransport.pb").AudioTransportSpec, (n = m.audioMessage) == null ? void 0 : (b = n.audio) == null ? void 0 : b.payload);
                b = R(n, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.AUDIO);
                u.msgType = d("MAWMsgType").MSG_TYPE.PTT;
                u.mediaMetadata = b;
                T(e, b, v, "attachment", j);
                return u
            } else if (m.videoMessage != null) {
                n = d("decodeProtobuf").decodeProtobuf(d("WAMediaTransport.pb").VideoTransportSpec, (n = m.videoMessage) == null ? void 0 : (n = n.video) == null ? void 0 : n.payload);
                n = S(n, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.VIDEO);
                var w = n.mediaMetadata;
                n = n.previewMetadata;
                b = w;
                b != null && b.xAttachmentType === d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.GIF ? u.msgType = d("MAWMsgType").MSG_TYPE.GIF : u.msgType = d("MAWMsgType").MSG_TYPE.VIDEO;
                u.mediaMetadata = b;
                T(e, b, v, "attachment", j, n);
                return u
            } else if (m.imageMessage != null) {
                w = d("decodeProtobuf").decodeProtobuf(d("WAMediaTransport.pb").ImageTransportSpec, (w = m.imageMessage) == null ? void 0 : (n = w.image) == null ? void 0 : n.payload);
                n = S(w, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.IMAGE);
                w = n.mediaMetadata;
                n = n.previewMetadata;
                b = w;
                u.msgType = d("MAWMsgType").MSG_TYPE.IMAGE;
                u.mediaMetadata = b;
                T(e, b, v, "attachment", j, n);
                return u
            } else if (m.stickerMessage != null) {
                w = d("decodeProtobuf").decodeProtobuf(d("WAMediaTransport.pb").StickerTransportSpec, (w = m.stickerMessage) == null ? void 0 : (n = w.sticker) == null ? void 0 : n.payload);
                if (((n = w.integral) == null ? void 0 : n.receiverFetchId) != null) {
                    n = d("WAParseMediaTransportProtocol").parseStickerReceiverFetchInfo(w);
                    if (n == null) {
                        d("WALogger").ERROR(t());
                        return u
                    }
                    u.msgType = d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH;
                    u.receiverFetchInfo = n;
                    return u
                }
                b = R(w, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.STICKER);
                u.msgType = d("MAWMsgType").MSG_TYPE.STICKER;
                u.mediaMetadata = b;
                T(e, b, v, "attachment", j);
                return u
            } else if (m.documentMessage != null) {
                n = d("decodeProtobuf").decodeProtobuf(d("WAMediaTransport.pb").DocumentTransportSpec, (n = m.documentMessage) == null ? void 0 : (w = n.document) == null ? void 0 : w.payload);
                b = R(n, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.DOCUMENT, (w = m.documentMessage) == null ? void 0 : w.fileName);
                u.msgType = d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE;
                u.mediaMetadata = b;
                T(e, b, v, "attachment", j);
                return u
            }
        } else if ((o == null ? void 0 : (n = o.obj.payload) == null ? void 0 : (m = n.applicationData) == null ? void 0 : m.revoke) != null) {
            n = o == null ? void 0 : (w = o.obj.payload) == null ? void 0 : (n = w.applicationData) == null ? void 0 : (m = n.revoke) == null ? void 0 : (w = m.key) == null ? void 0 : w.id;
            if (n == null) d("WALogger").ERROR(s());
            else {
                u.revokedMsgExternalId = d("WAStanzaUtils").toStanzaId(n);
                u.msgType = d("MAWMsgType").MSG_TYPE.REVOKED;
                return u
            }
        }
        if ((o == null ? void 0 : (m = o.obj.payload) == null ? void 0 : (w = m.content) == null ? void 0 : w.bumpExistingMessage) != null) {
            w = o == null ? void 0 : (n = o.obj.payload) == null ? void 0 : (m = n.content) == null ? void 0 : m.bumpExistingMessage;
            m = (n = w.key) == null ? void 0 : n.id;
            m != null && (h.has(m) || g.add(m), i.set(e, m));
            h = (n = w.key) == null ? void 0 : n.participant;
            if (h == null) {
                h = (g = w.key) == null ? void 0 : g.remoteJid
            }
            if (h == null) d("WALogger").ERROR(r());
            else {
                i = d("WAJids").unsafeCoerceToUserJid(h);
                m = i === c ? d("WAJids").AUTHOR_ME : i;
                k.set(d("WAStanzaUtils").toStanzaId(e), m);
                u.msgType = d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE;
                return u
            }
        }
        if ((o == null ? void 0 : (n = o.obj) == null ? void 0 : (w = n.payload) == null ? void 0 : (g = w.content) == null ? void 0 : g.noteReplyMessage) != null) {
            m = o == null ? void 0 : (h = o.obj) == null ? void 0 : (i = h.payload) == null ? void 0 : (k = i.content) == null ? void 0 : k.noteReplyMessage;
            n = m.noteTimestampMs;
            w = m.noteText;
            h = (g = a.metadata) == null ? void 0 : g.senderId;
            if (n != null && typeof n === "number" && h != null && f != null) {
                i = d("MAWJids").toUserJid(h);
                k = d("MAWJids").toUserJid(f);
                a = k === i ? c : k;
                g = {
                    author: a === c ? d("WAJids").AUTHOR_ME : a,
                    externalId: d("WAStanzaUtils").toStanzaId(e),
                    ts: d("WATimeUtils").castMilliSecondsToUnixTime(n),
                    type: d("WAMsgType").NOTE_REPLY
                };
                if ((w == null ? void 0 : w.text) != null) {
                    h = {
                        content: w == null ? void 0 : w.text,
                        mentionedJids: w == null ? void 0 : w.mentionedJid.map(function(a) {
                            return d("MAWJids").toUserJid(a)
                        })
                    };
                    g.msgContent = h
                }
                u.noteReply = g
            }
            if (m.textContent != null) {
                u.msgType = d("MAWMsgType").MSG_TYPE.TEXT;
                u.decodedPayload = m.textContent;
                return u
            } else if (m.stickerContent != null) {
                f = d("decodeProtobuf").decodeProtobuf(d("WAMediaTransport.pb").StickerTransportSpec, m.stickerContent.payload);
                b = R(f, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.STICKER);
                u.msgType = d("MAWMsgType").MSG_TYPE.STICKER;
                u.mediaMetadata = b;
                T(e, b, v, "attachment", j);
                return u
            } else if (m.videoContent != null) {
                i = d("decodeProtobuf").decodeProtobuf(d("WAMediaTransport.pb").VideoTransportSpec, m.videoContent.payload);
                b = R(i, d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.VIDEO);
                b != null && b.xAttachmentType === d("EchoMessageMediaFieldUtils").EchoMessageActMediaAttachmentType.GIF ? u.msgType = d("MAWMsgType").MSG_TYPE.GIF : u.msgType = d("MAWMsgType").MSG_TYPE.VIDEO;
                u.mediaMetadata = b;
                T(e, b, v, "attachment", j);
                return u
            }
        }
        if ((o == null ? void 0 : (k = o.obj) == null ? void 0 : (c = k.payload) == null ? void 0 : (a = c.content) == null ? void 0 : a.ravenMessageMsgr) != null) {
            u.ravenMsgEphemeralType = ca(o == null ? void 0 : (n = o.obj) == null ? void 0 : (w = n.payload) == null ? void 0 : (h = w.content) == null ? void 0 : (g = h.ravenMessageMsgr) == null ? void 0 : g.ephemeralType);
            if ((o == null ? void 0 : (f = o.obj) == null ? void 0 : (m = f.payload) == null ? void 0 : (i = m.content) == null ? void 0 : (b = i.ravenMessageMsgr) == null ? void 0 : b.imageMessage) != null) {
                if (l == null || !l) {
                    u.ravenUnstoredMedia = d("WAParseMediaTransportProtocol").decodeImageTransport(o == null ? void 0 : (k = o.obj) == null ? void 0 : (c = k.payload) == null ? void 0 : (a = c.content) == null ? void 0 : (n = a.ravenMessageMsgr) == null ? void 0 : (w = n.imageMessage) == null ? void 0 : w.payload, d("WATimeUtils").castMilliSecondsToUnixTime(u.sortOrderMs))
                }
                u.ravenMsgMediaType = d("MAWMsg").MAWRavenMsgMediaType.IMAGE
            } else if ((o == null ? void 0 : (h = o.obj) == null ? void 0 : (g = h.payload) == null ? void 0 : (f = g.content) == null ? void 0 : (m = f.ravenMessageMsgr) == null ? void 0 : m.videoMessage) != null) {
                if (l == null || !l) {
                    n = d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAMediaTransport.pb").VideoTransportSpec, o == null ? void 0 : (i = o.obj) == null ? void 0 : (b = i.payload) == null ? void 0 : (k = b.content) == null ? void 0 : (c = k.ravenMessageMsgr) == null ? void 0 : (a = c.videoMessage) == null ? void 0 : a.payload);
                    w = d("WAParseMediaTransportProtocol").parseVideoMsg(n, d("WATimeUtils").castMilliSecondsToUnixTime(u.sortOrderMs), !1);
                    w != null ? u.ravenUnstoredMedia = w : d("WALogger").ERROR(q())
                }
                u.ravenMsgMediaType = d("MAWMsg").MAWRavenMsgMediaType.VIDEO
            }
            u.msgType = d("MAWMsgType").MSG_TYPE.RAVEN;
            return u
        } else if ((o == null ? void 0 : (h = o.obj) == null ? void 0 : (g = h.payload) == null ? void 0 : (f = g.content) == null ? void 0 : f.pollCreationMessage) != null) {
            u.msgType = d("MAWMsgType").MSG_TYPE.GROUP_POLL_CREATE;
            m = o.obj.payload.content.pollCreationMessage;
            l = m.encKey;
            i = m.name;
            b = m.options;
            k = m.selectableOptionsCount;
            l != null && i != null && b != null && (u.groupPollInfo = {
                encryptionKey: l,
                name: i,
                options: b.map(function(a) {
                    a = a.optionName;
                    return a != null ? {
                        optionName: a
                    } : null
                }).filter(Boolean),
                selectableOptionsCount: k || 0
            });
            u.futureProofMessageType = "pollCreationMessage";
            return u
        }
        o != null && ea(u, o.obj);
        d("WALogger").ERROR(p());
        return u
    }

    function ea(a, b) {
        var c;
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.locationMessage) != null && (a.futureProofMessageType = "locationMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.liveLocationMessage) != null && (a.futureProofMessageType = "liveLocationMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.pollCreationMessage) != null && (a.futureProofMessageType = "pollCreationMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.pollUpdateMessage) != null && (a.futureProofMessageType = "pollUpdateMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.viewOnceMessage) != null && (a.futureProofMessageType = "viewOnceMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.contactMessage) != null && (a.futureProofMessageType = "contactMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.extendedTextMessage) != null && (a.futureProofMessageType = "extendedTextMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.groupInviteMessage) != null && (a.futureProofMessageType = "groupInviteMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.commonSticker) != null && (a.futureProofMessageType = "commonSticker");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.screenshotAction) != null && (a.futureProofMessageType = "screenshotAction");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.extendedMessageContentWithSear) != null && (a.futureProofMessageType = "extendedMessageContentWithSear");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.imageGalleryMessage) != null && (a.futureProofMessageType = "imageGalleryMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.content) == null ? void 0 : c.paymentsTransactionMessage) != null && (a.futureProofMessageType = "paymentsTransactionMessage");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (c = c.applicationData) == null ? void 0 : c.metadataSync) != null && (a.futureProofMessageType = "metadataSync");
        (b == null ? void 0 : (c = b.payload) == null ? void 0 : (b = c.applicationData) == null ? void 0 : b.aiBotResponse) != null && (a.futureProofMessageType = "aiBotResponse")
    }

    function U(a, b, c, e) {
        var f;
        f = (f = a.metadata) == null ? void 0 : f.messageId;
        a = d("decodeProtobuf").decodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, a.encryptedTransportMessage);
        var g = d("WAParseMessageApplication").parseMessageApplication(a);
        if (g.type === "error") {
            d("WALogger").ERROR(o());
            return
        }
        a = a.metadata;
        var h = a == null ? void 0 : a.quotedMessage;
        h = h == null ? void 0 : h.stanzaId;
        f != null && h != null && (c.has(h) || b.add(h), e.set(f, h));
        if (g.subprotocolType === "armadillo") {
            c = d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAArmadilloApplication.pb").ArmadilloSpec, g.payload);
            return {
                metadata: a,
                obj: c
            }
        } else if (g.subprotocolType === "consumerMessage") return {
            metadata: a,
            obj: d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAConsumerApplication.pb").ConsumerApplicationSpec, g.payload)
        }
    }

    function V(a, b, c, d, e, f, g, h, i) {
        return a.map(function(a) {
            return W(a, b, c, d, e, f, g, h, i)
        })
    }

    function W(a, b, c, e, f, g, h, i, j) {
        g === void 0 && (g = new Map());
        var k = d("decodeProtobuf").decodeProtobuf(d("WAArmadilloBackupMessage.pb").BackupMessageSpec, a.toplevelProtobuf.decryptedProtobuf);
        k = da(k, a.toplevelProtobuf.protobufTimestampMS, b, a.otid, c, e, f, g, h, i, j);
        c = a.supplementalProtobufs;
        for (h of c) {
            i = h[0];
            j = h[1];
            c = d("MessageBackupSupplementalKeyGenerator").parseIdentifierString(i);
            d("MAWODSProxy").odsBumpEntityKey({
                entity: d("WAOdsEnums").Entity.MAW_EB_DECODE_MESSAGE_PROTOBUF_SUPPLEMENTAL,
                key: c.type
            });
            i = d("decodeProtobuf").decodeProtobuf(d("WAArmadilloBackupMessage.pb").BackupMessageSpec, j.decryptedProtobuf);
            if (i.encryptedTransportMessage == null) continue;
            switch (c.type) {
                case "raven_action_message":
                    var l = U(i, e, f, g),
                        m = c.senderId;
                    m = d("MAWJids").toUserJid(m);
                    m = m === b ? d("WAJids").AUTHOR_ME : m;
                    if (l != null) {
                        var o, p, q;
                        l = l.obj;
                        o = (o = l.payload) == null ? void 0 : (o = o.content) == null ? void 0 : (o = o.ravenActionNotifMessage) == null ? void 0 : o.actionTimestamp;
                        p = (p = l.payload) == null ? void 0 : (p = p.content) == null ? void 0 : (p = p.ravenActionNotifMessage) == null ? void 0 : p.actionType;
                        if (o != null && p != null && typeof o === "number" && ((q = l.payload) == null ? void 0 : (q = q.content) == null ? void 0 : (q = q.ravenActionNotifMessage) == null ? void 0 : (q = q.key) == null ? void 0 : q.id) != null) {
                            q = d("WAStanzaUtils").toStanzaId((q = l.payload) == null ? void 0 : (l = q.content) == null ? void 0 : (q = l.ravenActionNotifMessage) == null ? void 0 : (l = q.key) == null ? void 0 : l.id);
                            if (((l = i.metadata) == null ? void 0 : l.timestampMs) != null && typeof((l = i.metadata) == null ? void 0 : l.timestampMs) === "number" && ((l = i.metadata) == null ? void 0 : l.messageId) != null) {
                                var r;
                                l = (l = i.metadata) == null ? void 0 : l.messageId;
                                r = d("WATimeUtils").castMilliSecondsToUnixTime((r = i.metadata) == null ? void 0 : r.timestampMs);
                                l = d("WAStanzaUtils").toStanzaId(l);
                                p = p === 0 ? d("MAWMsg").MAWRavenActionNotifType.PLAYED : p === 1 ? d("MAWMsg").MAWRavenActionNotifType.SCREENSHOTTED : d("MAWMsg").MAWRavenActionNotifType.FORCE_DISABLED;
                                o = {
                                    ack: d("WAAckLevel").ACK.RECEIVED,
                                    actionTimestamp: d("WATimeUtils").castMilliSecondsToUnixTime(o),
                                    actionType: p,
                                    author: m,
                                    externalId: l,
                                    ravenActionToMsgExternalId: q,
                                    ts: r,
                                    type: d("MAWMsgType").MSG_TYPE.RAVEN_ACTION
                                };
                                k.ravenActionUnstoredMsg = o
                            }
                        }
                    }
                    break;
                case "reaction":
                    m = (p = i.metadata) == null ? void 0 : p.messageId;
                    o = (l = U(i, e, f, g)) == null ? void 0 : (q = l.obj.payload) == null ? void 0 : (r = q.content) == null ? void 0 : r.reactionMessage;
                    p = d("WAJids").extractUserId(c.senderJid);
                    o != null && p != null && k.reactionData.push({
                        reaction: o,
                        reactionExternalId: m,
                        senderId: p,
                        ts: d("WATimeUtils").castMilliSecondsToUnixTime(j.protobufTimestampMS)
                    });
                    break;
                case "edit":
                    l = c.externalId;
                    m = (q = U(i, e, f, g)) == null ? void 0 : (r = q.obj.payload) == null ? void 0 : (o = r.content) == null ? void 0 : o.editMessage;
                    j = (p = i.metadata) == null ? void 0 : p.senderId;
                    if (m != null) {
                        r = (q = m.key) == null ? void 0 : q.id;
                        o = m.timestampMs;
                        if (r != null && o != null && j != null && typeof o === "number") {
                            i = d("MAWJids").toUserJid(j);
                            p = i === b ? d("WAJids").AUTHOR_ME : i;
                            k.editMsgData.push({
                                author: p,
                                editMsgContent: m,
                                externalId: l,
                                originalMsgExternalId: d("WAStanzaUtils").toStanzaId(r),
                                ts: d("WATimeUtils").castMilliSecondsToUnixTime(o)
                            })
                        }
                    }
                    break;
                case "unknown":
                    d("WALogger").ERROR(n());
                    break;
                default:
                    c.type
            }
        }
        f.add(a.otid);
        return k
    }

    function fa(a, b, e, f, g, h) {
        g == null ? void 0 : g.addPoint("replies_restore_start");
        return J(a, f, g).then(function() {
            b != null && (h.forEach(function(a) {
                d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(a, b, void 0, c("LSMEBTaskCreationSource").POINT_QUERY_FROM_EB, f)
            }), h.clear())
        })
    }

    function ga(a, e, f, g) {
        f == null ? void 0 : f.addPoint("xma_restore_start");
        var h = [],
            j = new Map();
        return (i || (i = b("Promise"))).all(a.map(function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                if (d("MAWDbMsg").isXMAMsg(a)) {
                    var b = a.externalId,
                        c = e.get(b);
                    if (c != null && c.xmaData != null) {
                        c = N(a.author, a.externalId, a.msgId, a.threadJid, c.xmaData);
                        if (c != null) {
                            var f, i, k = [],
                                l = [],
                                m = [],
                                n = new Map();
                            b = g.get(b);
                            b != null && b.forEach(function(b) {
                                var c = d("WAMediaUtils").stringToDeliveryObjectId(b.mediaMetadata.attachmentObjectId),
                                    e = d("WAHashUtils").stringToPlaintextHash(d("MAWHandleEchoMediaMsgsRestoreV2").getBase64WithoutPadding(b.mediaMetadata.plaintextHash)),
                                    g = n.get(e);
                                n.set(e, g != null ? [].concat(g, [a.msgId]) : [a.msgId]);
                                m.push(c);
                                b.mediaRestoreType === "xma_header" && (f = c);
                                b.mediaRestoreType === "xma_favicon" && (i = c);
                                b.mediaRestoreType === "xma_preview" && k.push(c)
                            });
                            var o = (yield d("MAWHandleEchoXMARestoreV2").getMediaForXMAByObjectIds(m, n));
                            o.forEach(function(a, b) {
                                j.set(a.mediaId, a)
                            });
                            if (f != null) {
                                c.headerMediaId = (b = o.get(f)) == null ? void 0 : b.mediaId
                            }
                            if (i != null) {
                                c.faviconMediaId = (b = o.get(i)) == null ? void 0 : b.mediaId
                            }
                            k.forEach(function(a) {
                                a = (a = o.get(a)) == null ? void 0 : a.mediaId;
                                a != null && l.push(a)
                            });
                            c.previewMediaIds = l;
                            l.length > 0 && (c.defaultPreviewMediaId = l[0]);
                            h.push(c)
                        }
                    }
                }
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }())).then(function() {
            return d("MAWHandleEchoXMARestoreV2").writeXMAsToDb(h).then(function(a) {
                a.forEach(function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                        var b;
                        a.previewMediaIds != null && a.previewMediaIds.length > 0 && (b = j.get(a.previewMediaIds[0]));
                        var e;
                        c("gkx")("821") ? e = (yield d("MAWHandleXmaTransactionUtil").checkMediaChunkTransactionAndCreatedBridgeXma(b, a)) : e = d("MAWBridgeXMA").createBridgeXMA(b, a, !1);
                        d("MAWMediaGalleryM2Utils").isMediaGalleryM2Enabled({
                            isSilent: !0
                        }) && c("FBLogger")("messenger_e2ee_web").info("Calling into NewXMA from %s", "MAWHandleEchoProtobufsRestoreApi");
                        d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
                            events: [{
                                tag: "NewXMA",
                                value: e
                            }]
                        })
                    });
                    return function(b) {
                        return a.apply(this, arguments)
                    }
                }()), f == null ? void 0 : f.addPoint("xma_restore_end", {
                    "int": {
                        xma: a.length
                    }
                })
            })
        })
    }

    function a(a) {
        return X.apply(this, arguments)
    }

    function X() {
        X = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var e = a.currentUserJid,
                f = a.deanonApiPayload,
                g = a.decryptedMessagesProtobufs,
                m = a.echoMessages,
                n = a.hasMoreAfter,
                o = a.hasMoreBefore,
                p = a.instanceKey,
                q = a.isMediaGalleryRestore,
                r = a.isPointRestore,
                s = a.minMsgId,
                t = a.referenceTimestamp,
                u = a.requestId,
                v = a.threadJidPrimaryId;
            a = a.uploadedFromEbQueue;
            if (g.length === 0) return (i || (i = b("Promise"))).resolve();
            d("WALogger").LOG(l(), g.length, r, t);
            var w = new Set(),
                x = new Set(),
                y = new Map(),
                z = new Map(),
                A = new Map(),
                B = v,
                C = (yield d("MAWHandleEchoMsgsRestoreApiV2").getThread(v, u));
            t = r ? d("MAWHandleEchoMsgsRestoreApiUtils").MAWRestoreType.POINT_RESTORE : t != null ? d("MAWHandleEchoMsgsRestoreApiUtils").MAWRestoreType.PAGINATED_RESTORE : d("MAWHandleEchoMsgsRestoreApiUtils").MAWRestoreType.INITIAL_RESTORE;
            t = t;
            var D = d("MAWQplProxy").startQplUserFlow(c("qpl")._(521486220, "827"), {
                bool: {
                    isPointRestore: r,
                    uploadedFromEbQueue: a
                },
                "int": {
                    messages: g.length
                },
                string: {
                    message_backup_type: "protobuf",
                    restore_type: t
                }
            }, void 0, 3e5);
            d("MAWEBRestoreTrackingUtils").addQPLRestorePointWithAnnotationsWorker({
                annotations: {
                    bool: {
                        isPointRestore: r,
                        uploadedFromEbQueue: a
                    },
                    "int": {
                        messages: g.length
                    },
                    string: {
                        message_backup_type: "protobuf",
                        restore_type: t
                    }
                },
                pointName: "restore_maw_job_start",
                traceId: u
            });
            d("MAWTraceUtils").recordCheckpointForTrace(u, (h || (h = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_ECHO_MESSAGE_RESTORE_BEGIN), [], !1);
            try {
                if (C) {
                    t = V(g, e, v, w, x, y, A, z);
                    D == null ? void 0 : D.addPoint("restore_protobuf_decode_done", {
                        "int": {
                            decoded_count: t.length,
                            input_decode_gap: g.length - t.length
                        }
                    });
                    var E = C.jid,
                        F = new Set(),
                        G = new Map(),
                        H = new Map(),
                        I = t.map(function(a) {
                            G.set(d("WAStanzaUtils").toStanzaId(a.externalId), a);
                            var b = O(a, E, e, y, H);
                            b == null && F.add(a.externalId);
                            return b
                        }).filter(Boolean),
                        J = t.filter(function(a) {
                            return F.has(a == null ? void 0 : a.externalId)
                        });
                    m != null && m.length > 0 && m.length !== g.length && (D == null ? void 0 : D.addPoint("mismatch_between_echo_and_protobuf_payload_from_server", {
                        "int": {
                            echoMessagesLength: m.length,
                            protobufMessagesLength: g.length
                        }
                    }));
                    if (J.length > 0) {
                        var K = new Map();
                        J.forEach(function(a) {
                            var b = "unknown";
                            a.msgType != null ? b = a.msgType : a.futureProofMessageType != null && (b = a.futureProofMessageType);
                            a = K.get(b);
                            a != null ? K.set(b, a + 1) : K.set(b, 1)
                        });
                        var L = {};
                        K.forEach(function(a, b) {
                            b = "protobuf_restore_failure_" + b;
                            L[b] = a
                        });
                        D == null ? void 0 : D.addPoint("protobuf_restore_failed_count_by_msg_type", {
                            "int": L
                        });
                        if (m != null && m.length === g.length) {
                            d("WALogger").LOG(k());
                            x.clear();
                            D == null ? void 0 : D.addPoint("reverting_to_echo_restore");
                            yield d("MAWHandleEchoMsgsRestoreApiV2").handleEchoMsgsBulkRestore(v, m, !1, o, n, s, void 0, void 0, p, void 0, void 0, D, void 0, a, c("justknobx")._("3060") && q);
                            return
                        }
                    }
                    J = I.map(function(a) {
                        return {
                            author: a.author,
                            chat: C.jid,
                            externalId: a.stanzaId
                        }
                    });
                    var M = new Set();
                    m = I.map(function(a) {
                        M.add(a.stanzaId);
                        return babelHelpers["extends"]({}, babelHelpers["extends"]({}, a.unstoredDbContent.unstoredDbMsg, {
                            threadJid: C.jid
                        }))
                    });
                    var N = new Map();
                    f != null && f.forEach(function(a) {
                        N.set(a.externalId, a.sortOrderMs)
                    });
                    t.forEach(function(a) {
                        var b = a.sortOrderMs;
                        a = a.externalId;
                        if (N.size > 0 && b != null) {
                            a = N.get(a);
                            a != null && (a !== b && (D == null ? void 0 : D.addPoint("protobuf_restore_toplevel_ts_mismatch")))
                        }
                    });
                    m.sort(function(a, b) {
                        return ((a = a.sortOrderMs) != null ? a : 0) - ((a = b.sortOrderMs) != null ? a : 0)
                    });
                    n = (yield(i || (i = b("Promise"))).all([d("MAWRestoreMsgsTxns").maybeGetThreadNewestMessage(C), d("MAWRestoreMsgsTxns").maybeGetOldestNonAdminMessage(C), d("MAWRestoreMsgsTxns").getMsgsByProtocolMsgIds(J)]));
                    a = n[0];
                    I = n[1];
                    t = I.maybeOldestAdminMsg;
                    J = I.maybeOldestMsg;
                    I = n[2];
                    var P = new Set(I.filter(function(a) {
                        return !c("gkx")("1689") || a.type !== d("MAWMsgType").MSG_TYPE.CIPHERTEXT
                    }).map(function(a) {
                        return a.externalId
                    }));
                    n = m.filter(function(a) {
                        return !P.has(a.externalId)
                    });
                    m = r || o;
                    z = {
                        bumpMessageAuthorMap: z,
                        existingMsgs: I,
                        hasMoreBefore: (o = m) != null ? o : !0,
                        instanceKey: p,
                        isPointRestore: r,
                        maybeNewestMsg: a,
                        maybeOldestAdminMsg: t,
                        maybeOldestMsg: J,
                        minMsgId: s,
                        newMsgs: n,
                        shouldSkipSyncToUI: c("justknobx")._("3060") && q,
                        thread: C
                    };
                    D == null ? void 0 : D.addPoint("message_restore_start");
                    I = (yield d("MAWRestoreMsgsTxns").restoreMsgsForThread(z));
                    m = 0;
                    o = 0;
                    D == null ? void 0 : D.addPoint("message_restore_end");
                    p = [];
                    (I == null ? void 0 : I.existingMsgs) != null && (p = p.concat(I == null ? void 0 : I.existingMsgs), m = I == null ? void 0 : I.existingMsgs.length);
                    (I == null ? void 0 : I.newlyAddedMsgs) != null && (p = p.concat(I == null ? void 0 : I.newlyAddedMsgs), o = I == null ? void 0 : I.newlyAddedMsgs.length);
                    d("MAWRestoreValidationUtils").compareRestoredMsgstoDeanonData({
                        dbMsgArray: p,
                        deanonData: f,
                        echoMsgExternalIds: void 0,
                        protobufMsgs: g,
                        restoreQplFlow: D,
                        traceId: u
                    });
                    var Q = [];
                    yield i.all(p.map(function() {
                        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                            if (a != null)
                                if (A.has(a.externalId)) {
                                    var b = a.sortOrderMs,
                                        c = d("WAParseConsumerMessageProtocol").interpretAsNonSystemAuthor(a.author),
                                        e = A.get(a.externalId);
                                    b == null ? d("WALogger").ERROR(j()) : e != null && a.mediaId == null && e.map(function(e) {
                                        e = {
                                            author: c,
                                            echoMsg: void 0,
                                            externalId: a.externalId,
                                            isXMA: d("MAWDbMsg").isXMAMsg(a),
                                            mediaData: e.mediaMetadata,
                                            messageTimestamp: b,
                                            msgId: a.msgId,
                                            previewMediaData: e.previewMetadata,
                                            threadJId: a.threadJid
                                        };
                                        Q.push(e)
                                    })
                                } else if (a.type === d("MAWMsgType").MSG_TYPE.RAVEN) {
                                e = H.get(a.externalId);
                                e != null && (yield ka(a, e))
                            }
                        });
                        return function(b) {
                            return a.apply(this, arguments)
                        }
                    }()));
                    a = d("MAWHandleEchoMediaMsgsRestoreV2").downloadMediaAndWriteToMediaStore(Q, E, q);
                    t = i.all(p.map(function() {
                        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                            a = G.get(a.externalId);
                            a != null && (yield ha(a, E, D, e, c("justknobx")._("3060") && q), yield ia(a, E, e, D, c("justknobx")._("3060") && q), a.ravenActionUnstoredMsg != null && (yield la(a.ravenActionUnstoredMsg, C)))
                        });
                        return function(b) {
                            return a.apply(this, arguments)
                        }
                    }()));
                    D == null ? void 0 : D.addPoint("media_restore_start");
                    yield i.all([a, t]);
                    D == null ? void 0 : D.addPoint("media_restore_end", {
                        "int": {
                            media: Q.length
                        }
                    });
                    yield ga(p, G, D, A);
                    yield ma(p, G, D);
                    yield fa(p, B, r, E, D, w);
                    D.endSuccess({
                        "int": {
                            existingMsgs: m,
                            messages_lost: g.length - m - o,
                            newlyAddedMsgs: o,
                            restoredMsgs: m + o,
                            totalMsgsToRestore: g.length
                        },
                        string: {
                            threadJidPrimaryId: v
                        }
                    });
                    d("MAWTraceUtils").recordCheckpointForTrace(u, (h || (h = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_RESTORE_MESSAGES_SUCCESS), [], !1);
                    d("MAWTraceUtils").recordCheckpointForTrace(u, h.ofNumber(c("LSDataTraceCheckPoint").FLOW_END_AND_FLUSH), [], !0)
                }
            } finally {
                A.clear(), x.clear()
            }
        });
        return X.apply(this, arguments)
    }

    function ha(a, b, c, d, e) {
        return Y.apply(this, arguments)
    }

    function Y() {
        Y = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e, f) {
            c.addPoint("msg_history_start");
            if (a.editMsgData.length > 0) {
                var g, h, i, j = [],
                    k = a.sortOrderMs;
                g = (g = a.metadata) == null ? void 0 : g.messageId;
                h = (h = a.metadata) == null ? void 0 : h.senderId;
                i = (i = a.decodedPayload) == null ? void 0 : i.text;
                if (g != null && h != null) {
                    k = d("WATimeUtils").castMilliSecondsToUnixTime(k);
                    h = d("MAWJids").toUserJid(h);
                    g = d("WAStanzaUtils").toStanzaId(g);
                    e = h === e ? d("WAJids").AUTHOR_ME : h;
                    h = Z(e, i, g, g, k, b);
                    h != null && j.push(h);
                    a.editMsgData.forEach(function(a) {
                        var c;
                        c = Z(a.author, (c = a.editMsgContent.message) == null ? void 0 : c.text, a.externalId, a.originalMsgExternalId, a.ts, b);
                        c != null && j.push(c)
                    });
                    yield ja(j, f);
                    c.addPoint("msg_history_end")
                }
            }
        });
        return Y.apply(this, arguments)
    }

    function Z(a, b, c, e, f, g) {
        var h = a === d("WAJids").AUTHOR_ME ? d("WAAckLevel").ACK.SENT : d("WAAckLevel").ACK.RECEIVED;
        if (b != null) return {
            author: a,
            editExternalId: c,
            editTs: f,
            msgContent: {
                content: b
            },
            originalMsgExternalId: e,
            sendStatus: h,
            threadJid: g
        };
        d("WALogger").ERROR(m());
        return void 0
    }

    function ia(a, b, c, d, e) {
        return $.apply(this, arguments)
    }

    function $() {
        $ = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f, g, h) {
            f = L(a, e, f);
            a = a.metadata;
            if (f != null && a != null) {
                g.addPoint("reactions_restore_start");
                var j = a.messageId,
                    k = [];
                f.forEach(function(a, b) {
                    return k.push({
                        stanzaId: b,
                        waReactionMsg: a
                    })
                });
                if (c("gkx")("4219")) {
                    a = k.filter(function(a) {
                        a = a.waReactionMsg;
                        return j != null && a.ts != null
                    }).map(function(a) {
                        var b = a.stanzaId;
                        a = a.waReactionMsg;
                        return {
                            args: {
                                groupingKey: a.reaction.groupingKey,
                                reaction: a.reaction.text,
                                reactToAuthor: d("WAParseConsumerMessageProtocol").interpretAsNonSystemAuthor(a.reactToMsgAuthor),
                                reactToExternalId: a.reactToExternalId,
                                senderTimestampMs: a.reaction.senderTimestampMs
                            },
                            author: d("WAParseConsumerMessageProtocol").interpretAsNonSystemAuthor(a.reactionAuthor),
                            chatJid: e,
                            externalId: b,
                            ts: a.ts
                        }
                    });
                    yield d("MAWWriteReactionMsgApi").bulkWriteReactionMsg(a, h)
                } else {
                    f = (i || (i = b("Promise"))).all(k.map(function() {
                        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                            var b = a.waReactionMsg,
                                c = b.ts;
                            c != null && j != null && (yield d("MAWWriteReactionMsgApi").writeReactionMsg(a.stanzaId, e, {
                                groupingKey: b.reaction.groupingKey,
                                reaction: b.reaction.text,
                                reactToAuthor: d("WAParseConsumerMessageProtocol").interpretAsNonSystemAuthor(b.reactToMsgAuthor),
                                reactToExternalId: b.reactToExternalId,
                                senderTimestampMs: b.reaction.senderTimestampMs
                            }, c, d("WAParseConsumerMessageProtocol").interpretAsNonSystemAuthor(b.reactionAuthor), h))
                        });
                        return function(b) {
                            return a.apply(this, arguments)
                        }
                    }()));
                    yield f
                }
                g.addPoint("reactions_restore_end")
            }
        });
        return $.apply(this, arguments)
    }
    var ja = e.makeMsgrTransactor({
            editMsgHistory: f.READWRITE,
            messages: f.READWRITE
        }, "bulkAddEditMsgHistory", function(a) {
            return function(b, e) {
                return d("MAWDbEditMsgHistoryTxns").bulkAddEditMsgHistory(a, b, !e).then(c("emptyFunction"))
            }
        }),
        ka = e.makeMsgrTransactor({
            chunk: f.READWRITE,
            media: f.READWRITE,
            mediaBackup: f.READWRITE,
            messages: f.READWRITE
        }, "handleUnstoredMedia", function(a) {
            return function(b, c) {
                return d("MAWMediaManagementTxns").handleUnstoredDbMedia(a, c, b, "ebrestore", !1, !1, "EncryptedBackups")
            }
        }),
        la = e.makeMsgrTransactor({
            messages: f.READWRITE,
            unrenderedMessages: f.READWRITE
        }, "writeRavenActinomsg", function(a) {
            return function(b, c) {
                return d("MAWDbRavenActionTxns").writeRavenActionMsg(a, b, c)
            }
        });

    function ma(a, b, e) {
        if (!c("gkx")("5624")) return;
        e == null ? void 0 : e.addPoint("receiver_fetch_restore_start");
        var f = [];
        a.forEach(function(a) {
            if (a.type === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH && a.receiverFetchId != null) {
                var c = b.get(a.externalId);
                if (c != null && c.receiverFetchInfo != null) {
                    c = babelHelpers["extends"]({}, c.receiverFetchInfo, {
                        type: "sticker"
                    });
                    f.push({
                        dbMsg: a,
                        unstoredDbReceiverFetchInfo: c
                    })
                }
            }
        });
        return na(f).then(function() {
            e == null ? void 0 : e.addPoint("receiver_fetch_restore_end")
        })["catch"](function(a) {
            e == null ? void 0 : e.addPoint("receiver_fetch_restore_failure")
        })
    }
    var na = e.makeMsgrTransactor({
        receiverFetchInfo: f.READWRITE
    }, "restoreWriteReceiverFetchInfosToTb", function(a) {
        return function(b) {
            return d("MAWDexieTable").dexieAll(b.map(function(b) {
                var c = b.dbMsg;
                b = b.unstoredDbReceiverFetchInfo;
                return d("MAWWriteReceiverFetchTxns").handleUnstoredReceiverFetchInfo(a, c, b)
            }))
        }
    });
    g.associateQuotedMessagesForRestoredDbMsgsTransactor = J;
    g.createUnstoredDbContentFromProtobufObject = O;
    g.decodeProtobufArray = V;
    g.decodeDecryptedMessageProtobuf = W;
    g.handleProtobufsRestore = a;
    g.writeReceiverFetchInfosToTb = na
}), 98);
__d("MAWEBUnstoredDbMsgUtils", ["FBLogger", "MAWEBUploadMessageUtils", "MAWHandleEBRestoreWithHIM", "MAWHandleEchoProtobufsRestoreApi", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to convert echo message to unstored db message"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b, e, f) {
        var g = e != null ? e : b != null ? d("WAJids").unsafeCoerceToChatJid(b) : void 0;
        if (g == null) {
            c("FBLogger")("labyrinth_web").mustfix("threadId and chatJid are both null - cannot convert protobuf to unstoredDbMsg");
            return []
        }
        return d("MAWHandleEchoProtobufsRestoreApi").decodeProtobufArray(a, f, void 0, new Set(), new Set(), new Map(), new Map(), new Map(), !0).map(function(a) {
            var b;
            if ((a == null ? void 0 : (b = a.metadata) == null ? void 0 : b.messageId) != null) {
                b = d("MAWHandleEchoProtobufsRestoreApi").createUnstoredDbContentFromProtobufObject(a, g, f, new Map(), void 0);
                if (b != null && b.unstoredDbContent.unstoredDbMsg != null) {
                    a = b.unstoredDbContent.unstoredDbMsg;
                    b = d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(a);
                    a.sortOrderMs = b;
                    return a
                }
                return null
            }
            return null
        }).filter(Boolean)
    }

    function b(a, b, c) {
        return d("MAWHandleEBRestoreWithHIM").convertEchoMessages(a, b).map(function(a) {
            var b;
            if (a == null || a.length === 0 || ((b = a[0].decodedMsg) == null ? void 0 : b.unstoredDbMsg) == null) {
                c != null && c.ERROR(h());
                return null
            }
            return (b = a[0].decodedMsg) == null ? void 0 : b.unstoredDbMsg
        }).filter(Boolean)
    }
    g.getUnstoredDbMsgFromProtobuf = a;
    g.getUnstoredDbMsgFromEcho = b
}), 98);
__d("MAWRestoreMessagesFromEncryptedBackupsDeferred", ["ExecutionEnvironment", "LSDatabaseSingleton", "LSVec", "MAWEncryptedBackupUtils", "Promise", "WAJobOrchestratorTypes", "asyncToGeneratorRuntime", "cr:10036", "gkx", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = c("requireDeferred")("MAWRestoreMessagesFromEncryptedBackupsNOP").__setRef("MAWRestoreMessagesFromEncryptedBackupsDeferred");

    function a(a, e, f, g, l, m, n, o, p, q, r, s, t) {
        t === void 0 && (t = d("WAJobOrchestratorTypes").JOB_PRIORITY.UI_ACTION);
        return k.load().then(function() {
            var k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(k) {
                var u = q != null ? Number(q) : void 0;
                u = c("gkx")("201") ? d("MAWEncryptedBackupUtils").getMessageMetadataFromDeanonAPI(e, f.length, u) : (j || (j = b("Promise"))).resolve();
                var v, w;
                (i || (i = c("ExecutionEnvironment"))).isInWorker && b("cr:10036") != null ? (yield b("cr:10036").init(), v = (yield b("cr:10036").getLSStorage())) : (v = (yield(h || (h = d("LSDatabaseSingleton"))).LSDatabaseSingleton), w = (yield u));
                return v.runInTransaction(function(b) {
                    return k.call(b, a, e, f, g, l, m, n, o, p, q, r, w, s, t)
                }, "readwrite").then(function() {
                    return [c("LSVec").ofArray([]), c("LSVec").ofArray([]), !1]
                })["catch"](function() {
                    return [c("LSVec").ofArray([]), c("LSVec").ofArray([]), !1]
                })
            });
            return function(a) {
                return k.apply(this, arguments)
            }
        }())
    }
    g.call = a
}), 98);
__d("MAWRestoreProtobufsFromEncryptedBackupsDeferred", ["ExecutionEnvironment", "I64", "LSDatabaseSingleton", "WAJobOrchestratorTypes", "asyncToGeneratorRuntime", "cr:10036", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = c("requireDeferred")("MAWRestoreProtobufsFromEncryptedBackupsNOP").__setRef("MAWRestoreProtobufsFromEncryptedBackupsDeferred");

    function a(a, e, f, g, l, m, n, o, p, q, r, s, t, u, v) {
        v === void 0 && (v = d("WAJobOrchestratorTypes").JOB_PRIORITY.UI_ACTION);
        return k.load().then(function() {
            var k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(k) {
                var w;
                (j || (j = c("ExecutionEnvironment"))).isInWorker && b("cr:10036") != null ? (yield b("cr:10036").init(), w = (yield b("cr:10036").getLSStorage())) : w = (yield(h || (h = d("LSDatabaseSingleton"))).LSDatabaseSingleton);
                return w.runInTransaction(function(b) {
                    return k.call(b, a, e, f, g, l != null ? (i || (i = d("I64"))).to_float(l) : 0, m, n != null ? (i || (i = d("I64"))).to_float(n) : (i || (i = d("I64"))).to_float((i || (i = d("I64"))).max_int), o, p, q, r, s, t, u, v)
                }, "readwrite")
            });
            return function(a) {
                return k.apply(this, arguments)
            }
        }())
    }
    g.call = a
}), 98);
__d("MediaDownloadMediator", ["asyncToGeneratorRuntime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = new Map();

    function a(a, b) {
        g.set(a, b)
    }

    function c(a, b) {
        return h.apply(this, arguments)
    }

    function h() {
        h = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            var c;
            yield(c = g.get(a)) == null ? void 0 : c["continue"](b);
            g["delete"](a)
        });
        return h.apply(this, arguments)
    }

    function d(a, b) {
        var c;
        void((c = g.get(a)) == null ? void 0 : c.handleError(b));
        g["delete"](a)
    }
    f.mapDeliveryObjectIdToMediaDownloader = a;
    f.handleNewCDNUrlFromMI = c;
    f.handleMIDownloadFailure = d
}), 66);
__d("WAFrankingNode", ["Promise", "WAFranking", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Can't handle franking version ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Franking key is missing"]);
        j = function() {
            return a
        };
        return a
    }

    function a(a, c, e) {
        if (c == null) {
            d("WALogger").ERROR(j());
            return (h || (h = b("Promise"))).resolve(null)
        }
        if (e != null && e !== 0) {
            d("WALogger").ERROR(i(), e);
            return (h || (h = b("Promise"))).resolve(null)
        }
        return d("WAFranking").genFrankingTag(c, a)
    }
    g.genFrankingTagFromMessageApplicationEncode = a
}), 98);
__d("WAGenReportingMeta", ["WAByteArray", "WAFranking", "WAFrankingNode", "WAGlobals", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c) {
        return h.apply(this, arguments)
    }

    function h() {
        h = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            if (d("WAGlobals").getConfig().isFrankingEnabled()) {
                var e = (yield d("WAFrankingNode").genFrankingTagFromMessageApplicationEncode(a, b, c));
                return {
                    frankingKey: b,
                    frankingTag: e,
                    frankingVersion: d("WAFranking").getFrankingVersion(c),
                    reportingContent: d("WAByteArray").uint8ArrayToBuffer(a),
                    reportingTag: null
                }
            } else return {
                frankingKey: b,
                frankingTag: null,
                frankingVersion: d("WAFranking").getFrankingVersion(c),
                reportingContent: null,
                reportingTag: null
            }
        });
        return h.apply(this, arguments)
    }
    g.genReportingMeta = a
}), 98);
__d("WAPushSafeTypes", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f.unsafeNotNullable = a
}), 66);