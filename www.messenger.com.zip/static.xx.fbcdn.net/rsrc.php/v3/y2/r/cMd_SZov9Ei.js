; /*FB_PKG_DELIM*/

__annotator = function(a) {
    return a
}, __d_stub = [], __d = function(a, b, c, d) {
    __d_stub.push([a, b, c, d])
}, __rl_stub = [], requireLazy = function() {
    __rl_stub.push(arguments)
};
//# sourceURL=https://static.xx.fbcdn.net/rsrc.php/v3/y2/r/cMd_SZov9Ei.js