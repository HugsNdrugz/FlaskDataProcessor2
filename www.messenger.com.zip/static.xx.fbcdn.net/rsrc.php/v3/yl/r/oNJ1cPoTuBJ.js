; /*FB_PKG_DELIM*/

__d("getChatJidForLSDBJid", ["I64", "LSMessagingThreadTypeUtil", "ReQL", "WAJids", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b, c) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            a = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.threads).getKeyRange(b)));
            if (a != null) {
                b = (h || (h = d("I64"))).to_string(c);
                return d("LSMessagingThreadTypeUtil").isGroup(a.threadType) ? d("WAJids").toGroupJid(b) : d("WAJids").toMsgrUserJid(b)
            }
        });
        return i.apply(this, arguments)
    }
    g.getMaybeChatJidForLSDBJid = a
}), 98);
__d("LSShimCompleteThreadCutover.nop", ["I64", "MAWBridgeFireAndForget", "ReQL", "asyncToGeneratorRuntime", "getChatJidForLSDBJid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e, f) {
            b = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.cutover_threads).getKeyRange(e)));
            if (b != null) {
                c = b.showOpenMessageHistory === !1;
                if (c) return [(h || (h = d("I64"))).one];
                c = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.mi_act_mapping_table.index("jid")).getKeyRange(b.armadilloThreadId)));
                if (c != null) {
                    b = (yield d("getChatJidForLSDBJid").getMaybeChatJidForLSDBJid(a, c.serverThreadKey, c.jid));
                    if (b == null) return [(h || (h = d("I64"))).one];
                    d("MAWBridgeFireAndForget").fireAndForget("backend", "insertAdminMessageInCutoverThreads", {
                        openThreadId: (h || (h = d("I64"))).to_string(e),
                        threadJid: b,
                        traceId: f
                    });
                    return [h.zero]
                }
                return [(h || (h = d("I64"))).one]
            }
            return [(h || (h = d("I64"))).one]
        });

        function c(b, c, d, e, f) {
            return a.apply(this, arguments)
        }
        return c
    }();
    g["default"] = a
}), 98);
__d("LSCompleteThreadCutover", ["LSShimCompleteThreadCutover.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.nativeOperation(b("LSShimCompleteThreadCutover.nop"), a[0], a[1], a[2]).then(function(a) {
                return a = a, d[0] = a[0], a
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxCompleteThreadCutoverStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteAllDeliverySettingWarnings", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.resolve(c)
    }
    a.__sproc_name__ = "LSOmnistoreSettingsDeleteAllDeliverySettingWarningsStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteThenInsertDeliverySetting", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(148).put({
                audience: a[0],
                deliverySetting: a[1],
                deliveryOptions: a[2],
                usernameToDeliverySetting: a[3]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsDeleteThenInsertDeliverySettingStoredProcedure";
    e.exports = a
}), null);
__d("LSInsertDeliverySettingWarning", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.resolve(c)
    }
    a.__sproc_name__ = "LSOmnistoreSettingsInsertDeliverySettingWarningStoredProcedure";
    e.exports = a
}), null);
__d("LSStoryContactSyncFromBucket", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(a) {
            return b.sequence([function(a) {
                return b.forEach(b.filter(b.db.table(7).fetch(), function(a) {
                    return !0
                }), function(a) {
                    var b = a.update;
                    a.item;
                    return b({
                        profileRingColor: void 0,
                        profileRingState: void 0
                    })
                })
            }, function(a) {
                return b.forEach(b.filter(b.db.table(53).fetch(), function(a) {
                    return b.i64.eq(a.bucketType, b.i64.cast([0, 1]))
                }), function(a) {
                    var d = a.item;
                    return c[1] = d.readState, b.i64.eq(c[1], b.i64.cast([0, 1])) ? c[0] = b.i64.cast([0, 39423]) : (b.i64.eq(c[1], b.i64.cast([0, 2])) ? c[2] = b.i64.cast([0, 14342874]) : c[2] = void 0, c[0] = c[2]), b.forEach(b.filter(b.db.table(7).fetch([
                        [
                            [d.ownerId]
                        ]
                    ]), function(a) {
                        return b.i64.eq(a.id, d.ownerId) && b.i64.eq(b.i64.cast([0, 1]), b.i64.cast([0, 1]))
                    }), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            profileRingState: c[1],
                            profileRingColor: c[0]
                        })
                    })
                })
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSStoriesStoryContactSyncFromBucketStoredProcedure";
    e.exports = a
}), null);
__d("LSTruncateFeatureLimits", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(a) {
            return b.forEach(b.db.table(150).fetch(), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsTruncateFeatureLimitsStoredProcedure";
    e.exports = a
}), null);
__d("LSTruncateReachabilitySettings", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(a) {
            return b.forEach(b.db.table(148).fetch(), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsTruncateReachabilitySettingsStoredProcedure";
    e.exports = a
}), null);