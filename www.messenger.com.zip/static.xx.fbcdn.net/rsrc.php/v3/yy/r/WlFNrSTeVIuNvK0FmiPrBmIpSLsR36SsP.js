; /*FB_PKG_DELIM*/

__d("LSDeleteThenInsertRankingRequest", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(135).put({
                scoreType: a[0],
                requestId: a[1]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSRankingDeleteThenInsertRankingRequestStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteThenInsertRankingScore", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(134).put({
                contactId: a[0],
                scoreType: a[1],
                contactType: a[2],
                score: a[3],
                scoreIndex: a[4]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSRankingDeleteThenInsertRankingScoreStoredProcedure";
    e.exports = a
}), null);
__d("LSTruncatePinnedThreads", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(a) {
            return b.forEach(b.db.table(82).fetch(), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsTruncatePinnedThreadsStoredProcedure";
    e.exports = a
}), null);
__d("LSUpsertFolder", ["LSUpdateFolderThreadSnippet"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(b) {
                return c.i64.neq(a[3], void 0) ? c.resolve(d[0] = a[3]) : c.sequence([function(b) {
                    return c.db.table(9).fetchDesc([
                        [
                            [a[0]]
                        ], "parentThreadKeyLastActivityTimestampMs"
                    ]).next().then(function(a, b) {
                        var e = a.done;
                        a = a.value;
                        return e ? d[3] = c.i64.cast([0, 0]) : (b = a.item, d[3] = b.lastActivityTimestampMs)
                    })
                }, function(a) {
                    return d[0] = d[3]
                }])
            }, function(b) {
                return c.i64.neq(a[4], void 0) ? c.resolve(d[1] = a[4]) : c.sequence([function(b) {
                    return c.sortBy(c.filter(c.db.table(9).fetch([
                        [
                            [a[0]]
                        ], "parentThreadKeyLastActivityTimestampMs"
                    ]), function(b) {
                        return c.i64.eq(b.parentThreadKey, a[0]) && c.i64.lt(b.lastReadWatermarkTimestampMs, b.lastActivityTimestampMs)
                    }), [
                        ["lastReadWatermarkTimestampMs", "ASC"]
                    ]).next().then(function(b, e) {
                        var f = b.done;
                        b = b.value;
                        return f ? c.sequence([function(b) {
                            return c.i64.neq(a[3], void 0) ? c.resolve(d[5] = a[3]) : c.sequence([function(b) {
                                return c.db.table(9).fetchDesc([
                                    [
                                        [a[0]]
                                    ], "parentThreadKeyLastActivityTimestampMs"
                                ]).next().then(function(b, e) {
                                    var a = b.done;
                                    b = b.value;
                                    return a ? d[6] = c.i64.cast([0, 0]) : (e = b.item, d[6] = e.lastActivityTimestampMs)
                                })
                            }, function(a) {
                                return d[5] = d[6]
                            }])
                        }, function(a) {
                            return d[3] = d[5]
                        }]) : (e = b.item, d[3] = e.lastReadWatermarkTimestampMs)
                    })
                }, function(a) {
                    return d[1] = d[3]
                }])
            }, function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(b, e) {
                    e = b.done;
                    b = b.value;
                    return e ? c.sequence([function(b) {
                        return c.forEach(c.filter(c.db.table(9).fetch([
                            [
                                [a[0]]
                            ]
                        ]), function(b) {
                            return c.i64.eq(b.threadKey, a[0]) && c.i64.lt(b.authorityLevel, c.i64.cast([0, 80]))
                        }), function(a) {
                            return a["delete"]()
                        })
                    }, function(b) {
                        return c.db.table(9).add({
                            threadKey: a[0],
                            mailboxType: c.i64.cast([0, 0]),
                            threadType: c.i64.cast([0, 6]),
                            threadName: a[1],
                            folderName: "",
                            parentThreadKey: c.i64.cast([0, 0]),
                            threadPictureUrl: a[2],
                            lastActivityTimestampMs: d[0],
                            lastReadWatermarkTimestampMs: d[1],
                            removeWatermarkTimestampMs: c.i64.cast([0, 0]),
                            muteExpireTimeMs: c.i64.cast([0, 0]),
                            snippet: "",
                            isAdminSnippet: !1,
                            hasPersistentMenu: !1,
                            disableComposerInput: !1,
                            snippetHasEmoji: !1,
                            authorityLevel: c.i64.cast([0, 80]),
                            ongoingCallState: c.i64.cast([0, 0]),
                            capabilities: c.i64.cast([0, 0]),
                            shouldRoundThreadPicture: !1
                        })
                    }]) : (b.item, c.forEach(c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        var e = b.update;
                        b.item;
                        return e({
                            threadName: a[1],
                            folderName: "",
                            parentThreadKey: c.i64.cast([0, 0]),
                            threadPictureUrl: a[2],
                            lastActivityTimestampMs: d[0],
                            lastReadWatermarkTimestampMs: d[1],
                            removeWatermarkTimestampMs: c.i64.cast([0, 0]),
                            muteExpireTimeMs: c.i64.cast([0, 0]),
                            snippet: "",
                            snippetText: void 0,
                            snippetStringHash: void 0,
                            snippetStringArgument1: void 0,
                            snippetAttribution: void 0,
                            snippetAttributionStringHash: void 0,
                            isAdminSnippet: !1,
                            hasPersistentMenu: !1,
                            disableComposerInput: !1,
                            snippetHasEmoji: !1,
                            authorityLevel: c.i64.cast([0, 80]),
                            ongoingCallState: c.i64.cast([0, 0]),
                            capabilities: c.i64.cast([0, 0]),
                            shouldRoundThreadPicture: !1
                        })
                    }))
                })
            }, function(d) {
                return c.storedProcedure(b("LSUpdateFolderThreadSnippet"), a[0], a[5], a[6])
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpsertFolderStoredProcedure";
    e.exports = a
}), null);
__d("LSExpandedStaticDependencies", ["LSAppendDataTraceAddon", "LSBeginHandlingFireForgetTasksForQueue", "LSClearAllScreenTimeRecords", "LSClearAllSupervisionEdgeRecords", "LSClearAllSupervisionMetadataRecords", "LSClearThreadLimits", "LSCompleteThreadCutover", "LSDeleteAllCmFbEventData", "LSDeleteAllCommunityChannelCategories", "LSDeleteAllCommunityFolders", "LSDeleteAllDeliverySettingWarnings", "LSDeleteAllPublicChatFbEventData", "LSDeleteBannersByIds", "LSDeleteThenInsertBotProfileInfoV2", "LSDeleteThenInsertCmCommunityList", "LSDeleteThenInsertContact", "LSDeleteThenInsertDeliverySetting", "LSDeleteThenInsertMessageRequest", "LSDeleteThenInsertMessagingPrivacySettings", "LSDeleteThenInsertNotificationsSettingsGraphQLSnapshot", "LSDeleteThenInsertProactiveWarningSettings", "LSDeleteThenInsertRankingRequest", "LSDeleteThenInsertRankingScore", "LSDeleteThenInsertThread", "LSEncryptedBackupsStatusTriggerUpsert", "LSEpdCookieSettingsUpsert", "LSExecuteFinallyBlockForSyncTransaction", "LSExecuteFirstBlockForSyncTransaction", "LSGroupRoomTruncate", "LSInsertDeliverySettingWarning", "LSIssueNextSync", "LSMailboxTaskCompletionApiOnTaskCompletion", "LSMarkBumpedThreadsSeen", "LSMarkFolderSeen", "LSPopulateCommunityFolderData", "LSRemoveTask", "LSReportAppState", "LSRoomTruncate", "LSSerializeTask", "LSSetBotResponseInfo", "LSSetMessageTextHasLinks", "LSSetRegionHint", "LSStoreProjectConfiguration", "LSStoryContactSyncFromBucket", "LSTaskExists", "LSTruncateCommunityListTable", "LSTruncateFeatureLimits", "LSTruncateNotificationSettings", "LSTruncatePakeMessagesDatabase", "LSTruncatePinnedThreads", "LSTruncateQuietTime", "LSTruncateReachabilitySettings", "LSUpdateCommunityThreadStaleState", "LSUpdateLastSyncCompletedTimestampMsToNow", "LSUpdateOrInsertCommunitySurfaceRange", "LSUpdateOrInsertOhaiGatewayKeyConfigs", "LSUpsertFolder", "LSUpsertGradientColor", "LSUpsertSequenceId", "LSUpsertTheme", "LSVerifyAndSaveNewCredentials", "LSVerifyContactParticipantExist", "LSVerifyContactRowExists", "LSVerifyE2EEMetadataThreadExistsV2", "LSVerifyThreadExists", "LSVerifyThreadRowExists"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        appendDataTraceAddon: c("LSAppendDataTraceAddon"),
        beginHandlingFireForgetTasksForQueue: c("LSBeginHandlingFireForgetTasksForQueue"),
        clearAllScreenTimeRecords: c("LSClearAllScreenTimeRecords"),
        clearAllSupervisionEdgeRecords: c("LSClearAllSupervisionEdgeRecords"),
        clearAllSupervisionMetadataRecords: c("LSClearAllSupervisionMetadataRecords"),
        clearThreadLimits: c("LSClearThreadLimits"),
        completeThreadCutover: c("LSCompleteThreadCutover"),
        deleteAllCmFbEventData: c("LSDeleteAllCmFbEventData"),
        deleteAllCommunityChannelCategories: c("LSDeleteAllCommunityChannelCategories"),
        deleteAllCommunityFolders: c("LSDeleteAllCommunityFolders"),
        deleteAllDeliverySettingWarnings: c("LSDeleteAllDeliverySettingWarnings"),
        deleteAllPublicChatFbEventData: c("LSDeleteAllPublicChatFbEventData"),
        deleteBannersByIds: c("LSDeleteBannersByIds"),
        deleteThenInsertBotProfileInfoV2: c("LSDeleteThenInsertBotProfileInfoV2"),
        deleteThenInsertCmCommunityList: c("LSDeleteThenInsertCmCommunityList"),
        deleteThenInsertContact: c("LSDeleteThenInsertContact"),
        deleteThenInsertDeliverySetting: c("LSDeleteThenInsertDeliverySetting"),
        deleteThenInsertMessageRequest: c("LSDeleteThenInsertMessageRequest"),
        deleteThenInsertMessagingPrivacySettings: c("LSDeleteThenInsertMessagingPrivacySettings"),
        deleteThenInsertNotificationsSettingsGraphQLSnapshot: c("LSDeleteThenInsertNotificationsSettingsGraphQLSnapshot"),
        deleteThenInsertProactiveWarningSettings: c("LSDeleteThenInsertProactiveWarningSettings"),
        deleteThenInsertRankingRequest: c("LSDeleteThenInsertRankingRequest"),
        deleteThenInsertRankingScore: c("LSDeleteThenInsertRankingScore"),
        deleteThenInsertThread: c("LSDeleteThenInsertThread"),
        encryptedBackupsStatusTriggerUpsert: c("LSEncryptedBackupsStatusTriggerUpsert"),
        epdCookieSettingsUpsert: c("LSEpdCookieSettingsUpsert"),
        executeFinallyBlockForSyncTransaction: c("LSExecuteFinallyBlockForSyncTransaction"),
        executeFirstBlockForSyncTransaction: c("LSExecuteFirstBlockForSyncTransaction"),
        groupRoomTruncate: c("LSGroupRoomTruncate"),
        insertDeliverySettingWarning: c("LSInsertDeliverySettingWarning"),
        issueNextSync: c("LSIssueNextSync"),
        mailboxTaskCompletionApiOnTaskCompletion: c("LSMailboxTaskCompletionApiOnTaskCompletion"),
        markBumpedThreadsSeen: c("LSMarkBumpedThreadsSeen"),
        markFolderSeen: c("LSMarkFolderSeen"),
        populateCommunityFolderData: c("LSPopulateCommunityFolderData"),
        removeTask: c("LSRemoveTask"),
        reportAppState: c("LSReportAppState"),
        roomTruncate: c("LSRoomTruncate"),
        serializeTask: c("LSSerializeTask"),
        setBotResponseInfo: c("LSSetBotResponseInfo"),
        setMessageTextHasLinks: c("LSSetMessageTextHasLinks"),
        setRegionHint: c("LSSetRegionHint"),
        storeProjectConfiguration: c("LSStoreProjectConfiguration"),
        storyContactSyncFromBucket: c("LSStoryContactSyncFromBucket"),
        taskExists: c("LSTaskExists"),
        truncateCommunityListTable: c("LSTruncateCommunityListTable"),
        truncateFeatureLimits: c("LSTruncateFeatureLimits"),
        truncateNotificationSettings: c("LSTruncateNotificationSettings"),
        truncatePakeMessagesDatabase: c("LSTruncatePakeMessagesDatabase"),
        truncatePinnedThreads: c("LSTruncatePinnedThreads"),
        truncateQuietTime: c("LSTruncateQuietTime"),
        truncateReachabilitySettings: c("LSTruncateReachabilitySettings"),
        updateCommunityThreadStaleState: c("LSUpdateCommunityThreadStaleState"),
        updateLastSyncCompletedTimestampMsToNow: c("LSUpdateLastSyncCompletedTimestampMsToNow"),
        updateOrInsertCommunitySurfaceRange: c("LSUpdateOrInsertCommunitySurfaceRange"),
        updateOrInsertOhaiGatewayKeyConfigs: c("LSUpdateOrInsertOhaiGatewayKeyConfigs"),
        upsertFolder: c("LSUpsertFolder"),
        upsertGradientColor: c("LSUpsertGradientColor"),
        upsertSequenceId: c("LSUpsertSequenceId"),
        upsertTheme: c("LSUpsertTheme"),
        verifyAndSaveNewCredentials: c("LSVerifyAndSaveNewCredentials"),
        verifyContactParticipantExist: c("LSVerifyContactParticipantExist"),
        verifyContactRowExists: c("LSVerifyContactRowExists"),
        verifyE2EEMetadataThreadExistsV2: c("LSVerifyE2EEMetadataThreadExistsV2"),
        verifyThreadExists: c("LSVerifyThreadExists"),
        verifyThreadRowExists: c("LSVerifyThreadRowExists")
    };
    b = a;
    g["default"] = b
}), 98); /*FB_PKG_DELIM*/
__d("LSDeleteBanner", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(118).fetch([
                [
                    [a[1], a[0]]
                ]
            ]), function(c) {
                return b.i64.eq(c.threadKey, a[1]) && b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(c.bannerId, a[0])
            }), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSInThreadBannerDeleteBannerStoredProcedure";
    e.exports = a
}), null);
__d("LSGetFirstAvailableThreadNullstateCTAID", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(a) {
            return b.sequence([function(a) {
                return b.db.table(29).fetchDesc().next().then(function(a, d) {
                    var e = a.done;
                    a = a.value;
                    return e ? c[0] = b.i64.cast([0, 1]) : (d = a.item, c[0] = b.i64.add(d.ctaId, b.i64.cast([0, 1])))
                })
            }, function(a) {
                return d[0] = c[0]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxGetFirstAvailableThreadNullstateCTAIDStoredProcedure";
    e.exports = a
}), null);
__d("LSGetFirstAvailableThreadNullstateCTAIDForThreadKey", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(e) {
            return b.sequence([function(d) {
                return b.db.table(29).fetch([
                    [
                        [a[0]]
                    ], "threadKeyCtaId"
                ]).next().then(function(a, b) {
                    var d = a.done;
                    a = a.value;
                    return d ? c[0] = void 0 : (b = a.item, c[0] = b.ctaId)
                })
            }, function(a) {
                return d[0] = c[0]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxGetFirstAvailableThreadNullstateCTAIDForThreadKeyStoredProcedure";
    e.exports = a
}), null);
__d("LSInsertIcebreakerData", ["LSArrayGetObjectAt", "LSGetFirstAvailableThreadNullstateCTAID", "LSGetFirstAvailableThreadNullstateCTAIDForThreadKey"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return c.storedProcedure(b("LSGetFirstAvailableThreadNullstateCTAIDForThreadKey"), a[0]).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(e) {
                return c.i64.eq(d[0], void 0) ? c.sequence([function(a) {
                    return c.storedProcedure(b("LSGetFirstAvailableThreadNullstateCTAID")).then(function(a) {
                        return a = a, d[1] = a[0], a
                    })
                }, function(e) {
                    return d[2] = c.createArray(), d[3] = c.i64.of_int32(a[1].length), c.i64.gt(d[3], c.i64.cast([0, 0])) ? c.loopAsync(d[3], function(e) {
                        return d[7] = e, c.sequence([function(e) {
                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), a[1], d[7]).then(function(a) {
                                return a = a, d[8] = a[0], d[9] = a[1], a
                            })
                        }, function(a) {
                            return d[10] = d[8].get("thread_key"), d[8], d[11] = (d[2].push(d[10]), d[2])
                        }])
                    }) : c.resolve()
                }, function(a) {
                    return d[4] = new c.Map(), c.sequence([function(a) {
                        return d[7] = c.createArray(), d[8] = c.i64.of_int32(d[2].length), c.i64.gt(d[8], c.i64.cast([0, 0])) ? c.loopAsync(d[8], function(a) {
                            return d[10] = a, c.sequence([function(a) {
                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[2], d[10]).then(function(a) {
                                    return a = a, d[11] = a[0], d[12] = a[1], a
                                })
                            }, function(a) {
                                return d[13] = (d[7].push(c.i64.to_string(d[11])), d[7])
                            }])
                        }) : c.resolve()
                    }, function(a) {
                        return d[9] = d[7].join(","), d[5] = d[9]
                    }])
                }, function(a) {
                    return c.forEach(c.filter(c.db.table(28).fetch(), function(a) {
                        return d[2].some(function(b) {
                            return c.i64.eq(a.threadKey, b)
                        })
                    }), function(a) {
                        a = a.item;
                        return d[4].set(c.i64.to_string(a.threadKey), !0)
                    })
                }, function(e) {
                    return d[6] = c.i64.of_int32(a[1].length), c.i64.gt(d[6], c.i64.cast([0, 0])) ? c.loopAsync(d[6], function(e) {
                        return d[7] = e, c.sequence([function(e) {
                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), a[1], d[7]).then(function(a) {
                                return a = a, d[8] = a[0], d[9] = a[1], a
                            })
                        }, function(a) {
                            return d[12] = c.i64.add(d[1], d[7]), d[10] = d[8].get("thread_key"), d[8], d[11] = d[4].get(c.i64.to_string(d[10])), d[4], d[11] !== void 0 ? c.db.table(29).fetch([
                                [
                                    [d[12]]
                                ]
                            ]).next().then(function(a) {
                                var b = a.done;
                                a.value;
                                return b ? (d[13] = d[8].get("thread_key"), d[8], d[14] = d[8].get("title"), d[8], d[15] = d[8].get("cta_type"), d[8], d[16] = d[8].get("platform_token"), d[8], d[17] = d[8].get("cta_identifier"), d[8], c.db.table(29).add({
                                    ctaId: d[12],
                                    threadKey: d[13],
                                    title: d[14],
                                    ctaType: d[15],
                                    platformToken: d[16],
                                    ctaIdentifier: d[17]
                                })) : 0
                            }) : c.resolve()
                        }])
                    }) : c.resolve()
                }]) : c.resolve()
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxInsertIcebreakerDataStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueInsertPersistentMenuCtasForThreadTask", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("thread_key", a[0]), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTask"), "insert_persistent_menu_ctas", c.i64.cast([0, 54]), d[1], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSComposerMenusIssueInsertPersistentMenuCtasForThreadTaskStoredProcedure";
    e.exports = a
}), null);
__d("LSIssueInsertPersistentMenuItemsForThreadTask", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("thread_key", a[0]), d[1] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTask"), "insert_persistent_menu_items", c.i64.cast([0, 117]), d[1], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsIssueInsertPersistentMenuItemsForThreadTaskStoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyCustomCommandsExist", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.db.table(296).fetch([
                [
                    [a[0]]
                ]
            ]).next().then(function(e, f) {
                f = e.done;
                e = e.value;
                return f ? (d[1] = new c.Map(), d[1].set("thread_key", a[0]), d[2] = c.toJSON(d[1]), c.storedProcedure(b("LSIssueNewTask"), "fetch_custom_thread_commands", c.i64.cast([0, 767]), d[2], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))) : (e.item, 0)
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsVerifyCustomCommandsExistStoredProcedure";
    e.exports = a
}), null); /*FB_PKG_DELIM*/
__d("GroupsCometChatMemberChatSuggestionDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7172810212754908"
}), null);
__d("LSIssueCommunityChannelListFetch", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return d[0] = new c.Map(), d[0].set("community_id", a[0]), d[0].set("forward_cursor", a[1]), d[0].set("channel_join_status", a[2]), d[1] = d[0].get("community_id"), d[0], d[2] = c.toJSON(d[0]), c.storedProcedure(b("LSIssueNewTask"), c.i64.to_string(d[1]), c.i64.cast([0, 338]), d[2], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxIssueCommunityChannelListFetchStoredProcedure";
    e.exports = a
}), null);
//# sourceURL=https://static.xx.fbcdn.net/rsrc.php/v3/yy/r/WlFNrSTeVIuNvK0FmiPrBmIpSLsR36SsP.js