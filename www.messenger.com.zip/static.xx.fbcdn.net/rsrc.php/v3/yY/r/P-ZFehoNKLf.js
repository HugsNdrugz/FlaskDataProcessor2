; /*FB_PKG_DELIM*/

__d("LSGetFirstAvailableAdminMessageCTAID", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(a) {
            return b.sequence([function(a) {
                return b.db.table(27).fetchDesc([
                    [
                        []
                    ], "ctaId"
                ]).next().then(function(a, d) {
                    var e = a.done;
                    a = a.value;
                    return e ? c[0] = b.i64.cast([0, 1]) : (d = a.item, c[0] = b.i64.add(d.ctaId, b.i64.cast([0, 1])))
                })
            }, function(a) {
                return d[0] = c[0]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxGetFirstAvailableAdminMessageCTAIDStoredProcedure";
    e.exports = a
}), null);
__d("LSApplyAdminMessageCTA", ["LSArrayGetObjectAt", "LSDeserializeFromJsonIntoDictionaryV2.nop", "LSGetFirstAvailableAdminMessageCTAID"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(a) {
                return c.storedProcedure(b("LSGetFirstAvailableAdminMessageCTAID")).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(b) {
                return c.db.table(27).put({
                    threadKey: a[0],
                    messageId: a[2],
                    ctaId: d[0],
                    timestampMs: a[1],
                    adClientToken: a[5],
                    adPreferenceUrl: a[6],
                    adHelpUrl: a[7],
                    showAdChoiceIcon: a[8],
                    title: a[3],
                    actionUrl: a[9],
                    adminMessageNicknameParticipantId: a[10],
                    targetId: a[11],
                    targetTitle: a[12]
                })
            }, function(e) {
                return c.filter(c.db.table(12).fetch([
                    [
                        [a[2]]
                    ], "messageId"
                ]), function(b) {
                    return a[2] === b.messageId && c.i64.eq(a[0], b.threadKey)
                }).next().then(function(a, e) {
                    var f = a.done;
                    a = a.value;
                    return f ? d[1] = void 0 : (e = a.item, c.sequence([function(a) {
                        return d[7] = e.metadataDataclass, d[7] !== void 0 ? c.sequence([function(a) {
                            return c.nativeOperation(b("LSDeserializeFromJsonIntoDictionaryV2.nop"), d[7]).then(function(a) {
                                return a = a, d[8] = a[0], a
                            })
                        }, function(a) {
                            return d[9] = new c.Map(), d[66] = "sticker", d[10] = d[8].get(d[66]), d[8], d[10] ? d[11] = !1 : d[11] = !0, d[11] ? 0 : (d[10] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[101] = "sticker_pack_id", d[97] = d[10].get(d[101]), d[10], d[97] !== void 0 ? d[96].set(d[101], d[97]) : 0, d[102] = "sticker_id", d[98] = d[10].get(d[102]), d[10], d[98] !== void 0 ? d[96].set(d[102], d[98]) : 0, d[103] = "avatar_style", d[99] = d[10].get(d[103]), d[10], d[99] !== void 0 ? d[96].set(d[103], d[99]) : 0, d[104] = "avatar_revision_id", d[100] = d[10].get(d[104]), d[10], d[100] !== void 0 ? (d[100] !== void 0 ? d[105] = c.i64.from_string(d[100]) : d[105] = void 0, d[96].set(d[104], d[105])) : 0, d[95] = d[96]), d[9].set(d[66], d[95])), d[67] = "word_effects", d[12] = d[8].get(d[67]), d[8], d[12] ? d[13] = !1 : d[13] = !0, d[13] ? c.resolve() : c.sequence([function(a) {
                                return d[12] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[103] = "magic_word_offsets", d[97] = d[12].get(d[103]), d[12], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? c.resolve() : c.sequence([function(a) {
                                        return d[106] = c.createArray(), d[107] = c.i64.of_int32(d[97].length), c.i64.gt(d[107], c.i64.cast([0, 0])) ? c.loopAsync(d[107], function(a) {
                                            return d[108] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[97], d[108]).then(function(a) {
                                                    return a = a, d[109] = a[0], d[110] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[111] = (d[106].push(d[109]), d[106])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return d[96].set(d[103], d[106])
                                    }])
                                }, function(a) {
                                    return d[104] = "magic_word_lengths", d[99] = d[12].get(d[104]), d[12], d[99] ? d[100] = !1 : d[100] = !0, d[100] ? c.resolve() : c.sequence([function(a) {
                                        return d[106] = c.createArray(), d[107] = c.i64.of_int32(d[99].length), c.i64.gt(d[107], c.i64.cast([0, 0])) ? c.loopAsync(d[107], function(a) {
                                            return d[108] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[99], d[108]).then(function(a) {
                                                    return a = a, d[109] = a[0], d[110] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[111] = (d[106].push(d[109]), d[106])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return d[96].set(d[104], d[106])
                                    }])
                                }, function(a) {
                                    return d[105] = "magic_word_emojis", d[101] = d[12].get(d[105]), d[12], d[101] ? d[102] = !1 : d[102] = !0, d[102] ? c.resolve() : c.sequence([function(a) {
                                        return d[101] ? d[106] = !1 : d[106] = !0, d[106] ? c.resolve(d[107] = void 0) : c.sequence([function(a) {
                                            return d[108] = c.createArray(), d[109] = c.i64.of_int32(d[101].length), c.i64.gt(d[109], c.i64.cast([0, 0])) ? c.loopAsync(d[109], function(a) {
                                                return d[110] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[101], d[110]).then(function(a) {
                                                        return a = a, d[111] = a[0], d[112] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[113] = (d[108].push(d[111]), d[108])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[107] = d[108]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[105], d[107])
                                    }])
                                }, function(a) {
                                    return d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[67], d[95])
                            }])
                        }, function(a) {
                            return d[68] = "ig_avatar_sticker", d[14] = d[8].get(d[68]), d[8], d[14] ? d[15] = !1 : d[15] = !0, d[15] ? 0 : (d[14] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "is_avatar_sticker", d[97] = d[14].get(d[98]), d[14], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[68], d[95])), d[69] = "power_up", d[16] = d[8].get(d[69]), d[8], d[16] ? d[17] = !1 : d[17] = !0, d[17] ? 0 : (d[16] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "power_up_style", d[97] = d[16].get(d[98]), d[16], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[69], d[95])), d[70] = "ai_bot", d[18] = d[8].get(d[70]), d[8], d[18] ? d[19] = !1 : d[19] = !0, d[19] ? c.resolve() : c.sequence([function(a) {
                                return d[18] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[125] = "response_id", d[97] = d[18].get(d[125]), d[18], d[97] !== void 0 ? d[96].set(d[125], d[97]) : 0, d[126] = "bot_action", d[98] = d[18].get(d[126]), d[18], d[98] !== void 0 ? d[96].set(d[126], d[98]) : 0, d[127] = "sentiment", d[99] = d[18].get(d[127]), d[18], d[99] !== void 0 ? d[96].set(d[127], d[99]) : 0, d[128] = "sentiment_intensity", d[100] = d[18].get(d[128]), d[18], d[100] !== void 0 ? d[96].set(d[128], d[100]) : 0, d[129] = "imagine_media_id", d[101] = d[18].get(d[129]), d[18], d[101] !== void 0 ? (d[101] !== void 0 ? d[150] = c.i64.from_string(d[101]) : d[150] = void 0, d[96].set(d[129], d[150])) : 0, d[130] = "bot_action_int", d[102] = d[18].get(d[130]), d[18], c.i64.neq(d[102], void 0) ? d[96].set(d[130], d[102]) : 0, d[131] = "sentiment_int", d[103] = d[18].get(d[131]), d[18], c.i64.neq(d[103], void 0) ? d[96].set(d[131], d[103]) : 0, d[132] = "sentiment_intensity_int", d[104] = d[18].get(d[132]), d[18], c.i64.neq(d[104], void 0) ? d[96].set(d[132], d[104]) : 0, d[133] = "bot_invocation_message_id", d[105] = d[18].get(d[133]), d[18], d[105] !== void 0 ? d[96].set(d[133], d[105]) : 0, d[134] = "bot_response_id", d[106] = d[18].get(d[134]), d[18], d[106] !== void 0 ? d[96].set(d[134], d[106]) : 0, d[135] = "bot_invocation_message_otid", d[107] = d[18].get(d[135]), d[18], d[107] !== void 0 ? d[96].set(d[135], d[107]) : 0, d[136] = "bot_invocation_logging_id", d[108] = d[18].get(d[136]), d[18], d[108] !== void 0 ? d[96].set(d[136], d[108]) : 0, d[137] = "bot_invocation_sender_id", d[109] = d[18].get(d[137]), d[18], d[109] !== void 0 ? d[96].set(d[137], d[109]) : 0, d[138] = "is_error", d[110] = d[18].get(d[138]), d[18], d[110] !== void 0 ? d[96].set(d[138], d[110]) : 0, d[139] = "bot_subscription_id", d[111] = d[18].get(d[139]), d[18], d[111] !== void 0 ? (d[111] !== void 0 ? d[150] = c.i64.from_string(d[111]) : d[150] = void 0, d[96].set(d[139], d[150])) : 0, d[140] = "bot_subscription_product_type", d[112] = d[18].get(d[140]), d[18], d[112] !== void 0 ? d[96].set(d[140], d[112]) : 0, d[141] = "bot_response_product_type", d[113] = d[18].get(d[141]), d[18], d[113] !== void 0 ? d[96].set(d[141], d[113]) : 0, d[142] = "original_prompt_text", d[114] = d[18].get(d[142]), d[18], d[114] !== void 0 ? d[96].set(d[142], d[114]) : 0, d[143] = "bot_response_additional_message_otids", d[115] = d[18].get(d[143]), d[18], d[115] ? d[116] = !1 : d[116] = !0, d[116] ? c.resolve() : c.sequence([function(a) {
                                        return d[115] ? d[150] = !1 : d[150] = !0, d[150] ? c.resolve(d[151] = void 0) : c.sequence([function(a) {
                                            return d[152] = c.createArray(), d[153] = c.i64.of_int32(d[115].length), c.i64.gt(d[153], c.i64.cast([0, 0])) ? c.loopAsync(d[153], function(a) {
                                                return d[154] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[115], d[154]).then(function(a) {
                                                        return a = a, d[155] = a[0], d[156] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[157] = (d[152].push(d[155]), d[152])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[151] = d[152]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[143], d[151])
                                    }])
                                }, function(a) {
                                    return d[144] = "imagine_media_info", d[117] = d[18].get(d[144]), d[18], d[117] ? d[118] = !1 : d[118] = !0, d[118] ? c.resolve() : c.sequence([function(a) {
                                        return d[117] ? d[150] = !1 : d[150] = !0, d[150] ? c.resolve(d[151] = void 0) : c.sequence([function(a) {
                                            return d[152] = c.createArray(), d[153] = c.i64.of_int32(d[117].length), c.i64.gt(d[153], c.i64.cast([0, 0])) ? c.loopAsync(d[153], function(a) {
                                                return d[154] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[117], d[154]).then(function(a) {
                                                        return a = a, d[155] = a[0], d[156] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[157] = new c.Map(), d[161] = "imagine_media_id", d[158] = d[155].get(d[161]), d[155], d[158] !== void 0 ? (d[158] !== void 0 ? d[164] = c.i64.from_string(d[158]) : d[164] = void 0, d[157].set(d[161], d[164])) : 0, d[162] = "editable", d[159] = d[155].get(d[162]), d[155], d[159] !== void 0 ? d[157].set(d[162], d[159]) : 0, d[163] = "animatable", d[160] = d[155].get(d[163]), d[155], d[160] !== void 0 ? d[157].set(d[163], d[160]) : 0, d[164] = (d[152].push(d[157]), d[152])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[151] = d[152]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[144], d[151])
                                    }])
                                }, function(a) {
                                    return d[145] = "groups_ugc_metadata", d[119] = d[18].get(d[145]), d[18], d[119] ? d[120] = !1 : d[120] = !0, d[120] ? 0 : (d[119] ? d[150] = !1 : d[150] = !0, d[150] ? d[151] = void 0 : (d[152] = new c.Map(), d[154] = "share_to_comment_uri", d[153] = d[119].get(d[154]), d[119], d[153] !== void 0 ? d[152].set(d[154], d[153]) : 0, d[151] = d[152]), d[96].set(d[145], d[151])), d[146] = "bot_proactive_message_type", d[121] = d[18].get(d[146]), d[18], c.i64.neq(d[121], void 0) ? d[96].set(d[146], d[121]) : 0, d[147] = "conversation_header", d[122] = d[18].get(d[147]), d[18], d[122] !== void 0 ? d[96].set(d[147], d[122]) : 0, d[148] = "stream_status", d[123] = d[18].get(d[148]), d[18], d[123] !== void 0 ? d[96].set(d[148], d[123]) : 0, d[149] = "stream_status_type", d[124] = d[18].get(d[149]), d[18], d[124] !== void 0 ? d[96].set(d[149], d[124]) : 0, d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[70], d[95])
                            }])
                        }, function(a) {
                            return d[71] = "pobox", d[20] = d[8].get(d[71]), d[8], d[20] ? d[21] = !1 : d[21] = !0, d[21] ? 0 : (d[20] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[99] = "pobox_fbid", d[97] = d[20].get(d[99]), d[20], d[97] !== void 0 ? (d[97] !== void 0 ? d[101] = c.i64.from_string(d[97]) : d[101] = void 0, d[96].set(d[99], d[101])) : 0, d[100] = "pobox_id", d[98] = d[20].get(d[100]), d[20], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[95] = d[96]), d[9].set(d[71], d[95])), d[72] = "video", d[22] = d[8].get(d[72]), d[8], d[22] ? d[23] = !1 : d[23] = !0, d[23] ? 0 : (d[22] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "unified_upload_mos", d[97] = d[22].get(d[98]), d[22], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[72], d[95])), d[73] = "text_translation", d[24] = d[8].get(d[73]), d[8], d[24] ? d[25] = !1 : d[25] = !0, d[25] ? 0 : (d[24] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[100] = "translated_text", d[97] = d[24].get(d[100]), d[24], d[97] !== void 0 ? d[96].set(d[100], d[97]) : 0, d[101] = "text_dialect", d[98] = d[24].get(d[101]), d[24], d[98] !== void 0 ? d[96].set(d[101], d[98]) : 0, d[102] = "translated_text_dialect", d[99] = d[24].get(d[102]), d[24], d[99] !== void 0 ? d[96].set(d[102], d[99]) : 0, d[95] = d[96]), d[9].set(d[73], d[95])), d[74] = "memories", d[26] = d[8].get(d[74]), d[8], d[26] ? d[27] = !1 : d[27] = !0, d[27] ? c.resolve() : c.sequence([function(a) {
                                return d[26] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[103] = "original_message_id", d[97] = d[26].get(d[103]), d[26], d[97] !== void 0 ? d[96].set(d[103], d[97]) : 0, d[104] = "original_message_creation_ts", d[98] = d[26].get(d[104]), d[26], d[98] !== void 0 ? (d[98] !== void 0 ? d[108] = c.i64.from_string(d[98]) : d[108] = void 0, d[96].set(d[104], d[108])) : 0, d[105] = "memory_server_id", d[99] = d[26].get(d[105]), d[26], d[99] !== void 0 ? (d[99] !== void 0 ? d[108] = c.i64.from_string(d[99]) : d[108] = void 0, d[96].set(d[105], d[108])) : 0, d[106] = "memory_template_type", d[100] = d[26].get(d[106]), d[26], d[100] !== void 0 ? d[96].set(d[106], d[100]) : 0, d[107] = "memory_context_messages", d[101] = d[26].get(d[107]), d[26], d[101] ? d[102] = !1 : d[102] = !0, d[102] ? c.resolve() : c.sequence([function(a) {
                                        return d[101] ? d[108] = !1 : d[108] = !0, d[108] ? c.resolve(d[109] = void 0) : c.sequence([function(a) {
                                            return d[110] = c.createArray(), d[111] = c.i64.of_int32(d[101].length), c.i64.gt(d[111], c.i64.cast([0, 0])) ? c.loopAsync(d[111], function(a) {
                                                return d[112] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[101], d[112]).then(function(a) {
                                                        return a = a, d[113] = a[0], d[114] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[115] = new c.Map(), d[120] = "sender_id", d[116] = d[113].get(d[120]), d[113], d[116] !== void 0 ? (d[116] !== void 0 ? d[123] = c.i64.from_string(d[116]) : d[123] = void 0, d[115].set(d[120], d[123])) : 0, d[121] = "message_text", d[117] = d[113].get(d[121]), d[113], d[117] !== void 0 ? d[115].set(d[121], d[117]) : 0, d[122] = "reactions", d[118] = d[113].get(d[122]), d[113], d[118] ? d[119] = !1 : d[119] = !0, d[119] ? c.resolve() : c.sequence([function(a) {
                                                        return d[118] ? d[123] = !1 : d[123] = !0, d[123] ? c.resolve(d[124] = void 0) : c.sequence([function(a) {
                                                            return d[125] = c.createArray(), d[126] = c.i64.of_int32(d[118].length), c.i64.gt(d[126], c.i64.cast([0, 0])) ? c.loopAsync(d[126], function(a) {
                                                                return d[127] = a, c.sequence([function(a) {
                                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[118], d[127]).then(function(a) {
                                                                        return a = a, d[128] = a[0], d[129] = a[1], a
                                                                    })
                                                                }, function(a) {
                                                                    return d[130] = (d[125].push(d[128]), d[125])
                                                                }])
                                                            }) : c.resolve()
                                                        }, function(a) {
                                                            return d[124] = d[125]
                                                        }])
                                                    }, function(a) {
                                                        return d[115].set(d[122], d[124])
                                                    }])
                                                }, function(a) {
                                                    return d[123] = (d[110].push(d[115]), d[110])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[109] = d[110]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[107], d[109])
                                    }])
                                }, function(a) {
                                    return d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[74], d[95])
                            }])
                        }, function(a) {
                            return d[75] = "command", d[28] = d[8].get(d[75]), d[8], d[28] ? d[29] = !1 : d[29] = !0, d[29] ? 0 : (d[28] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "command_type", d[97] = d[28].get(d[98]), d[28], c.i64.neq(d[97], void 0) ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[75], d[95])), d[76] = "admin_message", d[30] = d[8].get(d[76]), d[8], d[30] ? d[31] = !1 : d[31] = !0, d[31] ? 0 : (d[30] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[107] = "ad_client_token", d[97] = d[30].get(d[107]), d[30], d[97] !== void 0 ? d[96].set(d[107], d[97]) : 0, d[108] = "ad_preference_url", d[98] = d[30].get(d[108]), d[30], d[98] !== void 0 ? d[96].set(d[108], d[98]) : 0, d[109] = "ad_help_url", d[99] = d[30].get(d[109]), d[30], d[99] !== void 0 ? d[96].set(d[109], d[99]) : 0, d[110] = "show_ad_choice_icon", d[100] = d[30].get(d[110]), d[30], d[100] !== void 0 ? d[96].set(d[110], d[100]) : 0, d[111] = "title", d[101] = d[30].get(d[111]), d[30], d[101] !== void 0 ? d[96].set(d[111], d[101]) : 0, d[112] = "action_url", d[102] = d[30].get(d[112]), d[30], d[102] !== void 0 ? d[96].set(d[112], d[102]) : 0, d[113] = "admin_message_nickname_participant_id", d[103] = d[30].get(d[113]), d[30], d[103] !== void 0 ? (d[103] !== void 0 ? d[117] = c.i64.from_string(d[103]) : d[117] = void 0, d[96].set(d[113], d[117])) : 0, d[114] = "target_id", d[104] = d[30].get(d[114]), d[30], d[104] !== void 0 ? (d[104] !== void 0 ? d[117] = c.i64.from_string(d[104]) : d[117] = void 0, d[96].set(d[114], d[117])) : 0, d[115] = "target_title", d[105] = d[30].get(d[115]), d[30], d[105] !== void 0 ? d[96].set(d[115], d[105]) : 0, d[116] = "identifier_name", d[106] = d[30].get(d[116]), d[30], d[106] !== void 0 ? d[96].set(d[116], d[106]) : 0, d[95] = d[96]), d[9].set(d[76], d[95])), d[77] = "misinfo_metadata", d[32] = d[8].get(d[77]), d[8], d[32] ? d[33] = !1 : d[33] = !0, d[33] ? 0 : (d[32] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[99] = "has_misinfo", d[97] = d[32].get(d[99]), d[32], d[97] !== void 0 ? d[96].set(d[99], d[97]) : 0, d[100] = "misinfo_source", d[98] = d[32].get(d[100]), d[32], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[95] = d[96]), d[9].set(d[77], d[95])), d[78] = "forwarded_message", d[34] = d[8].get(d[78]), d[8], d[34] ? d[35] = !1 : d[35] = !0, d[35] ? 0 : (d[34] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[99] = "forwarded_from_thread_name", d[97] = d[34].get(d[99]), d[34], d[97] !== void 0 ? d[96].set(d[99], d[97]) : 0, d[100] = "forwarded_from_thread_url", d[98] = d[34].get(d[100]), d[34], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[95] = d[96]), d[9].set(d[78], d[95])), d[79] = "ai_metadata", d[36] = d[8].get(d[79]), d[8], d[36] ? d[37] = !1 : d[37] = !0, d[37] ? 0 : (d[36] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[102] = "is_ai_generated", d[97] = d[36].get(d[102]), d[36], d[97] !== void 0 ? d[96].set(d[102], d[97]) : 0, d[103] = "gen_ai_integrity_ent_id", d[98] = d[36].get(d[103]), d[36], d[98] !== void 0 ? (d[98] !== void 0 ? d[107] = c.i64.from_string(d[98]) : d[107] = void 0, d[96].set(d[103], d[107])) : 0, d[104] = "ai_product", d[99] = d[36].get(d[104]), d[36], d[99] !== void 0 ? d[96].set(d[104], d[99]) : 0, d[105] = "original_prompt_text", d[100] = d[36].get(d[105]), d[36], d[100] !== void 0 ? d[96].set(d[105], d[100]) : 0, d[106] = "imagine_media_id", d[101] = d[36].get(d[106]), d[36], d[101] !== void 0 ? (d[101] !== void 0 ? d[107] = c.i64.from_string(d[101]) : d[107] = void 0, d[96].set(d[106], d[107])) : 0, d[95] = d[96]), d[9].set(d[79], d[95])), d[80] = "encrypted_message", d[38] = d[8].get(d[80]), d[8], d[38] ? d[39] = !1 : d[39] = !0, d[39] ? c.resolve() : c.sequence([function(a) {
                                return d[38] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[104] = "thread_id", d[97] = d[38].get(d[104]), d[38], d[97] !== void 0 ? d[96].set(d[104], d[97]) : 0, d[105] = "offline_threading_id", d[98] = d[38].get(d[105]), d[38], d[98] !== void 0 ? d[96].set(d[105], d[98]) : 0, d[106] = "toplevel_payload", d[99] = d[38].get(d[106]), d[38], d[99] ? d[100] = !1 : d[100] = !0, d[100] ? 0 : (d[109] = new c.Map(), d[115] = "encrypted_payload", d[110] = d[99].get(d[115]), d[99], d[110] !== void 0 ? d[109].set(d[115], d[110]) : 0, d[116] = "payloadTimestampMs", d[111] = d[99].get(d[116]), d[99], d[111] !== void 0 ? d[109].set(d[116], c.i64.from_string(d[111])) : 0, d[117] = "encryption_version", d[112] = d[99].get(d[117]), d[99], c.i64.neq(d[112], void 0) ? d[109].set(d[117], d[112]) : 0, d[118] = "epoch_id", d[113] = d[99].get(d[118]), d[99], d[113] !== void 0 ? d[109].set(d[118], c.i64.from_string(d[113])) : 0, d[119] = "epoch_anon_id", d[114] = d[99].get(d[119]), d[99], d[114] !== void 0 ? d[109].set(d[119], d[114]) : 0, d[96].set(d[106], d[109])), d[107] = "supplemental_payloads", d[101] = d[38].get(d[107]), d[38], d[101] ? d[102] = !1 : d[102] = !0, d[102] ? c.resolve() : c.sequence([function(a) {
                                        return d[109] = c.createArray(), d[110] = c.i64.of_int32(d[101].length), c.i64.gt(d[110], c.i64.cast([0, 0])) ? c.loopAsync(d[110], function(a) {
                                            return d[111] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[101], d[111]).then(function(a) {
                                                    return a = a, d[112] = a[0], d[113] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[114] = new c.Map(), d[119] = "encrypted_supplemental_key", d[115] = d[112].get(d[119]), d[112], d[115] !== void 0 ? d[114].set(d[119], d[115]) : 0, d[120] = "supplemental_key_ciphertext", d[116] = d[112].get(d[120]), d[112], d[116] !== void 0 ? d[114].set(d[120], d[116]) : 0, d[121] = "encrypted_supplemental_payload", d[117] = d[112].get(d[121]), d[112], d[117] ? d[118] = !1 : d[118] = !0, d[118] ? 0 : (d[122] = new c.Map(), d[128] = "encrypted_payload", d[123] = d[117].get(d[128]), d[117], d[123] !== void 0 ? d[122].set(d[128], d[123]) : 0, d[129] = "payloadTimestampMs", d[124] = d[117].get(d[129]), d[117], d[124] !== void 0 ? d[122].set(d[129], c.i64.from_string(d[124])) : 0, d[130] = "encryption_version", d[125] = d[117].get(d[130]), d[117], c.i64.neq(d[125], void 0) ? d[122].set(d[130], d[125]) : 0, d[131] = "epoch_id", d[126] = d[117].get(d[131]), d[117], d[126] !== void 0 ? d[122].set(d[131], c.i64.from_string(d[126])) : 0, d[132] = "epoch_anon_id", d[127] = d[117].get(d[132]), d[117], d[127] !== void 0 ? d[122].set(d[132], d[127]) : 0, d[114].set(d[121], d[122])), d[122] = (d[109].push(d[114]), d[109])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return d[96].set(d[107], d[109])
                                    }])
                                }, function(a) {
                                    return d[108] = "is_open_eb", d[103] = d[38].get(d[108]), d[38], d[103] !== void 0 ? d[96].set(d[108], d[103]) : 0, d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[80], d[95])
                            }])
                        }, function(a) {
                            return d[81] = "rich_text", d[40] = d[8].get(d[81]), d[8], d[40] ? d[41] = !1 : d[41] = !0, d[41] ? 0 : (d[40] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "rich_text_format_type", d[97] = d[40].get(d[98]), d[40], c.i64.neq(d[97], void 0) ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[81], d[95])), d[82] = "content_logging_metadata", d[42] = d[8].get(d[82]), d[8], d[42] ? d[43] = !1 : d[43] = !0, d[43] ? c.resolve() : c.sequence([function(a) {
                                return d[42] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[101] = "containing_post", d[97] = d[42].get(d[101]), d[42], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? c.resolve() : c.sequence([function(a) {
                                        return d[97] ? d[103] = !1 : d[103] = !0, d[103] ? c.resolve(d[104] = void 0) : c.sequence([function(a) {
                                            return d[105] = new c.Map(), d[113] = "key_type", d[106] = d[97].get(d[113]), d[97], d[106] !== void 0 ? d[105].set(d[113], d[106]) : 0, d[114] = "fb_post_type", d[107] = d[97].get(d[114]), d[97], d[107] ? d[108] = !1 : d[108] = !0, d[108] ? c.resolve() : c.sequence([function(a) {
                                                return d[107] ? d[117] = !1 : d[117] = !0, d[117] ? c.resolve(d[118] = void 0) : c.sequence([function(a) {
                                                    return d[119] = c.createArray(), d[120] = c.i64.of_int32(d[107].length), c.i64.gt(d[120], c.i64.cast([0, 0])) ? c.loopAsync(d[120], function(a) {
                                                        return d[121] = a, c.sequence([function(a) {
                                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[107], d[121]).then(function(a) {
                                                                return a = a, d[122] = a[0], d[123] = a[1], a
                                                            })
                                                        }, function(a) {
                                                            return d[124] = (d[119].push(d[122]), d[119])
                                                        }])
                                                    }) : c.resolve()
                                                }, function(a) {
                                                    return d[118] = d[119]
                                                }])
                                            }, function(a) {
                                                return d[105].set(d[114], d[118])
                                            }])
                                        }, function(a) {
                                            return d[115] = "photos", d[109] = d[97].get(d[115]), d[97], d[109] ? d[110] = !1 : d[110] = !0, d[110] ? c.resolve() : c.sequence([function(a) {
                                                return d[109] ? d[117] = !1 : d[117] = !0, d[117] ? c.resolve(d[118] = void 0) : c.sequence([function(a) {
                                                    return d[119] = c.createArray(), d[120] = c.i64.of_int32(d[109].length), c.i64.gt(d[120], c.i64.cast([0, 0])) ? c.loopAsync(d[120], function(a) {
                                                        return d[121] = a, c.sequence([function(a) {
                                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[109], d[121]).then(function(a) {
                                                                return a = a, d[122] = a[0], d[123] = a[1], a
                                                            })
                                                        }, function(a) {
                                                            return d[124] = new c.Map(), d[126] = "key_type", d[125] = d[122].get(d[126]), d[122], d[125] !== void 0 ? d[124].set(d[126], d[125]) : 0, d[127] = (d[119].push(d[124]), d[119])
                                                        }])
                                                    }) : c.resolve()
                                                }, function(a) {
                                                    return d[118] = d[119]
                                                }])
                                            }, function(a) {
                                                return d[105].set(d[115], d[118])
                                            }])
                                        }, function(a) {
                                            return d[116] = "videos", d[111] = d[97].get(d[116]), d[97], d[111] ? d[112] = !1 : d[112] = !0, d[112] ? c.resolve() : c.sequence([function(a) {
                                                return d[111] ? d[117] = !1 : d[117] = !0, d[117] ? c.resolve(d[118] = void 0) : c.sequence([function(a) {
                                                    return d[119] = c.createArray(), d[120] = c.i64.of_int32(d[111].length), c.i64.gt(d[120], c.i64.cast([0, 0])) ? c.loopAsync(d[120], function(a) {
                                                        return d[121] = a, c.sequence([function(a) {
                                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[111], d[121]).then(function(a) {
                                                                return a = a, d[122] = a[0], d[123] = a[1], a
                                                            })
                                                        }, function(a) {
                                                            return d[124] = new c.Map(), d[126] = "key_type", d[125] = d[122].get(d[126]), d[122], d[125] !== void 0 ? d[124].set(d[126], d[125]) : 0, d[127] = (d[119].push(d[124]), d[119])
                                                        }])
                                                    }) : c.resolve()
                                                }, function(a) {
                                                    return d[118] = d[119]
                                                }])
                                            }, function(a) {
                                                return d[105].set(d[116], d[118])
                                            }])
                                        }, function(a) {
                                            return d[104] = d[105]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[101], d[104])
                                    }])
                                }, function(a) {
                                    return d[102] = "metadata", d[99] = d[42].get(d[102]), d[42], d[99] ? d[100] = !1 : d[100] = !0, d[100] ? c.resolve() : c.sequence([function(a) {
                                        return d[99] ? d[103] = !1 : d[103] = !0, d[103] ? c.resolve(d[104] = void 0) : c.sequence([function(a) {
                                            return d[105] = d[99].get("__typename"), d[99], d[105] === "XMSGGroupsContentLoggingMetadata" ? c.resolve((d[107] = new c.Map(), d[109] = "num_members", d[108] = d[99].get(d[109]), d[99], c.i64.neq(d[108], void 0) ? d[107].set(d[109], d[108]) : 0, d[106] = d[107])) : c.sequence([function(a) {
                                                return d[105] === "XMSGStoriesContentLoggingMetadata" ? c.resolve((d[108] = new c.Map(), d[113] = "author", d[109] = d[99].get(d[113]), d[99], d[109] ? d[110] = !1 : d[110] = !0, d[110] ? 0 : (d[109] ? d[116] = !1 : d[116] = !0, d[116] ? d[117] = void 0 : (d[118] = new c.Map(), d[121] = "profile", d[119] = d[109].get(d[121]), d[109], d[119] ? d[120] = !1 : d[120] = !0, d[120] ? 0 : (d[119] ? d[122] = !1 : d[122] = !0, d[122] ? d[123] = void 0 : (d[124] = new c.Map(), d[126] = "id", d[125] = d[119].get(d[126]), d[119], d[125] !== void 0 ? d[124].set(d[126], d[125]) : 0, d[123] = d[124]), d[118].set(d[121], d[123])), d[117] = d[118]), d[108].set(d[113], d[117])), d[114] = "post_source", d[111] = d[99].get(d[114]), d[99], d[111] !== void 0 ? d[108].set(d[114], d[111]) : 0, d[115] = "story_type", d[112] = d[99].get(d[115]), d[99], d[112] !== void 0 ? d[108].set(d[115], d[112]) : 0, d[107] = d[108])) : c.sequence([function(a) {
                                                    return function(a) {
                                                        c.logger(a).warn(a)
                                                    }(["Unknown subtype for LSXMSGContentLoggingMetadataUnion: ", "", d[105]].join("")), d[108] = new c.Map(), d[109] = d[99].keys(), d[110] = c.i64.of_int32(d[109].length), c.i64.gt(d[110], c.i64.cast([0, 0])) ? c.loopAsync(d[110], function(a) {
                                                        return d[111] = a, c.sequence([function(a) {
                                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[109], d[111]).then(function(a) {
                                                                return a = a, d[112] = a[0], d[113] = a[1], a
                                                            })
                                                        }, function(a) {
                                                            return d[114] = d[99].get(d[112]), d[99], d[108].set(d[112], d[114])
                                                        }])
                                                    }) : c.resolve()
                                                }, function(a) {
                                                    return d[107] = d[108]
                                                }])
                                            }, function(a) {
                                                return d[106] = d[107]
                                            }])
                                        }, function(a) {
                                            return d[106].set("__typename", d[105]), d[104] = d[106]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[102], d[104])
                                    }])
                                }, function(a) {
                                    return d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[82], d[95])
                            }])
                        }, function(a) {
                            return d[83] = "suggested_moderation_actions", d[44] = d[8].get(d[83]), d[8], d[44] ? d[45] = !1 : d[45] = !0, d[45] ? c.resolve() : c.sequence([function(a) {
                                return d[44] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[100] = "suggested_moderation_actions_list", d[97] = d[44].get(d[100]), d[44], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? c.resolve() : c.sequence([function(a) {
                                        return d[97] ? d[102] = !1 : d[102] = !0, d[102] ? c.resolve(d[103] = void 0) : c.sequence([function(a) {
                                            return d[104] = new c.Map(), d[107] = "suggested_moderation_actions", d[105] = d[97].get(d[107]), d[97], d[105] ? d[106] = !1 : d[106] = !0, d[106] ? c.resolve() : c.sequence([function(a) {
                                                return d[105] ? d[108] = !1 : d[108] = !0, d[108] ? c.resolve(d[109] = void 0) : c.sequence([function(a) {
                                                    return d[110] = c.createArray(), d[111] = c.i64.of_int32(d[105].length), c.i64.gt(d[111], c.i64.cast([0, 0])) ? c.loopAsync(d[111], function(a) {
                                                        return d[112] = a, c.sequence([function(a) {
                                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[105], d[112]).then(function(a) {
                                                                return a = a, d[113] = a[0], d[114] = a[1], a
                                                            })
                                                        }, function(a) {
                                                            return d[115] = new c.Map(), d[118] = "primary_action", d[116] = d[113].get(d[118]), d[113], d[116] !== void 0 ? d[115].set(d[118], d[116]) : 0, d[119] = "chained_actions", d[117] = d[113].get(d[119]), d[113], d[117] !== void 0 ? d[115].set(d[119], d[117]) : 0, d[120] = (d[110].push(d[115]), d[110])
                                                        }])
                                                    }) : c.resolve()
                                                }, function(a) {
                                                    return d[109] = d[110]
                                                }])
                                            }, function(a) {
                                                return d[104].set(d[107], d[109])
                                            }])
                                        }, function(a) {
                                            return d[103] = d[104]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[100], d[103])
                                    }])
                                }, function(a) {
                                    return d[101] = "suggested_moderation_actions_json", d[99] = d[44].get(d[101]), d[44], d[99] !== void 0 ? d[96].set(d[101], d[99]) : 0, d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[83], d[95])
                            }])
                        }, function(a) {
                            return d[84] = "highlights_tab_custom_card_metadata", d[46] = d[8].get(d[84]), d[8], d[46] ? d[47] = !1 : d[47] = !0, d[47] ? 0 : (d[46] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[99] = "is_custom_card", d[97] = d[46].get(d[99]), d[46], d[97] !== void 0 ? d[96].set(d[99], d[97]) : 0, d[100] = "moment", d[98] = d[46].get(d[100]), d[46], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[95] = d[96]), d[9].set(d[84], d[95])), d[85] = "highlights_tab_metadata", d[48] = d[8].get(d[85]), d[8], d[48] ? d[49] = !1 : d[49] = !0, d[49] ? c.resolve() : c.sequence([function(a) {
                                return d[48] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[102] = "reply_source_type", d[97] = d[48].get(d[102]), d[48], d[97] !== void 0 ? d[96].set(d[102], d[97]) : 0, d[103] = "reply_metadata", d[98] = d[48].get(d[103]), d[48], d[98] ? d[99] = !1 : d[99] = !0, d[99] ? c.resolve() : c.sequence([function(a) {
                                        return d[98] ? d[105] = !1 : d[105] = !0, d[105] ? c.resolve(d[106] = void 0) : c.sequence([function(a) {
                                            return d[107] = d[98].get("__typename"), d[98], d[107] === "XMSGHighlightsTabBirthdayReplyMetadata" ? c.resolve((d[109] = new c.Map(), d[111] = "birthday_age", d[110] = d[98].get(d[111]), d[98], c.i64.neq(d[110], void 0) ? d[109].set(d[111], d[110]) : 0, d[108] = d[109])) : c.sequence([function(a) {
                                                return function(a) {
                                                    c.logger(a).warn(a)
                                                }(["Unknown subtype for LSXMSGHighlightsTabReplyMetadataUnion: ", "", d[107]].join("")), d[109] = new c.Map(), d[110] = d[98].keys(), d[111] = c.i64.of_int32(d[110].length), c.i64.gt(d[111], c.i64.cast([0, 0])) ? c.loopAsync(d[111], function(a) {
                                                    return d[112] = a, c.sequence([function(a) {
                                                        return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[110], d[112]).then(function(a) {
                                                            return a = a, d[113] = a[0], d[114] = a[1], a
                                                        })
                                                    }, function(a) {
                                                        return d[115] = d[98].get(d[113]), d[98], d[109].set(d[113], d[115])
                                                    }])
                                                }) : c.resolve()
                                            }, function(a) {
                                                return d[108] = d[109]
                                            }])
                                        }, function(a) {
                                            return d[108].set("__typename", d[107]), d[106] = d[108]
                                        }])
                                    }, function(a) {
                                        return d[96].set(d[103], d[106])
                                    }])
                                }, function(a) {
                                    return d[104] = "moment_card_metadata", d[100] = d[48].get(d[104]), d[48], d[100] ? d[101] = !1 : d[101] = !0, d[101] ? 0 : (d[100] ? d[105] = !1 : d[105] = !0, d[105] ? d[106] = void 0 : (d[107] = new c.Map(), d[109] = "moment_card_type", d[108] = d[100].get(d[109]), d[100], d[108] !== void 0 ? d[107].set(d[109], d[108]) : 0, d[106] = d[107]), d[96].set(d[104], d[106])), d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[85], d[95])
                            }])
                        }, function(a) {
                            return d[86] = "business_thread_response_feedback", d[50] = d[8].get(d[86]), d[8], d[50] ? d[51] = !1 : d[51] = !0, d[51] ? 0 : (d[50] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "is_feedback_button_enabled_for_message", d[97] = d[50].get(d[98]), d[50], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[86], d[95])), d[87] = "live_shopping_metadata", d[52] = d[8].get(d[87]), d[8], d[52] ? d[53] = !1 : d[53] = !0, d[53] ? 0 : (d[52] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "referral_post_id", d[97] = d[52].get(d[98]), d[52], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[87], d[95])), d[88] = "reply_metadata", d[54] = d[8].get(d[88]), d[8], d[54] ? d[55] = !1 : d[55] = !0, d[55] ? 0 : (d[54] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "is_markdown", d[97] = d[54].get(d[98]), d[54], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[88], d[95])), d[89] = "mustache_cta", d[56] = d[8].get(d[89]), d[8], d[56] ? d[57] = !1 : d[57] = !0, d[57] ? 0 : (d[56] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[100] = "cta_type", d[97] = d[56].get(d[100]), d[56], d[97] !== void 0 ? d[96].set(d[100], d[97]) : 0, d[101] = "title", d[98] = d[56].get(d[101]), d[56], d[98] !== void 0 ? d[96].set(d[101], d[98]) : 0, d[102] = "action_url", d[99] = d[56].get(d[102]), d[56], d[99] !== void 0 ? d[96].set(d[102], d[99]) : 0, d[95] = d[96]), d[9].set(d[89], d[95])), d[90] = "inline_entities", d[58] = d[8].get(d[90]), d[8], d[58] ? d[59] = !1 : d[59] = !0, d[59] ? c.resolve() : c.sequence([function(a) {
                                return d[58] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[101] = "entities", d[97] = d[58].get(d[101]), d[58], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? c.resolve() : c.sequence([function(a) {
                                        return d[104] = c.createArray(), d[105] = c.i64.of_int32(d[97].length), c.i64.gt(d[105], c.i64.cast([0, 0])) ? c.loopAsync(d[105], function(a) {
                                            return d[106] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[97], d[106]).then(function(a) {
                                                    return a = a, d[107] = a[0], d[108] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[109] = new c.Map(), d[118] = "offset", d[110] = d[107].get(d[118]), d[107], c.i64.neq(d[110], void 0) ? d[109].set(d[118], d[110]) : 0, d[119] = "length", d[111] = d[107].get(d[119]), d[107], c.i64.neq(d[111], void 0) ? d[109].set(d[119], d[111]) : 0, d[120] = "type", d[112] = d[107].get(d[120]), d[107], d[112] !== void 0 ? d[109].set(d[120], d[112]) : 0, d[121] = "metadata", d[113] = d[107].get(d[121]), d[107], d[113] ? d[114] = !1 : d[114] = !0, d[114] ? 0 : (d[113] ? d[125] = !1 : d[125] = !0, d[125] ? d[126] = void 0 : (d[127] = new c.Map(), d[130] = "search_query", d[128] = d[113].get(d[130]), d[113], d[128] !== void 0 ? d[127].set(d[130], d[128]) : 0, d[131] = "reminder_topic", d[129] = d[113].get(d[131]), d[113], d[129] !== void 0 ? d[127].set(d[131], d[129]) : 0, d[126] = d[127]), d[109].set(d[121], d[126])), d[122] = "action_label", d[115] = d[107].get(d[122]), d[107], d[115] !== void 0 ? d[109].set(d[122], d[115]) : 0, d[123] = "context_token", d[116] = d[107].get(d[123]), d[107], d[116] !== void 0 ? d[109].set(d[123], d[116]) : 0, d[124] = "context_token_type", d[117] = d[107].get(d[124]), d[107], c.i64.neq(d[117], void 0) ? d[109].set(d[124], d[117]) : 0, d[125] = (d[104].push(d[109]), d[104])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return d[96].set(d[101], d[104])
                                    }])
                                }, function(a) {
                                    return d[102] = "inference_timestamp_ms", d[99] = d[58].get(d[102]), d[58], d[99] !== void 0 ? (d[99] !== void 0 ? d[104] = c.i64.from_string(d[99]) : d[104] = void 0, d[96].set(d[102], d[104])) : 0, d[103] = "inference_model_version", d[100] = d[58].get(d[103]), d[58], c.i64.neq(d[100], void 0) ? d[96].set(d[103], d[100]) : 0, d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[90], d[95])
                            }])
                        }, function(a) {
                            return d[91] = "note_metadata", d[60] = d[8].get(d[91]), d[8], d[60] ? d[61] = !1 : d[61] = !0, d[61] ? c.resolve() : c.sequence([function(a) {
                                return d[60] ? d[94] = !1 : d[94] = !0, d[94] ? c.resolve(d[95] = void 0) : c.sequence([function(a) {
                                    return d[96] = new c.Map(), d[101] = "message_type", d[97] = d[60].get(d[101]), d[60], d[97] !== void 0 ? d[96].set(d[101], d[97]) : 0, d[102] = "mentions", d[98] = d[60].get(d[102]), d[60], d[98] ? d[99] = !1 : d[99] = !0, d[99] ? c.resolve() : c.sequence([function(a) {
                                        return d[104] = c.createArray(), d[105] = c.i64.of_int32(d[98].length), c.i64.gt(d[105], c.i64.cast([0, 0])) ? c.loopAsync(d[105], function(a) {
                                            return d[106] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[98], d[106]).then(function(a) {
                                                    return a = a, d[107] = a[0], d[108] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[109] = new c.Map(), d[112] = "offset", d[110] = d[107].get(d[112]), d[107], c.i64.neq(d[110], void 0) ? d[109].set(d[112], d[110]) : 0, d[113] = "length", d[111] = d[107].get(d[113]), d[107], c.i64.neq(d[111], void 0) ? d[109].set(d[113], d[111]) : 0, d[114] = (d[104].push(d[109]), d[104])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return d[96].set(d[102], d[104])
                                    }])
                                }, function(a) {
                                    return d[103] = "expiration_timestamp_ms", d[100] = d[60].get(d[103]), d[60], d[100] !== void 0 ? d[96].set(d[103], c.i64.from_string(d[100])) : 0, d[95] = d[96]
                                }])
                            }, function(a) {
                                return d[9].set(d[91], d[95])
                            }])
                        }, function(a) {
                            return d[92] = "ai_bot_summon_metadata", d[62] = d[8].get(d[92]), d[8], d[62] ? d[63] = !1 : d[63] = !0, d[63] ? 0 : (d[62] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "is_e2ee_summon_message", d[97] = d[62].get(d[98]), d[62], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[92], d[95])), d[93] = "ai_forwarded_metadata", d[64] = d[8].get(d[93]), d[8], d[64] ? d[65] = !1 : d[65] = !0, d[65] ? 0 : (d[64] ? d[94] = !1 : d[94] = !0, d[94] ? d[95] = void 0 : (d[96] = new c.Map(), d[98] = "is_generated_by_meta_ai", d[97] = d[64].get(d[98]), d[64], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[95] = d[96]), d[9].set(d[93], d[95])), d[6] = d[9]
                        }]) : c.resolve((d[8] = new c.Map(), d[6] = d[8]))
                    }, function(a) {
                        return d[1] = d[6]
                    }]))
                })
            }, function(e) {
                return d[1] ? d[3] = !1 : d[3] = !0, d[3] ? 0 : (d[6] = new c.Map(), d[6].set("ad_client_token", a[5]), d[6].set("ad_preference_url", a[6]), d[6].set("ad_help_url", a[7]), d[6].set("show_ad_choice_icon", a[8]), d[6].set("title", a[3]), d[6].set("action_url", a[9]), d[6].set("admin_message_nickname_participant_id", a[10]), d[6].set("target_id", a[11]), d[6].set("target_title", a[12]), d[6].set("identifier_name", void 0), d[1].set("admin_message", d[6])), d[1] ? d[4] = !1 : d[4] = !0, d[4] ? c.resolve(d[5] = void 0) : c.sequence([function(a) {
                    return d[6] = new c.Map(), d[64] = "sticker", d[7] = d[1].get(d[64]), d[1], d[7] ? d[8] = !1 : d[8] = !0, d[8] ? 0 : (d[7] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[101] = "sticker_pack_id", d[97] = d[7].get(d[101]), d[7], d[97] !== void 0 ? d[96].set(d[101], d[97]) : 0, d[102] = "sticker_id", d[98] = d[7].get(d[102]), d[7], d[98] !== void 0 ? d[96].set(d[102], d[98]) : 0, d[103] = "avatar_style", d[99] = d[7].get(d[103]), d[7], d[99] !== void 0 ? d[96].set(d[103], d[99]) : 0, d[104] = "avatar_revision_id", d[100] = d[7].get(d[104]), d[7], c.i64.neq(d[100], void 0) ? (c.i64.neq(d[100], void 0) ? d[105] = c.i64.to_string(d[100]) : d[105] = void 0, d[96].set(d[104], d[105])) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[64], d[93]) : 0), d[65] = "word_effects", d[9] = d[1].get(d[65]), d[1], d[9] ? d[10] = !1 : d[10] = !0, d[10] ? 0 : (d[9] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[103] = "magic_word_offsets", d[97] = d[9].get(d[103]), d[9], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? 0 : d[96].set(d[103], d[97]), d[104] = "magic_word_lengths", d[99] = d[9].get(d[104]), d[9], d[99] ? d[100] = !1 : d[100] = !0, d[100] ? 0 : d[96].set(d[104], d[99]), d[105] = "magic_word_emojis", d[101] = d[9].get(d[105]), d[9], d[101] ? d[102] = !1 : d[102] = !0, d[102] ? 0 : (d[106] = c.i64.of_int32(d[101].length), c.i64.neq(d[106], c.i64.cast([0, 0])) ? d[96].set(d[105], d[101]) : 0), d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[65], d[93]) : 0), d[66] = "ig_avatar_sticker", d[11] = d[1].get(d[66]), d[1], d[11] ? d[12] = !1 : d[12] = !0, d[12] ? 0 : (d[11] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "is_avatar_sticker", d[97] = d[11].get(d[98]), d[11], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[66], d[93]) : 0), d[67] = "power_up", d[13] = d[1].get(d[67]), d[1], d[13] ? d[14] = !1 : d[14] = !0, d[14] ? 0 : (d[13] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "power_up_style", d[97] = d[13].get(d[98]), d[13], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[67], d[93]) : 0), d[68] = "ai_bot", d[15] = d[1].get(d[68]), d[1], d[15] ? d[16] = !1 : d[16] = !0, d[16] ? c.resolve() : c.sequence([function(a) {
                        return d[15] ? d[92] = !1 : d[92] = !0, d[92] ? c.resolve(d[93] = void 0) : c.sequence([function(a) {
                            return d[96] = new c.Map(), d[125] = "response_id", d[97] = d[15].get(d[125]), d[15], d[97] !== void 0 ? d[96].set(d[125], d[97]) : 0, d[126] = "bot_action", d[98] = d[15].get(d[126]), d[15], d[98] !== void 0 ? d[96].set(d[126], d[98]) : 0, d[127] = "sentiment", d[99] = d[15].get(d[127]), d[15], d[99] !== void 0 ? d[96].set(d[127], d[99]) : 0, d[128] = "sentiment_intensity", d[100] = d[15].get(d[128]), d[15], d[100] !== void 0 ? d[96].set(d[128], d[100]) : 0, d[129] = "imagine_media_id", d[101] = d[15].get(d[129]), d[15], c.i64.neq(d[101], void 0) ? (c.i64.neq(d[101], void 0) ? d[150] = c.i64.to_string(d[101]) : d[150] = void 0, d[96].set(d[129], d[150])) : 0, d[130] = "bot_action_int", d[102] = d[15].get(d[130]), d[15], c.i64.neq(d[102], void 0) ? d[96].set(d[130], d[102]) : 0, d[131] = "sentiment_int", d[103] = d[15].get(d[131]), d[15], c.i64.neq(d[103], void 0) ? d[96].set(d[131], d[103]) : 0, d[132] = "sentiment_intensity_int", d[104] = d[15].get(d[132]), d[15], c.i64.neq(d[104], void 0) ? d[96].set(d[132], d[104]) : 0, d[133] = "bot_invocation_message_id", d[105] = d[15].get(d[133]), d[15], d[105] !== void 0 ? d[96].set(d[133], d[105]) : 0, d[134] = "bot_response_id", d[106] = d[15].get(d[134]), d[15], d[106] !== void 0 ? d[96].set(d[134], d[106]) : 0, d[135] = "bot_invocation_message_otid", d[107] = d[15].get(d[135]), d[15], d[107] !== void 0 ? d[96].set(d[135], d[107]) : 0, d[136] = "bot_invocation_logging_id", d[108] = d[15].get(d[136]), d[15], d[108] !== void 0 ? d[96].set(d[136], d[108]) : 0, d[137] = "bot_invocation_sender_id", d[109] = d[15].get(d[137]), d[15], d[109] !== void 0 ? d[96].set(d[137], d[109]) : 0, d[138] = "is_error", d[110] = d[15].get(d[138]), d[15], d[110] !== void 0 ? d[96].set(d[138], d[110]) : 0, d[139] = "bot_subscription_id", d[111] = d[15].get(d[139]), d[15], c.i64.neq(d[111], void 0) ? (c.i64.neq(d[111], void 0) ? d[150] = c.i64.to_string(d[111]) : d[150] = void 0, d[96].set(d[139], d[150])) : 0, d[140] = "bot_subscription_product_type", d[112] = d[15].get(d[140]), d[15], d[112] !== void 0 ? d[96].set(d[140], d[112]) : 0, d[141] = "bot_response_product_type", d[113] = d[15].get(d[141]), d[15], d[113] !== void 0 ? d[96].set(d[141], d[113]) : 0, d[142] = "original_prompt_text", d[114] = d[15].get(d[142]), d[15], d[114] !== void 0 ? d[96].set(d[142], d[114]) : 0, d[143] = "bot_response_additional_message_otids", d[115] = d[15].get(d[143]), d[15], d[115] ? d[116] = !1 : d[116] = !0, d[116] ? 0 : (d[150] = c.i64.of_int32(d[115].length), c.i64.neq(d[150], c.i64.cast([0, 0])) ? d[96].set(d[143], d[115]) : 0), d[144] = "imagine_media_info", d[117] = d[15].get(d[144]), d[15], d[117] ? d[118] = !1 : d[118] = !0, d[118] ? c.resolve() : c.sequence([function(a) {
                                return d[117] ? d[150] = !1 : d[150] = !0, d[150] ? c.resolve(d[151] = void 0) : c.sequence([function(a) {
                                    return d[153] = c.createArray(), d[154] = c.i64.of_int32(d[117].length), c.i64.gt(d[154], c.i64.cast([0, 0])) ? c.loopAsync(d[154], function(a) {
                                        return d[155] = a, c.sequence([function(a) {
                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[117], d[155]).then(function(a) {
                                                return a = a, d[156] = a[0], d[157] = a[1], a
                                            })
                                        }, function(a) {
                                            return d[158] = new c.Map(), d[162] = "imagine_media_id", d[159] = d[156].get(d[162]), d[156], c.i64.neq(d[159], void 0) ? (c.i64.neq(d[159], void 0) ? d[165] = c.i64.to_string(d[159]) : d[165] = void 0, d[158].set(d[162], d[165])) : 0, d[163] = "editable", d[160] = d[156].get(d[163]), d[156], d[160] !== void 0 ? d[158].set(d[163], d[160]) : 0, d[164] = "animatable", d[161] = d[156].get(d[164]), d[156], d[161] !== void 0 ? d[158].set(d[164], d[161]) : 0, d[165] = (d[153].push(d[158]), d[153])
                                        }])
                                    }) : c.resolve()
                                }, function(a) {
                                    return d[151] = d[153]
                                }])
                            }, function(a) {
                                return d[152] = c.i64.of_int32(d[151].length), c.i64.neq(d[152], c.i64.cast([0, 0])) ? d[96].set(d[144], d[151]) : 0
                            }])
                        }, function(a) {
                            return d[145] = "groups_ugc_metadata", d[119] = d[15].get(d[145]), d[15], d[119] ? d[120] = !1 : d[120] = !0, d[120] ? 0 : (d[119] ? d[150] = !1 : d[150] = !0, d[150] ? d[151] = void 0 : (d[154] = new c.Map(), d[156] = "share_to_comment_uri", d[155] = d[119].get(d[156]), d[119], d[155] !== void 0 ? d[154].set(d[156], d[155]) : 0, d[151] = d[154]), d[152] = d[151].keys(), d[153] = c.i64.of_int32(d[152].length), c.i64.neq(d[153], c.i64.cast([0, 0])) ? d[96].set(d[145], d[151]) : 0), d[146] = "bot_proactive_message_type", d[121] = d[15].get(d[146]), d[15], c.i64.neq(d[121], void 0) ? d[96].set(d[146], d[121]) : 0, d[147] = "conversation_header", d[122] = d[15].get(d[147]), d[15], d[122] !== void 0 ? d[96].set(d[147], d[122]) : 0, d[148] = "stream_status", d[123] = d[15].get(d[148]), d[15], d[123] !== void 0 ? d[96].set(d[148], d[123]) : 0, d[149] = "stream_status_type", d[124] = d[15].get(d[149]), d[15], d[124] !== void 0 ? d[96].set(d[149], d[124]) : 0, d[93] = d[96]
                        }])
                    }, function(a) {
                        return d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[68], d[93]) : 0
                    }])
                }, function(a) {
                    return d[69] = "pobox", d[17] = d[1].get(d[69]), d[1], d[17] ? d[18] = !1 : d[18] = !0, d[18] ? 0 : (d[17] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[99] = "pobox_fbid", d[97] = d[17].get(d[99]), d[17], c.i64.neq(d[97], void 0) ? (c.i64.neq(d[97], void 0) ? d[101] = c.i64.to_string(d[97]) : d[101] = void 0, d[96].set(d[99], d[101])) : 0, d[100] = "pobox_id", d[98] = d[17].get(d[100]), d[17], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[69], d[93]) : 0), d[70] = "video", d[19] = d[1].get(d[70]), d[1], d[19] ? d[20] = !1 : d[20] = !0, d[20] ? 0 : (d[19] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "unified_upload_mos", d[97] = d[19].get(d[98]), d[19], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[70], d[93]) : 0), d[71] = "text_translation", d[21] = d[1].get(d[71]), d[1], d[21] ? d[22] = !1 : d[22] = !0, d[22] ? 0 : (d[21] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[100] = "translated_text", d[97] = d[21].get(d[100]), d[21], d[97] !== void 0 ? d[96].set(d[100], d[97]) : 0, d[101] = "text_dialect", d[98] = d[21].get(d[101]), d[21], d[98] !== void 0 ? d[96].set(d[101], d[98]) : 0, d[102] = "translated_text_dialect", d[99] = d[21].get(d[102]), d[21], d[99] !== void 0 ? d[96].set(d[102], d[99]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[71], d[93]) : 0), d[72] = "memories", d[23] = d[1].get(d[72]), d[1], d[23] ? d[24] = !1 : d[24] = !0, d[24] ? c.resolve() : c.sequence([function(a) {
                        return d[23] ? d[92] = !1 : d[92] = !0, d[92] ? c.resolve(d[93] = void 0) : c.sequence([function(a) {
                            return d[96] = new c.Map(), d[103] = "original_message_id", d[97] = d[23].get(d[103]), d[23], d[97] !== void 0 ? d[96].set(d[103], d[97]) : 0, d[104] = "original_message_creation_ts", d[98] = d[23].get(d[104]), d[23], c.i64.neq(d[98], void 0) ? (c.i64.neq(d[98], void 0) ? d[108] = c.i64.to_string(d[98]) : d[108] = void 0, d[96].set(d[104], d[108])) : 0, d[105] = "memory_server_id", d[99] = d[23].get(d[105]), d[23], c.i64.neq(d[99], void 0) ? (c.i64.neq(d[99], void 0) ? d[108] = c.i64.to_string(d[99]) : d[108] = void 0, d[96].set(d[105], d[108])) : 0, d[106] = "memory_template_type", d[100] = d[23].get(d[106]), d[23], d[100] !== void 0 ? d[96].set(d[106], d[100]) : 0, d[107] = "memory_context_messages", d[101] = d[23].get(d[107]), d[23], d[101] ? d[102] = !1 : d[102] = !0, d[102] ? c.resolve() : c.sequence([function(a) {
                                return d[101] ? d[108] = !1 : d[108] = !0, d[108] ? c.resolve(d[109] = void 0) : c.sequence([function(a) {
                                    return d[111] = c.createArray(), d[112] = c.i64.of_int32(d[101].length), c.i64.gt(d[112], c.i64.cast([0, 0])) ? c.loopAsync(d[112], function(a) {
                                        return d[113] = a, c.sequence([function(a) {
                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[101], d[113]).then(function(a) {
                                                return a = a, d[114] = a[0], d[115] = a[1], a
                                            })
                                        }, function(a) {
                                            return d[116] = new c.Map(), d[121] = "sender_id", d[117] = d[114].get(d[121]), d[114], c.i64.neq(d[117], void 0) ? (c.i64.neq(d[117], void 0) ? d[124] = c.i64.to_string(d[117]) : d[124] = void 0, d[116].set(d[121], d[124])) : 0, d[122] = "message_text", d[118] = d[114].get(d[122]), d[114], d[118] !== void 0 ? d[116].set(d[122], d[118]) : 0, d[123] = "reactions", d[119] = d[114].get(d[123]), d[114], d[119] ? d[120] = !1 : d[120] = !0, d[120] ? 0 : (d[124] = c.i64.of_int32(d[119].length), c.i64.neq(d[124], c.i64.cast([0, 0])) ? d[116].set(d[123], d[119]) : 0), d[124] = (d[111].push(d[116]), d[111])
                                        }])
                                    }) : c.resolve()
                                }, function(a) {
                                    return d[109] = d[111]
                                }])
                            }, function(a) {
                                return d[110] = c.i64.of_int32(d[109].length), c.i64.neq(d[110], c.i64.cast([0, 0])) ? d[96].set(d[107], d[109]) : 0
                            }])
                        }, function(a) {
                            return d[93] = d[96]
                        }])
                    }, function(a) {
                        return d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[72], d[93]) : 0
                    }])
                }, function(a) {
                    return d[73] = "command", d[25] = d[1].get(d[73]), d[1], d[25] ? d[26] = !1 : d[26] = !0, d[26] ? 0 : (d[25] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "command_type", d[97] = d[25].get(d[98]), d[25], c.i64.neq(d[97], void 0) ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[73], d[93]) : 0), d[74] = "admin_message", d[27] = d[1].get(d[74]), d[1], d[27] ? d[28] = !1 : d[28] = !0, d[28] ? 0 : (d[27] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[107] = "ad_client_token", d[97] = d[27].get(d[107]), d[27], d[97] !== void 0 ? d[96].set(d[107], d[97]) : 0, d[108] = "ad_preference_url", d[98] = d[27].get(d[108]), d[27], d[98] !== void 0 ? d[96].set(d[108], d[98]) : 0, d[109] = "ad_help_url", d[99] = d[27].get(d[109]), d[27], d[99] !== void 0 ? d[96].set(d[109], d[99]) : 0, d[110] = "show_ad_choice_icon", d[100] = d[27].get(d[110]), d[27], d[100] !== void 0 ? d[96].set(d[110], d[100]) : 0, d[111] = "title", d[101] = d[27].get(d[111]), d[27], d[101] !== void 0 ? d[96].set(d[111], d[101]) : 0, d[112] = "action_url", d[102] = d[27].get(d[112]), d[27], d[102] !== void 0 ? d[96].set(d[112], d[102]) : 0, d[113] = "admin_message_nickname_participant_id", d[103] = d[27].get(d[113]), d[27], c.i64.neq(d[103], void 0) ? (c.i64.neq(d[103], void 0) ? d[117] = c.i64.to_string(d[103]) : d[117] = void 0, d[96].set(d[113], d[117])) : 0, d[114] = "target_id", d[104] = d[27].get(d[114]), d[27], c.i64.neq(d[104], void 0) ? (c.i64.neq(d[104], void 0) ? d[117] = c.i64.to_string(d[104]) : d[117] = void 0, d[96].set(d[114], d[117])) : 0, d[115] = "target_title", d[105] = d[27].get(d[115]), d[27], d[105] !== void 0 ? d[96].set(d[115], d[105]) : 0, d[116] = "identifier_name", d[106] = d[27].get(d[116]), d[27], d[106] !== void 0 ? d[96].set(d[116], d[106]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[74], d[93]) : 0), d[75] = "misinfo_metadata", d[29] = d[1].get(d[75]), d[1], d[29] ? d[30] = !1 : d[30] = !0, d[30] ? 0 : (d[29] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[99] = "has_misinfo", d[97] = d[29].get(d[99]), d[29], d[97] !== void 0 ? d[96].set(d[99], d[97]) : 0, d[100] = "misinfo_source", d[98] = d[29].get(d[100]), d[29], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[75], d[93]) : 0), d[76] = "forwarded_message", d[31] = d[1].get(d[76]), d[1], d[31] ? d[32] = !1 : d[32] = !0, d[32] ? 0 : (d[31] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[99] = "forwarded_from_thread_name", d[97] = d[31].get(d[99]), d[31], d[97] !== void 0 ? d[96].set(d[99], d[97]) : 0, d[100] = "forwarded_from_thread_url", d[98] = d[31].get(d[100]), d[31], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[76], d[93]) : 0), d[77] = "ai_metadata", d[33] = d[1].get(d[77]), d[1], d[33] ? d[34] = !1 : d[34] = !0, d[34] ? 0 : (d[33] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[102] = "is_ai_generated", d[97] = d[33].get(d[102]), d[33], d[97] !== void 0 ? d[96].set(d[102], d[97]) : 0, d[103] = "gen_ai_integrity_ent_id", d[98] = d[33].get(d[103]), d[33], c.i64.neq(d[98], void 0) ? (c.i64.neq(d[98], void 0) ? d[107] = c.i64.to_string(d[98]) : d[107] = void 0, d[96].set(d[103], d[107])) : 0, d[104] = "ai_product", d[99] = d[33].get(d[104]), d[33], d[99] !== void 0 ? d[96].set(d[104], d[99]) : 0, d[105] = "original_prompt_text", d[100] = d[33].get(d[105]), d[33], d[100] !== void 0 ? d[96].set(d[105], d[100]) : 0, d[106] = "imagine_media_id", d[101] = d[33].get(d[106]), d[33], c.i64.neq(d[101], void 0) ? (c.i64.neq(d[101], void 0) ? d[107] = c.i64.to_string(d[101]) : d[107] = void 0, d[96].set(d[106], d[107])) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[77], d[93]) : 0), d[78] = "encrypted_message", d[35] = d[1].get(d[78]), d[1], d[35] ? d[36] = !1 : d[36] = !0, d[36] ? c.resolve() : c.sequence([function(a) {
                        return d[35] ? d[92] = !1 : d[92] = !0, d[92] ? c.resolve(d[93] = void 0) : c.sequence([function(a) {
                            return d[96] = new c.Map(), d[104] = "thread_id", d[97] = d[35].get(d[104]), d[35], d[97] !== void 0 ? d[96].set(d[104], d[97]) : 0, d[105] = "offline_threading_id", d[98] = d[35].get(d[105]), d[35], d[98] !== void 0 ? d[96].set(d[105], d[98]) : 0, d[106] = "toplevel_payload", d[99] = d[35].get(d[106]), d[35], d[99] ? d[100] = !1 : d[100] = !0, d[100] ? 0 : (d[109] = new c.Map(), d[115] = "encrypted_payload", d[110] = d[99].get(d[115]), d[99], d[110] !== void 0 ? d[109].set(d[115], d[110]) : 0, d[116] = "payloadTimestampMs", d[111] = d[99].get(d[116]), d[99], c.i64.neq(d[111], void 0) ? d[109].set(d[116], c.i64.to_string(d[111])) : 0, d[117] = "encryption_version", d[112] = d[99].get(d[117]), d[99], c.i64.neq(d[112], void 0) ? d[109].set(d[117], d[112]) : 0, d[118] = "epoch_id", d[113] = d[99].get(d[118]), d[99], c.i64.neq(d[113], void 0) ? d[109].set(d[118], c.i64.to_string(d[113])) : 0, d[119] = "epoch_anon_id", d[114] = d[99].get(d[119]), d[99], d[114] !== void 0 ? d[109].set(d[119], d[114]) : 0, d[96].set(d[106], d[109])), d[107] = "supplemental_payloads", d[101] = d[35].get(d[107]), d[35], d[101] ? d[102] = !1 : d[102] = !0, d[102] ? c.resolve() : c.sequence([function(a) {
                                return d[109] = c.createArray(), d[110] = c.i64.of_int32(d[101].length), c.i64.gt(d[110], c.i64.cast([0, 0])) ? c.loopAsync(d[110], function(a) {
                                    return d[111] = a, c.sequence([function(a) {
                                        return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[101], d[111]).then(function(a) {
                                            return a = a, d[112] = a[0], d[113] = a[1], a
                                        })
                                    }, function(a) {
                                        return d[114] = new c.Map(), d[119] = "encrypted_supplemental_key", d[115] = d[112].get(d[119]), d[112], d[115] !== void 0 ? d[114].set(d[119], d[115]) : 0, d[120] = "supplemental_key_ciphertext", d[116] = d[112].get(d[120]), d[112], d[116] !== void 0 ? d[114].set(d[120], d[116]) : 0, d[121] = "encrypted_supplemental_payload", d[117] = d[112].get(d[121]), d[112], d[117] ? d[118] = !1 : d[118] = !0, d[118] ? 0 : (d[122] = new c.Map(), d[128] = "encrypted_payload", d[123] = d[117].get(d[128]), d[117], d[123] !== void 0 ? d[122].set(d[128], d[123]) : 0, d[129] = "payloadTimestampMs", d[124] = d[117].get(d[129]), d[117], c.i64.neq(d[124], void 0) ? d[122].set(d[129], c.i64.to_string(d[124])) : 0, d[130] = "encryption_version", d[125] = d[117].get(d[130]), d[117], c.i64.neq(d[125], void 0) ? d[122].set(d[130], d[125]) : 0, d[131] = "epoch_id", d[126] = d[117].get(d[131]), d[117], c.i64.neq(d[126], void 0) ? d[122].set(d[131], c.i64.to_string(d[126])) : 0, d[132] = "epoch_anon_id", d[127] = d[117].get(d[132]), d[117], d[127] !== void 0 ? d[122].set(d[132], d[127]) : 0, d[114].set(d[121], d[122])), d[122] = (d[109].push(d[114]), d[109])
                                    }])
                                }) : c.resolve()
                            }, function(a) {
                                return d[96].set(d[107], d[109])
                            }])
                        }, function(a) {
                            return d[108] = "is_open_eb", d[103] = d[35].get(d[108]), d[35], d[103] !== void 0 ? d[96].set(d[108], d[103]) : 0, d[93] = d[96]
                        }])
                    }, function(a) {
                        return d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[78], d[93]) : 0
                    }])
                }, function(a) {
                    return d[79] = "rich_text", d[37] = d[1].get(d[79]), d[1], d[37] ? d[38] = !1 : d[38] = !0, d[38] ? 0 : (d[37] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "rich_text_format_type", d[97] = d[37].get(d[98]), d[37], c.i64.neq(d[97], void 0) ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[79], d[93]) : 0), d[80] = "content_logging_metadata", d[39] = d[1].get(d[80]), d[1], d[39] ? d[40] = !1 : d[40] = !0, d[40] ? c.resolve() : c.sequence([function(a) {
                        return d[39] ? d[92] = !1 : d[92] = !0, d[92] ? c.resolve(d[93] = void 0) : c.sequence([function(a) {
                            return d[96] = new c.Map(), d[101] = "containing_post", d[97] = d[39].get(d[101]), d[39], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? c.resolve() : c.sequence([function(a) {
                                return d[97] ? d[103] = !1 : d[103] = !0, d[103] ? c.resolve(d[104] = void 0) : c.sequence([function(a) {
                                    return d[107] = new c.Map(), d[115] = "key_type", d[108] = d[97].get(d[115]), d[97], d[108] !== void 0 ? d[107].set(d[115], d[108]) : 0, d[116] = "fb_post_type", d[109] = d[97].get(d[116]), d[97], d[109] ? d[110] = !1 : d[110] = !0, d[110] ? 0 : (d[119] = c.i64.of_int32(d[109].length), c.i64.neq(d[119], c.i64.cast([0, 0])) ? d[107].set(d[116], d[109]) : 0), d[117] = "photos", d[111] = d[97].get(d[117]), d[97], d[111] ? d[112] = !1 : d[112] = !0, d[112] ? c.resolve() : c.sequence([function(a) {
                                        return d[111] ? d[119] = !1 : d[119] = !0, d[119] ? c.resolve(d[120] = void 0) : c.sequence([function(a) {
                                            return d[122] = c.createArray(), d[123] = c.i64.of_int32(d[111].length), c.i64.gt(d[123], c.i64.cast([0, 0])) ? c.loopAsync(d[123], function(a) {
                                                return d[124] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[111], d[124]).then(function(a) {
                                                        return a = a, d[125] = a[0], d[126] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[127] = new c.Map(), d[129] = "key_type", d[128] = d[125].get(d[129]), d[125], d[128] !== void 0 ? d[127].set(d[129], d[128]) : 0, d[130] = (d[122].push(d[127]), d[122])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[120] = d[122]
                                        }])
                                    }, function(a) {
                                        return d[121] = c.i64.of_int32(d[120].length), c.i64.neq(d[121], c.i64.cast([0, 0])) ? d[107].set(d[117], d[120]) : 0
                                    }])
                                }, function(a) {
                                    return d[118] = "videos", d[113] = d[97].get(d[118]), d[97], d[113] ? d[114] = !1 : d[114] = !0, d[114] ? c.resolve() : c.sequence([function(a) {
                                        return d[113] ? d[119] = !1 : d[119] = !0, d[119] ? c.resolve(d[120] = void 0) : c.sequence([function(a) {
                                            return d[122] = c.createArray(), d[123] = c.i64.of_int32(d[113].length), c.i64.gt(d[123], c.i64.cast([0, 0])) ? c.loopAsync(d[123], function(a) {
                                                return d[124] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[113], d[124]).then(function(a) {
                                                        return a = a, d[125] = a[0], d[126] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[127] = new c.Map(), d[129] = "key_type", d[128] = d[125].get(d[129]), d[125], d[128] !== void 0 ? d[127].set(d[129], d[128]) : 0, d[130] = (d[122].push(d[127]), d[122])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[120] = d[122]
                                        }])
                                    }, function(a) {
                                        return d[121] = c.i64.of_int32(d[120].length), c.i64.neq(d[121], c.i64.cast([0, 0])) ? d[107].set(d[118], d[120]) : 0
                                    }])
                                }, function(a) {
                                    return d[104] = d[107]
                                }])
                            }, function(a) {
                                return d[105] = d[104].keys(), d[106] = c.i64.of_int32(d[105].length), c.i64.neq(d[106], c.i64.cast([0, 0])) ? d[96].set(d[101], d[104]) : 0
                            }])
                        }, function(a) {
                            return d[102] = "metadata", d[99] = d[39].get(d[102]), d[39], d[99] ? d[100] = !1 : d[100] = !0, d[100] ? 0 : (d[99] ? d[103] = !1 : d[103] = !0, d[103] ? d[104] = void 0 : (d[107] = d[99].get("__typename"), d[99], d[107] === "XMSGGroupsContentLoggingMetadata" ? (d[109] = new c.Map(), d[111] = "num_members", d[110] = d[99].get(d[111]), d[99], c.i64.neq(d[110], void 0) ? d[109].set(d[111], d[110]) : 0, d[108] = d[109]) : (d[107] === "XMSGStoriesContentLoggingMetadata" ? (d[110] = new c.Map(), d[115] = "author", d[111] = d[99].get(d[115]), d[99], d[111] ? d[112] = !1 : d[112] = !0, d[112] ? 0 : (d[111] ? d[118] = !1 : d[118] = !0, d[118] ? d[119] = void 0 : (d[122] = new c.Map(), d[125] = "profile", d[123] = d[111].get(d[125]), d[111], d[123] ? d[124] = !1 : d[124] = !0, d[124] ? 0 : (d[123] ? d[126] = !1 : d[126] = !0, d[126] ? d[127] = void 0 : (d[130] = new c.Map(), d[132] = "id", d[131] = d[123].get(d[132]), d[123], d[131] !== void 0 ? d[130].set(d[132], d[131]) : 0, d[127] = d[130]), d[128] = d[127].keys(), d[129] = c.i64.of_int32(d[128].length), c.i64.neq(d[129], c.i64.cast([0, 0])) ? d[122].set(d[125], d[127]) : 0), d[119] = d[122]), d[120] = d[119].keys(), d[121] = c.i64.of_int32(d[120].length), c.i64.neq(d[121], c.i64.cast([0, 0])) ? d[110].set(d[115], d[119]) : 0), d[116] = "post_source", d[113] = d[99].get(d[116]), d[99], d[113] !== void 0 ? d[110].set(d[116], d[113]) : 0, d[117] = "story_type", d[114] = d[99].get(d[117]), d[99], d[114] !== void 0 ? d[110].set(d[117], d[114]) : 0, d[109] = d[110]) : (function(a) {
                                c.logger(a).warn(a)
                            }(["Unknown subtype for LSXMSGContentLoggingMetadataUnion: ", "", d[107]].join("")), d[109] = d[99]), d[108] = d[109]), d[108].set("__typename", d[107]), d[104] = d[108]), d[105] = d[104].keys(), d[106] = c.i64.of_int32(d[105].length), c.i64.neq(d[106], c.i64.cast([0, 0])) ? d[96].set(d[102], d[104]) : 0), d[93] = d[96]
                        }])
                    }, function(a) {
                        return d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[80], d[93]) : 0
                    }])
                }, function(a) {
                    return d[81] = "suggested_moderation_actions", d[41] = d[1].get(d[81]), d[1], d[41] ? d[42] = !1 : d[42] = !0, d[42] ? c.resolve() : c.sequence([function(a) {
                        return d[41] ? d[92] = !1 : d[92] = !0, d[92] ? c.resolve(d[93] = void 0) : c.sequence([function(a) {
                            return d[96] = new c.Map(), d[100] = "suggested_moderation_actions_list", d[97] = d[41].get(d[100]), d[41], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? c.resolve() : c.sequence([function(a) {
                                return d[97] ? d[102] = !1 : d[102] = !0, d[102] ? c.resolve(d[103] = void 0) : c.sequence([function(a) {
                                    return d[106] = new c.Map(), d[109] = "suggested_moderation_actions", d[107] = d[97].get(d[109]), d[97], d[107] ? d[108] = !1 : d[108] = !0, d[108] ? c.resolve() : c.sequence([function(a) {
                                        return d[107] ? d[110] = !1 : d[110] = !0, d[110] ? c.resolve(d[111] = void 0) : c.sequence([function(a) {
                                            return d[113] = c.createArray(), d[114] = c.i64.of_int32(d[107].length), c.i64.gt(d[114], c.i64.cast([0, 0])) ? c.loopAsync(d[114], function(a) {
                                                return d[115] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[107], d[115]).then(function(a) {
                                                        return a = a, d[116] = a[0], d[117] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[118] = new c.Map(), d[121] = "primary_action", d[119] = d[116].get(d[121]), d[116], d[119] !== void 0 ? d[118].set(d[121], d[119]) : 0, d[122] = "chained_actions", d[120] = d[116].get(d[122]), d[116], d[120] !== void 0 ? d[118].set(d[122], d[120]) : 0, d[123] = (d[113].push(d[118]), d[113])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[111] = d[113]
                                        }])
                                    }, function(a) {
                                        return d[112] = c.i64.of_int32(d[111].length), c.i64.neq(d[112], c.i64.cast([0, 0])) ? d[106].set(d[109], d[111]) : 0
                                    }])
                                }, function(a) {
                                    return d[103] = d[106]
                                }])
                            }, function(a) {
                                return d[104] = d[103].keys(), d[105] = c.i64.of_int32(d[104].length), c.i64.neq(d[105], c.i64.cast([0, 0])) ? d[96].set(d[100], d[103]) : 0
                            }])
                        }, function(a) {
                            return d[101] = "suggested_moderation_actions_json", d[99] = d[41].get(d[101]), d[41], d[99] !== void 0 ? d[96].set(d[101], d[99]) : 0, d[93] = d[96]
                        }])
                    }, function(a) {
                        return d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[81], d[93]) : 0
                    }])
                }, function(a) {
                    return d[82] = "highlights_tab_custom_card_metadata", d[43] = d[1].get(d[82]), d[1], d[43] ? d[44] = !1 : d[44] = !0, d[44] ? 0 : (d[43] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[99] = "is_custom_card", d[97] = d[43].get(d[99]), d[43], d[97] !== void 0 ? d[96].set(d[99], d[97]) : 0, d[100] = "moment", d[98] = d[43].get(d[100]), d[43], d[98] !== void 0 ? d[96].set(d[100], d[98]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[82], d[93]) : 0), d[83] = "highlights_tab_metadata", d[45] = d[1].get(d[83]), d[1], d[45] ? d[46] = !1 : d[46] = !0, d[46] ? 0 : (d[45] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[102] = "reply_source_type", d[97] = d[45].get(d[102]), d[45], d[97] !== void 0 ? d[96].set(d[102], d[97]) : 0, d[103] = "reply_metadata", d[98] = d[45].get(d[103]), d[45], d[98] ? d[99] = !1 : d[99] = !0, d[99] ? 0 : (d[98] ? d[105] = !1 : d[105] = !0, d[105] ? d[106] = void 0 : (d[109] = d[98].get("__typename"), d[98], d[109] === "XMSGHighlightsTabBirthdayReplyMetadata" ? (d[111] = new c.Map(), d[113] = "birthday_age", d[112] = d[98].get(d[113]), d[98], c.i64.neq(d[112], void 0) ? d[111].set(d[113], d[112]) : 0, d[110] = d[111]) : (function(a) {
                        c.logger(a).warn(a)
                    }(["Unknown subtype for LSXMSGHighlightsTabReplyMetadataUnion: ", "", d[109]].join("")), d[110] = d[98]), d[110].set("__typename", d[109]), d[106] = d[110]), d[107] = d[106].keys(), d[108] = c.i64.of_int32(d[107].length), c.i64.neq(d[108], c.i64.cast([0, 0])) ? d[96].set(d[103], d[106]) : 0), d[104] = "moment_card_metadata", d[100] = d[45].get(d[104]), d[45], d[100] ? d[101] = !1 : d[101] = !0, d[101] ? 0 : (d[100] ? d[105] = !1 : d[105] = !0, d[105] ? d[106] = void 0 : (d[109] = new c.Map(), d[111] = "moment_card_type", d[110] = d[100].get(d[111]), d[100], d[110] !== void 0 ? d[109].set(d[111], d[110]) : 0, d[106] = d[109]), d[107] = d[106].keys(), d[108] = c.i64.of_int32(d[107].length), c.i64.neq(d[108], c.i64.cast([0, 0])) ? d[96].set(d[104], d[106]) : 0), d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[83], d[93]) : 0), d[84] = "business_thread_response_feedback", d[47] = d[1].get(d[84]), d[1], d[47] ? d[48] = !1 : d[48] = !0, d[48] ? 0 : (d[47] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "is_feedback_button_enabled_for_message", d[97] = d[47].get(d[98]), d[47], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[84], d[93]) : 0), d[85] = "live_shopping_metadata", d[49] = d[1].get(d[85]), d[1], d[49] ? d[50] = !1 : d[50] = !0, d[50] ? 0 : (d[49] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "referral_post_id", d[97] = d[49].get(d[98]), d[49], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[85], d[93]) : 0), d[86] = "reply_metadata", d[51] = d[1].get(d[86]), d[1], d[51] ? d[52] = !1 : d[52] = !0, d[52] ? 0 : (d[51] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "is_markdown", d[97] = d[51].get(d[98]), d[51], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[86], d[93]) : 0), d[87] = "mustache_cta", d[53] = d[1].get(d[87]), d[1], d[53] ? d[54] = !1 : d[54] = !0, d[54] ? 0 : (d[53] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[100] = "cta_type", d[97] = d[53].get(d[100]), d[53], d[97] !== void 0 ? d[96].set(d[100], d[97]) : 0, d[101] = "title", d[98] = d[53].get(d[101]), d[53], d[98] !== void 0 ? d[96].set(d[101], d[98]) : 0, d[102] = "action_url", d[99] = d[53].get(d[102]), d[53], d[99] !== void 0 ? d[96].set(d[102], d[99]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[87], d[93]) : 0), d[88] = "inline_entities", d[55] = d[1].get(d[88]), d[1], d[55] ? d[56] = !1 : d[56] = !0, d[56] ? c.resolve() : c.sequence([function(a) {
                        return d[55] ? d[92] = !1 : d[92] = !0, d[92] ? c.resolve(d[93] = void 0) : c.sequence([function(a) {
                            return d[96] = new c.Map(), d[101] = "entities", d[97] = d[55].get(d[101]), d[55], d[97] ? d[98] = !1 : d[98] = !0, d[98] ? c.resolve() : c.sequence([function(a) {
                                return d[104] = c.createArray(), d[105] = c.i64.of_int32(d[97].length), c.i64.gt(d[105], c.i64.cast([0, 0])) ? c.loopAsync(d[105], function(a) {
                                    return d[106] = a, c.sequence([function(a) {
                                        return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[97], d[106]).then(function(a) {
                                            return a = a, d[107] = a[0], d[108] = a[1], a
                                        })
                                    }, function(a) {
                                        return d[109] = new c.Map(), d[118] = "offset", d[110] = d[107].get(d[118]), d[107], c.i64.neq(d[110], void 0) ? d[109].set(d[118], d[110]) : 0, d[119] = "length", d[111] = d[107].get(d[119]), d[107], c.i64.neq(d[111], void 0) ? d[109].set(d[119], d[111]) : 0, d[120] = "type", d[112] = d[107].get(d[120]), d[107], d[112] !== void 0 ? d[109].set(d[120], d[112]) : 0, d[121] = "metadata", d[113] = d[107].get(d[121]), d[107], d[113] ? d[114] = !1 : d[114] = !0, d[114] ? 0 : (d[113] ? d[125] = !1 : d[125] = !0, d[125] ? d[126] = void 0 : (d[129] = new c.Map(), d[132] = "search_query", d[130] = d[113].get(d[132]), d[113], d[130] !== void 0 ? d[129].set(d[132], d[130]) : 0, d[133] = "reminder_topic", d[131] = d[113].get(d[133]), d[113], d[131] !== void 0 ? d[129].set(d[133], d[131]) : 0, d[126] = d[129]), d[127] = d[126].keys(), d[128] = c.i64.of_int32(d[127].length), c.i64.neq(d[128], c.i64.cast([0, 0])) ? d[109].set(d[121], d[126]) : 0), d[122] = "action_label", d[115] = d[107].get(d[122]), d[107], d[115] !== void 0 ? d[109].set(d[122], d[115]) : 0, d[123] = "context_token", d[116] = d[107].get(d[123]), d[107], d[116] !== void 0 ? d[109].set(d[123], d[116]) : 0, d[124] = "context_token_type", d[117] = d[107].get(d[124]), d[107], c.i64.neq(d[117], void 0) ? d[109].set(d[124], d[117]) : 0, d[125] = (d[104].push(d[109]), d[104])
                                    }])
                                }) : c.resolve()
                            }, function(a) {
                                return d[96].set(d[101], d[104])
                            }])
                        }, function(a) {
                            return d[102] = "inference_timestamp_ms", d[99] = d[55].get(d[102]), d[55], c.i64.neq(d[99], void 0) ? (c.i64.neq(d[99], void 0) ? d[104] = c.i64.to_string(d[99]) : d[104] = void 0, d[96].set(d[102], d[104])) : 0, d[103] = "inference_model_version", d[100] = d[55].get(d[103]), d[55], c.i64.neq(d[100], void 0) ? d[96].set(d[103], d[100]) : 0, d[93] = d[96]
                        }])
                    }, function(a) {
                        return d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[88], d[93]) : 0
                    }])
                }, function(a) {
                    return d[89] = "note_metadata", d[57] = d[1].get(d[89]), d[1], d[57] ? d[58] = !1 : d[58] = !0, d[58] ? c.resolve() : c.sequence([function(a) {
                        return d[57] ? d[92] = !1 : d[92] = !0, d[92] ? c.resolve(d[93] = void 0) : c.sequence([function(a) {
                            return d[96] = new c.Map(), d[101] = "message_type", d[97] = d[57].get(d[101]), d[57], d[97] !== void 0 ? d[96].set(d[101], d[97]) : 0, d[102] = "mentions", d[98] = d[57].get(d[102]), d[57], d[98] ? d[99] = !1 : d[99] = !0, d[99] ? c.resolve() : c.sequence([function(a) {
                                return d[104] = c.createArray(), d[105] = c.i64.of_int32(d[98].length), c.i64.gt(d[105], c.i64.cast([0, 0])) ? c.loopAsync(d[105], function(a) {
                                    return d[106] = a, c.sequence([function(a) {
                                        return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[98], d[106]).then(function(a) {
                                            return a = a, d[107] = a[0], d[108] = a[1], a
                                        })
                                    }, function(a) {
                                        return d[109] = new c.Map(), d[112] = "offset", d[110] = d[107].get(d[112]), d[107], c.i64.neq(d[110], void 0) ? d[109].set(d[112], d[110]) : 0, d[113] = "length", d[111] = d[107].get(d[113]), d[107], c.i64.neq(d[111], void 0) ? d[109].set(d[113], d[111]) : 0, d[114] = (d[104].push(d[109]), d[104])
                                    }])
                                }) : c.resolve()
                            }, function(a) {
                                return d[96].set(d[102], d[104])
                            }])
                        }, function(a) {
                            return d[103] = "expiration_timestamp_ms", d[100] = d[57].get(d[103]), d[57], c.i64.neq(d[100], void 0) ? d[96].set(d[103], c.i64.to_string(d[100])) : 0, d[93] = d[96]
                        }])
                    }, function(a) {
                        return d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[89], d[93]) : 0
                    }])
                }, function(a) {
                    return d[90] = "ai_bot_summon_metadata", d[59] = d[1].get(d[90]), d[1], d[59] ? d[60] = !1 : d[60] = !0, d[60] ? 0 : (d[59] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "is_e2ee_summon_message", d[97] = d[59].get(d[98]), d[59], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[90], d[93]) : 0), d[91] = "ai_forwarded_metadata", d[61] = d[1].get(d[91]), d[1], d[61] ? d[62] = !1 : d[62] = !0, d[62] ? 0 : (d[61] ? d[92] = !1 : d[92] = !0, d[92] ? d[93] = void 0 : (d[96] = new c.Map(), d[98] = "is_generated_by_meta_ai", d[97] = d[61].get(d[98]), d[61], d[97] !== void 0 ? d[96].set(d[98], d[97]) : 0, d[93] = d[96]), d[94] = d[93].keys(), d[95] = c.i64.of_int32(d[94].length), c.i64.neq(d[95], c.i64.cast([0, 0])) ? d[6].set(d[91], d[93]) : 0), d[63] = c.toJSON(d[6]), d[5] = d[63]
                }])
            }, function(b) {
                return c.forEach(c.filter(c.db.table(12).fetch([
                    [
                        [a[0], a[1], a[2]]
                    ]
                ]), function(b) {
                    return c.i64.eq(b.threadKey, a[0]) && c.i64.eq(c.i64.cast([0, 0]), c.i64.cast([0, 0])) && c.i64.eq(b.timestampMs, a[1]) && b.messageId === a[2]
                }), function(b) {
                    var c = b.update;
                    b.item;
                    return c({
                        adminMsgCtaId: d[0],
                        adminMsgCtaTitle: a[3],
                        adminMsgCtaType: a[4],
                        metadataDataclass: d[5]
                    })
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxApplyAdminMessageCTAStoredProcedure";
    e.exports = a
}), null);