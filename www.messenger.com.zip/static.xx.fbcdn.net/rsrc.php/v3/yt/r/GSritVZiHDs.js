; /*FB_PKG_DELIM*/

__d("CometMessagingJewelDropdownQPBannerPlaceholder.react", ["CometRow.react", "CometRowItem.react", "MDSGlimmer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h || d("react"),
        j = {
            actionButtonGlimmer: {
                borderTopStartRadius: "xhk9q7s",
                borderTopEndRadius: "x1otrzb0",
                borderBottomEndRadius: "x1i1ezom",
                borderBottomStartRadius: "x1o6z2jb",
                height: "xc9qbxq",
                $$css: !0
            },
            logoGlimmer: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                height: "xsdox4t",
                marginTop: "x1rdy4ex",
                width: "x1useyqa",
                $$css: !0
            },
            textGlimmer: {
                borderTopStartRadius: "xhk9q7s",
                borderTopEndRadius: "x1otrzb0",
                borderBottomEndRadius: "x1i1ezom",
                borderBottomStartRadius: "x1o6z2jb",
                height: "x1qx5ct2",
                marginBottom: "xu06os2",
                marginTop: "x1ok221b",
                $$css: !0
            }
        };

    function a() {
        var a, b;
        return i.jsxs("div", {
            className: "x1qjc9v5 xlhe6ec x1q0q8m5 x1qhh985 xu3j5b3 xcfux6l x26u7qi xm0m39n x1lq5wgf xgqcy7u x30kzoy x9jhf4c x13fuv20 x972fbf x9f619 x78zum5 xdt5ytf x1iyjqo2 xs83m0k xf30bs1 x1qughib x14vqqas xq8finb xod5an3 x16n37ib x2lwn1j xeuugli x6ikm8r x10wlt62 x1iorvi4 x150jy0e x1e558r4 x1l90r2v x1n2onr6 x1ja2u2z",
            children: [i.jsxs(c("CometRow.react"), {
                verticalAlign: "center",
                children: [i.jsx(a = c("CometRowItem.react"), {
                    verticalAlign: "top",
                    children: i.jsx(b = c("MDSGlimmer.react"), {
                        index: 0,
                        xstyle: j.logoGlimmer
                    })
                }), i.jsx(a, {
                    expanding: !0,
                    children: i.jsxs("div", {
                        className: "x78zum5 xdt5ytf xz62fqu x16ldp7u",
                        children: [i.jsx(b, {
                            index: 0,
                            xstyle: j.textGlimmer
                        }), i.jsx(b, {
                            index: 0,
                            xstyle: j.textGlimmer
                        })]
                    })
                })]
            }), i.jsxs(c("CometRow.react"), {
                align: "justify",
                direction: "forward",
                spacing: 8,
                wrap: "none",
                children: [i.jsx(a, {
                    expanding: !0,
                    children: i.jsx(b, {
                        index: 1,
                        xstyle: j.actionButtonGlimmer
                    })
                }), i.jsx(a, {
                    expanding: !0,
                    children: i.jsx(b, {
                        index: 1,
                        xstyle: j.actionButtonGlimmer
                    })
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWQuickPromotionThreadlistBannerQuery.graphql", ["MWQuickPromotionThreadlistBannerQuery_facebookRelayOperation", "relay-runtime"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                kind: "Literal",
                name: "surface_nux_id",
                value: 8783
            }, {
                kind: "Literal",
                name: "trigger",
                value: "MESSENGER_INBOX_THREADLIST_TOP"
            }],
            c = [{
                kind: "Literal",
                name: "supported",
                value: "37XnNV"
            }],
            d = {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "MWQuickPromotionThreadlistBannerQuery",
                    fragmentName: "CometQuickPromotionInboxThreadListBannerRendererStrategy_cometQuickPromotionBaseStrategy",
                    fragmentPropName: "cometQuickPromotionBaseStrategy",
                    kind: "ModuleImport"
                }],
                type: "CometQuickPromotionInboxThreadListBannerRendererStrategy",
                abstractKey: null
            },
            e = {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "MWQuickPromotionThreadlistBannerQuery",
                    fragmentName: "CometQuickPromotionMessengerWebEPDBannerRendererStrategy_cometQuickPromotionBaseStrategy",
                    fragmentPropName: "cometQuickPromotionBaseStrategy",
                    kind: "ModuleImport"
                }],
                type: "CometQuickPromotionMessengerWebEPDBannerRendererStrategy",
                abstractKey: null
            },
            f = {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "MWQuickPromotionThreadlistBannerQuery",
                    fragmentName: "CometQuickPromotionMessengerWebPrivacyPolicyNoticeBannerRendererStrategy_quickPromotionRef",
                    fragmentPropName: "quickPromotionRef",
                    kind: "ModuleImport"
                }],
                type: "CometQuickPromotionMessengerWebPrivacyPolicyNoticeBannerRendererStrategy",
                abstractKey: null
            },
            g = {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "MWQuickPromotionThreadlistBannerQuery",
                    fragmentName: "CometQuickPromotionArmadilloSecurityAlertsSettingsDefaultOffBannerRendererStrategy_cometQuickPromotionBaseStrategy",
                    fragmentPropName: "cometQuickPromotionBaseStrategy",
                    kind: "ModuleImport"
                }],
                type: "CometQuickPromotionArmadilloSecurityAlertsSettingsDefaultOffBannerRendererStrategy",
                abstractKey: null
            },
            h = {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "MWQuickPromotionThreadlistBannerQuery",
                    fragmentName: "CometQuickPromotionDarkModeBannerRendererStrategy_cometQuickPromotionBaseStrategy",
                    fragmentPropName: "cometQuickPromotionBaseStrategy",
                    kind: "ModuleImport"
                }],
                type: "CometQuickPromotionMessengerDarkModeBannerRendererStrategy",
                abstractKey: null
            };
        return {
            fragment: {
                argumentDefinitions: [],
                kind: "Fragment",
                metadata: null,
                name: "MWQuickPromotionThreadlistBannerQuery",
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "Viewer",
                    kind: "LinkedField",
                    name: "viewer",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: a,
                        concreteType: "ViewerEligibleQuickPromotionsConnection",
                        kind: "LinkedField",
                        name: "eligible_promotions",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "QuickPromotion",
                            kind: "LinkedField",
                            name: "nodes",
                            plural: !0,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "CometQuickPromotionSections",
                                kind: "LinkedField",
                                name: "comet_qp_sections",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: c,
                                    concreteType: null,
                                    kind: "LinkedField",
                                    name: "renderer_strategy",
                                    plural: !1,
                                    selections: [d, e, f, g, h],
                                    storageKey: 'renderer_strategy(supported:"37XnNV")'
                                }],
                                storageKey: null
                            }],
                            storageKey: null
                        }],
                        storageKey: 'eligible_promotions(surface_nux_id:8783,trigger:"MESSENGER_INBOX_THREADLIST_TOP")'
                    }],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [],
                kind: "Operation",
                name: "MWQuickPromotionThreadlistBannerQuery",
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "Viewer",
                    kind: "LinkedField",
                    name: "viewer",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: a,
                        concreteType: "ViewerEligibleQuickPromotionsConnection",
                        kind: "LinkedField",
                        name: "eligible_promotions",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "QuickPromotion",
                            kind: "LinkedField",
                            name: "nodes",
                            plural: !0,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "CometQuickPromotionSections",
                                kind: "LinkedField",
                                name: "comet_qp_sections",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: c,
                                    concreteType: null,
                                    kind: "LinkedField",
                                    name: "renderer_strategy",
                                    plural: !1,
                                    selections: [{
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "__typename",
                                        storageKey: null
                                    }, d, e, f, g, h],
                                    storageKey: 'renderer_strategy(supported:"37XnNV")'
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "id",
                                storageKey: null
                            }],
                            storageKey: null
                        }],
                        storageKey: 'eligible_promotions(surface_nux_id:8783,trigger:"MESSENGER_INBOX_THREADLIST_TOP")'
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("MWQuickPromotionThreadlistBannerQuery_facebookRelayOperation"),
                metadata: {},
                name: "MWQuickPromotionThreadlistBannerQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    b("relay-runtime").PreloadableQueryRegistry.set(a.params.id, a);
    e.exports = a
}), null);
__d("MWQuickPromotionThreadlistBanner.react", ["CometMessagingJewelDropdownQPBannerPlaceholder.react", "CometPlaceholder.react", "CometQuickPromotionLoggerContext.react", "CometRelay", "MWQuickPromotionThreadlistBannerQuery.graphql", "react", "useQuickPromotionFalcoEvent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = i || d("react");

    function a(a) {
        a = a.queries;
        a = a.bannerQueryRef;
        a = d("CometRelay").usePreloadedQuery(h !== void 0 ? h : h = b("MWQuickPromotionThreadlistBannerQuery.graphql"), a);
        a = a == null ? void 0 : (a = a.viewer) == null ? void 0 : (a = a.eligible_promotions) == null ? void 0 : (a = a.nodes[0]) == null ? void 0 : (a = a.comet_qp_sections) == null ? void 0 : a.renderer_strategy;
        var e = c("useQuickPromotionFalcoEvent")({
            context_surface_id: 8783,
            context_trigger: "messenger_inbox_threadlist_top"
        });
        return a == null ? null : j.jsx(c("CometPlaceholder.react"), {
            fallback: j.jsx(c("CometMessagingJewelDropdownQPBannerPlaceholder.react"), {}),
            children: j.jsx(c("CometQuickPromotionLoggerContext.react").Provider, {
                value: e,
                children: j.jsx(d("CometRelay").MatchContainer, {
                    match: a
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);