; /*FB_PKG_DELIM*/

__d("EchoBackupCompareUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b;
        return {
            contentSubtype: a.contentSubtype,
            contentType: a.contentType,
            reactionTsList: (b = a.reactionAuthoritativeTimestampMs) == null ? void 0 : b.map(function(a) {
                return a.displayName == null ? null : Number(a.displayName) / 1e3
            }).filter(Boolean).sort(),
            receiptTsList: (b = a.receiptStatusList) == null ? void 0 : b.map(function(a) {
                return a.timestampMs == null ? null : a.timestampMs / 1e3
            }).filter(Boolean).sort()
        }
    }

    function g(a, b) {
        if (a == null && b == null) return !0;
        if (a != null && b != null) return a.length === b.length && a.every(function(a, c) {
            return a === b[c]
        });
        return a == null && (b == null ? void 0 : b.length) === 0 || b == null && (a == null ? void 0 : a.length) === 0 ? !0 : !1
    }

    function b(a, b) {
        return b != null && a.contentSubtype === b.contentSubtype && a.contentType === b.contentType && g(a.reactionTsList, b.reactionTsList)
    }
    f.buildEchoDocCacheValue = a;
    f.echoEquals = b
}), 66);
__d("EchoConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = new Set(["\0", "\x01", "\x02", "\x03", "\x04", "\x05", "\x06", "\x07", "\b", "\t", "\n", "\v", "\f", "\r", "\x0e", "\x0f", "\x10", "\x11", "\x12", "\x13", "\x14", "\x15", "\x16", "\x17", "\x18", "\x19", "\x1a", "\x1b", "\x1c", "\x1d", "\x1e", "\x1f", '"', " ", "(", ")", ",", ":", ";", "<", ">", "@", "[", "]", "\\"]);
    f.ADDRESS_LOCAL_KEY_CHARS_NEED_QUOTE = a
}), 66);
__d("EchoEncodingUtils", ["EchoConstants", "EchoMessage", "MAWMsgType", "WABase64", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Set(['"', "\\", "\n", "\r", "\0"]),
        i = new Set(["\0", "\x01", "\x02", "\x03", "\x04", "\x05", "\x06", "\x07", "\b", "\t", "\n", "\v", "\f", "\r", "\x0e", "\x0f", "\x10", "\x11", "\x12", "\x13", "\x14", "\x15", "\x16", "\x17", "\x18", "\x19", "\x1a", "\x1b", "\x1c", "\x1d", "\x1e", "\x1f", '"', "\\"]);

    function j(a, b) {
        for (var b = b, c = Array.isArray(b), d = 0, b = c ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var e;
            if (c) {
                if (d >= b.length) break;
                e = b[d++]
            } else {
                d = b.next();
                if (d.done) break;
                e = d.value
            }
            e = e;
            if (a.indexOf(e) >= 0) return !0
        }
        return !1
    }

    function k(a, b, d) {
        d === void 0 && (d = new Set());
        if (a.length <= 0) throw c("unrecoverableViolation")("The input string must be non-empty", "labyrinth_web");
        var e = b;
        b === "conditional" && (j(a, d) ? e = "always" : e = "never");
        if (e === "never") return a;
        b = '"';
        for (d = 0; d < a.length; d++) {
            e = a[d];
            h.has(e) ? (b += "\\", e === "\r" ? b += "r" : e === "\n" ? b += "n" : b += e) : b += e
        }
        return b + '"'
    }

    function l(a) {
        if (!Number.isSafeInteger(a)) throw c("unrecoverableViolation")("The input value must be a safe integer", "labyrinth_web");
        return a.toString()
    }

    function m(a) {
        var b = "",
            c = a.displayName,
            e = a.localKey;
        a = a.transportKey;
        c != null && c.length > 0 && (b += k(c, "always") + " <");
        b += k(e, "conditional", d("EchoConstants").ADDRESS_LOCAL_KEY_CHARS_NEED_QUOTE) + "@" + a;
        c != null && c.length > 0 && (b += ">");
        return b
    }

    function n(a, b, c) {
        c != null && c.length !== 0 && a.set(b, k(c, "conditional", i))
    }

    function a(a, b, c) {
        if (c != null) {
            c = l(c);
            n(a, b, c)
        }
    }

    function b(a, b, c) {
        if (c != null) {
            c = l(c ? 1 : 0);
            n(a, b, c)
        }
    }

    function e(a, b, c) {
        c != null && a.set(b, m(c))
    }

    function f(a, b, c) {
        if (c != null) {
            var d = "";
            c.forEach(function(a, b) {
                d += m(a), b < c.length - 1 && (d += ", ")
            });
            a.set(b, d)
        }
    }

    function o(a) {
        var b = "";
        a.forEach(function(a, c) {
            b = b + c + ": " + a + "\r\n"
        });
        return b
    }

    function p(a) {
        return d("WABase64").encodeB64UrlSafe(a)
    }

    function q(a) {
        switch (a) {
            case d("MAWMsgType").MSG_TYPE.TEXT:
                return d("EchoMessage").EchoXMessageContentType.TEXT;
            case d("MAWMsgType").MSG_TYPE.IMAGE:
                return d("EchoMessage").EchoXMessageContentType.IMAGE;
            case d("MAWMsgType").MSG_TYPE.VIDEO:
                return d("EchoMessage").EchoXMessageContentType.VIDEO;
            case d("MAWMsgType").MSG_TYPE.PTT:
                return d("EchoMessage").EchoXMessageContentType.AUDIO;
            case d("MAWMsgType").MSG_TYPE.STICKER:
                return d("EchoMessage").EchoXMessageContentType.STICKER;
            case d("MAWMsgType").MSG_TYPE.GIF:
                return d("EchoMessage").EchoXMessageContentType.GIF;
            case d("MAWMsgType").MSG_TYPE.XMA:
                return d("EchoMessage").EchoXMessageContentType.XMA;
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                return d("EchoMessage").EchoXMessageContentType.DOCUMENT;
            case d("MAWMsgType").MSG_TYPE.REACTION:
                return d("EchoMessage").EchoXMessageContentType.REACTION;
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
                return d("EchoMessage").EchoXMessageContentType.EPHEMERAL_SETTINGS;
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
                return d("EchoMessage").EchoXMessageContentType.EPHEMERAL_SYNC_RESPONSE;
            case d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME:
                return d("EchoMessage").EchoXMessageContentType.MESSAGE_DELETE_FOR_ME;
            case d("MAWMsgType").MSG_TYPE.REVOKED:
                return d("EchoMessage").EchoXMessageContentType.UNSEND;
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
                return d("EchoMessage").EchoXMessageContentType.GROUP_INVITES;
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                return d("EchoMessage").EchoXMessageContentType.BUMP;
            default:
                return d("EchoMessage").EchoXMessageContentType.UNKNOWN
        }
    }

    function r(a) {
        if (a == null) return void 0;
        switch (a) {
            case d("EchoMessage").EchoXMessageContentType.TEXT:
                return d("MAWMsgType").MSG_TYPE.TEXT;
            case d("EchoMessage").EchoXMessageContentType.IMAGE:
                return d("MAWMsgType").MSG_TYPE.IMAGE;
            case d("EchoMessage").EchoXMessageContentType.VIDEO:
                return d("MAWMsgType").MSG_TYPE.VIDEO;
            case d("EchoMessage").EchoXMessageContentType.AUDIO:
                return d("MAWMsgType").MSG_TYPE.PTT;
            case d("EchoMessage").EchoXMessageContentType.STICKER:
                return d("MAWMsgType").MSG_TYPE.STICKER;
            case d("EchoMessage").EchoXMessageContentType.GIF:
                return d("MAWMsgType").MSG_TYPE.GIF;
            case d("EchoMessage").EchoXMessageContentType.XMA:
                return d("MAWMsgType").MSG_TYPE.XMA;
            case d("EchoMessage").EchoXMessageContentType.DOCUMENT:
                return d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE;
            case d("EchoMessage").EchoXMessageContentType.REACTION:
                return d("MAWMsgType").MSG_TYPE.REACTION;
            case d("EchoMessage").EchoXMessageContentType.EPHEMERAL_SETTINGS:
                return d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN;
            case d("EchoMessage").EchoXMessageContentType.EPHEMERAL_SYNC_RESPONSE:
                return d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE;
            case d("EchoMessage").EchoXMessageContentType.MESSAGE_DELETE_FOR_ME:
                return d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME;
            case d("EchoMessage").EchoXMessageContentType.UNSEND:
                return d("MAWMsgType").MSG_TYPE.REVOKED;
            case d("EchoMessage").EchoXMessageContentType.GROUP_INVITES:
                return d("MAWMsgType").MSG_TYPE.GROUP_INVITE;
            case d("EchoMessage").EchoXMessageContentType.BUMP:
                return d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE;
            default:
                return void 0
        }
    }
    g.echoSetStringField = n;
    g.echoSetIntField = a;
    g.echoSetBooleanField = b;
    g.echoSetAddressField = e;
    g.echoSetAddressListField = f;
    g.echoEncodeFields = o;
    g.convertMediaKeyToString = p;
    g.convertDbMsgTypeToXMessageContentType = q;
    g.convertXMessageContentTypeToDbMsgType = r
}), 98);
__d("EchoCommonUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    c = "Echo-Doc-Version";

    function a(a, b) {
        var c = a.localKey;
        a = a.transportKey;
        return c + "@" + a + "-" + b
    }

    function b(a, b, c) {
        return a == null ? {
            localKey: b,
            transportKey: c
        } : {
            displayName: a,
            localKey: b,
            transportKey: c
        }
    }
    f.ECHO_COMMON_FIELD_DOCUMENT_VERSION = c;
    f.getEchoAddressFieldNameWithSuffix = a;
    f.craftEchoAddress = b
}), 66);
__d("EchoDecodingUtils", ["invariant", "EchoConstants", "WALogger"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] ", " not a valid number in echo message"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Fail to decode if the input string does not have CRLF"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Address  decode failed with value: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] invalid input to echoDecodeAddressList detected"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] invalid transportKey in address detected"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] invalid localKey in address detected"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] parse localKey in address failed"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] echoDecodeAddress failed"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] conditional quote mode decode failed"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] invalid input to echoDecodeAddress"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Fail decoding because we didn't have a closing quote. Error Field: ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Field name is blank"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] This is a raw line and we cannot decode its field name and value."]);
        u = function() {
            return a
        };
        return a
    }
    var v = new Set([]);

    function w(a, b) {
        if (a.length === 0) return;
        var c = a.indexOf(":");
        if (c === -1) {
            d("WALogger").ERROR(u());
            return
        }
        var e = a.substring(0, c).trim();
        a = a.substring(c + 1).trim();
        if (e.length === 0) {
            d("WALogger").ERROR(t());
            return
        }
        if (a.length === 0) {
            b.has(e) && b["delete"](e);
            return
        }
        b.set(e, a)
    }

    function x(a, b, c, e) {
        c === void 0 && (c = new Set());
        var f = !1,
            g = b === "conditional" && a[0] === '"',
            h = "",
            i = g ? 1 : 0;
        while (i < a.length) {
            var j = a[i];
            if (b === "conditional" && !g && j === '"') break;
            if (!g && c.has(j)) break;
            if (g && !f && j === '"') {
                g = !1;
                i++;
                break
            }
            if (g && !f && j === "\\") {
                if (i === a.length - 1) break;
                f = !0
            } else f && j === "r" ? h += "\r" : f && j === "n" ? h += "\n" : h += j, f = !1;
            i++
        }
        if (g || h.length === 0) {
            c = (j = e) != null ? j : "unknown";
            d("WALogger").ERROR(s(), c);
            return {
                remainder: a,
                result: null,
                success: !1
            }
        }
        return {
            remainder: a.substring(i),
            result: h,
            success: !0
        }
    }

    function y(a, b) {
        if (a.length === 0) {
            d("WALogger").ERROR(r());
            return {
                remainder: a,
                result: null,
                success: !1
            }
        }
        var c = a.trimLeft();
        c = x(c, "conditional", d("EchoConstants").ADDRESS_LOCAL_KEY_CHARS_NEED_QUOTE, b);
        if (!c.success) {
            d("WALogger").ERROR(q());
            return {
                remainder: a,
                result: null,
                success: !1
            }
        }
        c.result != null || h(0, 47923);
        if (c.remainder[0] === "@") {
            var e = z(c.remainder, c.result, b);
            return {
                remainder: e.remainder,
                result: e.result,
                success: e.success
            }
        }
        e = c.result;
        c = c.remainder.trimLeft();
        if (c.startsWith("<")) {
            c = z(c.substring(1), void 0, b);
            b = c.result;
            var f = c.remainder;
            if (c.success && b != null && f.startsWith(">"))
                if (e.length === 0) return {
                    remainder: f.substring(1),
                    result: b,
                    success: !0
                };
                else return {
                    remainder: f.substring(1),
                    result: babelHelpers["extends"]({}, b, {
                        displayName: e
                    }),
                    success: !0
                }
        }
        d("WALogger").ERROR(p());
        return {
            remainder: a,
            result: null,
            success: !1
        }
    }

    function z(a, b, c) {
        var e = b == null ? a.trimLeft() : a;
        b = b;
        if (b == null) {
            var f = x(e, "conditional", d("EchoConstants").ADDRESS_LOCAL_KEY_CHARS_NEED_QUOTE, c);
            if (!f.success) {
                d("WALogger").ERROR(o());
                return {
                    remainder: a,
                    result: null,
                    success: !1
                }
            }
            b = f.result;
            e = f.remainder
        }
        if (b == null || b.length === 0 || e[0] !== "@") {
            d("WALogger").ERROR(n());
            return {
                remainder: a,
                result: null,
                success: !1
            }
        }
        f = x(e.substring(1), "never", d("EchoConstants").ADDRESS_LOCAL_KEY_CHARS_NEED_QUOTE, c);
        e = f.result;
        if (f.success && e != null && e.length > 0) return {
            remainder: f.remainder,
            result: {
                localKey: b,
                transportKey: e
            },
            success: !0
        };
        else {
            d("WALogger").ERROR(m());
            return {
                remainder: a,
                result: null,
                success: !1
            }
        }
    }

    function A(a, b) {
        if (a.length === 0) {
            d("WALogger").ERROR(l());
            return {
                result: null,
                success: !1
            }
        }
        var c = y(a, b);
        if (!c.success) {
            d("WALogger").ERROR(k(), a);
            return {
                result: null,
                success: !1
            }
        }
        c.result != null || h(0, 47927);
        a = [c.result];
        c = c.remainder;
        while (c.startsWith(",")) {
            var e = y(c.substring(1).trimLeft(), b);
            if (e.success) e.result != null && a.push(e.result), c = e.remainder;
            else break
        }
        return {
            result: a,
            success: !0
        }
    }

    function a(a) {
        var b = new Map(),
            c = a.split("\r\n");
        if (c.length === 1 && c[0] === a) {
            d("WALogger").ERROR(j());
            return b
        }
        c.forEach(function(a) {
            return w(a, b)
        });
        return b
    }

    function b(a, b) {
        a = a.get(b);
        if (a == null || a.length === 0 || a === '""') return {
            result: null,
            success: !1
        };
        a = x(a, "conditional", v, b);
        b = a.result;
        a = a.success;
        return {
            result: b,
            success: a
        }
    }

    function c(a, b) {
        a = B(a, b);
        return {
            result: (b = a.result) != null ? b : 0,
            success: a.success
        }
    }

    function B(a, b) {
        a = a.get(b);
        if (a == null || a.length === 0) return {
            result: null,
            success: !1
        };
        a = parseInt(a, 10);
        if (isNaN(a)) {
            d("WALogger").ERROR(i(), b);
            return {
                result: null,
                success: !1
            }
        } else return Number.isSafeInteger(a) ? {
            result: a,
            success: !0
        } : {
            result: a > Number.MAX_SAFE_INTEGER ? Number.MAX_SAFE_INTEGER : Number.MIN_SAFE_INTEGER,
            success: !0
        }
    }

    function e(a, b) {
        a = C(a, b);
        return {
            result: (b = a.result) != null ? b : !1,
            success: a.success
        }
    }

    function C(a, b) {
        a = B(a, b);
        return !a.success || a.result !== 0 && a.result !== 1 ? {
            result: null,
            success: !1
        } : {
            result: a.result === 1,
            success: !0
        }
    }

    function f(a, b) {
        a = a.get(b);
        if (a == null || a.length === 0) return {
            result: null,
            success: !1
        };
        a = y(a, b);
        b = a.result;
        a = a.success;
        return {
            result: b,
            success: a
        }
    }

    function D(a, b) {
        a = a.get(b);
        return a == null || a.length === 0 ? {
            result: null,
            success: !1
        } : A(a, b)
    }

    function E(a, b) {
        a = a.get(b);
        if (a == null || a.length === 0) return {
            result: null,
            success: !1
        };
        b = a.split(",").map(function(a) {
            return a.trim()
        }).filter(Boolean);
        return b.length === 0 ? {
            result: null,
            success: !1
        } : {
            result: b,
            success: !0
        }
    }
    g.echoDecodeFields = a;
    g.echoDecodeStringField = b;
    g.echoDecodeIntField = c;
    g.echoDecodeNullableIntField = B;
    g.echoDecodeBooleanField = e;
    g.echoDecodeNullableBooleanField = C;
    g.echoDecodeAddressField = f;
    g.echoDecodeAddressListField = D;
    g.echoDecodeObjectIdListField = E
}), 98);
__d("EchoMessage", ["$InternalEnum", "EchoCommonUtils", "EchoDecodingUtils", "EchoEncodingUtils", "EchoMessageMediaFieldUtils", "EchoMessageMediaGroupFieldUtil", "EchoMessageQuoteFieldUtils", "EchoMessageReceiptStatusFieldUtils", "EchoMessageXMAFieldUtils", "FBLogger", "WALogger", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] mandatory xma data is missing from xma message, msgId: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " Message origin: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " Message origin: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " Message origin: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " Message origin: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Failed to decode media data for Receiver Fetch, Message origin: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] fieldsMap is empty for the echo message"]);
        n = function() {
            return a
        };
        return a
    }
    var o = "Message-ID",
        p = "Thread-ID",
        q = "Sort-Order",
        r = "Display-Timestamp",
        s = "Authoritative-Timestamp",
        t = "From",
        u = "Text",
        v = "Text-Size",
        w = "Send-Error",
        x = "Is-Tombstoned",
        y = "Expire-Timestamp",
        z = "Delete-Timestamp",
        A = "Ephemeral-Duration",
        B = "Message-Content-Type",
        C = "X-Message-Content-Type",
        D = "Message-Content-Subtype",
        E = "Is-Forwarded",
        F = "X-Offline-Threading-ID",
        G = "X-Thread-ID",
        H = "X-Message-Placeholder-Type",
        I = "Reactions",
        J = "Reaction-Authoritative-Timestamps",
        K = "X-Reaction-Offline-Threading-IDs",
        L = "Echo-Serialization-Origin",
        M = "Revoke-Sent-Timestamp",
        N = "Revoke-Unsent-Timestamp",
        O = "Edit-Count",
        P = "Edit-Contents-",
        Q = "Edit-Timestamps-";
    f = "Group-ID";
    var R = "Group-Index",
        S = "Group-Size",
        T = "Receiver-Fetch-Id",
        U = "Message-Ephemerality-Type",
        V = 1,
        W = (b = b("$InternalEnum"))({
            NONE: "none",
            SMALL: "small",
            MEDIUM: "medium",
            LARGE: "large"
        }),
        X = b({
            NONE: "none",
            UNSEND: "unsend"
        }),
        Y = b({
            DECRYPTION_FAILURE: "decryption_failure",
            UNSUPPORTED_NEEDS_UPDATE: "unsupported_needs_update",
            TEXT: "text",
            ADMIN_MESSAGE: "admin_message",
            MEDIA: "media",
            XMA: "xma",
            NULL_STATE: "null_state",
            PLACEHOLDER: "placeholder"
        }),
        aa = b({
            UNKNOWN: "unknown",
            TEXT: "text",
            IMAGE: "image",
            VIDEO: "video",
            AUDIO: "audio",
            STICKER: "sticker",
            GIF: "gif",
            URL: "url",
            EPHEMERAL_SETTINGS: "ephemeral_settings",
            LOCATION: "location",
            DOCUMENT: "document",
            UNSEND: "unsend",
            SCREENSHOT_ACTION: "screenshot_action",
            REACTION: "reaction",
            XMA: "xma",
            VISUAL_MESSAGE_VIDEO: "visual_message_video",
            VISUAL_MESSAGE_IMAGE: "visual_message_image",
            VISUAL_MESSAGE_ACTION: "visual_message_action",
            SCREEN_RECORDING_ACTION: "screen_recording_action",
            MESSAGE_DELETE_FOR_ME: "message_delete_for_me",
            ENCRYPTED_BACKUP_NEW_DEVICE_ENROLLMENT: "encrypted_backup_new_device_enrollment",
            SENDER_KEY: "sender_key",
            DELETE_THREAD: "delete_thread",
            READ_THREAD: "read_thread",
            UNREAD_THREAD: "unread_thread",
            REACTION_UNSEND: "reaction_unsend",
            GROUP_INVITES: "group_invites",
            EPHEMERAL_SYNC_RESPONSE: "ephemeral_sync_response",
            BUMP: "bump"
        }),
        Z = b({
            NO_PLACEHOLDER: "0",
            DECRYPTION_FAILURE: "-1",
            CLIENT_NOT_SUPPORTED_NEED_UPDATE: "-2",
            UNAVIALABLE_DEVICE: "-3"
        }),
        $ = b({
            UNKNOWN: "Unknown",
            WEB: "Web",
            MOBILE: "Mobile"
        });

    function a(a) {
        var b = new Map();
        ia(b, a);
        "mediaData" in a && a.mediaData && d("EchoMessageMediaFieldUtils").echoMessageSetMediaMetadataFields(b, a.mediaData);
        return d("EchoEncodingUtils").echoEncodeFields(b)
    }

    function ba(a, b) {
        var c, e = [],
            f = new Set();
        b.forEach(function(c, g, h) {
            c = g.startsWith(P);
            h = g.startsWith(Q);
            if (c || h) {
                h = g.slice(c ? P.length : Q.length);
                if (!f.has(h)) {
                    f.add(h);
                    c = (g = d("EchoDecodingUtils").echoDecodeStringField(b, "" + P + h).result) != null ? g : "";
                    g = ((g = d("EchoDecodingUtils").echoDecodeIntField(b, "" + Q + h).result) != null ? g : 0) / 1e3;
                    e.push({
                        messageId: h,
                        originalMessageId: a,
                        text: c,
                        timestamp: g
                    })
                }
            }
        });
        c = (c = d("EchoDecodingUtils").echoDecodeIntField(b, O).result) != null ? c : 0;
        return {
            editCount: c,
            editHistory: e
        }
    }

    function e(a) {
        a = d("EchoDecodingUtils").echoDecodeFields(a);
        if (a.size === 0) {
            d("WALogger").ERROR(n());
            return null
        }
        var b = d("EchoDecodingUtils").echoDecodeStringField(a, o),
            e = d("EchoDecodingUtils").echoDecodeStringField(a, p),
            f = d("EchoDecodingUtils").echoDecodeIntField(a, q),
            g = d("EchoDecodingUtils").echoDecodeIntField(a, r),
            O = d("EchoDecodingUtils").echoDecodeStringField(a, B),
            P = d("EchoDecodingUtils").echoDecodeStringField(a, C),
            Q = d("EchoDecodingUtils").echoDecodeStringField(a, D);
        if (b.success && e.success && f.success) {
            b = b.result;
            if (b == null) throw c("FBLogger")("messenger_e2ee_web").mustfixThrow("The decoded messageId cannot be null");
            e = e.result;
            if (e == null) throw c("FBLogger")("messenger_e2ee_web").mustfixThrow("The decoded threadId cannot be null");
            O = O == null ? void 0 : O.result;
            if (O == null) throw c("FBLogger")("messenger_e2ee_web").mustfixThrow("The decoded contentTypeString cannot be null");
            var R = ba(b, a),
                S = R.editCount;
            R = R.editHistory;
            Q = {
                contentSubtype: fa(Q.result),
                contentType: da(O),
                displayTimestampMs: g.success ? g.result : f.result,
                editCount: S,
                editHistory: R,
                messageId: b,
                sortOrderMs: f.result,
                threadId: e
            };
            O = ea(P.result);
            O != null && (Q.xContentType = O);
            g = d("EchoDecodingUtils").echoDecodeAddressField(a, t);
            g.success && g.result != null && (Q.from = g.result);
            S = d("EchoDecodingUtils").echoDecodeNullableBooleanField(a, x);
            S.success && S.result != null && (Q.isTombstoned = S.result);
            R = d("EchoDecodingUtils").echoDecodeStringField(a, u);
            R.success && R.result != null && (Q.text = R.result);
            b = d("EchoDecodingUtils").echoDecodeStringField(a, v);
            if (b.success && b.result != null) {
                f = ca(b.result);
                Q.textSize = f
            }
            e = d("EchoDecodingUtils").echoDecodeStringField(a, H);
            if (e.success && e.result != null) {
                P = ga(e.result);
                Q.xMessagePlaceholderType = P
            }
            O = d("EchoDecodingUtils").echoDecodeStringField(a, w);
            O.success && O.result != null && (Q.sendError = O.result);
            g = d("EchoDecodingUtils").echoDecodeNullableIntField(a, y);
            g.success && g.result != null && (Q.expireTimestampMs = g.result);
            S = d("EchoDecodingUtils").echoDecodeNullableIntField(a, z);
            S.success && S.result != null && (Q.deleteTimestampMs = S.result);
            R = d("EchoDecodingUtils").echoDecodeNullableIntField(a, A);
            R.success && R.result != null && (Q.ephemeralDurationInSec = R.result);
            b = d("EchoDecodingUtils").echoDecodeStringField(a, U);
            b.success && b.result != null && (b.result === "view_once" && (Q.viewOnce = !0));
            f = d("EchoDecodingUtils").echoDecodeNullableIntField(a, s);
            f.success && f.result != null && (Q.authoritativeTimestampMs = f.result);
            e = d("EchoMessageReceiptStatusFieldUtils").echoMessageDecodeReceiptStatusDataFields(a);
            e.length > 0 && (Q.receiptStatusList = e);
            P = d("EchoDecodingUtils").echoDecodeNullableBooleanField(a, E);
            P.success && P.result != null && (Q.isForwarded = P.result);
            d("EchoMessageMediaGroupFieldUtil").decodeMessageMediaGroupFields(a, Q);
            O = d("EchoDecodingUtils").echoDecodeStringField(a, F);
            O.success && O.result != null && (Q.xOfflineThreadingId = O.result);
            g = d("EchoDecodingUtils").echoDecodeStringField(a, G);
            g.success && g.result != null && (Q.xThreadId = g.result);
            S = d("EchoDecodingUtils").echoDecodeStringField(a, L);
            S.success && S.result != null && (Q.serializationOrigin = ha(S.result));
            R = d("EchoDecodingUtils").echoDecodeNullableIntField(a, d("EchoCommonUtils").ECHO_COMMON_FIELD_DOCUMENT_VERSION);
            Q.version = R.success && R.result != null ? R.result : V;
            b = d("EchoDecodingUtils").echoDecodeAddressListField(a, I);
            b.success && b.result != null && (Q.reactions = b.result);
            f = d("EchoDecodingUtils").echoDecodeAddressListField(a, J);
            f.success && f.result != null && (Q.reactionAuthoritativeTimestampMs = f.result);
            e = d("EchoDecodingUtils").echoDecodeAddressListField(a, K);
            e.success && e.result != null && (Q.reactionXOfflineThreadingIds = e.result);
            P = d("EchoMessageQuoteFieldUtils").echoMessageDecodeQuoteFields(a);
            P != null && (Q.quoteData = P);
            O = (Q == null ? void 0 : Q.contentType) === Y.XMA && a.has(d("EchoMessageMediaFieldUtils").ECHO_MESSAGE_FIELD_NAME_ATTACHMENT_TYPE) && (a.has(d("EchoMessageMediaFieldUtils").ECHO_MESSAGE_FIELD_NAME_ATTACHMENT_OBJECT_ID) || a.has(d("EchoMessageMediaFieldUtils").ECHO_MESSAGE_FIELD_NAME_ATTACHMENT_OBJECT_IDS));
            g = a.has(T);
            S = c("gkx")("5624");
            if (a.has(T) && S) {
                R = d("EchoMessageMediaFieldUtils").decodeReceiverFetchData(a);
                b = d("EchoDecodingUtils").echoDecodeStringField(a, T);
                f = b.result;
                e = b.success;
                R == null || !e || f == null ? d("WALogger").ERROR(m(), Q.serializationOrigin) : (Q.receiverFetchData = R, Q.receiverFetchId = f)
            }
            if (((Q == null ? void 0 : Q.contentType) === Y.MEDIA || O) && !g) {
                P = d("EchoMessageMediaFieldUtils").echoMessageDecodeMediaDataFields(a, Q == null ? void 0 : Q.contentType, Q == null ? void 0 : Q.xContentType);
                S = "[labyrinth_web] mandatory media data is missing from media message, msgId: " + Q.messageId + ".";
                P != null ? (P.length !== 1 && P.length !== 2 && ((Q == null ? void 0 : Q.contentType) === Y.MEDIA && d("WALogger").ERROR(l(), S, Q.serializationOrigin), (Q == null ? void 0 : Q.contentType) === Y.XMA && d("WALogger").WARN(k(), S, Q.serializationOrigin)), Q.mediaData = P[0], P.length === 2 && (Q.previewMediaData = P[1])) : ((Q == null ? void 0 : Q.contentType) === Y.MEDIA && d("WALogger").ERROR(j(), S, Q.serializationOrigin), (Q == null ? void 0 : Q.contentType) === Y.XMA && d("WALogger").WARN(i(), S, Q.serializationOrigin))
            }
            if (Q.contentType === Y.PLACEHOLDER && Q.contentSubtype === X.UNSEND) {
                b = d("EchoDecodingUtils").echoDecodeNullableIntField(a, M);
                b.success && b.result != null && (Q.revokeSentTimestampMs = b.result);
                e = d("EchoDecodingUtils").echoDecodeNullableIntField(a, N);
                e.success && e.result != null && (Q.revokeUnsentTimestampMS = e.result)
            }
            if (Q.contentType === Y.XMA) {
                R = d("EchoMessageXMAFieldUtils").decodeXMAFields(a);
                if (R != null) Q.xmaData = R;
                else {
                    d("WALogger").ERROR(h(), Q.messageId);
                    return null
                }
            }
            return Q
        } else return null
    }

    function ca(a) {
        return (a = W.cast(a)) != null ? a : W.NONE
    }

    function da(a) {
        return (a = Y.cast(a)) != null ? a : Y.TEXT
    }

    function ea(a) {
        return aa.cast(a)
    }

    function fa(a) {
        return (a = X.cast(a)) != null ? a : X.NONE
    }

    function ga(a) {
        return (a = Z.cast(a)) != null ? a : Z.NO_PLACEHOLDER
    }

    function ha(a) {
        return (a = $.cast(a)) != null ? a : $.UNKNOWN
    }

    function ia(a, b) {
        var c;
        (c = d("EchoEncodingUtils")).echoSetStringField(a, o, b.messageId);
        c.echoSetStringField(a, p, b.threadId);
        c.echoSetIntField(a, q, b.sortOrderMs);
        c.echoSetIntField(a, r, b.displayTimestampMs);
        c.echoSetIntField(a, s, b.authoritativeTimestampMs);
        c.echoSetAddressField(a, t, b.from);
        c.echoSetStringField(a, u, b.text);
        b.textSize != null && d("EchoEncodingUtils").echoSetStringField(a, v, b.textSize);
        b.xMessagePlaceholderType != null && d("EchoEncodingUtils").echoSetStringField(a, H, b.xMessagePlaceholderType);
        d("EchoEncodingUtils").echoSetStringField(a, w, b.sendError);
        d("EchoEncodingUtils").echoSetBooleanField(a, x, b.isTombstoned);
        d("EchoEncodingUtils").echoSetIntField(a, y, b.expireTimestampMs);
        d("EchoEncodingUtils").echoSetIntField(a, z, b.deleteTimestampMs);
        d("EchoEncodingUtils").echoSetIntField(a, A, b.ephemeralDurationInSec);
        b.contentType != null && d("EchoEncodingUtils").echoSetStringField(a, B, b.contentType);
        b.xContentType != null && d("EchoEncodingUtils").echoSetStringField(a, C, b.xContentType);
        d("EchoMessageReceiptStatusFieldUtils").echoMessageSetReceiptStatusDataFields(a, b.receiptStatusList);
        d("EchoEncodingUtils").echoSetBooleanField(a, E, b.isForwarded);
        d("EchoEncodingUtils").echoSetStringField(a, F, b.xOfflineThreadingId);
        d("EchoEncodingUtils").echoSetStringField(a, G, b.xThreadId);
        d("EchoEncodingUtils").echoSetIntField(a, d("EchoCommonUtils").ECHO_COMMON_FIELD_DOCUMENT_VERSION, b.version);
        b.contentSubtype != null && d("EchoEncodingUtils").echoSetStringField(a, D, b.contentSubtype);
        d("EchoEncodingUtils").echoSetAddressListField(a, I, b.reactions);
        d("EchoEncodingUtils").echoSetAddressListField(a, J, b.reactionAuthoritativeTimestampMs);
        d("EchoEncodingUtils").echoSetAddressListField(a, K, b.reactionXOfflineThreadingIds);
        d("EchoMessageQuoteFieldUtils").echoMessageSetQuoteFields(a, b);
        b.serializationOrigin != null && d("EchoEncodingUtils").echoSetStringField(a, L, b.serializationOrigin);
        b.revokeSentTimestampMs != null && d("EchoEncodingUtils").echoSetIntField(a, M, b.revokeSentTimestampMs);
        b.revokeUnsentTimestampMS != null && d("EchoEncodingUtils").echoSetIntField(a, N, b.revokeUnsentTimestampMS);
        d("EchoMessageMediaGroupFieldUtil").echoMessageSetMediaGroupFields(a, b);
        c = b.xmaData;
        c != null && d("EchoMessageXMAFieldUtils").echoMessageSetXMAFields(a, c);
        ((c = b.editHistory) == null ? void 0 : c.length) > 0 && (d("EchoEncodingUtils").echoSetIntField(a, O, b.editCount), b.editHistory.forEach(function(b) {
            var c = b.messageId;
            c != null && (d("EchoEncodingUtils").echoSetStringField(a, P + c, b.text), d("EchoEncodingUtils").echoSetIntField(a, Q + c, b.timestamp * 1e3))
        }));
        b.receiverFetchId != null && d("EchoEncodingUtils").echoSetStringField(a, T, b.receiverFetchId)
    }
    g.ECHO_SERIALIZATION_ORIGIN = L;
    g.ECHO_MESSAGE_FIELD_NAME_EDIT_COUNT = O;
    g.ECHO_MESSAGE_FIELD_NAME_EDIT_CONTENT_PREFIX = P;
    g.ECHO_MESSAGE_FIELD_NAME_EDIT_TS_PREFIX = Q;
    g.ECHO_MESSAGE_FIELD_GROUP_ID = f;
    g.ECHO_MESSAGE_FIELD_GROUP_INDEX = R;
    g.ECHO_MESSAGE_FIELD_GROUP_SIZE = S;
    g.ECHO_MESSAGE_FIELD_RECEIVER_FETCH_ID = T;
    g.ECHO_MESSAGE_FIELD_NAME_EPHEMERALITY_TYPE = U;
    g.ECHO_MESSAGE_MIGRATION_DOCUMENT_VERSION = V;
    g.MessageTextSize = W;
    g.EchoMessageContentSubtype = X;
    g.EchoMessageContentType = Y;
    g.EchoXMessageContentType = aa;
    g.EchoMessagePlaceholderType = Z;
    g.EchoSerializationOriginType = $;
    g.encodeEchoMessage = a;
    g.decodeEchoMessage = e
}), 98);
__d("EchoMessageMediaFieldUtils", ["$InternalEnum", "EchoDecodingUtils", "EchoEncodingUtils", "EchoMessage", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing media fields for receiver fetch"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Invalid media attachment type: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] multi blob media message: can not parse objects ids. ", " msgType: ", " mediaType: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing enum fields from media fields: attachmentType: ", " mediaPreviewContentType: ", " mediaAttachmentType: ", " EchoOrigin: ", " xOfflineThreadingId: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing ", " from media fields. AttachmentType: ", " EchoOrigin: ", " xOfflineThreadingId: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing ", " from media fields. AttachmentType: ", " EchoOrigin: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing ", " from media fields. xAttachmentType: ", ", AttachmentType: ", ". EchoOrigin: ", " xOfflineThreadingId: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Unable to get primary and secondary attachment object ids"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] multi blob media message: primary attachment object id is null. msgType: ", " mediaType: ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing xAttachmentType field from required media metadata fields, msgId: ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing xContentType field from required media metadata fields, msgId: ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing plaintextHash field from required media metadata fields, msgId: ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing direct path field from required media metadata fields, msgId: ", ""]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing attachment type from required media metadata fields, msgId: ", ""]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing attachment object id from required media metadata fields, msgId: ", ""]);
        v = function() {
            return a
        };
        return a
    }
    var w = "X-Object-Id",
        x = "X-Attachment-Object-Ids",
        y = "Attachment-Type",
        z = "Content-Type",
        A = "X-Encrypted-Hash",
        B = "X-Attachment-Type",
        C = "X-Backup-Ent-Fbid",
        D = "X-Backup-Status",
        E = "X-Content-Type",
        F = "X-Direct-Path",
        G = "Height",
        H = "X-Media-Key",
        I = "X-Media-Key-Timestamp",
        J = "Playable-Duration",
        K = "Preview-Height",
        L = "Preview-Content-Type",
        M = "Preview-Width",
        N = "Size",
        O = "Width",
        P = "X-Plaintext-Hash",
        Q = "File-Name",
        R = "Header-Attribution-Content-Type",
        S = (f = b("$InternalEnum"))({
            IMAGE: "image",
            STICKER: "sticker",
            VIDEO: "video",
            GIF: "animated_image",
            PTT: "audio",
            XMA: "xma",
            DOCUMENT: "document"
        }),
        T = f({
            IMAGE_JPEG: "image/jpeg",
            IMAGE_PNG: "image/png",
            STICKER: "image/webp",
            GIF: "image/gif",
            AUDIO_MP4: "audio/mp4",
            AUDIO_WAV: "audio/wav",
            XMA: "xma"
        }),
        U = f({
            INVALID: "-1",
            IMAGE: "0",
            PTT: "1",
            AUDIO: "2",
            DOCUMENT: "3",
            VIDEO: "4",
            GIF: "5",
            STICKER: "6",
            PROFILE_PICTURE: "7",
            APP_STATE: "8",
            HISTORY_SYNC: "9",
            THUMBNAIL_IMAGE: "10",
            THUMBNAIL_VIDEO: "11",
            THUMBNAIL_GIF: "12",
            THUMBNAIL_DOCUMENT: "13",
            THUMBNAIL_LINK: "14",
            NOVI_IMAGE: "15",
            NOVI_VIDEO: "16",
            KYCID: "17",
            WAFFLE_IMAGE: "18",
            WAFFLE_VIDEO: "19",
            WAFFLE_GIF: "20",
            PAYMENT_BG_IMAGE: "21",
            XMA_IMAGE: "22",
            PAYMENT_BR_DOCUMENT: "23",
            BIZ_COVER_PHOTO: "24",
            MESSENGER_PREVIEW: "25"
        }),
        V = f({
            FULL: "full",
            PREVIEW: "preview"
        });

    function W(a, b) {
        var c = a.attachmentObjectId,
            e = a.attachmentType,
            f = a.backupEntFbid,
            g = a.directPath,
            h = a.filename,
            i = a.encryptedHash,
            j = a.height,
            k = a.mediaBackupStatus,
            l = a.mediaContentType,
            m = a.mediaKey,
            n = a.mediaKeyTimestamp,
            o = a.mediaPlayableDuration,
            p = a.plaintextHash,
            w = a.previewContentHeight,
            x = a.previewContentType,
            y = a.previewContentWidth,
            z = a.size,
            A = a.width,
            B = a.xAttachmentType,
            C = a.xContentType;
        a = a.xmaData;
        if (c == null) d("WALogger").ERROR(v(), b);
        else if (e == null) d("WALogger").ERROR(u(), b);
        else if (g == null) d("WALogger").ERROR(t(), b);
        else if (p == null) d("WALogger").ERROR(s(), b);
        else if (C == null) d("WALogger").ERROR(r(), b);
        else if (B == null) d("WALogger").ERROR(q(), b);
        else return {
            attachmentObjectId: c,
            attachmentType: e,
            backupEntFbid: f,
            directPath: g,
            encryptedHash: i,
            filename: h,
            height: j,
            mediaBackupStatus: k,
            mediaContentType: l,
            mediaKey: m,
            mediaKeyTimestamp: n,
            mediaPlayableDuration: o,
            plaintextHash: p,
            previewContentHeight: w,
            previewContentType: x,
            previewContentWidth: y,
            size: z,
            width: A,
            xAttachmentType: B,
            xContentType: C,
            xmaData: a
        }
    }

    function a(a, b) {
        var c;
        (c = d("EchoEncodingUtils")).echoSetStringField(a, w, b.attachmentObjectId);
        c.echoSetStringField(a, y, b.attachmentType);
        c.echoSetStringField(a, P, b.plaintextHash);
        c.echoSetStringField(a, A, b.encryptedHash);
        c.echoSetIntField(a, N, b.size);
        c.echoSetStringField(a, H, b.mediaKey);
        c.echoSetIntField(a, I, b.mediaKeyTimestamp);
        c.echoSetStringField(a, F, b.directPath);
        b.mediaContentType != null && d("EchoEncodingUtils").echoSetStringField(a, z, b.mediaContentType);
        d("EchoEncodingUtils").echoSetIntField(a, O, b.width);
        d("EchoEncodingUtils").echoSetIntField(a, G, b.height);
        b.previewContentType != null && d("EchoEncodingUtils").echoSetStringField(a, L, b.previewContentType);
        b.headerAttributionContentType != null && d("EchoEncodingUtils").echoSetStringField(a, R, b.headerAttributionContentType);
        d("EchoEncodingUtils").echoSetIntField(a, M, b.previewContentWidth);
        d("EchoEncodingUtils").echoSetIntField(a, K, b.previewContentHeight);
        d("EchoEncodingUtils").echoSetIntField(a, J, b.mediaPlayableDuration);
        b.xAttachmentType != null && d("EchoEncodingUtils").echoSetStringField(a, B, b.xAttachmentType);
        d("EchoEncodingUtils").echoSetStringField(a, E, b.xContentType);
        d("EchoEncodingUtils").echoSetStringField(a, C, b.backupEntFbid);
        d("EchoEncodingUtils").echoSetStringField(a, D, b.mediaBackupStatus);
        d("EchoEncodingUtils").echoSetStringField(a, Q, b.filename)
    }

    function c(a, b, c) {
        var e = {},
            f = !1,
            g = !1,
            h = !1;
        if (ba(a)) {
            var i = $(a, b, c);
            if (i == null) {
                d("WALogger").ERROR(p(), b, c);
                return null
            }
            i.length !== 2 && d("WALogger").ERROR(o());
            c = !1;
            var j = !1,
                k = i[0];
            i = i[1];
            var l = {};
            f = Z(a, e, k);
            c = Z(a, l, i);
            g = Y(a, e, b, k, k);
            j = Y(a, l, b, i, k);
            h = X(a, e, k);
            k = X(a, l, i);
            if (!f || !g || !h || !c || !j || !k) return null;
            i = d("EchoDecodingUtils").echoDecodeStringField(a, "X-Offline-Threading-ID").result;
            c = W(e, i);
            j = W(l, i);
            if (c != null && j != null) return [c, j]
        } else {
            f = Z(a, e);
            g = Y(a, e, b);
            h = X(a, e);
            if (!f || !g || !h) return null;
            k = W(e);
            if (k != null) return [k]
        }
        return null
    }

    function X(a, b, c) {
        var e, f = d("EchoDecodingUtils").echoDecodeStringField(a, "X-Offline-Threading-ID").result;
        e = (e = a.get(d("EchoMessage").ECHO_SERIALIZATION_ORIGIN)) != null ? e : "";
        c = [{
            fieldName: "height",
            id: G
        }, {
            fieldName: "width",
            id: O
        }, {
            fieldName: "size",
            id: N
        }, {
            fieldName: "previewContentHeight",
            id: K
        }, {
            fieldName: "previewContentWidth",
            id: M
        }, {
            fieldName: "mediaKeyTimestamp",
            id: c != null ? c + "-" + I : I
        }];
        var g = [{
            attachmentTypes: [U.VIDEO, U.AUDIO],
            fieldName: "mediaPlayableDuration",
            id: J
        }];
        for (var h = 0; h < g.length; h++) {
            var i = g[h],
                j = i.attachmentTypes,
                k = i.fieldName;
            i = i.id;
            i = d("EchoDecodingUtils").echoDecodeIntField(a, i);
            var l = i.result;
            i = i.success;
            if (i && l != null) b[k] = l;
            else if (!(b.xAttachmentType != null && !aa(j, b.xAttachmentType) || b.attachmentType === S.XMA)) {
                d("WALogger").ERROR(n(), k, b.xAttachmentType, b.attachmentType, e, f);
                return !1
            }
        }
        c.map(function(f) {
            var c = f.fieldName;
            f = f.id;
            f = d("EchoDecodingUtils").echoDecodeIntField(a, f);
            var e = f.result;
            f = f.success;
            f && e != null && (b[c] = e)
        });
        return !0
    }

    function Y(a, b, c, e, f) {
        var g, h = d("EchoDecodingUtils").echoDecodeStringField(a, "X-Offline-Threading-ID").result,
            i, j;
        g = (g = a.get(d("EchoMessage").ECHO_SERIALIZATION_ORIGIN)) != null ? g : "";
        var k = [{
            fieldName: "filename",
            id: Q
        }];
        e != null && f != null ? (b.attachmentObjectId = e, i = [{
            fieldName: "plaintextHash",
            id: e + "-" + P
        }, {
            fieldName: "directPath",
            id: e + "-" + F
        }, {
            fieldName: "xContentType",
            id: e + "-" + E
        }], k.push({
            fieldName: "mediaKey",
            id: e + "-" + H
        }), j = f + "-" + C, e = e + "-" + A) : (i = [{
            fieldName: "attachmentObjectId",
            id: w
        }, {
            fieldName: "plaintextHash",
            id: P
        }, {
            fieldName: "directPath",
            id: F
        }, {
            fieldName: "xContentType",
            id: E
        }], k.push({
            fieldName: "mediaKey",
            id: H
        }), j = C, e = A);
        k.push({
            fieldName: "backupEntFbid",
            id: j
        });
        k.push({
            fieldName: "mediaContentType",
            id: z
        });
        k.push({
            fieldName: "encryptedHash",
            id: e
        });
        j = f != null ? f + "-" + D : D;
        k.push({
            fieldName: "mediaBackupStatus",
            id: j
        });
        e = [];
        for (f = i, j = Array.isArray(f), i = 0, f = j ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var n;
            if (j) {
                if (i >= f.length) break;
                n = f[i++]
            } else {
                i = f.next();
                if (i.done) break;
                n = i.value
            }
            n = n;
            var o = n.fieldName;
            n = n.id;
            n = d("EchoDecodingUtils").echoDecodeStringField(a, n);
            var p = n.result;
            n = n.success;
            n && p != null ? b[o] = p : e.push(o)
        }
        if (e.length > 0) {
            n = e.join(", ");
            c === d("EchoMessage").EchoMessageContentType.XMA ? d("WALogger").WARN(m(), n, b.attachmentType, g) : d("WALogger").ERROR(l(), n, b.attachmentType, g, h);
            return !1
        }
        k.map(function(f) {
            var c = f.fieldName;
            f = f.id;
            f = d("EchoDecodingUtils").echoDecodeStringField(a, f);
            var e = f.result;
            f = f.success;
            f && e != null && (b[c] = e)
        });
        return !0
    }

    function Z(a, b, c) {
        var e, f = d("EchoDecodingUtils").echoDecodeStringField(a, "X-Offline-Threading-ID").result;
        e = (e = a.get(d("EchoMessage").ECHO_SERIALIZATION_ORIGIN)) != null ? e : "";
        var g = d("EchoDecodingUtils").echoDecodeStringField(a, y);
        g = g.result === "file" ? S.DOCUMENT : S.cast(g.result);
        g != null && (b.attachmentType = g);
        var h = d("EchoDecodingUtils").echoDecodeStringField(a, L);
        h = T.cast(h.result);
        h != null && (b.previewContentType = h);
        var i = d("EchoDecodingUtils").echoDecodeStringField(a, R);
        i = i.result;
        i != null && (b.headerAttributionContentType = i);
        i = d("EchoDecodingUtils").echoDecodeStringField(a, c != null ? c + "-" + B : B);
        i.success && i.result != null && (a = ca(i.result), a != null && (b.xAttachmentType = a));
        if (g != null && (h != null || g === S.DOCUMENT || g === S.PTT)) return !0;
        else d("WALogger").ERROR(k(), g, h, i, e, f);
        return !1
    }

    function aa(a, b) {
        return a.reduce(function(a, c) {
            return a || c === b
        }, !1)
    }

    function ba(a) {
        return a.has(x)
    }

    function $(a, b, c) {
        var e = d("EchoDecodingUtils").echoDecodeObjectIdListField(a, x),
            f = e.result;
        e = e.success;
        if (!e || f == null || f.length !== 2) {
            d("WALogger").ERROR(j(), f, b, c);
            return null
        }
        e = f.find(function(b) {
            b = b + "-" + D;
            b = d("EchoDecodingUtils").echoDecodeStringField(a, b);
            var c = b.result;
            b = b.success;
            if (b && c != null) return !0
        });
        if (e != null) {
            b = e === f[0] ? f[1] : f[0];
            return [e, b]
        }
        e = f.find(function(b) {
            b = b + "-" + E;
            b = d("EchoDecodingUtils").echoDecodeStringField(a, b);
            var c = b.result;
            b = b.success;
            if (b && c != null && V.cast(c) === V.FULL) return !0
        });
        if (e != null) {
            c = e === f[0] ? f[1] : f[0];
            return [e, c]
        }
        return f
    }

    function ca(a) {
        var b = U.cast(a);
        b == null && d("WALogger").ERROR(i(), a);
        return (a = b) != null ? a : U.INVALID
    }

    function e(a) {
        var b = {};
        b = Z(a, b);
        if (!b) return null;
        b = d("EchoDecodingUtils").echoDecodeStringField(a, z);
        var c = d("EchoDecodingUtils").echoDecodeIntField(a, G),
            e = d("EchoDecodingUtils").echoDecodeIntField(a, O);
        a = d("EchoDecodingUtils").echoDecodeStringField(a, y);
        if (!b.success || !c.success || !e.success || !a.success || b.result == null || c.result == null || e.result == null || a.result == null) {
            d("WALogger").ERROR(h());
            return null
        }
        return {
            mimetype: b.result,
            previewHeight: c.result,
            previewWidth: e.result,
            type: a.result
        }
    }
    g.ECHO_MESSAGE_FIELD_NAME_ATTACHMENT_OBJECT_ID = w;
    g.ECHO_MESSAGE_FIELD_NAME_ATTACHMENT_OBJECT_IDS = x;
    g.ECHO_MESSAGE_FIELD_NAME_ATTACHMENT_TYPE = y;
    g.AttachmentType = S;
    g.EchoMessageMediaPreviewType = T;
    g.EchoMessageActMediaAttachmentType = U;
    g.convertMediaMetadataDetailsToMediaMetadata = W;
    g.echoMessageSetMediaMetadataFields = a;
    g.echoMessageDecodeMediaDataFields = c;
    g.setMediaIntFields = X;
    g.setMediaEnumFields = Z;
    g.getAttachmentObjectIdsFromMultiBlobMediaMsg = $;
    g.decodeReceiverFetchData = e
}), 98);
__d("EchoMessageMediaGroupFieldUtil", ["EchoDecodingUtils", "EchoEncodingUtils", "EchoMessage"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b.groupId != null && d("EchoEncodingUtils").echoSetStringField(a, d("EchoMessage").ECHO_MESSAGE_FIELD_GROUP_ID, b.groupId), b.groupIndex != null && d("EchoEncodingUtils").echoSetIntField(a, d("EchoMessage").ECHO_MESSAGE_FIELD_GROUP_INDEX, b.groupIndex), b.groupSize != null && d("EchoEncodingUtils").echoSetIntField(a, d("EchoMessage").ECHO_MESSAGE_FIELD_GROUP_SIZE, b.groupSize)
    }

    function b(a, b) {
        var c = d("EchoDecodingUtils").echoDecodeStringField(a, d("EchoMessage").ECHO_MESSAGE_FIELD_GROUP_ID);
        c.success && c.result != null && (b.groupId = c.result);
        c = d("EchoDecodingUtils").echoDecodeIntField(a, d("EchoMessage").ECHO_MESSAGE_FIELD_GROUP_INDEX);
        c.success && c.result != null && (b.groupIndex = c.result);
        c = d("EchoDecodingUtils").echoDecodeIntField(a, d("EchoMessage").ECHO_MESSAGE_FIELD_GROUP_SIZE);
        c.success && c.result != null && (b.groupSize = c.result)
    }
    g.echoMessageSetMediaGroupFields = a;
    g.decodeMessageMediaGroupFields = b
}), 98);
__d("EchoMessageQuoteFieldUtils", ["$InternalEnum", "EchoDecodingUtils", "EchoEncodingUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "Reply-Message-Id",
        i = "Reply-Message-Sender",
        j = "Reply-Sort-Order",
        k = "Reply-Type",
        l = "Reply-Status",
        m = b("$InternalEnum").Mirrored(["BUMP"]),
        n = b("$InternalEnum")({
            VALID: "valid"
        });

    function a(a) {
        var b = {
                quoteMessageId: "<not set>",
                quoteMessageSender: {
                    localKey: "<not set>",
                    transportKey: "<not set>"
                },
                quoteSortOrderInMs: 0
            },
            c = o(a, b),
            d = p(a, b),
            e = q(a, b);
        a = r(a, b);
        return !c || !d || !e || !a ? null : b
    }

    function c(a, b) {
        b = b.quoteData;
        if (b == null) return;
        d("EchoEncodingUtils").echoSetStringField(a, h, b.quoteMessageId);
        d("EchoEncodingUtils").echoSetAddressField(a, i, b.quoteMessageSender);
        d("EchoEncodingUtils").echoSetIntField(a, j, b.quoteSortOrderInMs);
        b.status != null && d("EchoEncodingUtils").echoSetStringField(a, l, b.status);
        b.replyType != null && d("EchoEncodingUtils").echoSetStringField(a, k, b.replyType)
    }

    function o(a, b) {
        var c = [{
            fieldName: "quoteMessageSender",
            id: i
        }];
        for (var e = 0; e < c.length; e++) {
            var f = c[e],
                g = f.fieldName;
            f = f.id;
            f = d("EchoDecodingUtils").echoDecodeAddressField(a, f);
            var h = f.result;
            f = f.success;
            if (f && h != null) b[g] = h;
            else return !1
        }
        return !0
    }

    function p(a, b) {
        var c = [{
            fieldName: "quoteMessageId",
            id: h
        }];
        for (var e = 0; e < c.length; e++) {
            var f = c[e],
                g = f.fieldName;
            f = f.id;
            f = d("EchoDecodingUtils").echoDecodeStringField(a, f);
            var i = f.result;
            f = f.success;
            if (f && i != null) b[g] = i;
            else return !1
        }
        return !0
    }

    function q(a, b) {
        var c = [{
            fieldName: "quoteSortOrderInMs",
            id: j
        }];
        for (var e = 0; e < c.length; e++) {
            var f = c[e],
                g = f.fieldName;
            f = f.id;
            f = d("EchoDecodingUtils").echoDecodeIntField(a, f);
            var h = f.result;
            f = f.success;
            if (f && h != null) b[g] = h;
            else return !1
        }
        return !0
    }

    function r(a, b) {
        var c = d("EchoDecodingUtils").echoDecodeStringField(a, k);
        c = m.cast(c.result);
        c != null && (b.replyType = c);
        c = d("EchoDecodingUtils").echoDecodeStringField(a, l);
        a = n.cast(c.result);
        a != null && (b.status = a);
        return !0
    }
    g.EchoMessageQuoteReplyType = m;
    g.EchoMessageQuoteStatus = n;
    g.echoMessageDecodeQuoteFields = a;
    g.echoMessageSetQuoteFields = c
}), 98);
__d("EchoMessageReceiptStatusFieldUtils", ["$InternalEnum", "EchoCommonUtils", "EchoDecodingUtils", "EchoEncodingUtils", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Error occurred while decoding participants from echo doc, error: ", ""]);
        h = function() {
            return a
        };
        return a
    }
    var i = "Receipt-Status",
        j = "Receipt-Timestamp",
        k = b("$InternalEnum")({
            UNKNOWN: "unknown",
            SENDING: "sending",
            SERVER_RECEIVED: "server_received",
            DELIVERED: "delivered",
            READ: "read",
            ERROR: "error",
            NON_RETRYABLE_ERROR: "non_retryable_error"
        });

    function a(a, b) {
        if (b == null || b.length === 0) return;
        b.forEach(function(b) {
            d("EchoEncodingUtils").echoSetStringField(a, d("EchoCommonUtils").getEchoAddressFieldNameWithSuffix(b.address, i), b.status), b.timestampMs != null && d("EchoEncodingUtils").echoSetIntField(a, d("EchoCommonUtils").getEchoAddressFieldNameWithSuffix(b.address, j), b.timestampMs)
        })
    }

    function c(a) {
        var b = [];
        l(a).forEach(function(c) {
            var e = d("EchoCommonUtils").getEchoAddressFieldNameWithSuffix(c, i);
            e = d("EchoDecodingUtils").echoDecodeStringField(a, e);
            if (e.success) {
                e = (e = k.cast(e.result)) != null ? e : k.UNKNOWN;
                var f = d("EchoCommonUtils").getEchoAddressFieldNameWithSuffix(c, j);
                f = d("EchoDecodingUtils").echoDecodeNullableIntField(a, f);
                f.result != null ? b.push({
                    address: c,
                    status: e,
                    timestampMs: f.result
                }) : b.push({
                    address: c,
                    status: e
                })
            }
        });
        return b
    }

    function l(a) {
        var b = new Set();
        for (var a = a.keys(), c = Array.isArray(a), e = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (c) {
                if (e >= a.length) break;
                f = a[e++]
            } else {
                e = a.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            if (f.includes(i)) try {
                f = f.split("@");
                var g = f[0];
                f = m(f[1]);
                b.add({
                    localKey: g,
                    transportKey: f
                })
            } catch (a) {
                d("WALogger").ERROR(h(), a)
            }
        }
        return Array.from(b)
    }

    function m(a) {
        a = a.split(i);
        return a[0].split("-")[0]
    }
    g.MessageReceiptStatus = k;
    g.echoMessageSetReceiptStatusDataFields = a;
    g.echoMessageDecodeReceiptStatusDataFields = c
}), 98);
__d("EchoMessageXMAFieldUtils", ["$InternalEnum", "EchoDecodingUtils", "EchoEncodingUtils", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing ", " from xma fields"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing ", " from xma fields"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing ", " from media fields"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Missing xmaIsTombstoned from xma fields"]);
        k = function() {
            return a
        };
        return a
    }
    var l = "XMA-Default-CTA",
        m = "XMA-Gating-Type",
        n = "XMA-Header-Subtitle",
        o = "XMA-Header-Title",
        p = "XMA-Is-Tombstoned",
        q = "XMA-Layout-Type",
        r = "XMA-Max-Subtitle-Num-Lines",
        s = "XMA-Max-Title-Num-Lines",
        t = "XMA-Subtitle-Text",
        u = "XMA-Target-Expiry",
        v = "XMA-Target-ID",
        w = "XMA-Target-Type",
        x = "XMA-Target-Username",
        y = "XMA-Title-Text",
        z = "XMA-Content-Ref",
        A = b("$InternalEnum").Mirrored(["SINGLE", "HSCROLL", "VSTACK", "PORTRAIT"]),
        B = b("$InternalEnum").Mirrored(["NONE", "IG_STORY_PHOTO_MENTION", "IG_SINGLE_IMAGE_POST_SHARE", "IG_MULTIPOST_SHARE", "IG_SINGLE_VIDEO_POST_SHARE", "IG_STORY_PHOTO_SHARE", "IG_STORY_VIDEO_SHARE", "IG_CLIPS_SHARE", "IG_IGTV_SHARE", "IG_SHOP_SHARE", "IG_PROFILE_SHARE", "IG_STORY_PHOTO_HIGHLIGHT_SHARE", "IG_STORY_VIDEO_HIGHLIGHT_SHARE", "IG_STORY_REPLY", "IG_STORY_REACTION", "FB_FEED_SHARE", "FB_STORY_REPLY", "FB_STORY_SHARE", "FB_STORY_MENTION", "FB_FEED_VIDEO_SHARE", "FB_GAMING_CUSTOM_UPDATE", "FB_PRODUCER_STORY_REPLY", "MSG_EXTERNAL_LINK_SHARE", "MSG_RECEIVER_FETCH", "RTC_AUDIO_CALL", "RTC_VIDEO_CALL", "RTC_MISSED_AUDIO_CALL", "RTC_MISSED_VIDEO_CALL", "RTC_GROUP_AUDIO_CALL", "RTC_GROUP_VIDEO_CALL", "FB_EVENT", "FB_SHORT"]),
        C = b("$InternalEnum").Mirrored(["NONE", "PRIVATE", "SENSITIVE", "MISINFORMATION", "MEDIA_LABEL", "POST_COVER", "POST_LABEL", "WARNING_SCREENS", "INFO", "EYE_OFF", "NEWS_OFF", "WARNING"]);

    function a(a, b) {
        b.xmaLayoutType != null && d("EchoEncodingUtils").echoSetStringField(a, q, b.xmaLayoutType), b.xmaTargetType != null && d("EchoEncodingUtils").echoSetStringField(a, w, b.xmaTargetType), d("EchoEncodingUtils").echoSetStringField(a, x, b.xmaTargetUsername), d("EchoEncodingUtils").echoSetStringField(a, v, b.xmaTargetId), b.xmaTargetExpiry != null && d("EchoEncodingUtils").echoSetIntField(a, u, b.xmaTargetExpiry), d("EchoEncodingUtils").echoSetStringField(a, l, b.xmaDefaultCTA), d("EchoEncodingUtils").echoSetStringField(a, o, b.xmaHeaderTitle), d("EchoEncodingUtils").echoSetStringField(a, n, b.xmaHeaderSubtitle), d("EchoEncodingUtils").echoSetStringField(a, y, b.xmaTitleText), d("EchoEncodingUtils").echoSetStringField(a, t, b.xmaSubtitleText), b.xmaMaxTitleNumLines != null && d("EchoEncodingUtils").echoSetIntField(a, s, b.xmaMaxTitleNumLines), b.xmaMaxSubtitleNumLines != null && d("EchoEncodingUtils").echoSetIntField(a, r, b.xmaMaxSubtitleNumLines), b.xmaGatingType != null && d("EchoEncodingUtils").echoSetStringField(a, m, b.xmaGatingType), d("EchoEncodingUtils").echoSetBooleanField(a, p, b.xmaIsTombstoned), b.xmaContentRef != null && d("EchoEncodingUtils").echoSetStringField(a, z, b.xmaContentRef)
    }

    function c(a) {
        var b = F(a, p);
        if (b == null) {
            d("WALogger").ERROR(k());
            return null
        }
        var c = C.cast(d("EchoDecodingUtils").echoDecodeStringField(a, m).result),
            e = A.cast(d("EchoDecodingUtils").echoDecodeStringField(a, q).result),
            f = B.cast(d("EchoDecodingUtils").echoDecodeStringField(a, w).result);
        return {
            xmaContentRef: D(a, z),
            xmaDefaultCTA: D(a, l),
            xmaGatingType: c,
            xmaHeaderSubtitle: D(a, n),
            xmaHeaderTitle: D(a, o),
            xmaIsTombstoned: b,
            xmaLayoutType: e,
            xmaMaxSubtitleNumLines: E(a, r),
            xmaMaxTitleNumLines: E(a, s),
            xmaSubtitleText: D(a, t),
            xmaTargetExpiry: E(a, u),
            xmaTargetId: D(a, v),
            xmaTargetType: f,
            xmaTargetUsername: D(a, x),
            xmaTitleText: D(a, y)
        }
    }

    function D(a, b) {
        a = d("EchoDecodingUtils").echoDecodeStringField(a, b);
        var c = a.result;
        a = a.success;
        if (a && c != null) return c;
        else d("WALogger").WARN(j(), b)
    }

    function E(a, b) {
        a = d("EchoDecodingUtils").echoDecodeIntField(a, b);
        var c = a.result;
        a = a.success;
        if (a && c != null) return c;
        else d("WALogger").WARN(i(), b)
    }

    function F(a, b) {
        a = d("EchoDecodingUtils").echoDecodeBooleanField(a, b);
        var c = a.result;
        a = a.success;
        if (a && c != null) return c;
        else d("WALogger").WARN(h(), b)
    }
    g.XMALayoutType = A;
    g.XMAContentType = B;
    g.XMAGatingType = C;
    g.echoMessageSetXMAFields = a;
    g.decodeXMAFields = c
}), 98);
__d("LSEBPayloadSerializerError", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        INVALID_BACKUP_OPERATION: -7,
        INVALID_CONTENT_TYPE: -6,
        INVALID_PAYLOAD_FORMAT: -5,
        CQL_DB_ERROR: -4,
        REQUIRED_COLUMN_NOT_PRESENT_ON_CLIENT: -3,
        DEPRECATED_SPROC: -2,
        UNKNOWN_ERROR: -1,
        NOT_AN_ERROR: 0,
        BACKUP_NOT_FOUND: 1,
        REQUIRED_TABLE_NOT_FOUND: 2,
        NATIVE_OP_NOT_FOUND: 3,
        BACKUP_UPLOAD_KILLSWITCHED: 4,
        TASK_ID_NOT_FOUND: 5,
        NOT_IMPLEMENTED: 6,
        NOT_SUPPORTED_ON_WEB: 7,
        DUPLICATE_TASK: 8,
        CLIENT_STATE_NOT_LOADED: 9,
        RECOVERY_CODE_NOT_FOUND: 10,
        EPOCH_KEYS_NOT_FOUND: 11,
        DEVICE_PAYLOAD_NOT_CREATED: 12,
        NULL_DEVICE_PAYLOAD: 13,
        EPOCH_PAYLOAD_NOT_CREATED: 14,
        NULL_EPOCH_PAYLOAD: 15,
        VIRTUAL_DEVICE_PAYLOAD_NOT_CREATED: 16,
        NULL_VIRTUAL_DEVICE_PAYLOAD: 17,
        DEVICE_METADATA_NOT_FOUND: 18,
        NO_MATCHING_DEVICE_PUBLIC_KEY: 19,
        NULL_MAILBOX_ROOT_KEY: 20,
        NULL_ENCRYPTION_VERSION: 21,
        NULL_OCMF_KEY: 22,
        NULL_EPOCH_KEYS: 23,
        NULL_DEVICE_ID: 24,
        OPE_KEY_DERIVATION_FAILED: 25,
        MESSAGE_KEY_DERIVATION_FAILED: 26,
        NULL_MAILBOX_ROOT_KEY_V2: 27,
        ECHO_DOCUMENT_ENCODING_FAILED: 30,
        ECHO_PAYLOAD_CREATION_DISABLED: 31,
        MESSAGE_PAYLOAD_ENCRYPTION_FAILED: 40,
        SERVER_THREAD_ID_NOT_FOUND_FOR_JID: 52,
        UNKNOWN_PROTOBUF_TYPE: 60,
        SUPPLEMENTARY_DATA_KEY_UNEXPECTED: 61,
        PROTOBUF_ENCRYPTION_FAILED: 62,
        PROTOBUF_NOT_FOUND_IN_TOPLEVEL_TABLE: 63,
        PROTOBUF_NOT_FOUND_IN_SUPPLEMENTAL_TABLE: 64,
        SUPPLEMENTAL_KEY_NOT_SET_IN_CONTEXT_TABLE: 65,
        SUPPLEMENTAL_ENCRYPTION_FAILED: 66,
        PROTOBUF_CONTEXT_ROW_NOT_FOUND: 67,
        PROTOBUF_FORMATTING_FAILED: 68,
        SUPPLEMENTAL_FORMATTING_FAILED: 69,
        PROTOBUF_ALREADY_DELETED: 70,
        PROTOBUF_NOT_FOUND_IN_DELETED_MESSAGES_TABLE: 71,
        DELETION_PROTOBUF_IS_NULL: 72,
        THREAD_PK_NOT_FOUND_FOR_JID: 100,
        MESSAGE_DECRYPTION_FAILED: 101,
        EPOCH_KEY_FETCH_FAILED: 102,
        TOO_MANY_OPEN_EPOCHS: 103,
        MESSAGE_RANGE_PREPARE_FAILURE: 104,
        ECHO_DOCUMENT_RESTORE_FAILED: 105,
        MISMATCH_POINT_QUERY_MESSAGE_AND_RANGE_LENGTH: 106,
        INITIAL_THREADS_FETCH_FOR_RESTORE_FAILED: 107,
        MISSING_SUPPLEMENTAL_KEY_CIPHERTEXT: 108,
        SUPPLEMENTAL_KEY_DECRYPTION_FAILURE: 109,
        DEVICE_ID_MISMATCH: 110,
        RESTORE_TO_TAM_INFO: 111,
        MISSING_SERVER_THREAD_KEY: 112,
        EB_ADD_DEVICE_FOUND_NO_LOCAL_THREADS: 113,
        EB_MORE_THREADS_IN_MAPPING_TABLE: 114,
        RESTORE_INTEGRITY_CHECK_FAILED: 115,
        MESSAGE_PK_NOT_FOUND_IN_CLIENT_MESSAGES: 200,
        OTID_NOT_FOUND_IN_ACT_MESSAGES: 201,
        THREAD_ID_NOT_FOUND_IN_ACT_THREADS: 202,
        THREAD_PK_NOT_FOUND_IN_CLIENT_THREADS: 203,
        FAILED_TO_GET_THREAD_SORT_KEY: 204,
        MEDIA_INFO_INVALID: 205,
        REVERB_DB_NOT_ENABLED_FOR_INSTAMADILLO: 206,
        SKIPPED_EB_DISABLED: 300,
        SKIPPED_THREAD_NOT_ELIGIBLE: 301,
        SKIPPED_MESSAGE_NOT_ELIGIBLE: 302,
        NO_EPOCHS_FOUND: 400,
        LATEST_EPOCH_QUERY_BY_ID_FAILED: 401,
        FOUND_EPOCH_WITH_NULL_ROOT_KEY: 402,
        FOUND_EPOCH_WITH_NULL_ANON_ID: 403,
        NO_RECOVERY_CODE: 501,
        NO_ERROR: 601,
        ERROR_GENERAL: 602,
        UNKNOWN: 603,
        ONBOARDING_MATERIAL_DERIVATION_FAILURE: 604,
        NULL_DEVICE_HMAC: 605,
        MISSING_LATEST_EPOCH_AT_ONBOARDING: 606,
        NO_THREADS_TO_COMPARE: 701,
        START_SORT_KEY_FAILURE: 702,
        END_SORT_KEY_FAILURE: 703,
        LOOPING_UPLOAD_PAYLOAD_NOT_FOUND: 704,
        NULL_ECHO_IDENTIFIERS: 705,
        ECHO_TIMESTAMP_CONVERSION_FAILED: 706,
        ECHO_PROTOBUF_THREAD_ID_MISMATCH: 707,
        ECHO_PROTOBUF_TIMESTAMP_MISMATCH: 708,
        ECHO_PROTOBUF_OTID_MISMATCH: 709,
        NULL_ECHO_DOCUMENT: 710,
        INVALID_PROTOBUF_BACKUP_ACTION: 711,
        EMPTY_ENCODED_ECHO_DOCUMENT: 712,
        ECHO_DOCUMENT_ENCODING_UNKNOWN_ENCODING_ERROR: 750,
        ECHO_DOCUMENT_ENCODING_MESSAGE_PK_NOT_FOUND_ERROR: 751,
        ECHO_DOCUMENT_ENCODING_DISK_WRITE_CHECK_FAILED: 752,
        ECHO_DOCUMENT_ENCODING_THREAD_TRANSPORT_ID_FETCH_FAILED: 753,
        ECHO_DOCUMENT_ENCODING_FILE_WRITE_FAILED: 754,
        ECHO_DOCUMENT_ENCODING_DISK_WRITE_DISABLED: 755,
        ECHO_DOCUMENT_ENCODING_SHOULD_NOT_PERSIST: 756,
        MISSING_SUPPLEMENTAL_DATA: 757,
        ECHO_DOCUMENT_ENCODING_MESSAGE_FIELDS_REPLY_PROXY_ERROR: 758,
        ECHO_DOCUMENT_ENCODING_MESSAGE_FIELDS_EDIT_MESSAGE_QUERY_ERROR: 759,
        ECHO_DOCUMENT_ENCODING_MESSAGE_FIELDS_EDIT_MESSAGE_ERROR: 760,
        ECHO_DOCUMENT_ENCODING_MESSAGE_FIELDS_RECEIPTS_ERROR: 761,
        ECHO_DOCUMENT_ENCODING_MESSAGE_FIELDS_REACTIONS_ERROR: 762,
        ECHO_DOCUMENT_ENCODING_MESSAGE_FIELDS_VISUAL_MESSAGE_ACTIONS_ERROR: 763,
        ECHO_DOCUMENT_ENCODING_MESSAGE_FIELDS_POLLS_ERROR: 764
    });
    f["default"] = a
}), 66);
__d("EncryptedBackupsAttachmentProductType", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        MSGR: "msgr",
        IGD: "igd"
    });
    c = a;
    f["default"] = c
}), 66);
__d("MAWBridgeUpload", ["MAWMainTraceUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.actionType,
            c = a.attachmentContext,
            d = a.attachmentContextArray,
            e = a.authTs,
            f = a.echoDocument,
            g = a.echoEncodingLatencyNs,
            i = a.errorCode,
            j = a.errorMessage,
            k = a.messageId,
            l = a.messageType,
            m = a.productType,
            n = a.protoMsg,
            o = a.sortOrderMs,
            p = a.threadId,
            q = a.traceId;
        a = a.uploadTrackingInstanceKey;
        c = h(c, m != null ? m : "msgr", d);
        return {
            actionType: b,
            attachmentBackupContext: c,
            authTs: e,
            echoDocument: f,
            echoEncodingLatencyNs: g,
            errorCode: i,
            errorMessage: j,
            messageId: k,
            messageType: l,
            protoMsg: n,
            sortOrderMs: o,
            threadId: p,
            traceId: q,
            uploadTrackingInstanceKey: a
        }
    }

    function b(a, b, c, d, e, f) {
        return {
            actionType: f,
            echoDocument: e,
            folderType: b,
            threadId: a,
            transportKey: c,
            ts: d
        }
    }

    function c(a, b, c, d, e, f, g, h) {
        return {
            deliveryObjectId: a,
            mediaType: b,
            messageId: c,
            productType: d,
            threadId: e,
            threadJid: f,
            traceId: h,
            ts: g
        }
    }

    function h(a, b, c) {
        if (c == null) return void 0;
        else {
            a = c.map(function(a) {
                return {
                    attachmentTraceId: d("MAWMainTraceUtils").createTraceId(),
                    mediaType: a.mediaType,
                    zippyObjectId: a.mediaObjectId
                }
            });
            c = {
                attachmentInfos: a,
                productType: b
            };
            return c
        }
    }
    g.createBridgeUploadMessage = a;
    g.createBridgeDeleteMessagesOfThread = b;
    g.createBridgeUploadAttachment = c;
    g.createBridgeUploadAttachmentBackupContext = h
}), 98);
__d("MAWUploadThreadTxns", ["$InternalEnum", "MAWFolderTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = b("$InternalEnum")({
        INBOX: 0,
        PENDING: 1,
        OTHER: 2,
        SPAM: 3,
        ARCHIVED: 4,
        HIDDEN: 5
    });

    function i(a) {
        switch (a) {
            case d("MAWFolderTypes").FOLDER_ID.INBOX:
                return h.INBOX;
            case d("MAWFolderTypes").FOLDER_ID.PENDING:
                return h.PENDING;
            case d("MAWFolderTypes").FOLDER_ID.ARCHIVED:
                return h.ARCHIVED;
            default:
                return h.INBOX
        }
    }

    function a(a) {
        return i(a).toString()
    }
    g.FolderType = h;
    g.getFolderTypeAsText = a
}), 98);
__d("MAWBridgeEventTransmitter", ["MAWBridge", "MAWBridgeMsg", "MAWBridgeTrace", "MAWBridgeTypesCreators", "MAWBridgeUpload", "MAWIndexedDb", "MAWUploadThreadTxns", "WAJids", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c, e, f) {
        d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
            events: [{
                tag: "IssuePointQuery",
                value: {
                    jid: f,
                    messageId: a,
                    startSortKey: c,
                    taskSource: e,
                    threadId: b
                }
            }]
        })
    }

    function b(a, b) {
        d("MAWIndexedDb").afterTransaction({
            tag: "DeleteMessagesOfThread",
            value: d("MAWBridgeUpload").createBridgeDeleteMessagesOfThread(d("WAJids").threadIdForChatJid(a.jid), d("MAWUploadThreadTxns").getFolderTypeAsText(a.folder), "AdvancedCrypto", (a = b) != null ? a : d("WATimeUtils").castToMillisTime(1), null, 2)
        })
    }

    function c(a, b, c, e, f) {
        d("MAWIndexedDb").afterTransaction({
            tag: "MsgsLoaded",
            value: d("MAWBridgeTypesCreators").createBridgeMsgsLoadedInfo(a, b, c, e, f)
        })
    }

    function e(a, b, c) {
        d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
            events: [{
                tag: "StartTrace",
                value: d("MAWBridgeTrace").createBridgeStartTraceData(a, b, c)
            }]
        })
    }

    function f(a, b) {
        (b == null ? void 0 : b.get(a.externalId)) != null ? d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
            events: [{
                tag: "NewMsg",
                value: d("MAWBridgeMsg").createBridgeMsg(a, b.get(a.externalId), void 0, "EncryptedBackups")
            }]
        }) : d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
            events: [{
                tag: "NewMsg",
                value: d("MAWBridgeMsg").createBridgeMsg(a, void 0, void 0, "EncryptedBackups")
            }]
        })
    }

    function h(a, b, c) {
        d("MAWBridge").getBridge().fireAndForget("event", "uiUpdate", {
            events: [{
                tag: "ThreadUpdated",
                value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                    cannotReplyReason: a,
                    folder: b,
                    threadJid: c
                })
            }]
        })
    }

    function i(a, b, c) {
        d("MAWIndexedDb").afterTransaction({
            tag: "DeleteMessageRangesV2",
            value: {
                minMsgId: a,
                minTimestampMs: b,
                threadJid: c
            }
        })
    }
    g.issuePointQueryOutsideTxn = a;
    g.deleteMessagesOfThreadAfterTxn = b;
    g.issueMsgLoadedEventAfterTxn = c;
    g.startTraceOutsideTxn = e;
    g.issueNewMsgUiEventOutsideTxn = f;
    g.updateThreadOutsideTxn = h;
    g.deleteMessageRangesV2AfterTxn = i
}), 98);
__d("MAWBridgeReceiverFetchInfo", ["WALogger", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to cast previewUrlExpirationTimestampMs to millis time: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c = b.mimetype,
            d = b.previewHeight,
            e = b.previewUrl,
            f = b.previewUrlExpirationTimestampMs,
            g = b.previewWidth,
            h = b.receiverFetchId;
        b = b.type;
        return {
            mimetype: c,
            msgId: a.msgId,
            previewHeight: d,
            previewUrl: e,
            previewUrlExpirationTimestampMs: j(f),
            previewWidth: g,
            receiverFetchId: h,
            sortOrderMs: i(a),
            threadJid: a.threadJid,
            type: b
        }
    }

    function b(a, b) {
        var c = b.mimetype,
            d = b.previewHeight,
            e = b.previewWidth,
            f = b.receiverFetchId;
        b = b.type;
        return {
            mimetype: c,
            msgId: a.msgId,
            previewHeight: d,
            previewWidth: e,
            receiverFetchId: f,
            sortOrderMs: i(a),
            threadJid: a.threadJid,
            type: b
        }
    }

    function i(a) {
        return d("WATimeUtils").castToMillisTime(a.sortOrderMs != null ? a.sortOrderMs : a.ts * 1e3)
    }

    function j(a) {
        if (a == null) return void 0;
        try {
            return d("WATimeUtils").castLongIntToMillisTime(a)
        } catch (a) {
            d("WALogger").ERROR(h(), a);
            return void 0
        }
    }
    g.createBridgeReceiverFetchInfoPayloadFromDbInfo = a;
    g.createBridgeReceiverFetchInfoPayloadFromUnstoredInfo = b
}), 98);
__d("MAWDbChunkTxns", ["MAWMediaUtils", "MAWODSProxy", "WAErrorMessage", "WAOdsEnums", "WATagsLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to add chunk. Possible duplicate? Will attempt a retry. For hashedPlaintextHash: ", ". Error: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to add chunk after retry. Error: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to add chunk for hashedPlaintextHash: ", ". Error: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Chunk found after retry for hashedPlaintextHash: ", ""]);
        k = function() {
            return a
        };
        return a
    }
    var l = d("WATagsLogger").TAGS(["MAWDbChunkTxns"]);
    b = function a(b, c, e, f, g) {
        g === void 0 && (g = 0);
        var m = d("MAWMediaUtils").genHMACPlaintextHash(c);
        return b.chunk.where("hashedPlaintextHash").equals(m).first().then(function(n) {
            if (n) {
                g > 0 && l.LOG(k(), m);
                return n
            } else {
                var o = {
                    blobData: e,
                    hashedPlaintextHash: m,
                    mimetype: f,
                    plaintextHash: c
                };
                return b.chunk.add(o).then(function(a) {
                    return babelHelpers["extends"]({}, o, {
                        chunkId: a
                    })
                })["catch"](function(k) {
                    var n = d("WAErrorMessage").maybeGetMessageFromError(k);
                    if (g > 0) {
                        l.WARN(j(), m, n);
                        l.ERROR(i(), n);
                        throw k
                    } else {
                        l.WARN(h(), m, n);
                        d("MAWODSProxy").odsBumpEntityKey({
                            amount: 1,
                            entity: d("WAOdsEnums").Entity.MAW_MEDIA_DB_DUPLICATE_CHUNK,
                            key: "retry"
                        });
                        return a(b, c, e, f, g + 1)
                    }
                })
            }
        })
    };
    var m = function(a, b) {
        return a.chunk.where("hashedPlaintextHash").equals(b)
    };
    c = function(a, b) {
        return m(a, b).count().then(function(a) {
            return a > 0
        })
    };
    e = function(a, b) {
        return m(a, b).first()
    };
    f = function(a, b) {
        return a.chunk.where("hashedPlaintextHash").anyOf(b).toArray().then(function(a) {
            return new Map(a.map(function(a) {
                return [a.hashedPlaintextHash, a]
            }))
        })
    };

    function a(a, b) {
        return a.chunk.bulkGet(b)
    }
    var n = function(a, b) {
        b = d("MAWMediaUtils").genHMACPlaintextHash(b);
        return a.chunk.get({
            hashedPlaintextHash: b
        })
    };
    g.getOrCreateMediaChunk = b;
    g.hasMediaChunk = c;
    g.maybeGetChunkFromHash = e;
    g.maybeBulkGetChunksFromHash = f;
    g.bulkGetChunks = a;
    g.maybeGetChunkByPlaintextHash = n
}), 98);
__d("MAWJidUtils", ["FBLogger", "I64", "LSIntEnum", "MAWJids", "WAGlobals", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j(a, b, e) {
        if (d("WAJids").isAuthorSystem(a) || b == null || e == null) {
            c("FBLogger")("messenger_e2ee_web").warn("Failed to create protocolMsgId with externalId %s for a msg to edit", e);
            return
        }
        return {
            author: a,
            chat: b,
            externalId: e
        }
    }

    function a(a) {
        var b;
        return j(a.author, a.threadJid, (b = a.externalId) != null ? b : a.editExternalId)
    }

    function b(a) {
        return d("WAJids").isAuthorMe(a) ? d("WAGlobals").getMyUserJid() : a
    }

    function e(a, b) {
        a = (h || (h = d("I64"))).to_string(a);
        b = (i || (i = d("LSIntEnum"))).unwrapIntEnum(b);
        switch (b) {
            case 15:
                return d("MAWJids").jidUtils.toUserJid(a);
            case 16:
                return d("WAJids").toGroupJid(a);
            default:
                return null
        }
    }
    g.maybeToProtocolMsgId = j;
    g.toProtocolMsgId = a;
    g.getAuthorJid = b;
    g.LSJidtoChatJid = e
}), 98);
__d("MAWLoadReplyMediaTxns", ["ExecutionEnvironment", "MAWBridgeReceiverFetchInfo", "MAWDbChunkTxns", "MAWDbMedia", "MAWDbMsg", "MAWDbXMATxns", "MAWDexieTable", "MAWIndexedDb", "MAWJidUtils", "MAWMediaUtils", "MAWMsgType", "MAWUserJidWrapper", "MAWXMAUtils", "MWPBumpEntityKey", "WAAssertUnreachable", "WAJids", "WALogger", "WAMsgType", "WAResultOrError", "gkx", "justknobx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Invalid msg for getReplyMediaForReceiverFetch with type: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing msgId for getReplyMediaForReceiverFetch"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unable to convert receiver fetch id to media id: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing receiverFetchInfo for getReplyMediaForReceiverFetchWithReceiverFetchId"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing receiverFetchId for getReplyMediaForReceiverFetchWithReceiverFetchId"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unable to fetch reply media XMA with id ", ": ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unable to fetch reply media with id ", ": ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p(a, b, e) {
        if (c("gkx")("2419") && e != null) {
            e = d("MAWMediaUtils").genHMACPlaintextHash(e);
            return a.media.where("hashedPlaintextHash").equals(e).first()
        } else return a.media.get(b)
    }

    function q(a, b, c) {
        if (c != null) {
            c = d("MAWMediaUtils").genHMACPlaintextHash(c);
            return a.media.where("hashedPlaintextHash").equals(c).first().then(function(b) {
                return b == null ? [void 0, void 0] : d("MAWDbChunkTxns").maybeGetChunkFromHash(a, b.hashedPlaintextHash).then(function(a) {
                    return a == null ? [void 0, b] : [a, b]
                })
            })
        } else return a.media.get(b).then(function(b) {
            return b == null ? [void 0, void 0] : d("MAWDbChunkTxns").maybeGetChunkFromHash(a, b.hashedPlaintextHash).then(function(a) {
                return a == null ? [void 0, b] : [a, b]
            })
        })
    }
    var r = new Set([(e = d("MAWDbMedia")).MEDIA_TYPE.IMAGE, e.MEDIA_TYPE.GIF, e.MEDIA_TYPE.PTT, e.MEDIA_TYPE.STICKER, e.MEDIA_TYPE.VIDEO, e.MEDIA_TYPE.DOCUMENT_FILE]);

    function s(a) {
        var b;
        switch (a.mediaType) {
            case d("MAWDbMedia").MEDIA_TYPE.IMAGE:
            case d("MAWDbMedia").MEDIA_TYPE.GIF:
            case d("MAWDbMedia").MEDIA_TYPE.STICKER:
                b = a.validatedImageInfo;
                break;
            case d("MAWDbMedia").MEDIA_TYPE.VIDEO:
                b = a.validatedVideoInfo;
                break
        }
        a = b || {};
        var c = a.height,
            e = a.jpegThumbnailHeight,
            f = a.jpegThumbnailWidth;
        a = a.width;
        return {
            replyMediaPreviewHeight: (e = e) != null ? e : c,
            replyMediaPreviewWidth: (e = f) != null ? e : a
        }
    }

    function t(a) {
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return !0;
            case d("MAWMsgType").MSG_TYPE.XMA:
                return d("MAWXMAUtils").isXMAShare(a.xmaMessageType) || c("justknobx")._("2919") && d("MAWXMAUtils").isXMAStoryReply(a.xmaMessageType);
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("WAMsgType").NOTE_REPLY:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
                return !1;
            default:
                return c("WAAssertUnreachable")(a.type)
        }
    }

    function u(a, b, e) {
        var f;
        if (b == null) return d("MAWDexieTable").dexieResolve();
        f = (f = c("qex")._("237")) != null ? f : !1;
        f = f ? p(a, b, e).then(function(a) {
            if (a == null) return d("WAResultOrError").makeError("reply_media_not_found");
            if (!r.has(a.mediaType)) return d("WAResultOrError").makeError("reply_media_type_unknown");
            var c = s(a),
                e = c.replyMediaPreviewHeight;
            c = c.replyMediaPreviewWidth;
            b != null && a.plaintextHash == null && d("MWPBumpEntityKey").bumpEntityKeyWithAppId("maw.reply_attachment_media_missing_plaintext_hash", "load_reply_media_txns_for_reply_type_unknown}");
            return d("WAResultOrError").makeResult({
                replyMediaId: b,
                replyMediaPreviewHeight: e,
                replyMediaPreviewWidth: c,
                replyPlaintextHash: a.plaintextHash
            })
        }) : q(a, b, e).then(function(a) {
            var c = a[0];
            a = a[1];
            if (a == null) return d("WAResultOrError").makeError("reply_media_not_found");
            if (!r.has(a.mediaType)) return d("WAResultOrError").makeError("reply_media_type_unknown");
            var e = s(a),
                f = e.replyMediaPreviewHeight;
            e = e.replyMediaPreviewWidth;
            var g;
            c != null && (g = c.mimetype);
            if (b != null && a.plaintextHash == null) {
                d("MWPBumpEntityKey").bumpEntityKeyWithAppId("maw.reply_attachment_media_missing_plaintext_hash", "load_reply_media_txns_for_reply_type_" + ((c = g) != null ? c : "unknown"))
            }
            return d("WAResultOrError").makeResult({
                replyMediaId: b,
                replyMediaPreviewHeight: f,
                replyMediaPreviewWidth: e,
                replyMediaUrlMimeType: g,
                replyPlaintextHash: a.plaintextHash
            })
        });
        return f.then(function(a) {
            if (a.success !== !0) {
                d("WALogger").ERROR(o(), b, a.error);
                return
            }
            return a.value
        })
    }

    function v(a, b) {
        var e, f = b.defaultPreviewMediaId;
        if (f == null) return d("MAWDexieTable").dexieResolve({
            replyXMAId: b.xmaId
        });
        e = (e = c("qex")._("237")) != null ? e : !1;
        e = e ? a.media.get(f).then(function(a) {
            if (a == null) return d("WAResultOrError").makeError("reply_xma_media_not_found");
            if (!r.has(a.mediaType)) return d("WAResultOrError").makeError("reply_xma_media_type_unknown");
            var c = s(a),
                e = c.replyMediaPreviewHeight;
            c = c.replyMediaPreviewWidth;
            return d("WAResultOrError").makeResult({
                replyMediaPreviewHeight: e,
                replyMediaPreviewWidth: c,
                replyPlaintextHash: a.plaintextHash,
                replyXMAId: b.xmaId
            })
        }) : q(a, f).then(function(a) {
            var c = a[0];
            a = a[1];
            if (c == null || a == null) return d("WAResultOrError").makeError("reply_xma_media_not_found");
            if (!r.has(a.mediaType)) return d("WAResultOrError").makeError("reply_xma_media_type_unknown");
            var e = s(a),
                f = e.replyMediaPreviewHeight;
            e = e.replyMediaPreviewWidth;
            return d("WAResultOrError").makeResult({
                replyMediaPreviewHeight: f,
                replyMediaPreviewWidth: e,
                replyMediaUrlMimeType: c.mimetype,
                replyPlaintextHash: a.plaintextHash,
                replyXMAId: b.xmaId
            })
        });
        return e.then(function(a) {
            if (a.success !== !0) {
                d("WALogger").ERROR(n(), b.xmaId, a.error);
                return
            }
            return a.value
        })
    }

    function a(a, b, c) {
        var e, f;
        c === void 0 && (c = !1);
        e = ((e = b.quote) == null ? void 0 : e.content) || {};
        var g = e.author,
            h = e.externalId,
            i = e.mediaId,
            j = e.msgId,
            k = e.plaintextHash,
            l = e.type;
        e = e.xmaMessageType;
        if (((f = b.quote) == null ? void 0 : f.content) == null || !t((f = b.quote) == null ? void 0 : f.content)) return d("MAWDexieTable").dexieResolve();
        f = b.threadJid;
        b = g === d("MAWUserJidWrapper").getMyUserJid();
        b = b ? d("WAJids").AUTHOR_ME : g;
        if (d("MAWXMAUtils").isXMAShare(e)) return w(a, d("MAWJidUtils").maybeToProtocolMsgId(b, f, h));
        return l === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH ? y(a, j) : u(a, i, c ? null : k)
    }

    function w(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : d("MAWDbXMATxns").maybeGetXMAFromProtocolMsgId(a, b).then(function(b) {
            if (b == null || d("MAWXMAUtils").isXMAExpired(b.isTombstoned, b.targetExpiringAtSec)) return;
            return v(a, b)
        })
    }

    function b(a, b) {
        var e = b.author,
            f = b.externalId,
            g = b.mediaId,
            h = b.plaintextHash,
            i = b.threadJid,
            j = b.type,
            k = b.xmaMessageType;
        k = d("MAWXMAUtils").isXMAShare(k);
        j = j === d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH;
        if (!d("MAWDbMsg").isMediaMsg(b) && !k && !j) return d("MAWDexieTable").dexieResolve();
        if (k) return w(a, d("MAWJidUtils").maybeToProtocolMsgId(e, i, f));
        return j ? !c("gkx")("5177") ? d("MAWDexieTable").dexieResolve() : x(a, b.receiverFetchId) : u(a, g, h)
    }

    function x(a, b, e) {
        if (b == null) {
            d("WALogger").ERROR(m());
            return d("MAWDexieTable").dexieResolve()
        }
        return a.receiverFetchInfo.get({
            receiverFetchId: b
        }).then(function(a) {
            if (a == null) {
                d("WALogger").WARN(l());
                return
            }
            try {
                var b, f = d("MAWDbMedia").convertNumberToMediaId(parseInt(a.receiverFetchId, 10));
                b = (b = c("qex")._("237")) != null ? b : !1;
                e != null && (!b || (h || (h = c("ExecutionEnvironment"))).isInWorker) && d("MAWIndexedDb").afterTransaction({
                    tag: "NewReceiverFetchInfo",
                    value: d("MAWBridgeReceiverFetchInfo").createBridgeReceiverFetchInfoPayloadFromDbInfo(e, a)
                });
                return {
                    replyMediaId: f,
                    replyMediaPreviewHeight: a.previewHeight,
                    replyMediaPreviewWidth: a.previewWidth,
                    replyMediaUrlMimeType: a.mimetype
                }
            } catch (a) {
                d("WALogger").ERROR(k(), a);
                return
            }
        })
    }

    function y(a, b) {
        if (b == null) {
            d("WALogger").ERROR(j());
            return d("MAWDexieTable").dexieResolve()
        }
        return a.messages.get({
            msgId: b
        }).then(function(b) {
            if (b == null || b.type !== d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH || b.receiverFetchId == null) {
                d("WALogger").ERROR(i(), b == null ? void 0 : b.type);
                return
            }
            return x(a, b.receiverFetchId, b)
        })
    }
    g.getMedia = p;
    g.getMediaAndChunk = q;
    g.MSG_MEDIA_TYPE = r;
    g.getImageAttributes = s;
    g.isMediaReplyContent = t;
    g.getReplyMediaForMsgQuote = a;
    g.getReplyMediaForMsg = b
}), 98);
__d("EncryptedBackupsUtils", ["FBLogger", "WAJids", "WAStanzaUtils", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    f = function(a) {
        return Date.now() - a > d("WATimeUtils").DAY_MILLISECONDS * 30
    };

    function a(a, b, c, d, e) {
        d = {
            frankingTag: d == null ? void 0 : d.frankingTag,
            reportingTag: d == null ? void 0 : d.reportingTag
        };
        d = {
            frankingMetadata: d,
            messageId: b,
            senderId: a,
            timestampMs: c
        };
        return {
            encryptedTransportMessage: e,
            metadata: d
        }
    }

    function b(a) {
        return JSON.stringify([a.author, a.chat, a.externalId])
    }

    function e(a) {
        a = JSON.parse(a);
        if (!Array.isArray(a)) throw c("FBLogger")("labyrinth_web").mustfixThrow("Unable to parse msg id string as proper json");
        if (a.length !== 3) throw c("FBLogger")("labyrinth_web").mustfixThrow("Parsed array should have 3 components");
        var b = d("WAJids").unsafeCoerceToUserJid(a[0]),
            e = d("WAJids").unsafeCoerceToChatJid(a[1]);
        a = d("WAStanzaUtils").toStanzaId(a[2]);
        return {
            author: b,
            chat: e,
            externalId: a
        }
    }
    g.entryOlderThan30Days = f;
    g.asBackupMessage = a;
    g.convertWAMsgIdToStringId = b;
    g.convertStringIdToWAMsgId = e
}), 98);
__d("MAWDbMsgUtil", ["WAJids", "WALogger", "WAMsgMap"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Invalid author when converting msg array to map"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing jid prevents adding message to array map"]);
        i = function() {
            return a
        };
        return a
    }

    function a(a) {
        return a.reduce(function(a, b) {
            var c = b.threadJid;
            if (c == null) {
                d("WALogger").ERROR(i());
                return a
            }
            if (b.author === "@system") {
                d("WALogger").ERROR(h());
                return a
            }
            a.set({
                author: b.author,
                chat: c,
                externalId: b.externalId
            }, b);
            return a
        }, new(d("WAMsgMap").MsgMap)())
    }

    function b(a) {
        return d("WAJids").isAuthorSystem(a.author) || a.threadJid == null ? null : {
            author: a.author,
            chat: a.threadJid,
            externalId: a.externalId
        }
    }
    g.convertMsgArrayToMap = a;
    g.getProtocolMsgIdFromDbMsg = b
}), 98);
__d("MAWDbUnrenderedMsgTxns", ["MAWAckLevel", "MAWDbMsg", "MAWDbMsgUtil", "MAWDexieTable", "WAJids", "WALogger", "WAMsgMap", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["bulkUpdateSystemAck on sent message"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["bulkUpdateSystemAck on incoming message"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updateSystemAckForUnrenderedMsg on non existing message"]);
        j = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c = b.author,
            e = b.chat,
            f = b.externalId;
        return a.threads.get({
            jid: e
        }).then(function(b) {
            return b == null ? d("WAResultOrError").makeError("missing_thread_unrendered_msg") : k(a, f, e, c).then(function(a) {
                return a == null ? d("WAResultOrError").makeError("missing_unrendered_msg") : d("WAResultOrError").makeResult(a)
            })
        })
    }

    function b(a, b) {
        var c = b.map(function(a) {
            a = a.externalId;
            return a
        });
        return a.unrenderedMessages.where("externalId").anyOf(c).toArray().then(function(a) {
            var c = d("MAWDbMsgUtil").convertMsgArrayToMap(a),
                e = new(d("WAMsgMap").MsgMap)();
            b.forEach(function(a) {
                var b = c.get(a);
                b != null && e.set(a, b)
            });
            return e
        })
    }

    function k(a, b, c, d) {
        return a.unrenderedMessages.where("externalId").equals(b).filter(function(a) {
            return a.author === d && a.threadJid === c
        }).first()
    }

    function l(a, b) {
        return a + "_" + b
    }

    function c(a, b) {
        var c = b.map(function(a) {
                a = a.externalId;
                return a
            }),
            e = Array.from(new Set(b.map(function(a) {
                return a.chat
            })));
        return d("MAWDexieTable").dexieAll([a.threads.where("jid").anyOf(e).toArray(), a.unrenderedMessages.where("externalId").anyOf(c).toArray()]).then(function(a) {
            var c = a[0];
            a = a[1];
            if (a.length === 0 || c.length === 0) return [];
            var d = new Map();
            b.forEach(function(a) {
                var b = a.author,
                    c = a.chat;
                a = a.externalId;
                var e = d.get(a) || new Set();
                e.add(l(b, c));
                d.set(a, e)
            });
            return a.filter(function(a) {
                var b = a.author,
                    c = a.externalId;
                a = a.threadJid;
                c = d.get(c);
                return c != null && a != null && c.has(l(b, a))
            })
        })
    }

    function e(a, b, c) {
        return m(a, [{
            ack: c,
            msgId: b
        }]).then(function(a) {
            a = a[0];
            if (a == null) {
                d("WALogger").LOG(j());
                return null
            }
            return a
        })
    }

    function m(a, b) {
        var c = b.map(function(a) {
                return a.msgId
            }),
            e = new Map();
        b.forEach(function(a) {
            return e.set(a.msgId, {
                ack: a.ack
            })
        });
        return a.unrenderedMessages.where("msgId").anyOf(c).toArray().then(function(b) {
            if (b.length === 0) return b;
            var c = [],
                f = [];
            b.forEach(function(a) {
                var b;
                if (a.author !== d("WAJids").AUTHOR_ME) {
                    d("WALogger").ERROR(i());
                    c.push(a);
                    return
                }
                if (a.ack > d("MAWAckLevel").ACK.clock) {
                    d("WALogger").LOG(h());
                    c.push(a);
                    return
                }
                b = (b = e.get(a.msgId)) == null ? void 0 : b.ack;
                if (b == null) return null;
                a = babelHelpers["extends"]({}, a, {
                    ack: b
                });
                b === d("MAWAckLevel").ACK.sent && delete a.resendCount;
                f.push(a)
            });
            return a.unrenderedMessages.bulkPut(f).then(function() {
                return [].concat(f, c)
            })
        })
    }

    function f(a, b) {
        b = b.map(function(b) {
            return a.unrenderedMessages.get({
                msgId: b
            })
        });
        return d("MAWDexieTable").dexieAll(b)
    }

    function n(a, b) {
        return a.unrenderedMessages.where("msgId").between(d("MAWDbMsg").msgIdsInChatLowerBound(b.chatId), d("MAWDbMsg").msgIdsInChatUpperBound(b.chatId)).last().then(function(a) {
            a = a == null ? 0 : d("MAWDbMsg").getInChatMsgIdFromMsgId(a.msgId);
            return a + 1
        })
    }
    g.maybeGetUnrenderedMsgByProtocolMsgId = a;
    g.getUnrenderedMsgMapByProtocolMsgId = b;
    g.maybeGetUnrenderedMsgByExternalId = k;
    g.getUnrenderedMsgsByProtocolMsgId = c;
    g.updateSystemAckForUnrenderedMsg = e;
    g.bulkUpdateSystemAckForUnrenderedMsgs = m;
    g.getUnrenderedMsgsByMsgIds = f;
    g.getNextUnrenderedMsgIdNumberForThread = n
}), 98);
__d("WAArrayGroupBy", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        var c = new Map();
        for (var d = 0; d < a.length; d++) {
            var e = b(a[d]),
                f = c.get(e);
            f == null ? c.set(e, [a[d]]) : f.push(a[d])
        }
        return Array.from(c.entries())
    }
    f.groupBy = a
}), 66);
__d("MAWDbMsgTxns", ["EncryptedBackupsUtils", "MAWAckLevel", "MAWBridgeMsg", "MAWDbMsg", "MAWDbMsgUtil", "MAWDbThreadTxns", "MAWDbUnrenderedMsgTxns", "MAWDbXMATxns", "MAWDexieTable", "MAWIndexedDb", "MAWJidUtils", "MAWLoadReplyMediaTxns", "MAWMsgType", "MAWUpdateThreadMsgMetadataApi", "Random", "WAArrayGroupBy", "WAJids", "WALogger", "WAMsg", "WAMsgMap", "WAResultOrError", "WATimeUtils", "emptyFunction", "err", "gkx", "justknobx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Successfull deleted ", " messages"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updateMediaId on message ", " that already has this mediaId ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Replacing mediaId for message with pre-existing media. type=", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updateMediaId on message ", " that already has this mediaId ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getFutureproofMsg gets a message ", " with unsupported type ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getMsgsFromOffset() newest msg thread jid is not equal to thread jid.\n            msg.threadJid: ", ",\n            thread.jid: ", ",\n            thread.chatId: ", ",\n            offsetMsgId: ", "."]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getMsgsFromOffset, fetched msgs length: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getMsgsFromOffset input: offsetMsgId: ", ", numMsgs: ", ", includeOffset: ", ", includeExpired: ", ", direction: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["bulkUpdateSystemAck: not updating ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updateSystemAck on non existing message"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[maybeGetMsgByProtocolMsgId] Suspected multiple instances of same message!"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[maybeGetMsgByProtocolMsgId] Can't have ", " messages with the same protocolMsgId!"]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[CacheDiscrepancy] Thread ", " has a discrepancy between the cached and uncached values for field: ", ". Cached value: ", ", uncached value: ", ".\n        Cached msgType: ", ", uncached msgType: ", ".\n        Cached ts: ", ", uncached sortOrderMs: ", "."]);
        t = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : a.messages.get({
            msgId: b
        })
    }

    function b(a, b) {
        return a.messages.where("threadJid").equals(b).count().then(function(a) {
            return a === 0
        })
    }

    function e(a, b) {
        return a.messages.where("threadJid").equals(b).filter(function(a) {
            return a.type !== d("MAWMsgType").MSG_TYPE.ADMIN
        }).toArray()
    }

    function u(a, b, c, e, f, g) {
        d("WALogger").LOG(t(), a.jid, b, c, e, f == null ? void 0 : f.type, g == null ? void 0 : g.type, a.newestMsgTs, g == null ? void 0 : g.sortOrderMs)
    }

    function v(a, b, c, e) {
        return e.then(function(e) {
            if (e == null && c == null || e === d("WATimeUtils").castToMillisTime(0) || e != null && c != null && Math.floor(e / 1e3) === c / 1e3) return;
            u(a, b, c, e, null, null)
        })
    }

    function w(a) {
        switch (a) {
            case "newestMsgTs":
                return d("Random").coinflip(c("justknobx")._("2537"))
        }
    }

    function x(a, b) {
        b = w(b);
        var c = !1;
        switch (a) {
            case "query_by_sortOrderMs":
                c = !0;
                break;
            case "use_cached_fields":
                c = !1;
                break
        }
        return {
            isCacheBypassed: c,
            isLoggingExpected: b
        }
    }

    function y(a, b, c, d) {
        return a.messages.where(["threadJid", "sortOrderMs"]).between([b, Number.MIN_SAFE_INTEGER], [b, Number.MAX_SAFE_INTEGER], c, d)
    }

    function z(a, b) {
        return y(a, b, !1, !1).last()
    }

    function f(a, b) {
        return z(a, b).then(function(a) {
            return a == null ? void 0 : a.msgId
        })
    }

    function A(a, b, c) {
        c === void 0 && (c = "query_by_sortOrderMs");
        var e = "newestMsgTs";
        c = x(c, e);
        var f = c.isCacheBypassed;
        c = c.isLoggingExpected;
        var g = b.newestMsgTs;
        a = z(a, b.jid).then(function(a) {
            return (a == null ? void 0 : a.sortOrderMs) == null ? null : d("WATimeUtils").castToMillisTime(a.sortOrderMs)
        });
        c && v(b, e, g, a);
        return f ? a : d("MAWDexieTable").dexieResolve(g)
    }

    function B(a, b, c) {
        return y(a, b, !1, !1).reverse().limit(c).toArray()
    }

    function C(a, b) {
        return y(a, b, !1, !1).first()
    }

    function D(a, b) {
        return C(a, b).then(function(a) {
            return a == null ? void 0 : a.msgId
        })
    }

    function E(a, b) {
        return a.messages.where("externalId").equals(b.externalId).filter(function(a) {
            return a.author === b.author && a.threadJid === b.chat
        }).toArray().then(G)
    }

    function F(a, b) {
        var c = new Set(b.map(function(a) {
            var b = a.author,
                c = a.chat;
            a = a.externalId;
            return d("WAMsg").craftWAMsgIdString({
                author: b,
                chat: c,
                externalId: a
            })
        }));
        return a.messages.where("externalId").anyOf(b.map(function(a) {
            a = a.externalId;
            return a
        })).filter(function(a) {
            var b = a.author,
                e = a.externalId;
            a = a.threadJid;
            return c.has(d("WAMsg").craftWAMsgIdString({
                author: b,
                chat: a,
                externalId: e
            }))
        }).toArray().then(function(a) {
            return d("WAArrayGroupBy").groupBy(a, function(a) {
                return d("WAMsg").craftWAMsgIdString({
                    author: a.author,
                    chat: a.threadJid,
                    externalId: a.externalId
                })
            }).map(function(a) {
                a[0];
                a = a[1];
                return G(a)
            }).filter(Boolean)
        })
    }

    function G(a) {
        if (a.length > 1) {
            var b = a.map(function(a) {
                var b;
                return a.type + ":" + ((b = a.serverTs) != null ? b : 0).toString() + ":" + ((b = a.ts) != null ? b : 0).toString()
            });
            b = new Set(b).size === 1;
            !b ? d("WALogger").ERROR(s(), a.length) : d("WALogger").ERROR(r())
        }
        return a[0]
    }

    function H(a, b, c, d) {
        d = {
            author: d,
            chat: c,
            externalId: b
        };
        return E(a, d)
    }

    function I(a, b) {
        return a.messages.where("msgId").equals(b).toArray()
    }

    function J(a, b) {
        return M(a, b).then(function(a) {
            return a.success ? a : a
        })
    }

    function K(a, b) {
        var c = b.map(function(a) {
            a = a.externalId;
            return a
        });
        return a.messages.where("externalId").anyOf(c).toArray().then(function(a) {
            var c = d("MAWDbMsgUtil").convertMsgArrayToMap(a),
                e = new(d("WAMsgMap").MsgMap)();
            b.forEach(function(a) {
                var b = c.get(a);
                b != null && e.set(a, b)
            });
            return e
        })
    }

    function L(a, b) {
        return a.messages.where("msgId").equals(b).first().then(function(a) {
            return a == null ? void 0 : a.sortOrderMs
        })
    }

    function M(a, b) {
        var c = b.author,
            e = b.chat,
            f = b.externalId;
        return a.threads.get({
            jid: e
        }).then(function(b) {
            return b == null ? d("WAResultOrError").makeError("missing_thread_msg") : H(a, f, b.jid, c).then(function(a) {
                return a == null ? d("WAResultOrError").makeError("missing_msg") : d("WAResultOrError").makeResult(a)
            })
        })
    }

    function N(a, b) {
        var c = b.author,
            d = b.chat,
            e = b.externalId;
        return a.threads.get({
            jid: d
        }).then(function(b) {
            if (b == null) return;
            return a.messages.where("revokedExternalId").equals(e).filter(function(a) {
                return a.author === c && a.threadJid === b.jid && a.type === "Revoked"
            }).first()
        })
    }

    function O(a, b, c, e) {
        var f = a.messages.where("revokedExternalId").equals(b).filter(function(a) {
            return a.author === e && a.threadJid === c && a.type === d("MAWMsgType").MSG_TYPE.REVOKED
        }).first();
        a = d("MAWDbUnrenderedMsgTxns").maybeGetUnrenderedMsgByExternalId(a, b, c, e).then(function(a) {
            if ((a == null ? void 0 : a.type) === d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME) return a
        });
        return d("MAWDexieTable").dexieAll([f, a]).then(function(a) {
            var b = a[0];
            a = a[1];
            return b != null || a != null
        })
    }

    function P(a, b) {
        var c = new Array(b.length),
            e = new Set();
        b.forEach(function(a) {
            c.push(a.externalId), e.add(d("EncryptedBackupsUtils").convertWAMsgIdToStringId(a))
        });
        return a.messages.where("externalId").anyOf(c).filter(function(a) {
            return e.has(d("EncryptedBackupsUtils").convertWAMsgIdToStringId({
                author: a.author,
                chat: a.threadJid,
                externalId: a.externalId
            }))
        }).toArray()
    }

    function Q(a, b, c, e, f, g) {
        return R(a, [{
            ack: c,
            msgId: b,
            reportingMeta: f,
            serverTs: e
        }], g).then(function(a) {
            a = a.find(function(a) {
                return a.msgId === b
            });
            if (a == null) {
                d("WALogger").LOG(q());
                return null
            }
            return a
        })
    }

    function R(a, b, c) {
        c == null ? void 0 : c.addPoint("bulk_update_system_ack_start");
        var e = b.map(function(a) {
            return a.msgId
        });
        return d("MAWDbXMATxns").getXMAMsgIdsFromAssociatedMsgIds(a, e).then(function(f) {
            var g = new Map();
            b.forEach(function(a) {
                g.set(a.msgId, {
                    ack: a.ack,
                    reportingMeta: a.reportingMeta,
                    serverTs: a.serverTs
                });
                var b = f.get(a.msgId);
                b != null && g.set(b, {
                    ack: a.ack,
                    reportingMeta: a.reportingMeta,
                    serverTs: a.serverTs
                })
            });
            var h = Array.from(new Set(e.concat(Array.from(f.values()))));
            return a.messages.where("msgId").anyOf(h).toArray().then(function(b) {
                if (b.length === 0) return b;
                var e = [],
                    f = [];
                b.forEach(function(a) {
                    var b, c;
                    if (a.author !== d("WAJids").AUTHOR_ME || a.ack > d("MAWAckLevel").ACK.clock) {
                        e.push(a);
                        return
                    }
                    b = (b = g.get(a.msgId)) == null ? void 0 : b.ack;
                    c = (c = g.get(a.msgId)) == null ? void 0 : c.serverTs;
                    if (b == null) return null;
                    var h = babelHelpers["extends"]({}, a, {
                        ack: b
                    });
                    c != null && (h.serverTs = c);
                    a = (c = g.get(a.msgId)) == null ? void 0 : c.reportingMeta;
                    a != null && (h.reportingMeta = a);
                    b === d("MAWAckLevel").ACK.sent && delete h.resendCount;
                    f.push(h)
                });
                e.length > 0 && d("WALogger").LOG(p(), e.map(function(a) {
                    return a.msgId
                }).toString());
                return a.messages.bulkPut(f).then(function() {
                    return d("MAWDexieTable").dexieAll(f.map(function(b) {
                        return d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, b)
                    }))
                }).then(function(a) {
                    f.forEach(function(b, e) {
                        d("MAWIndexedDb").afterTransaction({
                            tag: "MsgUpdated",
                            value: d("MAWBridgeMsg").createBridgeMsg(b, void 0, a[e], void 0, c == null ? void 0 : c.getFlowDetails().instanceKey)
                        })
                    });
                    return [].concat(f, e)
                })
            })
        })
    }

    function S(a, b, e, f) {
        return d("MAWDbThreadTxns").getThread(a, b).then(function(b) {
            if (!b.success || f == null || b.value.oldestMsg !== e && b.value.newestMsg !== e) return;
            var g = b.value;
            b = [a.messages.where(["threadJid", "sortOrderMs"]).above([g.jid, f]).first(), a.messages.where(["threadJid", "sortOrderMs"]).below([g.jid, f]).last()];
            return d("MAWDexieTable").dexieAll(b).then(function(b) {
                var f = b[0];
                b = b[1];
                return d("MAWDbThreadTxns").updateThread(a, babelHelpers["extends"]({}, g, {
                    newestMsg: g.newestMsg === e ? b == null ? void 0 : b.msgId : g.newestMsg,
                    newestMsgTs: g.newestMsg === e ? (b == null ? void 0 : b.ts) == null ? null : d("WATimeUtils").castUnixTimeToMillisTime(b.ts) : g.newestMsgTs,
                    oldestMsg: g.oldestMsg === e ? f == null ? void 0 : f.msgId : g.oldestMsg
                })).then(c("emptyFunction"))
            })
        })
    }

    function T(a, b, e, f, g) {
        if (b === (e == null ? void 0 : e.msgId) && f === (g == null ? void 0 : g.msgId)) return d("MAWDexieTable").dexieResolve();
        d("MAWIndexedDb").afterTransactionEffect(function() {
            c("promiseDone")(c("MAWUpdateThreadMsgMetadataApi")(a, b, e, f, g))
        })
    }

    function U(a, b, e, f, g, h, i) {
        g === void 0 && (g = !1);
        h === void 0 && (h = !1);
        i === void 0 && (i = "before");
        return f === 0 ? d("MAWDexieTable").dexieResolve({
            hasMoreAfter: !1,
            hasMoreBefore: !1,
            msgs: []
        }) : d("MAWDexieTable").dexieAll([a.threads.get({
            jid: b
        }), e == null ? d("MAWDexieTable").dexieResolve(null) : a.messages.get({
            msgId: e
        })]).then(function(b) {
            var j = b[0],
                k = b[1],
                l = j == null ? void 0 : j.oldestMsg,
                p = j == null ? void 0 : j.newestMsg;
            if (j == null || e != null && k == null) return {
                hasMoreAfter: !1,
                hasMoreBefore: !1,
                msgs: []
            };
            var q = h ? function(a) {
                return !0
            } : function(a) {
                return a.messageExpirationTs == null || a.messageExpirationTs > d("WATimeUtils").unixTime()
            };
            b = d("MAWDexieTable").dexieResolve([]);
            f === 1 && g && k != null && (b = d("MAWDexieTable").dexieResolve([k].filter(q)));
            d("WALogger").LOG(o(), k == null ? void 0 : k.msgId, f, g, h, i);
            return b.then(function(b) {
                b = b.length > 0 ? d("MAWDexieTable").dexieResolve(b) : Z(a, j.jid, k, g, f, q, i);
                var h = c("gkx")("23927");
                return d("MAWDexieTable").dexieAll([b, z(a, j.jid), C(a, j.jid)]).then(function(a) {
                    var b = a[0],
                        c = a[1];
                    a = a[2];
                    T(j, l, a, p, c);
                    d("WALogger").LOG(n(), b.length);
                    if (b.length === 0) return {
                        hasMoreAfter: !1,
                        hasMoreBefore: !1,
                        msgs: []
                    };
                    var g = b[b.length - 1],
                        i = b[0];
                    g = h ? g.msgId !== (a == null ? void 0 : a.msgId) : g.msgId !== (a == null ? void 0 : a.msgId) && b.length === f;
                    a = h ? i.msgId !== (c == null ? void 0 : c.msgId) : !1;
                    i.threadJid !== j.jid && d("WALogger").ERROR(m(), i.threadJid, j.jid, j.chatId, e);
                    return {
                        hasMoreAfter: a,
                        hasMoreBefore: g,
                        msgs: b
                    }
                })
            })
        })
    }

    function V(a) {
        return a.messages.where("altIndex").equals(d("MAWDbMsg").FUTUREPROOF_ALT_INDEX).toArray().then(function(a) {
            var b = [];
            a.forEach(function(a) {
                if (a.type !== d("MAWMsgType").MSG_TYPE.FUTUREPROOF) {
                    d("WALogger").ERROR(l(), a.msgId, a.type);
                    return
                }
                b.push(a)
            });
            return b
        })
    }

    function W(a) {
        return a.toString()
    }

    function aa(a, b, e, f) {
        var g = b.mediaId;
        if (g === e) {
            d("WALogger").LOG(k(), b.msgId, e);
            return d("MAWDexieTable").dexieResolve()
        }
        g = g != null ? a.media.get(g) : d("MAWDexieTable").dexieResolve();
        return g.then(function(g) {
            g && d("WALogger").ERROR(j(), b.type);
            g = (g = f) != null ? g : void 0;
            g = babelHelpers["extends"]({}, b, {
                mediaId: e,
                plaintextHash: g
            });
            return a.messages.put(g).then(c("emptyFunction"))
        })
    }

    function ba(a, b) {
        var e = Array.from(b.keys());
        return a.messages.where("msgId").anyOf(e).toArray().then(function(e) {
            var f = [];
            e.map(function(a) {
                var e = b.get(a.msgId),
                    g = a.mediaId;
                if (g != null && g !== e) {
                    if (e != null) throw c("err")("mediaId " + W(g) + " in message " + a.msgId + " is different with the " + W(e) + " in bulkUpdateMediaId");
                    d("WALogger").LOG(i(), a.msgId, e);
                    return
                }
                g = babelHelpers["extends"]({}, a, {
                    mediaId: e,
                    plaintextHash: a.plaintextHash
                });
                f.push(g)
            });
            return a.messages.bulkPut(f).then(c("emptyFunction"))
        })
    }

    function ca(a, b) {
        return X(a, [b]).then(c("emptyFunction"))
    }

    function X(a, b) {
        return a.messages.where("msgId").anyOf(b).toArray().then(function(b) {
            var c = b.map(function(a) {
                return babelHelpers["extends"]({}, a, {
                    isExpiredXmaMsg: !0
                })
            });
            return a.messages.bulkPut(c).then(function() {
                return c
            })
        })
    }

    function Y(a, b, c, e) {
        if (e != null && e <= 0) return d("MAWDexieTable").dexieResolve([]);
        a = a.messages.where("altIndex").equals(d("MAWDbMsg").craftToBeReadAltIndex(b)).filter(function(a) {
            return d("MAWDbMsg").getSortOrderWithFallback(a) <= c
        });
        e != null && (a = a.limit(e));
        return a.toArray()
    }

    function da(a, b, c) {
        return Y(a, b, c).then(function(b) {
            var c = b.map(function(a) {
                return babelHelpers["extends"]({
                    altIndex: null
                }, a)
            });
            return a.messages.bulkPut(c).then(function() {
                return c
            })
        })
    }

    function ea(a, b) {
        return a.messages["delete"](b)
    }

    function fa(a, b, c) {
        var e = b.map(function(a) {
            return a.rowId
        });
        b = c != null ? b.map(function(a) {
            a = d("MAWJidUtils").toProtocolMsgId(a);
            if (!a) return;
            return babelHelpers["extends"]({}, a, {
                reason: c
            })
        }).filter(Boolean) : [];
        return d("MAWDexieTable").dexieAll([a.deletedMessages.bulkAdd(b), a.messages.bulkDelete(e)]).then(function(a) {
            a[0];
            a = a[1];
            d("WALogger").LOG(h(), a)
        })
    }

    function ga(a, b) {
        return a.messages.where("msgId").anyOf(b).toArray()
    }

    function ha(a) {
        return a.messages.where("altIndex").anyOf([d("MAWDbMsg").SPAM_ALT_INDEX, d("MAWDbMsg").FUTUREPROOF_SPAM_ALT_INDEX]).toArray()
    }

    function Z(a, b, c, e, f, g, h) {
        h === void 0 && (h = "before");
        c = c == null ? null : d("MAWDbMsg").getSortOrderWithFallback(c);
        if (h === "before") {
            return a.messages.where(["threadJid", "sortOrderMs"]).between([b, Number.MIN_SAFE_INTEGER], [b, (h = c) != null ? h : Number.MAX_SAFE_INTEGER], !0, e).reverse().filter(g).limit(f).toArray()
        } else {
            return a.messages.where(["threadJid", "sortOrderMs"]).between([b, (h = c) != null ? h : Number.MIN_SAFE_INTEGER], [b, Number.MAX_SAFE_INTEGER], e, !0).filter(g).limit(f).toArray().then(function(a) {
                return a.sort(function(a, b) {
                    return b.ts - a.ts
                })
            })
        }
    }

    function ia(a, b, c, d) {
        var e = c.msgId;
        if (a == null && b == null) return {
            newestMsg: e,
            oldestMsg: e
        };
        if (d == null) {
            var f;
            return {
                newestMsg: e,
                oldestMsg: (f = a == null ? void 0 : a.msgId) != null ? f : e
            }
        }
        f = [a, b, c].filter(Boolean);
        return {
            newestMsg: f.reduce(function(a, b) {
                return $(b, e, d) >= $(a, e, d) ? b : a
            }).msgId,
            oldestMsg: f.reduce(function(a, b) {
                return $(a, e, d) < $(b, e, d) ? a : b
            }).msgId
        }
    }

    function $(a, b, c) {
        return a.msgId === b ? c : d("MAWDbMsg").getSortOrderWithFallback(a)
    }

    function ja(a, b) {
        return a.messages.where("msgId").between(d("MAWDbMsg").msgIdsInChatLowerBound(b.chatId), d("MAWDbMsg").msgIdsInChatUpperBound(b.chatId)).last().then(function(a) {
            a = a == null ? 0 : d("MAWDbMsg").getInChatMsgIdFromMsgId(a.msgId);
            return a + 1
        })
    }
    g.maybeGetMsg = a;
    g.getIsThreadEmpty = b;
    g.getNonAdminMsgs = e;
    g.getThreadMessagesBySortOrder = y;
    g.getThreadNewestMessageBySortOrder = z;
    g.getThreadNewestMessageId = f;
    g.getThreadNewestMessageTs = A;
    g.getThreadNewestNumMessagesBySortOrder = B;
    g.getThreadOldestMessageBySortOrder = C;
    g.getThreadOldestMessageId = D;
    g.maybeGetMsgByProtocolMsgId = E;
    g.getUniqueMsgsByProtocolMsgIds = F;
    g.maybeGetMsgByExternalId = H;
    g.maybeGetMsgListByMsgId_I_KNOW_WHAT_I_AM_DOING = I;
    g.maybeGetMsgResultByProtocolMsgId = J;
    g.getMsgMapByProtocolMsgId = K;
    g.getSortOrderFromMsgId = L;
    g.maybeGetRevokedMsgByProtocolMsgId = N;
    g.checkIfMsgIsDeletedForMeOrRevoked = O;
    g.getMsgsByProtocolMsgId = P;
    g.updateSystemAck = Q;
    g.bulkUpdateSystemAck = R;
    g.maybeUpdateThreadMsgsForDeleteForMe = S;
    g.getMsgsFromOffset = U;
    g.getFutureProofMsgs = V;
    g.updateMediaId = aa;
    g.bulkUpdateMediaId = ba;
    g.updateDbMsgXMAExpiration = ca;
    g.bulkUpdateDbMsgXMAExpired = X;
    g.getMsgsNeedingRetroactiveReadReceiptsUpTo = Y;
    g.clearRetroactiveReadReceiptStatusFromMsgsUpTo = da;
    g.deleteDbMsg = ea;
    g.deleteMessages = fa;
    g.getMsgsByMsgIds = ga;
    g.getSpamMsgs = ha;
    g.fetchMessagesFromDbWithSortOrderMs = Z;
    g.calculateOldestAndNewestMsg = ia;
    g.getNextMsgIdNumberForThread = ja
}), 98);
__d("MAWDbThreadTxns", ["MAWBridgeTypesCreators", "MAWDbMsgTxns", "MAWDexieTable", "MAWFolderTypes", "MAWIndexedDb", "WAArrayZip", "WALogger", "WAResultOrError", "WATimeUtils", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["markCutoverThreadAsNotMigratedLocally failed because thread is already unmigrated"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["markThreadAsMigratedLocally failed because thread is already migrated"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["markThreadAsMigratedLocally failed to get the thread"]);
        j = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return a.threads.get({
            deduplicationKey: b
        }).then(function(a) {
            return a == null ? d("WAResultOrError").makeError("missing") : d("WAResultOrError").makeResult(a)
        })
    }

    function k(a, b) {
        return a.threads.get({
            jid: b
        }).then(function(a) {
            return a == null ? d("WAResultOrError").makeError("missing") : d("WAResultOrError").makeResult(a)
        })
    }

    function l(a, b) {
        return a.threads.where("jid").anyOf(b).toArray()
    }

    function b(a, b) {
        return a.threads.where("jid").startsWith(b + "@").first().then(function(a) {
            return a == null ? d("WAResultOrError").makeError("missing") : d("WAResultOrError").makeResult(a)
        })
    }

    function e(a, b) {
        return a.threads.where("jid").equals(b)["delete"]().then(c("emptyFunction"))
    }

    function f(a, b) {
        return a.participants.where("userJid").equals(b).toArray().then(function(b) {
            b = b.map(function(a) {
                return a.threadJid
            });
            return l(a, b)
        })
    }

    function m(a, b) {
        return a.participants.where("userJid").anyOf(b).toArray().then(function(b) {
            var c = new Map(),
                d = new Set();
            b.forEach(function(a) {
                var b, e = a.userJid;
                b = (b = c.get(e)) != null ? b : [];
                b.push(a.threadJid);
                c.set(e, b);
                d.add(a.threadJid)
            });
            return l(a, Array.from(d)).then(function(a) {
                var b = a.reduce(function(a, b) {
                    a.set(b.jid, b);
                    return a
                }, new Map());
                return new Map(Array.from(c.entries()).map(function(a) {
                    var c = a[0];
                    a = a[1];
                    return [c, a.map(function(a) {
                        return b.get(a)
                    }).filter(Boolean)]
                }))
            })
        })
    }

    function n(a, b, c) {
        return (b == null ? void 0 : b.lastReadMsgReceiptSent) == null ? d("MAWDexieTable").dexieResolve(!1) : d("MAWDbMsgTxns").getSortOrderFromMsgId(a, b.lastReadMsgReceiptSent).then(function(a) {
            return c.sortOrderMs == null || a == null ? !1 : c.sortOrderMs <= a
        })
    }

    function o(a, b) {
        return a.threads.get({
            jid: b.threadJid
        }).then(function(c) {
            return n(a, c, b)
        })
    }

    function p(a, b) {
        return a.threads.where("jid").anyOf(b.map(function(a) {
            return a.threadJid
        })).toArray().then(function(c) {
            return d("MAWDexieTable").dexieAll(d("WAArrayZip").zip(b, c).map(function(b) {
                var c = b[0];
                b = b[1];
                return n(a, b, c)
            }))
        })
    }

    function q(a, b, c) {
        return a.threads.where("jid").anyOf(b).toArray().then(function(b) {
            var e = b.filter(Boolean).map(function(a) {
                return babelHelpers["extends"]({}, a, {
                    archived: !0,
                    cannotReplyReason: c ? "viewer_not_subscribed" : a.cannotReplyReason,
                    folder: d("MAWFolderTypes").FOLDER_ID.ARCHIVED
                })
            });
            return a.threads.bulkPut(e).then(function() {
                e.forEach(function(a) {
                    c && d("WALogger").LOG(["[Occamadillo] Leaving a group thread\n          " + a.jid.toString() + ", showing a VIEWER_NOT_SUBSCRIBED composer blocker"]), d("MAWIndexedDb").afterTransaction({
                        tag: "ThreadUpdated",
                        value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                            cannotReplyReason: a.cannotReplyReason,
                            folder: d("MAWFolderTypes").FOLDER_ID.ARCHIVED,
                            threadJid: a.jid
                        })
                    })
                })
            })
        })
    }

    function r(a, b) {
        return a.threads.where("jid").anyOf(b).toArray().then(function(b) {
            var c = b.filter(Boolean).map(function(a) {
                return babelHelpers["extends"]({}, a, {
                    cannotReplyReason: null
                })
            });
            return a.threads.bulkPut(c).then(function() {
                c.forEach(function(a) {
                    a = {
                        cannotReplyReason: null,
                        threadJid: a.jid
                    };
                    d("MAWIndexedDb").afterTransaction({
                        tag: "ThreadUpdated",
                        value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread(a)
                    })
                })
            })
        })
    }

    function s(a, b) {
        return a.threads.where("jid").anyOf(b).toArray().then(function(b) {
            var c = b.filter(Boolean).map(function(a) {
                return babelHelpers["extends"]({}, a, {
                    archived: !1,
                    cannotReplyReason: a.cannotReplyReason === "viewer_not_subscribed" ? a.cannotReplyReason : null,
                    folder: d("MAWFolderTypes").FOLDER_ID.INBOX
                })
            });
            return a.threads.bulkPut(c).then(function() {
                c.forEach(function(a) {
                    d("MAWIndexedDb").afterTransaction({
                        tag: "ThreadUpdated",
                        value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                            cannotReplyReason: a.cannotReplyReason,
                            folder: d("MAWFolderTypes").FOLDER_ID.INBOX,
                            threadJid: a.jid
                        })
                    })
                })
            })
        })
    }

    function t(a, b) {
        return a.threads.where("jid").anyOf(b).toArray().then(function(b) {
            var c = b.filter(Boolean).map(function(a) {
                return babelHelpers["extends"]({}, a, {
                    cannotReplyReason: "viewer_not_subscribed"
                })
            });
            return a.threads.bulkPut(c).then(function() {
                c.forEach(function(a) {
                    var b = {
                        cannotReplyReason: "viewer_not_subscribed",
                        threadJid: a.jid
                    };
                    d("WALogger").LOG(["[Occamadillo] User is unsubscribed from thread\n          " + a.jid.toString() + ", showing a VIEWER_NOT_SUBSCRIBED composer blocker"]);
                    d("MAWIndexedDb").afterTransaction({
                        tag: "ThreadUpdated",
                        value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread(b)
                    })
                })
            })
        })
    }

    function u(a, b) {
        return k(a, b).then(function(b) {
            if (!b.success) {
                d("WALogger").WARN(j());
                return
            }
            b = b.value;
            if (b.isMigratedLocally === !0) {
                d("WALogger").WARN(i());
                return
            }
            b = babelHelpers["extends"]({}, b, {
                isMigratedLocally: !0
            });
            return a.threads.put(b).then(c("emptyFunction"))
        })
    }

    function v(a, b) {
        if (b.isMigratedLocally === !1) {
            d("WALogger").WARN(h());
            return d("MAWDexieTable").dexieResolve(b)
        }
        var c = babelHelpers["extends"]({}, b, {
            isMigratedLocally: !1
        });
        return a.threads.put(c).then(function() {
            return c
        })
    }

    function w(a, b) {
        return a.threads.put(b).then(c("emptyFunction"))
    }

    function x(a, b, c, e, f, g) {
        c = c === (e == null ? void 0 : e.msgId);
        f = f === (g == null ? void 0 : g.msgId);
        return c && f ? d("MAWDexieTable").dexieResolve() : w(a, babelHelpers["extends"]({}, b, {
            newestMsg: g == null ? void 0 : g.msgId,
            newestMsgTs: f ? b.newestMsgTs : (g == null ? void 0 : g.ts) == null ? null : d("WATimeUtils").castUnixTimeToMillisTime(g.ts),
            oldestMsg: e == null ? void 0 : e.msgId
        }))
    }
    g.getThreadByDeduplicationKey = a;
    g.getThread = k;
    g.getThreads = l;
    g.getThreadPrimaryId = b;
    g.deleteThreadRow = e;
    g.getAllThreadsForUser = f;
    g.getAllThreadsForUsers = m;
    g.needsRetroactiveReadReceiptInThread = o;
    g.bulkNeedsRetroactiveReadReceiptInThread = p;
    g.archiveThreads = q;
    g.subscribeToThreads = r;
    g.unarchiveThreads = s;
    g.unsubscribeFromThreads = t;
    g.markCutoverThreadAsMigratedLocally = u;
    g.markCutoverThreadAsNotMigratedLocally = v;
    g.updateThread = w;
    g.updateThreadMsgsForUndefinedOldestOrNewestMsgs = x
}), 98);
__d("MAWDbMediaTxns", ["MAWDbMsg", "MAWDexieTable", "MAWMediaUtils", "MAWMsgType", "WALogger", "WAResultOrError", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["mediaId is null for media msg with msgId: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["mediaId is null for media msg with msgId: ", " and msg type ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : a.media.get({
            mediaId: b
        })
    }

    function j(a, b) {
        return a.media.where("hashedPlaintextHash").equals(b).first()
    }

    function b(a, b) {
        b = d("MAWMediaUtils").genHMACPlaintextHash(b);
        return j(a, b)
    }

    function e(a, b) {
        b = b.map(function(a) {
            return d("MAWMediaUtils").genHMACPlaintextHash(a)
        });
        return k(a, b)
    }

    function k(a, b) {
        return a.media.where("hashedPlaintextHash").anyOf(b).toArray()
    }

    function f(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : l(a, b).then(function(c) {
            c = c == null ? void 0 : c.mediaId;
            return c != null ? a.media.get({
                mediaId: c
            }) : a.media.get({
                objectId: b
            })
        })
    }

    function l(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : a.mediaBackup.get({
            objectId: b
        })
    }

    function m(a, b) {
        a = a.mediaBackup.where("objectId").anyOf(b).toArray();
        return a.then(function(a) {
            return new Map(a.map(function(a) {
                return [a.objectId, a]
            }))
        })
    }

    function n(a, b) {
        if (b == null) return d("MAWDexieTable").dexieResolve();
        a = a.mediaBackup.where("msgId").equals(b).toArray();
        return a
    }

    function o(a, b) {
        if (b.length === 0) return d("MAWDexieTable").dexieResolve([]);
        b = b.filter(d("MAWDbMsg").isMediaMsg);
        var e = b.reduce(function(a, b) {
            if (b.mediaId == null) {
                d("WALogger").ERROR(i(), b.msgId, b.type);
                return a
            }
            return a.set(b.mediaId, b)
        }, new Map());
        b = Array.from(e.keys());
        return r(a, b).then(function(a) {
            var b = [];
            a.forEach(function(a) {
                if (a == null) throw c("err")("Error missing media");
                var d = e.get(a.mediaId);
                if (d == null) throw c("err")("Error missing media");
                b.push([d, a])
            });
            return b
        })
    }

    function p(a, b) {
        if (b.length === 0) return d("MAWDexieTable").dexieResolve([]);
        b = b.filter(d("MAWDbMsg").isMediaMsg).map(function(a) {
            var b = a.mediaId;
            if (b == null) {
                d("WALogger").ERROR(h(), a.msgId);
                throw c("err")("mediaId is missing")
            } else return b
        });
        return r(a, b).then(function(a) {
            var b = [];
            a.forEach(function(a) {
                a != null && b.push(a)
            });
            return b
        })
    }

    function q(a, b) {
        if (b.type === d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME || d("MAWDbMsg").isMediaMsg(b)) {
            var c = b.mediaId;
            return c == null ? b.type === d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME ? d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeResult()) : d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeError("missing")) : a.media.get(c).then(function(a) {
                return a == null ? d("WAResultOrError").makeError("missing") : d("WAResultOrError").makeResult(a)
            })
        } else return d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeResult())
    }

    function r(a, b) {
        return a.media.bulkGet(b)
    }

    function s(a, b) {
        var c = b.previewMediaIds != null ? r(a, b.previewMediaIds) : d("MAWDexieTable").dexieResolve(),
            e = b.headerMediaId != null ? a.media.get(b.headerMediaId) : d("MAWDexieTable").dexieResolve(),
            f = b.faviconMediaId != null ? a.media.get(b.faviconMediaId) : d("MAWDexieTable").dexieResolve();
        a = b.defaultPreviewMediaId != null ? a.media.get(b.defaultPreviewMediaId) : d("MAWDexieTable").dexieResolve();
        return d("MAWDexieTable").dexieAll([c, e, f, a]).then(function(a) {
            var c = a[0],
                e = a[1],
                f = a[2];
            a = a[3];
            if (b.headerMediaId != null && e == null) return d("WAResultOrError").makeError("missing");
            if (b.faviconMediaId != null && f == null) return d("WAResultOrError").makeError("missing");
            if (c == null) return d("WAResultOrError").makeError("missing");
            var g = [];
            for (var c = c, h = Array.isArray(c), i = 0, c = h ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var j;
                if (h) {
                    if (i >= c.length) break;
                    j = c[i++]
                } else {
                    i = c.next();
                    if (i.done) break;
                    j = i.value
                }
                j = j;
                if (j == null) return d("WAResultOrError").makeError("missing");
                else g.push(j)
            }
            return d("WAResultOrError").makeResult({
                defaultPreview: a,
                favicon: f,
                header: e,
                previews: g
            })
        })
    }

    function t(a, b, c) {
        b = babelHelpers["extends"]({}, b, c);
        return a.media.put(b)
    }
    g.maybeGetMediaFromMediaId = a;
    g.maybeGetMediaFromHashedPlaintextHash = j;
    g.maybeGetMediaFromPlaintextHash = b;
    g.maybeBulkGetMediaFromPlaintextHash = e;
    g.maybeBulkGetMediaFromHashedPlaintextHash = k;
    g.maybeGetMediaFromObjectId = f;
    g.maybeGetMediaBackupRowFromObjectId = l;
    g.maybeGetMediaBackupRowsFromObjectIds = m;
    g.maybeGetMediaBackupRowFromMsgId = n;
    g.getMsgMediaPairFromMsgs = o;
    g.getMediaFromMsgs = p;
    g.getAndCheckMediaFromMsg = q;
    g.bulkGetMedias = r;
    g.getMediaForXMA = s;
    g.updateMedia = t
}), 98);
__d("MAWDbXMATxns", ["MAWDbMediaTxns", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbThreadTxns", "MAWDexieTable", "MAWJidUtils", "MAWXMAUtils", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return a.xma.bulkGet(b)
    }

    function b(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : a.xma.get({
            xmaId: b
        })
    }

    function h(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : a.xma.where("associatedMessageId").equals(b).first()
    }

    function i(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : a.xma.where("externalId").equals(b.externalId).filter(function(a) {
            return a.author === b.author && a.threadJid === b.chat
        }).first()
    }

    function c(a, b) {
        return i(a, b).then(function(b) {
            return b == null ? d("WAResultOrError").makeError("missing") : d("MAWDexieTable").dexieAll([d("MAWDbMediaTxns").getMediaForXMA(a, b), d("MAWDbMsgTxns").maybeGetMsg(a, b.associatedMessageId)]).then(function(a) {
                var c = a[0];
                a = a[1];
                if (!c.success) return d("WAResultOrError").makeError("missing");
                c = c.value;
                var e = c.defaultPreview,
                    f = c.favicon,
                    g = c.header;
                c = c.previews;
                return d("WAResultOrError").makeResult({
                    associatedMessage: a,
                    defaultPreview: e,
                    favicon: f,
                    header: g,
                    previews: c,
                    xma: b
                })
            })
        })
    }

    function e(a, b) {
        return h(a, b).then(function(b) {
            if (b == null) return;
            return d("MAWDbMsgTxns").maybeGetMsg(a, b.msgId)
        })
    }

    function f(a, b) {
        if (b.length === 0) return d("MAWDexieTable").dexieResolve([]);
        b = b.filter(d("MAWDbMsg").isXMAMsg).map(function(a) {
            return d("MAWJidUtils").maybeToProtocolMsgId(a.author, a.threadJid, a.externalId)
        }).filter(Boolean);
        b = b.map(function(b) {
            return i(a, b)
        });
        return d("MAWDexieTable").dexieAll(b).then(function(a) {
            return a.filter(Boolean)
        })
    }

    function j(a, b) {
        return a.xma.where("associatedMessageId").anyOf(b).toArray().then(function(a) {
            a = a.filter(function(a) {
                return a.msgId != null && d("MAWXMAUtils").isXMAShare(a.targetType)
            });
            return a.reduce(function(a, b) {
                return b.associatedMessageId != null && b.msgId != null ? a.set(b.associatedMessageId, b.msgId) : a
            }, new Map())
        })
    }

    function k(a, b) {
        return a.xma.where("associatedMessageId").equals(b).first()
    }

    function l(a, b) {
        return a.xma.where("associatedMessageId").equals(b).first().then(function(b) {
            if (b == null) return;
            b = d("MAWJidUtils").maybeToProtocolMsgId(b.author, b.threadJid, b.externalId);
            if (b == null) return;
            return d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, b)
        })
    }

    function m(a, b) {
        return k(a, b).then(function(b) {
            return b == null ? d("WAResultOrError").makeResult() : d("MAWDexieTable").dexieAll([d("MAWDbMediaTxns").getMediaForXMA(a, b), d("MAWDbMsgTxns").maybeGetMsg(a, b.associatedMessageId)]).then(function(a) {
                var c = a[0];
                a = a[1];
                if (!c.success) return d("WAResultOrError").makeError("missing");
                c = c.value;
                var e = c.defaultPreview,
                    f = c.favicon,
                    g = c.header;
                c = c.previews;
                return d("WAResultOrError").makeResult({
                    associatedMessage: a,
                    defaultPreview: e,
                    favicon: f,
                    header: g,
                    previews: c,
                    xma: b
                })
            })
        })
    }

    function n(a, b, c) {
        return d("MAWDbThreadTxns").getThread(a, c).then(function(c) {
            if (!c.success) return;
            c = c.value;
            if (b == null) return d("MAWDexieTable").dexieResolve();
            c = {
                author: b.author,
                chat: c.jid,
                externalId: b.externalId
            };
            return d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, c)
        })
    }
    g.bulkGetXMAs = a;
    g.maybeGetXMAFromXMAId = b;
    g.maybeGetXMAFromAssociatedMsgId = h;
    g.maybeGetXMAFromProtocolMsgId = i;
    g.maybeGetXMAPayloadFromProtocolMsgId = c;
    g.getDbXMAMsgFromAssociatedMsgId = e;
    g.getXMAFromMsgs = f;
    g.getXMAMsgIdsFromAssociatedMsgIds = j;
    g.maybeGetDbXMAMsgByAssociatedMsgId = l;
    g.maybeGetXMAPayloadFromAssociatedMsgId = m;
    g.maybeGetAssociatedXMAMsg = n
}), 98);
__d("MAWUpdateThreadMsgMetadataApi", ["MAWDbThreadTxns", "MAWDexieTable", "MAWIndexedDb", "MAWTransactionMode", "WALogger", "WATimeUtils", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updated oldestMsg from id ", " to id ", " when oldestMsg is undefined"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updated newestMsg from id ", " to id ", ", and newestMsgTs from ", " to ", " when newestMsg is undefined"]);
        i = function() {
            return a
        };
        return a
    }
    a = d("MAWIndexedDb").makeMsgrTransactor({
        threads: d("MAWTransactionMode").READWRITE
    }, "updateThreadMsgMetadataApiTransactor", function(a) {
        return function(b, e, f, g, j) {
            var k = e === (f == null ? void 0 : f.msgId),
                l = g === (j == null ? void 0 : j.msgId);
            if (k && l) return d("MAWDexieTable").dexieResolve();
            l || d("WALogger").ERROR(i(), g, j == null ? void 0 : j.msgId, b.newestMsgTs, (j == null ? void 0 : j.ts) == null ? null : d("WATimeUtils").castUnixTimeToMillisTime(j.ts));
            k || d("WALogger").ERROR(h(), e, f == null ? void 0 : f.msgId);
            return d("MAWDbThreadTxns").updateThreadMsgsForUndefinedOldestOrNewestMsgs(a, b, e, f, g, j).then(c("emptyFunction"))
        }
    });
    b = a;
    g["default"] = b
}), 98);
__d("MAWDbPendingStanza", ["WAAssertUnreachable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "revoked",
        i = "deleteForMe",
        j = "deleteThread";
    b = "Revoked";
    d = "DeleteForMe";
    e = "DeleteThread";
    f = {
        DELETE_FOR_ME: d,
        DELETE_THREAD: e,
        REVOKED: b
    };

    function a(a) {
        switch (a) {
            case "Revoked":
                return h;
            case "DeleteForMe":
                return i;
            case "DeleteThread":
                return j;
            default:
                return c("WAAssertUnreachable")(a)
        }
    }
    g.PENDING_REVOKED = h;
    g.PENDING_DELETE_FOR_ME = i;
    g.REVOKED = b;
    g.DELETE_FOR_ME = d;
    g.PENDING_TYPE = f;
    g.getPendingSuffix = a
}), 98);
__d("MAWEBBackendQPLUtils", ["MAWEBSwitch", "MAWQplProxy", "gkx", "hashString", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return c("hashString")(a)
    }

    function a(a, b) {
        if (c("gkx")("23946") !== !0) return;
        var e = h(b);
        d("MAWQplProxy").startQplUserFlow(c("qpl")._(521485625, "1876"), {
            bool: {
                eb_switch: c("MAWEBSwitch").isEnabled(),
                is_retroactive_backups_upload: a
            },
            string: {
                trace_id: b
            }
        }, e)
    }

    function b(a, b, e) {
        if (c("gkx")("23946") !== !0 || a == null) return;
        a = h(a);
        d("MAWQplProxy").sendQplPointThroughBridge(c("qpl")._(521485625, "1876"), b, {
            annotations: e,
            instanceKey: a
        })
    }

    function e(a, b, e) {
        if (c("gkx")("23946") !== !0 || a == null) return;
        a = h(a);
        d("MAWQplProxy").sendQPLFailThroughBridge(c("qpl")._(521485625, "1876"), b, e, a)
    }
    g.getQplInstanceKey = h;
    g.startEBBackupUploadQplUserFlow = a;
    g.addPointEBBackupUpload = b;
    g.endFailEBBackupUpload = e
}), 98);
__d("MAWEBUploadMessageUtils", ["I64", "MAWDbMsg", "MAWExtractMsFromExternalId", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[sortOrder] externalId is not a valid int64"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[sortOrder] Timestamp bits in externalId not valid"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[sortOrder] ExternalId is not present"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["echoOverrideMessageSortOrder called without ID"]);
        l = function() {
            return a
        };
        return a
    }

    function a(a) {
        var b = a.revokedExternalId != null ? a.revokedExternalId : a.externalId;
        b == null && d("WALogger").ERROR(l());
        b = (h || (h = d("I64"))).of_string_opt(b);
        if (a.serverTs == null) {
            if (a.sortOrderMs != null) return a.sortOrderMs;
            b == null && d("WALogger").WARN(k());
            var c = b == null ? null : d("MAWExtractMsFromExternalId").extractMsFromExternalId(b);
            return d("MAWDbMsg").getCanonicalTsFromMsg(a) * 1e3 + ((c = c) != null ? c : 0)
        }
        if (b != null) {
            c = d("MAWExtractMsFromExternalId").extractMsFromExternalId(b);
            if (c != null) {
                b = a.originalTs != null ? a.originalTs : a.serverTs;
                return Number(b) * 1e3 + c
            } else d("WALogger").WARN(j())
        } else d("WALogger").WARN(i());
        return d("MAWDbMsg").getSortOrderWithFallback(a)
    }
    g.echoOverrideMessageSortOrder = a
}), 98);
__d("MAWEncryptedBackupCacheManager", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = new Map(),
        h = new Map(),
        i = new Map();

    function a(a, b) {
        h.set(a, {
            cache: b,
            status: "restoring"
        })
    }

    function b(a) {
        a.forEach(function(a) {
            var b = h.get(a);
            b != null && h.set(a, {
                cache: b.cache,
                status: "done"
            })
        })
    }

    function c(a) {
        a = h.get(a);
        if (a != null) return a.status;
        else return "none"
    }

    function d(a) {
        return (a = h.get(a)) == null ? void 0 : a.cache
    }

    function e(a) {
        return h["delete"](a)
    }

    function j(a, b) {
        var c = g.get(a) || new Set();
        c.add(b);
        g.set(a, c)
    }

    function k(a, b) {
        a = g.get(a);
        return a != null ? a == null ? void 0 : a.has(b) : !1
    }

    function l(a, b) {
        a = g.get(a);
        a != null && a["delete"](b)
    }

    function m(a) {
        return h.has(a)
    }

    function n(a) {
        return i.has(a)
    }

    function o(a) {
        return i.get(a)
    }

    function p(a) {
        n(a) && i["delete"](a)
    }

    function q(a, b) {
        i.set(a, b)
    }
    f.restoredCache = h;
    f.addMsgEntryToRestoredCache = a;
    f.setRestoredCacheStatusAsDone = b;
    f.getRestoredCacheStatus = c;
    f.getRestoredCache = d;
    f.removeFromRestoredCache = e;
    f.addMsgEntryToReuploadCache = j;
    f.checkForMsgEntryInReuploadCache = k;
    f.removeMsgEntryFromReuploadCache = l;
    f.peekRestoreCache = m;
    f.peekPendingStanzaCache = n;
    f.getPendingStanzaCacheValue = o;
    f.removePendingStanzaCacheValue = p;
    f.addPendingStanzaToPendingStanzaCache = q
}), 66);
__d("WAProtocolMsgId", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a.externalId === b.externalId && a.author === b.author && a.chat === b.chat
    }
    f.equals = a
}), 66);
__d("EBUploadMessages", ["$InternalEnum", "EchoBackupCompareUtils", "EchoMessage", "LSDataTraceCheckPoint", "LSDataTraceType", "LSEBPayloadSerializerError", "LSIntEnum", "LSMEBTaskCreationSource", "MAWBridge", "MAWBridgeEventTransmitter", "MAWBridgeTrace", "MAWBridgeUpload", "MAWConstants", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbMsgUtil", "MAWDbPendingStanza", "MAWDbThreadTxns", "MAWDexieTable", "MAWEBBackendQPLUtils", "MAWEBSwitch", "MAWEBUploadMessageUtils", "MAWEBUploadTrackingUtils", "MAWEncryptedBackupCacheManager", "MAWHMACKey", "MAWHandlePendingStanzasInRestoreV2", "MAWIndexedDb", "MAWMediaUtils", "MAWMsgType", "MAWQplProxy", "MAWTraceUtils", "MAWTransactionMode", "Promise", "WAGlobals", "WAJids", "WALogger", "WAProtocolMsgId", "WAStanzaUtils", "WATimeUtils", "asyncToGeneratorRuntime", "cr:2172", "cr:5916", "gkx", "qpl", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot proceed with encodeAndSendEchoMessage: Encrypted Backups are not enabled"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Cannot proceed with encodeAndSendEchoMessage: Encrypted Backups are not enabled"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] attachmentContextArray is null, type: ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Duplicated upload stopped by cache, extId: ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] extId is null, source: ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] threadJid is null for pendingStanza"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] externalId is null for pendingStanza"]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] pendingStanzaMessageType: ", " not supported"]);
        v = function() {
            return a
        };
        return a
    }
    var w = c("requireDeferred")("EchoSerializationFailureFalcoEvent").__setRef("EBUploadMessages"),
        x = c("requireDeferred")("EchoSerializationSuccessFalcoEvent").__setRef("EBUploadMessages");

    function a(a) {
        return a == null ? [] : a.filter(Boolean).map(function(a) {
            if (a != null) return d("MAWDbMsg").toMsgId(a)
        }).filter(Boolean)
    }
    var y = b("$InternalEnum").Mirrored(["FATAL", "WARN"]);

    function z(a, b) {
        return a.messages.bulkGet(b).then(function(a) {
            return a.filter(Boolean)
        })
    }

    function A(a, b) {
        return a.pendingStanzas.bulkGet(b).then(function(a) {
            return a.filter(Boolean).map(function(a) {
                var b = a.pendingContent.type;
                if (b == null || b !== d("MAWDbPendingStanza").PENDING_TYPE.REVOKED && b !== d("MAWDbPendingStanza").PENDING_TYPE.DELETE_FOR_ME) {
                    d("WALogger").WARN(v(), b);
                    return
                }
                b = a.pendingContent.content.externalId;
                if (b == null) {
                    d("WALogger").WARN(u());
                    return
                }
                b = a.pendingContent.content.threadJid;
                if (b == null) {
                    d("WALogger").WARN(t());
                    return
                }
                d("MAWHandlePendingStanzasInRestoreV2").issuePointQueryForPendingStanza(a)
            })
        }).then(function(a) {
            return []
        })
    }

    function B(a, b) {
        return a.reactions.bulkGet(b).then(function(b) {
            b = b.filter(Boolean).map(function(b) {
                return d("MAWDbThreadTxns").getThread(a, b.threadJid).then(function(e) {
                    var f = e.success ? e.value : null;
                    if (f != null && f.chatId != null) {
                        e = b.reactToAuthor;
                        e = e === d("WAGlobals").getMyUserJid() ? d("WAJids").AUTHOR_ME : e;
                        return d("MAWDbMsgTxns").maybeGetMsgByExternalId(a, b.reactToExternalId, f.jid, e).then(function(a) {
                            if (a == null && !d("MAWEncryptedBackupCacheManager").peekRestoreCache(b.reactToExternalId)) {
                                var e = d("WAJids").threadIdForChatJid(f.jid);
                                d("MAWEncryptedBackupCacheManager").addMsgEntryToReuploadCache(f.jid, b.reactToExternalId);
                                d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(b.reactToExternalId, e, void 0, c("LSMEBTaskCreationSource").POINT_QUERY_FROM_EB, f.jid)
                            }
                            return a
                        })
                    }
                })
            });
            return d("MAWDexieTable").dexieAll(b).then(function(a) {
                return a.filter(Boolean)
            })
        })
    }

    function C(a, b) {
        b = b.filter(Boolean);
        return a.xma.bulkGet(b).then(function(b) {
            b = b.map(function(a) {
                return a == null ? void 0 : a.associatedMessageId
            }).filter(Boolean);
            return a.messages.where("msgId").anyOf(b).toArray()
        })
    }

    function D(a, c, e) {
        c.forEach(function(a) {
            if (a.uploadTrackingInstanceKey != null)
                if (b("cr:2172") != null) d("MAWEBUploadTrackingUtils").addPointWorkerOnly(a.uploadTrackingInstanceKey, "fire_ebls_upload");
                else if (T()) {
                var c;
                d("MAWEBUploadTrackingUtils").addPointWorkerOnly((c = a.uploadTrackingInstanceKey) != null ? c : 0, "fire_gql_upload_ui_event")
            } else {
                d("MAWEBUploadTrackingUtils").addPointWorkerOnly((c = a.uploadTrackingInstanceKey) != null ? c : 0, "fire_ui_event")
            }
        });
        if (b("cr:2172") != null) return b("cr:2172").uploadMessagesFromWorker(c);
        else return d("MAWBridge").getBridge().sendAndReceive("event", "uploadMessagesToBackup", {
            checkPoint: a,
            messages: c,
            qpl: e
        })
    }

    function E(a, b, e) {
        var f = [],
            g = [];
        if (a != null) {
            var h = c("gkx")("23946"),
                i = c("qpl")._(521485625, "1876");
            b.forEach(function(b) {
                var c = b.checkPoint;
                b = b.pointName;
                h && b != null && f.push({
                    action: {
                        name: b,
                        type: "point"
                    },
                    annotations: null,
                    event: i,
                    instanceKey: d("MAWEBBackendQPLUtils").getQplInstanceKey(a),
                    timestamp: d("MAWQplProxy").performanceAbsoluteNow()
                });
                g.push(d("MAWBridgeTrace").createBridgeTraceRecordCheckpointData((j || (j = d("LSIntEnum"))).ofNumber(c), (b = e) != null ? b : a, void 0, !1, -1, void 0))
            })
        }
        return {
            checkPointArray: g,
            qplArray: f
        }
    }

    function F(a, b, c, e, f, g, h) {
        var i = b == null ? void 0 : b.externalId;
        if (i == null) {
            d("WALogger").ERROR(s(), h);
            return null
        }
        if (d("MAWEncryptedBackupCacheManager").getRestoredCacheStatus(i) === "done") {
            var j = d("EchoBackupCompareUtils").buildEchoDocCacheValue(a);
            j = d("EchoBackupCompareUtils").echoEquals(j, d("MAWEncryptedBackupCacheManager").getRestoredCache(i));
            d("MAWEncryptedBackupCacheManager").removeFromRestoredCache(i);
            if (j) {
                d("WALogger").LOG(r(), i);
                L("success", f, i, "construct_echo_success_duplicate_message", {
                    string: {
                        errorMsg: "not unique from cache"
                    }
                });
                return null
            }
        }
        if (b != null && c != null) {
            j = window.performance.now();
            var k = d("EchoMessage").encodeEchoMessage(a),
                l = window.performance.now();
            g = g == null ? void 0 : g.get(i);
            g == null && d("MAWMediaUtils").getMediaTypeFromMsgType(b.type) != null && h === "upload_queue" && d("WALogger").ERROR(q(), b.type);
            L("point", f, b.externalId, "construct_echo_success");
            H(b.externalId, c);
            return d("MAWBridgeUpload").createBridgeUploadMessage({
                actionType: 1,
                attachmentContextArray: g,
                authTs: b.serverTs,
                echoDocument: k,
                echoEncodingLatencyNs: (l - j) * 1e6,
                errorCode: null,
                errorMessage: null,
                messageId: i,
                messageType: b.type,
                productType: "msgr",
                protoMsg: e,
                sortOrderMs: d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(b),
                threadId: a.threadId,
                traceId: c,
                uploadTrackingInstanceKey: K(f, b.externalId)
            })
        }
        return null
    }

    function G(a, b) {
        a != null && void w.load().then(function(c) {
            return c.log(function() {
                return {
                    message_id: a,
                    trace_id: b
                }
            })
        })
    }

    function H(a, b) {
        a != null && void x.load().then(function(c) {
            return c.log(function() {
                return {
                    message_id: a,
                    trace_id: b
                }
            })
        })
    }

    function I(a, b, c) {
        if (a == null || b == null) return c;
        else {
            b = K(b, a.externalId);
            if (b != null) return b.toString();
            else return c
        }
    }

    function J(a, e, f, g, h) {
        var i = new Map();
        a.forEach(function(a) {
            return i.set(a.dbMsg.externalId, a)
        });
        N(g, a.map(function(a) {
            return {
                extId: a.dbMsg.externalId,
                type: a.dbMsg.type
            }
        }), "encode_and_send_echo_message", f, h);
        return O(a).then(function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                var b = a.map(function(a) {
                    var b, k = i.get(a.externalId) || {
                            dbMsg: null,
                            traceId: null
                        },
                        l = k.dbMsg;
                    k = k.traceId;
                    b = l != null ? (b = e == null ? void 0 : e.find(function(a) {
                        var b = a.originalMsgProtocolId,
                            c = d("MAWDbMsgUtil").getProtocolMsgIdFromDbMsg(l);
                        if (c == null) return !1;
                        if (a.backupActionType === 2 && b != null) {
                            var e = b.author,
                                f = b.chat;
                            b = b.externalId;
                            if (e != null && f != null && b != null) return d("WAProtocolMsgId").equals({
                                author: e,
                                chat: f,
                                externalId: b
                            }, c)
                        }
                        return d("WAProtocolMsgId").equals(a.msgId, c)
                    })) != null ? b : void 0 : void 0;
                    var m = a.echoMessage,
                        n = [],
                        o = I(l, f, k);
                    if (a.maybeErrorDetail != null) {
                        a = a.maybeErrorDetail;
                        if (l != null && k != null)
                            if (a.uploadErrorType === y.WARN || a.errorCode === c("LSEBPayloadSerializerError").MEDIA_INFO_INVALID) {
                                var q;
                                q = a.uploadErrorType === y.WARN ? "possible error when constructing echo message: " + ((q = a.errorMsg) != null ? q : "") : "media info invalid thrown from constructEchoMessage, error msg: " + ((q = a.errorMsg) != null ? q : "");
                                d("WALogger").WARN(p(), q);
                                L("success", f, l.externalId, "construct_echo_success_media/xma_warn/error", {
                                    string: {
                                        errorMsg: q
                                    }
                                });
                                G(l.externalId, k)
                            } else {
                                q = d("MAWBridgeUpload").createBridgeUploadMessage({
                                    actionType: 1,
                                    authTs: l.serverTs,
                                    echoDocument: null,
                                    echoEncodingLatencyNs: null,
                                    errorCode: a.errorCode,
                                    errorMessage: a.errorMsg,
                                    messageId: (q = m == null ? void 0 : m.xOfflineThreadingId) != null ? q : "0",
                                    messageType: l.type,
                                    protoMsg: b,
                                    sortOrderMs: d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(l),
                                    threadId: (q = m == null ? void 0 : m.threadId) != null ? q : "0",
                                    traceId: k,
                                    uploadTrackingInstanceKey: K(f, l.externalId)
                                });
                                L("fail", f, l.externalId, "construct_echo_failed", {
                                    string: {
                                        errorMsg: (a = a.errorMsg) != null ? a : "null error msg, msg type: " + l.type
                                    }
                                });
                                H(l.externalId, k);
                                return {
                                    bridgeUploadMessage: q,
                                    toCheckPoint: null,
                                    toQPL: null
                                }
                            }
                        return null
                    }
                    if ((m == null ? void 0 : m.xOfflineThreadingId) == null) {
                        if (l != null && k != null) {
                            q = d("MAWBridgeUpload").createBridgeUploadMessage({
                                actionType: 1,
                                authTs: l.serverTs,
                                echoDocument: null,
                                echoEncodingLatencyNs: null,
                                errorCode: c("LSEBPayloadSerializerError").OTID_NOT_FOUND_IN_ACT_MESSAGES,
                                errorMessage: null,
                                messageId: "0",
                                messageType: l.type,
                                protoMsg: b,
                                sortOrderMs: d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(l),
                                threadId: (a = m == null ? void 0 : m.threadId) != null ? a : "0",
                                traceId: k,
                                uploadTrackingInstanceKey: K(f, l.externalId)
                            });
                            L("fail", f, l.externalId, "construct_echo_failed", {
                                string: {
                                    errorMsg: "oitd not found"
                                }
                            });
                            H(l.externalId, k);
                            return {
                                bridgeUploadMessage: q,
                                toCheckPoint: null,
                                toQPL: null
                            }
                        }
                        return null
                    } else {
                        a = F(m, l, k, b, f, g, h);
                        if (a == null) return null;
                        n.push({
                            checkPoint: c("LSDataTraceCheckPoint").LABYRINTH_WEB_UPLOAD_ISSUE_MESSAGE_UPLOAD_UI_EVENT,
                            pointName: "issue_message_upload_ui_event"
                        });
                        q = E(k, n, o);
                        m = q.checkPointArray;
                        b = q.qplArray;
                        d("MAWTraceUtils").startNewTrace((j || (j = d("LSIntEnum"))).ofNumber(c("LSDataTraceType").ENCRYPTED_BACKUPS_UPLOAD), d("MAWTraceUtils").CONTEXT_BACKUP_UPLOAD, o);
                        return {
                            bridgeUploadMessage: a,
                            toCheckPoint: m,
                            toQPL: b
                        }
                    }
                }).filter(Boolean);
                while (b.length > 0) {
                    var k = [],
                        l = [],
                        m = [];
                    while (k.length < d("MAWConstants").BRIDGE_UPLOAD_BATCH_SIZE && b.length > 0) {
                        var n = b.shift();
                        n != null && (k.push(n.bridgeUploadMessage), n.toCheckPoint != null && m.push.apply(m, n.toCheckPoint), n.toQPL != null && l.push.apply(l, n.toQPL))
                    }
                    yield D(m, k, l)
                }
                return a
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }())
    }

    function K(a, b) {
        return a.get(b)
    }

    function L(a, b, c, e, f) {
        b = K(b, c);
        if (b != null) switch (a) {
            case "success":
                d("MAWEBUploadTrackingUtils").endSuccessWorkerOnly(b, e, f);
                break;
            case "fail":
                d("MAWEBUploadTrackingUtils").endFailWorkerOnly(b, e, f);
                break;
            case "point":
                d("MAWEBUploadTrackingUtils").addPointWorkerOnly(b, e, f);
                break
        }
    }

    function M(a) {
        var b = new Set(),
            c = [];
        a.forEach(function(a) {
            var e = a.externalId + "|" + d("WAJids").threadIdForChatJid(a.threadJid) + "|" + a.author;
            d("MAWEncryptedBackupCacheManager").getRestoredCacheStatus(a.externalId) !== "restoring" && !b.has(e) && (b.add(e), c.push(a))
        });
        return c
    }

    function e(a, e, f, g, h, j, k) {
        if (!c("MAWEBSwitch").isEnabled()) {
            d("WALogger").LOG(o());
            h.forEach(function(a, b) {
                d("MAWEBUploadTrackingUtils").endSuccessWorkerOnly(a, "upload_tracking_cancelled_eb_turned_off_upload", {
                    string: {
                        externalId: b,
                        from: "uploadUniqueMessage"
                    }
                })
            });
            return (i || (i = b("Promise"))).resolve()
        }
        a = M(a).filter(function(a) {
            return d("MAWEBUploadTrackingUtils").isUploadSupported(a)
        }).map(function(a) {
            var b;
            b = (b = f) != null ? b : !1;
            L("point", h, a.externalId, "construct_echo_start", {
                bool: {
                    isMedia: d("MAWMsgType").isMAWSupportedMediaType(a.type),
                    isRetroactiveBackupsUpload: b
                },
                string: {
                    msgType: a.type
                }
            });
            b = ((b = K(h, a.externalId)) != null ? b : d("MAWTraceUtils").createTraceId()).toString();
            d("MAWEBBackendQPLUtils").startEBBackupUploadQplUserFlow(f, b);
            f != null && f && d("MAWEBBackendQPLUtils").addPointEBBackupUpload(b, "retroactive_backup_upload_started");
            return {
                lastRetryTs: d("WATimeUtils").millisTime(),
                msg: a,
                retriedTimes: 0,
                traceId: b
            }
        });
        return Q(a.filter(function(a) {
            return a.msg.type !== d("MAWMsgType").MSG_TYPE.RAVEN
        }).map(function(a) {
            var b = a.msg.quoteExternalId;
            if (b != null) return {
                dbMsg: a.msg,
                quotedMsg: e == null ? void 0 : e.get(b),
                traceId: a.traceId
            };
            else return {
                dbMsg: a.msg,
                traceId: a.traceId
            }
        }), g, j, h, new Map(), k).then(function() {
            return (i || (i = b("Promise"))).resolve()
        })
    }

    function N(a, b, c, d, e) {
        e === void 0 && (e = "upload_queue");
        if (e !== "upload_queue") return;
        e = a.size;
        var f = b.length;
        for (b of b)
            if (!a.has(b.extId)) {
                var g;
                b.type != null ? g = {
                    mismatch_msg_type: b.type,
                    missing_extId: b.extId
                } : g = {
                    missing_extId: b.extId
                };
                L("point", d, b.extId, c, {
                    "int": {
                        dbMsgsSize: f,
                        uploadEntitySize: e
                    },
                    string: g
                })
            }
    }

    function f(a, e, f, g) {
        if (!c("MAWEBSwitch").isEnabled()) {
            d("WALogger").LOG(n());
            e.forEach(function(a, b) {
                d("MAWEBUploadTrackingUtils").endSuccessWorkerOnly(a, "upload_tracking_cancelled_eb_turned_off_upload", {
                    string: {
                        externalId: b,
                        from: "uploadMessageFromUploadQueue"
                    }
                })
            });
            return (i || (i = b("Promise"))).resolve()
        }
        return Q(a.filter(function(a) {
            var b = d("MAWEBUploadTrackingUtils").isUploadSupported(a) && a.type !== d("MAWMsgType").MSG_TYPE.RAVEN;
            b || L("success", e, a.externalId, "upload_not_supported", {
                string: {
                    msgType: a.type
                }
            });
            return b
        }).map(function(a) {
            var b;
            b = ((b = K(e, a.externalId)) != null ? b : d("MAWTraceUtils").createTraceId()).toString();
            L("point", e, a.externalId, "construct_echo_start");
            return {
                dbMsg: a,
                traceId: b
            }
        }), void 0, f, e, g, "upload_queue")
    }
    var O = d("MAWIndexedDb").makeMsgrTransactor({
        editMsgHistory: (h = d("MAWTransactionMode")).READONLY,
        media: h.READONLY,
        mediaBackup: h.READONLY,
        messages: h.READONLY,
        reactions: h.READONLY,
        receiverFetchInfo: h.READONLY,
        threads: h.READONLY,
        xma: h.READONLY
    }, "constructEchoMessage", function(a) {
        return function() {
            for (var c = arguments.length, d = new Array(c), e = 0; e < c; e++) d[e] = arguments[e];
            return b("cr:5916").constructEchoMessage.apply(b("cr:5916"), [a].concat(d))
        }
    });

    function P(a, b, e, f, g) {
        b = z(a, b);
        c("gkx")("2251") ? A(a, e) : d("MAWDexieTable").dexieResolve();
        e = B(a, f);
        f = C(a, g);
        return d("MAWDexieTable").dexieAll([b, e, f]).then(function(a) {
            return a.flat()
        })
    }

    function Q(a, e, f, g, h, n) {
        var o = new Map();
        N(h, a.map(function(a) {
            return {
                extId: a.dbMsg.externalId,
                type: a.dbMsg.type
            }
        }), "construct_echo_msg", g, n);
        a.forEach(function(a) {
            var b = a.dbMsg;
            a = a.traceId;
            d("MAWEBBackendQPLUtils").addPointEBBackupUpload(a, "echo_message_upload_begin", {
                string: {
                    message_type: b.type
                }
            });
            var f = d("MAWQplProxy").startQplUserFlow(c("qpl")._(521475102, "868"), {
                bool: {
                    eb_switch: c("MAWEBSwitch").isEnabled()
                },
                "int": {
                    sort_order: b.sortOrderMs
                },
                string: {
                    hashed_msgid: R(b.externalId),
                    message_id: b.externalId,
                    message_type: b.type.toString(),
                    org_trace_id: e == null ? void 0 : e.get(b.externalId),
                    trace_id: a
                }
            });
            o.set(b.externalId, {
                constructEchoFlow: f,
                traceId: a
            })
        });
        a = J(a, f, g, h, n)["catch"](function(a) {
            a = "[labyrinth_web] Error while encode and upload message to backup: " + String(a);
            d("WALogger").ERROR(m(), a);
            for (var e of o.values()) d("MAWEBBackendQPLUtils").endFailEBBackupUpload(e.traceId, "echo_message_upload_failure", {
                string: {
                    error_message: a
                }
            }), d("MAWTraceUtils").recordFailureAndFlushForTraceId(e.traceId, (j || (j = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_ECHO_MESSAGE_UPLOAD_FAILURE), [], a), e.constructEchoFlow.endFail("serialisation_failure");
            return (i || (i = b("Promise"))).resolve()
        });
        return a.then(function(a) {
            a == null ? void 0 : a.forEach(function(a) {
                var b;
                b = (b = a.echoMessage) == null ? void 0 : b.messageId;
                if (b != null && o.has(d("WAStanzaUtils").toStanzaId(b))) {
                    var e;
                    b = o.get(d("WAStanzaUtils").toStanzaId(b)) || {
                        constructEchoFlow: null,
                        traceId: null
                    };
                    var f = b.constructEchoFlow;
                    b = b.traceId;
                    e = a == null ? void 0 : (e = a.maybeErrorDetail) == null ? void 0 : e.uploadErrorType;
                    a = a == null ? void 0 : (a = a.maybeErrorDetail) == null ? void 0 : a.errorMsg;
                    if (e != null) switch (e) {
                        case y.WARN:
                            a != null && d("WALogger").WARN(l(), a);
                            f == null ? void 0 : f.endSuccess({
                                bool: {
                                    is_skipped: !0
                                }
                            });
                            b != null && (d("MAWEBBackendQPLUtils").addPointEBBackupUpload(b, "echo_message_upload_invalid_request"), d("MAWTraceUtils").recordInvalidUploadRequestAndFlushTrace(b, (j || (j = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_ECHO_MESSAGE_UPLOAD_INVALID_REQUEST), []));
                            break;
                        case y.FATAL:
                            a = (e = a) != null ? e : "[labyrinth_web] unknown error in the upload message flow";
                            d("WALogger").ERROR(k(), a);
                            b != null && (d("MAWEBBackendQPLUtils").endFailEBBackupUpload(b, "echo_message_upload_failure", {
                                string: {
                                    error_message: a
                                }
                            }), d("MAWTraceUtils").recordFailureAndFlushForTraceId(b, (j || (j = d("LSIntEnum"))).ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_ECHO_MESSAGE_UPLOAD_FAILURE), [], a));
                            f == null ? void 0 : f.endFail("serialisation_failure");
                            break
                    } else f == null ? void 0 : f.endSuccess()
                }
            });
            return (i || (i = b("Promise"))).resolve()
        })
    }

    function R(a) {
        if (a == null) return "";
        var b = d("WAGlobals").getHMACKey();
        return d("MAWHMACKey").hmacTweetNaCl(a, b)
    }

    function S(a, b) {
        var e = d("MAWTraceUtils").startNewTrace((j || (j = d("LSIntEnum"))).ofNumber(c("LSDataTraceType").ENCRYPTED_BACKUPS_UPLOAD), d("MAWTraceUtils").CONTEXT_BACKUP_UPLOAD);
        d("MAWTraceUtils").recordCheckpointForTrace(e, j.ofNumber(c("LSDataTraceCheckPoint").LABYRINTH_WEB_ECHO_MESSAGE_UPLOAD_BEGIN), [d("MAWTraceUtils").getTagForMsgType(a.type)], !1);
        d("MAWIndexedDb").afterTransaction({
            tag: "UploadMessage",
            value: d("MAWBridgeUpload").createBridgeUploadMessage({
                actionType: 2,
                authTs: a.serverTs,
                echoDocument: null,
                echoEncodingLatencyNs: null,
                errorCode: null,
                errorMessage: null,
                messageId: a.externalId,
                messageType: a.type,
                sortOrderMs: d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(a),
                threadId: d("WAJids").threadIdForChatJid(b),
                traceId: e,
                uploadTrackingInstanceKey: null
            })
        })
    }

    function T() {
        return c("gkx")("381")
    }
    g.convertStringMsgIdtoMsgId = a;
    g.UploadErrorType = y;
    g.deduplicateMessageArray = M;
    g.uploadUniqueMessage = e;
    g.logIfExtIdsNotInAttachmentContextArrayMap = N;
    g.uploadMessageFromUploadQueue = f;
    g.getMessagesBackupForUpload = P;
    g.sendDeleteEchoMessage = S
}), 98);
__d("MAWBridgeThread", ["MAWTimeUtils", "WAJids", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c, e, f) {
        var g = d("WAJids").switchOnMsgrChatJidType(a.jid, {
            group: function(a) {
                return !0
            },
            user: function(a) {
                return !1
            }
        });
        return {
            authoritativeThreadKey: c,
            cannotReplyReason: a.cannotReplyReason,
            clientThreadKey: b,
            description: e,
            folder: a.folder,
            isGroup: g,
            jid: a.jid,
            lastActivityTs: d("MAWTimeUtils").ensureValidMillisTime(a.snippetMsgTs != null && d("WATimeUtils").fromMillisTime(a.snippetMsgTs) !== 0 ? a.snippetMsgTs : f) || d("WATimeUtils").castToMillisTime(0),
            lastReadTs: d("MAWTimeUtils").ensureValidMillisTime(a.lastReadMsgTs) || d("WATimeUtils").castToMillisTime(0),
            muteExpireTimeMs: (c = a.muteExpireTimeMs) != null ? c : 0
        }
    }

    function b(a, b, c, d) {
        return {
            lastActivityTimestampMs: c,
            lastReadWatermarkTs: b,
            markUnread: d,
            threadJid: a
        }
    }
    g.createBridgeThread = a;
    g.createBridgeThreadTimestampsUpdated = b
}), 98);
__d("MAWGetOrCreateThreadTxns", ["MAWAdminMsgTxns", "MAWBridgeThread", "MAWBridgeTypesCreators", "MAWDbMsgTxns", "MAWDbThread", "MAWDexieTable", "MAWFolderTypes", "MAWIndexedDb", "MAWQplProxy", "MAWWriteBulkWriteIncomingAdminMsgTxns", "WATimeUtils", "getErrorSafe", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        if (a != null && b != null) {
            var c = d("WATimeUtils").fromMillisTime(a),
                e = d("WATimeUtils").fromMillisTime(b);
            return d("WATimeUtils").castToMillisTime(Math.max(c, e))
        }
        return (c = a) != null ? c : b
    }

    function i(a, b) {
        return a.threads.get({
            jid: b
        })
    }

    function j(a, b) {
        return a.threads.where("jid").anyOf(b).toArray().then(function(a) {
            var c = new Map();
            for (var a = a, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                c.set(f.jid, f)
            }
            return b.map(function(a) {
                return c.get(a)
            })
        })
    }

    function a(a, b, e) {
        var f = b.deduplicationKey,
            g = b.jid;
        f = b.deduplicationKey != null ? a.threads.get({
            deduplicationKey: f
        }) : d("MAWDexieTable").dexieResolve();
        return d("MAWDexieTable").dexieAll([f, i(a, g)]).then(function(f) {
            var g = f[0];
            f = f[1];
            if (g != null) return {
                created: !1,
                thread: g
            };
            if (f == null) {
                e != null && d("MAWQplProxy").sendQplPointThroughBridge(c("qpl")._(25313175, "1551"), "create-1-1-thread-start", {
                    instanceKey: e
                });
                return l(a, b, e).then(function(a) {
                    return {
                        created: !0,
                        thread: a
                    }
                })
            } else return o(a, b, f).then(function(a) {
                return {
                    created: !1,
                    thread: a
                }
            })
        })
    }

    function b(a, b) {
        var c = b.map(function(a) {
            a = a.deduplicationKey;
            return a
        }).filter(function(a) {
            return a != null
        });
        c = a.threads.where("deduplicationKey").anyOf(c).toArray();
        return d("MAWDexieTable").dexieAll([c, j(a, b.map(function(a) {
            a = a.jid;
            return a
        }))]).then(function(c) {
            var e = c[0];
            c = c[1];
            var f = new Map();
            for (var e = e, g = Array.isArray(e), h = 0, e = g ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (g) {
                    if (h >= e.length) break;
                    i = e[h++]
                } else {
                    h = e.next();
                    if (h.done) break;
                    i = h.value
                }
                i = i;
                i.deduplicationKey != null && f.set(i.deduplicationKey, i)
            }
            var j = {};
            i = [];
            h = [];
            for (g = c.entries(), e = Array.isArray(g), c = 0, g = e ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var k, l;
                if (e) {
                    if (c >= g.length) break;
                    l = g[c++]
                } else {
                    c = g.next();
                    if (c.done) break;
                    l = c.value
                }
                l = l;
                var n = l[0];
                l = l[1];
                k = (k = b[n]) == null ? void 0 : k.deduplicationKey;
                if (k != null) {
                    var o = f.get(k);
                    if (o != null) {
                        j[k] = {
                            created: !1,
                            thread: o
                        };
                        continue
                    }
                }
                l == null ? i.push(b[n]) : h.push({
                    params: b[n],
                    thread: l
                })
            }
            return d("MAWDexieTable").dexieAll([i.length ? m(a, i) : d("MAWDexieTable").dexieResolve([]), h.length ? p(a, h) : d("MAWDexieTable").dexieResolve([])]).then(function(a) {
                var c = a[0];
                a = a[1];
                for (var c = c, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= c.length) break;
                        f = c[e++]
                    } else {
                        e = c.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    j[f.jid] = {
                        created: !0,
                        thread: f
                    }
                }
                for (f = a, e = Array.isArray(f), d = 0, f = e ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    if (e) {
                        if (d >= f.length) break;
                        c = f[d++]
                    } else {
                        d = f.next();
                        if (d.done) break;
                        c = d.value
                    }
                    a = c;
                    j[a.jid] = {
                        created: !1,
                        thread: a
                    }
                }
                return b.map(function(a) {
                    var b = a.deduplicationKey;
                    a = a.jid;
                    if (b != null) {
                        return (b = j[b]) != null ? b : j[a]
                    }
                    return j[a]
                })
            })
        })
    }

    function k(a) {
        var b = a.authoritativeThreadKey,
            c = a.clientThreadKey,
            e = a.createTs,
            f = a.deduplicationKey,
            g = a.folder,
            h = a.jid;
        a = a.lastActivityTimestamp;
        var i = d("WATimeUtils").millisTime();
        e = (a = (a = a) != null ? a : e) != null ? a : i;
        i = {
            authoritativeThreadKey: b != null ? b : void 0,
            deduplicationKey: f,
            folder: g != null ? g : d("MAWFolderTypes").FOLDER_ID.INBOX,
            jid: h,
            lastReadMsg: null,
            lastReadMsgReceiptSent: null,
            newestMsg: null,
            newestMsgTs: e,
            oldestMsg: null,
            optimisticThreadKey: (a = c) != null ? a : void 0,
            threadOrder: d("MAWDbThread").craftThreadOrder(e, h)
        };
        return i
    }

    function l(a, b, e) {
        var f = b.authoritativeThreadKey,
            g = b.description,
            h = b.skipVerifyThread,
            i = k(b);
        return a.threads.add(i).then(function(b) {
            b = babelHelpers["extends"]({}, i, {
                chatId: b
            });
            h !== !0 && d("MAWIndexedDb").afterTransaction({
                tag: "VerifyThreadExists",
                value: d("MAWBridgeThread").createBridgeThread(b, b.optimisticThreadKey, f, g, i.newestMsgTs)
            });
            e != null && d("MAWQplProxy").sendQplPointThroughBridge(c("qpl")._(25313175, "1551"), "write-e2ee-admin-msg-in-new-thread", {
                instanceKey: e
            });
            return d("MAWAdminMsgTxns").writeE2EEThreadDescriptionMsg(a, b, e)
        })["catch"](function(a) {
            a = c("getErrorSafe")(a);
            a.message = "Error creating thread: " + a.message;
            throw a
        })
    }

    function m(a, b) {
        var e = b.map(k);
        return a.threads.bulkAdd(e, {
            allKeys: !0
        }).then(function(c) {
            c = c.map(function(a, c) {
                return {
                    data: babelHelpers["extends"]({}, e[c], {
                        chatId: a
                    }),
                    params: b[c]
                }
            });
            for (var f = c, g = Array.isArray(f), h = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (g) {
                    if (h >= f.length) break;
                    i = f[h++]
                } else {
                    h = f.next();
                    if (h.done) break;
                    i = h.value
                }
                i = i;
                i.params.skipVerifyThread !== !0 && d("MAWIndexedDb").afterTransaction({
                    tag: "VerifyThreadExists",
                    value: d("MAWBridgeThread").createBridgeThread(i.data, i.data.optimisticThreadKey, i.params.authoritativeThreadKey, i.params.description)
                })
            }
            return d("MAWWriteBulkWriteIncomingAdminMsgTxns").writeE2EEAdminMsgsForIncomingCreatedThreads(a, c.map(function(a) {
                return a.data
            }))
        })["catch"](function(a) {
            a = c("getErrorSafe")(a);
            a.message = "Error bulk creating threads: " + a.message;
            throw a
        })
    }

    function n(a, b, c) {
        var d = b.authoritativeThreadKey,
            e = b.clientThreadKey,
            f = b.deduplicationKey,
            g = b.folder;
        b = b.lastActivityTimestamp;
        g = {
            authoritativeThreadKey: (d = d) != null ? d : a.authoritativeThreadKey,
            cannotReplyReason: g != null || e != null ? null : a.cannotReplyReason,
            deduplicationKey: g != null || e != null ? f : a.deduplicationKey,
            folder: (d = g) != null ? d : a.folder,
            newestMsgTs: h(c, b),
            optimisticThreadKey: (f = e) != null ? f : a.optimisticThreadKey
        };
        return babelHelpers["extends"]({}, a, g)
    }

    function o(a, b, e) {
        var f = b.authoritativeThreadKey,
            g = b.description,
            h = b.skipVerifyThread;
        return d("MAWDbMsgTxns").getThreadNewestMessageTs(a, e).then(function(i) {
            var j = n(e, b, i);
            return a.threads.update(e.chatId, j).then(function() {
                var a;
                h !== !0 && d("MAWIndexedDb").afterTransaction({
                    tag: "VerifyThreadExists",
                    value: d("MAWBridgeThread").createBridgeThread(j, j.optimisticThreadKey, f, g, i)
                });
                d("MAWIndexedDb").afterTransaction({
                    tag: "ThreadUpdated",
                    value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                        folder: (a = j == null ? void 0 : j.folder) != null ? a : d("MAWFolderTypes").FOLDER_ID.INBOX,
                        threadJid: j.jid
                    })
                });
                return j
            })["catch"](function(a) {
                a = c("getErrorSafe")(a);
                a.message = "Error updating thread: " + a.message;
                throw a
            })
        })
    }

    function p(a, b) {
        return d("MAWDexieTable").dexieAll(b.map(function(b) {
            var c = b.params,
                e = b.thread;
            return d("MAWDbMsgTxns").getThreadNewestMessageTs(a, e).then(function(a) {
                a = n(e, c, a);
                return {
                    params: c,
                    thread: a
                }
            })
        })).then(function(b) {
            return a.threads.bulkUpdate(b.map(function(a) {
                a = a.thread;
                return {
                    changes: a,
                    key: a.chatId
                }
            })).then(function() {
                for (var a = b, c = Array.isArray(a), e = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (c) {
                        if (e >= a.length) break;
                        f = a[e++]
                    } else {
                        e = a.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    var g = f.params,
                        h = g.authoritativeThreadKey,
                        i = g.description;
                    g = g.skipVerifyThread;
                    f = f.thread;
                    g !== !0 && d("MAWIndexedDb").afterTransaction({
                        tag: "VerifyThreadExists",
                        value: d("MAWBridgeThread").createBridgeThread(f, f.optimisticThreadKey, h, i)
                    });
                    d("MAWIndexedDb").afterTransaction({
                        tag: "ThreadUpdated",
                        value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                            folder: (g = f == null ? void 0 : f.folder) != null ? g : d("MAWFolderTypes").FOLDER_ID.INBOX,
                            threadJid: f.jid
                        })
                    })
                }
                return b.map(function(a) {
                    a = a.thread;
                    return a
                })
            })
        })["catch"](function(a) {
            a = c("getErrorSafe")(a);
            a.message = "Error bulk updating threads: " + a.message;
            throw a
        })
    }
    g.getExistingThread = i;
    g.bulkGetExistingThread = j;
    g.getOrCreateThread = a;
    g.bulkGetOrCreateThread = b;
    g.createThread = l;
    g.bulkCreateThread = m;
    g.prepareUpdatedThreadData = n;
    g.updateThread = o;
    g.bulkUpdateThread = p
}), 98);
__d("MAWLocalizationUtils", ["MAWAckLevel", "MAWExternalId", "MAWLocalizationType", "MAWMsgType", "WAJids", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c, e, f) {
        return {
            ack: d("MAWAckLevel").ACK.sent,
            altIndex: (e = e) != null ? e : void 0,
            author: d("WAJids").AUTHOR_SYSTEM,
            externalId: d("MAWExternalId").generateExternalId(),
            msgContent: a,
            sortOrderMs: f,
            threadJid: b,
            ts: (e = c) != null ? e : d("WATimeUtils").unixTime(),
            type: d("MAWMsgType").MSG_TYPE.ADMIN
        }
    }

    function b(a) {
        switch (a) {
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_NAMED_GROUP:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_NAMED_GROUP:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_NAMED_GROUP:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_ONE_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_MORE_THAN_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU_AND_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU_AND_MORE_THAN_ONE_USERS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_MORE_THAN_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_ONE_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_MORE_THAN_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU_AND_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU_AND_MORE_THAN_ONE_USERS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_MORE_THAN_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_LEFT_GROUP:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SELF_DEMOTED:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_PROMOTED_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_DEMOTED_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_GOT_PROMOTED:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_GOT_DEMOTED:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_GOT_PROMOTED:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_GOT_DEMOTED:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_PROMOTED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_DEMOTED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_PROMOTED_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SELF_DEMOTED:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_DEMOTED_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_UPDATED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_UPDATED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_HOTLIKE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_THEME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_PHOTO:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_PINNED_MESSAGE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_UNPINNED_MESSAGE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_HOTLIKE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_THEME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_PHOTO:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_PINNED_MESSAGE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_UNPINNED_MESSAGE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_PARTICIPANT_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CLEAR_PARTICIPANT_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_CURRENT_USER_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SET_OWN_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_CLEAR_OWN_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_CLEAR_PARTICIPANT_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SET_OWN_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CLEAR_OWN_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_CLEAR_CURRENT_USER_NICKNAME:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_MINUTES:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_MINUTES:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_HOURS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_HOURS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_DAYS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_DAYS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_OFF:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_SECONDS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_SECONDS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_TAKE_SCREENSHOT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_RECORD_SCREEN:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SET_ADD_MODE_ADMIN_ONLY:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SET_ADD_MODE_ALL_MEMBERS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SET_ADD_MODE_ADMIN_ONLY:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SET_ADD_MODE_ALL_MEMBERS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.SERVER_SET_ADD_MODE_ADMIN_ONLY:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.SERVER_SET_ADD_MODE_ALL_MEMBERS:
                return !0
        }
        return !1
    }

    function c(a) {
        switch (a) {
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_UPDATED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_DEVICE:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_UPDATED_DEVICE:
                return !0
        }
        return !1
    }

    function e(a) {
        switch (a) {
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_ONE_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_ADDED_MORE_THAN_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU_AND_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU_AND_MORE_THAN_ONE_USERS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_ADDED_MORE_THAN_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_YOU_AND_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_YOU_AND_MORE_THAN_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_MORE_THAN_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_ONE_PARTICIPANT:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_REMOVED_MORE_THAN_TWO_PARTICIPANTS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU_AND_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU_AND_MORE_THAN_ONE_USERS:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REMOVED_MORE_THAN_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_YOU:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_YOU_AND_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_YOU_AND_MORE_THAN_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_ONE_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_MORE_THAN_TWO_USER:
            case d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_LEFT_GROUP:
                return !0
        }
        return !1
    }
    g.buildUnstoredDbAdminMsg = a;
    g.isAdminMsgNormalized = b;
    g.isDeviceChangeAdminMsg = c;
    g.isParticipantChangeAdminMsg = e
}), 98);
__d("MAWAdminMsgTxns", ["MAWDbMsg", "MAWDbThread", "MAWDbThreadTxns", "MAWLocalizationType", "MAWLocalizationUtils", "MAWTimeUtils", "MAWWriteBulkWriteIncomingAdminMsgTxns", "MAWWriteMsgTxns", "WALogger", "WATimeUtils", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["writeReachabilityErrorAdminMsg failed to create or get 1:1 thread"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b, c) {
        var e = a.ts;
        e = d("WATimeUtils").castUnixTimeToMillisTime(e);
        c = d("MAWTimeUtils").ensureValidMillisTime(c) || d("WATimeUtils").castToMillisTime(0);
        e = e > c ? e : c;
        return babelHelpers["extends"]({}, b, {
            newestMsg: a.msgId,
            newestMsgTs: e,
            oldestMsg: a.msgId,
            snippetMsg: a.msgId,
            snippetMsgTs: d("WATimeUtils").castUnixTimeToMillisTime(d("MAWDbMsg").getCanonicalTsFromMsg(a)),
            threadOrder: d("MAWDbThread").craftThreadOrder(e, b.jid)
        })
    }

    function b(a, b) {
        return d("MAWDbThreadTxns").getThread(a, b).then(function(b) {
            if (!b.success) {
                d("WALogger").WARN(h());
                return
            }
            b = b.value;
            var e = d("MAWLocalizationUtils").buildUnstoredDbAdminMsg({
                adminMsgContent: [],
                adminType: d("MAWLocalizationType").LOCALIZATION_TYPE.REACHABILITY_ERROR,
                version: 0
            }, b.jid, d("WATimeUtils").castMillisTimeToUnixTime(d("WATimeUtils").millisTime()));
            return d("MAWWriteMsgTxns").writeMsg(a, e, b, "MAWAdminMsgTxns::writeReachabilityErrorAdminMsg").then(c("emptyFunction"))
        })
    }

    function e(a, b, c) {
        return d("MAWWriteBulkWriteIncomingAdminMsgTxns").writeE2EEAdminMsgsForIncomingCreatedThreads(a, [b], c).then(function(a) {
            a = a[0];
            return a
        })
    }

    function f(a) {
        var b = d("MAWDbMsg").craftE2eeAdminMsgAltIndex(a.chatId);
        b = d("MAWLocalizationUtils").buildUnstoredDbAdminMsg({
            adminMsgContent: [],
            adminType: d("MAWLocalizationType").LOCALIZATION_TYPE.E2EE_THREAD_DESCRIPTION,
            version: 0
        }, a.jid, d("WATimeUtils").castToUnixTime(0), b);
        return babelHelpers["extends"]({}, b, {
            msgId: d("MAWDbMsg").craftMsgIdV2(a.chatId, 1, b),
            sortOrderMs: 0
        })
    }
    g.getUpdatedThreadForAdminMsg = a;
    g.writeReachabilityErrorAdminMsg = b;
    g.writeE2EEThreadDescriptionMsg = e;
    g.buildE2EEThreadDescriptionMsg = f
}), 98);
__d("MAWThreadUpdateMiddlewareGKUtil", ["MAWMsgType", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (!c("gkx")("4847")) return !1;
        switch (a) {
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SYNC_RESPONSE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_CHANGE_FROM_CURRENT_DEVICE:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
            case d("MAWMsgType").MSG_TYPE.ICDC_ALERT:
            case d("MAWMsgType").MSG_TYPE.SK_DISTRIBUTION:
                return c("gkx")("5915");
            case d("MAWMsgType").MSG_TYPE.TEXT:
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
            case d("MAWMsgType").MSG_TYPE.REVOKED:
            case d("MAWMsgType").MSG_TYPE.EDIT_ACTION:
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
            case d("MAWMsgType").MSG_TYPE.UNAVAILABLE:
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                return c("gkx")("5916");
            case d("MAWMsgType").MSG_TYPE.IMAGE:
            case d("MAWMsgType").MSG_TYPE.VIDEO:
            case d("MAWMsgType").MSG_TYPE.PTT:
            case d("MAWMsgType").MSG_TYPE.GIF:
            case d("MAWMsgType").MSG_TYPE.STICKER:
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
            case d("MAWMsgType").MSG_TYPE.XMA:
            case d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME:
            case d("MAWMsgType").MSG_TYPE.GROUP_INVITE:
            case d("MAWMsgType").MSG_TYPE.RAVEN:
            case d("MAWMsgType").MSG_TYPE.RAVEN_ACTION:
                return c("gkx")("6762");
            case d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL:
            case d("MAWMsgType").MSG_TYPE.GROUP_POLL_CREATE:
            case d("MAWMsgType").MSG_TYPE.GROUP_POLL_UPDATE:
                return !1;
            default:
                a;
                return !1
        }
    }

    function b() {
        return c("gkx")("4847") && c("gkx")("3739")
    }

    function e() {
        return c("gkx")("4847") && c("gkx")("6236")
    }

    function f() {
        return c("gkx")("4847") && c("gkx")("7904")
    }

    function h() {
        return c("gkx")("4847") && c("gkx")("6236") && c("gkx")("5915") && c("gkx")("3739") && c("gkx")("5916") && c("gkx")("6762")
    }
    g.isThreadUpdateEnabledViaMiddlewareForMsgType = a;
    g.isThreadUpdateEnabledViaMiddlewareForReactions = b;
    g.isSnippetRecalculationEnabled = e;
    g.isThrottledUpdatesEnabled = f;
    g.isMiddlewareFullyRolledOut = h
}), 98);
__d("MAWAfterWriteMsgUtil", ["$InternalEnum", "ArmadilloDataTraceType", "I64", "MAWBridgeMsg", "MAWBridgeTrace", "MAWBridgeTypesCreators", "MAWCalculateBumpTimestampMs", "MAWDbMsg", "MAWIndexedDb", "MAWLocalizationType", "MAWMsgType", "MAWThreadUpdateMiddlewareGKUtil", "MAWXMAUtils", "WAJids", "WALogger", "WATimeUtils", "justknobx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Skipping thread bump for thread: ", ", msgType: ", ", snippetType: ", ", newestMsgTs: ", ", bumpThreadOption: ", "."]);
        i = function() {
            return a
        };
        return a
    }
    var j = b("$InternalEnum").Mirrored(["DO_NOT_BUMP_THREAD", "BUMP_LOCAL_ONLY", "BUMP_LOCAL_AND_SERVER"]);

    function a(a) {
        var b = a.bumpThreadOption,
            e = a.dbMsg,
            f = a.hasMoreAfter,
            g = a.hasMoreBefore,
            h = a.initialLoad;
        h = h === void 0 ? !1 : h;
        var i = a.isFirstMsg,
            j = a.isOldestMsgUpdated,
            l = a.openMessageOtid,
            m = a.openMessageParticipantCount,
            n = a.optimisticMsg,
            o = a.participantCount,
            p = a.quotedReplyAttachmentMeta,
            q = a.s2sInstanceKey,
            r = a.snippet;
        a = a.updatedThread;
        var s = a.authoritativeThreadKey,
            t = a.jid,
            u = a.newestMsgTs;
        a = a.oldestMsg;
        if (e.altIndex === d("MAWDbMsg").SPAM_ALT_INDEX || e.altIndex === d("MAWDbMsg").FUTUREPROOF_SPAM_ALT_INDEX) return;
        d("MAWIndexedDb").afterTransaction({
            tag: "StartTrace",
            value: d("MAWBridgeTrace").createBridgeStartTraceData(e, t, d("ArmadilloDataTraceType").armadilloMessageSend, l, i, m, o, s)
        });
        d("MAWXMAUtils").isXMAStoryReply(e.xmaMessageType) || d("MAWIndexedDb").afterTransaction({
            tag: "NewMsg",
            value: d("MAWBridgeMsg").createBridgeMsg(e, n, p, void 0, q)
        });
        k(b, e, t, u, r);
        if (h && c("qex")._("1210") !== !0) {
            d("MAWIndexedDb").afterTransaction({
                tag: "MsgsLoaded",
                value: d("MAWBridgeTypesCreators").createBridgeMsgsLoadedInfo(t, [e], !0, (l = g) != null ? l : !1, (i = f) != null ? i : !1)
            })
        }
        j && a != null && d("MAWIndexedDb").afterTransaction({
            tag: "UpdateMinMessage",
            value: {
                minMessageId: a,
                minTimestampMs: d("MAWDbMsg").getCanonicalTsFromMsg(e) * 1e3,
                threadJid: t
            }
        })
    }

    function k(a, b, c, e, f) {
        switch (a) {
            case j.DO_NOT_BUMP_THREAD:
                l(a, b, c, e, f);
                return;
            case j.BUMP_LOCAL_ONLY:
            case j.BUMP_LOCAL_AND_SERVER:
                if (m(b) || f == null || e == null) {
                    l(a, b, c, e, f);
                    return
                }
                if (!d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type)) {
                    var g = f.snippetParams,
                        i = f.snippetSenderContactId;
                    f = f.snippetType;
                    e = d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMs(b.serverTs != null ? d("WATimeUtils").castUnixTimeToMillisTime(b.serverTs) : e, (h || (h = d("I64"))).of_string_opt(b.externalId));
                    d("MAWIndexedDb").afterTransaction({
                        tag: "ThreadBumpedV2",
                        value: d("MAWBridgeTypesCreators").createBridgeBumpedThreadV2({
                            bumpTimestampMs: e,
                            description: "writeMsgAfterTransaction-" + b.type,
                            isMessageAuthorMe: b.author === d("WAJids").AUTHOR_ME,
                            skipServerThreadBump: a === j.BUMP_LOCAL_ONLY,
                            snippetData: {
                                params: g,
                                senderContactId: i,
                                type: f
                            },
                            threadJid: c
                        })
                    })
                }
        }
    }

    function l(a, b, c, e, f) {
        if (d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type)) return;
        d("WALogger").LOG(i(), c, b.type, f == null ? void 0 : f.snippetType, e, a)
    }

    function m(a) {
        if (d("MAWXMAUtils").isXMAStoryReply(a.xmaMessageType)) return !0;
        return c("justknobx")._("2017") && a.type === d("MAWMsgType").MSG_TYPE.ADMIN && (d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(a.type) || a.msgContent.adminType === d("MAWLocalizationType").LOCALIZATION_TYPE.E2EE_THREAD_DESCRIPTION || a.msgContent.adminType === d("MAWLocalizationType").LOCALIZATION_TYPE.DUAL_THREAD_CUTOVER_ADMIN_MESSAGE) ? !0 : !1
    }
    g.WriteMsgAfterTxnBumpThreadOption = j;
    g.writeMsgAfterTransaction = a
}), 98);
__d("MAWThreadSnippetForAdminOrEphemeralMsg", ["MAWAdminMsgNormalized", "MAWLocalizationUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = a.msgContent.adminType;
        a = d("MAWLocalizationUtils").isAdminMsgNormalized(c) ? d("MAWAdminMsgNormalized").deconstructContactIdsFromAdminContent(c, a.msgContent.adminMsgContent) : {
            contactIds: [],
            contents: a.msgContent.adminMsgContent
        };
        var e = a.contactIds;
        a = a.contents;
        return {
            snippetParams: {
                contactIDs: [].concat(e.map(function(a) {
                    return a === "Facebook User" ? "0" : a
                })),
                strings: [].concat(a)
            },
            snippetSenderContactId: b,
            snippetType: c
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForBumpExistingMessageMsg", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Bump message sender is null"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Bump message has no quoted author"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Bumped message can not have AUTHOR_SYSTEM"]);
        j = function() {
            return a
        };
        return a
    }

    function k(a, b, c) {
        return {
            snippetParams: {
                contactIDs: (c = c) != null ? c : [],
                strings: []
            },
            snippetSenderContactId: a,
            snippetType: b
        }
    }
    var l = function(a) {
        return k(a, d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET)
    };

    function a(a, b, c) {
        var e;
        if (d("WAJids").isAuthorSystem(a.author)) {
            d("WALogger").ERROR(j());
            return l(b)
        }
        e = (e = (e = a.quote) == null ? void 0 : e.content.author) != null ? e : c;
        if (e == null) {
            d("WALogger").ERROR(i());
            return l(b)
        }
        if (d("WAJids").isAuthorMe(a.author)) return d("WAJids").isAuthorMe(e) ? k(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_BUMPED_OWN_MESSAGE) : k(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_BUMPED_MESSAGE, [d("WAJids").userIdFromJid(e)]);
        if (b == null) {
            d("WALogger").ERROR(h());
            return l(b)
        }
        if (d("WAJids").isAuthorMe(e)) return k(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_BUMPED_CURRENT_USER_MESSAGE, [b]);
        return e === a.author ? k(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_BUMPED_OWN_MESSAGE, [b]) : k(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_BUMPED_PARTICIPANT_MESSAGE, [b, d("WAJids").userIdFromJid(e)])
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForCiphertextMsg", ["MAWLocalizationType", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return {
            snippetParams: {
                contactIDs: [],
                strings: []
            },
            snippetSenderContactId: a,
            snippetType: c("gkx")("1564") ? d("MAWLocalizationType").LOCALIZATION_TYPE.USER_SEND_ENCRYPTED_MESSAGE_FALLBACK : d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForDocumentFileMsg", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Document file message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_ATTACHMENT : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_ATTACHMENT, c.contactIDs.push(b));
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForFallbackMessageMsg", ["MAWLocalizationType", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, c) {
        return {
            snippetParams: {
                contactIDs: (c = c) != null ? c : [],
                strings: []
            },
            snippetSenderContactId: a,
            snippetType: b
        }
    }

    function a(a, b) {
        var c = a.author;
        a = a.msgContent.subtype;
        if (d("WAJids").isAuthorMe(c)) switch (a) {
            case "liveLocationMessage":
            case "locationMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_LOCATION_FALLBACK);
            case "contactShareMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_CONTACT_SHARE_FALLBACK);
            case "storyMentionMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_STORY_MENTION_FALLBACK);
            case "pollCreationMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_POLL_CREATION_FALLBACK);
            case "bumpMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_BUMPED_MESSAGE);
            case "stickerReceiverFetchMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_STICKER_RECEIVER_FETCH_MESSAGE_FALLBACK);
            default:
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET)
        } else switch (a) {
            case "liveLocationMessage":
            case "locationMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_LOCATION_FALLBACK);
            case "contactShareMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_CONTACT_SHARE_FALLBACK);
            case "storyMentionMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_STORY_MENTION_FALLBACK);
            case "pollCreationMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_POLL_CREATION_FALLBACK);
            case "bumpMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_BUMPED_PARTICIPANT_MESSAGE);
            case "metaAiMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.META_AI_SEND_MESSAGE_FALLBACK);
            case "stickerReceiverFetchMessage":
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_STICKER_RECEIVER_FETCH_MESSAGE_FALLBACK);
            default:
                return h(b, d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET)
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForGifMsg", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Animated message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_GIF : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_GIF, c.contactIDs.push(b));
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForImageMsg", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Image message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_IMAGE : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_IMAGE, c.contactIDs.push(b));
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForPttMsg", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Ptt message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_AUDIO : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_AUDIO, c.contactIDs.push(b));
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForRavenMsg", ["MAWLocalizationType", "MAWMsg", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Animated message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        d("WAJids").isAuthorMe(a.author) ? e = a.ravenMediaType === d("MAWMsg").MAWRavenMsgMediaType.IMAGE ? d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_IMAGE : d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_VIDEO : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = a.ravenMediaType === d("MAWMsg").MAWRavenMsgMediaType.IMAGE ? d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_IMAGE : d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_VIDEO, c.contactIDs.push(b));
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForMsgUtils", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Sticker message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b, c) {
        var e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        b = {
            contactIDs: [],
            mentionJIDs: b,
            strings: []
        };
        d("WAJids").isAuthorMe(a) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_STICKER : d("WAJids").isAuthorSystem(a) || c == null ? d("WALogger").ERROR(h()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_STICKER, b.contactIDs.push(c));
        return {
            snippetParams: b,
            snippetSenderContactId: c,
            snippetType: e
        }
    }
    g.getMAWThreadSnippetForStickerMsg = a
}), 98);
__d("MAWThreadSnippetForReceiverFetchMsg", ["MAWThreadSnippetForMsgUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return d("MAWThreadSnippetForMsgUtils").getMAWThreadSnippetForStickerMsg(a.author, (a = a.msgContent) == null ? void 0 : a.mentionedJids, b)
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForRevokedMsg", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Revoked message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_UNSENT_MESSAGE : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_UNSENT_MESSAGE, c.contactIDs.push(b));
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForStickerMsg", ["MAWThreadSnippetForMsgUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return d("MAWThreadSnippetForMsgUtils").getMAWThreadSnippetForStickerMsg(a.author, (a = a.msgContent) == null ? void 0 : a.mentionedJids, b)
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForTextMsg", ["MAWLocalizationType", "MAWVault", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Text message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b, c) {
        var e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET,
            f = {
                contactIDs: [],
                mentionJIDs: a.msgContent.mentionedJids,
                strings: []
            };
        d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_TEXT : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = c ? d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_TEXT_IN_GROUP : d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_TEXT, f.contactIDs.push(b));
        if (a.specialTextSize === 1 || a.specialTextSize === 2 || a.specialTextSize === 3) {
            c = d("MAWVault").unvault(a.msgContent.content);
            f.strings.push(c === "\ud83d\udc4d" ? "(Y)" : a.msgContent.content)
        } else f.strings.push(a.msgContent.content);
        return {
            snippetParams: f,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForVideoMsg", ["MAWLocalizationType", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Video message can not have AUTHOR_SYSTEM"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_VIDEO : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(h()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_VIDEO, c.contactIDs.push(b));
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippetForXMAMsg", ["MAWLocalizationType", "WAArmadilloXMA.pb", "WAJids", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Encountered unexpected XMAMessageType when building a thread snippet: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA story mentions must have a target Jid"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        v = function() {
            return a
        };
        return a
    }

    function w() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        w = function() {
            return a
        };
        return a
    }

    function x() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        x = function() {
            return a
        };
        return a
    }

    function y() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        y = function() {
            return a
        };
        return a
    }

    function z() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        z = function() {
            return a
        };
        return a
    }

    function A() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message can not have AUTHOR_SYSTEM"]);
        A = function() {
            return a
        };
        return a
    }

    function B() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["XMA message does not have xmaMessageType"]);
        B = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c, e = d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET;
        c = {
            contactIDs: [],
            mentionJIDs: (c = a.msgContent) == null ? void 0 : c.mentionedJids,
            strings: []
        };
        a.xmaMessageType == null && d("WALogger").ERROR(B());
        switch (a.xmaMessageType) {
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_FEED_SHARE:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_GAMING_CUSTOM_UPDATE:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_RECEIVER_FETCH:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_ATTACHMENT : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(A()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_ATTACHMENT, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_EXTERNAL_LINK_SHARE:
                if (d("WAJids").isAuthorMe(a.author)) {
                    var f;
                    if (a.msgContent != null && ((f = a.msgContent) == null ? void 0 : f.content) != null) {
                        e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_TEXT;
                        c.strings.push((f = a.msgContent) == null ? void 0 : f.content)
                    } else e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_ATTACHMENT
                } else if (d("WAJids").isAuthorSystem(a.author) || b == null) d("WALogger").ERROR(z());
                else {
                    e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_TEXT;
                    c.contactIDs.push(b);
                    if (a.msgContent != null && ((f = a.msgContent) == null ? void 0 : f.content) != null) {
                        c.strings.push((f = a.msgContent) == null ? void 0 : f.content)
                    }
                }
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_REPLY:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_PRODUCER_STORY_REPLY:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_SHARE:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SENT_STORY : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(y()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SENT_STORY, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_STORY_MENTION:
                d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(x()) : d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_STORY_MENTION : e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_STORY_MENTION;
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_LOCATION_SHARING:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_LOCATION_SHARING_V2:
                d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(w()) : d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SEND_LOCATION : e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SEND_LOCATION;
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_CLIPS_SHARE:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_SHORT:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SENT_REEL : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(v()) : e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SENT_REEL;
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_FEED_POST_PRIVATE_REPLY:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_MULTIPOST_SHARE:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_SINGLE_IMAGE_POST_SHARE:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SENT_POST : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(u()) : e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SENT_POST;
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.MSG_HIGHLIGHTS_TAB_FRIEND_UPDATES_REPLY:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SENT_POST : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(t()) : e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SENT_POST;
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_SHARE:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_VIDEO_SHARE:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_REPLY:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_REACTION:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SENT_STORY : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(s()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SENT_STORY, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_HIGHLIGHT_SHARE:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_VIDEO_HIGHLIGHT_SHARE:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SENT_STORY_HIGHLIGHT : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(r()) : e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SENT_STORY_HIGHLIGHT;
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_PHOTO_MENTION:
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.IG_STORY_VIDEO_MENTION:
                if (d("WAJids").isAuthorMe(a.author)) {
                    e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_MENTIONED_STORY_IG;
                    f = a.threadJid;
                    var g;
                    f != null && (g = d("WAJids").interpretAsUserJid(f));
                    if (g != null) {
                        f = d("WAJids").userIdFromJid(g);
                        c.contactIDs.push(f)
                    } else d("WALogger").ERROR(q())
                } else d("WAJids").isAuthorSystem(a.author) ? d("WALogger").ERROR(p()) : e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_RECEIVED_STORY_MENTION_IG;
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_AUDIO_CALL:
                d("WAJids").isAuthorMe(a.author) && b != null ? (e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_AUDIO_CALLED, c.contactIDs.push(b)) : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(o()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_AUDIO_CALLED, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_VIDEO_CALL:
                d("WAJids").isAuthorMe(a.author) && b != null ? (e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_VIDEO_CALLED, c.contactIDs.push(b)) : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(n()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_VIDEO_CALLED, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_MISSED_AUDIO_CALL:
                d("WAJids").isAuthorMe(a.author) && b != null ? (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_MISSED_AUDIO_CALL, c.contactIDs.push(b)) : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(m()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_MISSED_AUDIO_CALL, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_MISSED_VIDEO_CALL:
                d("WAJids").isAuthorMe(a.author) && b != null ? (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_MISSED_VIDEO_CALL, c.contactIDs.push(b)) : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(l()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_MISSED_VIDEO_CALL, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_GROUP_AUDIO_CALL:
                d("WAJids").isAuthorMe(a.author) && b != null ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_STARTED_GROUP_AUDIO_CALL : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(k()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_STARTED_GROUP_AUDIO_CALL, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.RTC_GROUP_VIDEO_CALL:
                d("WAJids").isAuthorMe(a.author) && b != null ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_STARTED_GROUP_VIDEO_CALL : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(j()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_STARTED_GROUP_VIDEO_CALL, c.contactIDs.push(b));
                break;
            case d("WAArmadilloXMA.pb").EXTENDED_CONTENT_MESSAGE_EXTENDED_CONTENT_TYPE.FB_EVENT:
                d("WAJids").isAuthorMe(a.author) ? e = d("MAWLocalizationType").LOCALIZATION_TYPE.CURRENT_USER_SENT_EVENT : d("WAJids").isAuthorSystem(a.author) || b == null ? d("WALogger").ERROR(i()) : (e = d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_SENT_EVENT, c.contactIDs.push(b));
                break;
            default:
                d("WALogger").ERROR(h(), a.xmaMessageType)
        }
        return {
            snippetParams: c,
            snippetSenderContactId: b,
            snippetType: e
        }
    }
    g["default"] = a
}), 98);
__d("MAWThreadSnippet", ["FBLogger", "MAWLocalizationType", "MAWMsgType", "MAWThreadSnippetForAdminOrEphemeralMsg", "MAWThreadSnippetForBumpExistingMessageMsg", "MAWThreadSnippetForCiphertextMsg", "MAWThreadSnippetForDocumentFileMsg", "MAWThreadSnippetForFallbackMessageMsg", "MAWThreadSnippetForGifMsg", "MAWThreadSnippetForImageMsg", "MAWThreadSnippetForPttMsg", "MAWThreadSnippetForRavenMsg", "MAWThreadSnippetForReceiverFetchMsg", "MAWThreadSnippetForRevokedMsg", "MAWThreadSnippetForStickerMsg", "MAWThreadSnippetForTextMsg", "MAWThreadSnippetForVideoMsg", "MAWThreadSnippetForXMAMsg", "MAWUserJidWrapper", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return /^\d+$/.test(a)
    }

    function i(a) {
        if (d("WAJids").isAuthorSystem(a)) return;
        a = d("WAJids").isAuthorMe(a) ? d("WAJids").userIdFromJid(d("MAWUserJidWrapper").getMyUserJid()) : d("WAJids").userIdFromJid(a);
        if (!h(a)) {
            c("FBLogger")("maw_db").mustfix("[MAWThreadSnippetBuildTxns] Snippet sender contact id is invalid");
            return
        }
        return a
    }

    function a(a, b, e) {
        var f = i(a.author);
        switch (a.type) {
            case d("MAWMsgType").MSG_TYPE.CIPHERTEXT:
                return c("MAWThreadSnippetForCiphertextMsg")(f);
            case d("MAWMsgType").MSG_TYPE.TEXT:
                return c("MAWThreadSnippetForTextMsg")(a, f, b);
            case d("MAWMsgType").MSG_TYPE.IMAGE:
                return c("MAWThreadSnippetForImageMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.VIDEO:
                return c("MAWThreadSnippetForVideoMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.PTT:
                return c("MAWThreadSnippetForPttMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN:
            case d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION:
                return c("MAWThreadSnippetForAdminOrEphemeralMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.GIF:
                return c("MAWThreadSnippetForGifMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.STICKER:
                return c("MAWThreadSnippetForStickerMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.DOCUMENT_FILE:
                return c("MAWThreadSnippetForDocumentFileMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.REVOKED:
                return c("MAWThreadSnippetForRevokedMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.XMA:
                return c("MAWThreadSnippetForXMAMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.BUMP_EXISTING_MESSAGE:
                return c("MAWThreadSnippetForBumpExistingMessageMsg")(a, f, e);
            case d("MAWMsgType").MSG_TYPE.FUTUREPROOF:
                return c("MAWThreadSnippetForFallbackMessageMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.RECEIVER_FETCH:
                return c("MAWThreadSnippetForReceiverFetchMsg")(a, f);
            case d("MAWMsgType").MSG_TYPE.RAVEN:
                return c("MAWThreadSnippetForRavenMsg")(a, f);
            default:
                return {
                    snippetParams: {
                        contactIDs: [],
                        strings: []
                    },
                    snippetSenderContactId: f,
                    snippetType: d("MAWLocalizationType").LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET
                }
        }
    }
    g.getSnippetContactId = i;
    g.buildThreadSnippet = a
}), 98);
__d("MAWWriteBulkWriteIncomingAdminMsgTxns", ["MAWAdminMsgTxns", "MAWAfterWriteMsgUtil", "MAWDbMsgTxns", "MAWDexieTable", "MAWMessageHasUniqueExternalIdValidator", "MAWQplProxy", "MAWThreadSnippet", "MAWThreadSnippetForAdminOrEphemeralMsg", "MAWThreadUpdateMiddlewareGKUtil", "WALogger", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["OfflineBulkWriteAdminmsg - Missing thread when write e2ee thread description"]);
        h = function() {
            return a
        };
        return a
    }

    function i(a, b) {
        var e = [],
            f = [],
            g = [],
            i = new Map(),
            j = new Map(),
            k = b.map(function(b) {
                return d("MAWDbMsgTxns").getThreadOldestMessageId(a, b.jid).then(function(a) {
                    return i.set(b.jid, a)
                })
            }),
            l = b.map(function(b) {
                return d("MAWDbMsgTxns").getThreadNewestMessageTs(a, b).then(function(a) {
                    return j.set(b.jid, a)
                })
            });
        return d("MAWDexieTable").dexieAll([k, l]).then(function() {
            b.forEach(function(a) {
                a == null && d("WALogger").ERROR(h());
                var b = d("MAWAdminMsgTxns").buildE2EEThreadDescriptionMsg(a),
                    k = d("MAWAdminMsgTxns").getUpdatedThreadForAdminMsg(b, a, j.get(a.jid)),
                    l = d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type) ? null : c("MAWThreadSnippetForAdminOrEphemeralMsg")(b, d("MAWThreadSnippet").getSnippetContactId(b.author));
                a = i.get(a.jid);
                e.push(b);
                g.push(k);
                f.push({
                    bumpThreadOption: d("MAWAfterWriteMsgUtil").WriteMsgAfterTxnBumpThreadOption.BUMP_LOCAL_ONLY,
                    dbMsg: b,
                    initialLoad: a == null,
                    isFirstMsg: !1,
                    isOldestMsgUpdated: a != null && b.msgId !== a,
                    snippet: l,
                    updatedThread: k
                })
            });
            return {
                afterTransactionSyncMsgsData: f,
                e2eeThreadAdminMsgs: e,
                threadsToUpdate: g
            }
        })
    }

    function a(a, b, e) {
        return i(a, b).then(function(b) {
            var f = b.afterTransactionSyncMsgsData,
                g = b.e2eeThreadAdminMsgs,
                h = b.threadsToUpdate;
            d("MAWMessageHasUniqueExternalIdValidator").logMessageAddSource(g.map(function(a) {
                return a.externalId
            }), "MAWWriteBulkWriteIncomingAdminMsgTxns.js::writeE2EEAdminMsgsForIncomingCreatedThreads");
            e != null && d("MAWQplProxy").sendQplPointThroughBridge(c("qpl")._(25313175, "1551"), "write-bulk-admin-msgs-start", {
                instanceKey: e
            });
            return d("MAWDexieTable").dexieAll([a.messages.bulkAdd(g), a.threads.bulkPut(h)]).then(function() {
                e != null && d("MAWQplProxy").sendQplPointThroughBridge(c("qpl")._(25313175, "1551"), "write-bulk-admin-msgs-end", {
                    instanceKey: e
                });
                f.forEach(function(a) {
                    return d("MAWAfterWriteMsgUtil").writeMsgAfterTransaction(a)
                });
                return h
            })
        })
    }
    g.writeE2EEAdminMsgsForIncomingCreatedThreads = a
}), 98);
__d("MAWAuthor", ["MAWUserJidWrapper", "WAJids", "isStringNullOrEmpty"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        if (a == null || a === d("WAJids").AUTHOR_SYSTEM) return null;
        if (d("WAJids").isAuthorMe(a)) return d("MAWUserJidWrapper").getMyUserJid();
        var b = d("WAJids").authorAsUserJid(a);
        if (b == null || c("isStringNullOrEmpty")(d("WAJids").userIdFromJid(b))) return null;
        else return d("WAJids").authorAsUserJid(a)
    };
    g.getAuthorUserJid = a
}), 98);
__d("MAWDbReactionsTxns", ["FBLogger", "MAWAuthor", "MAWBridgeTypesCreators", "MAWDbMsg", "MAWDbMsgUtil", "MAWDexieTable", "MAWIndexedDb", "WALogger", "WAMsgMap", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Deleted ", " reactions"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Successfully deleted: ", " reactions rows."]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Successfully deleted reaction with id : ", "."]);
        j = function() {
            return a
        };
        return a
    }
    var k = function(a) {
        return a
    };

    function a(a, b) {
        return a.reactions.put(k(b))
    }

    function b(a, b) {
        return a.reactions["delete"](b.rowId).then(function() {
            var a = b.author,
                c = b.reactionId,
                e = b.reactToMsgId,
                f = b.threadJid;
            if (e == null) return;
            d("MAWIndexedDb").afterTransaction({
                tag: "DeleteReaction",
                value: d("MAWBridgeTypesCreators").createBridgeDeleteReaction({
                    author: a,
                    chatJid: f,
                    reactToMsgId: e
                })
            });
            d("WALogger").LOG(j(), c)
        })
    }

    function e(a, b) {
        return a.reactions.where("externalId").equals(b.externalId).filter(function(a) {
            return a.author === b.author && a.threadJid === b.chat
        }).first()
    }

    function f(a, b) {
        var c = d("MAWAuthor").getAuthorUserJid(b.author);
        return a.reactions.where("reactToExternalId").equals(b.externalId).filter(function(a) {
            return (a.reactToAuthor === c || a.reactToAuthor === b.author) && a.threadJid === b.chat
        }).toArray()
    }

    function l(a, b) {
        var d = b.reduce(function(a, b) {
            a.set(b.msgId, b);
            return a
        }, new Map());
        return a.reactions.where("reactToMsgId").anyOf(b.map(function(a) {
            return a.msgId
        })).toArray().then(function(a) {
            var b = a.filter(function(a) {
                var b = a.reactToExternalId;
                a = a.reactToMsgId;
                return a != null && b === ((b = d.get(a)) == null ? void 0 : b.externalId)
            });
            b.length < a.length && c("FBLogger")("messenger_e2ee_web").mustfix("Reactions query by reactToMsgId returns reactions with mismatching externalId");
            return b
        })
    }

    function m(a, b) {
        return l(a, [b])
    }

    function n(a, b) {
        var c = b.author,
            d = b.chat;
        b = b.externalId;
        return a.reactions.where("externalId").equals(b).filter(function(a) {
            return a.author === c && a.threadJid === d
        }).first()
    }

    function o(a, b) {
        var c = b.map(function(a) {
            a = a.externalId;
            return a
        });
        return a.reactions.where("externalId").anyOf(c).toArray().then(function(a) {
            var c = d("MAWDbMsgUtil").convertMsgArrayToMap(a),
                e = new(d("WAMsgMap").MsgMap)();
            b.forEach(function(a) {
                var b = c.get(a);
                b != null && e.set(a, b)
            });
            return e
        })
    }

    function p(a, b) {
        return d("MAWDexieTable").dexieAll(b.map(function(b) {
            var c = b.author;
            b = b.externalId;
            var e = d("MAWAuthor").getAuthorUserJid(c);
            return a.reactions.where("reactToExternalId").equals(b).filter(function(a) {
                return d("MAWAuthor").getAuthorUserJid(a.reactToAuthor) === e
            }).toArray()
        })).then(function(b) {
            b = b.flat();
            b.forEach(function(a) {
                var b = a.author,
                    c = a.reactToMsgId;
                a = a.threadJid;
                if (c == null) return;
                d("MAWIndexedDb").afterTransaction({
                    tag: "DeleteReaction",
                    value: d("MAWBridgeTypesCreators").createBridgeDeleteReaction({
                        author: b,
                        chatJid: a,
                        reactToMsgId: c
                    })
                })
            });
            d("WALogger").LOG(i(), b.length);
            return a.reactions.bulkDelete(b.map(function(a) {
                return a.rowId
            }))
        })
    }

    function q(a, b) {
        return a.reactions.where("reactToMsgId").anyOf(b.map(function(a) {
            return a.msgId
        }))["delete"]().then(function(a) {
            d("WALogger").LOG(h(), a)
        })
    }

    function r(a, b) {
        return a.reactions.where("reactionId").between(d("MAWDbMsg").msgIdsInChatLowerBound(b.chatId), d("MAWDbMsg").msgIdsInChatUpperBound(b.chatId)).last().then(function(a) {
            a = a == null ? 0 : d("MAWDbMsg").getInChatMsgIdFromMsgId(a.reactionId);
            return a + 1
        })
    }

    function s(a, b, c, e, f, g) {
        c = c == null ? null : c.ts;
        return a.reactions.where(["threadJid", "ts"]).between([b, d("WATimeUtils").castToUnixTime(0)], [b, (a = c) != null ? a : d("WATimeUtils").unixTime()], !0, e).reverse().filter(g).limit(f).toArray()
    }
    g.coerceToReaction = k;
    g.putReaction = a;
    g.deleteReaction = b;
    g.getReaction = e;
    g.getReactionForEcho = f;
    g.getReactionsFromMessages = l;
    g.getReactionsFromMessage = m;
    g.maybeGetReactionByProtocolMsgId = n;
    g.getReactionMapByProtocolMsgId = o;
    g.deleteReactionsByUniqueMsgIdentifiers = p;
    g.deleteAllReactionsForMessages = q;
    g.getNextReactionIdNumberForThread = r;
    g.fetchReactionsFromDbWithTimestamp = s
}), 98);
__d("MAWMsgCleaner", ["MAWLoggerUtils", "Promise", "WAAssertUnreachable", "WAShiftTimer", "WATagsLogger", "WATimeUtils", "WorkerScheduler", "gkx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", "::_purgeNow ", " msgs' content cleaned"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", "::_purgeNow"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", "::update ", ""]);
        k = function() {
            return a
        };
        return a
    }
    a = "Unsend";
    e = "Ephemeral";
    f = "DeleteForMe";
    var l = "PendingStanza",
        m = "Xma",
        n = "IGDDM",
        o = "Quote";
    f = {
        DELETE_FOR_ME: f,
        EPHEMERAL: e,
        IGDDM: n,
        PENDING_STANZA: l,
        QUOTE: o,
        UNSEND: a,
        XMA: m
    };
    var p;

    function q() {
        p == null && (p = d("WorkerScheduler").makeScheduler("cleaner", {
            concurrency: 1,
            maxConcurrency: 1,
            maxThrottleMs: 8e3
        }));
        return p
    }
    e = function() {
        function a(a, b) {
            var e = this;
            this.$1 = new(d("WAShiftTimer").ShiftTimer)(function() {
                c("promiseDone")(e.$2())
            });
            this.getNextTs = a.getNextTs;
            this.removeExpired = a.removeExpired;
            this.cleanerType = b;
            this.purgeEnabled = a.purgeEnabled;
            this.$1.forceRunNow()
        }
        var e = a.prototype;
        e.update = function(a) {
            var b = r(this.cleanerType);
            d("WATagsLogger").TAGS([b, d("MAWLoggerUtils").Tag.MsgCleaner, d("MAWLoggerUtils").Tag.CleanerUpdate]).LOG(k(), b, a);
            this.$1.onOrBefore(d("WATimeUtils").cappedMillisecondsUntil(a))
        };
        e.$2 = function() {
            var a = this,
                e = function() {
                    if (!a.purgeEnabled()) return (h || (h = b("Promise"))).resolve();
                    var c = r(a.cleanerType);
                    d("WATagsLogger").TAGS([c, d("MAWLoggerUtils").Tag.MsgCleaner, d("MAWLoggerUtils").Tag.CleanerPurge]).LOG(j(), c);
                    return a.removeExpired().then(function(b) {
                        b > 0 && d("WATagsLogger").TAGS([c, d("MAWLoggerUtils").Tag.MsgCleaner, d("MAWLoggerUtils").Tag.CleanerPurge]).LOG(i(), c, b);
                        return a.getNextTs()
                    }).then(function(b) {
                        b != null && a.update(b)
                    })
                };
            if (c("gkx")("6593")) {
                if (this.$3 != null) return (h || (h = b("Promise"))).resolve();
                this.$3 = q().task({
                    fn: e,
                    name: this.cleanerType,
                    priority: d("WorkerScheduler").BACKGROUND_PRIORITY
                });
                return this.$3.run()["finally"](function() {
                    a.$3 = null
                })
            } else return e()
        };
        return a
    }();

    function r(a) {
        switch (a) {
            case "Unsend":
                return "UnsendMsgCleaner";
            case "Ephemeral":
                return "EphemeralCleaner";
            case "DeleteForMe":
                return "DeleteForMeCleaner";
            case "PendingStanza":
                return "PendingStanzaCleaner";
            case "Xma":
                return "XmaCleaner";
            case "IGDDM":
                return "IGDDisappearingMsgCleaner";
            case "Quote":
                return "QuoteCleaner";
            default:
                return c("WAAssertUnreachable")(a)
        }
    }
    n = e;
    g.CLEANER_TYPE = f;
    g.MsgCleaner = e;
    g.MSG_CLEANER_FOR_TESTING_ONLY = n
}), 98);
__d("MAWDeleteForMeMsgContentCleaner", ["MAWMsgCleaner", "WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["DeleteForMeMsgContentCleaner: Adding timestamps (", ")"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["startDeleteForMeMsgContentCleaner invoked"]);
        j = function() {
            return a
        };
        return a
    }
    var k = null;

    function a(a) {
        d("WALogger").LOG(j()), k == null && (k = new(d("MAWMsgCleaner").MsgCleaner)(a, d("MAWMsgCleaner").CLEANER_TYPE.DELETE_FOR_ME))
    }

    function b(a) {
        if (k == null) {
            var b = "Trying to add new DeleteForMeContentCleanerTimestamp before the cleaner is initialized!";
            d("WALogger").ERROR(i(), b);
            throw c("err")(b)
        } else d("WALogger").DEV(h(), a), k.update(a)
    }

    function e() {
        return k
    }

    function f() {
        k = null
    }
    g.startDeleteForMeMsgContentCleaner = a;
    g.addNewDeleteForMeMsgContentCleanerTimestamp = b;
    g.getDeleteForMeMsgContentCleaner_FOR_TESTING_ONLY = e;
    g.resetDeleteForMeMsgContentCleaner_FOR_TESTING_ONLY = f
}), 98);
__d("isWAFTSContentSearchEnabled", ["isE2EEConversationSearchEnabled", "isMAWUniversalSearchEnabled"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("isE2EEConversationSearchEnabled")() || c("isMAWUniversalSearchEnabled")()
    }
    g["default"] = a
}), 98);
__d("MAWFTSTxns", ["MAWDexieTable", "isWAFTSContentSearchEnabled", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("justknobx")._("1146"),
        i = c("justknobx")._("2154");

    function a(a, b) {
        return !c("isWAFTSContentSearchEnabled")() ? d("MAWDexieTable").dexieResolve(null) : a.ftsPurgeBacklog.put({
            externalId: b
        })
    }

    function b(a, b) {
        return !c("isWAFTSContentSearchEnabled")() || !h ? d("MAWDexieTable").dexieResolve(null) : a.ftsBackloggedMessages.put({
            rowId: b
        })
    }

    function e(a, b) {
        return !c("isWAFTSContentSearchEnabled")() || !h || !i ? d("MAWDexieTable").dexieResolve(null) : a.ftsBackloggedMessages.bulkPut(b.map(function(a) {
            return {
                rowId: a
            }
        }))
    }

    function f(a, b) {
        return !c("isWAFTSContentSearchEnabled")() ? d("MAWDexieTable").dexieResolve(null) : a.ftsPurgeThreadBacklog.put({
            chatJid: b
        })
    }
    g.maybePutMessageToPurgeBacklog = a;
    g.maybePutMessageToBacklog = b;
    g.maybePutMessagesToBacklog = e;
    g.maybePutThreadToPurgeBacklog = f
}), 98);
__d("MAWPendingStanzaCleaner", ["MAWMsgCleaner", "WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["PendingStanzaCleaner: Adding timestamps (", ")"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        i = function() {
            return a
        };
        return a
    }
    var j = null;

    function a(a) {
        j == null && (j = new(d("MAWMsgCleaner").MsgCleaner)(a, d("MAWMsgCleaner").CLEANER_TYPE.PENDING_STANZA))
    }

    function b(a) {
        if (j == null) {
            var b = "Trying to add new PendingStanzaCleanerTimestamp before the cleaner is initialized!";
            d("WALogger").ERROR(i(), b);
            throw c("err")(b)
        } else d("WALogger").DEV(h(), a), j.update(a)
    }

    function e() {
        return j
    }

    function f() {
        j = null
    }
    g.startPendingStanzaCleaner = a;
    g.addNewPendingStanzaCleanerTimestamp = b;
    g.getPendingStanzaCleaner_FOR_TESTING_ONLY = e;
    g.resetPendingStanzaCleaner_FOR_TESTING_ONLY = f
}), 98);
__d("MAWAdminMsgTypesGrouped", ["MAWLocalizationType"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = [(a = d("MAWLocalizationType")).LOCALIZATION_TYPE.CUTOVER_IGD_THREAD_ADMIN_MESSAGE, a.LOCALIZATION_TYPE.CUTOVER_THREAD_ADMIN_MESSAGE, a.LOCALIZATION_TYPE.DUAL_THREAD_CUTOVER_ADMIN_MESSAGE];
    c = [a.LOCALIZATION_TYPE.CURRENT_USER_ADDED_DEVICE, a.LOCALIZATION_TYPE.CURRENT_USER_REMOVED_DEVICE, a.LOCALIZATION_TYPE.CURRENT_USER_UPDATED_DEVICE, a.LOCALIZATION_TYPE.PARTICIPANT_ADDED_DEVICE, a.LOCALIZATION_TYPE.PARTICIPANT_REMOVED_DEVICE, a.LOCALIZATION_TYPE.PARTICIPANT_UPDATED_DEVICE];
    e = [a.LOCALIZATION_TYPE.CURRENT_USER_ADDED_MORE_THAN_TWO_PARTICIPANTS, a.LOCALIZATION_TYPE.CURRENT_USER_ADDED_ONE_PARTICIPANT, a.LOCALIZATION_TYPE.CURRENT_USER_ADDED_TWO_PARTICIPANTS, a.LOCALIZATION_TYPE.CURRENT_USER_REMOVED_MORE_THAN_TWO_PARTICIPANTS, a.LOCALIZATION_TYPE.CURRENT_USER_REMOVED_ONE_PARTICIPANT, a.LOCALIZATION_TYPE.CURRENT_USER_REMOVED_TWO_PARTICIPANTS, a.LOCALIZATION_TYPE.PARTICIPANT_ADDED_MORE_THAN_TWO_USER, a.LOCALIZATION_TYPE.PARTICIPANT_ADDED_ONE_USER, a.LOCALIZATION_TYPE.PARTICIPANT_ADDED_TWO_USER, a.LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU, a.LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU_AND_MORE_THAN_ONE_USERS, a.LOCALIZATION_TYPE.PARTICIPANT_ADDED_YOU_AND_ONE_USER, a.LOCALIZATION_TYPE.PARTICIPANT_REMOVED_MORE_THAN_TWO_USER, a.LOCALIZATION_TYPE.PARTICIPANT_REMOVED_ONE_USER, a.LOCALIZATION_TYPE.PARTICIPANT_REMOVED_TWO_USER, a.LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU, a.LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU_AND_MORE_THAN_ONE_USERS, a.LOCALIZATION_TYPE.PARTICIPANT_REMOVED_YOU_AND_ONE_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_MORE_THAN_TWO_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_ONE_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_TWO_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_YOU, a.LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_YOU_AND_MORE_THAN_ONE_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_ADDED_YOU_AND_ONE_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_MORE_THAN_TWO_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_ONE_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_TWO_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_YOU, a.LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_YOU_AND_MORE_THAN_ONE_USER, a.LOCALIZATION_TYPE.UNKNOWN_USER_REMOVED_YOU_AND_ONE_USER];
    f = [a.LOCALIZATION_TYPE.CURRENT_USER_DEMOTED_PARTICIPANT, a.LOCALIZATION_TYPE.CURRENT_USER_PROMOTED_PARTICIPANT, a.LOCALIZATION_TYPE.PARTICIPANT_DEMOTED_PARTICIPANT, a.LOCALIZATION_TYPE.PARTICIPANT_PROMOTED_PARTICIPANT, a.LOCALIZATION_TYPE.CURRENT_USER_GOT_DEMOTED, a.LOCALIZATION_TYPE.CURRENT_USER_GOT_PROMOTED, a.LOCALIZATION_TYPE.CURRENT_USER_SELF_DEMOTED, a.LOCALIZATION_TYPE.PARTICIPANT_GOT_DEMOTED, a.LOCALIZATION_TYPE.PARTICIPANT_GOT_PROMOTED, a.LOCALIZATION_TYPE.PARTICIPANT_PROMOTED_YOU, a.LOCALIZATION_TYPE.PARTICIPANT_DEMOTED_YOU, a.LOCALIZATION_TYPE.PARTICIPANT_SELF_DEMOTED, a.LOCALIZATION_TYPE.CURRENT_USER_SET_ADD_MODE_ADMIN_ONLY, a.LOCALIZATION_TYPE.CURRENT_USER_SET_ADD_MODE_ALL_MEMBERS, a.LOCALIZATION_TYPE.PARTICIPANT_SET_ADD_MODE_ADMIN_ONLY, a.LOCALIZATION_TYPE.PARTICIPANT_SET_ADD_MODE_ALL_MEMBERS, a.LOCALIZATION_TYPE.SERVER_SET_ADD_MODE_ADMIN_ONLY, a.LOCALIZATION_TYPE.SERVER_SET_ADD_MODE_ALL_MEMBERS];
    d = [a.LOCALIZATION_TYPE.CURRENT_USER_LEFT_GROUP, a.LOCALIZATION_TYPE.PARTICIPANT_LEFT_GROUP];
    var h = [a.LOCALIZATION_TYPE.CURRENT_USER_NAMED_GROUP, a.LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_HOTLIKE, a.LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_NICKNAME, a.LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_PHOTO, a.LOCALIZATION_TYPE.CURRENT_USER_CUSTOMIZE_THEME, a.LOCALIZATION_TYPE.CURRENT_USER_CLEAR_OWN_NICKNAME, a.LOCALIZATION_TYPE.CURRENT_USER_CLEAR_PARTICIPANT_NICKNAME, a.LOCALIZATION_TYPE.CURRENT_USER_SET_OWN_NICKNAME],
        i = [a.LOCALIZATION_TYPE.PARTICIPANT_NAMED_GROUP, a.LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_CURRENT_USER_NICKNAME, a.LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_HOTLIKE, a.LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_PARTICIPANT_NICKNAME, a.LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_PHOTO, a.LOCALIZATION_TYPE.PARTICIPANT_CUSTOMIZE_THEME, a.LOCALIZATION_TYPE.UNKNOWN_USER_NAMED_GROUP, a.LOCALIZATION_TYPE.PARTICIPANT_CLEAR_CURRENT_USER_NICKNAME, a.LOCALIZATION_TYPE.PARTICIPANT_CLEAR_OWN_NICKNAME, a.LOCALIZATION_TYPE.PARTICIPANT_CLEAR_PARTICIPANT_NICKNAME, a.LOCALIZATION_TYPE.PARTICIPANT_SET_OWN_NICKNAME],
        j = [a.LOCALIZATION_TYPE.CURRENT_USER_PINNED_MESSAGE, a.LOCALIZATION_TYPE.CURRENT_USER_UNPINNED_MESSAGE, a.LOCALIZATION_TYPE.PARTICIPANT_PINNED_MESSAGE, a.LOCALIZATION_TYPE.PARTICIPANT_UNPINNED_MESSAGE],
        k = [a.LOCALIZATION_TYPE.TWO_USERS_CONNECTED, a.LOCALIZATION_TYPE.TWO_USERS_CONNECTED_ONE_MSPLIT],
        l = [a.LOCALIZATION_TYPE.CURRENT_USER_SEND_UNRENDERABLE_MESSAGE_FALLBACK, a.LOCALIZATION_TYPE.CURRENT_USER_SEND_LOCATION_FALLBACK, a.LOCALIZATION_TYPE.CURRENT_USER_SEND_POLL_CREATION_FALLBACK, a.LOCALIZATION_TYPE.CURRENT_USER_SEND_CONTACT_SHARE_FALLBACK, a.LOCALIZATION_TYPE.CURRENT_USER_SEND_STORY_MENTION_FALLBACK, a.LOCALIZATION_TYPE.CURRENT_USER_SEND_BUMP_MESSAGE_FALLBACK, a.LOCALIZATION_TYPE.CURRENT_USER_SEND_STICKER_RECEIVER_FETCH_MESSAGE_FALLBACK],
        m = [a.LOCALIZATION_TYPE.PARTICIPANT_SEND_UNRENDERABLE_MESSAGE_FALLBACK, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_LOCATION_FALLBACK, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_POLL_CREATION_FALLBACK, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_CONTACT_SHARE_FALLBACK, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_STORY_MENTION_FALLBACK, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_BUMP_MESSAGE, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_STICKER_RECEIVER_FETCH_MESSAGE_FALLBACK, a.LOCALIZATION_TYPE.META_AI_SEND_MESSAGE_FALLBACK, a.LOCALIZATION_TYPE.USER_SEND_UNAVAILABLE_MESSAGE_FALLBACK, a.LOCALIZATION_TYPE.USER_SEND_ENCRYPTED_MESSAGE_FALLBACK, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_BUMP_MESSAGE_ORIGINAL_UNAVAILABLE_FALLBACK],
        n = [a.LOCALIZATION_TYPE.CURRENT_USER_BUMPED_MESSAGE, a.LOCALIZATION_TYPE.CURRENT_USER_BUMPED_OWN_MESSAGE],
        o = [a.LOCALIZATION_TYPE.PARTICIPANT_BUMPED_CURRENT_USER_MESSAGE, a.LOCALIZATION_TYPE.PARTICIPANT_BUMPED_OWN_MESSAGE, a.LOCALIZATION_TYPE.PARTICIPANT_BUMPED_PARTICIPANT_MESSAGE],
        p = [a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_DAYS, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_HOURS, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_MINUTES, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_CHANGE_SECONDS, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_OFF, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_DAYS, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_HOURS, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_MINUTES, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_SETTING_TURNED_ON_SECONDS, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_DAYS, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_HOURS, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_MINUTES, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_CHANGE_SECONDS, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_OFF, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_DAYS, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_HOURS, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_MINUTES, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_SETTING_TURNED_ON_SECONDS, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_CHANGE_DAYS, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_CHANGE_HOURS, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_CHANGE_MINUTES, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_CHANGE_SECONDS, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_TURNED_OFF, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_TURNED_ON_DAYS, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_TURNED_ON_HOURS, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_TURNED_ON_MINUTES, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_TURNED_ON_SECONDS, a.LOCALIZATION_TYPE.EPHEMERAL_SETTINGS_AUTO_RESET],
        q = [a.LOCALIZATION_TYPE.YOUR_DEVICE_ICDC_ALERT_ADMIN_MESSAGE, a.LOCALIZATION_TYPE.ICDC_ALERT_ADMIN_MESSAGE],
        r = [a.LOCALIZATION_TYPE.CURRENT_USER_MISSED_AUDIO_CALL, a.LOCALIZATION_TYPE.CURRENT_USER_MISSED_VIDEO_CALL, a.LOCALIZATION_TYPE.PARTICIPANT_STARTED_GROUP_AUDIO_CALL, a.LOCALIZATION_TYPE.PARTICIPANT_STARTED_GROUP_VIDEO_CALL],
        s = [a.LOCALIZATION_TYPE.CURRENT_USER_AUDIO_CALLED, a.LOCALIZATION_TYPE.CURRENT_USER_STARTED_GROUP_AUDIO_CALL, a.LOCALIZATION_TYPE.CURRENT_USER_STARTED_GROUP_VIDEO_CALL, a.LOCALIZATION_TYPE.CURRENT_USER_VIDEO_CALLED, a.LOCALIZATION_TYPE.PARTICIPANT_MISSED_AUDIO_CALL, a.LOCALIZATION_TYPE.PARTICIPANT_MISSED_VIDEO_CALL, a.LOCALIZATION_TYPE.PARTICIPANT_AUDIO_CALLED, a.LOCALIZATION_TYPE.PARTICIPANT_VIDEO_CALLED],
        t = [a.LOCALIZATION_TYPE.CURRENT_USER_CREATED_GROUP, a.LOCALIZATION_TYPE.CURRENT_USER_MENTIONED_STORY_IG, a.LOCALIZATION_TYPE.CURRENT_USER_SENT_EVENT, a.LOCALIZATION_TYPE.CURRENT_USER_SENT_POST, a.LOCALIZATION_TYPE.CURRENT_USER_SENT_REEL, a.LOCALIZATION_TYPE.CURRENT_USER_SENT_STORY, a.LOCALIZATION_TYPE.CURRENT_USER_SENT_STORY_HIGHLIGHT, a.LOCALIZATION_TYPE.CURRENT_USER_RECEIVED_STORY_MENTION_IG, a.LOCALIZATION_TYPE.UNAVAILABLE_SNIPPET, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_RECORD_SCREEN, a.LOCALIZATION_TYPE.YOU_EPHEMERAL_TAKE_SCREENSHOT, a.LOCALIZATION_TYPE.CURRENT_USER_UNSENT_MESSAGE],
        u = [a.LOCALIZATION_TYPE.PARTICIPANT_CREATED_GROUP, a.LOCALIZATION_TYPE.UNKNOWN_USER_CREATED_GROUP, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_ATTACHMENT, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_AUDIO, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_GIF, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_IMAGE, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_STICKER, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_TEXT, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_TEXT_IN_GROUP, a.LOCALIZATION_TYPE.PARTICIPANT_SEND_VIDEO, a.LOCALIZATION_TYPE.PARTICIPANT_SENT_EVENT, a.LOCALIZATION_TYPE.PARTICIPANT_SENT_POST, a.LOCALIZATION_TYPE.PARTICIPANT_SENT_REEL, a.LOCALIZATION_TYPE.PARTICIPANT_SENT_STORY, a.LOCALIZATION_TYPE.PARTICIPANT_SENT_STORY_HIGHLIGHT, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_RECORD_SCREEN, a.LOCALIZATION_TYPE.PARTICIPANT_EPHEMERAL_TAKE_SCREENSHOT, a.LOCALIZATION_TYPE.PARTICIPANT_REACT_MESSAGE, a.LOCALIZATION_TYPE.PARTICIPANT_REACT_MESSAGE_IN_GROUP, a.LOCALIZATION_TYPE.PARTICIPANT_UNSENT_MESSAGE, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_RECORD_SCREEN, a.LOCALIZATION_TYPE.UNKNOWN_USER_EPHEMERAL_TAKE_SCREENSHOT];
    a = [a.LOCALIZATION_TYPE.EMPTY_SNIPPET];
    g.cutoverAdminMsgs = b;
    g.deviceChanges = c;
    g.participantsAddedRemoved = e;
    g.groupPermissionsChanged = f;
    g.participantLeftGroup = d;
    g.chatCustomizedByCurrentUser = h;
    g.chatCustomizedByOtherUser = i;
    g.pinnedMessageUpdate = j;
    g.twoUsersConnected = k;
    g.fallbackMsgFromCurrentUser = l;
    g.fallbackMsgFromOtherUser = m;
    g.currentUserBumpsMessage = n;
    g.otherUserBumpsMessage = o;
    g.ephemeralSettingChanges = p;
    g.icdcAlerts = q;
    g.callActionToNotifyAbout = r;
    g.callActionNotToNotifyAbout = s;
    g.otherNonAdminMsgToBeBumped = t;
    g.otherNonAdminMsgToBeMarkedAsUnread = u;
    g.otherNonAdminMsgToNotTriggerUpdate = a
}), 98);
__d("MAWGetThreadUpdateTypeForAdminMsg", ["FBLogger", "MAWAdminMsgTypesGrouped", "MAWLocalizationType", "MAWThreadUpdateType"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = (a = a.msgContent) == null ? void 0 : a.adminType;
        if (a == null) {
            c("FBLogger")("MAWCentralizedThreadUpdate").mustfix("nullAdminType");
            return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
        }
        if (h(a)) return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD;
        if (i(a)) return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD;
        if (j(a)) return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY;
        if (k(a)) return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE;
        c("FBLogger")("MAWCentralizedThreadUpdate").mustfix("unsupportedAdminMsgType");
        return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
    }

    function h(a) {
        return d("MAWAdminMsgTypesGrouped").chatCustomizedByOtherUser.includes(a) || d("MAWAdminMsgTypesGrouped").callActionToNotifyAbout.includes(a) || d("MAWAdminMsgTypesGrouped").twoUsersConnected.includes(a) || d("MAWAdminMsgTypesGrouped").fallbackMsgFromOtherUser.includes(a) || d("MAWAdminMsgTypesGrouped").otherUserBumpsMessage.includes(a) || d("MAWAdminMsgTypesGrouped").otherNonAdminMsgToBeMarkedAsUnread.includes(a) || a === d("MAWLocalizationType").LOCALIZATION_TYPE.REACHABILITY_ERROR
    }

    function i(a) {
        return d("MAWAdminMsgTypesGrouped").participantsAddedRemoved.includes(a) || d("MAWAdminMsgTypesGrouped").chatCustomizedByCurrentUser.includes(a) || d("MAWAdminMsgTypesGrouped").callActionNotToNotifyAbout.includes(a) || d("MAWAdminMsgTypesGrouped").fallbackMsgFromCurrentUser.includes(a) || d("MAWAdminMsgTypesGrouped").currentUserBumpsMessage.includes(a) || d("MAWAdminMsgTypesGrouped").otherNonAdminMsgToBeBumped.includes(a)
    }

    function j(a) {
        return a === d("MAWLocalizationType").LOCALIZATION_TYPE.CUTOVER_ROLLBACK_ADMIN_MESSAGE || d("MAWAdminMsgTypesGrouped").ephemeralSettingChanges.includes(a) || d("MAWAdminMsgTypesGrouped").groupPermissionsChanged.includes(a) || d("MAWAdminMsgTypesGrouped").participantLeftGroup.includes(a) || d("MAWAdminMsgTypesGrouped").pinnedMessageUpdate.includes(a)
    }

    function k(a) {
        return d("MAWAdminMsgTypesGrouped").cutoverAdminMsgs.includes(a) || d("MAWAdminMsgTypesGrouped").deviceChanges.includes(a) || d("MAWAdminMsgTypesGrouped").icdcAlerts.includes(a) || d("MAWAdminMsgTypesGrouped").otherNonAdminMsgToNotTriggerUpdate.includes(a) || a === d("MAWLocalizationType").LOCALIZATION_TYPE.E2EE_THREAD_DESCRIPTION || a === d("MAWLocalizationType").LOCALIZATION_TYPE.EMPTY_SNIPPET || a === d("MAWLocalizationType").LOCALIZATION_TYPE.DEBUG_MSG
    }
    g.getThreadUpdateTypeForAdminMsg = a
}), 98);
__d("MAWGetThreadUpdateType", ["FBLogger", "MAWDbThreadBumpMiddlewareUtils", "MAWGetThreadUpdateTypeForAdminMsg", "MAWThreadSnippetUtils", "MAWThreadUpdateMiddlewareGKUtil", "MAWThreadUpdateType", "MAWUserJidWrapper", "WAJids", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        return b && !d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(a.type) ? d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE : m(a.type)(a)
    }

    function i(a) {
        c("FBLogger")("MAWCentralizedThreadUpdate").mustfix("GetThreadUpdateType not implemented for message type %s", a.type);
        return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
    }

    function j(a, b) {
        if (b && !d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForReactions()) return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE;
        b = k(a.reactToAuthor);
        var c = !k(a.author);
        a = a.reaction == null;
        return b && c && !a ? d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD : d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
    }

    function k(a) {
        return a === d("WAJids").AUTHOR_ME || a === d("MAWUserJidWrapper").getMyUserJid()
    }

    function l(a, b) {
        var c = b.me;
        b = b.other;
        return d("WAJids").isAuthorMe(a.author) ? c : b
    }

    function m(a) {
        switch (a) {
            case "Text":
            case "ReceiverFetch":
            case "Sticker":
            case "Unavailable":
            case "Video":
            case "Futureproof":
            case "DocumentFile":
            case "EphemeralScreenshotAction":
            case "Gif":
            case "Image":
            case "Ptt":
            case "RavenAction":
            case "Raven":
            case "GroupPollCreate":
            case "GroupPollUpdate":
                return function(a) {
                    return l(a, {
                        me: d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD,
                        other: d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD
                    })
                };
            case "XMA":
                return function(a) {
                    return d("MAWThreadSnippetUtils").shouldIgnoreXMAMsgForSnippet(a) ? d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE : l(a, {
                        me: d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD,
                        other: d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD
                    })
                };
            case "Revoked":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD
                };
            case "DeleteForMe":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
                };
            case "BumpExistingMessage":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD
                };
            case "EditAction":
                return function(a) {
                    return l(a, {
                        me: d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY,
                        other: d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
                    })
                };
            case "GroupInvite":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD
                };
            case "Admin":
                return function(a) {
                    if (a.type === "Admin") return d("MAWGetThreadUpdateTypeForAdminMsg").getThreadUpdateTypeForAdminMsg(a);
                    throw c("err")("Non-admin msg passed in " + ((a = a.type) != null ? a : "UNKNOWN"))
                };
            case "SenderKeyDistribution":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
                };
            case "AlertICDC":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD
                };
            case "Ciphertext":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD
                };
            case "EphemeralSettingAdmin":
            case "EphemeralSettingChangeFromCurrentDevice":
            case "EphemeralSyncResponse":
                return function() {
                    return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY
                };
            case "ExpiredEphemeral":
                return i
        }
    }

    function a(a) {
        return d("MAWDbThreadBumpMiddlewareUtils").switchOnMsgOrReactionNullish(a, {
            forMessage: function(a) {
                return h(a, !0)
            },
            forNull: function() {
                return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE
            },
            forReaction: function(a) {
                return j(a, !0)
            }
        })
    }
    g.getThreadUpdateTypeForMsg = h;
    g.getThreadUpdateTypeForReaction = j;
    g.getThreadUpdateTypeForMsgOrReaction = a
}), 98);
__d("MAWUpdateThreadBumpTimestamp", ["I64", "MAWAckLevel", "MAWBridgeTypesCreators", "MAWCalculateBumpTimestampMs", "MAWDbThreadBumpMiddlewareUtils", "MAWIndexedDb", "MAWMsgType", "MAWODSProxy", "MAWThreadBumpType", "MAWThreadSnippetUtils", "MAWThreadUpdateMiddlewareGKUtil", "MAWThreadUpdateType", "WAJids", "gkx", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var b = a.bumpMsgOrReaction,
            e = a.db,
            f = a.isThrottled,
            g = f === void 0 ? !1 : f,
            h = a.odsBumpParams;
        f = a.sentByLocalDevice;
        var m = f === void 0 ? !1 : f,
            n = a.thread,
            o = a.threadUpdateType,
            p = a.unbumpTrigger;
        f = p != null;
        return d("MAWThreadSnippetUtils").getThreadSnippetFromScratch(e, n.jid, !f).then(function(a) {
            var e;
            e = k((e = p) != null ? e : b, a, o);
            var f;
            switch (e) {
                case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE:
                    f = !1;
                    break;
                case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY:
                    f = !0;
                    i("Updating snippet only since no message is eligible for bump", n, c("nullthrows")(a));
                    break;
                case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD:
                case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD:
                    f = !0;
                    var q = l(b, p, m, g);
                    j(c("nullthrows")(b), q, n, e, c("nullthrows")(a));
                    break;
                default:
                    e;
                    f = !1;
                    break
            }
            f && d("MAWODSProxy").odsBumpEntityKey(h)
        })
    }

    function i(a, b, c) {
        var e;
        d("MAWIndexedDb").afterTransaction({
            tag: "CentralizedThreadUpdate",
            value: d("MAWBridgeTypesCreators").createBridgeCentralizedThreadUpdate({
                centralizedThreadBumpData: null,
                centralizedThreadSnippetData: {
                    snippetContactIDs: c.snippetParams.contactIDs,
                    snippetMentionJIDs: (e = c.snippetParams.mentionJIDs) != null ? e : [],
                    snippetParams: c.snippetParams.strings,
                    snippetSenderContactId: c.snippetSenderContactId,
                    snippetType: c.snippetType
                },
                description: a,
                jid: b.jid,
                threadUpdateType: d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY
            })
        })
    }

    function j(a, b, c, e, f) {
        d("MAWIndexedDb").afterTransaction({
            tag: "CentralizedThreadUpdate",
            value: d("MAWBridgeTypesCreators").createBridgeCentralizedThreadUpdate({
                centralizedThreadBumpData: b,
                centralizedThreadSnippetData: {
                    snippetContactIDs: f.snippetParams.contactIDs,
                    snippetMentionJIDs: (b = f.snippetParams.mentionJIDs) != null ? b : [],
                    snippetParams: f.snippetParams.strings,
                    snippetSenderContactId: f.snippetSenderContactId,
                    snippetType: f.snippetType
                },
                description: d("MAWDbThreadBumpMiddlewareUtils").switchOnMsgOrReaction(a, {
                    forMessage: function(a) {
                        return "CentralizedThreadUpdate-MsgType:" + a.type
                    },
                    forReaction: function() {
                        return "CentralizedThreadUpdate-Reaction"
                    }
                }),
                jid: c.jid,
                threadUpdateType: e
            })
        })
    }

    function k(a, b, c) {
        var e = d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE;
        b = b != null;
        var f = d("MAWDbThreadBumpMiddlewareUtils").switchOnMsgOrReactionNullish(a, {
            forMessage: function(b) {
                return d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type) && (a == null ? void 0 : a.type) !== d("MAWMsgType").MSG_TYPE.REVOKED
            },
            forNull: function() {
                return !1
            },
            forReaction: function() {
                return d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForReactions()
            }
        });
        switch (c) {
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE:
                return c;
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY:
                return b ? c : e;
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD:
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD:
                if (f && b) return c;
                else if (b) return d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY;
                else return e;
            default:
                c;
                return e
        }
    }

    function l(a, b, c, e) {
        var f = b != null;
        return {
            bumpedByLocalDeviceSend: c,
            bumpTimestampMs: n(a),
            isAuthorMe: d("MAWDbThreadBumpMiddlewareUtils").switchOnMsgOrReactionNullish((c = b) != null ? c : a, {
                forMessage: function(a) {
                    return a.author === d("WAJids").AUTHOR_ME
                },
                forNull: function() {
                    return !1
                },
                forReaction: function(a) {
                    return a.author === d("WAJids").AUTHOR_ME
                }
            }),
            isThrottled: e,
            isUnbump: f,
            threadBumpType: m((c = b) != null ? c : a, f)
        }
    }

    function m(a, b) {
        return d("MAWDbThreadBumpMiddlewareUtils").switchOnMsgOrReactionNullish(a, {
            forMessage: function(a) {
                return d("MAWAckLevel").isMsgAuthoritative(a.ack) && a.serverTs != null ? d("MAWThreadBumpType").THREAD_BUMP_TYPE.LOCAL_AND_SERVER : c("gkx")("7698") ? d("MAWThreadBumpType").THREAD_BUMP_TYPE.NO_UPDATE : d("MAWThreadBumpType").THREAD_BUMP_TYPE.LOCAL_ONLY
            },
            forNull: function() {
                return d("MAWThreadBumpType").THREAD_BUMP_TYPE.NO_UPDATE
            },
            forReaction: function() {
                return b && !c("gkx")("7007") ? d("MAWThreadBumpType").THREAD_BUMP_TYPE.LOCAL_ONLY : d("MAWThreadBumpType").THREAD_BUMP_TYPE.LOCAL_AND_SERVER
            }
        })
    }

    function n(a) {
        return d("MAWDbThreadBumpMiddlewareUtils").switchOnMsgOrReactionNullish(a, {
            forMessage: function(a) {
                return d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMsForMsg({
                    msg: a,
                    throwIfNoServerTs: d("MAWAckLevel").isMsgAuthoritative(a.ack) && a.serverTs != null
                })
            },
            forNull: function() {
                return (h || (h = d("I64"))).zero
            },
            forReaction: d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMsForReaction
        })
    }
    g.updateThreadViaCentralizedThreadUpdate = a;
    g.updateSnippetViaCentralizedThreadHandler = i;
    g.getBumpTimestampMs = n
}), 98);
__d("MAWDbThreadBumpMiddlewareUtils", ["I64", "MAWCalculateBumpTimestampMs", "MAWDbMsg", "MAWDbReaction", "MAWGetThreadUpdateType", "MAWThreadUpdateType", "WATimeUtils", "emptyArray", "err", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        a = a.reduce(function(a, b) {
            return a.set(b.threadJid, [].concat((a = a.get(b.threadJid)) != null ? a : c("emptyArray"), [b]).toSorted(function(a, b) {
                return i(b, a)
            }))
        }, new Map());
        var b = new Map();
        a.forEach(function(a, e) {
            var f = null,
                g = d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY;
            for (var a = a, h = Array.isArray(a), i = 0, a = h ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var k;
                if (h) {
                    if (i >= a.length) break;
                    k = a[i++]
                } else {
                    i = a.next();
                    if (i.done) break;
                    k = i.value
                }
                k = k;
                var l = d("MAWGetThreadUpdateType").getThreadUpdateTypeForMsg(k, !1);
                switch (l) {
                    case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE:
                    case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY:
                        continue;
                    case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD:
                        f = j(f, k);
                        g = d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD;
                        break;
                    case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD:
                        f = j(f, k);
                        g = d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD;
                        break;
                    default:
                        throw c("err")("[MAWCentralizedThreadUpdate] Unhandled threadUpdateType " + l)
                }
                if (f != null) break
            }
            b.set(e, {
                bumpMsg: f,
                threadUpdateType: g
            })
        });
        return b
    }

    function i(a, b) {
        var c;
        c = (c = a.sortOrderMs) != null ? c : (h || (h = d("I64"))).to_float(d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMsForMsg({
            msg: a,
            throwIfNoServerTs: !1
        }));
        a = (a = b.sortOrderMs) != null ? a : (h || (h = d("I64"))).to_float(d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMsForMsg({
            msg: b,
            throwIfNoServerTs: !1
        }));
        return c - a
    }

    function j(a, b) {
        if (a == null || b == null) {
            var d;
            return c("nullthrows")((d = a) != null ? d : b, "both messages are null")
        }
        return i(a, b) > 0 ? a : b
    }

    function b(a) {
        return a.msgId != null ? d("WATimeUtils").castToMillisTime(d("MAWDbMsg").getSortOrderWithFallback(a)) : d("MAWDbReaction").getReactionTimeMs(a)
    }

    function e(a, b) {
        return a.msgId != null ? b.forMessage(a) : b.forReaction(a)
    }

    function f(a, b) {
        return a == null ? b.forNull() : a.msgId != null ? b.forMessage(a) : b.forReaction(a)
    }

    function k(a) {
        return a.reduce(function(a, b) {
            b.type == null ? (a.reactions == null && (a.reactions = 0), a.reactions += 1) : (a[b.type] == null && (a[b.type] = 0), a[b.type] += 1);
            return a
        }, {})
    }
    g.createThreadUpdateInfoWithoutSnippetMsgFromInsertedMsgs = a;
    g.getMsgOrReactionTimeMs = b;
    g.switchOnMsgOrReaction = e;
    g.switchOnMsgOrReactionNullish = f;
    g.getMessageTypesFromValues = k
}), 98);
__d("last", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = null;
        if (Array.isArray(a) || typeof a === "string") a.length && (b = {
            value: a[a.length - 1]
        });
        else
            for (var a = a, c = Array.isArray(a), d = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (c) {
                    if (d >= a.length) break;
                    e = a[d++]
                } else {
                    d = a.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                b = b || {};
                b.value = e
            }
        return b ? b.value : null
    }
    f["default"] = a
}), 66);
__d("MAWThreadNewestMsgOrReactionUtils", ["MAWDbMsg", "MAWDbMsgTxns", "MAWDbReaction", "MAWDbReactionsTxns", "MAWDbThreadBumpMiddlewareUtils", "MAWGetThreadUpdateType", "MAWThreadUpdateMiddlewareGKUtil", "MAWThreadUpdateType", "WALogger", "WAMsg", "WATimeUtils", "err", "first", "last"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[CentralizedThreadUpdate] No Reaction or Message in ", " is eligible for snippet"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return l(a, b, {
            checkIfMiddlewareIsEnabled: !1,
            filter: i
        })
    }

    function i(a, b) {
        switch (a) {
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD:
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD:
                return b !== !0;
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE:
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY:
                return !1;
            default:
                throw c("err")("[MAWCentralizedThreadUpdate] Unhandled threadUpdateType to create filter function : " + a)
        }
    }

    function b(a, b, c) {
        c === void 0 && (c = !0);
        return l(a, b, {
            checkIfMiddlewareIsEnabled: c,
            filter: j
        })
    }

    function j(a, b) {
        switch (a) {
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.SNIPPET_ONLY:
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.BUMP_THREAD:
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.MARK_THREAD_AS_UNREAD:
                return b !== !0;
            case d("MAWThreadUpdateType").THREAD_UPDATE_TYPE.NO_SNIPPET_OR_ACTIVITY_TS_UPDATE:
                return !1;
            default:
                throw c("err")("[MAWCentralizedThreadUpdate] Unhandled threadUpdateType to create filter function : " + a)
        }
    }

    function k(a, b, c) {
        return m(a, b, c).then(function(e) {
            return n(a, b, c, e != null ? d("MAWDbMsg").getSortOrderWithFallback(e) : Number.MIN_SAFE_INTEGER).then(function(a) {
                if (e == null && a == null) {
                    d("WALogger").WARN(h(), b);
                    return null
                }
                if (a == null) return e;
                if (e == null) return a;
                var c = d("WATimeUtils").castToMillisTime(d("MAWDbMsg").getSortOrderWithFallback(e)),
                    f = d("MAWDbReaction").getReactionTimeMs(a);
                return c >= f ? e : a
            })
        })
    }

    function l(a, b, c) {
        return k(a, b, c.filter).then(function(a) {
            return !c.checkIfMiddlewareIsEnabled ? a : d("MAWDbThreadBumpMiddlewareUtils").switchOnMsgOrReactionNullish(a, {
                forMessage: function(a) {
                    return d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(a.type) ? a : null
                },
                forNull: function() {
                    return null
                },
                forReaction: function(a) {
                    return d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForReactions() ? a : null
                }
            })
        })
    }

    function m(a, b, e) {
        return d("MAWDbMsgTxns").fetchMessagesFromDbWithSortOrderMs(a, b, null, !0, 1, function(a) {
            return e(d("MAWGetThreadUpdateType").getThreadUpdateTypeForMsg(a, !1), a.ephemeralMsgDisappeared === !0)
        }, "before").then(c("first"))
    }

    function n(a, b, e, f) {
        f === void 0 && (f = Number.MIN_SAFE_INTEGER);
        var g = function(c, g) {
                return d("MAWDbReactionsTxns").fetchReactionsFromDbWithTimestamp(a, b, g, g == null, c, function(a) {
                    return e(d("MAWGetThreadUpdateType").getThreadUpdateTypeForReaction(a, !1), !1) && d("MAWDbReaction").getReactionTimeMs(a) > f
                })
            },
            h = [1, 10],
            i = 100,
            j = new Set(),
            k = function b(d, e) {
                var f;
                return g((f = h[d]) != null ? f : i, e).then(function(e) {
                    return e.length === 0 ? null : o(a, e.filter(function(a) {
                        return !j.has(q(a))
                    })).then(function(a) {
                        var f = a.newestReaction;
                        a = a.nullMsgIds;
                        if (f != null) return f;
                        a.forEach(function(a) {
                            return j.add(a)
                        });
                        return b(d + 1, c("last")(e))
                    })
                })
            };
        return k(0, null)
    }

    function o(a, b) {
        return d("MAWDbMsgTxns").getUniqueMsgsByProtocolMsgIds(a, b.map(p)).then(function(a) {
            var c = new Set(a.map(r)),
                d = new Set(),
                e = null;
            b.forEach(function(a) {
                var b = q(a);
                c.has(b) ? e = s(e, a) : d.add(b)
            });
            return {
                newestReaction: e,
                nullMsgIds: d
            }
        })
    }

    function p(a) {
        return {
            author: a.reactToAuthor,
            chat: a.threadJid,
            externalId: a.reactToExternalId
        }
    }

    function q(a) {
        return d("WAMsg").craftWAMsgIdString(p(a))
    }

    function r(a) {
        return d("WAMsg").craftWAMsgIdString({
            author: a.author,
            chat: a.threadJid,
            externalId: a.externalId
        })
    }

    function s(a, b) {
        if (a == null) return b;
        return b == null ? a : d("MAWDbReaction").getReactionTimeMs(a) > d("MAWDbReaction").getReactionTimeMs(b) ? a : b
    }
    g.getNewestMsgOrReactionForBump = a;
    g.getNewestMsgOrReactionForSnippet = b;
    g.getNewestReactionToNonNullMsg = o
}), 98);
__d("MAWDbGroupInfoTxns", ["MAWBridgeTypesCreators", "MAWIndexedDb", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return h(a, b.jid).then(function(c) {
            var d = b.participantVersion;
            c.success && c.value.participantVersion != null && b.participantVersion == null && (d = c.value.participantVersion);
            c = b.subject.content;
            c != null && c.length === 0 && (c = void 0);
            var e = {
                creationTs: b.creationTs,
                creator: b.creator,
                groupJid: b.jid,
                inviter: b.inviter,
                memberAddMode: b.memberAddMode,
                name: c,
                nameOwner: b.subject.user,
                nameTs: b.subject.ts,
                participantVersion: d
            };
            return i(a, e).then(function() {
                return e
            })
        })
    }

    function h(a, b) {
        return a.groupInfo.get({
            groupJid: b
        }).then(function(a) {
            return a == null ? d("WAResultOrError").makeError("missing") : d("WAResultOrError").makeResult(a)
        })
    }

    function i(a, b) {
        return a.groupInfo.put(b).then(function() {
            d("MAWIndexedDb").afterTransaction({
                tag: "GroupInfoUpdated",
                value: d("MAWBridgeTypesCreators").createBridgeUpdatedGroupInfo(b)
            })
        })
    }

    function b(a, b) {
        return a.groupInfo.bulkPut(b).then(function() {
            b.forEach(function(a) {
                return d("MAWIndexedDb").afterTransaction({
                    tag: "GroupInfoUpdated",
                    value: d("MAWBridgeTypesCreators").createBridgeUpdatedGroupInfo(a)
                })
            })
        })
    }

    function c(a, b) {
        return a.groupInfo.bulkGet(b)
    }

    function e(a, b) {
        return a.groupInfo["delete"](b)
    }
    g.putGroupInfo = a;
    g.getGroupInfo = h;
    g.updateGroupInfo = i;
    g.bulkUpdateGroupInfo = b;
    g.getGroupInfos = c;
    g.deleteGroupInfo = e
}), 98);
__d("MAWThreadSnippetBuildTxns", ["$InternalEnum", "FBLogger", "I64", "MAWBridgeTypesCreators", "MAWCalculateBumpTimestampMs", "MAWDbGroupInfoTxns", "MAWDbMsg", "MAWDexieTable", "MAWIndexedDb", "MAWJidUtils", "MAWLocalizationType", "MAWMsgType", "MAWThreadSnippet", "MAWThreadSnippetUtils", "MAWThreadUpdateMiddlewareGKUtil", "MAWUserJidWrapper", "WAJids", "WALongInt", "WAProtocolMsgId", "WATimeUtils", "emptyFunction", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = b("$InternalEnum").Mirrored(["DO_NOT_BUMP_THREAD", "MATCH_BUMP_TIMESTAMP_MS_TO_SNIPPET"]);

    function j(a, b, c) {
        return d("MAWDexieTable").dexieAll([d("MAWDbGroupInfoTxns").getGroupInfo(a, d("WAJids").toGroupJid(b.threadJid))]).then(function(a) {
            a = a[0];
            a = a.success;
            return d("MAWThreadSnippet").buildThreadSnippet(b, a, c)
        })
    }

    function a(a, b, c, e) {
        return d("MAWDexieTable").dexieAll([d("MAWDbGroupInfoTxns").getGroupInfo(a, d("WAJids").toGroupJid(e))]).then(function(a) {
            a = a[0];
            a = a.success;
            return k(b, c, a)
        })
    }

    function k(a, b, e) {
        var f;
        d("WAJids").isAuthorMe(a) ? (c("FBLogger")("maw_db").warn("[MAWThreadSnippetBuildTxns] Reaction snippet author should not be @me"), f = d("WAJids").userIdFromJid(d("MAWUserJidWrapper").getMyUserJid())) : f = d("WAJids").userIdFromJid(a);
        a = {
            contactIDs: [],
            strings: []
        };
        e = e ? d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REACT_MESSAGE_IN_GROUP : d("MAWLocalizationType").LOCALIZATION_TYPE.PARTICIPANT_REACT_MESSAGE;
        a.contactIDs.push(f);
        a.strings.push(b);
        return {
            snippetParams: a,
            snippetSenderContactId: f,
            snippetType: e
        }
    }

    function e(a, b, e, f) {
        var g = e.newestReaction,
            h = e.reactionsToClear;
        if (g != null && d("WATimeUtils").castUnixTimeToMillisTime(g.ts) > ((e = b.snippetMsgTs) != null ? e : 0)) return d("MAWDexieTable").dexieResolve({
            newestReaction: g,
            thread: l(b, g, f)
        });
        e = c("justknobx")._("2763") ? h != null && h.length > 0 : h != null;
        return e && b.snippetMsg != null ? a.reactions.get({
            reactionId: b.snippetMsg
        }).then(function(c) {
            var e = !1;
            if (c == null) e = !0;
            else {
                var f = d("MAWJidUtils").maybeToProtocolMsgId(c.author, c.threadJid, c.reactToExternalId);
                f != null && (e = h.some(function(a) {
                    a = d("MAWJidUtils").maybeToProtocolMsgId(a.author, a.threadJid, a.reactToExternalId);
                    return a != null && d("WAProtocolMsgId").equals(a, f)
                }))
            }
            return e ? m(a, {
                bumpThreadOption: i.DO_NOT_BUMP_THREAD,
                isUnbump: !0,
                thread: b
            }).then(function(a) {
                return {
                    newestReaction: null,
                    thread: a
                }
            }) : d("MAWDexieTable").dexieResolve({
                newestReaction: null,
                thread: b
            })
        }) : d("MAWDexieTable").dexieResolve({
            newestReaction: null,
            thread: b
        })
    }

    function l(a, b, c) {
        if (!d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForReactions()) {
            var e = d("WATimeUtils").castUnixTimeToMillisTime(b.ts);
            c = k(b.author, b.reaction, c);
            var f = c.snippetParams,
                g = c.snippetSenderContactId;
            c = c.snippetType;
            var i = b.externalId !== void 0 ? (h || (h = d("I64"))).of_string_opt(b.externalId) : void 0;
            e = b.senderTimestampMs != null ? (h || (h = d("I64"))).of_string(d("WALongInt").longIntToDecimalString(b.senderTimestampMs)) : d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMs(e, i);
            d("MAWIndexedDb").afterTransaction({
                tag: "ThreadBumpedV2",
                value: d("MAWBridgeTypesCreators").createBridgeBumpedThreadV2({
                    bumpTimestampMs: e,
                    description: "newReaction",
                    isMessageAuthorMe: !1,
                    snippetData: {
                        params: f,
                        senderContactId: g,
                        type: c
                    },
                    threadJid: a.jid
                })
            })
        }
        return babelHelpers["extends"]({}, a, {
            snippetMsg: b.reactionId,
            snippetMsgTs: d("WATimeUtils").castUnixTimeToMillisTime(b.ts)
        })
    }

    function m(a, b) {
        var e = b.bumpMessageAuthorMap,
            f = b.bumpThreadOption,
            g = b.isUnbump,
            k = g === void 0 ? !1 : g,
            l = b.thread;
        return d("MAWThreadSnippetUtils").recalculateSnippetFromScratch_EXPENSIVE(a, l).then(function(b) {
            if (b == null) {
                d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(d("MAWMsgType").MSG_TYPE.TEXT) ? c("FBLogger")("MAWCentralizedThreadUpdate").mustfix("[Occamadillo] ThreadUpdated handler called for clear snippet when centralized thread bump is enabled") : d("MAWIndexedDb").afterTransaction({
                    tag: "ThreadUpdated",
                    value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                        snippetParams: {
                            contactIDs: [],
                            strings: []
                        },
                        snippetSenderContactId: "0",
                        snippetType: d("MAWLocalizationType").LOCALIZATION_TYPE.EMPTY_SNIPPET,
                        threadJid: l.jid
                    })
                });
                return babelHelpers["extends"]({}, l, {
                    snippetMsg: void 0,
                    snippetMsgTs: void 0
                })
            }
            var g = e == null ? void 0 : e.get(b.externalId);
            return j(a, b, g).then(function(a) {
                var c = a.snippetParams,
                    e = a.snippetSenderContactId;
                a = a.snippetType;
                var g = d("WATimeUtils").castUnixTimeToMillisTime(d("MAWDbMsg").getCanonicalTsFromMsg(b));
                switch (f) {
                    case i.DO_NOT_BUMP_THREAD:
                        d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type) || d("MAWIndexedDb").afterTransaction({
                            tag: "ThreadUpdated",
                            value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                                snippetParams: c,
                                snippetSenderContactId: e,
                                snippetType: a,
                                threadJid: l.jid
                            })
                        });
                        break;
                    case i.MATCH_BUMP_TIMESTAMP_MS_TO_SNIPPET:
                        if (!d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type)) {
                            var j = d("MAWCalculateBumpTimestampMs").calculateBumpTimestampMs(g, (h || (h = d("I64"))).of_string_opt(b == null ? void 0 : b.externalId));
                            d("MAWIndexedDb").afterTransaction({
                                tag: "ThreadBumpedV2",
                                value: d("MAWBridgeTypesCreators").createBridgeBumpedThreadV2({
                                    bumpTimestampMs: j,
                                    description: "getRefreshThreadSnippetChangeset",
                                    isMessageAuthorMe: b.author === "@me",
                                    isUnbump: k,
                                    skipBumpTimestampValidation: !0,
                                    skipServerThreadBump: !1,
                                    snippetData: {
                                        params: c,
                                        senderContactId: e,
                                        type: a
                                    },
                                    threadJid: l.jid
                                })
                            })
                        }
                }
                return babelHelpers["extends"]({}, l, {
                    snippetMsg: b.msgId,
                    snippetMsgTs: g
                })
            })
        })
    }

    function f(a, b, d) {
        return m(a, {
            bumpMessageAuthorMap: d,
            bumpThreadOption: i.DO_NOT_BUMP_THREAD,
            thread: b
        }).then(function(b) {
            return a.threads.put(b).then(c("emptyFunction"))
        })
    }
    g.buildThreadSnippet = j;
    g.buildReactionThreadSnippet = a;
    g.getReactionSnippetParams = k;
    g.getThreadChangesetForReactionChanges = e;
    g.getThreadChangesetForNewReaction = l;
    g.refreshThreadSnippet = f
}), 98);
__d("MAWEphemeralMsgUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return function(b) {
            return !a.has(b.msgId) && b.ephemeralMsgDisappeared !== !0
        }
    }
    f.filterNonExpiredMsg = a
}), 66);
__d("MAWThreadSnippetUtils", ["FBLogger", "MAWBridgeTypesCreators", "MAWDbMsg", "MAWDbReaction", "MAWDexieTable", "MAWEphemeralMsgUtils", "MAWIndexedDb", "MAWLocalizationType", "MAWLocalizationUtils", "MAWMsgType", "MAWThreadNewestMsgOrReactionUtils", "MAWThreadSnippetBuildTxns", "MAWThreadUpdateMiddlewareGKUtil", "MAWUpdateThreadBumpTimestamp", "MAWXMAUtils", "WALogger", "performance"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[MAWCentralizedThreadUpdate] Snippet Updated using cached field as no snippet is found from scratch. jid: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j(a) {
        var b;
        if (q(a)) return !0;
        b = ((b = a.msgContent) == null ? void 0 : b.adminType) != null ? d("MAWLocalizationUtils").isDeviceChangeAdminMsg(a.msgContent.adminType) : !1;
        if (a.type !== d("MAWMsgType").MSG_TYPE.ADMIN) return !1;
        a = a.msgContent.adminType;
        return a === d("MAWLocalizationType").LOCALIZATION_TYPE.DEBUG_MSG ? !0 : b
    }

    function a(a, b, c) {
        return a.messages.where("[threadJid+sortOrderMs]").between([b.jid, Number.MIN_SAFE_INTEGER], [b.jid, Number.MAX_SAFE_INTEGER], !1, !1).filter(function(a) {
            return (c == null || d("MAWEphemeralMsgUtils").filterNonExpiredMsg(c)(a)) && !j(a)
        }).reverse().first()
    }

    function k(a, b) {
        return m(a, b).then(function(a) {
            if (a != null) {
                var c = a.snippetParams,
                    e = a.snippetSenderContactId;
                a = a.snippetType;
                d("MAWIndexedDb").afterTransaction({
                    tag: "ThreadUpdated",
                    value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                        snippetParams: c,
                        snippetSenderContactId: e,
                        snippetType: a,
                        threadJid: b.jid
                    })
                })
            }
        })
    }

    function l(a, b, c, e) {
        e = e != null ? d("MAWDbReaction").castToIncomingDbReaction(e) : e;
        return e != null && e.ts > (b != null ? d("MAWDbMsg").getCanonicalTsFromMsg(b) : 0) ? d("MAWThreadSnippetBuildTxns").buildReactionThreadSnippet(a, e.author, e.reaction, c) : b == null ? d("MAWDexieTable").dexieResolve() : d("MAWThreadSnippetBuildTxns").buildThreadSnippet(a, b)
    }

    function m(a, b) {
        var e = b.newestMsg,
            f = b.snippetMsg,
            g = (f = f) != null ? f : e;
        return g == null ? d("MAWDexieTable").dexieResolve() : d("MAWDexieTable").dexieAll([a.messages.get({
            msgId: g
        }), a.reactions.get({
            reactionId: g
        })]).then(function(d) {
            var e = d[0];
            d = d[1];
            e != null && d != null && c("FBLogger")("maw_db").warn("[MAWUpdateThreadSnippet] msgId collision detected between Reaction and Message. jid: %s, msgId: %s", b.jid, g);
            return l(a, e, b.jid, d)
        })
    }
    var n = {
        snippetParams: {
            contactIDs: [],
            mentionJIDs: [],
            strings: []
        },
        snippetSenderContactId: null,
        snippetType: d("MAWLocalizationType").LOCALIZATION_TYPE.EMPTY_SNIPPET
    };

    function o(a, b) {
        return p(a, b.jid).then(function(c) {
            if (c == null) return k(a, b).then(function() {
                d("WALogger").WARN(i(), b.jid)
            });
            d("MAWUpdateThreadBumpTimestamp").updateSnippetViaCentralizedThreadHandler("calculateAndUpdateSnippetToUI", b, c)
        })
    }

    function p(a, b, e) {
        e === void 0 && (e = !0);
        var f = (h || (h = c("performance"))).now();
        return d("MAWThreadNewestMsgOrReactionUtils").getNewestMsgOrReactionForSnippet(a, b, e).then(function(e) {
            var g = (h || (h = c("performance"))).now();
            c("FBLogger")("MAWCentralizedThreadUpdate").warn("[getThreadSnippetFromScratch] Recalculating snippet from scratch took %s ms", g - f);
            if (e == null) {
                if (d("MAWThreadUpdateMiddlewareGKUtil").isMiddlewareFullyRolledOut()) return n;
                return
            }
            return l(a, e.msgId != null ? e : null, b, e.reactionId != null ? e : null).then(function(a) {
                return a
            })
        })
    }

    function b(a, b) {
        return d("MAWThreadUpdateMiddlewareGKUtil").isSnippetRecalculationEnabled() ? o(a, b) : k(a, b)
    }

    function q(a) {
        return d("MAWXMAUtils").isXMAStoryReply(a.xmaMessageType) || d("MAWXMAUtils").isXMAMsgHighlightsTabFriendUpdatesReply(a.xmaMessageType)
    }
    g.isDbMsgDisabledForThreadSnippet = j;
    g.recalculateSnippetFromScratch_EXPENSIVE = a;
    g.updateExistingSnippetToUI = k;
    g.EMPTY_SNIPPET_DATA = n;
    g.calculateAndUpdateSnippetToUI = o;
    g.getThreadSnippetFromScratch = p;
    g.updateSnippetToUIOnPageLoad = b;
    g.shouldIgnoreXMAMsgForSnippet = q
}), 98);
__d("MAWUpdateQuotedMsgTxns", ["MAWAuthor", "MAWBridgeMsg", "MAWDbXMATxns", "MAWDexieTable", "MAWIndexedDb", "MAWLoadReplyMediaTxns", "MAWMsgType", "WAJids", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a, b, c, e, f, g, h) {
            var i = d("MAWAuthor").getAuthorUserJid(e);
            return a.messages.where("quoteExternalId").equals(c).toArray().then(function(c) {
                if (c.length === 0) return;
                var e = c;
                (h == null || !h) && (e = c.filter(function(a) {
                    var c = a.quote;
                    a = a.threadJid;
                    return d("MAWAuthor").getAuthorUserJid(c == null ? void 0 : c.content.author) === i && a === b
                }));
                var j = e.map(function(a) {
                    var b;
                    b = Object.assign({}, (b = a.quote) == null ? void 0 : b.content, f.content);
                    b = babelHelpers["extends"]({}, a.quote, f, {
                        content: b
                    });
                    b.content.msgId == null && g != null && (b.content.msgId = g);
                    return babelHelpers["extends"]({}, a, {
                        quote: b
                    })
                });
                return a.messages.bulkPut(j).then(function() {
                    return j
                })
            })
        },
        i = function(a, b, c, e, f) {
            f === void 0 && (f = d("MAWMsgType").MSG_TYPE.UNAVAILABLE);
            f = {
                content: {
                    mediaId: void 0,
                    msgContent: void 0,
                    type: f
                }
            };
            return h(a, b, c, e, f).then(function(a) {
                if (a == null) return;
                a.forEach(function(a) {
                    d("MAWIndexedDb").afterTransaction({
                        tag: "MsgUpdated",
                        value: d("MAWBridgeMsg").createBridgeMsg(a)
                    })
                })
            })
        };
    b = function(a, b, c) {
        c === void 0 && (c = d("MAWMsgType").MSG_TYPE.UNAVAILABLE);
        var e = b.author,
            f = b.chat,
            g = b.externalId;
        return a.threads.get({
            jid: f
        }).then(function(b) {
            if (b == null) return;
            return i(a, b.jid, g, e, c)
        })
    };
    var j = function(a, b, c, e) {
        var f = c.author,
            g = c.externalId,
            i = c.mediaId,
            j = c.msgContent,
            k = c.msgId,
            l = c.plaintextHash,
            m = c.ts,
            n = c.type;
        if (d("WAJids").isAuthorSystem(f)) return d("MAWDexieTable").dexieResolve();
        var o = {
            author: f,
            chat: b,
            externalId: g
        };
        if (!d("MAWMsgType").isQuotedMsgType(n)) return d("MAWDexieTable").dexieResolve();
        var p = d("MAWDexieTable").dexieResolve(null);
        c.type === d("MAWMsgType").MSG_TYPE.XMA && (p = d("MAWDbXMATxns").maybeGetXMAPayloadFromProtocolMsgId(a, o).then(function(a) {
            return a.success === !1 ? d("MAWDexieTable").dexieResolve(null) : d("MAWDexieTable").dexieResolve(a.value)
        }));
        return p.then(function(c) {
            var d;
            c = {
                author: f,
                externalId: g,
                mediaId: (d = c == null ? void 0 : (d = c.defaultPreview) == null ? void 0 : d.mediaId) != null ? d : i,
                msgContent: j,
                plaintextHash: (d = c == null ? void 0 : (d = c.defaultPreview) == null ? void 0 : d.plaintextHash) != null ? d : l,
                ts: m,
                type: n,
                xmaMessageType: c == null ? void 0 : (d = c.xma) == null ? void 0 : d.targetType
            };
            return h(a, b, g, f, {
                content: c
            }, k, e)
        })
    };

    function a(a, b, e) {
        return !c("gkx")("5029") ? d("MAWDexieTable").dexieResolve() : d("MAWDexieTable").dexieAll([j(a, e, b), d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, b)]).then(function(c) {
            var e = c[0];
            c = c[1];
            if (e != null) return d("MAWDexieTable").dexieResolve(k(b, c)).then(function() {
                d("MAWDexieTable").dexieAll(e.map(function(b) {
                    return d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, b).then(function(a) {
                        k(b, a);
                        return b
                    })
                }))
            });
            else return d("MAWDexieTable").dexieResolve([])
        })
    }

    function k(a, b) {
        d("MAWIndexedDb").afterTransaction({
            tag: "MsgUpdated",
            value: d("MAWBridgeMsg").createBridgeMsg(a, void 0, b)
        })
    }
    g.disassociateQuotedMsg = i;
    g.disassociateQuotedMessageByProtocolMsgId = b;
    g.associateQuotedMessage = j;
    g.associateAllReplies = a;
    g.issueReplyMsgUpdate = k
}), 98);
__d("MAWWriteDeleteMessageTxns", ["EBUploadMessages", "MAWAckLevel", "MAWBridgeTypesCreators", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbPendingStanza", "MAWDbReactionsTxns", "MAWDbThreadTxns", "MAWDbXMATxns", "MAWDeleteForMeMsgContentCleaner", "MAWDexieTable", "MAWFTSTxns", "MAWIndexedDb", "MAWMsgType", "MAWPendingStanzaCleaner", "MAWThreadSnippetBuildTxns", "MAWUpdateQuotedMsgTxns", "MAWXMAUtils", "WAResultOrError", "WATimeUtils", "gkx", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 6 * d("WATimeUtils").HOUR_SECONDS,
        i = 30 * d("WATimeUtils").DAY_SECONDS;

    function a(a, b) {
        var c = b.protocolMsgId,
            e = c.author;
        b = c.chat;
        var f = c.externalId;
        return d("MAWDexieTable").dexieAll([d("MAWDbThreadTxns").getThread(a, b), a.unrenderedMessages.get({
            externalId: f
        }), d("MAWFTSTxns").maybePutMessageToPurgeBacklog(a, f)]).then(function(b) {
            var g = b[0];
            b = b[1];
            if (!g.success) return d("WAResultOrError").makeError("missing_thread");
            return b != null && b.threadJid === g.value.jid && b.author === e ? d("WAResultOrError").makeError("duplicate_delete_for_me") : d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, c).then(function(b) {
                if (b == null) {
                    var h = {
                            ack: d("MAWAckLevel").ACK.received,
                            author: e,
                            externalId: f,
                            threadJid: g.value.jid,
                            type: d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME
                        },
                        k = d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + i);
                    h = {
                        deleteTs: k,
                        externalIdWithType: f + "_" + d("MAWDbPendingStanza").PENDING_DELETE_FOR_ME,
                        pendingContent: {
                            content: h,
                            type: d("MAWDbPendingStanza").PENDING_TYPE.DELETE_FOR_ME
                        }
                    };
                    return a.pendingStanzas.add(h).then(function() {
                        d("MAWPendingStanzaCleaner").addNewPendingStanzaCleanerTimestamp(k);
                        return d("WAResultOrError").makeResult()
                    })
                }
                return d("MAWDexieTable").dexieResolve(j(a, b, e, c.chat, g.value)).then(function() {
                    return d("WAResultOrError").makeResult()
                })
            })
        })
    }

    function j(a, b, e, f, g) {
        var i, j = d("MAWDexieTable").dexieResolve();
        d("MAWXMAUtils").isXMAStoryReply((i = b.quote) == null ? void 0 : i.content.xmaMessageType) && (j = k(a, b));
        var l = {
            ack: b.ack,
            author: e,
            externalId: b.externalId,
            mediaId: b.mediaId,
            messageDeleteForMeTs: d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + h),
            msgContent: (i = d("MAWDbMsg").getMsgContent(b)) == null ? void 0 : i.content,
            msgId: b.msgId,
            quote: b.quote,
            reportingMeta: b.reportingMeta,
            serverTs: c("justknobx")._("1753") ? void 0 : b.serverTs,
            threadJid: f,
            ts: b.ts,
            type: d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME,
            xmaMessageType: b.xmaMessageType
        };
        i = d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").deleteDbMsg(a, b.rowId), j]).then(function() {
            d("MAWIndexedDb").afterTransaction({
                tag: "DeleteMessages",
                value: d("MAWBridgeTypesCreators").createBridgeDeleteMessages(b.threadJid, [b])
            });
            c("gkx")("23914") && c("justknobx")._("1071") && d("EBUploadMessages").sendDeleteEchoMessage(b, g.jid);
            if (d("MAWDbMsg").isMediaMsg(b)) {
                var e = b.mediaId,
                    f = b.plaintextHash;
                e != null && (f != null ? d("MAWIndexedDb").afterTransaction({
                    tag: "MediaExpired",
                    value: {
                        mediaId: e,
                        msgId: b.msgId,
                        plaintextHash: f,
                        threadJid: b.threadJid
                    }
                }) : d("MAWIndexedDb").afterTransaction({
                    tag: "MediaExpired",
                    value: {
                        mediaId: e,
                        msgId: b.msgId,
                        threadJid: b.threadJid
                    }
                }))
            }
            return d("MAWThreadSnippetBuildTxns").refreshThreadSnippet(a, g)
        });
        return d("MAWDexieTable").dexieAll([i, a.unrenderedMessages.add(l), d("MAWDbReactionsTxns").deleteReactionsByUniqueMsgIdentifiers(a, [{
            author: e,
            chatJid: b.threadJid,
            externalId: b.externalId
        }]), d("MAWUpdateQuotedMsgTxns").disassociateQuotedMsg(a, b.threadJid, b.externalId, b.author, d("MAWMsgType").MSG_TYPE.REVOKED)]).then(function() {
            return d("MAWDbMsgTxns").maybeUpdateThreadMsgsForDeleteForMe(a, g.jid, b.msgId, b.sortOrderMs).then(function() {
                d("MAWDeleteForMeMsgContentCleaner").addNewDeleteForMeMsgContentCleanerTimestamp(l.messageDeleteForMeTs);
                return d("WAResultOrError").makeResult()
            })
        })
    }

    function k(a, b) {
        return d("MAWDbXMATxns").maybeGetXMAFromAssociatedMsgId(a, b.msgId).then(function(b) {
            return d("MAWDbMsgTxns").maybeGetMsg(a, b == null ? void 0 : b.msgId).then(function(b) {
                if (b != null) return d("MAWDbMsgTxns").deleteDbMsg(a, b.rowId)
            })
        })
    }
    g.REVOKE_CONTENT_EXPIRATION_IN_SEC = h;
    g.handleDeleteForMe = a;
    g.deleteXMAStoryReplyMsg = k
}), 98);
__d("MAWBuildIncomingMsgs", ["MAWAckLevel", "MAWDbMsg", "MAWMsgType", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 6 * d("WATimeUtils").HOUR_SECONDS;

    function a(a, b) {
        var c = a.author;
        a = a.externalId;
        return {
            ack: d("MAWAckLevel").ACK.received,
            altIndex: void 0,
            author: c,
            externalId: a,
            serverTs: b,
            ts: b,
            type: d("MAWMsgType").MSG_TYPE.CIPHERTEXT
        }
    }

    function b(a, b) {
        var c = a.author;
        a = a.externalId;
        return {
            ack: d("MAWAckLevel").ACK.failed,
            altIndex: void 0,
            author: c,
            externalId: a,
            serverTs: b,
            ts: b,
            type: d("MAWMsgType").MSG_TYPE.UNAVAILABLE
        }
    }

    function c(a, b) {
        var c;
        return {
            ack: a.ack,
            author: a.author,
            externalId: a.externalId,
            messageDeleteForMeTs: d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + h),
            msgContent: (c = d("MAWDbMsg").getMsgContent(a)) == null ? void 0 : c.content,
            threadJid: b.jid,
            ts: a.ts,
            type: d("MAWMsgType").MSG_TYPE.DELETE_FOR_ME
        }
    }

    function e(a, b, c) {
        return {
            ack: a.ack,
            altIndex: void 0,
            author: a.author,
            externalId: c.externalId,
            msgContent: d("MAWDbMsg").getMsgContent(a),
            originalTs: a.ts,
            revokedExternalId: c.revokedExternalId,
            threadJid: b.jid,
            ts: c.ts,
            type: d("MAWMsgType").MSG_TYPE.REVOKED,
            unsendMsgContentDeleteTs: d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + h)
        }
    }
    g.REVOKE_CONTENT_EXPIRATION_IN_SEC = h;
    g.buildUnstoredCiphertextMsg = a;
    g.buildUnstoredUnavailableMsg = b;
    g.buildUnstoredDeleteForMeMsg = c;
    g.buildUnstoredRevokedMsg = e
}), 98);
__d("MAWDbEditMsgHistoryTxns", ["MAWAckLevel", "MAWDbEditMsgHistory", "MAWDexieTable", "MAWIndexedDb", "MAWVault", "WALogger", "WATagsLogger", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[getEditHistoryMsgByEditedProtocolMsgId] Suspected multiple instances of same message!"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[getEditHistoryMsgByEditedProtocolMsgId] Can't have ", " messages with the same editExternalId!"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No msgId found mapped with externalId: Edit messages with the externalId do not have associated Msg in the IDB."]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["\n          'No edit history found for the messages despite there being an editCount greater than 0"]);
        k = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        var c = [];
        if (b.length === 0) return d("MAWDexieTable").dexieResolve(c);
        b = b.filter(function(a) {
            return a.editCount != null && a.editCount > 0
        });
        var e = b.map(function(a) {
            return [a.externalId, a.threadJid]
        });
        if (e.length === 0) return d("MAWDexieTable").dexieResolve([]);
        var f = b.reduce(function(a, b) {
            b.msgId != null && a.set(b.externalId, b.msgId);
            return a
        }, new Map());
        return l(a, e).then(function(a) {
            if (a.length === 0) {
                d("WATagsLogger").TAGS(["MAWLoadMsgsTxns"]).ERROR(k());
                return []
            }
            for (var b = 0; b < a.length; b++) {
                var e = a[b],
                    g = f.get(e.originalMsgExternalId);
                g != null ? c.push(babelHelpers["extends"]({}, e, {
                    editMsgHistoryId: d("MAWDbEditMsgHistory").convertToEditMsgHistoryId64(e.editMsgHistoryId),
                    originalMsgId: g
                })) : d("WATagsLogger").TAGS(["MAWLoadMsgsTxns"]).ERROR(j())
            }
            d("MAWIndexedDb").afterTransaction({
                tag: "EditMsgHistoryAdded",
                value: c
            });
            return c
        })
    }

    function l(a, b) {
        return a.editMsgHistory.where(["originalMsgExternalId", "threadJid"]).anyOf(b).toArray()
    }

    function b(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve() : a.editMsgHistory.get({
            editMsgHistoryId: b
        })
    }

    function e(a, b, c) {
        return a.editMsgHistory.where("originalMsgExternalId").equals(c).filter(function(a) {
            return a.editExternalId === b.externalId && a.author === b.author && a.threadJid === b.chat
        }).toArray().then(function(a) {
            if (a.length > 1) {
                var b = a.map(function(a) {
                    return "" + a.editTs.toString()
                });
                b = new Set(b).size === 1;
                !b ? d("WALogger").ERROR(i(), a.length) : d("WALogger").ERROR(h())
            }
            return a[0]
        })
    }

    function f(a, b) {
        return b == null ? d("MAWDexieTable").dexieResolve([]) : a.editMsgHistory.where("originalMsgExternalId").equals(b.externalId).filter(function(a) {
            return a.author === b.author && a.threadJid === b.chat
        }).toArray().then(function(a) {
            var b = [];
            a.forEach(function(a) {
                if (a == null) return;
                b.push(a)
            });
            return b
        })
    }

    function m(a, b) {
        return a.editMsgHistory.bulkGet(b)
    }

    function n(a, b, c) {
        var e = b.map(function(a, b) {
            return babelHelpers["extends"]({}, a, {
                editMsgHistoryId: d("MAWDbEditMsgHistory").convertToEditMsgHistoryId64(c[b])
            })
        });
        return a.messages.where("externalId").anyOf(e.map(function(a) {
            return a.originalMsgExternalId
        })).toArray().then(function(a) {
            var b = new Map();
            a.forEach(function(a) {
                a != null && b.set(a.externalId, a)
            });
            return e.map(function(a) {
                var c = b.get(a.originalMsgExternalId);
                return c == null ? null : babelHelpers["extends"]({}, a, {
                    originalMsgId: c.msgId
                })
            }).filter(Boolean)
        }).then(function(a) {
            d("MAWIndexedDb").afterTransaction({
                tag: "EditMsgHistoryAdded",
                value: a
            });
            return c
        })
    }

    function o(a, b, c) {
        c === void 0 && (c = !0);
        return a.editMsgHistory.bulkAdd(b, {
            allKeys: !0
        }).then(function(e) {
            return c ? n(a, b, e) : d("MAWDexieTable").dexieResolve(e)
        })
    }

    function p(a, b, c, d) {
        return d.then(function(d) {
            return q(a, b, c, d)
        })
    }

    function q(a, b, c, e) {
        var f = [];
        return a.editMsgHistory.where("originalMsgExternalId").equals(b).filter(function(a) {
            return a.threadJid === e && a.author === c && (a.sendStatus == null || a.sendStatus >= d("MAWAckLevel").ACK.sent)
        }).toArray().then(function(a) {
            a.forEach(function(a) {
                f.push({
                    messageId: a.editExternalId,
                    originalMessageId: a.originalMsgExternalId,
                    text: d("MAWVault").unvault(a.msgContent.content),
                    timestamp: a.editTs
                })
            });
            return f
        })
    }

    function r(a, b, d, e) {
        return a.editMsgHistory.where("originalMsgExternalId").equals(b).filter(function(a) {
            return a.threadJid === e && a.author === d
        })["delete"]().then(c("emptyFunction"))
    }
    var s = function(a, b) {
        return a.editMsgHistory.where(["originalMsgExternalId", "threadJid"]).anyOf(b)["delete"]().then(function() {
            return d("MAWDexieTable").dexieResolve(b.length)
        })
    };

    function t(a, b, c) {
        return a.editMsgHistory.put(babelHelpers["extends"]({}, b, {
            msgContent: c.msgContent
        })).then(function(b) {
            return a.editMsgHistory.get({
                editMsgHistoryId: b
            })
        })
    }
    g.loadEditMsgHistory = a;
    g.getEditHistoryByOriginalMsgExternalIdAndThreadJid = l;
    g.maybeGetEditMsgHistoryFromEditMsgHistoryId = b;
    g.getEditHistoryMsgByEditedProtocolMsgId = e;
    g.maybeGetEditMsgHistoryFromProtocolMsgId = f;
    g.bulkGetEditMsgHistorys = m;
    g.bulkAddEditMsgHistory = o;
    g.getEditHistoryAsEchoWithJidPromise = p;
    g.getEditHistoryAsEcho = q;
    g.bulkRemoveEditHistory = r;
    g.deleteExpiredEditMsgHistory = s;
    g.updateEditMsgHistoryWithNewIncomingMsg = t
}), 98);
__d("MAWDeleteThreadUtil", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = [];
        a.forEach(function(a) {
            if (a.pendingContent.type === "DeleteThread") {
                a = a.pendingContent.content.metaSyncMessageRange.lastMessageTimestamp;
                a != null && b.push(a)
            }
        });
        if (b.length === 0) return null;
        b.sort(function(a, b) {
            return b - a
        });
        a = b[0];
        return {
            lastMessageTimestamp: a
        }
    }

    function b(a, b) {
        return b != null && b.lastMessageTimestamp >= a
    }
    f.getLatestDeleteThreadInfo = a;
    f.isMsgDeletedViaDeleteThread = b
}), 66);
__d("MAWDbPendingStanzaTxns", ["MAWDbPendingStanza", "MAWDeleteThreadUtil", "MAWPendingStanzaCleaner", "WAJids", "WATimeUtils", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, c, e, f) {
        var g = d("MAWDbPendingStanza").getPendingSuffix(f);
        return a.pendingStanzas.where("externalIdWithType").equals(b + "_" + g).filter(function(a) {
            a = a.pendingContent;
            return a.type === f && a.content.author === c && a.content.threadJid === e
        }).first()
    }

    function a(a, b, c, e) {
        return h(a, b, c, e, d("MAWDbPendingStanza").PENDING_TYPE.REVOKED)
    }

    function b(a, b, c, e) {
        return h(a, b, c, e, d("MAWDbPendingStanza").PENDING_TYPE.DELETE_FOR_ME)
    }

    function e(a, b) {
        var e = b.map(function(a) {
            a = a.expirationInSeconds;
            return d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + a)
        });
        b = b.map(function(a, b) {
            var c = a.content,
                f = a.externalId;
            a = a.pendingStanzaType;
            return {
                deleteTs: e[b],
                externalIdWithType: f + "_" + d("MAWDbPendingStanza").getPendingSuffix(a),
                pendingContent: c
            }
        });
        return a.pendingStanzas.bulkAdd(b).then(function() {
            return e.forEach(d("MAWPendingStanzaCleaner").addNewPendingStanzaCleanerTimestamp)
        }).then(c("emptyFunction"))
    }

    function f(a, b, c, e, f) {
        f = d("MAWDbPendingStanza").getPendingSuffix(f);
        var g = d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + c);
        c = {
            deleteTs: g,
            externalIdWithType: e + "_" + f,
            pendingContent: b
        };
        return a.pendingStanzas.add(c).then(function() {
            d("MAWPendingStanzaCleaner").addNewPendingStanzaCleanerTimestamp(g)
        })
    }

    function i(a, b) {
        var c = d("MAWDbPendingStanza").getPendingSuffix(d("MAWDbPendingStanza").PENDING_TYPE.DELETE_THREAD);
        return a.pendingStanzas.where("externalIdWithType").equals(b + "_" + c).toArray().then(function(a) {
            return d("MAWDeleteThreadUtil").getLatestDeleteThreadInfo(a)
        })
    }

    function j(a) {
        return a.pendingStanzas.toArray()
    }

    function k(a, b) {
        b = b.map(function(a) {
            return a.rowId
        });
        return a.pendingStanzas.bulkDelete(b)
    }

    function l(a) {
        var b;
        return (a == null ? void 0 : (b = a.pendingContent) == null ? void 0 : b.type) === d("MAWDbPendingStanza").PENDING_TYPE.REVOKED ? a == null ? void 0 : (b = a.pendingContent) == null ? void 0 : b.content : null
    }

    function m(a, b) {
        var c = d("MAWDbPendingStanza").getPendingSuffix(d("MAWDbPendingStanza").PENDING_TYPE.DELETE_THREAD);
        b = b.map(function(a) {
            return a + "_" + c
        });
        return a.pendingStanzas.where("externalIdWithType").anyOf(b).toArray().then(function(a) {
            a = a.reduce(function(a, b) {
                var c = a.get(b.externalIdWithType);
                c == null ? a.set(b.externalIdWithType, [b]) : c.push(b);
                return a
            }, new Map());
            var b = new Map();
            a.forEach(function(a, c) {
                c = d("WAJids").unsafeCoerceToChatJid(c.split("_")[0]);
                a = d("MAWDeleteThreadUtil").getLatestDeleteThreadInfo(a);
                a != null && b.set(c, a)
            });
            return b
        })
    }
    g.maybeGetPendingStanzaByExternalId = h;
    g.maybeGetPendingRevokedStanza = a;
    g.maybeGetPendingDeletedStanza = b;
    g.bulkPutPendingStanzas = e;
    g.putPendingStanza = f;
    g.maybeGetDeleteThreadFromPendingStanza = i;
    g.getAllPendingStanzas = j;
    g.deletePendingStanzas = k;
    g.getRevokedContent = l;
    g.bulkGetDeleteThreadPendingStanzas = m
}), 98);
__d("MAWBridgeMsgCountdown", ["MAWDbMsg", "MAWLoggerUtils", "WATagsLogger", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["createBridgeMsgsStartCountdown: msg ", ", expiration ", ", ms until countdown ", ", duration ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Calling the messages starting countdown bridge event with remaning time less or equal to 0 (expired message)"]);
        i = function() {
            return a
        };
        return a
    }
    var j = d("WATagsLogger").TAGS([d("MAWLoggerUtils").Tag.Ephemeral, d("MAWLoggerUtils").Tag.Countdown]);

    function a(a) {
        return {
            msgs: a.map(function(a) {
                var b, c = a.messageExpirationTs;
                b = (b = a.ephemeralSetting) == null ? void 0 : b.ephemeralExpirationInSec;
                if (c == null || b == null) return;
                var e = d("WATimeUtils").cappedMillisecondsUntil(c);
                if (e <= 0) {
                    j.LOG(i());
                    return
                }
                var f = b * 1e3;
                e > f && (e = f);
                j.LOG(h(), a.msgId, c, e, b);
                return {
                    countdownTs: c,
                    millisecondsUntilCountdownTs: e,
                    msgId: a.msgId,
                    threadJid: a.threadJid,
                    ts: d("MAWDbMsg").getCanonicalTsFromMsg(a)
                }
            }).filter(Boolean)
        }
    }

    function b(a, b) {
        return {
            countdownTs: b,
            msgId: a
        }
    }
    g.createBridgeMsgsStartCountdown = a;
    g.createBridgeMsgClearCountdown = b
}), 98);
__d("MAWEphemeralCleaner", ["MAWLoggerUtils", "MAWMsgCleaner", "WATagsLogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["EphemeralCleaner: Adding timestamps for UI(", ") and backend(", ")"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["startEphemeralCleaner invoked"]);
        j = function() {
            return a
        };
        return a
    }
    var k = null;

    function a(a) {
        var b = a.backendFns;
        a = a.uiFns;
        d("WATagsLogger").TAGS([d("MAWLoggerUtils").Tag.Ephemeral, d("MAWLoggerUtils").Tag.MsgCleaner, d("MAWLoggerUtils").Tag.CleanerStart]).LOG(j());
        if (k == null) {
            var c;
            k = {
                backend: new((c = d("MAWMsgCleaner")).MsgCleaner)(b, c.CLEANER_TYPE.EPHEMERAL),
                ui: new c.MsgCleaner(a, c.CLEANER_TYPE.EPHEMERAL)
            }
        }
    }

    function b(a, b) {
        if (k == null) {
            var e = "Trying to add new ephemeral timestamp before the cleaner is initialized!";
            d("WATagsLogger").TAGS([d("MAWLoggerUtils").Tag.Ephemeral, d("MAWLoggerUtils").Tag.MsgCleaner, d("MAWLoggerUtils").Tag.CleanerTimestamp]).ERROR(i(), e);
            throw c("err")(e)
        } else {
            e = k;
            var f = e.backend;
            e = e.ui;
            d("WATagsLogger").TAGS([d("MAWLoggerUtils").Tag.Ephemeral, d("MAWLoggerUtils").Tag.MsgCleaner, d("MAWLoggerUtils").Tag.CleanerTimestamp]).DEV(h(), a, b);
            e.update(a);
            f.update(b)
        }
    }

    function e() {
        return k
    }

    function f() {
        k = null
    }
    g.startEphemeralCleaner = a;
    g.addNewEphemeralTimestamp = b;
    g.getEphemeralCleaner_FOR_TESTING_ONLY = e;
    g.resetEphemeralCleaner_FOR_TESTING_ONLY = f
}), 98);
__d("MAWEphemeralSettingsCache", ["MAWBridge", "WATimeUtils", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map();

    function i(a, b) {
        h.set(a, b)
    }

    function a(a) {
        var b = {
            ephemeralExpirationInSec: 0,
            ephemeralLastUpdatedOrSetTimestamp: d("WATimeUtils").castToUnixTime(0)
        };
        return (a = h.get(a)) != null ? a : b
    }

    function c(a) {
        return j.apply(this, arguments)
    }

    function j() {
        j = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = {
                ephemeralExpirationInSec: 0,
                ephemeralLastUpdatedOrSetTimestamp: d("WATimeUtils").castToUnixTime(0)
            };
            if (!h.has(a)) {
                var c = (yield d("MAWBridge").getBridge().sendAndReceive("event", "getLSDBEphemeralSetting", {
                    chatJid: a
                }));
                i(a, (a = c) != null ? a : b)
            }
        });
        return j.apply(this, arguments)
    }
    g.setEphemeralSettingCache = i;
    g.getEphemeralSettingCache = a;
    g.requestLSDBCacheForJid = c
}), 98);
__d("MAWEphemeralUtil", ["MAWAckLevel", "MAWBridgeMsgCountdown", "MAWExternalId", "MAWIndexedDb", "MAWLocalizationType", "MAWMsgType", "WAArmadilloApplication.pb", "WAGlobals", "WAJids", "WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["The new ephemeral setting timestamp should be greater than the existing timestamp"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["New ephemeral duration should be different from the existing duration"]);
        i = function() {
            return a
        };
        return a
    }

    function a(a, b, c) {
        var e = d("WAGlobals").getMyDeviceJid();
        e = b.ephemeralExpirationInSec !== a.ephemeralExpirationInSec && b.ephemeralLastUpdatedOrSetTimestamp === a.ephemeralLastUpdatedOrSetTimestamp && e <= c;
        return e || a.ephemeralLastUpdatedOrSetTimestamp > b.ephemeralLastUpdatedOrSetTimestamp
    }

    function b(a, b, c) {
        if (a == null) return !0;
        a = a.ephemeralSetting;
        if (a != null && a.ephemeralExpirationInSec === b) {
            d("WALogger").DEV(i());
            return !1
        }
        if (a != null && a.ephemeralLastUpdatedOrSetTimestamp > c) {
            d("WALogger").DEV(h());
            return !1
        }
        return !0
    }

    function e(a) {
        a = {
            ack: d("MAWAckLevel").ACK.sent,
            altIndex: void 0,
            author: d("WAJids").AUTHOR_SYSTEM,
            externalId: d("MAWExternalId").generateExternalId(),
            msgContent: {
                adminMsgContent: [],
                adminType: d("MAWLocalizationType").LOCALIZATION_TYPE.YOU_EPHEMERAL_SETTING_CHANGE_MINUTES
            },
            ts: a,
            type: d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN
        };
        return {
            unstoredDbMedia: null,
            unstoredDbMsg: a,
            unstoredDbReaction: null
        }
    }

    function f(a, b) {
        var e;
        switch (b) {
            case d("WAArmadilloApplication.pb").ARMADILLO_CONTENT_SCREENSHOT_ACTION_SCREENSHOT_TYPE.SCREENSHOT_IMAGE:
                e = d("WAArmadilloApplication.pb").ARMADILLO_CONTENT_SCREENSHOT_ACTION_SCREENSHOT_TYPE.SCREENSHOT_IMAGE;
                break;
            case d("WAArmadilloApplication.pb").ARMADILLO_CONTENT_SCREENSHOT_ACTION_SCREENSHOT_TYPE.SCREEN_RECORDING:
                e = d("WAArmadilloApplication.pb").ARMADILLO_CONTENT_SCREENSHOT_ACTION_SCREENSHOT_TYPE.SCREEN_RECORDING;
                break;
            default:
                throw c("err")("Received unexpected screenshot action type")
        }
        b = {
            ack: d("MAWAckLevel").ACK.sent,
            altIndex: void 0,
            author: d("WAJids").AUTHOR_SYSTEM,
            externalId: d("MAWExternalId").generateExternalId(),
            msgContent: {
                adminMsgContent: [],
                adminType: d("MAWLocalizationType").LOCALIZATION_TYPE.YOU_EPHEMERAL_TAKE_SCREENSHOT,
                screenshotActionType: e
            },
            ts: a,
            type: d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION
        };
        return {
            unstoredDbMedia: null,
            unstoredDbMsg: b,
            unstoredDbReaction: void 0
        }
    }

    function j(a) {
        return d("WAJids").switchOnMsgrChatJidType(a, {
            group: function(a) {
                throw c("err")("Received invalid chatJid. We only support ephemeral messaging in 1:1 threads.")
            },
            user: function(a) {
                return a
            }
        })
    }

    function k(a) {
        a != null && a.messageExpirationTs != null && a.ephemeralCounterStarted === !0 && d("MAWIndexedDb").afterTransaction({
            tag: "MsgClearCountdown",
            value: d("MAWBridgeMsgCountdown").createBridgeMsgClearCountdown(a.msgId, a.messageExpirationTs)
        })
    }
    g.isLocalSettingOutdated = a;
    g.shouldUpdateForOutgoingUserEphemeralSettingChange = b;
    g.buildUnstoredDbEphemeralSettingMsgWithoutContentPlaceholder = e;
    g.buildUnstoredDbEphemeralScreenshotActionMsgWithoutContentPlaceholder = f;
    g.getUserJidForEphemeralSetting = j;
    g.maybeClearEphemeralMsgCountdown = k
}), 98);
__d("MAWEphemeralSettingsTxns", ["DateConsts", "MAWDbThreadTxns", "MAWDexieTable", "MAWEphemeralSettingsCache", "MAWEphemeralUtil", "MAWIndexedDb", "MAWLoggerUtils", "MAWUserJidWrapper", "WAJids", "WALogger", "WAResultOrError", "WATagsLogger", "WATimeUtils", "emptyFunction", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["maybeResetEphemeralSyncResponseBackoffInfo reset for ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["maybeResetEphemeralSyncResponseBackoffInfo no op for ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Contact ", " ", " and ephemeral setting ", " should not be null when receiving the server ack for outgoing ephemeral setting change"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["handleAndWriteIncomingEphemeralSetting - ephemeral setting in sync"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["handleAndWriteIncomingEphemeralSetting - Sending Sync Response with duration ", ", timestamp ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Received invalid chat jid for incoming ephemeral settings"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["handleAndWriteIncomingEphemeralSetting - Handle Incoming Ephemeral Setting duration: ", ", lastUpdated: ", ""]);
        o = function() {
            return a
        };
        return a
    }
    var p = d("WATagsLogger").TAGS([(h = d("MAWLoggerUtils")).Tag.Ephemeral, h.Tag.SettingChange, h.Tag.Incoming]),
        q = d("WATagsLogger").TAGS([h.Tag.Ephemeral, h.Tag.SettingChange, h.Tag.Outgoing]),
        r = null,
        s = 90 * d("DateConsts").SEC_PER_DAY;

    function a(a, b, e, f, g, h, i, j, k, q) {
        if (f < 0 || f > s) {
            j = d("WAJids").interpretAndValidateJid(i.jid).toString();
            throw c("err")("EphemeralSetting duration is invalid " + f + ", jidType: " + j)
        }
        k = {
            ephemeralExpirationInSec: f,
            ephemeralLastUpdatedOrSetTimestamp: g
        };
        d("WALogger").LOG(o(), f, g);
        j = d("WAJids").interpretAsUserJid(i.jid);
        if (j == null) {
            p.ERROR(n());
            return d("MAWDexieTable").dexieResolve(r)
        }
        f = d("WAJids").isAuthorMe(b) ? d("MAWUserJidWrapper").getMyUserJid() : b;
        b = e != null ? d("WAJids").toDeviceJid(f, e.id) : null;
        e = d("MAWEphemeralSettingsCache").getEphemeralSettingCache(i.jid);
        var t = e == null ? void 0 : e.ephemeralExpirationInSec,
            u = e == null ? void 0 : e.ephemeralLastUpdatedOrSetTimestamp;
        if (q) {
            if (e != null && b != null && !d("MAWEphemeralUtil").isLocalSettingOutdated(k, e, b))
                if (g !== u) {
                    d("WALogger").LOG(m(), t, u);
                    return d("MAWDexieTable").dexieResolve({
                        dbMsg: null,
                        outOfSyncEphemeralSetting: {
                            chatJid: i.jid,
                            correctEphemeralExpirationInSec: e.ephemeralExpirationInSec,
                            correctEphemeralLastUpdatedOrSetTimestamp: e.ephemeralLastUpdatedOrSetTimestamp
                        }
                    })
                } else {
                    d("WALogger").WARN(l());
                    return d("MAWDexieTable").dexieResolve(r)
                }
            d("MAWIndexedDb").afterTransaction({
                tag: "EphemeralSettingsUpdatedForUI",
                value: {
                    author: d("WAJids").userIdFromJid(f),
                    chatJid: i.jid,
                    ephemeralSettingArgs: k,
                    isEphemeralSettingReset: h
                }
            });
            return d("MAWDexieTable").dexieResolve(r)
        }
        q = {
            ephemeralSetting: k,
            ephemeralSyncResponseBackoffInfo: void 0,
            userJid: j
        };
        return a.ephemeralSettings.put(q).then(function() {
            return r
        })
    }

    function b(a, b, e, f, g) {
        var h = e;
        if (h < 0) throw c("err")("Ephemeral duration should be 0 or more");
        var i = d("MAWEphemeralUtil").getUserJidForEphemeralSetting(b);
        return d("MAWDbThreadTxns").getThread(a, b).then(function(b) {
            return !b.success ? d("WAResultOrError").makeResult({
                shouldUpdateSetting: !1
            }) : a.ephemeralSettings.get({
                userJid: i
            }).then(function(b) {
                if (!d("MAWEphemeralUtil").shouldUpdateForOutgoingUserEphemeralSettingChange(b, h, f)) return d("WAResultOrError").makeResult({
                    shouldUpdateSetting: !1
                });
                b = b == null ? {
                    ephemeralSetting: {
                        ephemeralExpirationInSec: h,
                        ephemeralLastUpdatedOrSetTimestamp: f
                    },
                    userJid: i
                } : babelHelpers["extends"]({}, b, {
                    ephemeralSetting: {
                        ephemeralExpirationInSec: h,
                        ephemeralLastUpdatedOrSetTimestamp: f
                    }
                });
                return a.ephemeralSettings.put(b).then(function() {
                    return d("WAResultOrError").makeResult({
                        shouldUpdateSetting: !0
                    })
                })
            })
        })
    }

    function e(a, b, e) {
        var f = d("MAWEphemeralUtil").getUserJidForEphemeralSetting(b);
        return a.ephemeralSettings.get({
            userJid: f
        }).then(function(b) {
            if (b == null || b.ephemeralSetting == null) {
                q.ERROR(k(), f, b, b == null ? void 0 : b.ephemeralSetting);
                throw c("err")("Contact and ephemeral setting should not be null when receiving the server ack for outgoing ephemeral setting change")
            }
            b = babelHelpers["extends"]({}, b, {
                ephemeralSetting: {
                    ephemeralExpirationInSec: b.ephemeralSetting.ephemeralExpirationInSec,
                    ephemeralLastUpdatedOrSetTimestamp: e
                }
            });
            return a.ephemeralSettings.put(b).then(c("emptyFunction"))
        })
    }

    function f(a, b) {
        a = d("WAJids").interpretAsUserJid(b);
        if (a == null) throw c("err")("Unexpected chatJid input to isEphemeralMessagesEnabledForContact");
        a = d("MAWEphemeralSettingsCache").getEphemeralSettingCache(b);
        if (a.ephemeralLastUpdatedOrSetTimestamp === d("WATimeUtils").castToUnixTime(0)) return d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeError("no_ephemeral_setting"));
        return a != null && a.ephemeralExpirationInSec > 0 ? d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeResult({
            outOfSyncEphemeralSetting: {
                chatJid: b,
                correctEphemeralExpirationInSec: a.ephemeralExpirationInSec,
                correctEphemeralLastUpdatedOrSetTimestamp: a.ephemeralLastUpdatedOrSetTimestamp
            }
        })) : d("MAWDexieTable").dexieResolve(d("WAResultOrError").makeError("no_ephemeral_setting"))
    }

    function t(a, b) {
        return a.ephemeralSettings.get({
            userJid: b
        }).then(function(c) {
            if ((c == null ? void 0 : c.ephemeralSyncResponseBackoffInfo) == null) {
                p.LOG(j(), b);
                return d("WAResultOrError").makeResult()
            }
            c.ephemeralSyncResponseBackoffInfo = void 0;
            p.LOG(i(), b);
            return a.ephemeralSettings.put(c).then(function() {
                return d("WAResultOrError").makeResult()
            })
        })
    }
    g.handleAndWriteIncomingEphemeralSetting = a;
    g.handleAndWriteOutgoingUserEphemeralSettingChange = b;
    g.updateContactWhenEphemeralSettingChangeMarkedSent = e;
    g.getOutOfSyncEphemeralSettingForIncomingNonEphemeralMsg = f;
    g.maybeResetEphemeralSyncResponseBackoffInfo = t
}), 98);
__d("MAWEphemeralMsgTxns", ["FBLogger", "MAWBridgeMsgCountdown", "MAWBridgeTypesCreators", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbThreadTxns", "MAWDbXMATxns", "MAWDexieTable", "MAWEphemeralCleaner", "MAWEphemeralConsts", "MAWEphemeralMsgUtils", "MAWEphemeralSettingsTxns", "MAWIndexedDb", "MAWLocalizationType", "MAWLoggerUtils", "MAWMsgType", "MAWThreadSnippetBuildTxns", "MAWThreadSnippetUtils", "MAWThreadUpdateMiddlewareGKUtil", "WAJids", "WATagsLogger", "WATimeUtils", "emptyFunction", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["incoming msg is out of sync: correct duration ", ", correct timestamp ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["incoming msg is ephemeral: duration ", ", timestamp ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["maybeUpdateEphemeralSettingOrCheckOutOfSyncAfterWritingIncomingMsg: Message from ", ", chat ", ", type ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updating ephemeral timestamp msg ", ", existing expiration ", ", existing deletion ", ", updated expiration ", ", updated deletion ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["markEphemeralMessageAsSent EphemeralCounter: Showing UI counter for ", ""]);
        l = function() {
            return a
        };
        return a
    }
    var m = d("WATagsLogger").TAGS([(f = d("MAWLoggerUtils")).Tag.Ephemeral, f.Tag.SettingSync, f.Tag.Incoming]),
        n = d("WATagsLogger").TAGS([f.Tag.Ephemeral, f.Tag.OnRead, f.Tag.Countdown]);

    function o(a, b, c) {
        c === void 0 && (c = function() {
            return !0
        });
        return d("MAWDbMsgTxns").getThreadMessagesBySortOrder(a, b, !1, !0).filter(c).limit(1).toArray().then(function(a) {
            return {
                needsUpdate: !0,
                value: (a = a[0]) != null ? a : null
            }
        })
    }

    function p(a, b, e) {
        return e.size === 0 ? d("MAWDexieTable").dexieResolve() : d("MAWDbThreadTxns").getThread(a, b).then(function(b) {
            if (!b.success) return;
            var f = b.value;
            return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").getThreadOldestMessageId(a, f.jid), d("MAWDbMsgTxns").getThreadNewestMessageId(a, f.jid)]).then(function(b) {
                var g = b[0],
                    h = b[1];
                if (g == null || h == null) return;
                b = d("MAWEphemeralMsgUtils").filterNonExpiredMsg(e);
                var i = e.has(g) ? o(a, f.jid, b) : d("MAWDexieTable").dexieResolve({
                    needsUpdate: !1
                });
                b = e.has(h) ? d("MAWDbMsgTxns").getThreadMessagesBySortOrder(a, f.jid, !0, !1).filter(b).reverse().limit(1).toArray().then(function(b) {
                    b = b[0];
                    return b != null && d("MAWThreadSnippetUtils").isDbMsgDisabledForThreadSnippet(b) ? d("MAWThreadSnippetUtils").recalculateSnippetFromScratch_EXPENSIVE(a, f, e).then(function(a) {
                        return {
                            needsUpdate: !0,
                            value: (a = a) != null ? a : null
                        }
                    }) : {
                        needsUpdate: !0,
                        value: (b = b) != null ? b : null
                    }
                }) : d("MAWDexieTable").dexieResolve({
                    needsUpdate: !1
                });
                return d("MAWDexieTable").dexieAll([i, b]).then(function(b) {
                    var e = b[0],
                        i = b[1];
                    if (!e.needsUpdate && !i.needsUpdate) return;
                    b = i.needsUpdate ? (b = (b = i.value) == null ? void 0 : b.msgId) != null ? b : void 0 : h;
                    var j = i.needsUpdate ? i.value != null ? d("WATimeUtils").castUnixTimeToMillisTime(d("MAWDbMsg").getCanonicalTsFromMsg(i.value)) : void 0 : f.snippetMsgTs,
                        k = babelHelpers["extends"]({}, f, {
                            newestMsg: b,
                            oldestMsg: e.needsUpdate ? (e = (e = e.value) == null ? void 0 : e.msgId) != null ? e : null : g,
                            snippetMsg: b,
                            snippetMsgTs: j
                        });
                    return a.threads.put(k).then(function() {
                        if (i.needsUpdate) {
                            var b = i.value;
                            if (b == null) d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(d("MAWMsgType").MSG_TYPE.TEXT) ? c("FBLogger")("MAWEphemeralMsgTxns").mustfix("[Occamadillo] ThreadUpdated handler called for clear snippet when centralized thread bump is enabled") : d("MAWIndexedDb").afterTransaction({
                                tag: "ThreadUpdated",
                                value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                                    snippetParams: {
                                        contactIDs: [],
                                        strings: []
                                    },
                                    snippetSenderContactId: "0",
                                    snippetType: d("MAWLocalizationType").LOCALIZATION_TYPE.EMPTY_SNIPPET,
                                    threadJid: k.jid
                                })
                            });
                            else if (!d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(b.type)) return d("MAWThreadSnippetBuildTxns").buildThreadSnippet(a, b).then(function(a) {
                                var b = a.snippetParams,
                                    c = a.snippetSenderContactId;
                                a = a.snippetType;
                                d("MAWIndexedDb").afterTransaction({
                                    tag: "ThreadUpdated",
                                    value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                                        snippetParams: b,
                                        snippetSenderContactId: c,
                                        snippetType: a,
                                        threadJid: k.jid
                                    })
                                })
                            })
                        }
                    })
                })
            })
        })
    }

    function a(a, b, e) {
        if (b == null || b.ephemeralSetting == null || b.ephemeralSetting.ephemeralExpirationInSec === 0) return d("MAWDexieTable").dexieResolve(b);
        var f = d("WATimeUtils").castToUnixTime(b.ts + b.ephemeralSetting.ephemeralExpirationInSec),
            g = d("WATimeUtils").castToUnixTime(f + d("MAWEphemeralConsts").ephemeralReportingWindowInSeconds);
        return q(a, [{
            messageDeleteTs: g,
            messageExpirationTs: f,
            msgId: b.msgId,
            readTsForLogging: b.ts
        }]).then(function(a) {
            var b = a[0],
                f = a[1];
            a = a[2];
            a.length > 0 && (n.LOG(l(), a.map(function(a) {
                return a.msgId
            })), e === !0 && c("justknobx")._("3060") || d("MAWIndexedDb").afterTransaction({
                tag: "MsgsStartCountdown",
                value: d("MAWBridgeMsgCountdown").createBridgeMsgsStartCountdown(a)
            }));
            b != null && f != null && d("MAWEphemeralCleaner").addNewEphemeralTimestamp(b, f);
            return a[0]
        })
    }

    function q(a, b) {
        var c = b.map(function(a) {
            return a.msgId
        });
        return d("MAWDbXMATxns").getXMAMsgIdsFromAssociatedMsgIds(a, c).then(function(d) {
            var e = new Map();
            b.forEach(function(a) {
                e.set(a.msgId, {
                    messageDeleteTs: a.messageDeleteTs,
                    messageExpirationTs: a.messageExpirationTs,
                    readTsForLogging: a.readTsForLogging
                });
                var b = d.get(a.msgId);
                b != null && e.set(b, {
                    messageDeleteTs: a.messageDeleteTs,
                    messageExpirationTs: a.messageExpirationTs,
                    readTsForLogging: a.readTsForLogging
                })
            });
            var f = null,
                g = null,
                h = [],
                i = Array.from(new Set(c.concat(Array.from(d.values()))));
            return a.messages.where("msgId").anyOf(i).toArray().then(function(b) {
                if (b.length === 0) return;
                b.forEach(function(a) {
                    var b = a.messageExpirationTs,
                        c = a.messageDeleteTs,
                        d = e.get(a.msgId),
                        i = d == null ? void 0 : d.messageExpirationTs;
                    d = d == null ? void 0 : d.messageDeleteTs;
                    n.LOG(k(), a.msgId, b, c, i, d);
                    if (i == null || d == null) return;
                    if (a.ephemeralCounterStarted === !0) return;
                    f == null ? f = i : i < f && (f = i);
                    g == null ? g = d : d < g && (g = d);
                    b = babelHelpers["extends"]({}, a, {
                        ephemeralCounterStarted: !0,
                        messageDeleteTs: d,
                        messageExpirationTs: i
                    });
                    h.push(b)
                });
                return a.messages.bulkPut(h)
            }).then(function() {
                return [f, g, h]
            })
        })
    }

    function b(a, b) {
        if (b.size === 0) return d("MAWDexieTable").dexieResolve();
        var e = [];
        b.forEach(function(b, c) {
            e.push(p(a, c, b))
        });
        return d("MAWDexieTable").dexieAll(e).then(c("emptyFunction"))
    }

    function e(a, b, e, f, g, k) {
        if (b == null || g == null) return d("MAWDexieTable").dexieResolve();
        m.LOG(j(), e, f.jid, b.type);
        var l = d("MAWDexieTable").dexieResolve();
        if (b.ephemeralSetting == null) d("WAJids").switchOnMsgrChatJidType(f.jid, {
            group: function() {
                return d("MAWEphemeralSettingsTxns").maybeResetEphemeralSyncResponseBackoffInfo(a, e).then(c("emptyFunction"))
            },
            user: function() {
                d("MAWDbMsg").isMsgEligibleForTriggeringEphemeralSyncResponse(b) && (l = d("MAWEphemeralSettingsTxns").getOutOfSyncEphemeralSettingForIncomingNonEphemeralMsg(a, f.jid).then(function(a) {
                    return a == null ? void 0 : (a = a.value) == null ? void 0 : a.outOfSyncEphemeralSetting
                }))
            }
        });
        else if (b.messageExpirationTs != null && b.messageDeleteTs != null) {
            var n = b.ephemeralSetting,
                o = b.messageDeleteTs,
                p = b.messageExpirationTs;
            m.LOG(i(), n.ephemeralExpirationInSec, n.ephemeralLastUpdatedOrSetTimestamp);
            d("MAWEphemeralCleaner").addNewEphemeralTimestamp(p, o);
            l = d("MAWEphemeralSettingsTxns").handleAndWriteIncomingEphemeralSetting(a, e, g, n.ephemeralExpirationInSec, n.ephemeralLastUpdatedOrSetTimestamp, !1, f, k, null, !0).then(function(a) {
                return a == null ? void 0 : a.outOfSyncEphemeralSetting
            })
        }
        return l.then(function(b) {
            if (b != null) {
                m.LOG(h(), b.correctEphemeralExpirationInSec, b.correctEphemeralLastUpdatedOrSetTimestamp);
                return b
            } else return d("MAWEphemeralSettingsTxns").maybeResetEphemeralSyncResponseBackoffInfo(a, e).then(c("emptyFunction"))
        })
    }
    g.markEphemeralMessageAsSent = a;
    g.bulkUpdateEphemeralMessageTimestamps = q;
    g.updateThreadsOnMessagesExpiredFromUi = b;
    g.syncEphemeralSettingOnIncomingMsg = e
}), 98);
__d("MAWExpiredQuoteCleaner", ["MAWMsgCleaner", "WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["ExpiredQuoteCleaner: Adding timestamps backend(", ")"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["startExpiredQuoteCleaner invoked"]);
        j = function() {
            return a
        };
        return a
    }
    var k = null;

    function a(a) {
        d("WALogger").LOG(j()), k == null && (k = new(d("MAWMsgCleaner").MsgCleaner)(a, d("MAWMsgCleaner").CLEANER_TYPE.QUOTE))
    }

    function b(a) {
        if (k == null) {
            var b = "Trying to add new addNewExpiredQuoteCleanerTimestamp before the cleaner is initialized!";
            d("WALogger").ERROR(i(), b);
            throw c("err")(b)
        } else d("WALogger").DEV(h(), a), k.update(a)
    }

    function e() {
        return k
    }

    function f() {
        k = null
    }
    g.startExpiredQuoteCleaner = a;
    g.addNewExpiredQuoteCleanerTimestamp = b;
    g.getExpiredQuoteCleaner_FOR_TESTING_ONLY = e;
    g.resetExpiredQuoteCleaner_FOR_TESTING_ONLY = f
}), 98);
__d("MAWQuotedMsgUtils", ["WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return a.content.type === "NoteReply" ? a.content.msgContent == null ? a : babelHelpers["extends"]({}, a, {
            content: babelHelpers["extends"]({}, a.content, {
                msgContent: void 0
            })
        }) : a
    }

    function a(a) {
        return a.content.expirationTs == null || a.content.expirationTs > d("WATimeUtils").unixTime() ? a : h(a)
    }
    g.dbQuotedMsgWithoutExpirableContent = h;
    g.dbQuotedMsgWithoutExpiredContent = a
}), 98);
__d("MAWGetMsgQuoteTxn", ["LSMEBTaskCreationSource", "MAWBridgeEventTransmitter", "MAWDbMsgTxns", "MAWDexieTable", "MAWIndexedDb", "MAWMsgType", "MAWQuotedMsgUtils", "MAWTransactionMode", "WAJids", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
        return a == null || a === d("WAJids").AUTHOR_SYSTEM ? null : d("WAJids").authorAsUserJid(a)
    };

    function i(a, b, e, f) {
        var g = b.quote;
        b = (g == null ? void 0 : g.content) || {};
        var i = b.author;
        b = b.externalId;
        if (i == null) return d("MAWDexieTable").dexieResolve(null);
        i = d("WAJids").isAuthorMe(i) ? d("WAJids").AUTHOR_ME : h(i);
        if (g == null || i == null || b == null) return d("MAWDexieTable").dexieResolve(null);
        var j = {
            author: i,
            chat: e,
            externalId: b
        };
        if (g.content.type === "NoteReply") return d("MAWDexieTable").dexieResolve({
            quote: d("MAWQuotedMsgUtils").dbQuotedMsgWithoutExpiredContent(g),
            quoteExternalId: g.content.externalId
        });
        var k = f != null && f === "ebrestore" ? c("LSMEBTaskCreationSource").EB_POINT_QUERY_RESTORE_PROTOBUF : c("LSMEBTaskCreationSource").EB_POINT_QUERY_IN_ACT;
        return d("MAWDbMsgTxns").maybeGetMsgByProtocolMsgId(a, j).then(function(b) {
            b == null && d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(j.externalId, d("WAJids").threadIdForChatJid(j.chat), void 0, k, j.chat);
            if (b == null || !d("MAWMsgType").isQuotedMsgType(b.type)) return {
                quote: g,
                quoteExternalId: g.content.externalId
            };
            var a = b.author,
                c = b.externalId,
                e = b.mediaId,
                f = b.msgContent,
                h = b.msgId,
                i = b.plaintextHash,
                l = b.specialTextSize,
                m = b.ts,
                n = b.type,
                o = b.xmaMessageType;
            a = {
                author: a,
                externalId: c,
                mediaId: e,
                msgContent: f,
                msgId: h,
                plaintextHash: i,
                specialTextSize: l,
                ts: m,
                type: n,
                xmaMessageType: o
            };
            b.messageExpirationTs != null && b.messageExpirationTs < d("WATimeUtils").unixTime() && (a = babelHelpers["extends"]({}, a, {
                mediaId: void 0,
                msgContent: void 0,
                type: d("MAWMsgType").MSG_TYPE.EXPIRED_EPHEMERAL
            }));
            return {
                quote: babelHelpers["extends"]({}, g, {
                    content: a
                }),
                quoteExternalId: b.externalId
            }
        })
    }

    function a(a, b, c) {
        return i(a, b, c).then(function(a) {
            return babelHelpers["extends"]({}, b, {
                quote: a == null ? void 0 : a.quote,
                quoteExpirationTs: a == null ? void 0 : a.quote.content.expirationTs,
                quoteExternalId: a == null ? void 0 : a.quoteExternalId
            })
        })
    }

    function j(a, b) {
        return a.messages.where("quoteExternalId").anyOf(b).toArray()
    }
    b = d("MAWIndexedDb").makeMsgrTransactor({
        messages: d("MAWTransactionMode").READONLY
    }, "maybeBatchGetMsgsByQuoteExternalId", function(a) {
        return function() {
            for (var b = arguments.length, c = new Array(b), d = 0; d < b; d++) c[d] = arguments[d];
            return j.apply(void 0, [a].concat(c))
        }
    });
    g.getMsgQuoteInfo = i;
    g.enhanceMsgWithQuoteInfo = a;
    g.maybeBatchGetMsgsByQuoteExternalId = j;
    g.maybeBatchGetMsgsByQuoteExternalIdWithTransaction = b
}), 98);
__d("MAWBridgeParticipants", ["WAJids", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = a.deliveredWatermarkTs,
            c = a.lastReadActionTs,
            e = a.lastReadWatermarkTs,
            f = a.threadJid,
            g = a.type;
        a = a.userJid;
        return {
            deliveredWatermarkTs: b || d("WATimeUtils").castToUnixTime(0),
            fbid: d("WAJids").extractUserId(a),
            isAdmin: g === "superadmin" || g === "admin",
            isInvited: g === "invitedParticipant",
            isSuperAdmin: g === "superadmin",
            lastReadActionTs: (b = c) != null ? b : d("WATimeUtils").castToUnixTime(0),
            readWatermarkTs: e || d("WATimeUtils").castToUnixTime(0),
            threadJid: f
        }
    }

    function a(a) {
        return {
            participants: a.map(function(a) {
                return h(a)
            })
        }
    }
    g.createBridgeParticipant = h;
    g.createBridgeParticipants = a
}), 98);
__d("MAWDbParticipantTxns", ["FBLogger", "MAWBridgeParticipants", "MAWBridgeTypesCreators", "MAWCurrentUser", "MAWDbParticipant", "MAWDexieTable", "MAWIndexedDb", "MAWODSProxy", "MAWUserJidWrapper", "WAJids", "WAOdsEnums", "WAResultOrError", "WATimeUtils", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["bulkUpdateParticipantTimestamps: participant ", ", ", " deliveredWatermarkTs: ", ", lastReadWatermarkTs: ", ", lastReadActionTs: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["bulkUpdateParticipantTimestamps: missing tsData for participant ", ", ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["bulkUpdateParticipantTimestamps: missing participants ", " vs ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function a(a, b, c, d, e) {
        d === void 0 && (d = "participant");
        return k(a, b, [{
            addressable: e,
            type: d,
            userJid: c
        }]).then(function(a) {
            return a[0]
        })
    }

    function k(a, b, c) {
        return m(a, c.map(function(a) {
            return babelHelpers["extends"]({}, a, {
                threadJid: b
            })
        }))
    }

    function l(a, b) {
        d("WAJids").switchOnMsgrChatJidType(a.threadJid, {
            group: c("emptyFunction"),
            user: function(e) {
                a.userJid !== e && a.userJid !== d("MAWUserJidWrapper").getMyUserJid() && c("FBLogger")("messenger_e2ee_web").mustfix("Attempting to insert participant to a mismatched one-on-one thread at %s", b)
            }
        })
    }

    function m(a, b) {
        if (b.length === 0) return d("MAWDexieTable").dexieResolve([]);
        var c = [];
        b.forEach(function(a) {
            var b = a.addressable,
                e = a.threadJid,
                f = a.type;
            a = a.userJid;
            c.push({
                addressable: b,
                deliveredWatermarkTs: d("WATimeUtils").castToUnixTime(0),
                id: d("MAWDbParticipant").craftParticipantId(e, a),
                lastReadWatermarkTs: d("WATimeUtils").castToUnixTime(0),
                threadJid: e,
                type: f,
                userJid: a
            })
        });
        c.forEach(function(a) {
            return l(a, "bulkAddParticipantsInThreads")
        });
        return a.participants.bulkPut(c).then(function() {
            d("MAWIndexedDb").afterTransaction({
                tag: "ParticipantsUpdated",
                value: d("MAWBridgeParticipants").createBridgeParticipants(c)
            });
            return c
        })
    }

    function b(a, b, c) {
        return s(a, b).then(function(e) {
            var f = [],
                g = new Set(c.map(function(a) {
                    return a.userJid
                }));
            for (var h = e, i = Array.isArray(h), j = 0, h = i ? h : h[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var l;
                if (i) {
                    if (j >= h.length) break;
                    l = h[j++]
                } else {
                    j = h.next();
                    if (j.done) break;
                    l = j.value
                }
                l = l;
                var m = g.has(l.userJid);
                m || f.push([l.threadJid, l.userJid])
            }
            m = [];
            l = new Set(e.map(function(a) {
                return a.userJid
            }));
            for (j = 0; j < c.length; j++) {
                i = c[j];
                h = l.has(i.userJid);
                h || m.push(i)
            }
            f.length > 0 && d("MAWODSProxy").odsBumpEntityKey({
                amount: 1,
                entity: d("WAOdsEnums").Entity.MAW_ONE_TO_ONE_THREAD_PARTICIPANT_CLEANUP,
                key: d("MAWCurrentUser").isEmployee() ? "employee" : "public"
            });
            return d("MAWDexieTable").dexieAll([k(a, b, m), o(a, f)]).then(function(a) {
                var b = a[0];
                a[1];
                a = c.reduce(function(a, c) {
                    var d = b.find(function(a) {
                            return a.userJid === c.userJid
                        }),
                        f = e.find(function(a) {
                            return a.userJid === c.userJid
                        });
                    d != null && f == null ? a.push(d) : f != null && a.push(f);
                    return a
                }, []);
                return a
            })
        })
    }

    function e(a, b) {
        b.forEach(function(a) {
            return l(a, "bulkUpdateParticipants")
        });
        return a.participants.bulkPut(b).then(function() {
            b.length > 0 && d("MAWIndexedDb").afterTransaction({
                tag: "ParticipantsUpdated",
                value: d("MAWBridgeParticipants").createBridgeParticipants(b)
            });
            return b
        })
    }

    function f(a, b, c) {
        if (c.length === 0) return d("MAWDexieTable").dexieResolve();
        c = c.map(function(a) {
            return [b, a]
        });
        return o(a, c)
    }

    function n(a, b, c) {
        if (b.length === 0) return d("MAWDexieTable").dexieResolve();
        b = b.map(function(a) {
            return [a, c]
        });
        return o(a, b)
    }

    function o(a, b) {
        return a.participants.where(["threadJid", "userJid"]).anyOf(b).toArray().then(function(b) {
            return a.participants.bulkDelete(b.map(function(a) {
                return a.id
            })).then(function() {
                return a.threads.where("jid").anyOf(Array.from(new Set(b.map(function(a) {
                    return a.threadJid
                })))).toArray()
            }).then(function(a) {
                var c = new Map(a.map(function(a) {
                    return [a.jid, a.chatId]
                }));
                b.forEach(function(a) {
                    var b = c.get(a.threadJid);
                    b != null && d("MAWIndexedDb").afterTransaction({
                        tag: "ParticipantRemoved",
                        value: {
                            threadJid: a.threadJid,
                            userId: d("WAJids").extractUserId(a.userJid)
                        }
                    })
                })
            })
        })
    }

    function p(a, b) {
        return a.participants.where("threadJid").equals(b)["delete"]()
    }

    function q(a, b, c, d, e) {
        return r(a, [{
            deliveredWatermarkTs: c,
            lastReadActionTs: e,
            lastReadWatermarkTs: d,
            participantKey: b
        }]).then(function(a) {
            return a[0]
        })
    }

    function r(a, b, c) {
        if (b.length === 0) return d("MAWDexieTable").dexieResolve([]);
        var e = new Map(),
            f = [];
        b.forEach(function(a) {
            f.push(a.participantKey), e.set(JSON.stringify(a.participantKey), a)
        });
        return a.participants.where(["threadJid", "userJid"]).anyOf(f).toArray().then(function(b) {
            b.length !== f.length && (c != null && c.LOG(j(), b.length, f.length));
            var g = [],
                k = [];
            b.forEach(function(a) {
                var b = e.get(JSON.stringify([a.threadJid, a.userJid]));
                if (b == null) {
                    c != null && c.LOG(i(), a.threadJid, a.userJid);
                    return
                }
                var d = b.deliveredWatermarkTs,
                    f = b.lastReadActionTs;
                b = b.lastReadWatermarkTs;
                var j = a.deliveredWatermarkTs,
                    l = a.lastReadWatermarkTs,
                    m = a.lastReadActionTs,
                    n = d > j,
                    o = b > l,
                    p = m == null || f > m;
                c != null && c.LOG(h(), a.threadJid, a.userJid, d, b, f);
                if (!n && !o && !p) {
                    k.push(a);
                    return
                }
                g.push(babelHelpers["extends"]({}, a, {
                    deliveredWatermarkTs: n ? d : j,
                    lastReadActionTs: p ? f : m,
                    lastReadWatermarkTs: o ? b : l
                }))
            });
            g.forEach(function(a) {
                return l(a, "bulkUpdateParticipantTimestamps")
            });
            return a.participants.bulkPut(g).then(function() {
                g.forEach(function(a) {
                    d("MAWIndexedDb").afterTransaction({
                        tag: "ReceivedReceipt",
                        value: d("MAWBridgeTypesCreators").createBridgeReceivedReceipt(a.threadJid, d("WAJids").extractUserId(a.userJid), a.deliveredWatermarkTs, a.lastReadWatermarkTs, a.lastReadActionTs)
                    })
                });
                return [].concat(g, k)
            })
        })
    }

    function s(a, b) {
        return a.participants.where("threadJid").equals(b).toArray()
    }

    function t(a, b) {
        return a.participants.where("threadJid").anyOf(b).toArray()
    }

    function u(a, b) {
        return s(a, b).then(function(a) {
            return a.filter(function(a) {
                return a.type === "invitedParticipant"
            })
        })
    }

    function v(a, b, c) {
        return a.participants.where(["threadJid", "userJid"]).equals([b, c]).first().then(function(a) {
            return a == null ? d("WAResultOrError").makeError("missing") : d("WAResultOrError").makeResult(a)
        })
    }

    function w(a, b) {
        return a.participants.where(["threadJid", "userJid"]).anyOf(b).toArray().then(function(a) {
            var c = new Map(a.map(function(a) {
                return [JSON.stringify([a.threadJid, a.userJid]), a]
            }));
            return b.map(function(a) {
                return c.get(JSON.stringify(a))
            })
        })
    }
    g.addParticipant = a;
    g.bulkAddParticipants = k;
    g.logIfIllegalParticipant = l;
    g.bulkAddParticipantsInThreads = m;
    g.bulkUpsertParticiantsInThread = b;
    g.bulkUpdateParticipants = e;
    g.bulkDeleteParticipantsInThread = f;
    g.bulkDeleteParticipantAcrossThreads = n;
    g.bulkDeleteParticipants = o;
    g.deleteAllParticipantsForThread = p;
    g.updateParticipantTimestamps = q;
    g.bulkUpdateParticipantTimestamps = r;
    g.getParticipantsInThread = s;
    g.getParticipantsInThreads = t;
    g.getInvitedParticipantsInThread = u;
    g.getParticipant = v;
    g.bulkGetParticipants = w
}), 98);
__d("MAWWriteMsgSideEffectTxns", ["MAWDbMsg", "MAWDbParticipantTxns", "MAWDexieTable"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = d("MAWDbMsg").getCanonicalTsFromMsg(b),
            e = b.author;
        return e !== "@me" && e !== "@system" ? d("MAWDbParticipantTxns").updateParticipantTimestamps(a, [b.threadJid, e], c, c, c) : d("MAWDexieTable").dexieResolve()
    }
    g.updateParticipantTimestampsForMsg = a
}), 98);
__d("MAWWriteMsgTxns", ["MAWAfterWriteMsgUtil", "MAWBridgeMsg", "MAWBridgeTypesCreators", "MAWBuildIncomingMsgs", "MAWDbEditMsgHistory", "MAWDbEditMsgHistoryTxns", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbPendingStanzaTxns", "MAWDbReactionsTxns", "MAWDbThread", "MAWDbThreadTxns", "MAWDbUnrenderedMsgTxns", "MAWDeleteForMeMsgContentCleaner", "MAWDeleteThreadUtil", "MAWDexieTable", "MAWEBUploadMessageUtils", "MAWEphemeralMsgTxns", "MAWExpiredQuoteCleaner", "MAWFTSTxns", "MAWFolderTypes", "MAWGetMsgQuoteTxn", "MAWGetOrCreateThreadTxns", "MAWIndexedDb", "MAWLoadReplyMediaTxns", "MAWLocalizationUtils", "MAWMessageHasUniqueExternalIdValidator", "MAWMsgType", "MAWThreadEvent", "MAWThreadSnippetBuildTxns", "MAWThreadSnippetUtils", "MAWThreadUpdateMiddlewareGKUtil", "MAWTimeUtils", "MAWUpdateQuotedMsgTxns", "MAWWriteMsgSideEffectTxns", "MAWWriteRevokeMessageTxns", "WAJids", "WALogger", "WATimeUtils", "err", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["handle", " Msg: Message from ", ", chat ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["writeMsgAfterTransaction - sortOrderMs: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j(a, b, e, f, g) {
        var h = e.ts;
        h = [d("WATimeUtils").castUnixTimeToMillisTime(h), e.type === d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN];
        var i = h[0],
            j = h[1];
        return d("MAWGetOrCreateThreadTxns").getExistingThread(a, b.jid).then(function(b) {
            if (b == null) throw c("err")("at this point there's always a thread - checking for updates");
            var h = d("MAWDbMsgTxns").getThreadOldestMessageBySortOrder(a, b.jid),
                k = d("MAWDbMsgTxns").getThreadNewestMessageBySortOrder(a, b.jid);
            return d("MAWDexieTable").dexieAll([h, k]).then(function(c) {
                var h, k, l = c[0];
                c = c[1];
                var m = c == null ? 1 : d("MAWDbMsg").getInChatMsgIdFromMsgId(c.msgId) + 1;
                h = d("WATimeUtils").castToMillisTime((h = c == null ? void 0 : c.sortOrderMs) != null ? h : 0);
                var n = i > h && !j ? i : h;
                h = (h = d("MAWTimeUtils").ensureValidMillisTime(b.lastReadMsgTs)) != null ? h : 0;
                k = d("WATimeUtils").castToMillisTime((k = c == null ? void 0 : c.sortOrderMs) != null ? k : 0);
                h = h < k;
                var o = e.author === d("WAJids").AUTHOR_ME || e.type === d("MAWMsgType").MSG_TYPE.ADMIN && d("MAWLocalizationUtils").isParticipantChangeAdminMsg(e.msgContent.adminType) && !h,
                    p = babelHelpers["extends"]({}, e, {
                        msgId: (k = g) != null ? k : d("MAWDbMsg").craftMsgIdV2(b.chatId, m, e)
                    }),
                    q = d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(e);
                k = q > ((h = b.snippetMsgTs) != null ? h : 0);
                var r = !d("MAWThreadSnippetUtils").isDbMsgDisabledForThreadSnippet(p) && k;
                m = d("MAWDbMsgTxns").calculateOldestAndNewestMsg(l, c, p, f);
                var s = m.newestMsg,
                    t = m.oldestMsg;
                h = r ? d("MAWThreadSnippetBuildTxns").buildThreadSnippet(a, p) : d("MAWDexieTable").dexieResolve(null);
                return h.then(function(a) {
                    return {
                        isOldestMsgUpdated: l != null && t !== l.msgId,
                        msgId: p.msgId,
                        prevOldestMsg: l,
                        updatedSnippet: a,
                        updatedThread: babelHelpers["extends"]({}, b, {
                            lastReadMsg: o ? p.msgId : b.lastReadMsg,
                            lastReadMsgTs: o ? n : b.lastReadMsgTs,
                            newestMsg: s,
                            newestMsgTs: n,
                            oldestMsg: t,
                            snippetMsg: r ? p.msgId : b.snippetMsg,
                            snippetMsgTs: r ? d("WATimeUtils").castToMillisTime(q) : b.snippetMsgTs,
                            threadOrder: d("MAWDbThread").craftThreadOrder(n, b.jid)
                        })
                    }
                })
            })
        })
    }

    function a(a, b, c, e) {
        return a.messages.where(["threadJid", "sortOrderMs"]).equals([c.jid, e]).filter(function(a) {
            return a.type !== d("MAWMsgType").MSG_TYPE.EPHEMERAL_SETTING_ADMIN && a.type !== d("MAWMsgType").MSG_TYPE.EPHEMERAL_SCREENSHOT_ACTION ? !1 : a.type === b.type && a.msgContent.adminType === b.msgContent.adminType
        }).first().then(function(d) {
            return d != null ? d : l(a, b, c, "MAWWriteMsgTxns::writeDedupedEphemeralSettingAdminMessage")
        })
    }

    function b(a, b, c, e) {
        return a.messages.where(["threadJid", "sortOrderMs"]).equals([c.jid, e]).filter(function(a) {
            return a.type === d("MAWMsgType").MSG_TYPE.ADMIN && a.msgContent.adminType === b.msgContent.adminType
        }).first().then(function(d) {
            return d != null ? d : l(a, b, c, "MAWWriteMsgTxns::writeDedupedAdminMessage")
        })
    }

    function k(a, b, c) {
        c = c != null ? a.messages.put(babelHelpers["extends"]({}, b, {
            rowId: c
        })) : a.messages.add(b);
        return c.then(function(a) {
            return babelHelpers["extends"]({}, b, {
                rowId: a
            })
        })
    }

    function l(a, b, e, f, g) {
        g === void 0 && (g = {});
        g = g;
        var h = g.hasMoreAfter,
            l = g.hasMoreBefore,
            m = g.isFirstMsg,
            n = m === void 0 ? !1 : m;
        m = g.isIncoming;
        var o = m === void 0 ? !1 : m;
        m = g.isMediaGalleryRestore;
        var p = m === void 0 ? !1 : m;
        m = g.isOutgoing;
        var q = m === void 0 ? !1 : m,
            r = g.msgsLeftToRestoreForEB,
            s = g.openMessageOtid,
            t = g.openMessageParticipantCount,
            u = g.optimisticMsg,
            v = g.participantCount,
            w = g.quotedReplyAttachmentMeta,
            x = g.s2sInstanceKey;
        m = g.sortOrderMs;
        var y = g.upsertRowData;
        if (y && !q) throw c("err")("Upsert attempted outside outgoing message path; aborting.");
        return j(a, e, b, m, y == null ? void 0 : y.msgId).then(function(e) {
            var g = e.isOldestMsgUpdated,
                j = e.msgId,
                m = e.prevOldestMsg,
                z = e.updatedSnippet,
                A = e.updatedThread;
            e = babelHelpers["extends"]({}, b, {
                msgId: j,
                sortOrderMs: d("MAWEBUploadMessageUtils").echoOverrideMessageSortOrder(b)
            });
            d("MAWMessageHasUniqueExternalIdValidator").logMessageAddSource([e.externalId], "MAWWriteMsgTxns::writeMsg::" + f, {
                editCount: ((j = e.editCount) != null ? j : 0).toString(),
                hasOptimisticMessage: (u != null).toString(),
                isIncoming: o.toString(),
                isOutgoing: q.toString()
            });
            return d("MAWDexieTable").dexieAll([k(a, e, y == null ? void 0 : y.rowId), a.threads.put(A), d("MAWFTSTxns").maybePutMessageToBacklog(a, e.externalId)]).then(function(a) {
                var b = a[0];
                a[1];
                q && d("WALogger").LOG(i(), b.sortOrderMs);
                a = d("MAWAfterWriteMsgUtil").WriteMsgAfterTxnBumpThreadOption.BUMP_LOCAL_ONLY;
                o && b.altIndex !== d("MAWDbMsg").SPAM_ALT_INDEX && b.altIndex !== d("MAWDbMsg").FUTUREPROOF_SPAM_ALT_INDEX && b.author !== d("WAJids").AUTHOR_ME ? a = d("MAWAfterWriteMsgUtil").WriteMsgAfterTxnBumpThreadOption.BUMP_LOCAL_AND_SERVER : q && (a = d("MAWAfterWriteMsgUtil").WriteMsgAfterTxnBumpThreadOption.DO_NOT_BUMP_THREAD);
                p && c("justknobx")._("3060") || d("MAWAfterWriteMsgUtil").writeMsgAfterTransaction({
                    bumpThreadOption: a,
                    dbMsg: b,
                    hasMoreAfter: h,
                    hasMoreBefore: l,
                    initialLoad: m == null && !y,
                    isFirstMsg: n,
                    isOldestMsgUpdated: g,
                    msgsLeftToRestoreForEB: r,
                    openMessageOtid: s,
                    openMessageParticipantCount: t,
                    optimisticMsg: u,
                    participantCount: v,
                    quotedReplyAttachmentMeta: w,
                    s2sInstanceKey: x,
                    snippet: z,
                    updatedThread: A
                });
                return b
            })
        })
    }

    function m(a, b, e) {
        return d("MAWGetOrCreateThreadTxns").getExistingThread(a, e.jid).then(function(e) {
            if (e == null) throw c("err")("at this point there's always a thread - checking for updates");
            return d("MAWDbUnrenderedMsgTxns").getNextUnrenderedMsgIdNumberForThread(a, e).then(function(c) {
                var f = babelHelpers["extends"]({}, b, {
                    msgId: d("MAWDbMsg").craftUnrenderedMsgId(e.chatId, c)
                });
                return d("MAWDexieTable").dexieAll([a.unrenderedMessages.add(f), a.threads.put(e)]).then(function(a) {
                    var b = a[0];
                    a[1];
                    return babelHelpers["extends"]({}, f, {
                        rowId: b
                    })
                })
            })
        })
    }

    function e(a, b, c) {
        return d("MAWDexieTable").dexieAll([n(a, b, c), d("MAWDbEditMsgHistoryTxns").getEditHistoryByOriginalMsgExternalIdAndThreadJid(a, [
            [b.externalId, c.jid]
        ]).then(function(a) {
            return {
                editMsgHistories: a,
                originalEditMsgHistory: a.find(function(a) {
                    return a.editExternalId === b.externalId
                })
            }
        })]).then(function(a) {
            var b = a[0];
            a = a[1];
            var c = a.editMsgHistories;
            a = a.originalEditMsgHistory;
            return babelHelpers["extends"]({}, b, {
                editMsgHistories: c,
                existingEditMsgHistory: (b = a) != null ? b : null
            })
        })
    }

    function n(a, b, c) {
        c = [b.externalId, c.jid, b.author];
        var e = c[0],
            f = c[1];
        c = c[2];
        return d("MAWDexieTable").dexieAll([d("MAWDbMsgTxns").maybeGetMsgByExternalId(a, e, f, c), d("MAWDbPendingStanzaTxns").maybeGetPendingRevokedStanza(a, e, c, f), d("MAWDbPendingStanzaTxns").maybeGetPendingDeletedStanza(a, e, c, f), d("MAWDbMsgTxns").checkIfMsgIsDeletedForMeOrRevoked(a, e, f, c), d("MAWDbPendingStanzaTxns").maybeGetDeleteThreadFromPendingStanza(a, f).then(function(a) {
            return d("MAWDeleteThreadUtil").isMsgDeletedViaDeleteThread(b.ts, a)
        })]).then(function(a) {
            var b = a[0],
                c = a[1],
                d = a[2],
                e = a[3];
            a = a[4];
            return {
                existingMsg: (b = b) != null ? b : null,
                isDeletedWithThread: a,
                isDeleteForMeOrRevoked: e,
                pendingDeleteForMeStanza: (b = d) != null ? b : null,
                pendingRevokedStanza: (a = c) != null ? a : null
            }
        })
    }

    function f(a, b, e, f, g, i) {
        return d("MAWDbPendingStanzaTxns").maybeGetPendingRevokedStanza(a, b.externalId, b.author, e.jid).then(function(j) {
            if (j != null) return q(a, b, e, j);
            j = b.author;
            d("WALogger").DEV(h(), b.type, j, e.jid);
            var k = babelHelpers["extends"]({}, babelHelpers["extends"]({}, b, {
                threadJid: e.jid
            }));
            e.folder === d("MAWFolderTypes").FOLDER_ID.OTHER && (k.altIndex = k.altIndex === d("MAWDbMsg").FUTUREPROOF_ALT_INDEX ? d("MAWDbMsg").FUTUREPROOF_SPAM_ALT_INDEX : d("MAWDbMsg").SPAM_ALT_INDEX);
            return d("MAWGetMsgQuoteTxn").getMsgQuoteInfo(a, k, e.jid, i).then(function(b) {
                b != null && (k = babelHelpers["extends"]({}, k, {
                    quote: b == null ? void 0 : b.quote,
                    quoteExpirationTs: b == null ? void 0 : b.quote.content.expirationTs,
                    quoteExternalId: b == null ? void 0 : b.quoteExternalId
                }));
                b = k.quoteExpirationTs;
                b != null && b > d("WATimeUtils").unixTime() && d("MAWExpiredQuoteCleaner").addNewExpiredQuoteCleanerTimestamp(b);
                return d("MAWDexieTable").dexieAll([d("MAWUpdateQuotedMsgTxns").associateQuotedMessage(a, e.jid, k), d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, k), d("MAWLoadReplyMediaTxns").getReplyMediaForMsg(a, k)]).then(function(b) {
                    var h = b[0],
                        i = b[1],
                        j = b[2];
                    return l(a, k, e, f, {
                        isIncoming: !0,
                        isMediaGalleryRestore: g,
                        quotedReplyAttachmentMeta: i
                    }).then(function(b) {
                        return d("MAWDexieTable").dexieAll([d("MAWWriteMsgSideEffectTxns").updateParticipantTimestampsForMsg(a, k), d("MAWEphemeralMsgTxns").markEphemeralMessageAsSent(a, b, g)]).then(function(a) {
                            a = a[1];
                            h != null && (g === !0 && c("justknobx")._("3060") || h.forEach(function(a) {
                                d("MAWIndexedDb").afterTransaction({
                                    tag: "MsgUpdated",
                                    value: d("MAWBridgeMsg").createBridgeMsg(a, void 0, j)
                                })
                            }));
                            return a || b
                        })
                    })
                })
            })
        })
    }

    function o(a, b, c, e, f, g) {
        var h = babelHelpers["extends"]({}, babelHelpers["extends"]({}, b, {
            msgId: c.msgId,
            rowId: c.rowId,
            serverTs: c.serverTs,
            sortOrderMs: c.sortOrderMs,
            threadJid: e.jid,
            ts: c.ts
        }));
        return d("MAWDexieTable").dexieAll([d("MAWUpdateQuotedMsgTxns").associateQuotedMessage(a, e.jid, h), d("MAWLoadReplyMediaTxns").getReplyMediaForMsgQuote(a, h), d("MAWLoadReplyMediaTxns").getReplyMediaForMsg(a, h), d("MAWGetMsgQuoteTxn").getMsgQuoteInfo(a, h, e.jid, g), d("MAWDbMsgTxns").getThreadNewestMessageId(a, e.jid)]).then(function(g) {
            var i = g[0],
                j = g[1],
                k = g[2],
                l = g[3],
                m = g[4];
            h = babelHelpers["extends"]({}, h, {
                quote: l == null ? void 0 : l.quote,
                quoteExternalId: l == null ? void 0 : l.quoteExternalId
            });
            return ((g = c.editCount) != null ? g : 0) > 0 && f != null && b.type === d("MAWMsgType").MSG_TYPE.TEXT ? d("MAWDbEditMsgHistoryTxns").updateEditMsgHistoryWithNewIncomingMsg(a, f, b).then(function(a) {
                a != null && d("MAWIndexedDb").afterTransaction({
                    tag: "EditMsgHistoryAdded",
                    value: [babelHelpers["extends"]({}, a, {
                        editMsgHistoryId: d("MAWDbEditMsgHistory").convertToEditMsgHistoryId64(a.editMsgHistoryId),
                        originalMsgId: c.msgId
                    })]
                });
                return c
            }) : a.messages.put(h).then(function() {
                return d("MAWDbThreadTxns").needsRetroactiveReadReceiptInThread(a, h)
            }).then(function(b) {
                if (b) {
                    h.altIndex = d("MAWDbMsg").craftToBeReadAltIndex(e.chatId);
                    return a.messages.put(h)
                }
            }).then(function() {
                d("MAWIndexedDb").afterTransaction({
                    tag: "MsgUpdated",
                    value: d("MAWBridgeMsg").createBridgeMsg(h, void 0, k)
                });
                d("MAWIndexedDb").afterTransaction({
                    tag: "MsgUpdated",
                    value: d("MAWBridgeMsg").createBridgeMsg(h, void 0, j)
                });
                d("MAWIndexedDb").afterTransactionThreadEvent({
                    chatJid: e.jid,
                    msgId: h.msgId
                }, d("MAWThreadEvent").PLACEHOLDER_CONVERT_SUBSCRIPTION);
                i != null && i.forEach(function(a) {
                    d("MAWIndexedDb").afterTransaction({
                        tag: "MsgUpdated",
                        value: d("MAWBridgeMsg").createBridgeMsg(a, void 0, k)
                    })
                });
                if (h.msgId === m) {
                    var b = h;
                    b.rowId;
                    b = babelHelpers.objectWithoutPropertiesLoose(b, ["rowId"]);
                    d("MAWWriteMsgSideEffectTxns").updateParticipantTimestampsForMsg(a, b);
                    if (!d("MAWThreadUpdateMiddlewareGKUtil").isThreadUpdateEnabledViaMiddlewareForMsgType(h.type)) return d("MAWThreadSnippetBuildTxns").buildThreadSnippet(a, h).then(function(a) {
                        var b = a.snippetParams,
                            c = a.snippetSenderContactId;
                        a = a.snippetType;
                        d("MAWIndexedDb").afterTransaction({
                            tag: "ThreadUpdated",
                            value: d("MAWBridgeTypesCreators").createBridgeUpdatedThread({
                                snippetParams: b,
                                snippetSenderContactId: c,
                                snippetType: a,
                                threadJid: e.jid
                            })
                        });
                        return h
                    })
                }
                return h
            })
        })
    }

    function p(a, b, c, e) {
        var f = d("MAWBuildIncomingMsgs").buildUnstoredDeleteForMeMsg(b, c);
        return d("MAWDexieTable").dexieAll([d("MAWDbReactionsTxns").deleteReactionsByUniqueMsgIdentifiers(a, [{
            author: f.author,
            chatJid: f.threadJid,
            externalId: f.externalId
        }]), m(a, f, c), a.pendingStanzas["delete"](e.rowId), d("MAWFTSTxns").maybePutMessageToPurgeBacklog(a, b.externalId)]).then(function(a) {
            a[0];
            a = a[1];
            d("MAWDeleteForMeMsgContentCleaner").addNewDeleteForMeMsgContentCleanerTimestamp(f.messageDeleteForMeTs);
            return babelHelpers["extends"]({}, f, {
                msgId: a.msgId,
                rowId: a.rowId
            })
        })
    }

    function q(a, b, e, f) {
        var g = d("MAWDbPendingStanzaTxns").getRevokedContent(f);
        if (g == null) throw c("err")("missing revoked content");
        b = d("MAWBuildIncomingMsgs").buildUnstoredRevokedMsg(b, e, g);
        return d("MAWDexieTable").dexieAll([l(a, b, e, "MAWHandleMsgTxns::handleOutOfOrderRevokedMessage"), a.pendingStanzas["delete"](f.rowId)]).then(function(b) {
            var c = b[0];
            return d("MAWWriteRevokeMessageTxns").markIncomingMessageRevoked(a, c, e).then(function() {
                return c
            })
        })
    }
    g.writeDedupedEphemeralSettingAdminMessage = a;
    g.writeDedupedAdminMessage = b;
    g.writeMsg = l;
    g.writeUnrenderedMsg = m;
    g.prepareTextMsgWriteData = e;
    g.prepareMsgWriteData = n;
    g.writeNewIncomingMsg = f;
    g.writeCiphertextUpdate = o;
    g.handleDeleteForMeMessage = p;
    g.handleOutOfOrderRevokedMessage = q
}), 98);
__d("MAWDbDeletedMessages", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        ChatDelete: "chat_delete",
        Revoke: "revoke"
    });
    f.DbDeletedMsgReasonEnum = a
}), 66);
__d("MAWUnsendMsgContentCleaner", ["MAWMsgCleaner", "WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["UnsendMsgContentCleaner: Adding timestamps (", ")"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["startUnsendMsgContentCleaner invoked"]);
        j = function() {
            return a
        };
        return a
    }
    var k = null;

    function a(a) {
        d("WALogger").LOG(j()), k == null && (k = new(d("MAWMsgCleaner").MsgCleaner)(a, d("MAWMsgCleaner").CLEANER_TYPE.UNSEND))
    }

    function b(a) {
        if (k == null) {
            var b = "Trying to add new UnsendMsgContentCleanerTimestamp before the cleaner is initialized!";
            d("WALogger").ERROR(i(), b);
            throw c("err")(b)
        } else d("WALogger").DEV(h(), a), k.update(a)
    }

    function e() {
        return k
    }

    function f() {
        k = null
    }
    g.startUnsendMsgContentCleaner = a;
    g.addNewUnsendMsgContentCleanerTimestamp = b;
    g.getUnsendMsgContentCleaner_FOR_TESTING_ONLY = e;
    g.resetUnsendMsgContentCleaner_FOR_TESTING_ONLY = f
}), 98);
__d("MAWWriteRevokeMessageTxns", ["EBUploadMessages", "FBLogger", "MAWAckLevel", "MAWBridgeMsg", "MAWBridgeTypesCreators", "MAWDbDeletedMessages", "MAWDbMsg", "MAWDbMsgTxns", "MAWDbPendingStanza", "MAWDbReactionsTxns", "MAWDexieTable", "MAWEphemeralUtil", "MAWFTSTxns", "MAWIndexedDb", "MAWJidUtils", "MAWMsgType", "MAWPendingStanzaCleaner", "MAWThreadSnippetBuildTxns", "MAWUnsendMsgContentCleaner", "MAWUpdateQuotedMsgTxns", "MAWWriteDeleteMessageTxns", "MAWWriteMsgTxns", "MAWXMAUtils", "WATimeUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 6 * d("WATimeUtils").HOUR_SECONDS,
        i = 30 * d("WATimeUtils").DAY_SECONDS;

    function a(a, b, e, f, g, h) {
        if (h != null && f == null) {
            h = babelHelpers["extends"]({}, b, {
                originalTs: d("WATimeUtils").castMilliSecondsToUnixTime(h),
                threadJid: e.jid,
                unsendMsgContentDeleteTs: (h = b.serverTs) != null ? h : b.ts
            });
            return d("MAWWriteMsgTxns").writeMsg(a, h, e, "MAWWriteRevokeMessageTxns::writeIncomingRevokeMsg").then(function(a) {
                return a.type === "Revoked" ? a : null
            })
        }
        var k = d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + i),
            m = b.author,
            n = b.externalId,
            o = b.revokedExternalId,
            p = g != null ? l(a, g) : d("MAWDexieTable").dexieResolve();
        return d("MAWDexieTable").dexieAll([f == null ? d("MAWDbMsgTxns").maybeGetMsgByExternalId(a, b.revokedExternalId, e.jid, b.author) : d("MAWDexieTable").dexieResolve(f), d("MAWFTSTxns").maybePutMessageToPurgeBacklog(a, n)]).then(function(g) {
            var h = g[0];
            (f == null || h != null) && c("FBLogger")("messenger_e2ee_web").warn("Revoked message missing originalMsg incorrectly");
            if (h == null) {
                g = {
                    deleteTs: k,
                    externalIdWithType: o + "_" + d("MAWDbPendingStanza").PENDING_REVOKED,
                    pendingContent: {
                        content: {
                            ack: d("MAWAckLevel").ACK.received,
                            altIndex: void 0,
                            author: m,
                            externalId: n,
                            revokedExternalId: o,
                            threadJid: e.jid,
                            ts: b.ts,
                            type: "Revoked"
                        },
                        type: d("MAWDbPendingStanza").PENDING_TYPE.REVOKED
                    }
                };
                return d("MAWDexieTable").dexieAll([a.pendingStanzas.add(g), p]).then(function(b) {
                    b[0];
                    b = b[1];
                    d("MAWPendingStanzaCleaner").addNewPendingStanzaCleanerTimestamp(k);
                    b === !0 && d("MAWThreadSnippetBuildTxns").refreshThreadSnippet(a, e)
                })
            }
            return p.then(function() {
                return j(a, h, e, b.externalId, b.revokedExternalId, b.serverTs, b.ts, !1)
            })
        })
    }

    function j(a, b, c, e, f, g, i, j) {
        var l = babelHelpers["extends"]({}, b, {
            altIndex: void 0,
            externalId: e,
            msgContent: d("MAWDbMsg").getMsgContent(b),
            originalTs: (e = b.serverTs) != null ? e : b.ts,
            revokedExternalId: f,
            serverTs: g,
            threadJid: c.jid,
            ts: i,
            type: "Revoked",
            unsendMsgContentDeleteTs: d("WATimeUtils").castToUnixTime(d("WATimeUtils").unixTime() + h)
        });
        if (j) {
            d("EBUploadMessages").sendDeleteEchoMessage(b, c.jid);
            return d("MAWDexieTable").dexieResolve(l)
        }
        return k(a, b, l, c).then(function() {
            return l
        })
    }

    function k(a, b, c, e, f) {
        var g;
        f === void 0 && (f = !1);
        g = d("MAWXMAUtils").isXMAStoryReply((g = b.quote) == null ? void 0 : g.content.xmaMessageType) ? d("MAWWriteDeleteMessageTxns").deleteXMAStoryReplyMsg(a, b) : d("MAWDexieTable").dexieResolve();
        var h = d("MAWJidUtils").toProtocolMsgId(b);
        h = h != null ? a.deletedMessages.add(babelHelpers["extends"]({}, h, {
            reason: d("MAWDbDeletedMessages").DbDeletedMsgReasonEnum.Revoke
        })) : d("MAWDexieTable").dexieResolve();
        return d("MAWDexieTable").dexieAll([a.messages.put(c), d("MAWDbReactionsTxns").deleteReactionsByUniqueMsgIdentifiers(a, [{
            author: c.author,
            chatJid: c.threadJid,
            externalId: c.revokedExternalId
        }]), d("MAWUpdateQuotedMsgTxns").disassociateQuotedMsg(a, c.threadJid, c.revokedExternalId, c.author, d("MAWMsgType").MSG_TYPE.REVOKED), g, h, d("MAWFTSTxns").maybePutMessageToPurgeBacklog(a, b.externalId)]).then(function() {
            f || d("MAWUnsendMsgContentCleaner").addNewUnsendMsgContentCleanerTimestamp(c.unsendMsgContentDeleteTs);
            return d("MAWThreadSnippetBuildTxns").refreshThreadSnippet(a, e)
        }).then(function() {
            b != null && d("EBUploadMessages").sendDeleteEchoMessage(b, b.threadJid);
            d("MAWIndexedDb").afterTransaction({
                tag: "MsgUpdated",
                value: d("MAWBridgeMsg").createBridgeMsg(c)
            });
            if (b != null && d("MAWDbMsg").isMediaMsg(b)) {
                var a = b.mediaId,
                    e = b.plaintextHash;
                a != null && (e != null ? d("MAWIndexedDb").afterTransaction({
                    tag: "MediaExpired",
                    value: {
                        mediaId: a,
                        msgId: b.msgId,
                        plaintextHash: e,
                        threadJid: b.threadJid
                    }
                }) : d("MAWIndexedDb").afterTransaction({
                    tag: "MediaExpired",
                    value: {
                        mediaId: a,
                        msgId: b.msgId,
                        threadJid: b.threadJid
                    }
                }))
            }
            d("MAWEphemeralUtil").maybeClearEphemeralMsgCountdown(b)
        })
    }

    function b(a, b, e) {
        if (b.type !== d("MAWMsgType").MSG_TYPE.REVOKED) throw c("err")("Cant mark unrevoked message revoked");
        var f = d("MAWJidUtils").toProtocolMsgId(b);
        f = f != null ? a.deletedMessages.add(babelHelpers["extends"]({}, f, {
            reason: d("MAWDbDeletedMessages").DbDeletedMsgReasonEnum.Revoke
        })) : d("MAWDexieTable").dexieResolve();
        return d("MAWDexieTable").dexieAll([d("MAWDbReactionsTxns").deleteReactionsByUniqueMsgIdentifiers(a, [{
            author: b.author,
            chatJid: b.threadJid,
            externalId: b.revokedExternalId
        }]), d("MAWThreadSnippetBuildTxns").refreshThreadSnippet(a, e), f]).then(function() {
            d("MAWUnsendMsgContentCleaner").addNewUnsendMsgContentCleanerTimestamp(b.unsendMsgContentDeleteTs), d("MAWIndexedDb").afterTransaction({
                tag: "NewMsg",
                value: d("MAWBridgeMsg").createBridgeMsg(b)
            })
        })
    }

    function l(a, b) {
        return b.type === d("MAWMsgType").MSG_TYPE.CIPHERTEXT ? a.messages["delete"](b.rowId).then(function() {
            d("MAWIndexedDb").afterTransaction({
                tag: "DeleteMessages",
                value: d("MAWBridgeTypesCreators").createBridgeDeleteMessages(b.threadJid, [b])
            });
            return !0
        }) : d("MAWDexieTable").dexieResolve(!1)
    }
    g.REVOKE_CONTENT_EXPIRATION_IN_SEC = h;
    g.writeIncomingRevokeMsg = a;
    g.revokeUnstoredMsg = j;
    g.markExistingMsgRevoked = k;
    g.markIncomingMessageRevoked = b
}), 98);
__d("MAWHandlePendingStanzasInRestoreV2", ["EBUploadMessages", "LSMEBTaskCreationSource", "MAWBridgeEventTransmitter", "MAWDbPendingStanza", "MAWDbPendingStanzaTxns", "MAWDexieTable", "MAWEBUploadTrackingUtils", "MAWEncryptedBackupCacheManager", "MAWIndexedDb", "MAWTransactionMode", "MAWWriteRevokeMessageTxns", "Promise", "WAJids", "WALogger", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] pendingStanza type ", " is not supported"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] revokedExternalId is null for pendingStanza"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] revokedExternalId is null for pendingStanza"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] threadJid is null for pendingStanza"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] pendingStanzaTs is null for pendingStanza"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] revokedExternalId is null for pendingStanza"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] externalId is null for pendingStanza"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Delete For Me pending stanza does not need to be applied."]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] thread is null"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] pendingStanza type ", " is not supported"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Pending Stanza not found in the cache. This shouldn't happen."]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] Could not find thread for chatId ", " for pendingStanza"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[labyrinth_web] externalId is null for pendingStanza"]);
        u = function() {
            return a
        };
        return a
    }
    a = function(a, c, d) {
        a = a.restoredMsgsData;
        if (a) {
            var e = a.newlyAddedMsgs;
            e = e.concat(a.existingMsgs);
            return v(e, c, d)
        }
        return (h || (h = b("Promise"))).resolve()
    };
    var v = function(a, e, f) {
            f == null ? void 0 : f.addPoint("apply_pending_stanza_start");
            var g = 0,
                i = 0,
                j = 0,
                k = 0,
                l = new Map();
            return D().then(function(a) {
                a == null ? void 0 : a.map(function(a) {
                    var b = a.pendingContent.content.externalId;
                    if (b == null) {
                        d("WALogger").WARN(u());
                        return
                    }
                    l.set(a.externalIdWithType, a)
                }), k = l.size
            }).then(function() {
                var b = new Set();
                return z(a).then(function(f) {
                    return d("MAWDexieTable").dexieAll(a.map(function(a) {
                        var c = a.externalId,
                            h = f.get(a.threadJid);
                        if (h == null) {
                            d("WALogger").ERROR(t(), a.threadJid);
                            return d("MAWDexieTable").dexieResolve()
                        }
                        if (e)
                            if (d("MAWEncryptedBackupCacheManager").peekPendingStanzaCache(c)) {
                                var k = d("MAWEncryptedBackupCacheManager").getPendingStanzaCacheValue(c);
                                if (k == null) {
                                    d("WALogger").ERROR(s());
                                    return
                                }
                                return y(k, a, h, e).then(function(a) {
                                    a != null && b.add(k);
                                    d("MAWEncryptedBackupCacheManager").removePendingStanzaCacheValue(c);
                                    l["delete"](k.externalIdWithType);
                                    a = k.pendingContent.type;
                                    a === d("MAWDbPendingStanza").PENDING_TYPE.REVOKED && g++;
                                    i++
                                })
                            } else l.clear();
                        else {
                            var m = c + "_" + d("MAWDbPendingStanza").PENDING_REVOKED,
                                n = l.get(m);
                            if (n != null) return y(n, a, h, e).then(function(a) {
                                a != null && (b.add(n), g++, j++), l["delete"](n.externalIdWithType)
                            })
                        }
                    })).then(function() {
                        if (!e) {
                            var a = w(l);
                            g += a[1];
                            i += a[0] + a[1];
                            c("promiseDone")(x(Array.from(b)))
                        }
                    })
                })
            }).then(function(a) {
                f == null ? void 0 : f.addPoint("apply_pending_stanza_end", {
                    "int": {
                        initialRestorePendingStanzaCount: j,
                        pendingStanzasToBeUploadedCount: k,
                        pointRestorePendingStanzaCount: i,
                        revokedCount: g
                    }
                });
                return (h || (h = b("Promise"))).resolve()
            })
        },
        w = function(a) {
            var b = 0,
                c = 0;
            a.forEach(function(a) {
                var e = a.pendingContent.type;
                e === d("MAWDbPendingStanza").PENDING_TYPE.REVOKED ? c++ : e === d("MAWDbPendingStanza").PENDING_TYPE.DELETE_FOR_ME && b++;
                C(a)
            });
            a.clear();
            return [b, c]
        },
        x = (e = d("MAWIndexedDb")).makeMsgrTransactor({
            pendingStanzas: (f = d("MAWTransactionMode")).READWRITE
        }, "deletePendingStanzasFromIndexedDB", function(a) {
            return function(b) {
                return d("MAWDbPendingStanzaTxns").deletePendingStanzas(a, b)
            }
        }),
        y = function(a, e, f, g) {
            var i = a.pendingContent.type;
            if (i === d("MAWDbPendingStanza").PENDING_TYPE.REVOKED) return B(a, e, f, g).then(function(a) {
                if (a != null) {
                    var b = d("MAWEBUploadTrackingUtils").genInstanceKeyOnly();
                    d("MAWEBUploadTrackingUtils").startUploadTracking(a.externalId, a.type, "pendingstanza", b);
                    c("promiseDone")(d("EBUploadMessages").uploadUniqueMessage([a], void 0, !1, void 0, new Map([
                        [a.externalId, b]
                    ]), void 0, "revoked_message"))
                }
            });
            else if (i === d("MAWDbPendingStanza").PENDING_TYPE.DELETE_FOR_ME) return A(a);
            else {
                d("WALogger").WARN(r(), i);
                return (h || (h = b("Promise"))).resolve()
            }
        },
        z = e.makeMsgrTransactor({
            threads: f.READONLY
        }, "getThreadsForMessages", function(a) {
            return function(b) {
                var c = [];
                b.forEach(function(a) {
                    c.push(a.threadJid)
                });
                return a.threads.where("jid").anyOf(c).toArray().then(function(a) {
                    var b = new Map();
                    a.forEach(function(a) {
                        if (a == null) {
                            d("WALogger").WARN(q());
                            return d("MAWDexieTable").dexieResolve()
                        }
                        b.set(a.jid, a)
                    });
                    return b
                })
            }
        }),
        A = e.makeMsgrTransactor({
            pendingStanzas: f.READWRITE
        }, "deleteForMeMsg", function(a) {
            return function(b) {
                d("WALogger").LOG(p());
                return d("MAWDexieTable").dexieAll([a.pendingStanzas["delete"](b.rowId)]).then(function() {
                    return d("MAWDexieTable").dexieResolve(b)
                })
            }
        }),
        B = e.makeMsgrTransactor({
            chunk: f.READONLY,
            deletedMessages: f.READWRITE,
            ftsPurgeBacklog: f.READWRITE,
            groupInfo: f.READWRITE,
            media: f.READONLY,
            messages: f.READWRITE,
            pendingStanzas: f.READWRITE,
            reactions: f.READWRITE,
            threads: f.READWRITE,
            xma: f.READONLY
        }, "revokeMessage", function(a) {
            return function(b, c, e, f) {
                var g = b.pendingContent.content.externalId;
                if (g == null) {
                    d("WALogger").ERROR(o());
                    return d("MAWDexieTable").dexieResolve()
                }
                var h = b.pendingContent.content.revokedExternalId;
                if (h == null) {
                    d("WALogger").ERROR(n());
                    return d("MAWDexieTable").dexieResolve()
                }
                var i = b.pendingContent.content.ts;
                if (i == null) {
                    d("WALogger").ERROR(m());
                    return d("MAWDexieTable").dexieResolve()
                }
                return d("MAWWriteRevokeMessageTxns").revokeUnstoredMsg(a, c, e, g, h, c.serverTs, c.ts, f).then(function(c) {
                    a.pendingStanzas["delete"](b.rowId);
                    return d("MAWDexieTable").dexieResolve(c)
                })
            }
        });

    function C(a) {
        var b = a.pendingContent.content.threadJid;
        if (b == null) {
            d("WALogger").WARN(l());
            return
        }
        var e = d("WAJids").threadIdForChatJid(b),
            f = a.pendingContent.type;
        if (f === d("MAWDbPendingStanza").PENDING_TYPE.REVOKED) {
            var g = a.pendingContent.content.revokedExternalId;
            if (g == null) {
                d("WALogger").WARN(k());
                return
            }
            g = g
        } else if (f === d("MAWDbPendingStanza").PENDING_TYPE.DELETE_FOR_ME) {
            var h = a.pendingContent.content.externalId;
            if (h == null) {
                d("WALogger").WARN(j());
                return
            }
            g = h
        } else {
            d("WALogger").WARN(i(), f);
            return
        }
        d("MAWEncryptedBackupCacheManager").addPendingStanzaToPendingStanzaCache(g, a);
        d("MAWBridgeEventTransmitter").issuePointQueryOutsideTxn(g, e, void 0, c("LSMEBTaskCreationSource").POINT_QUERY_FROM_EB, b)
    }
    var D = e.makeMsgrTransactor({
        pendingStanzas: f.READONLY
    }, "getAllPendingStanzas", function(a) {
        return function() {
            return d("MAWDbPendingStanzaTxns").getAllPendingStanzas(a)
        }
    });
    g.applyPendingStanzas = a;
    g.issuePointQueryForPendingStanza = C
}), 98);
__d("WAArmadilloBackupMessage.pb", ["WAProtoConst"], (function(a, b, c, d, e, f, g) {
    a = {};
    b = {};
    c = {};
    e = {};
    a.internalSpec = {
        metadata: [1, (f = d("WAProtoConst")).TYPES.MESSAGE, c],
        encryptedTransportMessage: [2, f.TYPES.BYTES],
        encryptedTransportEvent: [5, f.TYPES.MESSAGE, b],
        encryptedTransportLocallyTransformedMessage: [6, f.TYPES.MESSAGE, b],
        __oneofs__: {
            payload: ["encryptedTransportMessage", "encryptedTransportEvent", "encryptedTransportLocallyTransformedMessage"]
        }
    };
    b.internalSpec = {
        payload: [1, f.TYPES.BYTES],
        version: [2, f.TYPES.INT32]
    };
    c.internalSpec = {
        senderId: [1, f.TYPES.STRING],
        messageId: [2, f.TYPES.STRING],
        timestampMs: [3, f.TYPES.INT64],
        frankingMetadata: [4, f.TYPES.MESSAGE, e],
        payloadVersion: [5, f.TYPES.INT32],
        futureProofBehavior: [6, f.TYPES.INT32],
        threadTypeTag: [7, f.TYPES.INT32]
    };
    e.internalSpec = {
        frankingTag: [3, f.TYPES.BYTES],
        reportingTag: [4, f.TYPES.BYTES]
    };
    g.BackupMessageSpec = a;
    g.BackupMessage$SubprotocolSpec = b;
    g.BackupMessage$MetadataSpec = c;
    g.BackupMessage$Metadata$FrankingMetadataSpec = e
}), 98);
__d("EncryptedBackupsUploadEntity", ["$InternalEnum", "EncryptedBackupsUtils", "WAArmadilloBackupMessage.pb", "WAGlobals", "WAJids", "WATimeUtils", "encodeProtobuf"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a
    }
    var h = b("$InternalEnum").Mirrored(["NEEDS_BACKUP", "COMPLETED", "NEEDS_BACKUP_RETRY", "PERMANENT_FAILURE", "EXPIRED", "THREAD_DELETED", "DELETION_PURGED", "MESSAGE_DELETED", "UPLOADING"]);
    b = b("$InternalEnum")({
        INVALID: "-1",
        IMAGE: "0",
        PTT: "1",
        DOCUMENT: "3",
        VIDEO: "4",
        GIF: "5",
        STICKER: "6",
        XMA: "22",
        MESSENGER_PREVIEW: "25"
    });

    function c(a) {
        var b = a.messageApplication,
            c = a.msgId,
            e = a.reportingMeta;
        a = a.sortOrderMs;
        var f = d("WAJids").authorToUserId(c.author, d("WAJids").extractUserId(d("WAGlobals").getMyUserJid()));
        return d("encodeProtobuf").encodeProtobuf(d("WAArmadilloBackupMessage.pb").BackupMessageSpec, d("EncryptedBackupsUtils").asBackupMessage(f, c.externalId, a, (f = e) != null ? f : {
            frankingKey: null,
            frankingTag: null,
            frankingVersion: null,
            reportingContent: null,
            reportingTag: null
        }, b)).readByteArray()
    }

    function e(a) {
        return a.buffer.slice(a.byteOffset, a.byteLength + a.byteOffset)
    }

    function f(a) {
        var b = a.attachmentContext,
            c = a.backupDirective,
            e = a.dbMsgType,
            f = a.isOpenEB;
        f = f === void 0 ? !1 : f;
        var g = a.legacyAttachmentContext,
            i = a.msgId,
            j = a.originalMsgProtocolId,
            k = a.protobuf,
            l = a.senderId,
            m = a.serverTs,
            n = a.sortOrderMs;
        a = a.tags;
        e = {
            backupActionType: c.actionType,
            backupDirective: c,
            dbMsgType: e,
            failTsMs: d("WATimeUtils").castToMillisTime(0),
            isOpenEB: f,
            msgId: i,
            msgIdKey: d("EncryptedBackupsUtils").convertWAMsgIdToStringId(i),
            msgType: "text",
            originalMsgProtocolId: j,
            protobuf: k,
            senderId: l,
            serverTs: m,
            sortOrderMs: n,
            supplementalKey: c.supplementalKey,
            tags: a,
            uploadStatus: h.NEEDS_BACKUP,
            uploadTsSec: d("WATimeUtils").unixTime()
        };
        b != null && (e = babelHelpers["extends"]({}, e, {
            attachmentContext: b,
            legacyAttachmentContext: g,
            msgType: "media"
        }));
        return e
    }
    g.toEbBackupMessageBytes = a;
    g.EbUploadStatus = h;
    g.AttachmentContextMediaType = b;
    g.encodeBackupMessage = c;
    g.getEbBackupMessageBytesBuffer = e;
    g.asEBUploadEntity = f
}), 98);
__d("WAPersistedQueueApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return {
            ack: k,
            clear: m,
            "delete": l,
            index: i,
            keys: n,
            read: h,
            write: j
        }
    }

    function h(a, b) {
        return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READONLY, function(a) {
            a = a.toCollection();
            (b == null ? void 0 : b.order) === "desc" && (a = a.reverse());
            (b == null ? void 0 : b.filter) != null && (a = a.filter(b.filter));
            (b == null ? void 0 : b.limit) != null && (a = a.limit(b.limit));
            return a.toArray()
        }, "read")
    }

    function i(a, b) {
        return {
            equals: function(c) {
                return {
                    read: function(e) {
                        return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READONLY, function(a) {
                            a = a.where(b).equals(c.length === 1 ? c[0] : c);
                            (e == null ? void 0 : e.order) === "desc" && (a = a.reverse());
                            (e == null ? void 0 : e.filter) != null && (a = a.filter(e.filter));
                            (e == null ? void 0 : e.limit) != null && (a = a.limit(e.limit));
                            return a.toArray()
                        }, "index-equal")
                    }
                }
            },
            keys: function() {
                return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READONLY, function(a) {
                    a = a.orderBy(b);
                    return a.uniqueKeys()
                }, "index-keys")
            },
            read: function(c) {
                return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READONLY, function(a) {
                    a = a.orderBy(b);
                    (c == null ? void 0 : c.order) === "desc" && (a = a.reverse());
                    (c == null ? void 0 : c.filter) != null && (a = a.filter(c.filter));
                    (c == null ? void 0 : c.limit) != null && (a = a.limit(c.limit));
                    return a.toArray()
                }, "index-read")
            }
        }
    }

    function j(a, b) {
        return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READWRITE, function(a) {
            return a.bulkAdd(b).then(function() {})
        }, "write")
    }

    function k(a, b) {
        return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READWRITE, function(a) {
            return a.bulkDelete(b)
        }, "ack")
    }

    function l(a, b) {
        return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READWRITE, function(a) {
            return a.bulkDelete(b)
        }, "delete")
    }

    function m(a) {
        return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READWRITE, function(a) {
            return a.clear().then(function() {})
        }, "clear")
    }

    function n(a) {
        return d("WADbTransactor").persistedQueueTransactor(a, d("MAWTransactionMode").READONLY, function(a) {
            a = a.toCollection();
            return a.primaryKeys()
        }, "keys")
    }
    g.dexieApiForPersistedQueue = a;
    g.persistedQueueRead = h;
    g.persistedQueueIndex = i;
    g.persistedQueueWrite = j;
    g.persistedQueueAck = k;
    g.persistedQueueDelete = l;
    g.persistedQueueClear = m;
    g.persistedQueueKeys = n
}), 98);
__d("EncryptedBackupsUploadQueue", ["EncryptedBackupsUploadEntity", "MAWEBUploadTrackingUtils", "Promise", "WAPersistedQueue", "WAPersistedQueueApi", "WATagsLogger", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to write to ebUploadQueue ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["EB Upload Queue is already initialized"]);
        j = function() {
            return a
        };
        return a
    }
    var k = d("WATagsLogger").TAGS(["EbUploadQueue"]),
        l = null;

    function m() {
        return l == null ? n() : l
    }

    function n() {
        l != null && k.ERROR(j());
        var a = d("WAPersistedQueue").initPersistedQueue("ebUploadQueue", d("WAPersistedQueueApi").dexieApiForPersistedQueue());
        l = a;
        return a
    }

    function a(a) {
        if (a.length === 0) return;
        var e = a.map(function(a) {
            var b = a.attachmentContext,
                c = a.backupDirective,
                e = a.dbMsgType,
                f = a.isOpenEB,
                g = a.legacyAttachmentContext,
                h = a.messageApplication,
                i = a.msgId,
                j = a.originalMsgProtocolId,
                k = a.reportingMeta,
                l = a.senderId,
                m = a.serverTs,
                n = a.sortOrderMs;
            a = a.tags;
            return d("EncryptedBackupsUploadEntity").asEBUploadEntity({
                attachmentContext: b,
                backupDirective: c,
                dbMsgType: e,
                isOpenEB: f,
                legacyAttachmentContext: g,
                msgId: i,
                originalMsgProtocolId: j,
                protobuf: d("EncryptedBackupsUploadEntity").encodeBackupMessage({
                    messageApplication: h,
                    msgId: i,
                    reportingMeta: k,
                    sortOrderMs: n
                }),
                senderId: l,
                serverTs: m,
                sortOrderMs: n,
                tags: a
            })
        });
        a = m();
        c("promiseDone")(a.addAndCommit(e)["catch"](function(a) {
            e.forEach(function(a) {
                d("MAWEBUploadTrackingUtils").removeExternalIdFromUploadQueueStartedCache(a.msgId.externalId)
            });
            k.ERROR(i(), a);
            return (h || (h = b("Promise"))).reject(a)
        }))
    }
    g.logger = k;
    g.ebUploadQueue = m;
    g.initEbUploadQueue = n;
    g.putMsgsToEbUpload = a
}), 98);
__d("MAWCastToMsgrServerMediaType", ["EncryptedBackupsUploadEntity", "MAWDbMedia", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["invalid attachment mediaType: ", " for castMediaAttachmentTypeToServerMediaType method"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["invalid client mediaType: ", " for castClientMediaTypeToServerMediaType method"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["invalid mediaType: ", " for castToMsgrServerMediaType method"]);
        j = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        b === void 0 && (b = !1);
        if (b && a === "image") return "xma";
        switch (a) {
            case "image":
            case "video":
            case "gif":
            case "sticker":
                return a;
            case "document":
                return "file";
            case "ptt":
                return "audio";
            case "xma-image":
                return "xma";
            case "preview":
                return "preview";
            default:
                d("WALogger").ERROR(j(), a);
                return null
        }
    }

    function b(a, b) {
        b === void 0 && (b = !1);
        if (b && a === d("MAWDbMedia").MEDIA_TYPE.IMAGE) return "xma";
        switch (a) {
            case "Image":
                return "image";
            case "Video":
                return "video";
            case "Gif":
                return "gif";
            case "Sticker":
                return "sticker";
            case "DocumentFile":
                return "file";
            case "Ptt":
                return "audio";
            default:
                d("WALogger").ERROR(i(), a);
                return null
        }
    }

    function c(a) {
        switch (a) {
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.IMAGE:
                return "image";
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.VIDEO:
                return "video";
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.GIF:
                return "gif";
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.STICKER:
                return "sticker";
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.DOCUMENT:
                return "file";
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.PTT:
                return "audio";
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.XMA:
                return "xma";
            case d("EncryptedBackupsUploadEntity").AttachmentContextMediaType.MESSENGER_PREVIEW:
                return "preview";
            default:
                d("WALogger").ERROR(h(), a);
                return null
        }
    }
    g.castToMsgrServerMediaType = a;
    g.castClientMediaTypeToServerMediaType = b;
    g.castMediaAttachmentTypeToServerMediaType = c
}), 98);
__d("MAWDbRavenActionTxns", ["MAWBridgeTypesCreators", "MAWDbMsg", "MAWIndexedDb", "MAWMsg", "MAWRavenUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e) {
        return a.messages.where("externalId").equals(b.ravenActionToMsgExternalId).filter(function(a) {
            return a.threadJid === e.jid
        }).first().then(function(f) {
            var g = f == null ? void 0 : f.msgId;
            if (g == null) throw c("err")("Cannot Write Raven Action without ID of Raven Message");
            return h(a, f).then(function(c) {
                var d = babelHelpers["extends"]({
                    msgId: g,
                    threadJid: e.jid
                }, b);
                return a.unrenderedMessages.add(d).then(function(a) {
                    return babelHelpers["extends"]({
                        rowId: a
                    }, d)
                })
            }).then(function(a) {
                d("MAWIndexedDb").afterTransaction({
                    tag: "RavenActionUpdate",
                    value: d("MAWBridgeTypesCreators").createBridgeRavenAction(a)
                });
                return
            })
        })
    }

    function h(a, b) {
        if ((b == null ? void 0 : b.type) !== "Raven") throw c("err")("Cannot Modify Message because Message is not Raven Message");
        var e = [d("MAWMsg").MAWRavenMsgEphemeralMediaState.cast(Number(b.ravenEphemeralMediaState)), d("MAWMsg").MAWRavenMsgEphemeralType.cast(Number(b.ravenEphemeralType))],
            f = e[0];
        e = e[1];
        if (f == null || e == null) throw c("err")("ravenEphemeralMediaStateEnum or ravenEphemeralTypeEnum is null");
        f = d("MAWRavenUtils").getNextRavenMessageEphemeralState(f, e);
        return a.messages.put(babelHelpers["extends"]({}, b, {
            ravenEphemeralMediaState: f
        }))
    }

    function b(a, b, c) {
        c = d("MAWDbMsg").isRavenActionMsgType(c) && (b == null ? void 0 : b.externalId) != null ? [b.externalId] : [];
        return a.messages.where("externalId").anyOf(c).filter(function(a) {
            return a.author === (b == null ? void 0 : b.author) && a.threadJid === (b == null ? void 0 : b.chat)
        }).first()
    }
    g.writeRavenActionMsg = a;
    g.modifyRavenMsgWithActionMsg = h;
    g.maybeGetRavenMsgQueryByProtocolMsgId = b
}), 98);
__d("MAWDbReceiverFetchTxns", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a.receiverFetchInfo.get({
            receiverFetchId: b
        })
    }
    f.maybeGetReceiverFetchInfoFromReceiverFetchId = a
}), 66);
__d("MAWReStoreDb", ["FBLogger", "MAWIndexedDb", "MAWReStoreDbSetup", "asyncToGeneratorRuntime", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a() {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            if (c("gkx")("3577")) try {
                var a = (yield d("MAWReStoreDbSetup").getDB());
                return a
            } catch (a) {
                throw c("FBLogger")("igd_web_on_msgr").blameToPreviousFrame().catching(a).mustfixThrow("Failed to get ReStore DB: %s", arguments[0])
            }
            h == null && (d("MAWIndexedDb").willSetupDB() ? h = d("MAWIndexedDb").getDB().then(function() {
                return d("MAWReStoreDbSetup").getDB()
            }) : h = d("MAWReStoreDbSetup").getDB());
            return h
        });
        return i.apply(this, arguments)
    }

    function e() {
        return d("MAWReStoreDbSetup").shouldUseReStoreDb()
    }
    g.getDB = a;
    g.shouldUseReStoreDb = e
}), 98);