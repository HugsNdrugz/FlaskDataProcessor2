; /*FB_PKG_DELIM*/

__d("LSInsertAdminMessageInClientMessages.nop", ["FBLogger", "I64", "MAWBridgeFireAndForget", "MAWEphemeralMsgAutoResetSystemId", "MAWJids", "MAWMiActOnActThreadReady", "Promise", "WATimeUtils", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    a = function(a, e, f, g, l, m, n) {
        if (l === "change_thread_theme") {
            var o = n.has("theme_emoji") ? j(n.get("theme_emoji")) : void 0,
                p = n.has("theme_name_with_subtitle") ? j(n.get("theme_name_with_subtitle")) : void 0;
            if (p == null) {
                c("FBLogger")("messenger_e2ee_web").mustfix("invalid themeNameWithSubtitle when writing admin message for thread theme customization");
                return (i || (i = b("Promise"))).resolve()
            }
            return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, c) {
                d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForThreadThemeCustomization", {
                    actorFbid: (h || (h = d("I64"))).to_string(g),
                    chatJid: c,
                    serverAuthoritativeTimestampMs: d("WATimeUtils").castToMillisTime(h.to_float(m)),
                    themeEmoji: o,
                    themeNameWithSubtitle: p
                });
                return (i || (i = b("Promise"))).resolve()
            })
        } else if (l === "change_thread_image") return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, c) {
            d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForThreadPhotoCustomization", {
                actorFbid: (h || (h = d("I64"))).to_string(g),
                chatJid: c,
                serverAuthoritativeTimestampMs: d("WATimeUtils").castToMillisTime(h.to_float(m))
            });
            return (i || (i = b("Promise"))).resolve()
        });
        else if (l === "pin_messages_v2") return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, e) {
            c("gkx")("4552") && d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForPinMessage", {
                actorFbid: (h || (h = d("I64"))).to_string(g),
                chatJid: e,
                serverAuthoritativeTimestampMs: d("WATimeUtils").castToMillisTime(h.to_float(m))
            });
            return (i || (i = b("Promise"))).resolve()
        });
        else if (l === "unpin_messages_v2") return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, e) {
            c("gkx")("4552") && d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForUnpinMessage", {
                actorFbid: (h || (h = d("I64"))).to_string(g),
                chatJid: e,
                serverAuthoritativeTimestampMs: d("WATimeUtils").castToMillisTime(h.to_float(m))
            });
            return (i || (i = b("Promise"))).resolve()
        });
        else if (l === "change_thread_icon") {
            var q = n.has("thread_icon") ? j(n.get("thread_icon")) : void 0;
            if (q == null) {
                c("FBLogger")("messenger_e2ee_web").mustfix("invalid thread_icon when writing admin message for thread hotlike customization");
                return (i || (i = b("Promise"))).resolve()
            }
            return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, c) {
                d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForThreadHotlikeCustomization", {
                    actorFbid: (h || (h = d("I64"))).to_string(g),
                    chatJid: c,
                    serverAuthoritativeTimestampMs: d("WATimeUtils").castToMillisTime(h.to_float(m)),
                    threadIcon: q.length === 0 ? "\ud83d\udc4d" : q
                });
                return (i || (i = b("Promise"))).resolve()
            })
        } else if (l === "change_thread_quick_reaction") {
            var r = n.has("thread_quick_reaction_emoji") ? j(n.get("thread_quick_reaction_emoji")) : void 0;
            if (r == null) {
                c("FBLogger")("messenger_e2ee_web").mustfix("invalid reaction when writing admin message for thread quick reaction customization");
                return (i || (i = b("Promise"))).resolve()
            }
            return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, c) {
                d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForThreadHotlikeCustomization", {
                    actorFbid: (h || (h = d("I64"))).to_string(g),
                    chatJid: c,
                    serverAuthoritativeTimestampMs: d("WATimeUtils").castToMillisTime(h.to_float(m)),
                    threadIcon: r.length === 0 ? "\ud83d\udc4d" : r
                });
                return (i || (i = b("Promise"))).resolve()
            })
        } else if (l === "change_thread_nickname") {
            var s = n.has("participant_id") ? j(n.get("participant_id")) : void 0,
                t = n.has("nickname") ? j(n.get("nickname")) : void 0;
            if (s == null || t == null) {
                c("FBLogger")("messenger_e2ee_web").mustfix("invalid params when writing admin message for thread nickname customization");
                return (i || (i = b("Promise"))).resolve()
            }
            return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, c) {
                d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForThreadNicknameCustomization", {
                    actorFbid: (h || (h = d("I64"))).to_string(g),
                    chatJid: c,
                    nickName: t,
                    participantId: s,
                    serverAuthoritativeTimestampMs: d("WATimeUtils").castToMillisTime(h.to_float(m))
                });
                return (i || (i = b("Promise"))).resolve()
            })
        } else if (l === "change_disappearing_setting") return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSInsertAdminMessageInClientMessages.nop", function(a, e) {
            a = n.has("disappearing_setting_time") ? j(n.get("disappearing_setting_time")) : void 0;
            var f = n.has("old_disappearing_setting_time") ? j(n.get("old_disappearing_setting_time")) : void 0,
                g = n.has("disappearing_setting_actor_fbid") ? j(n.get("disappearing_setting_actor_fbid")) : void 0,
                l = n.has("disappearing_setting_is_initial_sync") ? k(n.get("disappearing_setting_is_initial_sync")) === !0 : !1;
            a == null && c("FBLogger")("messenger_e2ee_web").mustfix("[labyrinth][web] settingsTtl missing for admin msg, isInitSync: %s", l.toString());
            var o = g === c("MAWEphemeralMsgAutoResetSystemId"),
                p = parseInt(a, 10);
            g == null && l && c("FBLogger")("messenger_e2ee_web").info("[labyrinth][web] author for ephemeral admin msg is null, ttl is zero: %s", (p === 0).toString());
            if (l) return (i || (i = b("Promise"))).resolve();
            if (l || o) {
                d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForEphemeralSettingsChange", {
                    author: null,
                    chatJid: e,
                    expirationInSec: p,
                    isEphemeralSettingReset: o,
                    isInitSync: l,
                    isTurningOnEphemeralSetting: l,
                    serverTs: d("WATimeUtils").castToUnixTime((h || (h = d("I64"))).to_float(m) / 1e3)
                });
                return (i || (i = b("Promise"))).resolve()
            } else g != null && a != null ? d("MAWBridgeFireAndForget").fireAndForget("backend", "writeAdminMessageForEphemeralSettingsChange", {
                author: d("MAWJids").toUserJid(g),
                chatJid: e,
                expirationInSec: p,
                isEphemeralSettingReset: !1,
                isInitSync: !1,
                isTurningOnEphemeralSetting: f == null || f === "0",
                serverTs: d("WATimeUtils").castToUnixTime((h || (h = d("I64"))).to_float(m) / 1e3)
            }) : c("FBLogger")("messenger_e2ee_web").mustfix("[labyrinth][web] param missing for admin msg, author: %s, settingsTtl: %s, oldSettingsTtl: %s, isInitSync: %s", (g != null).toString(), (a != null).toString(), (f != null).toString(), l.toString());
            return (i || (i = b("Promise"))).resolve()
        });
        return (i || (i = b("Promise"))).resolve()
    };
    var j = function(a) {
            if (a == null) return void 0;
            if (typeof a === "string") return a;
            c("FBLogger")("messenger_e2ee_web").mustfix("Invalid type for string, expected string, but got %s", typeof a);
            return void 0
        },
        k = function(a) {
            if (typeof a === "boolean") return a;
            c("FBLogger")("messenger_e2ee_web").mustfix("Invalid type for boolean, expected boolean, but got %s", typeof a);
            return void 0
        };
    g["default"] = a
}), 98);
__d("LSInsertAdminMessageInClientMessages", ["LSInsertAdminMessageInClientMessages.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.nativeOperation(b("LSInsertAdminMessageInClientMessages.nop"), a[0], a[1], a[2], a[3], a[4])
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxInsertAdminMessageInClientMessagesStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateDisappearingSettingInClientThreadsTable.nop", ["I64", "LSMessagingThreadAttributionType", "MAWBridgeFireAndForget", "MAWBridgeSendAndReceive", "MAWCurrentUser", "MAWEphemeralMsgAutoResetSystemId", "MAWJids", "MAWMessageSendReporter", "MAWMiActOnActThreadReady", "Promise", "ReQL", "WATimeUtils", "asyncToGeneratorRuntime", "gkx", "promiseDone", "qpl", "sendToSentQPLLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f) {
            var g = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.threads).getKeyRange(f)));
            if (g != null) return d("MAWMiActOnActThreadReady").onActThreadReady(a, f, "LSUpdateDisappearingSettingInClientThreadsTable.nop", function(a, e) {
                a = {
                    ephemeralExpirationInSec: (i || (i = d("I64"))).to_int32((a = g.disappearingSettingTtl) != null ? a : (i || (i = d("I64"))).zero),
                    ephemeralLastUpdatedOrSetTimestamp: d("WATimeUtils").castMilliSecondsToUnixTime(i.to_float((a = g.disappearingSettingUpdatedTs) != null ? a : (i || (i = d("I64"))).zero))
                };
                d("MAWBridgeFireAndForget").fireAndForget("backend", "setEphemeralSettingCache", {
                    jid: e,
                    settings: a
                });
                if (g.disappearingSettingUpdatedBy != null) {
                    var f = (i || (i = d("I64"))).to_string(g.disappearingSettingUpdatedBy),
                        j = f === c("MAWEphemeralMsgAutoResetSystemId");
                    if (f === d("MAWCurrentUser").getID() || j)
                        if (c("gkx")("7854")) {
                            var k = d("sendToSentQPLLogger").markSendToSentStartWithAnnotation(g, {
                                isEphemeralSetting: !0
                            }, c("LSMessagingThreadAttributionType").UNKNOWN);
                            c("promiseDone")(d("MAWMessageSendReporter").MAWMessageSendReporter(null, d("MAWBridgeSendAndReceive").sendAndReceive("backend", "setEphemeralSettingsFromFrontend", {
                                chatJid: e,
                                ephemeralExpirationInSec: a.ephemeralExpirationInSec,
                                ephemeralLastUpdatedOrSetTimestamp: a.ephemeralLastUpdatedOrSetTimestamp,
                                isEphemeralSettingReset: j,
                                s2sInstanceKey: k
                            }), {
                                qplEventType: c("qpl")._(25313175, "1551"),
                                qplInstanceKey: k
                            }))
                        } else {
                            var l = d("sendToSentQPLLogger").markSendToSentStartWithAnnotation(g, {
                                isEphemeralSetting: !0
                            }, c("LSMessagingThreadAttributionType").UNKNOWN);
                            c("promiseDone")(d("MAWBridgeSendAndReceive").sendAndReceive("backend", "setEphemeralSettingsFromFrontend", {
                                chatJid: e,
                                ephemeralExpirationInSec: a.ephemeralExpirationInSec,
                                ephemeralLastUpdatedOrSetTimestamp: a.ephemeralLastUpdatedOrSetTimestamp,
                                isEphemeralSettingReset: j,
                                s2sInstanceKey: l
                            }).then(function() {
                                d("sendToSentQPLLogger").markSendToSentSuccess(l)
                            })["catch"](function(a) {
                                d("sendToSentQPLLogger").markSendToSentFail(l, "failed_to_send_empemeral_settings", a)
                            }))
                        }
                    else d("MAWBridgeFireAndForget").fireAndForget("backend", "setEphemeralSettingsFromMI", {
                        author: d("MAWJids").toUserJid(f),
                        chatJid: e,
                        ephemeralExpirationInSec: a.ephemeralExpirationInSec,
                        ephemeralLastUpdatedOrSetTimestamp: a.ephemeralLastUpdatedOrSetTimestamp,
                        fromWAI: !1,
                        isEphemeralSettingReset: !1,
                        serverTs: a.ephemeralLastUpdatedOrSetTimestamp
                    })
                }
                return (h || (h = b("Promise"))).resolve()
            })
        });

        function e(b, c, d) {
            return a.apply(this, arguments)
        }
        return e
    }();
    g["default"] = a
}), 98);
__d("LSUpdateDisappearingSettingInClientThreadsTable", ["LSUpdateDisappearingSettingInClientThreadsTable.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.nativeOperation(b("LSUpdateDisappearingSettingInClientThreadsTable.nop"), a[0])
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxUpdateDisappearingSettingInClientThreadsTableStoredProcedure";
    e.exports = a
}), null);