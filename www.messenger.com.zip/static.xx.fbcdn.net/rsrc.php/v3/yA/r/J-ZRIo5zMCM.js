; /*FB_PKG_DELIM*/

__d("LSUpdateEventStartAndEndTime", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    eventStartTimestampMs: a[1],
                    eventEndTimestampMs: a[2]
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateEventStartAndEndTimeStoredProcedure";
    e.exports = a
}), null);
__d("LSClearEventStartAndEndTime", ["LSUpdateEventStartAndEndTime"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(b) {
                return c.islc(c.db.table(201).fetch([
                    [
                        [a[0]]
                    ]
                ]), 0, c.i64.to_float(c.i64.cast([0, 1]))).next().then(function(a, b) {
                    var c = a.done;
                    a = a.value;
                    return c ? d[0] = void 0 : (b = a.item, d[0] = b.threadId)
                })
            }, function(a) {
                return c.i64.neq(d[0], void 0) ? c.storedProcedure(b("LSUpdateEventStartAndEndTime"), d[0], void 0, void 0) : c.resolve()
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxClearEventStartAndEndTimeStoredProcedure";
    e.exports = a
}), null);
__d("LSClearAllCmEventStartAndEndTimes", ["LSClearEventStartAndEndTime"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(a) {
            return c.forEach(c.db.table(201).fetch(), function(a) {
                a = a.item;
                return c.storedProcedure(b("LSClearEventStartAndEndTime"), a.eventId)
            })
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxClearAllCmEventStartAndEndTimesStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteAllCmFbEventData", ["LSArrayGetObjectAt", "LSClearAllCmEventStartAndEndTimes"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(a) {
            return c.sequence([function(a) {
                return c.storedProcedure(b("LSClearAllCmEventStartAndEndTimes"))
            }, function(a) {
                return d[0] = c.createArray(), c.forEach(c.db.table(201).fetch(), function(a) {
                    a = a.item;
                    return d[2] = (d[0].push(a.eventId), d[0])
                })
            }, function(a) {
                return c.forEach(c.db.table(202).fetch(), function(a) {
                    a = a.item;
                    return d[2] = (d[0].push(a.eventId), d[0])
                })
            }, function(a) {
                return c.forEach(c.db.table(238).fetch(), function(a) {
                    a = a.item;
                    return d[2] = (d[0].push(a.eventId), d[0])
                })
            }, function(a) {
                return c.sequence([function(a) {
                    return d[2] = c.createArray(), d[3] = c.i64.of_int32(d[0].length), c.i64.gt(d[3], c.i64.cast([0, 0])) ? c.loopAsync(d[3], function(a) {
                        return d[5] = a, c.sequence([function(a) {
                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[0], d[5]).then(function(a) {
                                return a = a, d[6] = a[0], d[7] = a[1], a
                            })
                        }, function(a) {
                            return d[8] = (d[2].push(c.i64.to_string(d[6])), d[2])
                        }])
                    }) : c.resolve()
                }, function(a) {
                    return d[4] = d[2].join(","), d[1] = d[4]
                }])
            }, function(a) {
                return c.forEach(c.filter(c.db.table(200).fetch(), function(a) {
                    return d[0].some(function(b) {
                        return c.i64.eq(a.eventId, b)
                    })
                }), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return c.forEach(c.db.table(202).fetch(), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return c.forEach(c.db.table(201).fetch(), function(a) {
                    return a["delete"]()
                })
            }, function(a) {
                return c.forEach(c.db.table(238).fetch(), function(a) {
                    return a["delete"]()
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsDeleteAllCmFbEventDataStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteThenInsertCmChannelEvent", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(201).put({
                eventId: a[0],
                threadId: a[1]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsDeleteThenInsertCmChannelEventStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteThenInsertCommunityEventsV2", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.resolve(c)
    }
    a.__sproc_name__ = "LSOmnistoreSettingsDeleteThenInsertCommunityEventsV2StoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteThenInsertFbEvent", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(200).put({
                eventId: a[0],
                eventName: a[3],
                eventPictureUrl: a[5],
                numGoingUsers: a[8],
                numInterestedUsers: a[9],
                startTimeMs: a[1],
                endTimeMs: a[2],
                locationName: a[4],
                eventPictureUrlFallback: a[6],
                eventPictureUrlExpirationTimestampMs: a[7],
                rsvpStatus: a[10]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOmnistoreSettingsDeleteThenInsertFbEventStoredProcedure";
    e.exports = a
}), null);
__d("LSLazyMessageForcedFetch", ["LSIssueNewTask"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.db.table(12).fetch([
                [
                    [a[0]]
                ], "messageId"
            ]).next().then(function(e, f) {
                var g = e.done;
                e = e.value;
                return g ? 0 : (f = e.item, c.sequence([function(a) {
                    return d[5] = f.threadKey, c.db.table(9).fetch([
                        [
                            [d[5]]
                        ]
                    ]).next().then(function(b, e) {
                        var a = b.done;
                        b = b.value;
                        return a ? d[0] = c.i64.cast([0, 1]) : (e = b.item, d[7] = e.syncGroup, c.i64.neq(d[7], void 0) ? d[6] = d[7] : d[6] = c.i64.cast([0, 1]), d[0] = d[6])
                    })
                }, function(e) {
                    return d[2] = new c.Map(), d[2].set("thread_key", d[5]), d[2].set("message_id", a[0]), d[2].set("sync_group", d[0]), d[3] = d[2].get("thread_key"), d[2], d[4] = c.toJSON(d[2]), c.storedProcedure(b("LSIssueNewTask"), c.i64.to_string(d[3]), c.i64.cast([0, 19]), d[4], void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]), void 0, void 0, c.i64.cast([0, 0]), c.i64.cast([0, 0]))
                }]))
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxLazyMessageForcedFetchStoredProcedure";
    e.exports = a
}), null);
__d("LSRefreshEventXMAsOnRSVP", ["LSLazyMessageForcedFetch"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.forEach(c.filter(c.db.table(16).fetch([
                [
                    [a[1]]
                ]
            ]), function(b) {
                return a[0] === b.attachmentFbid && c.i64.eq(a[1], b.threadKey)
            }), function(a) {
                a = a.item;
                return c.storedProcedure(b("LSLazyMessageForcedFetch"), a.messageId, a.threadKey)
            })
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxRefreshEventXMAsOnRSVPStoredProcedure";
    e.exports = a
}), null);