; /*FB_PKG_DELIM*/

__d("LSDeleteBanners", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.filter(b.db.table(118).fetch(), function(c) {
                return b.i64.eq(b.i64.cast([0, 0]), b.i64.cast([0, 0])) && b.i64.eq(c.bannerId, a[0])
            }), function(a) {
                return a["delete"]()
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSInThreadBannerDeleteBannersStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteBannersByIds", ["LSArrayGetObjectAt"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return c.sequence([function(e) {
                    return d[1] = c.createArray(), d[2] = c.i64.of_int32(a[1].length), c.i64.gt(d[2], c.i64.cast([0, 0])) ? c.loopAsync(d[2], function(e) {
                        return d[4] = e, c.sequence([function(e) {
                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), a[1], d[4]).then(function(a) {
                                return a = a, d[5] = a[0], d[6] = a[1], a
                            })
                        }, function(a) {
                            return d[7] = (d[1].push(c.i64.to_string(d[5])), d[1])
                        }])
                    }) : c.resolve()
                }, function(a) {
                    return d[3] = d[1].join(","), d[0] = d[3]
                }])
            }, function(b) {
                return c.forEach(c.filter(c.db.table(118).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(b) {
                    return c.i64.eq(b.threadKey, a[0]) && a[1].some(function(a) {
                        return c.i64.eq(b.bannerId, a)
                    })
                }), function(a) {
                    return a["delete"]()
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSInThreadBannerDeleteBannersByIdsStoredProcedure";
    e.exports = a
}), null);
__d("LSDeleteThenInsertProactiveWarningSettings", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]).next().then(function(c, d) {
                d = c.done;
                c = c.value;
                return d ? 0 : (c.item, b.db.table(183).put({
                    threadKey: a[0],
                    nextCheckTimestampMs: a[2],
                    token: a[3],
                    tag: a[4],
                    storyLocation: a[5],
                    entryPoint: a[6],
                    context: a[7],
                    suspectId: a[1]
                }))
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSProactiveWarningsDeleteThenInsertProactiveWarningSettingsStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateOrInsertOhaiGatewayKeyConfigs", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(313).put({
                keyId: a[0],
                publicKey: a[1],
                kemId: a[2],
                kdfId: a[3],
                aeadId: a[4],
                expirationDate: a[5],
                lastUpdatedTime: a[6]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSOhaiUpdateOrInsertOhaiGatewayKeyConfigsStoredProcedure";
    e.exports = a
}), null);
__d("LSUpsertContextualProfileV1", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return b.i64.eq(a[5], b.i64.cast([0, 0])) ? c[0] = void 0 : c[0] = a[5], b.db.table(216).put({
                ownerId: a[0],
                associatedEntityId: a[1],
                profilePictureUrl: a[2],
                profilePictureFallbackUrl: a[4],
                profilePictureUrlExpirationTimestampMs: c[0],
                profileName: a[3]
            })
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSContactUpsertContextualProfileV1StoredProcedure";
    e.exports = a
}), null);