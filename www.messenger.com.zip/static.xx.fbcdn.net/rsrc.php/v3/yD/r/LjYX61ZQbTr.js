; /*FB_PKG_DELIM*/

__d("WAAbPropsHelpers", ["WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["maybeUpdateExpoKeys: config_expo_key ", " changed"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["maybeUpdateExpoKeys: deleting config_expo_key ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["maybeUpdatePropValues: deleting config ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["parseValue: unsure how to read ", ""]);
        k = function() {
            return a
        };
        return a
    }
    var l = 86400,
        m = 600,
        n = 604800;

    function a(a) {
        return a == null ? l : Math.max(m, Math.min(n, a))
    }

    function o(a) {
        var b = [];
        Object.keys(a).forEach(function(c) {
            var d = a[c],
                e = d[0];
            d[1];
            d = d[2];
            if (typeof e !== "number") return;
            b.push({
                configName: c,
                configCode: e,
                configDefault: d
            })
        });
        return b
    }

    function b(a, b) {
        a = a[b][0];
        return typeof a === "number" ? a : null
    }

    function p(a, b) {
        switch (typeof b) {
            case "boolean":
                return a === "1";
            case "number":
                return parseFloat(a);
            case "string":
                return a;
            default:
                d("WALogger").WARN(k(), a);
                return null
        }
    }

    function c(a, b) {
        var c = new Map();
        b.forEach(function(a) {
            var b = a.configCode,
                d = a.configValue;
            a = a.configExpoKey;
            c.set(b, {
                configValue: d,
                configExpoKey: a
            })
        });
        var d = {},
            e = {};
        o(a).forEach(function(a) {
            var b = a.configName,
                f = a.configCode;
            a = a.configDefault;
            var g = c.get(f);
            if (g == null) return;
            var h = g.configValue;
            g = g.configExpoKey;
            h = p(h, a);
            h != null && (d[b] = h);
            e[f] = g != null ? g : null
        });
        return {
            values: d,
            expoKeys: e
        }
    }

    function e(a, b, c) {
        var e = babelHelpers["extends"]({}, b, a),
            f = {};
        Object.keys(e).forEach(function(a) {
            if (c[a] == null) {
                d("WALogger").LOG(j(), a);
                return
            }
            f[a] = e[a]
        });
        return f
    }

    function f(a, b, c) {
        var e = babelHelpers["extends"]({}, b, a),
            f = {};
        a = o(c).map(function(a) {
            return a.configCode
        });
        var g = new Set(a),
            j = new Set();
        Object.keys(e).forEach(function(a) {
            a = parseInt(a, 10);
            var c = b ? b[a] : null;
            !g.has(a) ? (d("WALogger").LOG(i(), a), c != null && c.trim() && j.add(c)) : (e[a] !== c && (d("WALogger").LOG(h(), a), c != null && c.trim() && j.add(c)), f[a] = e[a])
        });
        return {
            propExpoKeys: f,
            expoKeysToDelete: j
        }
    }

    function q(a, b) {
        if (b == null) return;
        var c = b;
        a.forEach(function(a) {
            c["delete"](a)
        });
        if (c.size === 0) return;
        return {
            internalExpoKeys: c,
            expoKeyStr: Array.from(c).join(",")
        }
    }
    g.maybeUpdateRefresh = a;
    g.asAbList = o;
    g.asAbCode = b;
    g.parseAbProps = c;
    g.maybeUpdatePropValues = e;
    g.maybeUpdateExpoKeys = f;
    g.maybeUpdateInternalExpoKeys = q
}), 98);
__d("WAAbProps", ["WAAbPropsHelpers", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;

    function i(a) {
        if (h) return h;
        else throw c("err")("abProps::" + a + " called before startAbProps")
    }

    function a(a, b) {
        h == null && (h = {
            config: b,
            db: a
        })
    }

    function b() {
        return i("getHash").db.getHash()
    }

    function e() {
        return i("getRefreshSecs").db.getRefreshSecs().then(function(a) {
            return d("WAAbPropsHelpers").maybeUpdateRefresh(a)
        })
    }

    function f() {
        return i("getConfig").config
    }

    function j() {
        return i("getAbProps").db.getAbProps()
    }

    function k(a) {
        return i("getAbProps").db.setAbProps(a)
    }
    g.startAbProps = a;
    g.getHash = b;
    g.getRefreshSecs = e;
    g.getConfig = f;
    g.getAbProps = j;
    g.setAbProps = k
}), 98);
__d("WASmaxInAbPropsIQErrorBadRequestMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "bad-request");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 400);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorBadRequestMixin = a
}), 98);
__d("WASmaxInAbPropsIQErrorFeatureNotImplementedMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "feature-not-implemented");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 501);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorFeatureNotImplementedMixin = a
}), 98);
__d("WASmaxInAbPropsIQErrorBadRequestOrFeatureNotImplementedMixinGroup", ["WAResultOrError", "WASmaxInAbPropsIQErrorBadRequestMixin", "WASmaxInAbPropsIQErrorFeatureNotImplementedMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInAbPropsIQErrorBadRequestMixin").parseIQErrorBadRequestMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "IQErrorBadRequest",
            value: b.value
        });
        var c = d("WASmaxInAbPropsIQErrorFeatureNotImplementedMixin").parseIQErrorFeatureNotImplementedMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "IQErrorFeatureNotImplemented",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["IQErrorBadRequest", "IQErrorFeatureNotImplemented"], [b, c])
    }
    g.parseIQErrorBadRequestOrFeatureNotImplementedMixinGroup = a
}), 98);
__d("WASmaxInAbPropsIQErrorResponseMixin", ["WAResultOrError", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!b.success) return b;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "type", "error");
        return !c.success ? c : d("WAResultOrError").makeResult({
            type: c.value
        })
    }
    g.parseIQErrorResponseMixin = a
}), 98);
__d("WASmaxInAbPropsGetExperimentConfigResponseErrorNoRetry", ["WAResultOrError", "WASmaxInAbPropsIQErrorBadRequestOrFeatureNotImplementedMixinGroup", "WASmaxInAbPropsIQErrorResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInAbPropsIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInAbPropsIQErrorBadRequestOrFeatureNotImplementedMixinGroup").parseIQErrorBadRequestOrFeatureNotImplementedMixinGroup(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorIQErrorBadRequestOrFeatureNotImplementedMixinGroup: b.value
        }))
    }
    g.parseGetExperimentConfigResponseErrorNoRetry = a
}), 98);
__d("WASmaxInAbPropsIQErrorInternalServerErrorMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "internal-server-error");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 500);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorInternalServerErrorMixin = a
}), 98);
__d("WASmaxInAbPropsGetExperimentConfigResponseErrorRetry", ["WAResultOrError", "WASmaxInAbPropsIQErrorInternalServerErrorMixin", "WASmaxInAbPropsIQErrorResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        c = d("WASmaxInAbPropsIQErrorInternalServerErrorMixin").parseIQErrorInternalServerErrorMixin(c.value);
        if (!c.success) return c;
        a = d("WASmaxInAbPropsIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            errorIQErrorInternalServerErrorMixin: c.value
        }, a.value))
    }
    g.parseGetExperimentConfigResponseErrorRetry = a
}), 98);
__d("WASmaxInAbPropsExperimentConfigMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "prop");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "config_code", 1, void 0);
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").attrString(a, "config_value");
        if (!c.success) return c;
        a = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, a, "config_expo_key", 0, void 0);
        return !a.success ? a : d("WAResultOrError").makeResult({
            configCode: b.value,
            configValue: c.value,
            configExpoKey: a.value
        })
    }
    g.parseExperimentConfigMixin = a
}), 98);
__d("WASmaxInAbPropsSamplingConfigMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "prop");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "event_code", 1, void 0);
        if (!b.success) return b;
        a = d("WASmaxParseUtils").attrIntRange(a, "sampling_weight", -1e4, 1e4);
        return !a.success ? a : d("WAResultOrError").makeResult({
            eventCode: b.value,
            samplingWeight: a.value
        })
    }
    g.parseSamplingConfigMixin = a
}), 98);
__d("WASmaxInAbPropsExperimentOrSamplingConfigMixinGroup", ["WAResultOrError", "WASmaxInAbPropsExperimentConfigMixin", "WASmaxInAbPropsSamplingConfigMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInAbPropsExperimentConfigMixin").parseExperimentConfigMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "ExperimentConfig",
            value: b.value
        });
        var c = d("WASmaxInAbPropsSamplingConfigMixin").parseSamplingConfigMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "SamplingConfig",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["ExperimentConfig", "SamplingConfig"], [b, c])
    }
    g.parseExperimentOrSamplingConfigMixinGroup = a
}), 98);
__d("WASmaxInAbPropsIQResultResponseMixin", ["WAResultOrError", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!b.success) return b;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "type", "result");
        return !c.success ? c : d("WAResultOrError").makeResult({
            type: c.value
        })
    }
    g.parseIQResultResponseMixin = a
}), 98);
__d("WASmaxInAbPropsGetExperimentConfigResponseSuccess", ["WAResultOrError", "WASmaxInAbPropsExperimentOrSamplingConfigMixinGroup", "WASmaxInAbPropsIQResultResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "prop");
        if (!b.success) return b;
        b = d("WASmaxInAbPropsExperimentOrSamplingConfigMixinGroup").parseExperimentOrSamplingConfigMixinGroup(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            experimentOrSamplingConfigMixinGroup: b.value
        })
    }

    function i(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "erid");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentBytesRange(a, 1, 100);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "props");
        if (!c.success) return c;
        var e = d("WASmaxParseUtils").optionalChildWithTag(a, "erid", i);
        if (!e.success) return e;
        var f = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, c.value, "protocol", "1");
        if (!f.success) return f;
        var g = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrString, c.value, "ab_key");
        if (!g.success) return g;
        var j = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrString, c.value, "hash");
        if (!j.success) return j;
        var k = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, c.value, "refresh", 0, void 0);
        if (!k.success) return k;
        var l = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, c.value, "refresh_id", 0, void 0);
        if (!l.success) return l;
        a = d("WASmaxInAbPropsIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxParseUtils").mapChildrenWithTag(c.value, "prop", 0, Infinity, h);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            propsProtocol: f.value,
            propsAbKey: g.value,
            propsHash: j.value,
            propsRefresh: k.value,
            propsRefreshId: l.value
        }, a.value, {
            erid: e.value,
            propsProp: b.value
        }))
    }
    g.parseGetExperimentConfigResponseSuccessPropsProp = h;
    g.parseGetExperimentConfigResponseSuccessErid = i;
    g.parseGetExperimentConfigResponseSuccess = a
}), 98);
__d("WASmaxAttrs", ["WAWap"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        if (b == null) return d("WAWap").DROP_ATTR;
        else return a(b)
    }

    function b(a, b) {
        if (b) return a;
        else return d("WAWap").DROP_ATTR
    }
    g.OPTIONAL = a;
    g.OPTIONAL_LITERAL = b
}), 98);
__d("WASmaxOutAbPropsBaseIQGetRequestMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("iq", {
            id: d("WAWap").generateId(),
            type: "get"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBaseIQGetRequestMixin = a
}), 98);
__d("WASmaxOutAbPropsGetExperimentConfigRequest", ["WASmaxAttrs", "WASmaxJsx", "WASmaxOutAbPropsBaseIQGetRequestMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = a.propsHash;
        a = d("WASmaxOutAbPropsBaseIQGetRequestMixin").mergeBaseIQGetRequestMixin(d("WASmaxJsx").smax("iq", {
            xmlns: "abt",
            to: d("WAWap").S_WHATSAPP_NET
        }, d("WASmaxJsx").smax("props", {
            protocol: "1",
            hash: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        })));
        return a
    }
    g.makeGetExperimentConfigRequest = a
}), 98);
__d("WASmaxAbPropsGetExperimentConfigRPC", ["WAComms", "WASmaxInAbPropsGetExperimentConfigResponseErrorNoRetry", "WASmaxInAbPropsGetExperimentConfigResponseErrorRetry", "WASmaxInAbPropsGetExperimentConfigResponseSuccess", "WASmaxOutAbPropsGetExperimentConfigRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h, i;
        return b("regeneratorRuntime").async(function(j) {
            while (1) switch (j.prev = j.next) {
                case 0:
                    e = d("WASmaxOutAbPropsGetExperimentConfigRequest").makeGetExperimentConfigRequest(a);
                    j.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = j.sent;
                    g = d("WASmaxInAbPropsGetExperimentConfigResponseSuccess").parseGetExperimentConfigResponseSuccess(f, e);
                    if (!g.success) {
                        j.next = 7;
                        break
                    }
                    return j.abrupt("return", {
                        name: "GetExperimentConfigResponseSuccess",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInAbPropsGetExperimentConfigResponseErrorNoRetry").parseGetExperimentConfigResponseErrorNoRetry(f, e);
                    if (!h.success) {
                        j.next = 10;
                        break
                    }
                    return j.abrupt("return", {
                        name: "GetExperimentConfigResponseErrorNoRetry",
                        value: h.value
                    });
                case 10:
                    i = d("WASmaxInAbPropsGetExperimentConfigResponseErrorRetry").parseGetExperimentConfigResponseErrorRetry(f, e);
                    if (!i.success) {
                        j.next = 13;
                        break
                    }
                    return j.abrupt("return", {
                        name: "GetExperimentConfigResponseErrorRetry",
                        value: i.value
                    });
                case 13:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("GetExperimentConfig", {
                        Success: g,
                        ErrorNoRetry: h,
                        ErrorRetry: i
                    }));
                case 14:
                case "end":
                    return j.stop()
            }
        }, null, this)
    }
    g.sendGetExperimentConfigRPC = a
}), 98);
__d("WAGetAbPropsProtocol", ["WALogger", "WAResultOrError", "WASmaxAbPropsGetExperimentConfigRPC", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getAbPropsProtocol failed ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        var c, e, f, g, j, k, l, m, n, o, p;
        return b("regeneratorRuntime").async(function(q) {
            while (1) switch (q.prev = q.next) {
                case 0:
                    q.next = 2;
                    return b("regeneratorRuntime").awrap(d("WASmaxAbPropsGetExperimentConfigRPC").sendGetExperimentConfigRPC({
                        propsHash: a
                    }));
                case 2:
                    c = q.sent;
                    if (!(c.name === "GetExperimentConfigResponseSuccess")) {
                        q.next = 7;
                        break
                    }
                    e = c.value, f = e.propsAbKey, g = e.propsHash, j = e.propsRefresh, k = e.propsRefreshId, l = e.propsProp, m = e.erid;
                    n = i(l), o = n.newProps, p = n.samplingConfigs;
                    return q.abrupt("return", d("WAResultOrError").makeResult({
                        abKey: f,
                        hash: g,
                        refresh: j,
                        refreshId: k,
                        props: o,
                        samplingConfigs: p,
                        erid: m == null ? void 0 : m.elementValue
                    }));
                case 7:
                    d("WALogger").WARN(h(), c.value);
                    return q.abrupt("return", d("WAResultOrError").makeError());
                case 9:
                case "end":
                    return q.stop()
            }
        }, null, this)
    }

    function i(a) {
        var b = [],
            c = [];
        a.forEach(function(a) {
            a = a.experimentOrSamplingConfigMixinGroup;
            if (a.name === "ExperimentConfig") {
                var d;
                b.push({
                    configCode: a.value.configCode,
                    configValue: a.value.configValue,
                    configExpoKey: (d = a.value.configExpoKey) == null ? void 0 : d.toString()
                })
            } else a.name === "SamplingConfig" && c.push({
                eventCode: a.value.eventCode,
                samplingWeight: a.value.samplingWeight
            })
        });
        return {
            newProps: b,
            samplingConfigs: c
        }
    }
    g.getAbPropsProtocol = a
}), 98);
__d("WAAbPropsSync", ["WAAbProps", "WAAbPropsHelpers", "WAGetAbPropsProtocol", "WALogger", "WAPromiseManagement", "WAResultOrError", "WATimeUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAAbProps.update: updating ab configs"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAAbProps.update: detected no hash"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["syncAbProps: detected no hash"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["fetchAbProps failed"]);
        k = function() {
            return a
        };
        return a
    }
    c = d("WAPromiseManagement").cacheWhilePending(function() {
        return "abProps"
    }, a);

    function a(a) {
        var b = a.sendHash;
        b = b === void 0 ? !0 : b;
        var c = a.eventFlow;
        c == null ? void 0 : c.addPoint("sync_ab_props", {
            bool: {
                sendHash: b
            }
        });
        return b == null || b === !1 ? l(null, c) : d("WAAbProps").getHash().then(function(a) {
            return l(a, c)
        })
    }
    e = a;

    function l(a, c) {
        var e, f, g, h, i, l, n, o, p;
        return b("regeneratorRuntime").async(function(q) {
            while (1) switch (q.prev = q.next) {
                case 0:
                    c == null ? void 0 : c.addPoint("fetch_ab_props");
                    q.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAGetAbPropsProtocol").getAbPropsProtocol(a));
                case 3:
                    e = q.sent;
                    if (e.success) {
                        q.next = 8;
                        break
                    }
                    d("WALogger").ERROR(k());
                    q.next = 15;
                    break;
                case 8:
                    f = e.value, g = f.abKey, h = f.hash, i = f.refresh, l = f.props;
                    n = d("WAAbPropsHelpers").parseAbProps(d("WAAbProps").getConfig(), l);
                    c == null ? void 0 : c.addPoint("save_ab_props");
                    q.next = 13;
                    return b("regeneratorRuntime").awrap(m(g, h, i, n));
                case 13:
                    o = q.sent, o.success === !1 && (o.error, d("WALogger").LOG(j()));
                case 15:
                    q.next = 17;
                    return b("regeneratorRuntime").awrap(d("WAAbProps").getRefreshSecs());
                case 17:
                    p = q.sent;
                    return q.abrupt("return", {
                        seconds: p
                    });
                case 19:
                case "end":
                    return q.stop()
            }
        }, null, this)
    }

    function m(a, c, e, f) {
        var g, j, k, l, m, n, o, p, q, r, s, t, u;
        return b("regeneratorRuntime").async(function(v) {
            while (1) switch (v.prev = v.next) {
                case 0:
                    v.next = 2;
                    return b("regeneratorRuntime").awrap(d("WAAbProps").getAbProps());
                case 2:
                    k = v.sent;
                    l = {
                        abKey: (g = a) != null ? g : k.abKey,
                        hash: (j = c) != null ? j : k.hash,
                        refresh: d("WAAbPropsHelpers").maybeUpdateRefresh(e),
                        lastSyncTime: d("WATimeUtils").unixTime(),
                        propValues: k.propValues,
                        propExpoKeys: k.propExpoKeys,
                        internalExpoKeys: k.internalExpoKeys,
                        expoKeyStr: k.expoKeyStr
                    };
                    if (!(c == null)) {
                        v.next = 9;
                        break
                    }
                    v.next = 7;
                    return b("regeneratorRuntime").awrap(d("WAAbProps").setAbProps(l));
                case 7:
                    d("WALogger").LOG(i());
                    return v.abrupt("return", d("WAResultOrError").makeError("noHash"));
                case 9:
                    d("WALogger").LOG(h());
                    m = f.values, n = f.expoKeys;
                    o = d("WAAbPropsHelpers").maybeUpdatePropValues(m, k.propValues, d("WAAbProps").getConfig());
                    p = d("WAAbPropsHelpers").maybeUpdateExpoKeys(n, k.propExpoKeys, d("WAAbProps").getConfig()), q = p.propExpoKeys, r = p.expoKeysToDelete;
                    u = d("WAAbPropsHelpers").maybeUpdateInternalExpoKeys(r, k.internalExpoKeys);
                    u != null && (s = u.internalExpoKeys, t = u.expoKeyStr);
                    v.next = 17;
                    return b("regeneratorRuntime").awrap(d("WAAbProps").setAbProps(babelHelpers["extends"]({}, l, {
                        propValues: o,
                        propExpoKeys: q,
                        internalExpoKeys: s,
                        expoKeyStr: t
                    })));
                case 17:
                    return v.abrupt("return", d("WAResultOrError").makeResult());
                case 18:
                case "end":
                    return v.stop()
            }
        }, null, this)
    }
    g.syncAbProps = c;
    g.syncAbPropsDebug = e
}), 98);
__d("WAParsableWapNode", ["WABinary", "WAJids", "WALogger", "WALongInt", "WAParsableXmlNode", "WASignalKeys", "WATimeUtils", "WAWap", "WAWapJid", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["ParsableWapNode: attrFromJid() is called with ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["ParsableWapNode: attrFromJid() is called with ", ""]);
        i = function() {
            return a
        };
        return a
    }
    var j = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a(a, c) {
            var d;
            d = b.call(this, "XmppParsingFailure: " + a + ": " + c) || this;
            d.name = "XmppParsingFailure";
            d.parser = a;
            d.reason = c;
            return d
        }
        var c = a.prototype;
        c.toString = function() {
            return "XmppParsingFailure: " + this.parser + ": " + this.reason
        };
        return a
    }(babelHelpers.wrapNativeSuper(Error));
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c) {
            return a.call(this, b, c) || this
        }
        var e = b.prototype;
        e.assertFromServer = function() {
            var a = this.attrString("from");
            a !== d("WAJids").WA_SERVER_JID_SUFFIX && this["throw"]('to have "from"="s.whatsapp.net", but instead has "' + a + '"')
        };
        e.attrUserJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            return c.userJid == null ? this["throw"]('to have "' + a + '"={UserJid}, but instead has "' + b + '"') : c.userJid
        };
        e.attrPhoneUserJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            return c.jidType === "phoneUser" ? c.userJid : this["throw"]('to have "' + a + '"={PhoneUserJid}, but instead has "' + b + '"')
        };
        e.attrLidUserJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            return c.jidType === "lidUser" ? c.userJid : this["throw"]('to have "' + a + '"={LidUserJid}, but instead has "' + b + '"')
        };
        e.maybeAttrUserJid = function(a) {
            return this.hasAttr(a) ? this.attrUserJid(a) : null
        };
        e.maybeAttrPhoneUserJid = function(a) {
            return this.hasAttr(a) ? this.attrPhoneUserJid(a) : null
        };
        e.maybeAttrLidUserJid = function(a) {
            return this.hasAttr(a) ? this.attrLidUserJid(a) : null
        };
        e.attrGroupJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            return c.groupJid == null ? this["throw"]('to have "' + a + '"={GroupJid}, but instead has "' + b + '"') : c.groupJid
        };
        e.maybeAttrGroupJid = function(a) {
            return this.hasAttr(a) ? this.attrGroupJid(a) : null
        };
        e.attrChatJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            if (c.userJid != null) return c.userJid;
            return c.groupJid != null ? c.groupJid : this["throw"]('to have "' + a + '"={ChatJid}, but instead has "' + b + '"')
        };
        e.attrPhoneChatJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            if (c.jidType === "phoneUser") return c.userJid;
            else if (c.jidType === "group") return c.groupJid;
            else return this["throw"]('to have "' + a + '"={ChatJid}, but instead has "' + b + '"')
        };
        e.attrDeviceJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            if (c.deviceJid != null) return c.deviceJid;
            if (c.userJid != null) return d("WAJids").defaultDeviceJidForUser(c.userJid);
            if (c.hostedDeviceJid != null) return c.hostedDeviceJid;
            return c.hostedLidDeviceJid != null ? c.hostedLidDeviceJid : this["throw"]('to have "' + a + '"={DeviceJid}, but instead has "' + b + '"')
        };
        e.attrPhoneDeviceJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            if (c.jidType === "phoneDevice") return c.deviceJid;
            return c.jidType === "phoneUser" ? d("WAJids").defaultPhoneDeviceJidForUser(c.userJid) : this["throw"]('to have "' + a + '"={PhoneDeviceJid}, but instead has "' + b + '"')
        };
        e.attrLidDeviceJid = function(a) {
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            if (c.jidType === "lidDevice") return c.deviceJid;
            return c.jidType === "lidUser" ? d("WAJids").defaultLidDeviceJidForLidUserJid(c.userJid) : this["throw"]('to have "' + a + '"={LidDeviceJid}, but instead has "' + b + '"')
        };
        e.attrDeviceId = function(a) {
            a = this.attrInt(a);
            return d("WAJids").interpretAsDeviceId(a)
        };
        e.attrFromJidChat = function() {
            var a = this.attrJidWithType();
            switch (a.jidType) {
                case "msgrUser":
                    var b = a.userJid,
                        e = d("WAJids").defaultDeviceJidForUser(b);
                    return {
                        type: "device",
                        chat: b,
                        deviceJid: e,
                        author: e
                    };
                case "interopUser":
                    b = a.userJid;
                    e = d("WAJids").defaultDeviceJidForUser(b);
                    return {
                        type: "device",
                        chat: b,
                        deviceJid: e,
                        author: e
                    };
                case "phoneUser":
                    b = a.userJid;
                    e = d("WAJids").defaultDeviceJidForUser(b);
                    return {
                        type: "device",
                        chat: b,
                        deviceJid: e,
                        author: e
                    };
                case "lidUser":
                    b = a.userJid;
                    e = d("WAJids").defaultLidDeviceJidForLidUserJid(b);
                    return {
                        type: "device",
                        chat: b,
                        deviceJid: e,
                        author: e
                    };
                case "phoneDevice":
                    b = a.deviceJid;
                    return {
                        type: "device",
                        chat: d("WAJids").extractUserJid(b),
                        deviceJid: b,
                        author: b
                    };
                case "msgrDevice":
                    e = a.deviceJid;
                    return {
                        type: "device",
                        chat: d("WAJids").extractUserJid(e),
                        deviceJid: e,
                        author: e
                    };
                case "interopDevice":
                    b = a.deviceJid;
                    return {
                        type: "device",
                        chat: d("WAJids").extractUserJid(b),
                        deviceJid: b,
                        author: b
                    };
                case "lidDevice":
                    e = a.deviceJid;
                    return {
                        type: "device",
                        chat: d("WAJids").extractUserJid(e),
                        deviceJid: e,
                        author: e
                    };
                case "group":
                    b = this.hasAttr("participant") ? this.attrDeviceJid("participant") : null;
                    return b == null ? this["throw"]("expected to have participant JID for group") : {
                        type: "group",
                        chat: a.groupJid,
                        groupJid: a.groupJid,
                        author: b
                    };
                case "broadcast":
                    e = this.hasAttr("participant") ? this.attrDeviceJid("participant") : null;
                    return e == null ? this["throw"]("expected to have participant JID for group") : {
                        type: "broadcast",
                        broadcastJid: a.broadcastJid,
                        chat: d("WAJids").extractUserJid(e),
                        author: e
                    };
                case "hosted":
                    b = a.hostedDeviceJid;
                    return {
                        type: "device",
                        chat: d("WAJids").extractUserJid(b),
                        deviceJid: b,
                        author: b
                    };
                case "hostedLid":
                    e = a.hostedLidDeviceJid;
                    return {
                        type: "device",
                        chat: d("WAJids").extractUserJid(e),
                        deviceJid: e,
                        author: e
                    };
                case "call":
                    d("WALogger").ERROR(i(), a.callJid);
                    throw c("err")("ParsableWapNode: attrFromJid() does not support CallJid");
                default:
                    a.jidType;
                    return this["throw"]("attrFromJidChat should not be used with jid of type " + a.jidType)
            }
        };
        e.attrFromJidPhoneChat = function() {
            var a = this.attrJidWithType();
            switch (a.jidType) {
                case "phoneUser":
                    var b = a.userJid,
                        e = d("WAJids").defaultPhoneDeviceJidForUser(b);
                    return {
                        type: "device",
                        chat: b,
                        deviceJid: e,
                        author: e
                    };
                case "phoneDevice":
                    b = a.deviceJid;
                    return {
                        type: "device",
                        chat: d("WAJids").extractPhoneUserJid(b),
                        deviceJid: b,
                        author: b
                    };
                case "group":
                    e = this.hasAttr("participant") ? this.attrPhoneDeviceJid("participant") : null;
                    return e == null ? this["throw"]("expected to have participant JID for group") : {
                        type: "group",
                        chat: a.groupJid,
                        groupJid: a.groupJid,
                        author: e
                    };
                case "broadcast":
                    b = this.hasAttr("participant") ? this.attrPhoneDeviceJid("participant") : null;
                    return b == null ? this["throw"]("expected to have participant JID for group") : {
                        type: "broadcast",
                        broadcastJid: a.broadcastJid,
                        chat: d("WAJids").extractPhoneUserJid(b),
                        author: b
                    };
                case "call":
                    d("WALogger").ERROR(h(), a.callJid);
                    throw c("err")("ParsableWapNode: attrFromJid() does not support CallJid");
                default:
                    a.jidType;
                    return this["throw"]("attrFromJidChat should not be used with jid of type " + a.jidType)
            }
        };
        e.attrFromPhoneJid = function() {
            var a = this.attrJidWithType();
            if (a.jidType === "status") {
                a = this.hasAttr("participant") ? this.attrPhoneDeviceJid("participant") : null;
                return a == null ? this["throw"]("to have participant for status msg") : {
                    type: "status",
                    author: a
                }
            } else return this.attrFromJidPhoneChat()
        };
        e.attrFromJid = function() {
            var a = this.attrJidWithType();
            if (a.jidType === "status") {
                var b = this.hasAttr("participant") ? this.attrPhoneDeviceJid("participant") : null;
                return b == null ? this["throw"]("to have participant for status msg") : {
                    type: "status",
                    author: b
                }
            }
            if (a.jidType === "newsletter") return {
                type: "newsletter",
                newsletterJid: a.newsletterJid
            };
            if (a.jidType === "hosted") return {
                type: "hosted",
                hostedDeviceJid: a.hostedDeviceJid
            };
            return a.jidType === "hostedLid" ? {
                type: "hostedLid",
                hostedLidDeviceJid: a.hostedLidDeviceJid
            } : this.attrFromJidChat()
        };
        e.attrJidWithType = function(a) {
            a === void 0 && (a = "from");
            var b = this.attrString(a),
                c = d("WAJids").interpretAndValidateJid(b);
            return c.jidType === "unknown" ? this["throw"]('to have "' + a + '"={Jid}, but instead has "' + b + '"') : c
        };
        e.attrWapJid = function(a) {
            a === void 0 && (a = "from");
            a = this.attrString(a);
            var b = d("WAJids").interpretAndValidateJid(a);
            return b.jidType === "unknown" ? d("WAWapJid").WapJid.create(null, a) : d("WAWap").JID(d("WAJids").extractFromJid(b))
        };
        e.attrLongInt = function(a) {
            a = this.attrString(a);
            return d("WALongInt").decimalStringToLongInt(a)
        };
        e.attrTime = function(a) {
            return d("WATimeUtils").castToUnixTime(this.attrInt(a))
        };
        e.attrFutureTime = function(a) {
            a = this.attrInt(a);
            return d("WATimeUtils").futureUnixTime(a)
        };
        e.contentString = function() {
            if (this.hasChildren()) return this["throw"]("to have string content, but has children instead");
            else if (this.hasContent()) {
                var a = new(d("WABinary").Binary)(this.contentBytes());
                return a.readString(a.size())
            } else return this["throw"]("to have content")
        };
        e.decodeAsString = function(a) {
            return d("WAWap").decodeAsString(a)
        };
        e.contentSerializedPubKey = function() {
            if (this.hasContent()) return d("WASignalKeys").serializeIdentity(this.contentBytes());
            else return this["throw"]("to have content")
        };
        e.createParseError = function(a) {
            return new j(this.name(), "expected <" + this.tag() + "> " + a)
        };
        e["throw"] = function(a) {
            throw this.createParseError(a)
        };
        return b
    }(d("WAParsableXmlNode").ParsableXmlNode);
    g.XmppParsingFailure = j;
    g.ParsableWapNode = a
}), 98);
__d("WADeprecatedWapParser", ["WAParsableWapNode", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b) {
            this.$1 = a, this.$2 = b
        }
        var b = a.prototype;
        b.parse = function(a) {
            a = new(d("WAParsableWapNode").ParsableWapNode)(this.$1, a);
            try {
                return {
                    success: this.$2(a)
                }
            } catch (a) {
                if (a instanceof d("WAParsableWapNode").XmppParsingFailure) return {
                    error: a
                };
                else throw a
            }
        };
        b.parseOrThrow = function(a) {
            a = this.parse(a);
            if (a.error) throw c("err")(String(a.error));
            return a.success
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("WAAckParser", ["WADeprecatedWapParser", "WAJids"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = new(c("WADeprecatedWapParser"))("ack", function(a) {
        a.assertTag("ack");
        return {
            id: a.attrString("id"),
            ts: a.maybeAttrString("t"),
            "class": a.attrString("class"),
            type: a.maybeAttrString("type"),
            from: a.attrJidWithType(),
            participant: a.hasAttr("participant") ? a.attrDeviceJid("participant") : null,
            recipient: a.hasAttr("recipient") ? a.attrUserJid("recipient") : null
        }
    });

    function a(a, b) {
        return a.id === b.id && (b["class"] === void 0 || a["class"] === b["class"]) && (b.type === void 0 || a.type === b.type) && (b.from === void 0 || h(a.from, b.from)) && (b.participant === void 0 || a.participant === b.participant) && (b.recipient === void 0 || a.recipient === b.recipient) && (b.ts === void 0 || a.ts === b.ts)
    }

    function h(a, b) {
        if (d("WAJids").extractFromJid(a) === b) return !0;
        if (a.userJid != null) return d("WAJids").defaultDeviceJidForUser(a.userJid) === b;
        if (a.deviceJid != null) {
            a = a.deviceJid;
            return d("WAJids").extractDeviceId(a) === 0 && d("WAJids").extractUserJid(a) === b
        }
        return !1
    }
    g.AckParser = b;
    g.ackMatchesTemplate = a;
    g.fromJidsAreEqual = h
}), 98);
__d("WAAlignChunkLengthsToMultipleOfAesBlockSize", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        return parseInt((a + 15) / 16, 10) * 16
    }

    function a(a, b) {
        var c = [],
            d = 0,
            e = 0,
            f = 0;
        for (var h = 0; h < a.length; ++h) {
            d += a[h];
            if (h === a.length - 1 && b != null && b > 0) {
                d > e ? c.push(b - e) : (c.pop(), c.push(b - f));
                break
            } else if (d > e) {
                var i = g(d - e);
                f = e;
                c.push(i);
                e += i
            }
        }
        return c
    }
    f.alignChunkSizeToMultipleAesBlockSize = g;
    f.alignChunkLengthsToMultipleOfAesBlockSize = a
}), 66);
__d("WAAppData", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 1;
    b = 2;
    f.EPOCH_STATUS_OPEN = a;
    f.EPOCH_STATUS_CLOSE = b
}), 66);
__d("WAArrayChunk", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c, d) {
        c === void 0 && (c = !1);
        var e = 0,
            f = [];
        while (e < a.length) {
            var g = [],
                h = 0;
            while (e < a.length) {
                var i = a[e],
                    j = d ? d(i) : 1;
                if (!c && h === 0 || h + j <= b) h += j, g.push(i), e++;
                else {
                    c && j > b && e++;
                    break
                }
            }
            g.length > 0 && f.push(g)
        }
        return f
    }
    f.chunk = a
}), 66);
__d("WACryptoPkcs7", ["WACryptoDependencies", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = new Uint8Array(1);
        do d("WACryptoDependencies").getCrypto().getRandomValues(b); while (b[0] === 0);
        h(a, b[0])
    }

    function b(a) {
        var b = new Uint8Array(1);
        d("WACryptoDependencies").getCrypto().getRandomValues(b);
        h(a, (b[0] & 15) + 1)
    }

    function h(a, b) {
        for (var c = 0; c < b; c++) a.writeUint8(b)
    }

    function e(a) {
        if (a.length === 0) throw c("err")("unpadPkcs7 given empty bytes");
        var b = a[a.length - 1];
        if (b > a.length) throw c("err")("unpadPkcs7 given " + a.length + " bytes, but pad is " + b);
        return new Uint8Array(a.buffer, a.byteOffset, a.length - b)
    }
    g.writeRandomPad = a;
    g.writeRandomPadMax16 = b;
    g.writePad = h;
    g.unpadPkcs7 = e
}), 98);
__d("WAAsMessageTransport", ["WABinary", "WACryptoPkcs7"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c, e, f) {
        f === void 0 && (f = 2);
        var g;
        b != null && (g = {
            destinationJid: b
        });
        var h;
        a != null && (h = {
            applicationPayload: {
                payload: a,
                version: f
            }
        });
        b = new(d("WABinary").Binary)();
        d("WACryptoPkcs7").writeRandomPadMax16(b);
        return {
            payload: h,
            protocol: {
                integral: {
                    padding: b.readBuffer(),
                    dsm: g
                },
                ancillary: {
                    skdm: c == null ? void 0 : c,
                    icdc: e == null ? void 0 : e
                }
            }
        }
    }
    g.asMessageTransport = a
}), 98);
__d("WABulkPutContactsApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        contacts: d("MAWTransactionMode").READWRITE
    }, "bulkPutContacts", function(a) {
        return function(b) {
            b = b.map(function(a) {
                return {
                    contactJid: a.contactJid,
                    dhash: a.dhash,
                    icdcFails: a.icdcFails,
                    icdcInfo: a.icdcInfo,
                    lastSyncTs: a.lastSyncTs
                }
            });
            return a.contacts.bulkPut(b).then(function() {})
        }
    });
    g.bulkPutContacts = a
}), 98);
__d("WABulkPutContactsApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        var b = a.map(function(a) {
            return {
                contactJid: a.contactJid,
                dhash: a.dhash,
                icdcFails: a.icdcFails,
                icdcInfo: a.icdcInfo,
                lastSyncTs: a.lastSyncTs
            }
        });
        return d("WormDb").getDb().runInTransaction(["contacts"], "readwrite", function(a) {
            return a.stores.contacts.bulkPut(b)
        }, d("WormDb").signalOp("bulkPutContacts"))
    };
    g.bulkPutContacts = a
}), 98);
__d("WABulkPutMediaKeysApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        mediaKeys: d("MAWTransactionMode").READWRITE
    }, "bulkPutMediaKeys", function(a) {
        return function(b) {
            return a.mediaKeys.bulkPut(b).then(function() {})
        }
    });
    g.bulkPutMediaKeys = a
}), 98);
__d("WASmaxInPreKeysIQErrorBadRequestMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "bad-request");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 400);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorBadRequestMixin = a
}), 98);
__d("WASmaxInPreKeysIQErrorNoValidJIDMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "not-acceptable");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 406);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorNoValidJIDMixin = a
}), 98);
__d("WASmaxInPreKeysRequestErrorsFetch", ["WAResultOrError", "WASmaxInPreKeysIQErrorBadRequestMixin", "WASmaxInPreKeysIQErrorFallbackClientMixin", "WASmaxInPreKeysIQErrorNoValidJIDMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInPreKeysIQErrorBadRequestMixin").parseIQErrorBadRequestMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "IQErrorBadRequest",
            value: b.value
        });
        var c = d("WASmaxInPreKeysIQErrorNoValidJIDMixin").parseIQErrorNoValidJIDMixin(a);
        if (c.success) return d("WAResultOrError").makeResult({
            name: "IQErrorNoValidJID",
            value: c.value
        });
        var e = d("WASmaxInPreKeysIQErrorFallbackClientMixin").parseIQErrorFallbackClientMixin(a);
        return e.success ? d("WAResultOrError").makeResult({
            name: "IQErrorFallbackClient",
            value: e.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["IQErrorBadRequest", "IQErrorNoValidJID", "IQErrorFallbackClient"], [b, c, e])
    }
    g.parseRequestErrorsFetch = a
}), 98);
__d("WASmaxInPreKeysFetchKeyBundlesResponseRequestError", ["WAResultOrError", "WASmaxInPreKeysIQErrorResponseMixin", "WASmaxInPreKeysRequestErrorsFetch", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInPreKeysIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInPreKeysRequestErrorsFetch").parseRequestErrorsFetch(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorRequestErrorsFetch: b.value
        }))
    }
    g.parseFetchKeyBundlesResponseRequestError = a
}), 98);
__d("WASmaxInPreKeysFetchKeyBundlesResponseServerError", ["WAResultOrError", "WASmaxInPreKeysIQErrorResponseMixin", "WASmaxInPreKeysServerErrors", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInPreKeysIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInPreKeysServerErrors").parseServerErrors(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorServerErrors: b.value
        }))
    }
    g.parseFetchKeyBundlesResponseServerError = a
}), 98);
__d("WASmaxInPreKeysEnums", ["WAJids"], (function(a, b, c, d, e, f, g) {
    b = {
        validators: [(a = d("WAJids")).validateDeviceJid, a.validateDeviceJid],
        typeName: "DeviceJid|DeviceJid"
    };
    c = {
        validators: [a.validateDeviceJid, a.validateDeviceJid, a.validateInteropDeviceJid, a.validateInteropDeviceJid],
        typeName: "DeviceJid|DeviceJid|InteropDeviceJid|InteropDeviceJid"
    };
    e = {
        validators: [a.validateDeviceJid, a.validateDomainJid],
        typeName: "DeviceJid|DomainJid"
    };
    f = {
        validators: [a.validateUserJid, a.validateUserJid],
        typeName: "UserJid|UserJid"
    };
    g.DEVICEJID_DEVICEJID = b;
    g.DEVICEJID_DEVICEJID_INTEROPDEVICEJID_INTEROPDEVICEJID = c;
    g.DEVICEJID_DOMAINJID = e;
    g.USERJID_USERJID = f
}), 98);
__d("WASmaxInPreKeysResponsePaddingMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").flattenedChildWithTag(a, "padding");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").contentBytesRange(b.value, 0, 524288);
        return !a.success ? a : d("WAResultOrError").makeResult({
            paddingElementValue: a.value
        })
    }
    g.parseResponsePaddingMixin = a
}), 98);
__d("WASmaxInPreKeysFetchKeyBundlesUserErrorFallbackMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").attrString(b.value, "text");
        if (!a.success) return a;
        b = d("WASmaxParseUtils").attrIntRange(b.value, "code", 500, 599);
        return !b.success ? b : d("WAResultOrError").makeResult({
            errorText: a.value,
            errorCode: b.value
        })
    }
    g.parseFetchKeyBundlesUserErrorFallbackMixin = a
}), 98);
__d("WASmaxInPreKeysFetchKeyBundlesUserErrorMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").attrString(b.value, "text");
        if (!a.success) return a;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, b.value, "code", 500);
        return !b.success ? b : d("WAResultOrError").makeResult({
            errorText: a.value,
            errorCode: b.value
        })
    }
    g.parseFetchKeyBundlesUserErrorMixin = a
}), 98);
__d("WASmaxInPreKeysDeviceIdentityMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").flattenedChildWithTag(a, "device-identity");
        if (!a.success) return a;
        a = d("WASmaxParseUtils").contentBytes(a.value);
        return !a.success ? a : d("WAResultOrError").makeResult({
            deviceIdentityElementValue: a.value
        })
    }
    g.parseDeviceIdentityMixin = a
}), 98);
__d("WASmaxInPreKeysPreKeyMixin", ["WAResultOrError", "WASmaxInPreKeysKeyDataMixin", "WASmaxInPreKeysKeyIDMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").flattenedChildWithTag(a, "key");
        if (!a.success) return a;
        var b = d("WASmaxParseUtils").flattenedChildWithTag(a.value, "id");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").flattenedChildWithTag(a.value, "value");
        if (!a.success) return a;
        b = d("WASmaxInPreKeysKeyIDMixin").parseKeyIDMixin(b.value);
        if (!b.success) return b;
        a = d("WASmaxInPreKeysKeyDataMixin").parseKeyDataMixin(a.value);
        return !a.success ? a : d("WAResultOrError").makeResult({
            keyIdKeyIDMixin: b.value,
            keyValueKeyDataMixin: a.value
        })
    }
    g.parsePreKeyMixin = a
}), 98);
__d("WASmaxInPreKeysFetchKeyBundlesUserSuccessMixin", ["WAResultOrError", "WASmaxInPreKeysDeviceIdentityMixin", "WASmaxInPreKeysIdentityKeyMixin", "WASmaxInPreKeysKeyTypeMixin", "WASmaxInPreKeysPreKeyMixin", "WASmaxInPreKeysRegistrationIDMixin", "WASmaxInPreKeysSignedPreKeyMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, a, "t", 0, void 0);
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").optionalLiteral(d("WASmaxParseUtils").attrString, a, "is_cloud_api", "true");
        if (!c.success) return c;
        var e = d("WASmaxInPreKeysRegistrationIDMixin").parseRegistrationIDMixin(a);
        if (!e.success) return e;
        var f = d("WASmaxInPreKeysKeyTypeMixin").parseKeyTypeMixin(a),
            g = d("WASmaxInPreKeysIdentityKeyMixin").parseIdentityKeyMixin(a);
        if (!g.success) return g;
        var h = d("WASmaxInPreKeysPreKeyMixin").parsePreKeyMixin(a),
            i = d("WASmaxInPreKeysSignedPreKeyMixin").parseSignedPreKeyMixin(a);
        if (!i.success) return i;
        a = d("WASmaxInPreKeysDeviceIdentityMixin").parseDeviceIdentityMixin(a);
        return d("WAResultOrError").makeResult(babelHelpers["extends"]({
            t: b.value,
            isCloudApi: c.value
        }, e.value, {
            keyTypeMixin: f.success ? f.value : null
        }, g.value, {
            preKeyMixin: h.success ? h.value : null
        }, i.value, {
            deviceIdentityMixin: a.success ? a.value : null
        }))
    }
    g.parseFetchKeyBundlesUserSuccessMixin = a
}), 98);
__d("WASmaxInPreKeysUserFetchKeyBundlesSuccessOrFetchKeyBundlesErrorOrFetchKeyBundlesErrorFallbackMixinGroup", ["WAResultOrError", "WASmaxInPreKeysFetchKeyBundlesUserErrorFallbackMixin", "WASmaxInPreKeysFetchKeyBundlesUserErrorMixin", "WASmaxInPreKeysFetchKeyBundlesUserSuccessMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInPreKeysFetchKeyBundlesUserSuccessMixin").parseFetchKeyBundlesUserSuccessMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "FetchKeyBundlesUserSuccess",
            value: b.value
        });
        var c = d("WASmaxInPreKeysFetchKeyBundlesUserErrorMixin").parseFetchKeyBundlesUserErrorMixin(a);
        if (c.success) return d("WAResultOrError").makeResult({
            name: "FetchKeyBundlesUserError",
            value: c.value
        });
        var e = d("WASmaxInPreKeysFetchKeyBundlesUserErrorFallbackMixin").parseFetchKeyBundlesUserErrorFallbackMixin(a);
        return e.success ? d("WAResultOrError").makeResult({
            name: "FetchKeyBundlesUserErrorFallback",
            value: e.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["UserSuccess", "UserError", "UserErrorFallback"], [b, c, e])
    }
    g.parseUserFetchKeyBundlesSuccessOrFetchKeyBundlesErrorOrFetchKeyBundlesErrorFallbackMixinGroup = a
}), 98);
__d("WASmaxInPreKeysFetchKeyBundlesResponseSuccess", ["WAResultOrError", "WASmaxInPreKeysEnums", "WASmaxInPreKeysIQResultResponseMixin", "WASmaxInPreKeysResponsePaddingMixin", "WASmaxInPreKeysUserFetchKeyBundlesSuccessOrFetchKeyBundlesErrorOrFetchKeyBundlesErrorFallbackMixinGroup", "WASmaxParseJid", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxParseJid").attrJidEnum(a, "jid", d("WASmaxInPreKeysEnums").DEVICEJID_DEVICEJID);
        if (!b.success) return b;
        a = d("WASmaxInPreKeysUserFetchKeyBundlesSuccessOrFetchKeyBundlesErrorOrFetchKeyBundlesErrorFallbackMixinGroup").parseUserFetchKeyBundlesSuccessOrFetchKeyBundlesErrorOrFetchKeyBundlesErrorFallbackMixinGroup(a);
        return !a.success ? a : d("WAResultOrError").makeResult({
            jid: b.value,
            userFetchKeyBundlesSuccessOrFetchKeyBundlesErrorOrFetchKeyBundlesErrorFallbackMixinGroup: a.value
        })
    }

    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "list");
        if (!c.success) return c;
        b = d("WASmaxInPreKeysIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        if (!b.success) return b;
        a = d("WASmaxInPreKeysResponsePaddingMixin").parseResponsePaddingMixin(a);
        c = d("WASmaxParseUtils").mapChildrenWithTag(c.value, "user", 0, 1e5, h);
        return !c.success ? c : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, b.value, {
            responsePaddingMixin: a.success ? a.value : null,
            listUser: c.value
        }))
    }
    g.parseFetchKeyBundlesResponseSuccessListUser = h;
    g.parseFetchKeyBundlesResponseSuccess = a
}), 98);
__d("WASmaxOutPreKeysFetchKeyBundlesRequest", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxOutPreKeysClientRequestMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.userJid;
        a = a.hasUserReasonIdentity;
        b = d("WASmaxJsx").smax("user", {
            jid: d("WAWap").JID(b),
            reason: d("WASmaxAttrs").OPTIONAL_LITERAL("identity", a)
        });
        return b
    }

    function a(a) {
        a = a.userArgs;
        a = d("WASmaxOutPreKeysClientRequestMixin").mergeClientRequestMixin(d("WASmaxJsx").smax("iq", {
            type: "get"
        }, d("WASmaxJsx").smax("key", null, d("WASmaxChildren").REPEATED_CHILD(h, a, 1, 1e5))));
        return a
    }
    g.makeFetchKeyBundlesRequestKeyUser = h;
    g.makeFetchKeyBundlesRequest = a
}), 98);
__d("WASmaxPreKeysFetchKeyBundlesRPC", ["WAComms", "WASmaxInPreKeysFetchKeyBundlesResponseRequestError", "WASmaxInPreKeysFetchKeyBundlesResponseServerError", "WASmaxInPreKeysFetchKeyBundlesResponseSuccess", "WASmaxOutPreKeysFetchKeyBundlesRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h, i;
        return b("regeneratorRuntime").async(function(j) {
            while (1) switch (j.prev = j.next) {
                case 0:
                    e = d("WASmaxOutPreKeysFetchKeyBundlesRequest").makeFetchKeyBundlesRequest(a);
                    j.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = j.sent;
                    g = d("WASmaxInPreKeysFetchKeyBundlesResponseSuccess").parseFetchKeyBundlesResponseSuccess(f, e);
                    if (!g.success) {
                        j.next = 7;
                        break
                    }
                    return j.abrupt("return", {
                        name: "FetchKeyBundlesResponseSuccess",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInPreKeysFetchKeyBundlesResponseRequestError").parseFetchKeyBundlesResponseRequestError(f, e);
                    if (!h.success) {
                        j.next = 10;
                        break
                    }
                    return j.abrupt("return", {
                        name: "FetchKeyBundlesResponseRequestError",
                        value: h.value
                    });
                case 10:
                    i = d("WASmaxInPreKeysFetchKeyBundlesResponseServerError").parseFetchKeyBundlesResponseServerError(f, e);
                    if (!i.success) {
                        j.next = 13;
                        break
                    }
                    return j.abrupt("return", {
                        name: "FetchKeyBundlesResponseServerError",
                        value: i.value
                    });
                case 13:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("FetchKeyBundles", {
                        Success: g,
                        RequestError: h,
                        ServerError: i
                    }));
                case 14:
                case "end":
                    return j.stop()
            }
        }, null, this)
    }
    g.sendFetchKeyBundlesRPC = a
}), 98);
__d("WAFetchPreKeyBundlesProtocol", ["WAConvertRegistrationIdMixin", "WAConvertSignedPreKeyMixin", "WAParsableXmlNode", "WAResultOrError", "WASignalKeys", "WASmaxPreKeysFetchKeyBundlesRPC", "WATagsLogger", "WATimeUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["RequestError: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["ServerError: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["fetched prekey successfully"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["start fetching prekey of ", "..."]);
        k = function() {
            return a
        };
        return a
    }
    var l = d("WATagsLogger").TAGS(["fetchPreKeyBundlesProtocol"]);

    function a(a) {
        var c, e, f, g;
        return b("regeneratorRuntime").async(function(n) {
            while (1) switch (n.prev = n.next) {
                case 0:
                    l.LOG(k(), a.join(", "));
                    n.next = 3;
                    return b("regeneratorRuntime").awrap(d("WASmaxPreKeysFetchKeyBundlesRPC").sendFetchKeyBundlesRPC({
                        userArgs: a.map(function(a) {
                            return {
                                userJid: a,
                                hasUserReasonIdentity: !1
                            }
                        })
                    }));
                case 3:
                    c = n.sent;
                    n.t0 = c.name;
                    n.next = n.t0 === "FetchKeyBundlesResponseSuccess" ? 7 : n.t0 === "FetchKeyBundlesResponseServerError" ? 11 : n.t0 === "FetchKeyBundlesResponseRequestError" ? 14 : 17;
                    break;
                case 7:
                    l.LOG(j());
                    e = new Map();
                    c.value.listUser.map(function(a) {
                        var b = a.userFetchKeyBundlesSuccessOrFetchKeyBundlesErrorOrFetchKeyBundlesErrorFallbackMixinGroup;
                        b.name === "FetchKeyBundlesUserSuccess" && e.set(a.jid, m(b.value))
                    });
                    return n.abrupt("return", d("WAResultOrError").makeResult(e));
                case 11:
                    f = c.value.errorServerErrors.name;
                    l.WARN(i(), f);
                    return n.abrupt("return", d("WAResultOrError").makeError({
                        type: "server-error",
                        payload: f
                    }));
                case 14:
                    g = c.value.errorRequestErrorsFetch.name;
                    l.ERROR(h(), g);
                    return n.abrupt("return", d("WAResultOrError").makeError({
                        type: "request-error",
                        payload: g
                    }));
                case 17:
                case "end":
                    return n.stop()
            }
        }, null, this)
    }

    function m(a) {
        var b = d("WAConvertRegistrationIdMixin").registrationIdMixin(a),
            c = d("WASignalKeys").serializeIdentity(a.elementValue),
            e = d("WAConvertSignedPreKeyMixin").convertSignedPreKeyMixin(a),
            f = a.preKeyMixin ? n(a.preKeyMixin) : null;
        a = d("WATimeUtils").castToUnixTime(a.t || 0);
        return {
            keys: {
                regId: b,
                identity: c,
                oneTimeKey: f,
                signedKey: {
                    id: e.id,
                    signature: e.signature,
                    publicKey: d("WASignalKeys").serializeIdentity(e.pubkey)
                }
            },
            timestamp: a
        }
    }

    function n(a) {
        return {
            id: d("WAParsableXmlNode").convertBytesToUint(a.keyIdKeyIDMixin.elementValue, 3),
            publicKey: d("WASignalKeys").serializeIdentity(a.keyValueKeyDataMixin.elementValue)
        }
    }
    g.fetchPreKeyBundlesProtocol = a
}), 98);
__d("WABulkRequestKeys", ["WAFetchPreKeyBundlesProtocol", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var c;
        return b("regeneratorRuntime").async(function(e) {
            while (1) switch (e.prev = e.next) {
                case 0:
                    e.next = 2;
                    return b("regeneratorRuntime").awrap(d("WAFetchPreKeyBundlesProtocol").fetchPreKeyBundlesProtocol(a));
                case 2:
                    c = e.sent;
                    if (c.success) {
                        e.next = 5;
                        break
                    }
                    return e.abrupt("return", d("WAResultOrError").makeError("errRequestKeysParsingFailed"));
                case 5:
                    return e.abrupt("return", d("WAResultOrError").makeResult(c.value));
                case 6:
                case "end":
                    return e.stop()
            }
        }, null, this)
    }
    g.bulkRequestKeys = a
}), 98);
__d("WAGetPrekeyIdsInRange", ["WASignalKeys"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 16777215;

    function i(a) {
        return a
    }

    function a(a, b) {
        var c = [];
        a = i(a);
        var e = i(b);
        if (a <= e)
            for (var f = a; f <= b; f++) c.push(d("WASignalKeys").castToPreKeyId(f));
        else {
            for (b = a; b < h; b++) c.push(d("WASignalKeys").castToPreKeyId(b));
            for (f = 1; f <= e; f++) c.push(d("WASignalKeys").castToPreKeyId(f))
        }
        return c
    }
    g.PRE_KEY_MAX_ID = h;
    g.getPrekeyIdsInRange = a
}), 98);
__d("WADbPrekeyTxns", ["MAWDexieTable", "WAGetPrekeyIdsInRange", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return a.prekeyGeneration.get(b).then(function(b) {
            if (b == null) throw c("err")("Expected a prekey generation row");
            b = d("WAGetPrekeyIdsInRange").getPrekeyIdsInRange(b.startingId, b.endingId);
            return h(a, b).then(function(a) {
                return a.filter(Boolean).map(function(a) {
                    return a.encoded
                })
            })
        })
    }

    function b(a, b) {
        return b.length === 0 ? d("MAWDexieTable").dexieResolve() : a.prekey.bulkDelete(b).then(function() {})
    }

    function h(a, b) {
        return a.prekey.bulkGet(b)
    }

    function e(a, b) {
        return a.prekeyGeneration.bulkGet(b)
    }
    g.getPrekeysForGeneration = a;
    g.bulkDeletePreKeys = b;
    g.getPrekeys = h;
    g.getPrekeyGenerations = e
}), 98);
__d("WADbSenderKeySessionTxns", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a.senderKeySessions.bulkPut(b).then(function() {})
    }

    function b(a, b) {
        return a.senderKeySessions.where("groupJid").equals(b)["delete"]()
    }

    function c(a, b) {
        return a.senderKeySessions.bulkGet(b)
    }
    f.bulkPutSenderKeySessions = a;
    f.deleteSenderKeysByGroupJid = b;
    f.getSenderKeySessionsBySenderKeySessionId = c
}), 66);
__d("WADbSessionTxns", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a.session.bulkPut(b).then(function() {})
    }

    function b(a, b) {
        return a.session.bulkGet(b)
    }
    f.bulkSaveSessions = a;
    f.bulkGetSessions = b
}), 66);
__d("WABulkSaveSignalDataApi", ["MAWDexieTable", "MAWTransactionMode", "WAArrayZip", "WACryptoManager", "WADbIdentityTxns", "WADbPrekeyTxns", "WADbSenderKeySessionTxns", "WADbSessionTxns", "WADbSignal", "WADbTransactor", "WAJids", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("WADbTransactor").makeSignalTransactor({
        contacts: (a = d("MAWTransactionMode")).READWRITE,
        identity: a.READWRITE,
        prekey: a.READWRITE,
        senderKeySessions: a.READWRITE,
        session: a.READWRITE
    }, "bulkSaveSignalData", function(a) {
        return function(b) {
            var c = b.dhashUpdate,
                e = b.icdcUpdate,
                f = b.identityRemove,
                g = b.identityUpdate,
                i = b.preKeyRemove,
                k = b.senderKeySessionUpdate,
                l = b.sessionRemove;
            b = b.sessionUpdate;
            b = b.map(function(a) {
                var b = a.id;
                a = a.updated;
                return {
                    id: b,
                    session: d("WACryptoManager").encodeSession(a)
                }
            });
            var m = [],
                n = [];
            k.forEach(function(a) {
                var b = a.author,
                    c = a.groupId;
                a = a.updated;
                var e = d("WAJids").extractUserJid(b);
                b = d("WAJids").extractDeviceId(b);
                var f = d("WADbSignal").buildSenderKeySessionId(c, e, b);
                n.push({
                    deviceId: b,
                    groupJid: c,
                    id: f,
                    record: d("WACryptoManager").encodeSenderKeySession(a),
                    userJid: e
                })
            });
            return d("MAWDexieTable").dexieAll([a.session.bulkDelete(l), a.identity.bulkDelete(f), j(a, e), d("WADbSessionTxns").bulkSaveSessions(a, b), d("WADbSenderKeySessionTxns").bulkPutSenderKeySessions(a, n), h(a, g, c), d("WADbPrekeyTxns").bulkDeletePreKeys(a, i.map(function(a) {
                a = a.id;
                return a
            }))]).then(function() {
                return d("WAResultOrError").makeResult(m)
            })
        }
    });

    function h(a, b, c) {
        if (b.length === 0) return d("MAWDexieTable").dexieResolve([]);
        b = b.map(function(a) {
            var b = a.id;
            a = a.identity;
            return {
                deviceJid: b,
                identity: a,
                userJid: d("WAJids").extractUserJid(b)
            }
        });
        return d("MAWDexieTable").dexieAll([d("WADbIdentityTxns").bulkPutIdentities(a, b), d("WADbIdentityTxns").invalidateDhash(a, b.map(function(a) {
            return a.userJid
        })).then(function() {
            return i(a, c)
        })]).then(function() {
            return []
        })
    }

    function i(a, b) {
        return b.length === 0 ? d("MAWDexieTable").dexieResolve() : a.contacts.bulkGet(b.map(function(a) {
            a = a.id;
            return a
        })).then(function(a) {
            return d("WAArrayZip").zip(b, a).map(function(a) {
                var b = a[0].dhash;
                a = a[1];
                return a == null ? null : babelHelpers["extends"]({}, a, {
                    dhash: b
                })
            })
        }).then(function(b) {
            return a.contacts.bulkPut(b.filter(Boolean))
        })
    }

    function j(a, b) {
        return b.length === 0 ? d("MAWDexieTable").dexieResolve() : a.contacts.bulkGet(b.map(function(a) {
            a = a.id;
            return a
        })).then(function(a) {
            return d("WAArrayZip").zip(b, a).map(function(a) {
                var b = a[0].icdc;
                a = a[1];
                return a == null ? null : babelHelpers["extends"]({}, a, {
                    icdcInfo: b
                })
            })
        }).then(function(b) {
            return a.contacts.bulkPut(b.filter(Boolean))
        })
    }
    g.bulkSaveSignalData = b
}), 98);
__d("WABulkSaveSignalDataApiV2", ["Promise", "WAArrayZip", "WACryptoManager", "WADbIdentityTxnsV2", "WADbSignal", "WAJids", "WAResultOrError", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a) {
        var c = a.dhashUpdate,
            e = a.icdcUpdate,
            f = a.identityRemove,
            g = a.identityUpdate,
            j = a.preKeyRemove,
            l = a.senderKeySessionUpdate,
            m = a.sessionRemove;
        a = a.sessionUpdate;
        var n = a.map(function(a) {
                var b = a.id;
                a = a.updated;
                return {
                    id: b,
                    session: d("WACryptoManager").encodeSession(a)
                }
            }),
            o = [],
            p = [];
        l.forEach(function(a) {
            var b = a.author,
                c = a.groupId;
            a = a.updated;
            var e = d("WAJids").extractUserJid(b);
            b = d("WAJids").extractDeviceId(b);
            var f = d("WADbSignal").buildSenderKeySessionId(c, e, b);
            p.push({
                deviceId: b,
                groupJid: c,
                id: f,
                record: d("WACryptoManager").encodeSenderKeySession(a),
                userJid: e
            })
        });
        return d("WormDb").getDb().runInTransaction(["contacts", "identity", "prekey", "senderKeySessions", "session"], "readwrite", function(a) {
            var l = a.stores,
                q = l.session,
                r = l.identity,
                s = l.senderKeySessions;
            l = l.prekey;
            return (h || (h = b("Promise"))).all([q.bulkDelete(m), r.bulkDelete(f), i(a.stores, e), q.bulkPut(n), s.bulkPut(p), k(a.stores, g, c), l.bulkDelete(j.map(function(a) {
                a = a.id;
                return a
            }))]).then(function() {
                return d("WAResultOrError").makeResult(o)
            })
        }, d("WormDb").signalOp("bulkSaveSignalData"))
    };

    function i(a, b) {
        return j.apply(this, arguments)
    }

    function j() {
        j = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            if (c.length === 0) return (h || (h = b("Promise"))).resolve();
            var e = (yield a.contacts.bulkGet(c.map(function(a) {
                a = a.id;
                return a
            })).then(function(a) {
                return d("WAArrayZip").zip(c, a).map(function(a) {
                    var b = a[0].icdc;
                    a = a[1];
                    return a == null ? null : babelHelpers["extends"]({}, a, {
                        icdcInfo: b
                    })
                })
            }));
            return a.contacts.bulkPut(e.filter(Boolean))
        });
        return j.apply(this, arguments)
    }

    function k(a, b, c) {
        return l.apply(this, arguments)
    }

    function l() {
        l = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c, e) {
            if (c.length === 0) return;
            c = c.map(function(a) {
                var b = a.id;
                a = a.identity;
                return {
                    deviceJid: b,
                    identity: a,
                    userJid: d("WAJids").extractUserJid(b)
                }
            });
            yield(h || (h = b("Promise"))).all([a.identity.bulkPut(c), d("WADbIdentityTxnsV2").invalidateDhash(a, c.map(function(a) {
                return a.userJid
            })).then(function() {
                return m(a, e)
            })])
        });
        return l.apply(this, arguments)
    }

    function m(a, b) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            if (b.length === 0) return;
            var c = (yield a.contacts.bulkGet(b.map(function(a) {
                a = a.id;
                return a
            })));
            b = d("WAArrayZip").zip(b, c).map(function(a) {
                var b = a[0].dhash;
                a = a[1];
                return a == null ? null : babelHelpers["extends"]({}, a, {
                    dhash: b
                })
            });
            return a.contacts.bulkPut(b.filter(Boolean))
        });
        return n.apply(this, arguments)
    }
    g.bulkSaveSignalData = a
}), 98);
__d("WADbPersonalSenderKeyStatusTxns", ["MAWDexieTable", "MAWTransactionMode", "WADbTransactor", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            hasSenderKey: new Set(),
            rotateSenderKey: !0,
            senderKeyId: null,
            senderKeyTs: d("WATimeUtils").castToUnixTime(0)
        },
        i = d("WADbTransactor").makeSignalTransactor({
            personalSenderKeyStatuses: d("MAWTransactionMode").READWRITE
        }, "putNewPersonalSenderKeyStatus", function(a) {
            return function(b) {
                return d("MAWDexieTable").dexieAll(b.map(function(b) {
                    return j(a, b)
                })).then(function() {})
            }
        });

    function j(a, b) {
        var c = babelHelpers["extends"]({}, h, {
            groupJid: b
        });
        return a.personalSenderKeyStatuses.put(c).then(function() {
            return c
        })
    }

    function a(a, b, c) {
        return l(a, b).then(function(b) {
            var d = [];
            b.forEach(function(a) {
                if (a == null || a.rotateSenderKey) return;
                c.forEach(function(b) {
                    return a.hasSenderKey["delete"](b)
                });
                d.push(a)
            });
            return a.personalSenderKeyStatuses.bulkPut(d).then(function() {
                return b
            })
        })
    }

    function b(a, b) {
        return a.personalSenderKeyStatuses.bulkDelete(b)
    }

    function c(a, b) {
        return k(a, [b]).then(function(a) {
            return a[0]
        })
    }

    function k(a, b) {
        return l(a, b).then(function(b) {
            var c = [];
            b.forEach(function(a) {
                if (a == null) return;
                a.rotateSenderKey = !0;
                c.push(a)
            });
            return a.personalSenderKeyStatuses.bulkPut(c).then(function() {
                return b
            })
        })
    }

    function e(a, b) {
        return a.personalSenderKeyStatuses.bulkPut(b).then(function() {})
    }

    function f(a, b, c, d) {
        return a.personalSenderKeyStatuses.get(b).then(function(e) {
            var f = babelHelpers["extends"]({}, e || h, {
                groupJid: b,
                rotateSenderKey: !1,
                senderKeyId: c,
                senderKeyTs: d
            });
            return a.personalSenderKeyStatuses.put(f).then(function() {
                return f
            })
        })
    }

    function l(a, b) {
        return a.personalSenderKeyStatuses.bulkGet(b)
    }
    g.bulkPutNewPersonalSenderKeyStatus = i;
    g.putNewPersonalSenderKeyStatus = j;
    g.removeDevicesToMultiplePersonalSenderKeyStatuses = a;
    g.bulkDeletePersonalSenderKeyStatus = b;
    g.setRotateSenderKeyToTrue = c;
    g.bulkSetRotateSenderKeyToTrueTxn = k;
    g.bulkUpdateSenderKeyStatus = e;
    g.updateSenderKeyStatusAsRotated = f;
    g.bulkGetPersonalSenderKeyStatuses = l
}), 98);
__d("WABulkSetRotateSenderKeyToTrueApi", ["MAWTransactionMode", "WADbPersonalSenderKeyStatusTxns", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        personalSenderKeyStatuses: d("MAWTransactionMode").READWRITE
    }, "bulkSetRotateSenderKeyToTrue", function(a) {
        return function(b, c) {
            return d("WADbPersonalSenderKeyStatusTxns").bulkSetRotateSenderKeyToTrueTxn(a, c).then(function() {})
        }
    });
    g.bulkSetRotateSenderKeyToTrue = a
}), 98);
__d("WAHttpResumeCheck", ["WALogger", "WAMediaUtils", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpResumeCheck: fail to parse request body ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpResumeCheck: resume is NaN: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpResumeCheck: object_id is missing"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpResumeCheck: direct_path is missing"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpResumeCheck: response status ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpResumeCheck: fail to initiate fetch ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function a(a) {
        var c, e, f;
        return b("regeneratorRuntime").async(function(g) {
            while (1) switch (g.prev = g.next) {
                case 0:
                    g.prev = 0;
                    g.next = 3;
                    return b("regeneratorRuntime").awrap(fetch(a, {
                        method: "POST",
                        mode: "cors",
                        cache: "no-cache",
                        headers: {
                            "Content-Type": "text/plain"
                        }
                    }));
                case 3:
                    c = g.sent;
                    g.next = 10;
                    break;
                case 6:
                    g.prev = 6;
                    g.t0 = g["catch"](0);
                    d("WALogger").ERROR(m(), g.t0);
                    throw g.t0;
                case 10:
                    e = c, f = e.status;
                    d("WALogger").LOG(l(), f);
                    g.t1 = f;
                    g.next = g.t1 === 200 ? 15 : g.t1 === 404 ? 16 : g.t1 === 408 ? 17 : g.t1 === 429 ? 18 : g.t1 === 507 ? 18 : 19;
                    break;
                case 15:
                    return g.abrupt("return", c.json().then(function(a) {
                        var b = a.resume,
                            c = a.direct_path;
                        a = a.object_id;
                        if (b === "complete") {
                            if (c == null) {
                                d("WALogger").ERROR(k());
                                return d("WAResultOrError").makeResult({
                                    type: "media-not-found"
                                })
                            }
                            if (a == null) {
                                d("WALogger").ERROR(j());
                                return d("WAResultOrError").makeResult({
                                    type: "media-not-found"
                                })
                            }
                            return d("WAResultOrError").makeResult({
                                type: "media-found",
                                directPath: d("WAMediaUtils").unsafeCastToDirectPath(c),
                                objectId: d("WAMediaUtils").stringToDeliveryObjectId(a)
                            })
                        }
                        c = parseInt(b, 10);
                        if (c === 0) return d("WAResultOrError").makeResult({
                            type: "media-not-found"
                        });
                        if (Number.isNaN(c)) {
                            d("WALogger").ERROR(i(), b);
                            return d("WAResultOrError").makeResult({
                                type: "media-not-found"
                            })
                        }
                        return d("WAResultOrError").makeResult({
                            type: "media-partial-found",
                            resumeFromBytes: c
                        })
                    })["catch"](function(a) {
                        d("WALogger").ERROR(h(), a);
                        return d("WAResultOrError").makeError("body-network-error")
                    }));
                case 16:
                    return g.abrupt("return", d("WAResultOrError").makeResult({
                        type: "media-not-found"
                    }));
                case 17:
                    return g.abrupt("return", d("WAResultOrError").makeError("server-timeout"));
                case 18:
                    return g.abrupt("return", d("WAResultOrError").makeError("upload-throttled"));
                case 19:
                    if (!(f >= 400 && f < 500)) {
                        g.next = 21;
                        break
                    }
                    return g.abrupt("return", d("WAResultOrError").makeError("request-error"));
                case 21:
                    return g.abrupt("return", d("WAResultOrError").makeError("unspecified-http-error"));
                case 22:
                case "end":
                    return g.stop()
            }
        }, null, this, [
            [0, 6]
        ])
    }
    g.httpResumeCheck = a
}), 98);
__d("WAHttpUtils", ["err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        if (!/^https:\/\/[-\w.]+\.\w+$/.test(a)) throw c("err")('buildUrl given invalid host "' + a + '"');
        if (!b.startsWith("/")) throw c("err")('buildUrl given invalid path "' + b + '"');
        var e = d;
        d = "" + a + b;
        if (!e) return d;
        a = Object.keys(e).map(function(a) {
            var b = e[a];
            b instanceof ArrayBuffer && (b = new Uint8Array(b));
            b = b instanceof Uint8Array ? Array.prototype.slice.call(b).map(function(a) {
                return "%" + a.toString(16)
            }).join("") : encodeURIComponent(b.toString());
            return encodeURIComponent(a) + "=" + b
        });
        if (a.length > 0) {
            b = a.join("&");
            return d.includes("?") ? d + "&" + b : d + "?" + b
        } else return d
    }
    g.buildUrl = a
}), 98);
__d("WAMediaUrl", ["WABase64", "WAGlobals", "WAHttpUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 1;

    function a(a, b, c, e, f, g, i) {
        var j = d("WAGlobals").getDependencies().mediaUploadRoot();
        c = d("WABase64").encodeB64UrlSafe(c);
        b = d("WABase64").encodeB64UrlSafe(b);
        f = {
            auth: f,
            token: b
        };
        g && (f.resume = h);
        i != null && i > 0 && (f.bytestart = i);
        return d("WAHttpUtils").buildUrl("https://" + e, j + "/" + a + "/" + c, f)
    }

    function b(a, b, c, e, f, g, h) {
        b = d("WABase64").encodeB64UrlSafe(b);
        b = {
            hash: b,
            mode: e
        };
        f != null && (b._nc_cat = f);
        g != null && g >= 0 && (b.bytestart = g);
        h != null && h > 0 && (b.byteend = h);
        return d("WAHttpUtils").buildUrl("https://" + c, a, b)
    }
    g.RESUME_PARAM = h;
    g.buildUploadUrl = a;
    g.buildDownloadUrl = b
}), 98);
__d("WACheckCiphertextInServer", ["WAHttpResumeCheck", "WAMediaUrl", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, c, e, f) {
        return f.run(function(f, g) {
            var h, i, j;
            return b("regeneratorRuntime").async(function(k) {
                while (1) switch (k.prev = k.next) {
                    case 0:
                        h = d("WAMediaUrl").buildUploadUrl(a, e, c, f.domain, g, !0);
                        k.next = 3;
                        return b("regeneratorRuntime").awrap(d("WAHttpResumeCheck").httpResumeCheck(h));
                    case 3:
                        i = k.sent;
                        if (!i.success) {
                            k.next = 8;
                            break
                        }
                        return k.abrupt("return", d("WAResultOrError").makeResult(i));
                    case 8:
                        j = i.error;
                        k.t0 = j;
                        k.next = k.t0 === "server-timeout" ? 12 : k.t0 === "unspecified-http-error" ? 12 : 13;
                        break;
                    case 12:
                        return k.abrupt("return", d("WAResultOrError").makeError({
                            progressMade: !0
                        }));
                    case 13:
                        return k.abrupt("return", d("WAResultOrError").makeResult(d("WAResultOrError").makeError(j)));
                    case 14:
                    case "end":
                        return k.stop()
                }
            }, null, this)
        }).then(function(a) {
            return (a = a) != null ? a : d("WAResultOrError").makeError("max-attempts-exceeded")
        })
    }
    g.checkCiphertextInServer = a
}), 98);
__d("WAParseIqResponse", ["WAWap"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c) {
        var e = a.content;
        if (e && Array.isArray(e) && e[0]) {
            e = e[0];
            if (e.tag === "error") {
                var f = e.attrs || {},
                    g;
                c && (typeof c === "function" ? g = c(a) : g = c.parseOrThrow(e));
                c = g;
                return {
                    success: !1,
                    errorCode: parseInt(f.code, 10),
                    errorText: d("WAWap").decodeAsString(f.text) || "",
                    errorType: d("WAWap").decodeAsString(f.type) || "",
                    errorBackoff: parseInt(f.backoff, 10),
                    toString: h,
                    customError: c
                }
            }
        }
        if (typeof b === "function") return {
            success: !0,
            result: b(a)
        };
        else return {
            success: !0,
            result: b.parseOrThrow(a)
        }
    }

    function h() {
        return "IqError " + this.errorCode + ": " + this.errorText
    }
    g.parseIqResponse = a
}), 98);
__d("WADeprecatedSendIq", ["Promise", "WAAckParser", "WAArrayUtils", "WAComms", "WALogger", "WAParseIqResponse"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Comms has no open socket, will send stanza when socket opens"]);
        i = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return d("WAComms")._sendIq(a, !1).then(function(a) {
            return d("WAParseIqResponse").parseIqResponse(a, b)
        })
    }

    function c(a, b, c) {
        return d("WAComms")._sendIq(a, !1).then(function(a) {
            return d("WAParseIqResponse").parseIqResponse(a, b, c)
        })
    }

    function e(a, b, c) {
        return d("WAComms")._sendIq(a, !1, c).then(function(a) {
            return d("WAParseIqResponse").parseIqResponse(a, b)
        })
    }

    function f(a, b) {
        return d("WAComms")._sendIq(a, !0).then(function(a) {
            return d("WAParseIqResponse").parseIqResponse(a, b)
        })
    }

    function j(a, b) {
        return k(a, b).then(function() {})
    }

    function k(a, c) {
        return new(h || (h = b("Promise")))(function(e) {
            var f = d("WAComms").singletonOrThrowIfUninitialized("deprecatedSendStanzaAndReturnAck"),
                g = function(a) {
                    var b = d("WAAckParser").AckParser.parse(a);
                    return !b.error && d("WAAckParser").ackMatchesTemplate(b.success, c) ? a : null
                },
                j = {
                    type: "ack",
                    parseAndTest: g,
                    resolve: e,
                    stanza: a,
                    attachedToSocketId: d("WAComms").DEFAULT_SOCKET_ID,
                    orderedId: d("WAComms").getAndIncrementNextOrderedId()
                };
            f.ackHandlers.push(j);
            if (!f.socket) {
                d("WALogger").LOG(i());
                return
            }
            f.callStanza(a)["catch"](function(a) {
                var c = f.ackHandlers.indexOf(j);
                if (c === -1) return;
                d("WAArrayUtils").removeIndexWithoutPreservingOrder(f.ackHandlers, c);
                j.resolve((h || (h = b("Promise"))).reject(a))
            })
        })
    }

    function l(a, b) {
        d("WAComms").castSmaxStanza(a, b)
    }
    g.deprecatedSendIq = a;
    g.deprecatedSendIqErrorParser = c;
    g.deprecatedSendIqIfConnectedWithin = e;
    g.deprecatedSendIqWithoutRetry = f;
    g.deprecatedSendStanzaAndWaitForAck = j;
    g.deprecatedSendStanzaAndReturnAck = k;
    g.deprecatedCastStanza = l
}), 98);
__d("WAComputeAndUploadICDCInfo", ["WABase64", "WADeprecatedSendIq", "WADeprecatedWapParser", "WAGetDevices", "WAGlobals", "WAICDCUtils", "WAIdentityUtils", "WALogger", "WAPromiseBackoffs", "WAWap", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Cannot update ICDC for user, because of ", " server response"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed getting devices ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Loading identities fails with error: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["computeAndUploadICDCInfo called ", ""]);
        k = function() {
            return a
        };
        return a
    }
    var l = new(c("WADeprecatedWapParser"))("parseUploadICDCInfoResponse", function(a) {
            a.assertTag("iq"), a.assertFromServer(), a.assertAttr("type", "result")
        }),
        m = 0;
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            a = c.reason;
            var e = c.caller;
            c = c.sequence;
            d("WALogger").LOG(k(), c);
            var f;
            try {
                f = (yield d("WAGlobals").getWaOneQueue().enqueue(function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                        a = a.cryptoManager;
                        var b = (yield a.storage.loadIdentities(d("WAGlobals").getMyUserJid()));
                        a = a.regInfo;
                        return {
                            regInfo: a,
                            identities: Array.from(b.values())
                        }
                    });
                    return function(b) {
                        return a.apply(this, arguments)
                    }
                }(), {
                    operationType: "icdc_load_identities",
                    flush: !1,
                    afterInit: !0
                }))
            } catch (a) {
                d("WALogger").ERROR(j(), a.toString())
            }
            if (f == null) return;
            var g = f,
                n = g.regInfo;
            g = g.identities;
            n = d("WAICDCUtils").computeICDCInfoForUpload(n.staticKeyPair, c, g, a, e);
            var o = n.icdcInfo;
            c = n.encodedSignedICDC;
            a = (yield d("WAIdentityUtils").computeIdentitiesHash(g));
            e = d("WAWap").wap("iq", {
                id: d("WAWap").generateId(),
                to: d("WAWap").S_WHATSAPP_NET,
                type: "set",
                xmlns: "fbid:devices"
            }, d("WAWap").wap("icdc", {
                ihash: d("WAWap").CUSTOM_STRING(d("WABase64").encodeB64(a)),
                seq: d("WAWap").INT(o.seq),
                ts: d("WAWap").INT(o.timestamp)
            }, c));
            n = (yield d("WADeprecatedSendIq").deprecatedSendIq(e, l));
            n.success ? (m = 0, yield d("WAGlobals").getWaOneQueue().enqueue(function(a) {
                a = a.cryptoManager;
                return a.storage.saveICDC(d("WAGlobals").getMyUserJid(), {
                    sequence: o.seq,
                    timestamp: o.timestamp,
                    devices: o.devices,
                    signingDeviceIndex: o.signingDeviceIndex,
                    dirty: !1
                })
            }, {
                operationType: "save_icdc",
                flush: !0,
                afterInit: !0
            })) : (m += 1, n.errorCode === 406 || n.errorCode === 500 ? setTimeout(function() {
                d("WAGetDevices").getDevices(null, {
                    ignoreDhash: !0,
                    reason: "compute-Upload-icdc",
                    users: new Set().add(d("WAGlobals").getMyUserJid())
                })["catch"](function(a) {
                    d("WALogger").ERROR(i(), a.toString())
                })
            }, d("WAPromiseBackoffs").getDelay(m, {
                jitter: .1,
                max: 3e4,
                algo: {
                    type: "fibonacci",
                    first: 1e3,
                    second: 1e3
                }
            })) : d("WALogger").WARN(h(), n.errorCode))
        });
        return function(b, c) {
            return a.apply(this, arguments)
        }
    }();
    g.computeAndUploadICDCInfo = a
}), 98);
__d("WAGetDevices", ["WADevicesState", "WALogger", "WAPushSafeTypes", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["fetchAndSaveDevices: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            a = d("WAPushSafeTypes").unsafeNotNullable(b);
            b = a.users;
            var c = a.reason;
            a = a.ignoreDhash;
            a = a === void 0 ? !1 : a;
            d("WALogger").LOG(h(), c);
            a && d("WADevicesState").getDevicesState().reset(Array.from(b));
            yield d("WADevicesState").getDevicesState().waitForUserDevices(Array.from(b), "getDevices job: " + c, a)
        });
        return i.apply(this, arguments)
    }
    g.getDevices = a
}), 98);
__d("WAFetchAndSaveDevices", ["Promise", "WABulkPutContactsApi", "WABulkPutContactsApiV2", "WAComputeAndUploadICDCInfo", "WADexieToWormMigration", "WAGlobals", "WAICDCUtils", "WALogger", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["computeAndSaveICDC: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Update user devices signal and DB"]);
        j = function() {
            return a
        };
        return a
    }

    function a(a) {
        return k.apply(this, arguments)
    }

    function k() {
        k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            if (a.length === 0) return;
            var c = [];
            yield d("WAGlobals").getWaOneQueue().enqueue(function(e) {
                var f = e.cryptoManager;
                d("WALogger").LOG(j());
                return (h || (h = b("Promise"))).all(a.map(function(a) {
                    var b;
                    c.push({
                        contactJid: a.jid,
                        dhash: a.dhash,
                        lastSyncTs: a.lastSyncTs,
                        icdcInfo: (b = a.icdcInfo) != null ? b : void 0
                    });
                    return f.storage.updateUserDevicesInfo([a])
                }))
            }, {
                operationType: "get_devices",
                flush: !0,
                afterInit: !0
            });
            var e = d("WADexieToWormMigration").isWorm("WAFetchAndSaveDevices") ? d("WABulkPutContactsApiV2").bulkPutContacts : d("WABulkPutContactsApi").bulkPutContacts;
            yield e(c);
            var f = d("WAGlobals").getMyUserJid();
            e = a.find(function(a) {
                return a.jid === f
            });
            if (e != null) {
                e = e.icdcInfo;
                if (e == null || d("WAICDCUtils").isICDCIndexInvalid(e) || (e == null ? void 0 : e.dirty)) {
                    var g;
                    e == null ? g = "empty" : e.dirty ? g = "dirty" : g = "invalidIndex";
                    d("WAComputeAndUploadICDCInfo").computeAndUploadICDCInfo(null, {
                        reason: g,
                        caller: "get_devices",
                        sequence: e == null ? void 0 : e.sequence
                    })["catch"](function(a) {
                        d("WALogger").DEV(i(), a)
                    })
                }
            }
        });
        return k.apply(this, arguments)
    }
    g.updateUsersDevicesSignalAndDB = a
}), 98);
__d("WAHandleFbDeviceChangeNotificationProtocol", ["WAICDCUtils", "WAResultOrError", "WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a.dhash
    }

    function b(a) {
        var b;
        b = ((b = a.iCDCDirtyMixin) == null ? void 0 : b.dirty) === "true";
        var c = d("WATimeUtils").castToUnixTime(a.ts),
            e = a.seq;
        a = d("WAICDCUtils").decodeICDCInfo(a.elementValue);
        e = d("WAICDCUtils").validateAndPrepareICDCFromNotification(e, b, c, a);
        return e == null ? d("WAResultOrError").makeError("icdc-validation-failure") : d("WAResultOrError").makeResult(e)
    }
    g.parseDhash = a;
    g.parseICDCFromServer = b
}), 98);
__d("WALoadContactsApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        contacts: d("MAWTransactionMode").READONLY
    }, "loadContacts", function(a) {
        return function(b) {
            return a.contacts.bulkGet(b).then(function(a) {
                return new Map(a.filter(Boolean).map(function(a) {
                    return [a.contactJid, {
                        contactJid: a.contactJid,
                        dhash: a.dhash,
                        icdcFails: a.icdcFails,
                        icdcInfo: a.icdcInfo,
                        lastSyncTs: a.lastSyncTs
                    }]
                }))
            })
        }
    });
    g.loadContacts = a
}), 98);
__d("WALoadContactsApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["contacts"], "readonly", function(b) {
            return b.stores.contacts.bulkGet(a).then(function(a) {
                return new Map(a.filter(Boolean).map(function(a) {
                    return [a.contactJid, {
                        contactJid: a.contactJid,
                        dhash: a.dhash,
                        icdcFails: a.icdcFails,
                        icdcInfo: a.icdcInfo,
                        lastSyncTs: a.lastSyncTs
                    }]
                }))
            })
        }, d("WormDb").signalOp("loadContacts"))
    };
    g.loadContacts = a
}), 98);
__d("WARPCAbortController", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = "rpc-timeout";

    function a(a, c) {
        var d, e = new(g || (g = b("Promise")))(function(a, b) {
            d = setTimeout(function() {
                b(h)
            }, c)
        });
        return g.race([a, e])["finally"](function() {
            clearTimeout(d)
        })
    }
    f.RPC_TIMEOUT = h;
    f.rpcAbortController = a
}), 66);
__d("WASmaxInDevicesIQErrorResponseMixin", ["WAResultOrError", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!b.success) return b;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "type", "error");
        return !c.success ? c : d("WAResultOrError").makeResult({
            type: c.value
        })
    }
    g.parseIQErrorResponseMixin = a
}), 98);
__d("WASmaxInDevicesIQErrorBadRequestMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "bad-request");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 400);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorBadRequestMixin = a
}), 98);
__d("WASmaxInDevicesNonRetryableIQErrorMixin", ["WASmaxInDevicesIQErrorBadRequestMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxInDevicesIQErrorBadRequestMixin").parseIQErrorBadRequestMixin(a);
        return !b.success ? b : b
    }
    g.parseNonRetryableIQErrorMixin = a
}), 98);
__d("WASmaxInDevicesIQErrorInternalServerErrorMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "internal-server-error");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 500);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorInternalServerErrorMixin = a
}), 98);
__d("WASmaxInDevicesIQErrorServiceUnavailableMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "service-unavailable");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 503);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorServiceUnavailableMixin = a
}), 98);
__d("WASmaxInDevicesIQErrorInternalServerErrorOrServiceUnavailableMixinGroup", ["WAResultOrError", "WASmaxInDevicesIQErrorInternalServerErrorMixin", "WASmaxInDevicesIQErrorServiceUnavailableMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInDevicesIQErrorInternalServerErrorMixin").parseIQErrorInternalServerErrorMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "IQErrorInternalServerError",
            value: b.value
        });
        var c = d("WASmaxInDevicesIQErrorServiceUnavailableMixin").parseIQErrorServiceUnavailableMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "IQErrorServiceUnavailable",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["IQErrorInternalServerError", "IQErrorServiceUnavailable"], [b, c])
    }
    g.parseIQErrorInternalServerErrorOrServiceUnavailableMixinGroup = a
}), 98);
__d("WASmaxInDevicesRetryableIQErrorMixin", ["WAResultOrError", "WASmaxInDevicesIQErrorInternalServerErrorOrServiceUnavailableMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, a, "backoff", 0, 86400);
        if (!b.success) return b;
        a = d("WASmaxInDevicesIQErrorInternalServerErrorOrServiceUnavailableMixinGroup").parseIQErrorInternalServerErrorOrServiceUnavailableMixinGroup(a);
        return !a.success ? a : d("WAResultOrError").makeResult({
            backoff: b.value,
            iQErrorInternalServerErrorOrServiceUnavailableMixinGroup: a.value
        })
    }
    g.parseRetryableIQErrorMixin = a
}), 98);
__d("WASmaxInDevicesRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup", ["WAResultOrError", "WASmaxInDevicesNonRetryableIQErrorMixin", "WASmaxInDevicesRetryableIQErrorMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInDevicesRetryableIQErrorMixin").parseRetryableIQErrorMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "RetryableIQError",
            value: b.value
        });
        var c = d("WASmaxInDevicesNonRetryableIQErrorMixin").parseNonRetryableIQErrorMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "NonRetryableIQError",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["RetryableIQError", "NonRetryableIQError"], [b, c])
    }
    g.parseRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup = a
}), 98);
__d("WASmaxInDevicesFetchResponseError", ["WAResultOrError", "WASmaxInDevicesIQErrorResponseMixin", "WASmaxInDevicesRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInDevicesIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInDevicesRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup").parseRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup: b.value
        }))
    }
    g.parseFetchResponseError = a
}), 98);
__d("WASmaxInDevicesIQErrorItemNotFoundMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "text", "item-not-found");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrInt, a, "code", 404);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: a.value
        })
    }
    g.parseIQErrorItemNotFoundMixin = a
}), 98);
__d("WASmaxInDevicesFetchNonRetryableUserErrorMixin", ["WASmaxInDevicesIQErrorItemNotFoundMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxInDevicesIQErrorItemNotFoundMixin").parseIQErrorItemNotFoundMixin(a);
        return !b.success ? b : b
    }
    g.parseFetchNonRetryableUserErrorMixin = a
}), 98);
__d("WASmaxInDevicesFetchRetryableUserErrorMixin", ["WAResultOrError", "WASmaxInDevicesIQErrorInternalServerErrorOrServiceUnavailableMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxInDevicesIQErrorInternalServerErrorOrServiceUnavailableMixinGroup").parseIQErrorInternalServerErrorOrServiceUnavailableMixinGroup(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            iQErrorInternalServerErrorOrServiceUnavailableMixinGroup: b.value
        })
    }
    g.parseFetchRetryableUserErrorMixin = a
}), 98);
__d("WASmaxInDevicesFetchOrFetchNonRetryableUserErrorMixinGroup", ["WAResultOrError", "WASmaxInDevicesFetchNonRetryableUserErrorMixin", "WASmaxInDevicesFetchRetryableUserErrorMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInDevicesFetchRetryableUserErrorMixin").parseFetchRetryableUserErrorMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "FetchRetryableUserError",
            value: b.value
        });
        var c = d("WASmaxInDevicesFetchNonRetryableUserErrorMixin").parseFetchNonRetryableUserErrorMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "FetchNonRetryableUserError",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["RetryableUserError", "NonRetryableUserError"], [b, c])
    }
    g.parseFetchOrFetchNonRetryableUserErrorMixinGroup = a
}), 98);
__d("WASmaxInDevicesFetchUserResponseFailureMixin", ["WAResultOrError", "WASmaxInDevicesFetchOrFetchNonRetryableUserErrorMixinGroup", "WASmaxParseJid", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!b.success) return b;
        a = d("WASmaxParseJid").attrUserJid(a, "jid");
        if (!a.success) return a;
        b = d("WASmaxInDevicesFetchOrFetchNonRetryableUserErrorMixinGroup").parseFetchOrFetchNonRetryableUserErrorMixinGroup(b.value);
        return !b.success ? b : d("WAResultOrError").makeResult({
            jid: a.value,
            errorFetchOrFetchNonRetryableUserErrorMixinGroup: b.value
        })
    }
    g.parseFetchUserResponseFailureMixin = a
}), 98);
__d("WASmaxInDevicesDeviceModelInfoMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "platform");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentString(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function i(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "model");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentString(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function a(a) {
        var b = d("WASmaxParseUtils").optionalChildWithTag(a, "platform", h);
        if (!b.success) return b;
        a = d("WASmaxParseUtils").optionalChildWithTag(a, "model", i);
        return !a.success ? a : d("WAResultOrError").makeResult({
            platform: b.value,
            model: a.value
        })
    }
    g.parseDeviceModelInfoPlatform = h;
    g.parseDeviceModelInfoModel = i;
    g.parseDeviceModelInfoMixin = a
}), 98);
__d("WASmaxInDevicesDhashMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").attrString(a, "dhash");
        return !a.success ? a : d("WAResultOrError").makeResult({
            dhash: a.value
        })
    }
    g.parseDhashMixin = a
}), 98);
__d("WASmaxInDevicesKeyDataMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").contentBytesRange(a, 32, 32);
        return !a.success ? a : d("WAResultOrError").makeResult({
            elementValue: a.value
        })
    }
    g.parseKeyDataMixin = a
}), 98);
__d("WASmaxInDevicesIdentityKeyMixin", ["WASmaxInDevicesKeyDataMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").flattenedChildWithTag(a, "identity");
        if (!a.success) return a;
        a = d("WASmaxInDevicesKeyDataMixin").parseKeyDataMixin(a.value);
        return !a.success ? a : a
    }
    g.parseIdentityKeyMixin = a
}), 98);
__d("WASmaxInDevicesDeviceListMixin", ["WAResultOrError", "WASmaxInDevicesDeviceModelInfoMixin", "WASmaxInDevicesDhashMixin", "WASmaxInDevicesIdentityKeyMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "device");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "id", 1, 999);
        if (!b.success) return b;
        var c = d("WASmaxInDevicesIdentityKeyMixin").parseIdentityKeyMixin(a);
        if (!c.success) return c;
        a = d("WASmaxInDevicesDeviceModelInfoMixin").parseDeviceModelInfoMixin(a);
        return d("WAResultOrError").makeResult(babelHelpers["extends"]({
            id: b.value
        }, c.value, {
            deviceModelInfoMixin: a.success ? a.value : null
        }))
    }

    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "devices");
        if (!b.success) return b;
        b = d("WASmaxInDevicesDhashMixin").parseDhashMixin(a);
        a = d("WASmaxParseUtils").mapChildrenWithTag(a, "device", 0, 25, h);
        return !a.success ? a : d("WAResultOrError").makeResult({
            dhashMixin: b.success ? b.value : null,
            device: a.value
        })
    }
    g.parseDeviceListDevice = h;
    g.parseDeviceListMixin = a
}), 98);
__d("WASmaxInDevicesICDCDirtyMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "icdc");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "dirty", "true");
        return !b.success ? b : d("WAResultOrError").makeResult({
            dirty: b.value
        })
    }
    g.parseICDCDirtyMixin = a
}), 98);
__d("WASmaxInDevicesICDCSeqMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").attrIntRange(a, "seq", 0, 2147483647);
        return !a.success ? a : d("WAResultOrError").makeResult({
            seq: a.value
        })
    }
    g.parseICDCSeqMixin = a
}), 98);
__d("WASmaxInDevicesICDCSignedListMixin", ["WAResultOrError", "WASmaxInDevicesICDCSeqMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "icdc");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "ts", 0, void 0);
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").contentBytesRange(a, 1, 40072);
        if (!c.success) return c;
        a = d("WASmaxInDevicesICDCSeqMixin").parseICDCSeqMixin(a);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            ts: b.value,
            elementValue: c.value
        }, a.value))
    }
    g.parseICDCSignedListMixin = a
}), 98);
__d("WASmaxInDevicesICDCFromServerMixin", ["WAResultOrError", "WASmaxInDevicesICDCDirtyMixin", "WASmaxInDevicesICDCSignedListMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "icdc");
        if (!b.success) return b;
        b = d("WASmaxInDevicesICDCSignedListMixin").parseICDCSignedListMixin(a);
        if (!b.success) return b;
        a = d("WASmaxInDevicesICDCDirtyMixin").parseICDCDirtyMixin(a);
        return d("WAResultOrError").makeResult(babelHelpers["extends"]({}, b.value, {
            iCDCDirtyMixin: a.success ? a.value : null
        }))
    }
    g.parseICDCFromServerMixin = a
}), 98);
__d("WASmaxInDevicesFetchUserResponseSuccessMixin", ["WAResultOrError", "WASmaxInDevicesDeviceListMixin", "WASmaxInDevicesICDCFromServerMixin", "WASmaxParseJid", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "devices");
        if (!b.success) return b;
        b = d("WASmaxInDevicesDeviceListMixin").parseDeviceListMixin(a);
        return !b.success ? b : b
    }

    function i(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "icdc");
        if (!b.success) return b;
        b = d("WASmaxInDevicesICDCFromServerMixin").parseICDCFromServerMixin(a);
        return !b.success ? b : b
    }

    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").optionalChildWithTag(a, "devices", h);
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").optionalChildWithTag(a, "icdc", i);
        if (!c.success) return c;
        a = d("WASmaxParseJid").attrUserJid(a, "jid");
        return !a.success ? a : d("WAResultOrError").makeResult({
            jid: a.value,
            devices: b.value,
            icdc: c.value
        })
    }
    g.parseFetchUserResponseSuccessDevices = h;
    g.parseFetchUserResponseSuccessIcdc = i;
    g.parseFetchUserResponseSuccessMixin = a
}), 98);
__d("WASmaxInDevicesUserResponseFetchFailureOrFetchSuccessMixinGroup", ["WAResultOrError", "WASmaxInDevicesFetchUserResponseFailureMixin", "WASmaxInDevicesFetchUserResponseSuccessMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInDevicesFetchUserResponseFailureMixin").parseFetchUserResponseFailureMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "FetchUserResponseFailure",
            value: b.value
        });
        var c = d("WASmaxInDevicesFetchUserResponseSuccessMixin").parseFetchUserResponseSuccessMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "FetchUserResponseSuccess",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["UserResponseFailure", "UserResponseSuccess"], [b, c])
    }
    g.parseUserResponseFetchFailureOrFetchSuccessMixinGroup = a
}), 98);
__d("WASmaxInDevicesFetchUserResponseMixin", ["WAResultOrError", "WASmaxInDevicesUserResponseFetchFailureOrFetchSuccessMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxInDevicesUserResponseFetchFailureOrFetchSuccessMixinGroup").parseUserResponseFetchFailureOrFetchSuccessMixinGroup(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            userResponseFetchFailureOrFetchSuccessMixinGroup: b.value
        })
    }
    g.parseFetchUserResponseMixin = a
}), 98);
__d("WASmaxInDevicesIQResultResponseMixin", ["WAResultOrError", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!b.success) return b;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "type", "result");
        return !c.success ? c : d("WAResultOrError").makeResult({
            type: c.value
        })
    }
    g.parseIQResultResponseMixin = a
}), 98);
__d("WASmaxInDevicesFetchResponseSuccess", ["WAResultOrError", "WASmaxInDevicesFetchUserResponseMixin", "WASmaxInDevicesIQResultResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "user");
        if (!b.success) return b;
        b = d("WASmaxInDevicesFetchUserResponseMixin").parseFetchUserResponseMixin(a);
        return !b.success ? b : b
    }

    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "users");
        if (!c.success) return c;
        a = d("WASmaxInDevicesIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxParseUtils").mapChildrenWithTag(c.value, "user", 0, 25, h);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            usersUser: b.value
        }))
    }
    g.parseFetchResponseSuccessUsersUser = h;
    g.parseFetchResponseSuccess = a
}), 98);
__d("WASmaxOutDevicesBaseIQGetRequestMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("iq", {
            id: d("WAWap").generateId(),
            type: "get"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBaseIQGetRequestMixin = a
}), 98);
__d("WASmaxOutDevicesDhashMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.anyDhash;
        a = d("WASmaxJsx").smax("smax$any", {
            dhash: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeDhashMixin = a
}), 98);
__d("WASmaxOutDevicesICDCSeqMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.anySeq;
        a = d("WASmaxJsx").smax("smax$any", {
            seq: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeICDCSeqMixin = a
}), 98);
__d("WASmaxOutDevicesFetchRequest", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutDevicesBaseIQGetRequestMixin", "WASmaxOutDevicesDhashMixin", "WASmaxOutDevicesICDCSeqMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.userJid,
            c = a.dhashMixinArgs;
        a = a.iCDCSeqMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutDevicesICDCSeqMixin").mergeICDCSeqMixin, d("WASmaxMixins").optionalMerge(d("WASmaxOutDevicesDhashMixin").mergeDhashMixin, d("WASmaxJsx").smax("user", {
            jid: d("WAWap").USER_JID(b)
        }), c), a);
        return b
    }

    function a(a) {
        a = a.userArgs;
        a = d("WASmaxOutDevicesBaseIQGetRequestMixin").mergeBaseIQGetRequestMixin(d("WASmaxJsx").smax("iq", {
            to: d("WAWap").S_WHATSAPP_NET,
            xmlns: "fbid:devices"
        }, d("WASmaxJsx").smax("users", null, d("WASmaxChildren").REPEATED_CHILD(h, a, 1, 25))));
        return a
    }
    g.makeFetchRequestUsersUser = h;
    g.makeFetchRequest = a
}), 98);
__d("WASmaxDevicesFetchRPC", ["WAComms", "WASmaxInDevicesFetchResponseError", "WASmaxInDevicesFetchResponseSuccess", "WASmaxOutDevicesFetchRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h;
        return b("regeneratorRuntime").async(function(i) {
            while (1) switch (i.prev = i.next) {
                case 0:
                    e = d("WASmaxOutDevicesFetchRequest").makeFetchRequest(a);
                    i.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = i.sent;
                    g = d("WASmaxInDevicesFetchResponseSuccess").parseFetchResponseSuccess(f, e);
                    if (!g.success) {
                        i.next = 7;
                        break
                    }
                    return i.abrupt("return", {
                        name: "FetchResponseSuccess",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInDevicesFetchResponseError").parseFetchResponseError(f, e);
                    if (!h.success) {
                        i.next = 10;
                        break
                    }
                    return i.abrupt("return", {
                        name: "FetchResponseError",
                        value: h.value
                    });
                case 10:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("Fetch", {
                        Success: g,
                        Error: h
                    }));
                case 11:
                case "end":
                    return i.stop()
            }
        }, null, this)
    }
    g.sendFetchRPC = a
}), 98);
__d("WAFetchFbDevicesProtocolV2", ["Promise", "WAArrayChunk", "WADexieToWormMigration", "WAHandleFbDeviceChangeNotificationProtocol", "WAJids", "WALoadContactsApi", "WALoadContactsApiV2", "WARPCAbortController", "WASignalKeys", "WASmaxDevicesFetchRPC", "WATagsLogger", "WATimeUtils", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Timeout for fetchAndSaveDevices"]);
        j = function() {
            return a
        };
        return a
    }
    var k = 25,
        l = 1e4,
        m = d("WATagsLogger").TAGS(["wa-devices-protocol"]);

    function a(a, b) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            if (a.length === 0) return new Map();
            var e = (yield o(a, c));
            c = d("WAArrayChunk").chunk(a.map(function(a) {
                var b = e.get(a);
                b = b != null ? {
                    anyDhash: b
                } : null;
                return {
                    userJid: a,
                    dhashMixinArgs: b
                }
            }), k);
            var f = new Map();
            yield(h || (h = b("Promise"))).allSettled(c.map(function(a) {
                return q(f, a)
            }));
            return f
        });
        return n.apply(this, arguments)
    }

    function o(a, b) {
        return p.apply(this, arguments)
    }

    function p() {
        p = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            if (b) return new Map();
            b = (yield d("WADexieToWormMigration").isWorm("WAFetchFbDevicesProtocolV2") ? d("WALoadContactsApiV2").loadContacts(a) : d("WALoadContactsApi").loadContacts(a));
            var c = new Map();
            b.forEach(function(a) {
                a && a.dhash != null && c.set(a.contactJid, a.dhash)
            });
            return c
        });
        return p.apply(this, arguments)
    }

    function q(a, b) {
        return r.apply(this, arguments)
    }

    function r() {
        r = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            try {
                var e = new Set(b.map(function(a) {
                    return a.userJid
                }));
                b = (yield d("WARPCAbortController").rpcAbortController(d("WASmaxDevicesFetchRPC").sendFetchRPC({
                    userArgs: b
                }), l));
                if (b.name === "FetchResponseError") throw c("err")("Failed to fetch user devices");
                b.value.usersUser.map(function(b) {
                    b = b.userResponseFetchFailureOrFetchSuccessMixinGroup;
                    if (b.name === "FetchUserResponseFailure") return;
                    b = b.value;
                    var c = b.jid,
                        f = b.devices;
                    b = b.icdc;
                    e["delete"](c);
                    a.set(c, {
                        newState: s(c, f, b, d("WATimeUtils").unixTime()),
                        stateIsUpToDate: !1
                    })
                });
                e.forEach(function(b) {
                    a.set(b, {
                        stateIsUpToDate: !0
                    })
                })
            } catch (a) {
                if (a === d("WARPCAbortController").RPC_TIMEOUT) {
                    m.ERROR(j());
                    return
                }
                m.ERROR(i(), a)
            }
        });
        return r.apply(this, arguments)
    }

    function s(a, b, c, e) {
        e === void 0 && (e = null);
        var f = [],
            g = null;
        if (b) {
            f = b.device.map(function(a) {
                var b;
                return {
                    id: d("WAJids").interpretAsDeviceId(a.id),
                    identity: d("WASignalKeys").serializeIdentity(a.elementValue),
                    platform: (b = a.deviceModelInfoMixin) == null ? void 0 : (b = b.platform) == null ? void 0 : b.elementValue,
                    model: (b = a.deviceModelInfoMixin) == null ? void 0 : (a = b.model) == null ? void 0 : a.elementValue
                }
            });
            g = (b = b.dhashMixin) == null ? void 0 : b.dhash
        }
        b = null;
        if (c) {
            c = d("WAHandleFbDeviceChangeNotificationProtocol").parseICDCFromServer(c);
            b = c.success ? c.value : null
        }
        return {
            jid: a,
            devices: f,
            lastSyncTs: d("WATimeUtils").unixTime(),
            dhash: g,
            icdcInfo: b,
            notificationTs: e
        }
    }
    g.fetchFbDevicesProtocol = a
}), 98);
__d("WADevicesState", ["I64", "Promise", "WAFetchAndSaveDevices", "WAFetchFbDevicesProtocolV2", "WAJids", "WALogger", "WAPREList", "WAPREMetrics", "WAResolvable", "WAResultOrError", "WATagsLogger", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["updateDevicesSignalAndDB failed: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getDevices -> update devices signal"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["fetchFBDevicesProtocol failed: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["getDevices called for users ", ", reason: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[S406998] Invalid userJid reason: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to parse stanza id ", ": ", ""]);
        o = function() {
            return a
        };
        return a
    }
    var p = 3e4,
        q = 1e3 * 60 * 60,
        r = d("WATagsLogger").TAGS(["WADevicesState"]);

    function s(a) {
        var b = 6917529027641082e3,
            c = !1;
        try {
            c = (i || (i = d("I64"))).equal(i.and_(i.of_string(a), i.of_float(b)), i.of_float(b))
        } catch (b) {
            d("WALogger").ERROR(o(), a, b)
        }
        return c
    }
    c = function() {
        function a() {
            this.$1 = new Map()
        }
        var c = a.prototype;
        c.$2 = function(a) {
            var b = this;
            setTimeout(function() {
                a.forEach(function(a) {
                    var c = a[0];
                    a = a[1];
                    a.resolveWasCalled() || (a.resolve(d("WAResultOrError").makeError()), b.$1.get(c) === a && b.$1["delete"](c))
                })
            }, p);
            setTimeout(function() {
                a.forEach(function(a) {
                    var c = a[0];
                    a = a[1];
                    b.$1.get(c) === a && b.$1["delete"](c)
                })
            }, q)
        };
        c.waitForUserDevices = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c, e) {
                var f = this;
                e === void 0 && (e = !1);
                var g = [];
                for (a of a) s(d("WAJids").userIdFromJid(a)) ? d("WALogger").ERROR(n(), c) : g.push(a);
                var i = [],
                    o = [];
                g.forEach(function(a) {
                    var b = f.$1.get(a);
                    if (b == null) {
                        var c = new(d("WAResolvable").Resolvable)();
                        i.push([a, c]);
                        f.$1.set(a, c)
                    } else o.push([a, b.promise])
                });
                this.$2(i);
                r.LOG(m(), Array.from(g), c);
                var p = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.GET_DEVICES, {
                    string: {
                        reason: c
                    }
                });
                p.addPoint("fetch_start");
                var q = (yield d("WAFetchFbDevicesProtocolV2").fetchFbDevicesProtocol(i.map(function(a) {
                    a = a[0];
                    return a
                }), e)["catch"](function(a) {
                    p.addPoint("fetch_fail");
                    r.ERROR(l(), a);
                    return new Map()
                }));
                p.addPoint("fetch_end");
                var t = !0;
                r.DEV(k());
                p.addPoint("signal_update_start");
                yield d("WAFetchAndSaveDevices").updateUsersDevicesSignalAndDB(Array.from(q.values()).map(function(a) {
                    return a.newState
                }).filter(Boolean))["catch"](function(a) {
                    t = !1, r.ERROR(j(), a)
                });
                p.addPoint("signal_update_end");
                i.forEach(function(a) {
                    var b = a[0];
                    a = a[1];
                    if (!t) {
                        a.resolve(d("WAResultOrError").makeError());
                        f.$1["delete"](b);
                        return
                    }
                    q.has(b) ? a.resolve(d("WAResultOrError").makeResult()) : (a.resolve(d("WAResultOrError").makeError()), f.$1["delete"](b))
                });
                p.endSuccess();
                yield(h || (h = b("Promise"))).allSettled(o.map(function(a) {
                    a[0];
                    a = a[1];
                    return a
                }))
            });

            function c(b, c, d) {
                return a.apply(this, arguments)
            }
            return c
        }();
        c.reset = function(a) {
            var b = this;
            a.forEach(function(a) {
                return b.$1["delete"](a)
            })
        };
        return a
    }();
    var t = new c();

    function a() {
        return t
    }
    g.DeviceStateClassV2 = c;
    g.getDevicesState = a
}), 98);
__d("WAConcurrentIterate", ["Promise", "regeneratorRuntime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a, c, d) {
        var e = [],
            f = [],
            h = 0,
            i = function() {
                var d;
                return b("regeneratorRuntime").async(function(e) {
                    while (1) switch (e.prev = e.next) {
                        case 0:
                            if (!(h < a)) {
                                e.next = 8;
                                break
                            }
                            d = h;
                            h++;
                            e.next = 5;
                            return b("regeneratorRuntime").awrap(c(d));
                        case 5:
                            f[d] = e.sent;
                            e.next = 0;
                            break;
                        case 8:
                        case "end":
                            return e.stop()
                    }
                }, null, this)
            };
        d = Math.min(a, d);
        for (var j = 0; j < d; j++) e.push(i());
        return (g || (g = b("Promise"))).all(e).then(function() {
            return f
        })
    }
    f.concurrentIterate = a
}), 66);
__d("WAMultiDevice.pb", ["WAProtoConst"], (function(a, b, c, d, e, f, g) {
    a = {};
    b = {};
    c = {};
    e = {};
    f = {};
    var h = {},
        i = {},
        j = {},
        k = {},
        l = {},
        m = {};
    a.internalSpec = {
        payload: [1, (d = d("WAProtoConst")).TYPES.MESSAGE, c],
        metadata: [2, d.TYPES.MESSAGE, b]
    };
    b.internalSpec = {};
    c.internalSpec = {
        applicationData: [1, d.TYPES.MESSAGE, e],
        signal: [2, d.TYPES.MESSAGE, m],
        __oneofs__: {
            payload: ["applicationData", "signal"]
        }
    };
    e.internalSpec = {
        appStateSyncKeyShare: [1, d.TYPES.MESSAGE, h],
        appStateSyncKeyRequest: [2, d.TYPES.MESSAGE, f],
        __oneofs__: {
            applicationData: ["appStateSyncKeyShare", "appStateSyncKeyRequest"]
        }
    };
    f.internalSpec = {
        keyIds: [1, d.FLAGS.REPEATED | d.TYPES.MESSAGE, l]
    };
    h.internalSpec = {
        keys: [1, d.FLAGS.REPEATED | d.TYPES.MESSAGE, i]
    };
    i.internalSpec = {
        keyId: [1, d.TYPES.MESSAGE, l],
        keyData: [2, d.TYPES.MESSAGE, j]
    };
    j.internalSpec = {
        keyData: [1, d.TYPES.BYTES],
        fingerprint: [2, d.TYPES.MESSAGE, k],
        timestamp: [3, d.TYPES.INT64]
    };
    k.internalSpec = {
        rawId: [1, d.TYPES.UINT32],
        currentIndex: [2, d.TYPES.UINT32],
        deviceIndexes: [3, d.FLAGS.REPEATED | d.FLAGS.PACKED | d.TYPES.UINT32]
    };
    l.internalSpec = {
        keyId: [1, d.TYPES.BYTES]
    };
    m.internalSpec = {};
    g.MultiDeviceSpec = a;
    g.MultiDevice$MetadataSpec = b;
    g.MultiDevice$PayloadSpec = c;
    g.MultiDevice$ApplicationDataSpec = e;
    g.MultiDevice$ApplicationData$AppStateSyncKeyRequestMessageSpec = f;
    g.MultiDevice$ApplicationData$AppStateSyncKeyShareMessageSpec = h;
    g.MultiDevice$ApplicationData$AppStateSyncKeySpec = i;
    g.MultiDevice$ApplicationData$AppStateSyncKey$AppStateSyncKeyDataSpec = j;
    g.MultiDevice$ApplicationData$AppStateSyncKey$AppStateSyncKeyData$AppStateSyncKeyFingerprintSpec = k;
    g.MultiDevice$ApplicationData$AppStateSyncKeyIdSpec = l;
    g.MultiDevice$SignalSpec = m
}), 98);
__d("WAParseAppStateSyncKeyRequest", ["WASyncdKeyTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [];
        for (var a = a.keyIds, c = Array.isArray(a), e = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (c) {
                if (e >= a.length) break;
                f = a[e++]
            } else {
                e = a.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            f.keyId != null && b.push(d("WASyncdKeyTypes").toSyncKeyId(f.keyId))
        }
        return {
            keyIds: b
        }
    }
    g.parseAppStateSyncKeyRequest = a
}), 98);
__d("WASyncdKeyManagementUtils", ["WASyncdKeyTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return new DataView(d("WASyncdKeyTypes").fromSyncKeyId(a)).getUint16(0)
    }

    function h(a) {
        return new DataView(d("WASyncdKeyTypes").fromSyncKeyId(a)).getUint32(2)
    }

    function b(a) {
        return h(a) + 1
    }
    g.getKeyDeviceId = a;
    g.getKeyEpoch = h;
    g.generateNewKeyEpoch = b
}), 98);
__d("WAParseAppStateSyncKeyShare", ["WALogger", "WALongInt", "WASyncdKeyManagementUtils", "WASyncdKeyTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Key missing keyId"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a) {
        var b = [],
            c = [];
        for (var a = a.keys, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= a.length) break;
                f = a[e++]
            } else {
                e = a.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            f = i(f);
            f != null && (f.type === "orphan" ? c.push(f.keyId) : (f.type, b.push(f.keyData)))
        }
        return {
            keys: b,
            orphanKeys: c
        }
    }

    function i(a) {
        var b, c, e, f, g, i;
        if (((b = a.keyId) == null ? void 0 : b.keyId) == null) {
            d("WALogger").WARN(h());
            return null
        }
        b = d("WASyncdKeyTypes").toSyncKeyId(a.keyId.keyId);
        c = (c = a.keyData) == null ? void 0 : c.keyData;
        e = d("WALongInt").maybeNumberOrThrowIfTooLarge((e = a.keyData) == null ? void 0 : e.timestamp);
        f = (f = a.keyData) == null ? void 0 : (f = f.fingerprint) == null ? void 0 : f.currentIndex;
        g = (g = a.keyData) == null ? void 0 : (g = g.fingerprint) == null ? void 0 : g.deviceIndexes;
        i = (i = a.keyData) == null ? void 0 : (i = i.fingerprint) == null ? void 0 : i.rawId;
        return a.keyData == null || c == null || e == null || f == null || g == null || i == null ? {
            keyId: b,
            type: "orphan"
        } : {
            keyData: {
                fingerprint: {
                    currentIndex: f,
                    deviceIndexes: g,
                    rawId: i
                },
                keyData: d("WASyncdKeyTypes").toSyncKeyData(c),
                keyEpoch: d("WASyncdKeyManagementUtils").getKeyEpoch(b),
                keyId: b,
                timestamp: e
            },
            type: "key"
        }
    }
    g.parseAppStateSyncKeyShare = a
}), 98);
__d("WAConvertAppData", ["WAAppData", "WAArmadilloApplication.pb", "WAJids", "WALogger", "WAMultiDevice.pb", "WAParseAppStateSyncKeyRequest", "WAParseAppStateSyncKeyShare", "WAStanzaUtils", "WASyncdKeyTypes", "WATimeUtils", "decodeProtobuf", "encodeProtobuf", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata type: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata type: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata type: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata type: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata type: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["missing keys in EncryptedBackupsSecrets"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["status in EncryptedBackupsSecretsEpoch has invalid value"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["missing keys in EncryptedBackupsSecretsEpoch"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata sync action type: ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata sync action type: ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No participant in messageKey in message action when it is group chat and message is not fromMe: ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing messageKey in message action: ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unknown appdata sync action type: ", ""]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Missing chatId in chat action: ", ""]);
        u = function() {
            return a
        };
        return a
    }

    function v(a) {
        a = d("WAJids").interpretAndValidateJid(a);
        if (a.jidType === "msgrUser") return a.userJid;
        else if (a.jidType === "group") return a.groupJid;
        else {
            a.jidType;
            throw c("err")("Incorrect jid type: " + a.jidType)
        }
    }

    function w(a) {
        a = d("WAJids").interpretAndValidateJid(a);
        if (a.jidType === "msgrUser") return a.userJid;
        else if (a.jidType === "msgrDevice") return d("WAJids").extractUserJid(a.deviceJid);
        else {
            a.jidType;
            throw c("err")("Incorrect jid type: " + a.jidType)
        }
    }

    function x(a) {
        return a != null ? typeof a === "number" && a > d("WATimeUtils").MAX_INT ? d("WATimeUtils").castMilliSecondsToUnixTime(a) : d("WATimeUtils").castLongIntToUnixTime(a) : void 0
    }

    function y(a) {
        return a == null ? void 0 : {
            lastMessageTimestamp: x(a.lastMessageTimestamp),
            lastSystemMessageTimestamp: x(a.lastSystemMessageTimestamp),
            messages: a.messages == null ? [] : a.messages.map(function(a) {
                return {
                    key: a.key == null ? void 0 : {
                        fromMe: a.key.fromMe,
                        id: a.key.id
                    },
                    ts: x(a.timestamp)
                }
            })
        }
    }

    function z(a, b) {
        var c = a.chatId;
        if (c == null) {
            d("WALogger").WARN(u(), a);
            return null
        }
        if (a.chatArchive != null) {
            var e = a.chatArchive;
            e = y(e.messageRange);
            return {
                chatJid: v(c),
                messageRange: e,
                ts: b,
                type: "chat_archive"
            }
        } else if (a.chatDelete != null) {
            e = a.chatDelete;
            e = y(e.messageRange);
            return {
                chatJid: v(c),
                messageRange: e,
                ts: b,
                type: "chat_delete"
            }
        } else if (a.chatRead != null) {
            e = a.chatRead;
            var f = y(e.messageRange);
            return {
                chatJid: v(c),
                messageRange: f,
                read: e.read,
                ts: b,
                type: "chat_read"
            }
        } else {
            d("WALogger").WARN(t(), a);
            return null
        }
    }

    function A(a) {
        var b = a.key,
            c = b == null ? void 0 : b.remoteJid,
            e = b == null ? void 0 : b.id,
            f = b == null ? void 0 : b.fromMe;
        if (b == null || c == null || f == null || e == null) {
            d("WALogger").WARN(s(), a);
            return null
        }
        var g = v(c),
            h = d("WAJids").interpretAsGroupJid(g) != null;
        if (h && !f) {
            if ((b == null ? void 0 : b.participant) == null) {
                d("WALogger").WARN(r(), a);
                return null
            }
            h = w(b.participant)
        } else f ? h = d("WAJids").AUTHOR_ME : h = w(c);
        b = {
            author: h,
            chat: g,
            externalId: d("WAStanzaUtils").toStanzaId(e)
        };
        if (a.messageDelete != null) return {
            protocolMsgId: b,
            type: "delete_for_me"
        };
        else {
            d("WALogger").WARN(q(), a);
            return null
        }
    }

    function B(a) {
        var b = [];
        for (var c = 0; c < a.length; c++) {
            var e = a[c],
                f = x(e.actionTimestamp);
            if (e.chatAction != null) {
                f = z(e.chatAction, f);
                f != null && b.push({
                    chatAction: f
                })
            } else if (e.messageAction != null) {
                f = A(e.messageAction);
                f != null && b.push({
                    messageAction: f
                })
            } else d("WALogger").WARN(p(), e)
        }
        return b
    }

    function C(a) {
        var b = a.anonId,
            c = a.id,
            e = a.rootKey;
        a = a.status;
        if (a == null || c == null || b == null || e == null) {
            d("WALogger").WARN(o());
            return null
        }
        var f;
        if (a === d("WAArmadilloApplication.pb").ARMADILLO_SIGNAL_ENCRYPTED_BACKUPS_SECRETS_EPOCH_EPOCH_STATUS.ES_OPEN) f = d("WAAppData").EPOCH_STATUS_OPEN;
        else if (a === d("WAArmadilloApplication.pb").ARMADILLO_SIGNAL_ENCRYPTED_BACKUPS_SECRETS_EPOCH_EPOCH_STATUS.ES_CLOSE) f = d("WAAppData").EPOCH_STATUS_CLOSE;
        else {
            d("WALogger").WARN(n());
            return null
        }
        return {
            anonId: b,
            id: c,
            rootKey: e,
            status: f
        }
    }

    function D(a) {
        var b = a.backupId,
            c = a.epoch,
            e = a.mailboxRootKey,
            f = a.obliviousValidationToken,
            g = a.serverDataId;
        a = a.tempOcmfClientState;
        if (b == null || g == null || a == null || e == null || f == null) {
            d("WALogger").WARN(m());
            return null
        }
        return {
            backupId: b,
            epoch: c.map(C).reduce(function(a, b) {
                if (b != null) return a.concat([b]);
                else return a
            }, []),
            mailboxRootKey: e,
            obliviousValidationToken: f,
            serverDataId: g,
            tempOcmfClientState: a
        }
    }

    function E(a) {
        var b;
        if (((b = a.applicationData) == null ? void 0 : (b = b.metadataSync) == null ? void 0 : b.actions) != null) {
            return {
                actions: B((b = a.applicationData) == null ? void 0 : (b = b.metadataSync) == null ? void 0 : b.actions),
                type: "meta_sync"
            }
        } else if (((b = a.signal) == null ? void 0 : b.encryptedBackupsSecrets) != null) {
            b = D(a.signal.encryptedBackupsSecrets);
            return b == null ? null : {
                encryptedBackupsSecrets: b,
                type: "backups_secrets"
            }
        } else {
            d("WALogger").WARN(l(), a);
            return null
        }
    }

    function F(a) {
        var b;
        if (((b = a.applicationData) == null ? void 0 : b.appStateSyncKeyShare) != null) {
            return {
                syncKeyShare: d("WAParseAppStateSyncKeyShare").parseAppStateSyncKeyShare((b = a.applicationData) == null ? void 0 : b.appStateSyncKeyShare),
                type: "sync_key_share"
            }
        } else if (((b = a.applicationData) == null ? void 0 : b.appStateSyncKeyRequest) != null) {
            return {
                syncKeyRequest: d("WAParseAppStateSyncKeyRequest").parseAppStateSyncKeyRequest((b = a.applicationData) == null ? void 0 : b.appStateSyncKeyRequest),
                type: "sync_key_request"
            }
        } else {
            d("WALogger").WARN(k(), a);
            return null
        }
    }

    function a(a) {
        if (a.subprotocolType === "armadillo") {
            var b = d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAArmadilloApplication.pb").ArmadilloSpec, a.payload);
            if (b.payload == null) throw c("err")("Appdata contains unparseable armadillo data.");
            return E(b.payload)
        } else if (a.subprotocolType === "multiDevice") {
            b = d("decodeProtobuf").decodeProtobufWithUnknowns(d("WAMultiDevice.pb").MultiDeviceSpec, a.payload);
            if (b.payload == null) throw c("err")("Appdata contains unparseable armadillo data.");
            return F(b.payload)
        } else throw c("err")("Appdata contains unexpected message application: " + a.subprotocolType)
    }

    function G(a) {
        return a == null ? void 0 : {
            lastMessageTimestamp: a.lastMessageTimestamp,
            lastSystemMessageTimestamp: a.lastSystemMessageTimestamp,
            messages: a.messages.map(function(a) {
                return {
                    key: a.key == null ? void 0 : {
                        fromMe: a.key.fromMe,
                        id: a.key.id
                    },
                    timestamp: a.ts
                }
            })
        }
    }

    function H(a) {
        switch (a.type) {
            case "meta_sync":
                return {
                    payload: {
                        applicationData: P(a)
                    }
                };
            case "backups_secrets":
                return {
                    payload: {
                        signal: {
                            encryptedBackupsSecrets: N(a.encryptedBackupsSecrets)
                        }
                    }
                };
            default:
                a.type;
                d("WALogger").WARN(j(), a.type);
                return {}
        }
    }

    function I(a) {
        return {
            keyId: d("WASyncdKeyTypes").fromSyncKeyId(a)
        }
    }

    function J(a) {
        return {
            keyData: {
                fingerprint: {
                    currentIndex: a.fingerprint.currentIndex,
                    deviceIndexes: a.fingerprint.deviceIndexes,
                    rawId: a.fingerprint.rawId
                },
                keyData: d("WASyncdKeyTypes").fromSyncKeyData(a.keyData),
                timestamp: a.timestamp
            },
            keyId: I(a.keyId)
        }
    }

    function K(a) {
        var b = a.keys.map(J);
        a = a.orphanKeys == null ? [] : a.orphanKeys.map(function(a) {
            return {
                keyId: I(a)
            }
        });
        b.push.apply(b, a);
        return {
            keys: b
        }
    }

    function L(a) {
        return {
            keyIds: a.keyIds.map(I)
        }
    }

    function M(a) {
        switch (a.type) {
            case "sync_key_share":
                return {
                    payload: {
                        applicationData: {
                            appStateSyncKeyShare: K(a.syncKeyShare)
                        }
                    }
                };
            case "sync_key_request":
                return {
                    payload: {
                        applicationData: {
                            appStateSyncKeyRequest: L(a.syncKeyRequest)
                        }
                    }
                };
            default:
                a.type;
                d("WALogger").WARN(i(), a.type);
                return {}
        }
    }

    function b(a) {
        var b;
        switch (a.type) {
            case "meta_sync":
            case "backups_secrets":
                var c = d("encodeProtobuf").encodeProtobuf(d("WAArmadilloApplication.pb").ArmadilloSpec, H(a));
                b = {
                    armadillo: {
                        payload: c.readByteArray(),
                        version: 1
                    }
                };
                break;
            case "sync_key_share":
            case "sync_key_request":
                c = d("encodeProtobuf").encodeProtobuf(d("WAMultiDevice.pb").MultiDeviceSpec, M(a));
                b = {
                    multiDevice: {
                        payload: c.readByteArray(),
                        version: 1
                    }
                };
                break;
            default:
                a.type, d("WALogger").WARN(h(), a.type), b = {}
        }
        return {
            payload: {
                subProtocol: b
            }
        }
    }

    function N(a) {
        return {
            backupId: a.backupId,
            epoch: a.epoch.map(O),
            mailboxRootKey: a.mailboxRootKey,
            obliviousValidationToken: a.obliviousValidationToken,
            serverDataId: a.serverDataId,
            tempOcmfClientState: a.tempOcmfClientState
        }
    }

    function O(a) {
        var b;
        a.status === d("WAAppData").EPOCH_STATUS_OPEN ? b = d("WAArmadilloApplication.pb").ARMADILLO_SIGNAL_ENCRYPTED_BACKUPS_SECRETS_EPOCH_EPOCH_STATUS.ES_OPEN : a.status === d("WAAppData").EPOCH_STATUS_CLOSE && (b = d("WAArmadilloApplication.pb").ARMADILLO_SIGNAL_ENCRYPTED_BACKUPS_SECRETS_EPOCH_EPOCH_STATUS.ES_CLOSE);
        return {
            anonId: a.anonId,
            id: a.id,
            rootKey: a.rootKey,
            status: b
        }
    }

    function P(a) {
        return {
            metadataSync: {
                actions: a.actions.map(function(a) {
                    if (a.chatAction) return {
                        actionTimestamp: a.chatAction.ts,
                        chatAction: Q(a.chatAction)
                    };
                    else return {
                        messageAction: R(a.messageAction)
                    }
                })
            }
        }
    }

    function Q(a) {
        var b = G(a.messageRange),
            c = a.chatJid;
        switch (a.type) {
            case "chat_archive":
                return {
                    chatArchive: {
                        archived: a.archived,
                        messageRange: b
                    },
                    chatId: c
                };
            case "chat_delete":
                return {
                    chatDelete: {
                        messageRange: b
                    },
                    chatId: c
                };
            default:
                a.type;
                return {
                    chatId: c,
                    chatRead: {
                        messageRange: b,
                        read: a.read
                    }
                }
        }
    }

    function R(a) {
        if (a.type === "delete_for_me") {
            var b = a.protocolMsgId.chat,
                e = d("WAJids").interpretAsGroupJid(b) != null;
            return {
                key: {
                    fromMe: d("WAJids").isAuthorMe(a.protocolMsgId.author),
                    id: a.protocolMsgId.externalId,
                    participant: !d("WAJids").isAuthorMe(a.protocolMsgId.author) && e ? a.protocolMsgId.author : void 0,
                    remoteJid: b
                },
                messageDelete: {}
            }
        } else throw c("err")("No other available type")
    }
    g.parseArmadilloAppData = E;
    g.parseMultiDeviceAppData = F;
    g.parseAppData = a;
    g.convertArmadilloAppData = H;
    g.convertMultiDeviceAppData = M;
    g.convertAppData = b
}), 98);
__d("WADecimalStringMod", ["WALogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is over 64 bits']);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(['"', '" is not a valid decimal string']);
        i = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        if (!/^\d+$/.test(a)) {
            d("WALogger").ERROR(i(), a);
            throw c("err")("decimalStringMod is given an invalid decimal string")
        }
        var e = a.length;
        if (e < 16 || e === 16 && a <= "9007199254740991") return Number(a) % b;
        if (e > 20 || e === 20 && a > "18446744073709551615") {
            d("WALogger").ERROR(h(), a);
            throw c("err")("decimalStringMod is given value over 64 bits")
        }
        e = 0;
        for (var f = 0; f < a.length; f++) {
            var g = Number(a[f]);
            e = (e * 10 + g) % b
        }
        return e
    }
    g.decimalStringMod = a
}), 98);
__d("WACreateGetVcaEnabledBucket", ["WAArrayBufferUtils", "WADecimalStringMod", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["mediaRouteSelection: can't get fbId from mediaDirectPath"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return function() {
            return b == null ? null : d("WAArrayBufferUtils").arrayBufferMod(a, b) + 100
        }
    }

    function b(a, b) {
        return function() {
            if (b == null) return null;
            var c = a.split("/");
            c = c[c.length - 1];
            c = c.split("_")[1];
            if (!/^\d+$/.test(c)) return null;
            if (c == null) {
                d("WALogger").ERROR(h());
                return null
            } else return d("WADecimalStringMod").decimalStringMod(c, b) + 100
        }
    }
    g.createGetVcaEnabledBucket = a;
    g.msgrCreateGetVcaEnabledBucket = b
}), 98);
__d("WACreateGroup", ["WADbPersonalSenderKeyStatusTxns", "WAGlobals", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            yield d("WAGlobals").getDependencies().createGroups(a), yield d("WADbPersonalSenderKeyStatusTxns").bulkPutNewPersonalSenderKeyStatus(a.map(function(a) {
                return a.groupToCreate.jid
            }))
        });
        return function(b) {
            return a.apply(this, arguments)
        }
    }();
    g.createGroups = a
}), 98);
__d("WATypedArraysConcat", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        c === void 0 && (c = 0);
        c = b.reduce(function(a, b) {
            return a + b.length
        }, c);
        var d = new a(c),
            e = 0;
        b.forEach(function(a) {
            d.set(a, e), e += a.length
        });
        return d
    }
    f.concatTypedArrays = a
}), 66);
__d("WACryptoAesCbc", ["Promise", "WABinary", "WACryptoDependencies", "WATypedArraysCast", "WATypedArraysConcat", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = 16,
        j = 1024,
        k = 16,
        l = 1024 * 1024,
        m = i * l;
    l = function() {
        function a(a, b, c, e) {
            this.$4 = null;
            this.$6 = !1;
            this.$1 = a;
            this.$2 = b;
            this.$3 = c;
            var f = {
                name: "AES-CBC",
                iv: e
            };
            this.$5 = d("WACryptoDependencies").getCrypto().subtle.importKey("raw", c, "AES-CBC", !1, [b]).then(function(a) {
                return {
                    algo: f,
                    key: a
                }
            })
        }
        var b = a.prototype;
        b.append = function(a) {
            var b = this;
            this.$7("append");
            var c = this.$4;
            if (c) {
                c.writeByteArray(a);
                if (c.size() > j) {
                    var e = c.size() % i;
                    e = c.readByteArray(c.size() - e);
                    c.size() || (this.$4 = null)
                } else e = null
            } else if (a.length > j) {
                c = a.length % i;
                !c ? e = a : (this.$4 = new(d("WABinary").Binary)(a), e = this.$4.readByteArray(a.length - c))
            } else this.$4 = new(d("WABinary").Binary)(a), e = null;
            var f = e;
            f && (this.$5 = this.$5.then(function(a) {
                var c = a.key;
                a = a.algo;
                if (b.$2 === "encrypt") return d("WACryptoDependencies").getCrypto().subtle.encrypt(a, c, f).then(function(a) {
                    b.$1.writeByteArray(new Uint8Array(a, 0, a.byteLength - i));
                    return new Uint8Array(a, a.byteLength - 2 * i, i)
                });
                else {
                    var e = f.slice(-i);
                    return d("WACryptoDependencies").getCrypto().subtle.decrypt(a, c, f).then(function(a) {
                        b.$1.writeBuffer(a);
                        return e
                    })
                }
            }).then(function(a) {
                var c = {
                    name: "AES-CBC",
                    iv: a
                };
                return d("WACryptoDependencies").getCrypto().subtle.importKey("raw", b.$3, "AES-CBC", !1, [b.$2]).then(function(a) {
                    return {
                        algo: c,
                        key: a
                    }
                })
            }));
            return this.$5.then(function() {})
        };
        b.finalize = function(a) {
            var b = this;
            this.$7("finalize");
            var c;
            if (this.$4) {
                var e = this.$4;
                a && e.writeByteArray(a);
                c = e.readByteArray();
                this.$4 = null
            } else a && (c = a);
            if (c) {
                var f = c;
                return this.$5.then(function(a) {
                    var c = a.algo;
                    a = a.key;
                    if (b.$2 === "encrypt") return d("WACryptoDependencies").getCrypto().subtle.encrypt(c, a, f);
                    else return d("WACryptoDependencies").getCrypto().subtle.decrypt(c, a, f)
                }).then(function(a) {
                    b.$1.writeBuffer(a)
                })
            } else return this.$5.then(function() {})
        };
        b.$7 = function(a) {
            if (this.$6) throw c("err")("AesCbcStream." + a + " called after finalize")
        };
        return a
    }();

    function n(a) {
        return {
            name: "AES-CBC",
            iv: d("WATypedArraysCast").castTypedArrays(Uint8Array, a)
        }
    }

    function o(a) {
        return d("WACryptoDependencies").getCrypto().subtle.importKey("raw", d("WATypedArraysCast").castTypedArrays(Uint8Array, a), "AES-CBC", !1, ["encrypt"])
    }

    function p(a) {
        if (a) return d("WATypedArraysCast").castTypedArrays(Uint8Array, a);
        a = new Uint8Array(k);
        d("WACryptoDependencies").getCrypto().getRandomValues(a);
        return a
    }

    function q(a) {
        a = a.byteLength;
        var b = i - a % i;
        return Number.isNaN(b) ? a : a + b
    }

    function r(a, c, e) {
        var f = n(c);
        return (h || (h = b("Promise"))).resolve(d("WACryptoDependencies").getCrypto().subtle.importKey("raw", d("WATypedArraysCast").castTypedArrays(Uint8Array, a), "AES-CBC", !1, ["decrypt"])).then(function(a) {
            return d("WACryptoDependencies").getCrypto().subtle.decrypt(f, a, e)
        })
    }

    function a(a, c) {
        return (h || (h = b("Promise"))).resolve().then(function() {
            var b = c.slice(0, k),
                d = c.slice(k);
            return r(a, b, d)
        })
    }

    function e(a, c, e) {
        return (h || (h = b("Promise"))).resolve().then(function() {
            var f = p(e),
                g = n(f);
            return (h || (h = b("Promise"))).resolve(o(a)).then(function(a) {
                return d("WACryptoDependencies").getCrypto().subtle.encrypt(g, a, c)
            }).then(function(a) {
                return d("WATypedArraysConcat").concatTypedArrays(Uint8Array, [f, new Uint8Array(a)]).buffer
            })
        })
    }

    function f(a, d, e, f) {
        var g, h, j, k, l, n, r, t, u, v, w, x, y;
        return b("regeneratorRuntime").async(function(z) {
            while (1) switch (z.prev = z.next) {
                case 0:
                    f === void 0 && (f = m);
                    if (!(f % i !== 0)) {
                        z.next = 3;
                        break
                    }
                    throw c("err")("chunkSize must be a multiple of " + i + ", " + f + " received");
                case 3:
                    z.next = 5;
                    return b("regeneratorRuntime").awrap(o(a));
                case 5:
                    g = z.sent, h = new Uint8Array(d), j = Math.ceil(h.byteLength / f), k = p(e), l = new Uint8Array(q(h) + k.byteLength), l.set(k), (n = 0, r = k);
                case 12:
                    if (!(n < j)) {
                        z.next = 26;
                        break
                    }
                    u = n === j - 1;
                    v = n * f;
                    t = h.subarray(v, v + f);
                    z.next = 18;
                    return b("regeneratorRuntime").awrap(s(u, t, r, g));
                case 18:
                    w = z.sent, x = w.encryptedChunk, y = w.nextIv, l.set(x, k.byteLength + n * f), r = y;
                case 23:
                    n++;
                    z.next = 12;
                    break;
                case 26:
                    return z.abrupt("return", l.buffer);
                case 27:
                case "end":
                    return z.stop()
            }
        }, null, this)
    }

    function s(a, c, e, f) {
        var g, h;
        return b("regeneratorRuntime").async(function(j) {
            while (1) switch (j.prev = j.next) {
                case 0:
                    j.next = 2;
                    return b("regeneratorRuntime").awrap(d("WACryptoDependencies").getCrypto().subtle.encrypt(n(e), f, c).then(function(b) {
                        return a ? new Uint8Array(b) : new Uint8Array(b).subarray(0, -i)
                    }));
                case 2:
                    g = j.sent;
                    h = g.slice(-i);
                    return j.abrupt("return", {
                        encryptedChunk: g,
                        nextIv: h
                    });
                case 5:
                case "end":
                    return j.stop()
            }
        }, null, this)
    }
    g.AES_CBC_BLOCK_SIZE = i;
    g.AesCbcStream = l;
    g.importRawKey = o;
    g.getIv = p;
    g.aesCbcDecrypt = r;
    g.aesCbcDecryptSplit = a;
    g.aesCbcEncrypt = e;
    g.aesCbcEncryptWithChunking = f;
    g.aesCbcEncryptChunk = s
}), 98);
__d("WAMediaCryptoSidecar", ["WAConcurrentIterate", "WACryptoHmac", "WAMediaUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a === "video"
    }
    var h = 16,
        i = 10,
        j = 64 * 1024;

    function b(a, b, c) {
        c === void 0 && (c = 1);
        var e = b.buffer.byteLength;
        e = Math.ceil((e - h) / j);
        var f = new Uint8Array(i * e);
        return d("WAConcurrentIterate").concurrentIterate(e, function(c) {
            var e = c * j,
                g = e + h + j;
            e = b.subarray(e, g);
            return d("WACryptoHmac").sign(a, e).then(function(a) {
                a = new Uint8Array(a, 0, i);
                f.set(a, c * i)
            })
        }, c).then(function() {
            return d("WAMediaUtils").castToStreamingSidecar(f.buffer)
        })
    }
    g.shouldHaveStreamingSidecar = a;
    g.calculateStreamingSidecar = b
}), 98);
__d("WAMediaHkdfInfo", ["err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a) {
            case "document":
                return "WhatsApp Document Keys";
            case "image":
            case "sticker":
            case "xma-image":
                return "WhatsApp Image Keys";
            case "video":
            case "gif":
                return "WhatsApp Video Keys";
            case "audio":
            case "ptt":
                return "WhatsApp Audio Keys";
            case "md-app-state":
                return "WhatsApp App State Keys";
            case "md-msg-hist":
                return "WhatsApp History Keys";
            default:
                throw c("err")("getMediaHkdfInfo: unexpected media type " + a)
        }
    }

    function b() {
        return "Messenger Preview Keys"
    }
    g.getMediaHkdfInfo = a;
    g.getPreviewMediaHkdfInfo = b
}), 98);
__d("WAMediaCrypto", ["Promise", "WABinary", "WACryptoAesCbc", "WACryptoDependencies", "WACryptoHkdf", "WACryptoHmac", "WACryptoSha256", "WACryptoUtils", "WACustomError", "WAHashUtils", "WALogger", "WAMediaCryptoSidecar", "WAMediaHkdfInfo", "WAMediaUtils", "WATagsLogger", "WATypedArraysConcat", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Processing scan ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unable to decrypt partial due to invalid target scan"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["decryptPartialChunks targetScan greater length of scanLength array"]);
        k = function() {
            return a
        };
        return a
    }
    var l = d("WATagsLogger").TAGS(["WAMediaCrypto"]),
        m = d("WACustomError").customError("HmacValidationError", !1),
        n = new Uint8Array([2, 2]);

    function o(a, b) {
        return d("WACryptoHkdf").extractAndExpand(new Uint8Array(a), b, 112).then(function(a) {
            return {
                iv: new Uint8Array(a, 0, 16),
                cipherKey: new Uint8Array(a, 16, 32),
                hmacKey: new Uint8Array(a, 48, 32),
                refKey: new Uint8Array(a, 80, 32)
            }
        })
    }

    function p(a, b) {
        b = d("WAMediaHkdfInfo").getMediaHkdfInfo(b);
        return o(a, b)
    }

    function q(a) {
        var b = d("WAMediaHkdfInfo").getPreviewMediaHkdfInfo();
        return o(a, b)
    }

    function a(a) {
        var c, d, e;
        return b("regeneratorRuntime").async(function(f) {
            while (1) switch (f.prev = f.next) {
                case 0:
                    c = new Map();
                    f.next = 3;
                    return b("regeneratorRuntime").awrap(q(a));
                case 3:
                    d = f.sent;
                    c.set("preview", d);
                    e = ["document", "image", "video", "audio", "md-app-state", "md-msg-hist"];
                    f.next = 8;
                    return b("regeneratorRuntime").awrap((h || (h = b("Promise"))).all(e.map(function(b) {
                        return p(a, b).then(function(a) {
                            c.set(b, a)
                        })
                    })));
                case 8:
                    return f.abrupt("return", c);
                case 9:
                case "end":
                    return f.stop()
            }
        }, null, this)
    }

    function e(a) {
        switch (a) {
            case "image":
            case "video":
                return a;
            default:
                return null
        }
    }
    var r = 16,
        s = 16,
        t = 10,
        u = 64 * 1024;

    function f(a, c, e, f, g) {
        var i, j, k, l, m, n, o, p, q, v, w, x, y, z, A;
        return b("regeneratorRuntime").async(function(B) {
            while (1) switch (B.prev = B.next) {
                case 0:
                    i = new(d("WABinary").Binary)(), i.ensureCapacity(s + f.size + r + t), i.writeByteArray(c), j = new(d("WACryptoAesCbc").AesCbcStream)(i, "encrypt", a, c), k = 0, l = k + u;
                case 6:
                    if (!(l < f.size)) {
                        B.next = 17;
                        break
                    }
                    m = f.slice(k, l);
                    B.next = 10;
                    return b("regeneratorRuntime").awrap(d("WAMediaUtils").blobToArrayBuffer(m));
                case 10:
                    n = B.sent;
                    B.next = 13;
                    return b("regeneratorRuntime").awrap(j.append(new Uint8Array(n)));
                case 13:
                    k = l;
                    l += u;
                    B.next = 6;
                    break;
                case 17:
                    B.next = 19;
                    return b("regeneratorRuntime").awrap(d("WAMediaUtils").blobToArrayBuffer(f.slice(k)));
                case 19:
                    o = B.sent;
                    B.next = 22;
                    return b("regeneratorRuntime").awrap(j.finalize(new Uint8Array(o)));
                case 22:
                    p = i.peek(function(a) {
                        return a.readByteArray()
                    });
                    B.next = 25;
                    return b("regeneratorRuntime").awrap(d("WACryptoHmac").encodeKeySha256(e));
                case 25:
                    q = B.sent;
                    B.next = 28;
                    return b("regeneratorRuntime").awrap(d("WACryptoHmac").sign(q, p));
                case 28:
                    v = B.sent;
                    i.writeByteArray(new Uint8Array(v, 0, t));
                    w = i.readByteArray();
                    x = w.subarray(s);
                    B.next = 34;
                    return b("regeneratorRuntime").awrap((h || (h = b("Promise"))).all([d("WACryptoDependencies").getCrypto().subtle.digest("SHA-256", x), d("WAMediaCryptoSidecar").shouldHaveStreamingSidecar(g) ? d("WAMediaCryptoSidecar").calculateStreamingSidecar(q, w) : void 0]));
                case 34:
                    y = B.sent;
                    z = y[0];
                    A = y[1];
                    return B.abrupt("return", {
                        ciphertext: x,
                        ciphertextHash: z,
                        sidecar: A,
                        ivCiphertext: p,
                        ivCiphertextHmac: w
                    });
                case 38:
                case "end":
                    return B.stop()
            }
        }, null, this)
    }

    function v(a, c, e) {
        var f, g;
        return b("regeneratorRuntime").async(function(h) {
            while (1) switch (h.prev = h.next) {
                case 0:
                    h.next = 2;
                    return b("regeneratorRuntime").awrap(d("WACryptoHmac").encodeKeySha256(a));
                case 2:
                    f = h.sent;
                    g = d("WABinary").Binary.build(c, e).readByteArray();
                    return h.abrupt("return", d("WACryptoHmac").sign(f, g));
                case 5:
                case "end":
                    return h.stop()
            }
        }, null, this)
    }

    function w(a, c, e, f, g) {
        var h, i, j, k, l;
        return b("regeneratorRuntime").async(function(n) {
            while (1) switch (n.prev = n.next) {
                case 0:
                    if (10 <= g.length && g.length <= 32) {
                        n.next = 2;
                        break
                    }
                    throw new m("Bad hmac size " + g.length);
                case 2:
                    h = d("WABinary").Binary.build(c, e).readByteArray();
                    n.next = 5;
                    return b("regeneratorRuntime").awrap(d("WACryptoHmac").hmacSha256(f, h).then(function(a) {
                        return new Uint8Array(a)
                    }));
                case 5:
                    i = n.sent;
                    j = i.slice(0, g.length);
                    if (A(j, g)) {
                        n.next = 9;
                        break
                    }
                    throw new m("hmacAndDecrypt hmac mismatch");
                case 9:
                    n.next = 11;
                    return b("regeneratorRuntime").awrap(d("WACryptoAesCbc").aesCbcDecrypt(a, c, e));
                case 11:
                    k = n.sent;
                    n.next = 14;
                    return b("regeneratorRuntime").awrap(d("WACryptoDependencies").getCrypto().subtle.digest("SHA-256", k));
                case 14:
                    l = n.sent;
                    return n.abrupt("return", {
                        plaintextHash: d("WAHashUtils").toPlaintextHash(l),
                        plaintext: k
                    });
                case 16:
                case "end":
                    return n.stop()
            }
        }, null, this)
    }

    function x(a, b, c, e, f) {
        if (!(10 <= f.length && f.length <= 32)) throw new m("Bad hmac size " + f.length);
        var g = d("WATypedArraysConcat").concatTypedArrays(Uint8Array, [b, c]);
        return d("WACryptoHmac").hmacSha256(e, g, f.length).then(function(a) {
            return new Uint8Array(a)
        }).then(function(a) {
            if (!d("WACryptoUtils").uint8ArraysEqual(a, f)) throw new m("hmacAndDecrypt hmac mismatch")
        }).then(function() {
            var a = c.byteLength % r === t;
            if (a === !0) return c.subarray(0, -10);
            else return c
        }).then(function(c) {
            return y(a, b, c)
        })
    }

    function y(a, b, c) {
        var e = c.subarray(-r);
        return d("WACryptoAesCbc").aesCbcEncrypt(a, n, e).then(function(a) {
            return a.slice(s)
        }).then(function(a) {
            return d("WABinary").Binary.build(c, a).readByteArray()
        }).then(function(c) {
            return d("WACryptoAesCbc").aesCbcDecrypt(a, b, c)
        }).then(function(a) {
            return new Uint8Array(a, 0, a.byteLength - n.byteLength)
        }).then(function(a) {
            return {
                plaintext: a,
                nextIv: e
            }
        })
    }

    function z(a, e, f, g, h, m) {
        var n, o, p, q, r, s, t, u, v, w, y, z, A, B, C, D;
        return b("regeneratorRuntime").async(function(E) {
            while (1) switch (E.prev = E.next) {
                case 0:
                    h > m.scanLengths.length && l.ERROR(k());
                    n = Math.min(h, m.scanLengths.length);
                    if (!(n < 1)) {
                        E.next = 5;
                        break
                    }
                    l.ERROR(j());
                    throw c("err")("Unable to decrypt partial due to invalid target scan");
                case 5:
                    o = new(d("WABinary").Binary)();
                    p = [];
                    for (q = 0; q < n; q++) p.push(new Uint8Array(m.sidecar, q * 10, 10));
                    r = 0;
                    s = e;
                    t = 0;
                    u = 0;
                case 12:
                    if (!(u < n)) {
                        E.next = 29;
                        break
                    }
                    d("WALogger").DEV(i(), u);
                    v = m.alignedScanLengths[u];
                    w = r + v;
                    y = f.subarray(r, w);
                    E.next = 19;
                    return b("regeneratorRuntime").awrap(x(a, s, y, g, p[u]));
                case 19:
                    z = E.sent, A = z.plaintext, B = z.nextIv, o.write(A), r += v, s = B, t += m.scanLengths[u];
                case 26:
                    u++;
                    E.next = 12;
                    break;
                case 29:
                    C = o.readBuffer(t);
                    E.next = 32;
                    return b("regeneratorRuntime").awrap(d("WACryptoSha256").sha256(C));
                case 32:
                    D = E.sent;
                    return E.abrupt("return", {
                        plaintextHash: d("WAHashUtils").toPlaintextHash(D),
                        plaintext: C
                    });
                case 34:
                case "end":
                    return E.stop()
            }
        }, null, this)
    }

    function A(a, b) {
        if (a.length !== b.length) return !1;
        var c = 1,
            d = a.length;
        for (var e = 0; e < d; e++) c &= a[e] === b[e] ? 1 : 0;
        return c !== 0
    }
    g.HmacValidationError = m;
    g.DEFAULT_PADDING = n;
    g.computeMediaKeys = p;
    g.computeMediaKeysForPreview = q;
    g.deprecated_getAllCommonComputedMediaKeys = a;
    g.convertServerMediaTypeToPreviewMediaType = e;
    g.CBC_BLOCK_SIZE = r;
    g.IV_LENGTH = s;
    g.HMAC_LENGTH = t;
    g.encryptAndHmac = f;
    g.hmacCiphertext = v;
    g.hmacAndDecrypt = w;
    g.hmacAndDecryptPartial = x;
    g.decryptPartialChunks = z
}), 98);
__d("WACreateMediaDecrypterStream", ["WABinary", "WAMediaCrypto", "WAResultOrError", "WATagsLogger", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Invalid PKCS padding length"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Plaintext size is less than CBC_BLOCK_SIZE"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unexpected ciphertext in buffer following flush"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Unable to decrypt chunk. isLastChunk: ", " error: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Processing scan ", " of size ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["expectedHmacs and ciphertextLengths must have the same length"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["expectedHmacs must have at least one element"]);
        n = function() {
            return a
        };
        return a
    }
    var o = d("WATagsLogger").TAGS(["WADecryptStream"]);

    function a(a, c, e, f, g) {
        if (f.byteLength === 0) {
            o.ERROR(n());
            return d("WAResultOrError").makeError("missing-expected-hmacs")
        }
        if (f.byteLength !== g.length * d("WAMediaCrypto").HMAC_LENGTH) {
            o.ERROR(m());
            return d("WAResultOrError").makeError("hmac-chiphertext-array-mismatch")
        }
        var h = p(f),
            i = c,
            r = new(d("WABinary").Binary)(),
            s = 0,
            t = function() {
                var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b, c) {
                    r.writeByteArray(b);
                    for (; s < h.length && r.size() >= g[s]; s++) {
                        b = r.readByteArray(g[s]);
                        o.DEV(l(), s, b.length);
                        var f = s === g.length - 1;
                        try {
                            b = (yield d("WAMediaCrypto").hmacAndDecryptPartial(a, i, b, e, h[s]));
                            var j = b.plaintext;
                            b = b.nextIv;
                            f ? void c.enqueue(q(j)) : void c.enqueue(j);
                            i = b
                        } catch (a) {
                            o.ERROR(k(), f, a), a instanceof d("WAMediaCrypto").HmacValidationError ? c.error("enc-hash-mismatch") : c.error("decryption-error")
                        }
                    }
                });
                return function(a, b) {
                    return c.apply(this, arguments)
                }
            }();
        f = new TransformStream({
            transform: function(a, b) {
                a = a;
                return t(a, b)
            },
            flush: function(a) {
                r.size() > 0 && o.ERROR(j())
            }
        });
        return d("WAResultOrError").makeResult(f)
    }

    function p(a) {
        var b = [];
        if (a.byteLength % d("WAMediaCrypto").HMAC_LENGTH !== 0) throw c("err")("Sidecar length is not a multiple of hmac length");
        for (var e = 0; e < a.byteLength; e += d("WAMediaCrypto").HMAC_LENGTH) {
            var f = new Uint8Array(a, e, d("WAMediaCrypto").HMAC_LENGTH);
            b.push(f)
        }
        return b
    }

    function q(a) {
        if (a.length < d("WAMediaCrypto").CBC_BLOCK_SIZE) {
            o.ERROR(i());
            return a
        }
        var b = a[a.length - 1];
        if (b === 0 || b > d("WAMediaCrypto").CBC_BLOCK_SIZE) {
            o.ERROR(h());
            return a
        }
        return a.subarray(0, -b)
    }
    g.createDefaultDecryptStream = a
}), 98);
__d("WAExtractNcHotTimestamp", ["WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a == null) return null;
        a = h(a);
        if (a.has("_nc_hot")) {
            a = parseInt(a.get("_nc_hot"), 10);
            return Number.isInteger(a) ? d("WATimeUtils").castToUnixTime(a) : null
        } else return null
    }

    function h(a) {
        a = a.split("?");
        return new URLSearchParams(a.length === 2 ? a[1] : "")
    }
    g.extractNcHotTimestamp = a
}), 98);
__d("WAMediaConnParser", ["WADeprecatedWapParser", "WAServerMediaType"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = new(c("WADeprecatedWapParser"))("mediaConnParser", function(a) {
        a = a.child("media_conn");
        var b = j(a);
        return {
            hosts: b,
            authToken: a.attrString("auth"),
            authTokenExpiryTs: a.attrFutureTime("auth_ttl"),
            routesExpiryTs: a.attrFutureTime("ttl"),
            maxBuckets: a.attrInt("max_buckets"),
            maxManualRetry: (b = a.maybeAttrInt("max_manual_retry", 0, 4)) != null ? b : 3,
            maxAutoDownloadRetry: (b = a.maybeAttrInt("max_auto_download_retry", 0, 4)) != null ? b : 3
        }
    });

    function h(a) {
        var b;
        return !a.hasAttr("fallback_hostname") ? void 0 : {
            domain: a.attrString("fallback_hostname"),
            "class": a.maybeAttrString("fallback_class"),
            ip4: (b = a.maybeAttrString("fallback_ip4")) != null ? b : void 0,
            ip6: (b = a.maybeAttrString("fallback_ip6")) != null ? b : void 0
        }
    }

    function i(a) {
        var b;
        return {
            domain: a.attrString("hostname"),
            fallback: h(a),
            uploadable: k(a, "upload"),
            downloadable: k(a, "download"),
            isFallback: a.maybeAttrString("type") === "fallback",
            downloadBuckets: (b = (b = a.maybeChild("download_buckets")) == null ? void 0 : b.mapChildren(function(a) {
                return parseInt(a.tag(), 10)
            })) != null ? b : [],
            "class": a.maybeAttrString("class"),
            ip4: (b = a.maybeAttrString("ip4")) != null ? b : void 0,
            ip6: (b = a.maybeAttrString("ip6")) != null ? b : void 0
        }
    }

    function j(a) {
        return a.mapChildrenWithTag("host", i)
    }

    function k(a, b) {
        if (a.hasChild(b)) return a.child(b).mapChildren(function(a) {
            a = a.tag();
            return d("WAServerMediaType").castToServerMediaType(a)
        }).filter(Boolean);
        else return d("WAServerMediaType").SERVER_MEDIA
    }
    g.mediaConnParser = a
}), 98);
__d("WAGatherMediaInfo", ["WADeprecatedSendIq", "WAErrors", "WALogger", "WAMediaConnParser", "WAPromiseManagement", "WAPromiseRetryLoop", "WAResultOrError", "WAWap"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["gatherMediaInfo error ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["gatherMediaInfo got ", " hosts"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["gatherMediaInfo got client error: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["gatherMediaInfo got ", " seconds backoff"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["gatherMediaInfo failure ", ""]);
        l = function() {
            return a
        };
        return a
    }
    var m = 507;
    b = d("WAPromiseManagement").cacheWhilePending(function() {
        return "gatherMediaInfo"
    }, a);

    function a() {
        var a = new(d("WAPromiseRetryLoop").PromiseRetryLoop)({
            name: "gatherMediaInfo",
            timer: {
                jitter: .25,
                max: 987e3,
                algo: {
                    type: "fibonacci",
                    first: 6e3,
                    second: 12e3
                },
                relativeDelay: !0
            },
            code: o
        });
        a.start();
        return a.promise()
    }
    var n = 60;

    function o(a) {
        var b;
        b = (b = d("WAWap")).wap("iq", {
            to: b.S_WHATSAPP_NET,
            xmlns: "w:m",
            type: "set",
            id: b.generateId()
        }, b.wap("media_conn", null));
        return d("WADeprecatedSendIq").deprecatedSendIqIfConnectedWithin(b, d("WAMediaConnParser").mediaConnParser, n).then(function(b) {
            if (!b.success) {
                d("WALogger").LOG(l(), b);
                if (b.errorCode === m) {
                    var c = b.errorBackoff;
                    d("WALogger").LOG(k(), c);
                    a(d("WAResultOrError").makeError({
                        type: "backoff",
                        backoffMs: c * 1e3
                    }))
                } else b.errorCode < 500 && (d("WALogger").LOG(j(), b.errorCode), a(d("WAResultOrError").makeError({
                    type: "client-error",
                    code: b.errorCode,
                    text: b.errorText
                })))
            } else d("WALogger").LOG(i(), b.result.hosts.length), a(d("WAResultOrError").makeResult(b.result))
        })["catch"](function(b) {
            b instanceof d("WAErrors").Disconnected ? a(d("WAResultOrError").makeError("disconnected")) : d("WALogger").ERROR(h(), b)
        })
    }
    g.gatherMediaInfo = b
}), 98);
__d("WAMediaRouteSelection", ["WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = null,
            c = null,
            e = null,
            f = a.hosts,
            g = a.operation,
            h = a.mediaType;
        if (a.operation === "download") {
            var i = a.catHotTimespan,
                j = a.ncHot;
            a = a.getVcaEnabledBucket;
            var k = new Map();
            f.forEach(function(a) {
                a.downloadBuckets.forEach(function(b) {
                    k.set(b, a)
                })
            });
            var l = k.get(0);
            i > 0 && j != null && d("WATimeUtils").happenedWithin(d("WATimeUtils").castToUnixTime(j), i) ? b = 1 : a && (b = a());
            j = null;
            b != null && (j = k.get(b));
            ((i = j) == null ? void 0 : i.downloadable.includes(h)) ? c = j: (l == null ? void 0 : l.downloadable.includes(h)) && (c = l)
        }
        for (a = 0; a < f.length; a++) {
            i = f[a];
            g === "upload" && i.uploadable.includes(h) ? c == null ? c = i : i.isFallback && e == null && (e = i) : g === "download" && i.downloadable.includes(h) && (c == null ? c = i : i.isFallback && e == null && (e = i));
            if (c != null && e != null) break
        }
        return {
            selectedHost: c,
            fallbackHost: e,
            bucket: b
        }
    }
    g.mediaRouteSelection = a
}), 98);
__d("WAGetMediaRoute", ["$InternalEnum", "Promise", "WAComms", "WACreateGetVcaEnabledBucket", "WAExtractNcHotTimestamp", "WAGatherMediaInfo", "WAGlobals", "WAMediaRouteSelection", "WAPromiseManagement", "WAResultOrError", "WATagsLogger", "WATimeUtils", "WAWaitForComms", "WAWorkerGlobalScope", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error occurred on gather after backoff expiry: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Can not get mediaAccess: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["mediaAccess has gone, gather a new one"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["mediaAccess has gone, but we are still locked by backoff"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error occurred during authTTL automatic refresh: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["AuthTTL approaching expiry, refreshing MediaAccess routes"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error: no media host"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to get mediaAccess: ", ""]);
        p = function() {
            return a
        };
        return a
    }
    var q = d("WATagsLogger").TAGS(["GetMediaRoute"]),
        r = !0,
        s = 86400,
        t = b("$InternalEnum")({
            Fresh: "fresh",
            Cached: "cached",
            Stale: "stale"
        }),
        u = null,
        v = !1,
        w = null;

    function a(a, c) {
        var e, f, g, h, i, j, k, l, m, n, t;
        return b("regeneratorRuntime").async(function(u) {
            while (1) switch (u.prev = u.next) {
                case 0:
                    e = "get_cached_or_fresh_media_access_start";
                    f = "get_cached_or_fresh_media_access_end";
                    c == null ? void 0 : c.addPoint(e);
                    u.next = 5;
                    return b("regeneratorRuntime").awrap(A());
                case 5:
                    g = u.sent;
                    c == null ? void 0 : c.addPoint(f);
                    if (g.success) {
                        u.next = 11;
                        break
                    }
                    q.ERROR(p(), g.error);
                    c == null ? void 0 : c.addPoint("get_media_access_failed", {
                        string: {
                            mediaAccessStatus: g.error
                        }
                    });
                    return u.abrupt("return", g);
                case 11:
                    c == null ? void 0 : c.addAnnotations({
                        string: {
                            mediaAccessStatus: g.value.state
                        }
                    });
                    h = g.value.mediaAccess, i = h.authToken, j = h.hosts, k = h.maxBuckets;
                    l = a.operation === "upload" ? d("WAMediaRouteSelection").mediaRouteSelection({
                        operation: "upload",
                        mediaType: a.serverMediaType,
                        hosts: j
                    }) : d("WAMediaRouteSelection").mediaRouteSelection({
                        operation: "download",
                        mediaType: a.serverMediaType,
                        hosts: j,
                        catHotTimespan: s,
                        ncHot: d("WAExtractNcHotTimestamp").extractNcHotTimestamp(a.directPath),
                        getVcaEnabledBucket: r ? d("WACreateGetVcaEnabledBucket").msgrCreateGetVcaEnabledBucket(a.directPath, k) : void 0
                    }), m = l.selectedHost, n = l.fallbackHost, t = l.bucket;
                    if (!(m == null)) {
                        u.next = 17;
                        break
                    }
                    q.ERROR(o());
                    return u.abrupt("return", d("WAResultOrError").makeError("no-host"));
                case 17:
                    return u.abrupt("return", d("WAResultOrError").makeResult({
                        authToken: i,
                        selectedHost: m,
                        fallbackHost: n,
                        bucket: t
                    }));
                case 18:
                case "end":
                    return u.stop()
            }
        }, null, this)
    }

    function x() {
        var a = w;
        a != null && (d("WAWorkerGlobalScope").workerGlobalScope.clearTimeout(a), w = null)
    }

    function y(a) {
        x();
        var b = Math.max(a.authTokenExpiryTs - d("WATimeUtils").unixTime(), 0);
        if (b <= 5 * 60) return;
        var c = d("WATimeUtils").pastUnixTime(5 * 60, a.authTokenExpiryTs);
        b = d("WATimeUtils").pastUnixTime(Math.floor(b * .2), a.authTokenExpiryTs);
        a = c < b ? c : b;
        c = d("WATimeUtils").cappedMillisecondsUntil(a);
        b = Math.floor(Math.random() * d("WATimeUtils").MINUTE_MILLISECONDS);
        a = d("WAWorkerGlobalScope").workerGlobalScope.setTimeout(function() {
            q.LOG(n()), z()["catch"](function(a) {
                q.ERROR(m(), a)
            })
        }, c + b);
        w = a
    }
    var z = d("WAPromiseManagement").cacheWhilePending(function() {
            return "all"
        }, function() {
            var a, c, e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        if (!v) {
                            f.next = 3;
                            break
                        }
                        q.LOG(l());
                        return f.abrupt("return", d("WAResultOrError").makeError("backoff"));
                    case 3:
                        if (!d("WAGlobals").getConfig().mediaWaitsForComms()) {
                            f.next = 8;
                            break
                        }
                        f.next = 6;
                        return b("regeneratorRuntime").awrap(d("WAWaitForComms").waitForComms());
                    case 6:
                        f.next = 11;
                        break;
                    case 8:
                        if (!d("WAGlobals").getConfig().shouldWaitForConnection()) {
                            f.next = 11;
                            break
                        }
                        f.next = 11;
                        return b("regeneratorRuntime").awrap(d("WAComms").waitForConnection());
                    case 11:
                        q.LOG(k());
                        x();
                        f.next = 15;
                        return b("regeneratorRuntime").awrap(d("WAGatherMediaInfo").gatherMediaInfo());
                    case 15:
                        a = f.sent;
                        if (!a.success) {
                            f.next = 22;
                            break
                        }
                        u = a.value;
                        y(a.value);
                        return f.abrupt("return", d("WAResultOrError").makeResult({
                            mediaAccess: a.value,
                            state: t.Fresh
                        }));
                    case 22:
                        c = a.error;
                        e = c === "disconnected" ? "disconnected" : c.type;
                        q.WARN(j(), e);
                        if (!(c === "disconnected" || c.type === "client-error")) {
                            f.next = 29;
                            break
                        }
                        return f.abrupt("return", d("WAResultOrError").makeError("disconnected"));
                    case 29:
                        c.type;
                        v = !0;
                        d("WAWorkerGlobalScope").workerGlobalScope.setTimeout(function() {
                            v = !1, z()["catch"](function(a) {
                                q.ERROR(i(), a)
                            })
                        }, c.backoffMs);
                        return f.abrupt("return", d("WAResultOrError").makeError("backoff"));
                    case 33:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        }),
        A = function() {
            var a = u;
            if (a == null) return z();
            if (d("WATimeUtils").isInFuture(a.routesExpiryTs)) return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult({
                mediaAccess: a,
                state: t.Cached
            }));
            var c = z();
            return d("WATimeUtils").isInFuture(a.authTokenExpiryTs) ? (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult({
                mediaAccess: a,
                state: t.Stale
            })) : c
        };

    function c() {
        u = null, v = !1, x()
    }
    g.getMediaRoute = a;
    g.clearCachedMediaAccessForTest = c
}), 98);
__d("WAMediaOperationsRetrier", ["WALogger", "WAPromiseBackoffs", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["MediaOperationsRetrier:", " wait for internet, attempt = ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Running retrier"]);
        i = function() {
            return a
        };
        return a
    }
    var j = 4,
        k = {
            algo: {
                type: "constant",
                delay: 1e3
            },
            jitter: 0
        };
    a = function() {
        function a(a, b, c) {
            this.$1 = a, this.routesInfo = b, this.$2 = d("WAPromiseBackoffs").createPromiseTimer(k), this.$3 = 0, this.$4 = !1, this.$5 = c
        }
        var c = a.prototype;
        c.run = function(a, c) {
            var e, f, g, k;
            return b("regeneratorRuntime").async(function(l) {
                while (1) switch (l.prev = l.next) {
                    case 0:
                        if (!(this.$3 < j)) {
                            l.next = 29;
                            break
                        }
                        d("WALogger").DEV(i());
                        l.next = 4;
                        return b("regeneratorRuntime").awrap(this.$2());
                    case 4:
                        e = void 0;
                        if (!(this.$3 > 0)) {
                            l.next = 12;
                            break
                        }
                        e = this.$3 >= j - 2 && !this.$4;
                        d("WALogger").LOG(h(), this.$1, this.$3);
                        l.next = 10;
                        return b("regeneratorRuntime").awrap(this.$5 == null ? void 0 : this.$5());
                    case 10:
                        l.next = 13;
                        break;
                    case 12:
                        e = !1;
                    case 13:
                        f = this.routesInfo;
                        if (f) {
                            l.next = 16;
                            break
                        }
                        return l.abrupt("return", null);
                    case 16:
                        g = f.host;
                        e && f.fallbackHost && (g = f.fallbackHost);
                        l.next = 20;
                        return b("regeneratorRuntime").awrap(a(g, f.authToken, this.$3, c));
                    case 20:
                        k = l.sent;
                        if (!k.success) {
                            l.next = 25;
                            break
                        }
                        return l.abrupt("return", k.value);
                    case 25:
                        ++this.$3, this.$4 = k.error.progressMade;
                    case 27:
                        l.next = 0;
                        break;
                    case 29:
                        return l.abrupt("return", null);
                    case 30:
                    case "end":
                        return l.stop()
                }
            }, null, this)
        };
        return a
    }();
    g.MAX_ATTEMPTS = j;
    g.BACKOFF_OPTIONS = k;
    g.MediaOperationsRetrier = a
}), 98);
__d("WACreateMediaDownloadRetrier", ["WAComms", "WAGetMediaRoute", "WAMediaOperationsRetrier", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var c, e, f, g, h, i, j, k, l, m, n;
        return b("regeneratorRuntime").async(function(o) {
            while (1) switch (o.prev = o.next) {
                case 0:
                    c = a.directPath, e = a.eventFlow, f = a.fileEncSha256, g = a.mediaTypeDetails;
                    h = g.type === "regular" ? g.mediaType : "preview";
                    e == null ? void 0 : e.addPoint("get_media_route_start");
                    o.next = 5;
                    return b("regeneratorRuntime").awrap(d("WAGetMediaRoute").getMediaRoute({
                        operation: "download",
                        serverMediaType: h,
                        fileEncSha256: f,
                        directPath: c
                    }, e));
                case 5:
                    i = o.sent;
                    e == null ? void 0 : e.addPoint("get_media_route_finish");
                    if (i.success) {
                        o.next = 9;
                        break
                    }
                    return o.abrupt("return", i);
                case 9:
                    j = i.value, k = j.selectedHost, l = j.fallbackHost, m = j.authToken;
                    n = new(d("WAMediaOperationsRetrier").MediaOperationsRetrier)("download", {
                        host: {
                            domain: k.domain,
                            "class": k["class"]
                        },
                        fallbackHost: l && {
                            domain: l.domain,
                            "class": l["class"]
                        },
                        authToken: m,
                        timeElapsed: null
                    }, d("WAComms").waitForConnection);
                    return o.abrupt("return", d("WAResultOrError").makeResult({
                        retrier: n,
                        mediaRouteDetails: i.value
                    }));
                case 12:
                case "end":
                    return o.stop()
            }
        }, null, this)
    }
    g.createMediaDownloadRetrier = a
}), 98);
__d("WACreateRetrier", ["WAComms", "WAGetMediaRoute", "WAMediaOperationsRetrier", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, c) {
        var e, f, g, h, i, j;
        return b("regeneratorRuntime").async(function(k) {
            while (1) switch (k.prev = k.next) {
                case 0:
                    c == null ? void 0 : c.addPoint("get_media_route_start");
                    k.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAGetMediaRoute").getMediaRoute({
                        operation: "upload",
                        serverMediaType: a
                    }, c));
                case 3:
                    e = k.sent;
                    c == null ? void 0 : c.addPoint("get_media_route_finish");
                    if (e.success) {
                        k.next = 7;
                        break
                    }
                    return k.abrupt("return", e);
                case 7:
                    f = e.value, g = f.selectedHost, h = f.fallbackHost, i = f.authToken;
                    j = new(d("WAMediaOperationsRetrier").MediaOperationsRetrier)("upload", {
                        host: {
                            domain: g.domain,
                            "class": g["class"]
                        },
                        fallbackHost: h && {
                            domain: h.domain,
                            "class": h["class"]
                        },
                        authToken: i,
                        timeElapsed: null
                    }, d("WAComms").waitForConnection);
                    return k.abrupt("return", d("WAResultOrError").makeResult(j));
                case 10:
                case "end":
                    return k.stop()
            }
        }, null, this)
    }
    g.createUploadRetrier = a
}), 98);
__d("WADeletePreKeyGenerationsApi", ["MAWDexieTable", "MAWTransactionMode", "WADbPrekeyTxns", "WADbTransactor", "WAGetPrekeyIdsInRange", "WALogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Attempting to delete non-existent prekey generation"]);
        h = function() {
            return a
        };
        return a
    }
    a = d("WADbTransactor").makeSignalTransactor({
        prekey: d("MAWTransactionMode").READWRITE,
        prekeyGeneration: d("MAWTransactionMode").READWRITE
    }, "deletePreKeyGenerations", function(a) {
        return function(b) {
            return a.prekeyGeneration.bulkGet(b).then(function(c) {
                var e = [];
                c.forEach(function(a) {
                    if (a == null) {
                        d("WALogger").WARN(h());
                        return
                    }
                    d("WAGetPrekeyIdsInRange").getPrekeyIdsInRange(a.startingId, a.endingId).forEach(function(a) {
                        e.push(a)
                    })
                });
                c = a.prekeyGeneration.bulkDelete(b);
                var f = d("WADbPrekeyTxns").bulkDeletePreKeys(a, e);
                return d("MAWDexieTable").dexieAll([c, f]).then(function() {})
            })
        }
    });
    g.deletePreKeyGenerations = a
}), 98);
__d("WADeletePreKeyGenerationsApiV2", ["Promise", "WAGetPrekeyIdsInRange", "WALogger", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Attempting to delete non-existent prekey generation"]);
        i = function() {
            return a
        };
        return a
    }
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["prekey", "prekeyGeneration"], "readwrite", function() {
            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(c) {
                var e = (yield c.stores.prekeyGeneration.bulkGet(a)),
                    f = [];
                for (e of e) {
                    if (e == null) {
                        d("WALogger").WARN(i());
                        continue
                    }
                    for (var g of d("WAGetPrekeyIdsInRange").getPrekeyIdsInRange(e.startingId, e.endingId)) f.push(g)
                }
                yield(h || (h = b("Promise"))).all([c.stores.prekeyGeneration.bulkDelete(a), c.stores.prekey.bulkDelete(f)])
            });
            return function(a) {
                return c.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("deletePreKeyGenerations"))
    };
    g.deletePreKeyGenerations = a
}), 98);
__d("WAGetLastPreKeyGenerationIdApi", ["MAWDexieTable", "MAWTransactionMode", "WADbMetaTxns", "WADbTransactor", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READONLY
    }, "getLastPreKeyGenerationId", function(a) {
        return function() {
            var b = d("WADbMetaTxns").maybeGetLastPrekeyId(a),
                e = d("WADbMetaTxns").maybeGetLastPrekeyGenerationId(a);
            return d("MAWDexieTable").dexieAll([b, e]).then(function(a) {
                var b = a[0];
                a = a[1];
                if (b == null && a != null || b != null && a == null) throw c("err")("Last prekey id and Last prekey generation id should both be non-null");
                if (b != null && a != null) return {
                    lastGenerationId: a,
                    lastPreKeyId: b
                };
                else return null
            })
        }
    });
    g.getLastPreKeyGenerationId = a
}), 98);
__d("WAGetLastPreKeyGenerationIdApiV2", ["Promise", "WADbSignal", "WormDb", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            var a = (yield d("WormDb").getDb().runInTransaction(["meta"], "readonly", function(a) {
                    return (h || (h = b("Promise"))).all([a.stores.meta.get(d("WADbSignal").MetaKeysEnum.lastPrekeyId).then(function(a) {
                        return a == null ? void 0 : a.value.lastPrekeyId
                    }), a.stores.meta.get(d("WADbSignal").MetaKeysEnum.lastPrekeyGenerationId).then(function(a) {
                        return a == null ? void 0 : a.value.lastPrekeyGenerationId
                    })])
                }, d("WormDb").signalOp("getLastPreKeyGenerationId"))),
                e = a[0];
            a = a[1];
            if (e == null && a != null || e != null && a == null) throw c("err")("Last prekey id and Last prekey generation id should both be non-null");
            return e != null && a != null ? {
                lastGenerationId: a,
                lastPreKeyId: e
            } : null
        });
        return function() {
            return a.apply(this, arguments)
        }
    }();
    g.getLastPreKeyGenerationId = a
}), 98);
__d("WAGetPreKeyGenerationsTimestampsApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        prekeyGeneration: d("MAWTransactionMode").READONLY
    }, "getPreKeyGenerationsTimestamps", function(a) {
        return function() {
            return a.prekeyGeneration.toArray().then(function(a) {
                return a.map(function(a) {
                    return {
                        id: a.generationId,
                        timestamp: a.createdTs
                    }
                })
            })
        }
    });
    g.getPreKeyGenerationsTimestamps = a
}), 98);
__d("WAGetPreKeyGenerationsTimestampsApiV2", ["WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        return d("WormDb").getDb().runInTransaction(["prekeyGeneration"], "readonly", function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                a = (yield a.stores.prekeyGeneration.readAll());
                return a.map(function(a) {
                    return {
                        id: a.generationId,
                        timestamp: a.createdTs
                    }
                })
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("getPreKeyGenerationsTimestamps"))
    };
    g.getPreKeyGenerationsTimestamps = a
}), 98);
__d("WALoadICDCApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        contacts: d("MAWTransactionMode").READONLY
    }, "loadICDC", function(a) {
        return function(b) {
            return a.contacts.get(b).then(function(a) {
                return (a = a == null ? void 0 : a.icdcInfo) != null ? a : null
            })
        }
    });
    g.loadICDC = a
}), 98);
__d("WALoadICDCApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["contacts"], "readonly", function(b) {
            return b.stores.contacts.bulkGet([a]).then(function(a) {
                a = a.filter(Boolean).length > 0 ? a[0] : null;
                return (a = a == null ? void 0 : a.icdcInfo) != null ? a : null
            })
        }, d("WormDb").signalOp("loadICDC"))
    };
    g.loadICDC = a
}), 98);
__d("WALoadIdentitiesApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        identity: d("MAWTransactionMode").READONLY
    }, "loadIdentities", function(a) {
        return function(b) {
            return a.identity.where("userJid").equals(b).toArray().then(function(a) {
                return new Map(a.filter(Boolean).map(function(a) {
                    return [a.deviceJid, a.identity]
                }))
            })
        }
    });
    b = d("WADbTransactor").makeSignalTransactor({
        identity: d("MAWTransactionMode").READONLY
    }, "bulkLoadIdentities", function(a) {
        return function(b) {
            return a.identity.where("userJid").anyOf(b).toArray().then(function(a) {
                return a.filter(Boolean).reduce(function(a, b) {
                    var c = a.get(b.userJid);
                    c == null && (c = new Map());
                    c.set(b.deviceJid, b.identity);
                    a.set(b.userJid, c);
                    return a
                }, new Map())
            })
        }
    });
    g.loadIdentities = a;
    g.bulkLoadIdentities = b
}), 98);
__d("WALoadIdentitiesApiV2", ["Promise", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["identity"], "readonly", function() {
            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                b = (yield b.stores.identity.readIndex("userJid", [a]));
                return new Map(b.filter(Boolean).map(function(a) {
                    return [a.deviceJid, a.identity]
                }))
            });
            return function(a) {
                return c.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("loadIdentities"))
    };
    c = function(a) {
        return d("WormDb").getDb().runInTransaction(["identity"], "readonly", function() {
            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(c) {
                var d = (yield(h || (h = b("Promise"))).all(a.map(function(a) {
                        return c.stores.identity.readIndex("userJid", [a])
                    }))),
                    e = new Map();
                for (d of d)
                    for (var f of d) {
                        if (f == null) continue;
                        var g = e.get(f.userJid);
                        g == null && (g = new Map());
                        g.set(f.deviceJid, f.identity);
                        e.set(f.userJid, g)
                    }
                return e
            });
            return function(a) {
                return c.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("bulkLoadIdentities"))
    };
    g.loadIdentities = a;
    g.bulkLoadIdentities = c
}), 98);
__d("WALoadLastSyncTsApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        contacts: d("MAWTransactionMode").READONLY
    }, "loadLastSyncTs", function(a) {
        return function(b) {
            return a.contacts.get(b).then(function(a) {
                return (a = a == null ? void 0 : a.lastSyncTs) != null ? a : null
            })
        }
    });
    g.loadLastSyncTs = a
}), 98);
__d("WALoadLastSyncTsApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["contacts"], "readonly", function(b) {
            return b.stores.contacts.bulkGet([a]).then(function(a) {
                a = a.filter(Boolean).length > 0 ? a[0] : null;
                return (a = a == null ? void 0 : a.lastSyncTs) != null ? a : null
            })
        }, d("WormDb").signalOp("loadLastSyncTs"))
    };
    g.loadLastSyncTs = a
}), 98);
__d("WADbSignedPrekeyTxns", ["WADbMetaTxns", "WAResultOrError", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return d("WADbMetaTxns").maybeGetLastSignedPrekeyIdAndIdentity(a).then(function(b) {
            var e = b.identityPair;
            b = b.keyId;
            if (b == null)
                if (e == null) return d("WAResultOrError").makeError("missing-last-signed-prekey-id", c("err")("No lastSignedPrekeyId and registration in meta table."));
                else return d("WAResultOrError").makeError("missing-last-signed-prekey-id", c("err")("No lastSignedPrekeyId in meta table but identity exists. Very bad"));
            return a.signedPrekey.get({
                keyId: b
            }).then(function(a) {
                return a == null ? d("WAResultOrError").makeError("missing-last-signed-prekey-id", c("err")("No signed prekey matches the lastSignedPrekeyId supplied")) : d("WAResultOrError").makeResult(a.encoded)
            })
        })
    }

    function b(a, b) {
        return a.signedPrekey.bulkGet(b)
    }
    g.getLatestSignedPreKey = a;
    g.getSignedPrekeys = b
}), 98);
__d("WALoadLatestSignedPreKeyApi", ["MAWTransactionMode", "WADbSignedPrekeyTxns", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READONLY,
        signedPrekey: d("MAWTransactionMode").READONLY
    }, "loadLatestSignedPreKey", function(a) {
        return function() {
            return d("WADbSignedPrekeyTxns").getLatestSignedPreKey(a)
        }
    });
    g.loadLatestSignedPreKey = a
}), 98);
__d("WADbSignedPrekeyTxnsV2", ["WADbMetaTxnsV2", "WAResultOrError", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return h.apply(this, arguments)
    }

    function h() {
        h = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = (yield d("WADbMetaTxnsV2").maybeGetLastSignedPrekeyIdAndIdentity(a)),
                e = b.identityPair;
            b = b.keyId;
            if (b == null)
                if (e == null) return d("WAResultOrError").makeError("missing-last-signed-prekey-id", c("err")("No lastSignedPrekeyId and registration in meta table."));
                else return d("WAResultOrError").makeError("missing-last-signed-prekey-id", c("err")("No lastSignedPrekeyId in meta table but identity exists. Very bad"));
            e = (yield a.signedPrekey.get(b));
            return e == null ? d("WAResultOrError").makeError("missing-last-signed-prekey-id", c("err")("No signed prekey matches the lastSignedPrekeyId supplied")) : d("WAResultOrError").makeResult(e.encoded)
        });
        return h.apply(this, arguments)
    }
    g.getLatestSignedPreKey = a
}), 98);
__d("WALoadLatestSignedPreKeyApiV2", ["WADbSignedPrekeyTxnsV2", "WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        return d("WormDb").getDb().runInTransaction(["meta", "signedPrekey"], "readonly", function(a) {
            return d("WADbSignedPrekeyTxnsV2").getLatestSignedPreKey(a.stores)
        }, d("WormDb").signalOp("loadLatestSignedPreKey"))
    };
    g.loadLatestSignedPreKey = a
}), 98);
__d("WALoadOneTimePreKeyApi", ["MAWODSProxy", "MAWTransactionMode", "WADbTransactor", "WAOdsEnums"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        prekey: d("MAWTransactionMode").READONLY
    }, "loadOneTimePreKey", function(a) {
        return function(b) {
            return a.prekey.get(b).then(function(a) {
                if (a == null) d("MAWODSProxy").odsBumpEntityKey({
                    entity: d("WAOdsEnums").Entity.GET_PREKEY,
                    key: "miss_prekey_in_db"
                });
                else return a.encoded
            })
        }
    });
    g.loadOneTimePreKey = a
}), 98);
__d("WALoadOneTimePreKeyApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["prekey"], "readonly", function(b) {
            return b.stores.prekey.get(a).then(function(a) {
                return a == null ? void 0 : a.encoded
            })
        }, d("WormDb").signalOp("loadOneTimePreKey"))
    };
    g.loadOneTimePreKey = a
}), 98);
__d("WALoadPreKeysApi", ["MAWDexieTable", "MAWTransactionMode", "WACompareIdentity", "WADbMetaTxns", "WADbPrekeyTxns", "WADbSignedPrekeyTxns", "WADbTransactor", "WALoggerTag", "WASignalSignatures", "WATagsLogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No last prekey generation id"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to deserialize signed prekey"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to get latest signed prekey"]);
        j = function() {
            return a
        };
        return a
    }
    var k = d("WATagsLogger").TAGS([c("WALoggerTag").SignedPrekey]);
    b = d("WADbTransactor").makeSignalTransactor({
        identity: (a = d("MAWTransactionMode")).READONLY,
        meta: a.READONLY,
        prekey: a.READONLY,
        prekeyGeneration: a.READONLY,
        signedPrekey: a.READONLY
    }, "loadPreKeys", function(a) {
        return function(b) {
            return d("MAWDexieTable").dexieAll([d("WADbSignedPrekeyTxns").getLatestSignedPreKey(a), d("WACompareIdentity").compareIdentityDexie(a)]).then(function(e) {
                e = e[0];
                if (!e.success) {
                    var f;
                    k.ERROR(j());
                    throw (f = e.error) != null ? f : c("err")("Failed to get latest signed prekey")
                }
                var g = d("WASignalSignatures").deserializeSignedPreKey(e.value);
                if (g == null) {
                    k.ERROR(i());
                    throw c("err")("Failed to deserialize signed prekey")
                }
                f = b != null ? d("MAWDexieTable").dexieResolve(b) : d("WADbMetaTxns").maybeGetLastPrekeyGenerationId(a);
                return f.then(function(b) {
                    if (b == null) {
                        k.ERROR(h());
                        throw c("err")("No last prekey generation id")
                    }
                    return d("WADbPrekeyTxns").getPrekeysForGeneration(a, b).then(function(a) {
                        return {
                            preKeys: a,
                            signedPreKey: g
                        }
                    })
                })
            })
        }
    });
    g.loadPreKeys = b
}), 98);
__d("WADbPrekeyTxnsV2", ["WAGetPrekeyIdsInRange", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return h.apply(this, arguments)
    }

    function h() {
        h = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            b = (yield a.prekeyGeneration.get(b));
            if (b == null) throw c("err")("Expected a prekey generation row");
            b = d("WAGetPrekeyIdsInRange").getPrekeyIdsInRange(b.startingId, b.endingId);
            a = (yield a.prekey.bulkGet(b));
            return a.filter(Boolean).map(function(a) {
                return a.encoded
            })
        });
        return h.apply(this, arguments)
    }
    g.getPrekeysForGeneration = a
}), 98);
__d("WALoadPreKeysApiV2", ["WADbPrekeyTxnsV2", "WADbSignal", "WADbSignedPrekeyTxnsV2", "WALoggerTag", "WASignalSignatures", "WATagsLogger", "WormDb", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No last prekey generation id"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to deserialize signed prekey"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to get latest signed prekey"]);
        j = function() {
            return a
        };
        return a
    }
    var k = d("WATagsLogger").TAGS([c("WALoggerTag").SignedPrekey]);
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["identity", "meta", "prekey", "prekeyGeneration", "signedPrekey"], "readonly", function() {
            var e = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                var e = (yield d("WADbSignedPrekeyTxnsV2").getLatestSignedPreKey(b.stores));
                if (!e.success) {
                    var f;
                    k.ERROR(j());
                    throw (f = e.error) != null ? f : c("err")("Failed to get latest signed prekey")
                }
                var g = d("WASignalSignatures").deserializeSignedPreKey(e.value);
                if (g == null) {
                    k.ERROR(i());
                    throw c("err")("Failed to deserialize signed prekey")
                }
                f = a != null ? a : yield b.stores.meta.get(d("WADbSignal").MetaKeysEnum.lastPrekeyGenerationId).then(function(a) {
                    return a == null ? void 0 : a.value.lastPrekeyGenerationId
                });
                if (f == null) {
                    k.ERROR(h());
                    throw c("err")("No last prekey generation id")
                }
                return d("WADbPrekeyTxnsV2").getPrekeysForGeneration(b.stores, f).then(function(a) {
                    return {
                        preKeys: a,
                        signedPreKey: g
                    }
                })
            });
            return function(a) {
                return e.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("loadPreKeys"))
    };
    g.loadPreKeys = a
}), 98);
__d("WALoadSenderKeySessionApi", ["MAWTransactionMode", "WACryptoManager", "WADbSignal", "WADbTransactor", "WAJids", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        senderKeySessions: d("MAWTransactionMode").READONLY
    }, "loadSenderKeySession", function(a) {
        return function(b, c) {
            var e = d("WAJids").extractUserJid(c);
            c = d("WAJids").extractDeviceId(c);
            b = d("WADbSignal").buildSenderKeySessionId(b, e, c);
            return a.senderKeySessions.get({
                id: b
            }).then(function(a) {
                if (a == null) return d("WAResultOrError").makeError("errLoadSenderKeySession");
                a = d("WACryptoManager").decodeSenderKeySession(a.record);
                return d("WAResultOrError").makeResult(a)
            })
        }
    });
    g.loadSenderKeySession = a
}), 98);
__d("WALoadSenderKeySessionApiV2", ["WACryptoManager", "WADbSignal", "WAJids", "WAResultOrError", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a, c) {
        var e = d("WAJids").extractUserJid(c);
        c = d("WAJids").extractDeviceId(c);
        var f = d("WADbSignal").buildSenderKeySessionId(a, e, c);
        return d("WormDb").getDb().runInTransaction(["senderKeySessions"], "readonly", function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                a = (yield a.stores.senderKeySessions.get(f));
                if (a == null) return d("WAResultOrError").makeError("errLoadSenderKeySession");
                a = d("WACryptoManager").decodeSenderKeySession(a.record);
                return d("WAResultOrError").makeResult(a)
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("loadSenderKeySession"))
    };
    g.loadSenderKeySession = a
}), 98);
__d("WALoadSignedPreKeyApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        signedPrekey: d("MAWTransactionMode").READONLY
    }, "loadSignedPreKey", function(a) {
        return function(b) {
            return a.signedPrekey.get(b).then(function(a) {
                return a == null ? void 0 : a.encoded
            })
        }
    });
    g.loadSignedPreKey = a
}), 98);
__d("WALoadSignedPreKeyApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["signedPrekey"], "readonly", function(b) {
            return b.stores.signedPrekey.get(a).then(function(a) {
                return a == null ? void 0 : a.encoded
            })
        }, d("WormDb").signalOp("loadSignedPreKey"))
    };
    g.loadSignedPreKey = a
}), 98);
__d("WASaveOneTimePreKeyApi", ["MAWDexieTable", "MAWTransactionMode", "WADbMetaTxns", "WADbSignal", "WADbTransactor", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READWRITE,
        prekey: d("MAWTransactionMode").READWRITE
    }, "saveOneTimePreKey", function(a) {
        return function(b) {
            return d("WADbMetaTxns").maybeGetLastPrekeyId(a).then(function(c) {
                return c == null ? d("WAResultOrError").makeError("missing_last_prekey") : d("MAWDexieTable").dexieAll([a.prekey.put(babelHelpers["extends"]({}, b, {
                    isDeleted: !1
                })), a.meta.put({
                    key: d("WADbSignal").MetaKeysEnum.lastPrekeyId,
                    value: {
                        lastPrekeyId: b.keyId
                    }
                })]).then(function() {
                    return d("WAResultOrError").makeResult()
                })
            })
        }
    });
    g.saveOneTimePreKey = a
}), 98);
__d("WASaveOneTimePreKeyApiV2", ["Promise", "WADbSignal", "WAResultOrError", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["meta", "prekey"], "readwrite", function() {
            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(c) {
                var e = (yield c.stores.meta.get(d("WADbSignal").MetaKeysEnum.lastPrekeyId));
                e = e == null ? void 0 : e.value.lastPrekeyId;
                if (e == null) return d("WAResultOrError").makeError("missing_last_prekey");
                yield(h || (h = b("Promise"))).all([c.stores.prekey.bulkPut([babelHelpers["extends"]({}, a, {
                    isDeleted: !1
                })]), c.stores.meta.bulkPut([{
                    key: d("WADbSignal").MetaKeysEnum.lastPrekeyId,
                    value: {
                        lastPrekeyId: a.keyId
                    }
                }])]);
                return d("WAResultOrError").makeResult()
            });
            return function(a) {
                return c.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("saveOneTimePreKey"))
    };
    g.saveOneTimePreKey = a
}), 98);
__d("WASavePreKeysGenerationApi", ["MAWDexieTable", "MAWTransactionMode", "WACryptoManager", "WADbMetaTxns", "WADbSignal", "WADbTransactor", "WAResultOrError", "WATimeUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READWRITE,
        prekey: d("MAWTransactionMode").READWRITE,
        prekeyGeneration: d("MAWTransactionMode").READWRITE
    }, "savePreKeysGeneration", function(a) {
        return function(b) {
            return d("WADbMetaTxns").maybeGetLastPrekeyGenerationId(a).then(function(e) {
                if (b.length === 0) throw c("err")("Keys provided to savePreKeysGeneration cannot be empty");
                var f = d("WACryptoManager").castToPreKeyGenerationId(((e = e) != null ? e : 0) + 1);
                e = b[0].keyId;
                var g = b[b.length - 1].keyId,
                    h = b.map(function(a) {
                        return babelHelpers["extends"]({}, a, {
                            isDeleted: !1
                        })
                    });
                h = a.prekey.bulkPut(h);
                var i = a.meta.bulkPut([{
                    key: d("WADbSignal").MetaKeysEnum.lastPrekeyId,
                    value: {
                        lastPrekeyId: g
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.lastPrekeyGenerationId,
                    value: {
                        lastPrekeyGenerationId: f
                    }
                }]);
                g = a.prekeyGeneration.put({
                    createdTs: d("WATimeUtils").unixTime(),
                    endingId: g,
                    generationId: f,
                    startingId: e
                });
                return d("MAWDexieTable").dexieAll([h, i, g]).then(function() {
                    return d("WAResultOrError").makeResult(f)
                })
            })
        }
    });
    g.savePreKeysGeneration = a
}), 98);
__d("WASavePreKeysGenerationApiV2", ["Promise", "WACryptoManager", "WADbSignal", "WAResultOrError", "WATimeUtils", "WormDb", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a) {
        if (a.length === 0) throw c("err")("Keys provided to savePreKeysGeneration cannot be empty");
        return d("WormDb").getDb().runInTransaction(["meta", "prekey", "prekeyGeneration"], "readwrite", function() {
            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(c) {
                var e = (yield c.stores.meta.get(d("WADbSignal").MetaKeysEnum.lastPrekeyGenerationId));
                e = d("WACryptoManager").castToPreKeyGenerationId(((e = e == null ? void 0 : e.value.lastPrekeyGenerationId) != null ? e : 0) + 1);
                var f = a[0].keyId,
                    g = a[a.length - 1].keyId,
                    i = a.map(function(a) {
                        return babelHelpers["extends"]({}, a, {
                            isDeleted: !1
                        })
                    });
                yield(h || (h = b("Promise"))).all([c.stores.prekey.bulkPut(i), c.stores.meta.bulkPut([{
                    key: d("WADbSignal").MetaKeysEnum.lastPrekeyId,
                    value: {
                        lastPrekeyId: g
                    }
                }, {
                    key: d("WADbSignal").MetaKeysEnum.lastPrekeyGenerationId,
                    value: {
                        lastPrekeyGenerationId: e
                    }
                }]), c.stores.prekeyGeneration.bulkPut([{
                    createdTs: d("WATimeUtils").unixTime(),
                    endingId: g,
                    generationId: e,
                    startingId: f
                }])]);
                return d("WAResultOrError").makeResult(e)
            });
            return function(a) {
                return c.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("savePreKeysGeneration"))
    };
    g.savePreKeysGeneration = a
}), 98);
__d("WASaveSignedPreKeyIfNewApi", ["MAWDexieTable", "MAWTransactionMode", "WADbSignal", "WADbTransactor", "WASignalSignatures"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READWRITE,
        signedPrekey: d("MAWTransactionMode").READWRITE
    }, "saveSignedPreKeyIfNew", function(a) {
        return function(b, c) {
            return a.signedPrekey.get(b).then(function(e) {
                if (e != null) {
                    e = d("WASignalSignatures").deserializeSignedPreKey(e.encoded);
                    if (e != null) return {
                        key: e,
                        type: "duplicate"
                    }
                }
                e = a.signedPrekey.put({
                    encoded: c,
                    keyId: b
                });
                var f = a.meta.put({
                    key: d("WADbSignal").MetaKeysEnum.lastSignedPrekeyId,
                    value: {
                        lastSignedPrekeyId: b
                    }
                });
                return d("MAWDexieTable").dexieAll([e, f]).then(function() {
                    return {
                        type: "success"
                    }
                })
            })
        }
    });
    g.saveSignedPreKeyIfNew = a
}), 98);
__d("WASaveSignedPreKeyIfNewApiV2", ["Promise", "WADbSignal", "WASignalSignatures", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = function(a, c) {
        return d("WormDb").getDb().runInTransaction(["meta", "signedPrekey"], "readwrite", function() {
            var e = b("asyncToGeneratorRuntime").asyncToGenerator(function*(e) {
                var f = (yield e.stores.signedPrekey.get(a));
                if (f != null) {
                    f = d("WASignalSignatures").deserializeSignedPreKey(f.encoded);
                    if (f != null) return {
                        key: f,
                        type: "duplicate"
                    }
                }
                yield(h || (h = b("Promise"))).all([e.stores.signedPrekey.bulkPut([{
                    encoded: c,
                    keyId: a
                }]), e.stores.meta.bulkPut([{
                    key: d("WADbSignal").MetaKeysEnum.lastSignedPrekeyId,
                    value: {
                        lastSignedPrekeyId: a
                    }
                }])]);
                return {
                    type: "success"
                }
            });
            return function(a) {
                return e.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("saveSignedPreKeyIfNew"))
    };
    g.saveSignedPreKeyIfNew = a
}), 98);
__d("WASessionApi", ["MAWDexieTable", "MAWTransactionMode", "WABase64", "WACryptoManager", "WACryptoUtils", "WADbTransactor", "WALogger", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["MAWSessionApi -- identity in session table is different with identity table ", ", ", "  with context: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["MAWSessionApi -- identity in session table is different with identity table with context: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["MAWSessionApi -- missing identity"]);
        j = function() {
            return a
        };
        return a
    }
    a = d("WADbTransactor").makeSignalTransactor({
        identity: d("MAWTransactionMode").READONLY,
        session: d("MAWTransactionMode").READONLY
    }, "loadSession", function(a) {
        return function(b, e) {
            return d("MAWDexieTable").dexieAll([a.session.get({
                id: b
            }), a.identity.get({
                deviceJid: b
            })]).then(function(a) {
                var b = a[0];
                a = a[1];
                if (b == null) return null;
                b = d("WACryptoManager").decodeSession(b.session);
                a == null ? d("WALogger").ERROR(j()) : d("WACryptoUtils").uint8ArraysEqual(a.identity, b.remote.pubKey) || (d("WALogger").ERROR(i(), e), c("gkx")("23958") && c("gkx")("23959") && d("WALogger").ERROR(h(), d("WABase64").encodeB64(a.identity), d("WABase64").encodeB64(b.remote.pubKey), e));
                return b
            })
        }
    });
    b = d("WADbTransactor").makeSignalTransactor({
        session: d("MAWTransactionMode").READONLY
    }, "bulkLoadSession", function(a) {
        return function(b) {
            return a.session.bulkGet(b).then(k)
        }
    });

    function k(a) {
        return a.reduce(function(a, b) {
            if (b == null) return a;
            var c = d("WACryptoManager").decodeSession(b.session);
            a.set(b.id, c);
            return a
        }, new Map())
    }
    g.loadSession = a;
    g.bulkLoadSession = b
}), 98);
__d("WASessionApiV2", ["WACryptoManager", "WormDb", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["session"], "readonly", function() {
            var c = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                b = (yield b.stores.session.get(a));
                if (b == null) return null;
                b = d("WACryptoManager").decodeSession(b.session);
                return b
            });
            return function(a) {
                return c.apply(this, arguments)
            }
        }(), d("WormDb").signalOp("loadSession"))
    };
    c = function(a) {
        return d("WormDb").getDb().runInTransaction(["identity", "session"], "readonly", function(b) {
            return b.stores.session.bulkGet(a).then(h)
        }, d("WormDb").signalOp("bulkLoadSession"))
    };

    function h(a) {
        var b = new Map();
        for (a of a) {
            if (a == null) continue;
            var c = d("WACryptoManager").decodeSession(a.session);
            b.set(a.id, c)
        }
        return b
    }
    g.loadSession = a;
    g.bulkLoadSession = c
}), 98);
__d("WACryptoDbCallbacks", ["WABulkSaveSignalDataApi", "WABulkSaveSignalDataApiV2", "WADeletePreKeyGenerationsApi", "WADeletePreKeyGenerationsApiV2", "WADexieToWormMigration", "WAGetLastPreKeyGenerationIdApi", "WAGetLastPreKeyGenerationIdApiV2", "WAGetPreKeyGenerationsTimestampsApi", "WAGetPreKeyGenerationsTimestampsApiV2", "WALoadICDCApi", "WALoadICDCApiV2", "WALoadIdentitiesApi", "WALoadIdentitiesApiV2", "WALoadLastSyncTsApi", "WALoadLastSyncTsApiV2", "WALoadLatestSignedPreKeyApi", "WALoadLatestSignedPreKeyApiV2", "WALoadOneTimePreKeyApi", "WALoadOneTimePreKeyApiV2", "WALoadPreKeysApi", "WALoadPreKeysApiV2", "WALoadSenderKeySessionApi", "WALoadSenderKeySessionApiV2", "WALoadSignedPreKeyApi", "WALoadSignedPreKeyApiV2", "WASaveOneTimePreKeyApi", "WASaveOneTimePreKeyApiV2", "WASavePreKeysGenerationApi", "WASavePreKeysGenerationApiV2", "WASaveSignedPreKeyIfNewApi", "WASaveSignedPreKeyIfNewApiV2", "WASessionApi", "WASessionApiV2"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "WACryptoDbCallbacks";
    a = function() {
        return {
            bulkLoadIdentities: d("WADexieToWormMigration").isWorm(h) ? d("WALoadIdentitiesApiV2").bulkLoadIdentities : d("WALoadIdentitiesApi").bulkLoadIdentities,
            bulkSaveSignalData: d("WADexieToWormMigration").isWorm(h) ? d("WABulkSaveSignalDataApiV2").bulkSaveSignalData : d("WABulkSaveSignalDataApi").bulkSaveSignalData,
            deletePreKeyGenerations: d("WADexieToWormMigration").isWorm(h) ? d("WADeletePreKeyGenerationsApiV2").deletePreKeyGenerations : d("WADeletePreKeyGenerationsApi").deletePreKeyGenerations,
            getLastPreKeyGenerationId: d("WADexieToWormMigration").isWorm(h) ? d("WAGetLastPreKeyGenerationIdApiV2").getLastPreKeyGenerationId : d("WAGetLastPreKeyGenerationIdApi").getLastPreKeyGenerationId,
            getPreKeyGenerationsTimestamps: d("WADexieToWormMigration").isWorm(h) ? d("WAGetPreKeyGenerationsTimestampsApiV2").getPreKeyGenerationsTimestamps : d("WAGetPreKeyGenerationsTimestampsApi").getPreKeyGenerationsTimestamps,
            loadICDC: d("WADexieToWormMigration").isWorm(h) ? d("WALoadICDCApiV2").loadICDC : d("WALoadICDCApi").loadICDC,
            loadIdentities: d("WADexieToWormMigration").isWorm(h) ? d("WALoadIdentitiesApiV2").loadIdentities : d("WALoadIdentitiesApi").loadIdentities,
            loadLastSyncTs: d("WADexieToWormMigration").isWorm(h) ? d("WALoadLastSyncTsApiV2").loadLastSyncTs : d("WALoadLastSyncTsApi").loadLastSyncTs,
            loadLatestSignedPreKey: d("WADexieToWormMigration").isWorm(h) ? d("WALoadLatestSignedPreKeyApiV2").loadLatestSignedPreKey : d("WALoadLatestSignedPreKeyApi").loadLatestSignedPreKey,
            loadOneTimePreKey: d("WADexieToWormMigration").isWorm(h) ? d("WALoadOneTimePreKeyApiV2").loadOneTimePreKey : d("WALoadOneTimePreKeyApi").loadOneTimePreKey,
            loadPreKeys: d("WADexieToWormMigration").isWorm(h) ? d("WALoadPreKeysApiV2").loadPreKeys : d("WALoadPreKeysApi").loadPreKeys,
            loadSenderKeySession: d("WADexieToWormMigration").isWorm(h) ? d("WALoadSenderKeySessionApiV2").loadSenderKeySession : d("WALoadSenderKeySessionApi").loadSenderKeySession,
            loadSession: d("WADexieToWormMigration").isWorm(h) ? d("WASessionApiV2").loadSession : d("WASessionApi").loadSession,
            loadSessions: d("WADexieToWormMigration").isWorm(h) ? d("WASessionApiV2").bulkLoadSession : d("WASessionApi").bulkLoadSession,
            loadSignedPreKey: d("WADexieToWormMigration").isWorm(h) ? d("WALoadSignedPreKeyApiV2").loadSignedPreKey : d("WALoadSignedPreKeyApi").loadSignedPreKey,
            saveOneTimePreKey: d("WADexieToWormMigration").isWorm(h) ? d("WASaveOneTimePreKeyApiV2").saveOneTimePreKey : d("WASaveOneTimePreKeyApi").saveOneTimePreKey,
            savePreKeysGeneration: d("WADexieToWormMigration").isWorm(h) ? d("WASavePreKeysGenerationApiV2").savePreKeysGeneration : d("WASavePreKeysGenerationApi").savePreKeysGeneration,
            saveSignedPreKeyIfNew: d("WADexieToWormMigration").isWorm(h) ? d("WASaveSignedPreKeyIfNewApiV2").saveSignedPreKeyIfNew : d("WASaveSignedPreKeyIfNewApi").saveSignedPreKeyIfNew
        }
    };
    g.getCryptoDbCallbacks = a
}), 98);
__d("WASignalEntityStoreV2", ["$InternalEnum", "regeneratorRuntime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("$InternalEnum").Mirrored(["NOT_PERSISTED", "PERSIST_IN_PROGRESS", "PERSISTED"]);
    a = function() {
        function a() {
            this.$1 = new Map()
        }
        var c = a.prototype;
        c.TEST_ONLY_LOAD_FROM_MEMORY = function(a) {
            return this.$2(a)
        };
        c.$2 = function(a) {
            a = this.$1.get(a);
            return a != null ? {
                entity: a.entity,
                deleted: a.deleted
            } : null
        };
        c.load = function(a, c) {
            var d, e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        d = this.$2(a);
                        if (!(d == null ? void 0 : d.deleted)) {
                            f.next = 3;
                            break
                        }
                        return f.abrupt("return", null);
                    case 3:
                        if (!(d != null && d.entity != null)) {
                            f.next = 5;
                            break
                        }
                        return f.abrupt("return", d.entity);
                    case 5:
                        f.next = 7;
                        return b("regeneratorRuntime").awrap(c(a));
                    case 7:
                        e = f.sent;
                        this.$3(a, e);
                        return f.abrupt("return", e);
                    case 10:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        };
        c.bulkLoad = function(a, c) {
            var d, e, f, g, h, i, j, k, l, m, n, o, p;
            return b("regeneratorRuntime").async(function(q) {
                while (1) switch (q.prev = q.next) {
                    case 0:
                        d = [], e = new Map(), f = 0;
                    case 3:
                        if (!(f < a.length)) {
                            q.next = 15;
                            break
                        }
                        g = a[f];
                        h = this.$2(g);
                        if (!(h == null)) {
                            q.next = 9;
                            break
                        }
                        d.push(g);
                        return q.abrupt("continue", 12);
                    case 9:
                        if (!h.deleted) {
                            q.next = 11;
                            break
                        }
                        return q.abrupt("continue", 12);
                    case 11:
                        h.entity != null ? e.set(g, h.entity) : d.push(g);
                    case 12:
                        f++;
                        q.next = 3;
                        break;
                    case 15:
                        q.next = 17;
                        return b("regeneratorRuntime").awrap(c(d));
                    case 17:
                        i = q.sent, (j = i.entries(), k = Array.isArray(j), l = 0, j = k ? j : j[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]());
                    case 19:
                        if (!k) {
                            q.next = 25;
                            break
                        }
                        if (!(l >= j.length)) {
                            q.next = 22;
                            break
                        }
                        return q.abrupt("break", 36);
                    case 22:
                        m = j[l++];
                        q.next = 29;
                        break;
                    case 25:
                        l = j.next();
                        if (!l.done) {
                            q.next = 28;
                            break
                        }
                        return q.abrupt("break", 36);
                    case 28:
                        m = l.value;
                    case 29:
                        n = m, o = n[0], p = n[1], e.set(o, p), this.$3(o, p);
                    case 34:
                        q.next = 19;
                        break;
                    case 36:
                        return q.abrupt("return", e);
                    case 37:
                    case "end":
                        return q.stop()
                }
            }, null, this)
        };
        c.$3 = function(a, b) {
            this.$1.set(a, {
                entity: b,
                status: g.PERSISTED,
                deleted: !1
            })
        };
        c.store = function(a, b) {
            this.$1.set(a, {
                entity: b,
                status: g.NOT_PERSISTED,
                deleted: !1
            })
        };
        c.remove = function(a) {
            this.$1.set(a, {
                entity: null,
                status: g.NOT_PERSISTED,
                deleted: !0
            })
        };
        c.pureSnapshot = function() {
            var a = [],
                b = Array.from(this.$1.entries()).filter(function(a) {
                    a[0];
                    a = a[1];
                    return a.status === g.NOT_PERSISTED
                }).filter(function(b) {
                    var c = b[0];
                    b = b[1];
                    b.deleted && a.push({
                        id: c
                    });
                    return !b.deleted
                }).filter(function(a) {
                    a[0];
                    a = a[1];
                    return a.entity != null
                }).map(function(a) {
                    var b = a[0];
                    a = a[1];
                    return {
                        id: b,
                        cachedEntity: a.entity
                    }
                });
            return {
                update: b,
                remove: a
            }
        };
        c.snapshot = function() {
            var a = this,
                b = this.pureSnapshot();
            b.remove.forEach(function(b) {
                b = b.id;
                b = a.$1.get(b);
                b && (b.status = g.PERSIST_IN_PROGRESS)
            });
            b.update.forEach(function(b) {
                b = b.id;
                b = a.$1.get(b);
                b && (b.status = g.PERSIST_IN_PROGRESS)
            });
            return b
        };
        c.markSnapshotAsCommitted = function() {
            this.$1.forEach(function(a) {
                a.status === g.PERSIST_IN_PROGRESS && (a.status = g.PERSISTED)
            })
        };
        c.markSnapshotAsFailed = function() {
            this.$1.forEach(function(a) {
                a.status === g.PERSIST_IN_PROGRESS && (a.status = g.NOT_PERSISTED)
            })
        };
        c.clear = function() {
            this.$1 = new Map()
        };
        return a
    }();
    f.PersistStatus = g;
    f.SignalEntityStore = a
}), 66);
__d("WASignalIdentityStore", ["Promise", "WAJids", "WALogger", "WASignalEntityStoreV2", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[WASignalIdentityStore] This should never happen."]);
        i = function() {
            return a
        };
        return a
    }
    a = function() {
        function a() {
            this.$1 = new Map(), this.$2 = new(d("WASignalEntityStoreV2").SignalEntityStore)()
        }
        var c = a.prototype;
        c.bulkLoadIdentities = function(a) {
            var c = this,
                d, e, f, g, i, j;
            return b("regeneratorRuntime").async(function(k) {
                while (1) switch (k.prev = k.next) {
                    case 0:
                        d = function() {
                            var a, d, j;
                            return b("regeneratorRuntime").async(function(k) {
                                while (1) switch (k.prev = k.next) {
                                    case 0:
                                        if (!f) {
                                            k.next = 6;
                                            break
                                        }
                                        if (!(g >= e.length)) {
                                            k.next = 3;
                                            break
                                        }
                                        return k.abrupt("return", "break");
                                    case 3:
                                        i = e[g++];
                                        k.next = 10;
                                        break;
                                    case 6:
                                        g = e.next();
                                        if (!g.done) {
                                            k.next = 9;
                                            break
                                        }
                                        return k.abrupt("return", "break");
                                    case 9:
                                        i = g.value;
                                    case 10:
                                        a = i;
                                        d = a[0];
                                        j = a[1];
                                        k.next = 15;
                                        return b("regeneratorRuntime").awrap(c.loadIdentitiesByUser(d, function() {
                                            return (h || (h = b("Promise"))).resolve(j)
                                        }));
                                    case 15:
                                    case "end":
                                        return k.stop()
                                }
                            }, null, this)
                        }, (e = a, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]());
                    case 2:
                        k.next = 4;
                        return b("regeneratorRuntime").awrap(d());
                    case 4:
                        j = k.sent;
                        if (!(j === "break")) {
                            k.next = 7;
                            break
                        }
                        return k.abrupt("break", 9);
                    case 7:
                        k.next = 2;
                        break;
                    case 9:
                        return k.abrupt("return", a);
                    case 10:
                    case "end":
                        return k.stop()
                }
            }, null, this)
        };
        c.loadIdentitiesByUser = function(a, c) {
            var e, f, g;
            return b("regeneratorRuntime").async(function(j) {
                while (1) switch (j.prev = j.next) {
                    case 0:
                        e = this.$1.get(a);
                        if (!(e == null)) {
                            j.next = 13;
                            break
                        }
                        j.t0 = this;
                        j.t1 = a;
                        j.next = 6;
                        return b("regeneratorRuntime").awrap(c(a));
                    case 6:
                        j.t2 = j.sent;
                        f = j.t0.$3.call(j.t0, j.t1, j.t2);
                        g = Array.from(f.keys());
                        this.$1.set(a, new Set(g));
                        return j.abrupt("return", this.$2.bulkLoad(g, function() {
                            return (h || (h = b("Promise"))).resolve(f)
                        }));
                    case 13:
                        return j.abrupt("return", this.$2.bulkLoad(Array.from(e), function(a) {
                            a.length > 0 && d("WALogger").ERROR(i());
                            return (h || (h = b("Promise"))).resolve(new Map())
                        }));
                    case 14:
                    case "end":
                        return j.stop()
                }
            }, null, this)
        };
        c.$3 = function(a, b) {
            b = new Map(b);
            var c = this.$2.pureSnapshot(),
                e = c.remove;
            c = c.update;
            for (var e = e, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var h;
                if (f) {
                    if (g >= e.length) break;
                    h = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    h = g.value
                }
                h = h;
                h = h.id;
                b["delete"](h)
            }
            for (h = c, g = Array.isArray(h), f = 0, h = g ? h : h[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (g) {
                    if (f >= h.length) break;
                    e = h[f++]
                } else {
                    f = h.next();
                    if (f.done) break;
                    e = f.value
                }
                c = e;
                e = c.id;
                c = c.cachedEntity;
                c != null && d("WAJids").extractUserJid(e) === a && b.set(e, c)
            }
            return b
        };
        c.store = function(a, b) {
            this.$2.store(a, b);
            b = d("WAJids").extractUserJid(a);
            b = this.$1.get(b);
            b != null && b.add(a)
        };
        c.remove = function(a) {
            this.$2.remove(a);
            var b = d("WAJids").extractUserJid(a);
            b = this.$1.get(b);
            b != null && b["delete"](a)
        };
        c.clear = function() {
            this.$2.clear(), this.$1 = new Map()
        };
        c.load = function(a, b) {
            return this.$2.load(a, b)
        };
        c.bulkLoad = function(a, b) {
            return this.$2.bulkLoad(a, b)
        };
        c.snapshot = function() {
            return this.$2.snapshot()
        };
        c.pureSnapshot = function() {
            return this.pureSnapshot()
        };
        c.markSnapshotAsCommitted = function() {
            this.$2.markSnapshotAsCommitted()
        };
        c.markSnapshotAsFailed = function() {
            this.$2.markSnapshotAsFailed()
        };
        return a
    }();
    g.SignalIdentityStore = a
}), 98);
__d("WAInMemorySignalStore", ["Promise", "WACryptoManager", "WACryptoUtils", "WAGlobals", "WAICDCUtils", "WAIdentityUtils", "WAJids", "WAProtocolQueue", "WAResultOrError", "WASignalEntityStoreV2", "WASignalIdentityStore", "WATagsLogger", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Snapshot save: end"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Snapshot save: start"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Snapshot: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Removing old identity: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Removing my device identity. This should not happen"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Device notification of one user cannot remove identity the other one "]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Removing session dur to identity mismatch: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Device notification of one user cannot remove session the other one"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Receiving an identity for my device but it is different from original one"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Update user devices: userJid: ", "; new identities: ", "; previous identities: ", "}"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[ICDC] Identities do not match with ICDC identities"]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[ICDC] Current user does not have ICDC or it is incorrect"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[ICDC] Identity store does not have current device identity"]);
        u = function() {
            return a
        };
        return a
    }
    var v = d("WATagsLogger").TAGS(["CryptoManager", "InMemorySignalStore"]);
    a = function() {
        function a(a, c) {
            var e = this;
            this.loadSession = function(a, b) {
                return e.$1.load(a, function(a) {
                    return e.$9.loadSession(a, b)
                })
            };
            this.loadSessions = function(a) {
                return e.$1.bulkLoad(a, function(a) {
                    return e.$9.loadSessions(a).then(function(a) {
                        return new Map(Array.from(a.entries()).map(function(a) {
                            return [a[0], a[1]]
                        }))
                    })
                }).then(function(a) {
                    return new Map(Array.from(a.entries()).map(function(a) {
                        return [a[0], a[1]]
                    }))
                })
            };
            this.loadSignedPreKey = function(a) {
                return e.$7.load(a, function() {
                    return e.$9.loadSignedPreKey(a)
                })
            };
            this.bulkLoadIdentities = function(a) {
                return e.$9.bulkLoadIdentities(a).then(function(a) {
                    return e.$5.bulkLoadIdentities(a)
                })
            };
            this.loadIdentities = function(a) {
                return e.$5.loadIdentitiesByUser(a, function() {
                    return e.$9.loadIdentities(a)
                })
            };
            this.saveIdentity = function(a, c) {
                return (h || (h = b("Promise"))).resolve(e.storeIdentity(a, c))
            };
            this.loadOneTimePreKey = function(a) {
                return e.$6.load(a, function() {
                    return e.$9.loadOneTimePreKey(a)
                })
            };
            this.saveSenderKeySession = function(a, c, d) {
                e.storeSenderKeySession(a, c, d);
                return (h || (h = b("Promise"))).resolve()
            };
            this.saveSignedPreKeyIfNew = function(a, b) {
                return e.$9.saveSignedPreKeyIfNew(a, b)
            };
            this.loadSenderKeySession = function(a, c) {
                var f;
                return b("regeneratorRuntime").async(function(g) {
                    while (1) switch (g.prev = g.next) {
                        case 0:
                            g.next = 2;
                            return b("regeneratorRuntime").awrap(e.$8.load(d("WACryptoManager").encodeSenderKey(a, c), function() {
                                var d;
                                return b("regeneratorRuntime").async(function(f) {
                                    while (1) switch (f.prev = f.next) {
                                        case 0:
                                            f.next = 2;
                                            return b("regeneratorRuntime").awrap(e.$9.loadSenderKeySession(a, c));
                                        case 2:
                                            d = f.sent;
                                            return f.abrupt("return", d.success ? d.value : null);
                                        case 4:
                                        case "end":
                                            return f.stop()
                                    }
                                }, null, this)
                            }));
                        case 2:
                            f = g.sent;
                            if (!(f == null)) {
                                g.next = 5;
                                break
                            }
                            return g.abrupt("return", d("WAResultOrError").makeError("errLoadSenderKeySession"));
                        case 5:
                            return g.abrupt("return", d("WAResultOrError").makeResult(f));
                        case 6:
                        case "end":
                            return g.stop()
                    }
                }, null, this)
            };
            this.handleNewSession = function(a, c, f, g, i) {
                e.storeSession(a, c);
                f != null && e.storeIdentity(a, f);
                g != null && e.removeOneTimePreKey(g);
                return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult())
            };
            this.saveICDC = function(a, c) {
                e.$3.store(a, c);
                return (h || (h = b("Promise"))).resolve()
            };
            this.loadICDC = function(a) {
                return e.$3.load(a, function() {
                    return e.$9.loadICDC(a)
                })
            };
            this.saveDhash = function(a, c) {
                e.$2.store(a, c);
                return (h || (h = b("Promise"))).resolve()
            };
            this.getLastPreKeyGenerationId = function() {
                return e.$9.getLastPreKeyGenerationId()
            };
            this.savePreKeysGeneration = function(a) {
                return e.$9.savePreKeysGeneration(a)
            };
            this.getPreKeyGenerationsTimestamps = function() {
                return e.$9.getPreKeyGenerationsTimestamps()
            };
            this.deletePreKeyGenerations = function(a) {
                return e.$9.deletePreKeyGenerations(a)
            };
            this.saveOneTimePreKey = function(a) {
                return e.$9.saveOneTimePreKey(a)
            };
            this.loadPreKeys = function(a) {
                return e.$9.loadPreKeys(a)
            };
            this.loadLatestSignedPreKey = function() {
                return e.$9.loadLatestSignedPreKey()
            };
            this.calculateICDC = function(a) {
                if (a.length === 0) return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeError("missing_participants"));
                var c = new Set();
                return (h || (h = b("Promise"))).all(a.map(function(a) {
                    var f, g, h, i, j, k, l, m, n, o, p, q, r;
                    return b("regeneratorRuntime").async(function(w) {
                        while (1) switch (w.prev = w.next) {
                            case 0:
                                w.next = 2;
                                return b("regeneratorRuntime").awrap(e.loadIdentities(a));
                            case 2:
                                f = w.sent;
                                w.next = 5;
                                return b("regeneratorRuntime").awrap(e.loadICDC(a));
                            case 5:
                                g = w.sent;
                                w.next = 8;
                                return b("regeneratorRuntime").awrap(e.$9.loadLastSyncTs(a));
                            case 8:
                                h = w.sent;
                                d("WAICDCUtils").isLastSyncTsExpired(h) && c.add(a);
                                j = new Map(Array.from(f.entries()).map(function(a) {
                                    var b = a[0];
                                    a = a[1];
                                    d("WAGlobals").getMyDeviceJid() === b && (i = a);
                                    return [d("WAIdentityUtils").removeKeyTypeIfNeeded(a).toString(), b]
                                }));
                                a === d("WAGlobals").getMyDeviceJid() && i == null && (c.add(a), v.ERROR(u()));
                                if (!(g == null || d("WAICDCUtils").isICDCIndexInvalid(g))) {
                                    w.next = 16;
                                    break
                                }
                                c.add(a);
                                a === d("WAGlobals").getMyUserJid() && v.ERROR(t());
                                return w.abrupt("return", null);
                            case 16:
                                k = [], (l = g.devices, m = Array.isArray(l), n = 0, l = m ? l : l[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]());
                            case 18:
                                if (!m) {
                                    w.next = 24;
                                    break
                                }
                                if (!(n >= l.length)) {
                                    w.next = 21;
                                    break
                                }
                                return w.abrupt("break", 37);
                            case 21:
                                o = l[n++];
                                w.next = 28;
                                break;
                            case 24:
                                n = l.next();
                                if (!n.done) {
                                    w.next = 27;
                                    break
                                }
                                return w.abrupt("break", 37);
                            case 27:
                                o = n.value;
                            case 28:
                                p = o;
                                q = d("WAIdentityUtils").removeKeyTypeIfNeeded(p).toString();
                                r = j.get(q);
                                if (!(r == null)) {
                                    w.next = 34;
                                    break
                                }
                                c.add(a);
                                return w.abrupt("continue", 35);
                            case 34:
                                k.push({
                                    id: d("WAJids").extractDeviceId(r),
                                    identity: d("WAIdentityUtils").removeKeyTypeIfNeeded(p)
                                });
                            case 35:
                                w.next = 18;
                                break;
                            case 37:
                                g.devices.length !== k.length && (c.add(a), v.ERROR(s()));
                                return w.abrupt("return", {
                                    devices: k,
                                    sequence: g.sequence,
                                    signingDeviceIndex: g.signingDeviceIndex,
                                    timestamp: g.timestamp,
                                    user: a
                                });
                            case 39:
                            case "end":
                                return w.stop()
                        }
                    }, null, this)
                })).then(function(a) {
                    a = a.filter(Boolean);
                    return a.length === 0 ? d("WAResultOrError").makeError("icdc-empty") : d("WAResultOrError").makeResult({
                        icdcInfo: a,
                        usersWithMissingICDC: c
                    })
                })["catch"](function(a) {
                    return d("WAResultOrError").makeError("runtime-exception", a)
                })
            };
            this.$9 = a;
            this.$10 = c;
            this.$5 = new(d("WASignalIdentityStore").SignalIdentityStore)();
            this.$1 = new((a = d("WASignalEntityStoreV2")).SignalEntityStore)();
            this.$2 = new a.SignalEntityStore();
            this.$3 = new a.SignalEntityStore();
            this.$4 = new a.SignalEntityStore();
            this.$6 = new a.SignalEntityStore();
            this.$7 = new a.SignalEntityStore();
            this.$8 = new a.SignalEntityStore()
        }
        var c = a.prototype;
        c.storeSession = function(a, b) {
            this.$1.store(a, b)
        };
        c.storeIdentity = function(a, b) {
            if (!b) return;
            this.$5.store(a, b)
        };
        c.removeOneTimePreKey = function(a) {
            this.$6.remove(a)
        };
        c.storeSenderKeySession = function(a, b, c) {
            this.$8.store(d("WACryptoManager").encodeSenderKey(a, b), c)
        };
        c.updateUserDevicesInfo = function(a) {
            var c = this;
            return (h || (h = b("Promise"))).all(a.map(function(a) {
                var e, f, g, i, j, k, s, t, u, w, x, y, z, A, B, C, D, E, F, G, H, I, J, K, L, M, N;
                return b("regeneratorRuntime").async(function(O) {
                    while (1) switch (O.prev = O.next) {
                        case 0:
                            O.next = 2;
                            return b("regeneratorRuntime").awrap(c.loadIdentities(a.jid));
                        case 2:
                            e = O.sent, (f = a.devices, g = a.jid, i = a.notificationTs, j = a.dhash, k = a.icdcInfo), v.DEV(r(), g, f.map(function(b) {
                                b = b.id;
                                return d("WAJids").toDeviceJid(a.jid, b)
                            }).join(","), Array.from(e.keys()).join(",")), s = new Set(e.keys()), t = [], u = [], (w = f, x = Array.isArray(w), y = 0, w = x ? w : w[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]());
                        case 9:
                            if (!x) {
                                O.next = 15;
                                break
                            }
                            if (!(y >= w.length)) {
                                O.next = 12;
                                break
                            }
                            return O.abrupt("break", 41);
                        case 12:
                            z = w[y++];
                            O.next = 19;
                            break;
                        case 15:
                            y = w.next();
                            if (!y.done) {
                                O.next = 18;
                                break
                            }
                            return O.abrupt("break", 41);
                        case 18:
                            z = y.value;
                        case 19:
                            A = z;
                            B = A.id;
                            C = A.identity;
                            D = A.model;
                            E = A.platform;
                            F = d("WAJids").toDeviceJid(a.jid, B);
                            G = e.get(F);
                            d("WAGlobals").getMyDeviceJid() === F && (H = d("WACryptoUtils").uint8ArraysEqual(d("WAIdentityUtils").removeKeyTypeIfNeeded(c.$10.staticKeyPair.publicKey), d("WAIdentityUtils").removeKeyTypeIfNeeded(C)), H || v.ERROR(q()));
                            s["delete"](F);
                            if (!(G == null)) {
                                O.next = 32;
                                break
                            }
                            u.push({
                                instruction: "identityAdded",
                                jid: d("WAJids").extractUserJid(F),
                                type: "instruction",
                                device: F,
                                identity: C,
                                model: D,
                                platform: E,
                                notificationTs: i,
                                priority: d("WAProtocolQueue").WAProtocolQueuePriorityLow
                            });
                            O.next = 39;
                            break;
                        case 32:
                            if (d("WACryptoUtils").uint8ArraysEqual(G, C)) {
                                O.next = 39;
                                break
                            }
                            if (!(d("WAJids").extractUserJid(F) !== g)) {
                                O.next = 36;
                                break
                            }
                            v.ERROR(p());
                            return O.abrupt("continue", 39);
                        case 36:
                            t.push(F), v.DEV(o(), F), u.push({
                                instruction: "identityChanged",
                                jid: d("WAJids").extractUserJid(F),
                                type: "instruction",
                                device: F,
                                identity: C,
                                model: D,
                                platform: E,
                                notificationTs: i,
                                priority: d("WAProtocolQueue").WAProtocolQueuePriorityLow
                            });
                        case 39:
                            O.next = 9;
                            break;
                        case 41:
                            I = [], (J = s, K = Array.isArray(J), L = 0, J = K ? J : J[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]());
                        case 43:
                            if (!K) {
                                O.next = 49;
                                break
                            }
                            if (!(L >= J.length)) {
                                O.next = 46;
                                break
                            }
                            return O.abrupt("break", 63);
                        case 46:
                            M = J[L++];
                            O.next = 53;
                            break;
                        case 49:
                            L = J.next();
                            if (!L.done) {
                                O.next = 52;
                                break
                            }
                            return O.abrupt("break", 63);
                        case 52:
                            M = L.value;
                        case 53:
                            N = M;
                            if (!(d("WAJids").extractUserJid(N) !== g)) {
                                O.next = 57;
                                break
                            }
                            v.ERROR(n());
                            return O.abrupt("continue", 61);
                        case 57:
                            I.push(N), d("WAGlobals").getMyDeviceJid() === N && v.ERROR(m()), v.DEV(l(), N), u.push({
                                instruction: "identityRemoved",
                                jid: d("WAJids").extractUserJid(N),
                                type: "instruction",
                                device: N,
                                notificationTs: i,
                                priority: d("WAProtocolQueue").WAProtocolQueuePriorityLow
                            });
                        case 61:
                            O.next = 43;
                            break;
                        case 63:
                            return O.abrupt("return", (h || (h = b("Promise"))).all([j != null ? c.saveDhash(g, j) : (h || (h = b("Promise"))).resolve(), k != null ? c.saveICDC(g, k) : (h || (h = b("Promise"))).resolve()].concat(Array.from(I).map(function(a) {
                                return c.deleteIdentity(a)
                            }), [I.concat(t).map(function(a) {
                                return c.$11(a)
                            })], f.map(function(b) {
                                var a = b.id;
                                b = b.identity;
                                return c.saveIdentity(d("WAJids").toDeviceJid(g, a), b)
                            }))).then(function() {
                                return d("WAResultOrError").makeResult(u)
                            }));
                        case 64:
                        case "end":
                            return O.stop()
                    }
                }, null, this)
            })).then(function(a) {
                a = a.flatMap(function(a) {
                    return a.success ? a.value : []
                });
                a.forEach(function(a) {
                    void d("WAProtocolQueue").protocolQueue().addPending(a)
                })
            }).then(function() {})
        };
        c.savePendingToDatabase = function() {
            var a = this,
                c = this.$12();
            if (c == null) return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult([]));
            v.DEV(k(), c);
            v.LOG(j());
            return this.$9.bulkSaveSignalData(c).then(function(b) {
                v.LOG(i());
                a.$13();
                return b
            }, function(c) {
                a.$14();
                return (h || (h = b("Promise"))).reject(c)
            })
        };
        c.clear = function() {
            this.$1.clear(), this.$5.clear(), this.$6.clear(), this.$7.clear(), this.$8.clear(), this.$2.clear(), this.$3.clear()
        };
        c.deleteIdentity = function(a) {
            this.$5.remove(a);
            return (h || (h = b("Promise"))).resolve()
        };
        c.$11 = function(a) {
            this.$1.remove(a);
            return (h || (h = b("Promise"))).resolve()
        };
        c.$13 = function() {
            this.$1.markSnapshotAsCommitted(), this.$2.markSnapshotAsCommitted(), this.$3.markSnapshotAsCommitted(), this.$5.markSnapshotAsCommitted(), this.$6.markSnapshotAsCommitted(), this.$7.markSnapshotAsCommitted(), this.$8.markSnapshotAsCommitted()
        };
        c.$14 = function() {
            this.$1.markSnapshotAsFailed(), this.$2.markSnapshotAsFailed(), this.$3.markSnapshotAsFailed(), this.$5.markSnapshotAsFailed(), this.$6.markSnapshotAsFailed(), this.$7.markSnapshotAsFailed(), this.$8.markSnapshotAsFailed()
        };
        c.$12 = function() {
            var a = this.$1.snapshot(),
                b = [],
                c = a.remove.map(function(a) {
                    return a.id
                });
            a.update.forEach(function(a) {
                var c = a.id;
                a = a.cachedEntity;
                if (a == null) return;
                b.push({
                    id: c,
                    updated: a
                })
            });
            var e = [];
            this.$8.snapshot().update.forEach(function(a) {
                var b = d("WACryptoManager").decodeSenderKey(a.id),
                    c = b.groupId;
                b = b.deviceId;
                a.cachedEntity != null && c && b && e.push({
                    groupId: c,
                    author: b,
                    updated: a.cachedEntity
                })
            });
            a = this.$5.snapshot();
            var f = a.remove.map(function(a) {
                    return a.id
                }),
                g = [];
            a.update.forEach(function(a) {
                var b = a.id;
                a = a.cachedEntity;
                if (a == null) return;
                g.push({
                    id: b,
                    identity: a
                })
            });
            a = this.$6.snapshot().remove;
            var h = this.$2.snapshot(),
                i = [];
            for (var h = h.update, j = Array.isArray(h), k = 0, h = j ? h : h[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var l;
                if (j) {
                    if (k >= h.length) break;
                    l = h[k++]
                } else {
                    k = h.next();
                    if (k.done) break;
                    l = k.value
                }
                l = l;
                var m = l.cachedEntity;
                l = l.id;
                m != null && i.push({
                    id: l,
                    dhash: m
                })
            }
            l = this.$3.snapshot();
            m = [];
            for (k = l.update, j = Array.isArray(k), h = 0, k = j ? k : k[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                if (j) {
                    if (h >= k.length) break;
                    l = k[h++]
                } else {
                    h = k.next();
                    if (h.done) break;
                    l = h.value
                }
                l = l;
                var n = l.cachedEntity;
                l = l.id;
                n != null && m.push({
                    id: l,
                    icdc: n
                })
            }
            return b.length === 0 && c.length === 0 && g.length === 0 && e.length === 0 && a.length === 0 && m.length === 0 && i.length === 0 && f.length === 0 ? null : {
                dhashUpdate: i,
                icdcUpdate: m,
                identityRemove: f,
                identityUpdate: g,
                preKeyRemove: a,
                senderKeySessionUpdate: e,
                sessionRemove: c,
                sessionUpdate: b
            }
        };
        c.warmCache = function(a) {
            var c, e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        f.next = 2;
                        return b("regeneratorRuntime").awrap(this.bulkLoadIdentities(a.map(d("WAJids").interpretAsUserJid).filter(Boolean)));
                    case 2:
                        c = f.sent;
                        e = Array.from(c.values()).reduce(function(a, b) {
                            return a.concat(Array.from(b.keys()))
                        }, []);
                        f.next = 6;
                        return b("regeneratorRuntime").awrap(this.loadSessions(e));
                    case 6:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        };
        return a
    }();
    g.InMemorySignalStoreImpl = a
}), 98);
__d("WARequestKeysBatcher", ["WAResolvable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        delayMs: 50,
        maxSize: 100
    };

    function a(a, b) {
        b = b === void 0 ? h : b;
        var c = b.delayMs,
            e = b.maxSize,
            f = null;

        function g(b) {
            f && f.args === b && (f = null);
            return a(b)
        }
        return function(a) {
            if (f != null) f.args.push(a);
            else {
                var b = [a],
                    h = new(d("WAResolvable").Resolvable)();
                a = h.promise.then(g);
                var i = function() {
                        return void h.resolve(b)
                    },
                    j = setTimeout(i, c);
                f = {
                    args: b,
                    batchPromise: a,
                    run: i,
                    timer: j
                }
            }
            a = f;
            i = a.args;
            j = a.batchPromise;
            var k = i.length - 1;
            if (i.length >= e) {
                clearTimeout((a = f) == null ? void 0 : a.timer);
                f.run();
                f = null
            }
            return j.then(function(a) {
                return a[k]
            })
        }
    }
    g.makeSimpleBatcher = a
}), 98);
__d("WARequestKeys", ["WABulkRequestKeys", "WAPromiseManagement", "WARequestKeysBatcher", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WARequestKeysBatcher").makeSimpleBatcher(function(a) {
        var c;
        return b("regeneratorRuntime").async(function(e) {
            while (1) switch (e.prev = e.next) {
                case 0:
                    e.next = 2;
                    return b("regeneratorRuntime").awrap(d("WABulkRequestKeys").bulkRequestKeys(a));
                case 2:
                    c = e.sent;
                    if (!(c.success === !1)) {
                        e.next = 5;
                        break
                    }
                    return e.abrupt("return", a.map(function() {
                        return c
                    }));
                case 5:
                    return e.abrupt("return", a.map(function(a) {
                        a = c.value.get(a);
                        return a ? d("WAResultOrError").makeResult(a) : d("WAResultOrError").makeError("errRequestKeysNoKeys")
                    }));
                case 6:
                case "end":
                    return e.stop()
            }
        }, null, this)
    });
    c = d("WAPromiseManagement").cacheWhilePending(function(a) {
        return a
    }, a);
    g.requestKeys = c
}), 98);
__d("WACryptoManagerUtils", ["Promise", "WABulkRequestKeys", "WACryptoDbCallbacks", "WACryptoManager", "WAGlobals", "WAHandleFailureUtils", "WAInMemorySignalStore", "WALogger", "WALoggerTag", "WAPREList", "WAPREMetrics", "WARequestKeys", "WAResultOrError", "WASignalKeys", "WASignalSignatures", "WATagsLogger", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Cannot generate one time prekey"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Cannot deserialize signed prekey"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No signed prekey: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[SendMessage] Fail encrypt messages"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Runtime excpetion when encrypting group content: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to encrypt group content: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["DecryptMsg runtime error: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["DecryptMsg runtime error: ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["DecryptMsg error: ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["DecryptMsg error: ", ""]);
        r = function() {
            return a
        };
        return a
    }
    var s = d("WATagsLogger").TAGS([c("WALoggerTag").SignedPrekey]);

    function a(a) {
        var b = new(d("WAInMemorySignalStore").InMemorySignalStoreImpl)(d("WACryptoDbCallbacks").getCryptoDbCallbacks(), a),
            c = t();
        return {
            manager: d("WACryptoManager").initCryptoManager({
                regInfo: a,
                storage: b,
                network: c
            }),
            storage: b
        }
    }

    function t() {
        return {
            requestKeys: d("WARequestKeys").requestKeys,
            bulkRequestKeys: d("WABulkRequestKeys").bulkRequestKeys
        }
    }

    function u(a, b) {
        if (b.success) a == null ? void 0 : a.endSuccess();
        else {
            var c, e = b.error;
            d("WALogger").WARN(r(), e);
            switch (e) {
                case "errDuplicateMsg":
                    a == null ? void 0 : a.addPoint(e);
                    a == null ? void 0 : a.endSuccess();
                    return;
                case "errCryptoDeserialization":
                case "errSignalNoSession":
                case "errSignalInvalidMsg":
                case "errInvalidMac":
                case "errSignalInvalidSignedPreKey":
                case "errSignalSignedPreKeyIdMismatch":
                case "errSignalSignedPreKeyDeserialization":
                case "errSignalInvalidOneTimeKey":
                case "errSignalOneTimeKeyMismatch":
                case "errSignalOneTimeKeyDeserialization":
                case "errSignalInvalidKey":
                case "errSignalDecryptionFailed":
                case "errSignalDeserializeInvalidProtoFormat":
                case "errSignalDeserializeRatchetKeyBadFormat":
                case "errSignalDeserializePkInvalidProtoFormat":
                case "errSignalDeserializePkKeyBadFormat":
                case "errSignalTooManyMessagesInFuture":
                case "errSignalEmptyVersionContentSuffix":
                case "errSignalContentExceededExpectedLength":
                case "errSignalGrpInvalidProtoFormat":
                case "errSignalGrpInvalidKeyFormat":
                case "errSignalGrpVersionContentEmpty":
                case "errSignalGrpInvalidVersionContentLength":
                case "errSignalGrpSenderKeyInvalidProtoFormat":
                case "errSignalGrpSenderKeyProtoError":
                case "errSignalGrpTooManyMessagesInFuture":
                    c = e;
                    break;
                default:
                    typeof e === "string" ? c = e : (d("WALogger").ERROR(q(), b), c = "fail");
                    break
            }
            a == null ? void 0 : a.endFail(c)
        }
    }

    function e(a, c, e, f, g) {
        var i = null;
        return d("WACryptoManager").decryptContent(f.cryptoManager, c, {
            ciphertext: e,
            type: a
        }, function(a, c) {
            i = {
                plaintext: a,
                remoteIdentity: c
            };
            return (h || (h = b("Promise"))).resolve()
        }).then(function(a) {
            u(g, a);
            if (a.success) return d("WAResultOrError").makeResult(i);
            else return a
        })["catch"](function(a) {
            g == null ? void 0 : g.endFail("runtime-exception");
            d("WALogger").ERROR(p(), a);
            throw a
        })
    }

    function f(a, c, e, f, g) {
        var i = null;
        return d("WACryptoManager").decryptGroupContent(f.cryptoManager, a, c, e, function(a) {
            i = {
                plaintext: a
            };
            return (h || (h = b("Promise"))).resolve()
        }).then(function(a) {
            u(g, a);
            if (a.success) return d("WAResultOrError").makeResult(i);
            else return a
        })["catch"](function(a) {
            g == null ? void 0 : g.endFail("runtime-exception");
            d("WALogger").ERROR(o(), a);
            throw a
        })
    }

    function v(a, b) {
        return d("WACryptoManager").getParticipantInfo(b, a)
    }

    function w(a) {
        return a.storage.getPreKeyGenerationsTimestamps()
    }

    function x(a, b) {
        return b.storage.deletePreKeyGenerations(a)
    }

    function y(a, b, c, e) {
        return d("WACryptoManager").saveSenderKeySession(e.cryptoManager, a, b, c)
    }

    function z(a) {
        return A.apply(this, arguments)
    }

    function A() {
        A = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var e = (yield a.storage.loadLatestSignedPreKey());
            if (e.success === !1) {
                var f;
                s.EXPECTED_ERROR(k(), (f = (f = e.payload) == null ? void 0 : f.toString()) != null ? f : "");
                d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.WA_NO_SIGNED_PRE_KEY).endFail("missing-signed-prekey");
                e.error === "missing-last-signed-prekey-id" && (yield d("WAHandleFailureUtils").reregisterPhone());
                throw (f = e.payload) != null ? f : c("err")("No signed prekey")
            }
            f = d("WASignalSignatures").deserializeSignedPreKey(e.value);
            if (f == null) {
                s.ERROR(j());
                throw c("err")("Cannot deserialize signed prekey")
            }
            e = (yield d("WACryptoManager").generateOneTimePreKey(a));
            if (e == null) {
                d("WATagsLogger").TAGS([c("WALoggerTag").OneTimePrekey]).ERROR(i());
                throw c("err")("Cannot generate one time prekey")
            }
            a = a.regInfo;
            var g = a.regId;
            a = a.staticKeyPair;
            return (h || (h = b("Promise"))).resolve({
                regId: g,
                keyType: d("WASignalKeys").KEY_TYPE,
                publicKey: a.publicKey,
                signedPreKey: f,
                preKey: e
            })
        });
        return A.apply(this, arguments)
    }

    function B(a, b, c) {
        var e = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.MESSAGE_ENCRYPTION, {
            string: {
                chat: "group",
                jid: a
            },
            bool: {
                useLongSessionDrop: d("WAGlobals").getConfig().useLongSessionDrop()
            }
        }, void 0);
        return d("WACryptoManager").encryptGroupContent(c.cryptoManager, a, d("WAGlobals").getMyDeviceJid(), b).then(function(a) {
            a.success ? e.endSuccess() : (d("WATagsLogger").TAGS(["EncryptGroupContent"]).ERROR(n(), a.error), e.endFail(a.error));
            return a
        })["catch"](function(a) {
            d("WATagsLogger").TAGS(["EncryptGroupContent"]).ERROR(m(), a);
            e.endFail("runtime-exception");
            return d("WAResultOrError").makeError("runtime-exception")
        })
    }

    function C(a, b, c, e, f, g) {
        var h = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.MESSAGE_ENCRYPTION, {
            string: {
                chat: "1:1",
                jid: c
            },
            string_array: {
                node_types: e,
                message_types: f,
                media_types: g
            },
            bool: {
                useLongSessionDrop: d("WAGlobals").getConfig().useLongSessionDrop()
            }
        }, void 0);
        return d("WACryptoManager").bulkEncryptContent(b.cryptoManager, a).then(function(a) {
            if (a.success) h.endSuccess();
            else {
                var b = a.error;
                switch (b) {
                    case "missing":
                    case "mismatch":
                    case "runtime-exception":
                        break;
                    default:
                        break
                }
                h.endFail(b)
            }
            return a
        })
    }

    function D(a, b, c, e, f, g) {
        var h = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.MESSAGE_ENCRYPTION, {
            string: {
                chat: "1:1",
                jid: g
            },
            bool: {
                useLongSessionDrop: d("WAGlobals").getConfig().useLongSessionDrop()
            }
        }, void 0);
        return d("WACryptoManager").encryptContent(c.cryptoManager, a, b, e || d("WACryptoManager").DEFAULT_SESSION_REQUEST, f).then(function(a) {
            if (a.success) h.endSuccess();
            else {
                var b = a.error;
                switch (b) {
                    case "identity-mismatch":
                    case "errSignalInvalidKey":
                        break;
                    default:
                        break
                }
                h.endFail(b)
            }
            return a
        })
    }

    function E(a, b) {
        return d("WACryptoManager").bulkEncryptContent(b.cryptoManager, a).then(function(a) {
            if (a.success === !1) {
                d("WALogger").ERROR(l());
                return new Map()
            }
            return a.value
        })
    }

    function F(a, b) {
        return G.apply(this, arguments)
    }

    function G() {
        G = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            a = (yield d("WACryptoManager").ensureSessionsExists(c.cryptoManager, a));
            yield(h || (h = b("Promise"))).all(Array.from(a.entries()).map(function(a) {
                var b = a[0];
                a = a[1];
                return c.cryptoManager.storage.handleNewSession(b, a, a.remote.pubKey)
            }))
        });
        return G.apply(this, arguments)
    }
    g.createCryptoManager = a;
    g.decryptMsg = e;
    g.decryptGroupMsg = f;
    g.getParticipantInfo = v;
    g.getPreKeyGenerationsTimestamps = w;
    g.deletePreKeyGenerations = x;
    g.saveSenderKeySession = y;
    g.getSignalInfoForRetry = z;
    g.encryptGroupContentWithMetrics = B;
    g.bulkEncryptMsgWithMetrics = C;
    g.encryptMsgWithMetrics = D;
    g.bulkEncrypt = E;
    g.bulkPreEstablishOutgoingSession = F
}), 98);
__d("WADecryptMedia", ["WAGlobals", "WAMediaCrypto", "WAResultOrError", "WATagsLogger", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Download Plaintext Success"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Download Plaintext Error ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Using default plaintext verifier"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " is not a working hmac salt."]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Found a working hmac salt using ", "."]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Trying ", " as an alternative hmac salt."]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Encountered enc-hash-mismatch - looking for a potential working hmac salt"]);
        n = function() {
            return a
        };
        return a
    }
    var o = d("WATagsLogger").TAGS(["WADecryptMedia"]);

    function p(a, c, e, f) {
        var g, h, i, j, p, q, r, s, t, u, v;
        return b("regeneratorRuntime").async(function(w) {
            while (1) switch (w.prev = w.next) {
                case 0:
                    o.WARN(n());
                    g = e.type === "preview" ? "preview" : e.mediaType;
                    w.next = 4;
                    return b("regeneratorRuntime").awrap(d("WAMediaCrypto").deprecated_getAllCommonComputedMediaKeys(f));
                case 4:
                    h = w.sent, (j = h, p = Array.isArray(j), q = 0, j = p ? j : j[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]());
                case 6:
                    if (!p) {
                        w.next = 12;
                        break
                    }
                    if (!(q >= j.length)) {
                        w.next = 9;
                        break
                    }
                    return w.abrupt("break", 39);
                case 9:
                    r = j[q++];
                    w.next = 16;
                    break;
                case 12:
                    q = j.next();
                    if (!q.done) {
                        w.next = 15;
                        break
                    }
                    return w.abrupt("break", 39);
                case 15:
                    r = q.value;
                case 16:
                    s = r;
                    t = s[0];
                    u = s[1];
                    w.prev = 19;
                    if (!(t === g)) {
                        w.next = 22;
                        break
                    }
                    return w.abrupt("continue", 37);
                case 22:
                    o.LOG(m(), t);
                    w.t0 = d("WAResultOrError").makeResult;
                    w.next = 26;
                    return b("regeneratorRuntime").awrap(d("WAMediaCrypto").hmacAndDecrypt(u.cipherKey, u.iv, a, u.hmacKey, c));
                case 26:
                    w.t1 = w.sent;
                    v = w.t0(w.t1);
                    i = {
                        hmacAndDecryptResult: v,
                        alternativeHmacSaltUsed: t
                    };
                    o.LOG(l(), t);
                    return w.abrupt("return", i);
                case 33:
                    w.prev = 33;
                    w.t2 = w["catch"](19);
                    o.LOG(k(), t);
                    return w.abrupt("continue", 37);
                case 37:
                    w.next = 6;
                    break;
                case 39:
                    return w.abrupt("return", {
                        hmacAndDecryptResult: d("WAResultOrError").makeError("enc-hash-mismatch")
                    });
                case 40:
                case "end":
                    return w.stop()
            }
        }, null, this, [
            [19, 33]
        ])
    }

    function a(a) {
        var c, e, f, g, k, l, m, n, q, r, s, t, u, v;
        return b("regeneratorRuntime").async(function(w) {
            while (1) switch (w.prev = w.next) {
                case 0:
                    c = a.ciphertextHmac, e = a.mediaKey, f = a.mediaTypeDetails, g = a.plaintextHash;
                    o.LOG(j());
                    k = c.byteLength - d("WAMediaCrypto").HMAC_LENGTH;
                    l = new Uint8Array(c, k);
                    m = new Uint8Array(c, 0, k);
                    f.type === "preview" ? n = d("WAMediaCrypto").computeMediaKeysForPreview(e) : n = d("WAMediaCrypto").computeMediaKeys(e, f.mediaType);
                    r = null;
                    w.next = 9;
                    return b("regeneratorRuntime").awrap(n.then(function(a) {
                        var b = a.iv,
                            c = a.cipherKey;
                        a = a.hmacKey;
                        return d("WAMediaCrypto").hmacAndDecrypt(c, b, m, a, l)
                    }).then(d("WAResultOrError").makeResult)["catch"](function(a) {
                        o.ERROR(i(), a);
                        if (a instanceof d("WAMediaCrypto").HmacValidationError) return d("WAResultOrError").makeError("enc-hash-mismatch");
                        else return d("WAResultOrError").makeError("decryption-error")
                    }));
                case 9:
                    q = w.sent;
                    if (!(d("WAGlobals").getConfig().isMediaFallbackToAlternativeHmacSaltsEnabled() === !0 && q.success === !1 && q.error === "enc-hash-mismatch")) {
                        w.next = 16;
                        break
                    }
                    w.next = 13;
                    return b("regeneratorRuntime").awrap(p(m, l, f, e));
                case 13:
                    s = w.sent, q = s.hmacAndDecryptResult, r = s.alternativeHmacSaltUsed;
                case 16:
                    if (q.success) {
                        w.next = 18;
                        break
                    }
                    return w.abrupt("return", q);
                case 18:
                    t = q.value, u = t.plaintext, v = t.plaintextHash;
                    if (!(g !== v)) {
                        w.next = 21;
                        break
                    }
                    return w.abrupt("return", d("WAResultOrError").makeError("hash-mismatch"));
                case 21:
                    o.LOG(h());
                    return w.abrupt("return", d("WAResultOrError").makeResult({
                        plaintext: u,
                        alternativeHmacSaltUsed: r
                    }));
                case 23:
                case "end":
                    return w.stop()
            }
        }, null, this)
    }
    g.decryptMedia = a
}), 98);
__d("WASmaxInMmsdIQErrorResponseMixin", ["WAResultOrError", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!b.success) return b;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "type", "error");
        return !c.success ? c : d("WAResultOrError").makeResult({
            type: c.value
        })
    }
    g.parseIQErrorResponseMixin = a
}), 98);
__d("WASmaxInMmsdEnums", [], (function(a, b, c, d, e, f) {
    a = {
        0: "0",
        1: "1"
    };
    b = {
        400: "400",
        401: "401",
        404: "404",
        408: "408",
        409: "409",
        415: "415",
        426: "426",
        429: "429"
    };
    c = {
        500: "500",
        501: "501",
        502: "502",
        503: "503",
        507: "507"
    };
    d = {
        fallback: "fallback",
        primary: "primary"
    };
    e = {
        "false": "false",
        "true": "true"
    };
    var g = {
        fna: "fna",
        pop: "pop"
    };
    f.ENUM_0_1 = a;
    f.ENUM_400_401_404_408_409_415_426_429 = b;
    f.ENUM_500_501_502_503_507 = c;
    f.ENUM_FALLBACK_PRIMARY = d;
    f.ENUM_FALSE_TRUE = e;
    f.ENUM_FNA_POP = g
}), 66);
__d("WASmaxInMmsdRequestErrorMixin", ["WAResultOrError", "WASmaxInMmsdEnums", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrString(a, "text");
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").attrStringEnum(a, "code", d("WASmaxInMmsdEnums").ENUM_400_401_404_408_409_415_426_429);
        if (!c.success) return c;
        a = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, a, "backoff", 0, 10800);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: c.value,
            backoff: a.value
        })
    }
    g.parseRequestErrorMixin = a
}), 98);
__d("WASmaxInMmsdResignCdnUrlResponseClientError", ["WAResultOrError", "WASmaxInMmsdIQErrorResponseMixin", "WASmaxInMmsdRequestErrorMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        c = d("WASmaxInMmsdRequestErrorMixin").parseRequestErrorMixin(c.value);
        if (!c.success) return c;
        a = d("WASmaxInMmsdIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            errorRequestErrorMixin: c.value
        }, a.value))
    }
    g.parseResignCdnUrlResponseClientError = a
}), 98);
__d("WASmaxInMmsdServerErrorMixin", ["WAResultOrError", "WASmaxInMmsdEnums", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrString(a, "text");
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").attrStringEnum(a, "code", d("WASmaxInMmsdEnums").ENUM_500_501_502_503_507);
        if (!c.success) return c;
        a = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, a, "backoff", 0, 10800);
        return !a.success ? a : d("WAResultOrError").makeResult({
            text: b.value,
            code: c.value,
            backoff: a.value
        })
    }
    g.parseServerErrorMixin = a
}), 98);
__d("WASmaxInMmsdResignCdnUrlResponseServerError", ["WAResultOrError", "WASmaxInMmsdIQErrorResponseMixin", "WASmaxInMmsdServerErrorMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        c = d("WASmaxInMmsdServerErrorMixin").parseServerErrorMixin(c.value);
        if (!c.success) return c;
        a = d("WASmaxInMmsdIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            errorServerErrorMixin: c.value
        }, a.value))
    }
    g.parseResignCdnUrlResponseServerError = a
}), 98);
__d("WASmaxInMmsdIQResultResponseMixin", ["WAResultOrError", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!b.success) return b;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "type", "result");
        return !c.success ? c : d("WAResultOrError").makeResult({
            type: c.value
        })
    }
    g.parseIQResultResponseMixin = a
}), 98);
__d("WASmaxInMmsdResignCdnUrlResponseSuccess", ["WAResultOrError", "WASmaxInMmsdIQResultResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "cdn_url_resign");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").attrString(c.value, "direct_path");
        if (!c.success) return c;
        a = d("WASmaxInMmsdIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            cdnUrlResignDirectPath: c.value
        }, a.value))
    }
    g.parseResignCdnUrlResponseSuccess = a
}), 98);
__d("WASmaxOutMmsdBaseIQGetRequestMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("iq", {
            id: d("WAWap").generateId(),
            type: "get"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBaseIQGetRequestMixin = a
}), 98);
__d("WASmaxOutMmsdIQRequestCommonMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("iq", {
            xmlns: "w:m",
            to: d("WAWap").S_WHATSAPP_NET
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIQRequestCommonMixin = a
}), 98);
__d("WASmaxMixinGroupExhaustiveError", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.name = "SmaxMixinGroupExhaustiveError", b) || babelHelpers.assertThisInitialized(c)
        }
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    f.SmaxMixinGroupExhaustiveError = a
}), 66);
__d("WASmaxOutMmsdResignCdnUrlResignWithHandleParamsMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.cdnUrlResignHandle;
        a = d("WASmaxJsx").smax("cdn_url_resign", {
            handle: d("WAWap").CUSTOM_STRING(a),
            use_case_hint: "wa_stickers"
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeResignCdnUrlResignWithHandleParamsMixin = a
}), 98);
__d("WASmaxOutMmsdResignCdnUrlResignWithObjectIdAndFBIdParamsMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.cdnUrlResignFbid;
        a = a.cdnUrlResignObjectId;
        b = d("WASmaxJsx").smax("cdn_url_resign", {
            fbid: d("WAWap").CUSTOM_STRING(b),
            object_id: d("WAWap").CUSTOM_STRING(a),
            use_case_hint: "fb_encrypted_backup"
        });
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeResignCdnUrlResignWithObjectIdAndFBIdParamsMixin = a
}), 98);
__d("WASmaxOutMmsdResignWithResignCdnUrlObjectIdAndFBIdOrResignCdnUrlHandleParamsMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMmsdResignCdnUrlResignWithHandleParamsMixin", "WASmaxOutMmsdResignCdnUrlResignWithObjectIdAndFBIdParamsMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.resignCdnUrlResignWithObjectIdAndFBIdParams) return d("WASmaxOutMmsdResignCdnUrlResignWithObjectIdAndFBIdParamsMixin").mergeResignCdnUrlResignWithObjectIdAndFBIdParamsMixin(a, b.resignCdnUrlResignWithObjectIdAndFBIdParams);
        if (b.resignCdnUrlResignWithHandleParams) return d("WASmaxOutMmsdResignCdnUrlResignWithHandleParamsMixin").mergeResignCdnUrlResignWithHandleParamsMixin(a, b.resignCdnUrlResignWithHandleParams);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeResignWithResignCdnUrlObjectIdAndFBIdOrResignCdnUrlHandleParamsMixinGroup = a
}), 98);
__d("WASmaxOutMmsdResignCdnUrlResignParamsMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMmsdResignWithResignCdnUrlObjectIdAndFBIdOrResignCdnUrlHandleParamsMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.resignWithResignCdnUrlObjectIdAndFBIdOrResignCdnUrlHandleParamsMixinGroupArgs;
        a = d("WASmaxOutMmsdResignWithResignCdnUrlObjectIdAndFBIdOrResignCdnUrlHandleParamsMixinGroup").mergeResignWithResignCdnUrlObjectIdAndFBIdOrResignCdnUrlHandleParamsMixinGroup(d("WASmaxJsx").smax("cdn_url_resign", null), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeResignCdnUrlResignParamsMixin = a
}), 98);
__d("WASmaxOutMmsdResignCdnUrlRequest", ["WASmaxJsx", "WASmaxOutMmsdBaseIQGetRequestMixin", "WASmaxOutMmsdIQRequestCommonMixin", "WASmaxOutMmsdResignCdnUrlResignParamsMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = a.cdnUrlResignSignDuration;
        a = a.resignCdnUrlResignParamsMixinArgs;
        b = d("WASmaxOutMmsdIQRequestCommonMixin").mergeIQRequestCommonMixin(d("WASmaxOutMmsdBaseIQGetRequestMixin").mergeBaseIQGetRequestMixin(d("WASmaxJsx").smax("iq", null, d("WASmaxOutMmsdResignCdnUrlResignParamsMixin").mergeResignCdnUrlResignParamsMixin(d("WASmaxJsx").smax("cdn_url_resign", {
            sign_duration: d("WAWap").INT(b)
        }), a))));
        return b
    }
    g.makeResignCdnUrlRequest = a
}), 98);
__d("WASmaxMmsdResignCdnUrlRPC", ["WAComms", "WASmaxInMmsdResignCdnUrlResponseClientError", "WASmaxInMmsdResignCdnUrlResponseServerError", "WASmaxInMmsdResignCdnUrlResponseSuccess", "WASmaxOutMmsdResignCdnUrlRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h, i;
        return b("regeneratorRuntime").async(function(j) {
            while (1) switch (j.prev = j.next) {
                case 0:
                    e = d("WASmaxOutMmsdResignCdnUrlRequest").makeResignCdnUrlRequest(a);
                    j.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = j.sent;
                    g = d("WASmaxInMmsdResignCdnUrlResponseSuccess").parseResignCdnUrlResponseSuccess(f, e);
                    if (!g.success) {
                        j.next = 7;
                        break
                    }
                    return j.abrupt("return", {
                        name: "ResignCdnUrlResponseSuccess",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInMmsdResignCdnUrlResponseClientError").parseResignCdnUrlResponseClientError(f, e);
                    if (!h.success) {
                        j.next = 10;
                        break
                    }
                    return j.abrupt("return", {
                        name: "ResignCdnUrlResponseClientError",
                        value: h.value
                    });
                case 10:
                    i = d("WASmaxInMmsdResignCdnUrlResponseServerError").parseResignCdnUrlResponseServerError(f, e);
                    if (!i.success) {
                        j.next = 13;
                        break
                    }
                    return j.abrupt("return", {
                        name: "ResignCdnUrlResponseServerError",
                        value: i.value
                    });
                case 13:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("ResignCdnUrl", {
                        Success: g,
                        ClientError: h,
                        ServerError: i
                    }));
                case 14:
                case "end":
                    return j.stop()
            }
        }, null, this)
    }
    g.sendResignCdnUrlRPC = a
}), 98);
__d("WAGetResignedCdnUrl", ["WAAssertUnreachable", "WAErrorMessage", "WALogger", "WAMediaUtils", "WAPromiseRetryLoop", "WAResultOrError", "WASmaxMmsdResignCdnUrlRPC", "WASmaxParsingFailure"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["requestCdnResignedUrl - Unknown Error ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["requestCdnResignedUrl - Error thrown whilst parsing SMAX response - ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Direct path signature expired. objectId: ", ", fbid: ", "."]);
        j = function() {
            return a
        };
        return a
    }
    var k = "507",
        l = 259200;

    function a(a) {
        var b = a.objectId;
        a = a.fbid;
        b = new(d("WAPromiseRetryLoop").PromiseRetryLoop)({
            name: "requestCdnResignedUrl",
            timer: {
                jitter: .25,
                max: 987e3,
                algo: {
                    type: "fibonacci",
                    first: 6e3,
                    second: 12e3
                },
                relativeDelay: !0
            },
            code: m({
                objectId: b,
                fbid: a
            })
        });
        b.start();
        return b.promise()
    }

    function m(a) {
        var b = a.objectId,
            e = a.fbid;
        return function(a) {
            d("WALogger").LOG(j(), b, e);
            return d("WASmaxMmsdResignCdnUrlRPC").sendResignCdnUrlRPC({
                cdnUrlResignSignDuration: l,
                resignCdnUrlResignParamsMixinArgs: {
                    resignWithResignCdnUrlObjectIdAndFBIdOrResignCdnUrlHandleParamsMixinGroupArgs: {
                        resignCdnUrlResignWithObjectIdAndFBIdParams: {
                            cdnUrlResignFbid: e,
                            cdnUrlResignObjectId: b
                        }
                    }
                }
            }).then(function(b) {
                switch (b.name) {
                    case "ResignCdnUrlResponseSuccess":
                        return a(d("WAResultOrError").makeResult(d("WAMediaUtils").unsafeCastToDirectPath(b.value.cdnUrlResignDirectPath)));
                    case "ResignCdnUrlResponseClientError":
                        return a(d("WAResultOrError").makeError({
                            type: "client-error",
                            text: b.value.errorRequestErrorMixin.text
                        }));
                    case "ResignCdnUrlResponseServerError":
                        if (b.value.errorServerErrorMixin.code !== k) return;
                        return a(d("WAResultOrError").makeError({
                            type: "server-error",
                            text: b.value.errorServerErrorMixin.text,
                            backoff: b.value.errorServerErrorMixin.backoff
                        }));
                    default:
                        throw c("WAAssertUnreachable")(b.name)
                }
            })["catch"](function(b) {
                var c = d("WAErrorMessage").maybeGetMessageFromError(b);
                if (b instanceof d("WASmaxParsingFailure").SmaxParsingFailure) {
                    d("WALogger").ERROR(i(), c);
                    return a(d("WAResultOrError").makeError({
                        type: "smax-parsing-error"
                    }))
                } else {
                    d("WALogger").ERROR(h(), c);
                    return
                }
            })
        }
    }
    g.getCdnResignedUrl = a
}), 98);
__d("WAHttpDownloadMedia", ["WAErrorMessage", "WAGlobals", "WALogger", "WAMediaQplHelper", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Download Media Error: can not resume from offset"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpDownloadMedia: fail to parse request body: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Fetch Media HTTP status ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpDownloadMedia: fail to initiate fetch: ", ", message: ", ""]);
        k = function() {
            return a
        };
        return a
    }
    var l = "URL signature expired";

    function a(a, c) {
        var e, f, g, m, n, o, p, q;
        return b("regeneratorRuntime").async(function(r) {
            while (1) switch (r.prev = r.next) {
                case 0:
                    f = (e = c) != null ? e : {}, g = f.mediaMetrics, m = f.abortSignal;
                    g == null ? void 0 : g.addPoint("http_fetch_start");
                    r.next = 4;
                    return b("regeneratorRuntime").awrap(self.fetch(a, {
                        method: "GET",
                        mode: "cors",
                        cache: d("WAGlobals").getConfig().isHttpFetchCacheEnabled() ? "force-cache" : "no-store",
                        signal: m
                    }).then(function(a) {
                        g == null ? void 0 : g.addPoint("http_fetch_end");
                        return d("WAResultOrError").makeResult(a)
                    })["catch"](function(a) {
                        var b = d("WAErrorMessage").maybeGetMessageFromError(a);
                        g == null ? void 0 : g.addPoint("http_fetch_fail", {
                            string: {
                                httpFetchError: b
                            }
                        });
                        d("WALogger").WARN(k(), a, b);
                        return d("WAResultOrError").makeError("http-fetch-exception")
                    }));
                case 4:
                    n = r.sent;
                    if (!(n.success === !1)) {
                        r.next = 7;
                        break
                    }
                    return r.abrupt("return", n);
                case 7:
                    o = n.value;
                    p = o.headers.get("content-length");
                    q = o.status;
                    d("WALogger").LOG(j(), q);
                    g == null ? void 0 : g.addAnnotations({
                        string: {
                            ciphertextMediaSizeBucket: p != null ? d("WAMediaQplHelper").convertIntegerSizeToStringBucket(Number(p)) : null
                        },
                        "int": {
                            httpStatus: q
                        }
                    });
                    r.t0 = q;
                    r.next = r.t0 === 200 ? 15 : r.t0 === 206 ? 15 : r.t0 === 401 ? 16 : r.t0 === 403 ? 17 : r.t0 === 404 ? 18 : r.t0 === 410 ? 18 : r.t0 === 408 ? 19 : r.t0 === 416 ? 20 : r.t0 === 429 ? 22 : r.t0 === 507 ? 22 : 23;
                    break;
                case 15:
                    return r.abrupt("return", d("WAResultOrError").makeResult(o));
                case 16:
                    return r.abrupt("return", d("WAResultOrError").makeError("access-expired"));
                case 17:
                    return r.abrupt("return", o.text().then(function(a) {
                        return a === l ? d("WAResultOrError").makeError("signature-expired") : d("WAResultOrError").makeError("access-expired")
                    })["catch"](function(a) {
                        d("WALogger").ERROR(i(), a);
                        return d("WAResultOrError").makeError("access-expired")
                    }));
                case 18:
                    return r.abrupt("return", d("WAResultOrError").makeError("media-not-found"));
                case 19:
                    return r.abrupt("return", d("WAResultOrError").makeError("server-timeout"));
                case 20:
                    d("WALogger").ERROR(h());
                    return r.abrupt("return", d("WAResultOrError").makeError("request-error"));
                case 22:
                    return r.abrupt("return", d("WAResultOrError").makeError("download-throttled"));
                case 23:
                    if (!(q >= 400 && q < 500)) {
                        r.next = 25;
                        break
                    }
                    return r.abrupt("return", d("WAResultOrError").makeError("request-error"));
                case 25:
                    return r.abrupt("return", d("WAResultOrError").makeError("unspecified-http-error"));
                case 26:
                case "end":
                    return r.stop()
            }
        }, null, this)
    }
    g.httpDownloadMedia = a
}), 98);
__d("WADownloadCiphertext", ["WAAssertUnreachable", "WABase64", "WACreateMediaDownloadRetrier", "WACryptoSha256", "WACryptoUtils", "WAGetResignedCdnUrl", "WAHashUtils", "WAHttpDownloadMedia", "WALogger", "WAMediaUrl", "WAPromiseDelays", "WAPromiseManagement", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Download Plaintext failed: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["downloadMedia given up"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["downloadCiphertext http download exception: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["result to generate a new cdn url was throttled (507)"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Cannot generate a new cdn url: missing objectId or fbid"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Download Media Error: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpDownloadMedia: fail to parse request body ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Downloading ciphertext for hash : ", " from ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Start download ciphertext for hash: ", ""]);
        p = function() {
            return a
        };
        return a
    }

    function a(a) {
        var e, f, g, r, s, t, u, v, w, x, y, z, A, B, C, D, E;
        return b("regeneratorRuntime").async(function(F) {
            while (1) switch (F.prev = F.next) {
                case 0:
                    e = a.mediaTypeDetails, f = a.fileEncSha256, g = a.directPath, r = a.plaintextHash, s = a.objectId, t = a.fbid, u = a.pathRedirected, v = a.eventFlow, w = a.fromBytes, x = a.toBytes;
                    d("WALogger").LOG(p(), d("WAHashUtils").sanitisePlaintextHash(r));
                    F.next = 4;
                    return b("regeneratorRuntime").awrap(d("WACreateMediaDownloadRetrier").createMediaDownloadRetrier({
                        mediaTypeDetails: e,
                        directPath: g,
                        eventFlow: v,
                        fileEncSha256: f
                    }));
                case 4:
                    y = F.sent;
                    if (y.success) {
                        F.next = 7;
                        break
                    }
                    return F.abrupt("return", y);
                case 7:
                    z = y.value, A = z.retrier, B = z.mediaRouteDetails;
                    F.next = 10;
                    return b("regeneratorRuntime").awrap(A.run(function(a) {
                        a = a.domain;
                        a = d("WAMediaUrl").buildDownloadUrl(g, f, a, "manual", B.bucket, w, x);
                        d("WALogger").DEV_XMPP(o(), d("WAHashUtils").sanitisePlaintextHash(r), a);
                        v == null ? void 0 : v.addPoint("http_download_media_start");
                        return d("WAHttpDownloadMedia").httpDownloadMedia(a, {
                            mediaMetrics: v
                        }).then(function(c) {
                            var a, e, f, g;
                            return b("regeneratorRuntime").async(function(h) {
                                while (1) switch (h.prev = h.next) {
                                    case 0:
                                        if (!c.success) {
                                            h.next = 4;
                                            break
                                        }
                                        return h.abrupt("return", c.value.arrayBuffer().then(function(a) {
                                            v == null ? void 0 : v.addPoint("http_download_media_end");
                                            return d("WAResultOrError").makeResult(d("WAResultOrError").makeResult(a))
                                        })["catch"](function(a) {
                                            v == null ? void 0 : v.addPoint("response_array_buffer_error");
                                            d("WALogger").ERROR(n(), a);
                                            return d("WAResultOrError").makeResult(d("WAResultOrError").makeError("body-network-error"))
                                        }));
                                    case 4:
                                        v == null ? void 0 : v.addPoint("http_download_media_fail");
                                        a = c.error;
                                        d("WALogger").LOG(m(), a);
                                        h.t0 = a;
                                        h.next = h.t0 === "signature-expired" ? 10 : h.t0 === "http-fetch-exception" ? 37 : h.t0 === "server-timeout" ? 37 : h.t0 === "unspecified-http-error" ? 37 : 38;
                                        break;
                                    case 10:
                                        if (!(s == null || t == null)) {
                                            h.next = 13;
                                            break
                                        }
                                        d("WALogger").LOG(l());
                                        return h.abrupt("return", d("WAResultOrError").makeResult(d("WAResultOrError").makeError("signature-expired")));
                                    case 13:
                                        h.next = 15;
                                        return b("regeneratorRuntime").awrap(d("WAGetResignedCdnUrl").getCdnResignedUrl({
                                            objectId: s,
                                            fbid: t
                                        }));
                                    case 15:
                                        e = h.sent;
                                        if (e.success) {
                                            h.next = 31;
                                            break
                                        }
                                        v == null ? void 0 : v.addPoint("resign_cdn_url_fail", {
                                            string: {
                                                resignCdnErrorType: e.error.type,
                                                resignCdnError: e.error.text
                                            }
                                        });
                                        f = d("WAResultOrError").makeResult(d("WAResultOrError").makeError("signature-expired"));
                                        h.t1 = e.error.type;
                                        h.next = h.t1 === "client-error" ? 22 : h.t1 === "server-error" ? 23 : 29;
                                        break;
                                    case 22:
                                        return h.abrupt("return", f);
                                    case 23:
                                        if (!(e.error.backoff != null)) {
                                            h.next = 28;
                                            break
                                        }
                                        g = e.error.backoff;
                                        v == null ? void 0 : v.addPoint("resign_cdn_url_backoff");
                                        d("WALogger").LOG(k());
                                        return h.abrupt("return", d("WAPromiseDelays").delayMs(g).then(function() {
                                            return d("WAResultOrError").makeResult(d("WAResultOrError").makeError("signature-expired"))
                                        }));
                                    case 28:
                                        return h.abrupt("return", f);
                                    case 29:
                                        e.error.type;
                                        return h.abrupt("return", f);
                                    case 31:
                                        e.success;
                                        v == null ? void 0 : v.addPoint("resign_cdn_url_success");
                                        if (!(u != null)) {
                                            h.next = 36;
                                            break
                                        }
                                        h.next = 36;
                                        return b("regeneratorRuntime").awrap(u(e.value));
                                    case 36:
                                        return h.abrupt("return", d("WAResultOrError").makeResult(d("WAResultOrError").makeError("signature-expired")));
                                    case 37:
                                        return h.abrupt("return", d("WAResultOrError").makeError({
                                            progressMade: !0
                                        }));
                                    case 38:
                                        return h.abrupt("return", d("WAResultOrError").makeResult(d("WAResultOrError").makeError(a)));
                                    case 39:
                                    case "end":
                                        return h.stop()
                                }
                            }, null, this)
                        })["catch"](function(a) {
                            d("WALogger").WARN(j(), a);
                            return d("WAResultOrError").makeError({
                                progressMade: !1
                            })
                        })
                    }));
                case 10:
                    C = F.sent;
                    if (!(C == null)) {
                        F.next = 14;
                        break
                    }
                    d("WALogger").WARN(i());
                    return F.abrupt("return", d("WAResultOrError").makeError("max-attempts-exceeded"));
                case 14:
                    if (!(C.success === !1)) {
                        F.next = 26;
                        break
                    }
                    D = C.error;
                    d("WALogger").WARN(h(), D);
                    F.t0 = D;
                    F.next = F.t0 === "signature-expired" ? 20 : F.t0 === "media-not-found" ? 20 : F.t0 === "download-throttled" ? 20 : F.t0 === "body-network-error" ? 20 : F.t0 === "request-error" ? 20 : F.t0 === "access-expired" ? 21 : 22;
                    break;
                case 20:
                    return F.abrupt("return", d("WAResultOrError").makeError(D));
                case 21:
                    return F.abrupt("return", d("WAResultOrError").makeError("disconnected"));
                case 22:
                    D;
                    throw c("WAAssertUnreachable")(D);
                case 24:
                    F.next = 39;
                    break;
                case 26:
                    E = C.value;
                    F.t1 = !q(w, x);
                    if (!F.t1) {
                        F.next = 35;
                        break
                    }
                    F.t2 = d("WACryptoUtils").arrayBuffersEqual;
                    F.next = 32;
                    return b("regeneratorRuntime").awrap(d("WACryptoSha256").sha256(E));
                case 32:
                    F.t3 = F.sent, F.t4 = f, F.t1 = !F.t2(F.t3, F.t4);
                case 35:
                    if (!F.t1) {
                        F.next = 37;
                        break
                    }
                    return F.abrupt("return", d("WAResultOrError").makeError("ciphertext-hash-mismatch"));
                case 37:
                    v == null ? void 0 : v.addPoint("download_finish", {
                        "int": {
                            byteLength: E.byteLength
                        },
                        bool: {
                            isPartialDownload: q(w, x)
                        }
                    });
                    return F.abrupt("return", d("WAResultOrError").makeResult(E));
                case 39:
                case "end":
                    return F.stop()
            }
        }, null, this)
    }
    e = d("WAPromiseManagement").cacheWhilePending(function(a) {
        var b = a.fileEncSha256,
            c = a.fromBytes;
        a = a.toBytes;
        return d("WABase64").encodeB64UrlSafe(b) + "-" + ((b = c) != null ? b : "X") + "-" + ((c = a) != null ? c : "X")
    }, a);

    function q(a, b) {
        return a != null && a > 0 ? !0 : b != null
    }
    g.cachedDownloadCiphertext = e
}), 98);
__d("WADownloadAndDecryptMedia", ["WADecryptMedia", "WADownloadCiphertext", "WAResultOrError", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var c, e, f, g, h, i, j, k, l, m, n;
        return b("regeneratorRuntime").async(function(o) {
            while (1) switch (o.prev = o.next) {
                case 0:
                    c = a.mediaTypeDetails, e = a.fileEncSha256, f = a.directPath, g = a.mediaKey, h = a.plaintextHash, i = a.objectId, j = a.fbid, k = a.pathRedirected, l = a.eventFlow;
                    o.next = 3;
                    return b("regeneratorRuntime").awrap(d("WADownloadCiphertext").cachedDownloadCiphertext({
                        mediaTypeDetails: c,
                        fileEncSha256: e,
                        directPath: f,
                        objectId: i,
                        fbid: j,
                        pathRedirected: k,
                        eventFlow: l,
                        plaintextHash: h
                    }));
                case 3:
                    m = o.sent;
                    if (!(m.success !== !0)) {
                        o.next = 6;
                        break
                    }
                    return o.abrupt("return", m);
                case 6:
                    o.next = 8;
                    return b("regeneratorRuntime").awrap(d("WADecryptMedia").decryptMedia({
                        mediaKey: g,
                        mediaTypeDetails: c,
                        plaintextHash: h,
                        ciphertextHmac: m.value
                    }));
                case 8:
                    n = o.sent;
                    if (!(n.success !== !0)) {
                        o.next = 11;
                        break
                    }
                    return o.abrupt("return", n);
                case 11:
                    n.value.alternativeHmacSaltUsed != null && l.addAnnotations({
                        string: {
                            alternativeHmacSaltUsed: n.value.alternativeHmacSaltUsed
                        }
                    });
                    return o.abrupt("return", d("WAResultOrError").makeResult(n.value.plaintext));
                case 13:
                case "end":
                    return o.stop()
            }
        }, null, this)
    }
    g.downloadAndDecryptMedia = a
}), 98);
__d("WAProgressiveJpegAlignScanLengths", ["WAAlignChunkLengthsToMultipleOfAesBlockSize"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.scanLengths;
        a = a.totalEncryptedBytes;
        return d("WAAlignChunkLengthsToMultipleOfAesBlockSize").alignChunkLengthsToMultipleOfAesBlockSize(b.map(function(a) {
            return a
        }), a).map(function(a) {
            return a
        })
    }

    function b(a) {
        return a
    }
    g.progressiveJpegAlignChunkLengthsToMultipleOfAesBlockSize = a;
    g.toProgressiveJpegAlignedScanLength = b
}), 98);
__d("WAProgressiveJpegGetPJpegDetails", ["WAMediaCrypto", "WAProgressiveJpegAlignScanLengths", "WAProgressiveJpegGetScanLengths", "WAResultOrError", "WATagsLogger", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Progressive Jpeg has too few scans"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Progressive Jpeg sidecar size mismatch"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Progressive Jpeg sidecar is missing"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Progressive Jpeg sidecar has an invalid length"]);
        k = function() {
            return a
        };
        return a
    }
    var l = d("WATagsLogger").TAGS(["WAProgressiveJpegDetails"]);

    function a(a) {
        var b = a.progressiveJpegDetails;
        a = a.ciphertextLength;
        return babelHelpers["extends"]({}, b, {
            alignedScanLengths: d("WAProgressiveJpegAlignScanLengths").progressiveJpegAlignChunkLengthsToMultipleOfAesBlockSize({
                scanLengths: b.scanLengths,
                totalEncryptedBytes: a
            })
        })
    }

    function c(a, c, e) {
        var f, g, h, i;
        return b("regeneratorRuntime").async(function(j) {
            while (1) switch (j.prev = j.next) {
                case 0:
                    f = c.byteLength - d("WAMediaCrypto").IV_LENGTH;
                    g = d("WAProgressiveJpegGetScanLengths").getProgressiveJpegScanLengths(a);
                    h = d("WAProgressiveJpegAlignScanLengths").progressiveJpegAlignChunkLengthsToMultipleOfAesBlockSize({
                        scanLengths: g,
                        totalEncryptedBytes: f
                    });
                    j.next = 5;
                    return b("regeneratorRuntime").awrap(m(h, c, e));
                case 5:
                    i = j.sent;
                    return j.abrupt("return", {
                        scanLengths: g,
                        sidecar: i
                    });
                case 7:
                case "end":
                    return j.stop()
            }
        }, null, this)
    }

    function m(a, c, e) {
        var f, g, h, i, j, k, l, m, n;
        return b("regeneratorRuntime").async(function(o) {
            while (1) switch (o.prev = o.next) {
                case 0:
                    f = new Uint8Array(a.length * 10), g = 0, h = 0, i = c.slice(0, 16), j = c.slice(16), k = 0;
                case 6:
                    if (!(k < a.length)) {
                        o.next = 19;
                        break
                    }
                    l = a[k];
                    h = g + l;
                    m = j.subarray(g, h);
                    o.next = 12;
                    return b("regeneratorRuntime").awrap(d("WAMediaCrypto").hmacCiphertext(e, i, m));
                case 12:
                    n = o.sent.slice(0, 10), f.set(new Uint8Array(n), k * 10), i = m.slice(m.length - 16, m.length), g = h;
                case 16:
                    k++;
                    o.next = 6;
                    break;
                case 19:
                    return o.abrupt("return", f.buffer);
                case 20:
                case "end":
                    return o.stop()
            }
        }, null, this)
    }

    function n(a) {
        if (a.sidecar.byteLength % d("WAMediaCrypto").HMAC_LENGTH !== 0) {
            l.ERROR(k());
            return d("WAResultOrError").makeError("pjpeg-check-sidecar-invalid-length")
        }
        if (a.scanLengths.length > 0 && a.sidecar.byteLength === 0) {
            l.ERROR(j());
            return d("WAResultOrError").makeError("pjpeg-check-no-sidecar")
        }
        if (a.scanLengths.length === 0) return d("WAResultOrError").makeResult(!1);
        if (a.scanLengths.length * d("WAMediaCrypto").HMAC_LENGTH !== a.sidecar.byteLength) {
            l.ERROR(i());
            return d("WAResultOrError").makeError("pjpeg-check-scan-length-mismatch")
        }
        if (a.scanLengths.length < 3) {
            l.WARN(h());
            return d("WAResultOrError").makeError("pjpeg-too-few-scans")
        }
        return d("WAResultOrError").makeResult(!0)
    }

    function e(a, b) {
        var c = 0;
        if (b === 0) return 0;
        for (var d = 0; d < b; d++) {
            var e = a[d];
            e != null && (c += e)
        }
        return c
    }

    function f(a) {
        a = a.progressiveJpegDetails;
        if (a == null) return d("WAResultOrError").makeResult(null);
        var b = n(a);
        if (b.success === !1) return b;
        return b.value === !0 ? d("WAResultOrError").makeResult({
            scanLengths: a.scanLengths,
            sidecar: a.sidecar
        }) : d("WAResultOrError").makeResult(null)
    }
    g.getExtendedProgressiveJpegDetails = a;
    g.getProgressiveJpegDetails = c;
    g.isValidProgressiveJpegDetails = n;
    g.getTotalByteSizeForScan = e;
    g.maybeGetProgressiveJpegDetailsUsingMediaEntry = f
}), 98);
__d("WADownloadDownloadablePreview", ["WADownloadMedia", "WAGlobals", "WAMediaCrypto", "WAProgressiveJpegGetPJpegDetails", "WAStartMediaDownloadQplFlow", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["finished downloading"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["failed to download media. Reason: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["media: mediaPreview - unsupported preview media type ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["media: mediaPreview - mediaEntryData ", " is incomplete for media preview"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["DownloadableThumbnail exists. Attempting to download."]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Skipping downloadablePreview for progressive jpeg"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No downloadableThumbnail. Skipping..."]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["thumbnail_available: ", ""]);
        o = function() {
            return a
        };
        return a
    }
    var p = d("WADownloadMedia").mediaDownloadLogger.TAGS(["DownloadDownloadablePreview"]);

    function a(a, b, c, d, e, f, g) {
        return q.apply(this, arguments)
    }

    function q() {
        q = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e, f, g, q) {
            var r = g.getMediaPlaintext,
                s = g.handleMediaPreviewBeforeDownload,
                t = g.handleMediaPreviewDownloadFailed;
            g = g.updateMediaEntryForMsg;
            var u = e.downloadableThumbnail,
                v = u == null ? void 0 : u.directPath,
                w = v != null,
                x = d("WAProgressiveJpegGetPJpegDetails").maybeGetProgressiveJpegDetailsUsingMediaEntry(e);
            x = x.success === !0 ? x.value : null;
            p.LOG(o(), w);
            if (u == null || v == null) {
                p.LOG(n());
                return null
            }
            if (x != null && e.serverMediaType === "image" && d("WAGlobals").getConfig().skipDownloadablePreviewForProgressiveJpeg()) {
                p.LOG(m());
                return null
            }
            p.LOG(l());
            w = u.fileEncSha256;
            var y = u.fileSha256,
                z = u.mediaKey;
            u = u.objectId;
            f = d("WAStartMediaDownloadQplFlow").startMediaDownloadQplFlow({
                protocolMsgId: a,
                downloadEntry: f + "-preview",
                msgType: null,
                triggerUIView: q
            });
            f.addAnnotations({
                bool: {
                    duplicateDirectPath: v === e.directPath,
                    isMediaFallbackToAlternativeHmacSaltsEnabled: d("WAGlobals").getConfig().isMediaFallbackToAlternativeHmacSaltsEnabled(),
                    isProgressiveJpeg: x != null
                },
                string: {
                    mediaType: "preview",
                    fullSizeMediaType: e.serverMediaType
                }
            });
            f.addPoint("wa_protocol_media_download_start");
            if (v == null || w == null || y == null || z == null) {
                p.ERROR(k(), e);
                f.endFail("wa_protocol_media_download_fail", {
                    string: {
                        wa_protocol_media_download_fail_reason: "preview-incomplete-media-entry"
                    }
                });
                return
            }
            q = d("WAMediaCrypto").convertServerMediaTypeToPreviewMediaType(c);
            if (q == null) {
                p.ERROR(j(), c);
                f.endFail("wa_protocol_media_download_fail", {
                    string: {
                        wa_protocol_media_download_fail_reason: "preview-unsupported-type"
                    }
                });
                return
            }
            yield s(b);
            x = (yield d("WADownloadMedia").downloadMediaImpl({
                protocolMsgId: a,
                downloadFlow: f,
                mediaTypeDetails: {
                    messageType: q,
                    type: "preview"
                },
                directPath: v,
                fileEncSha256: w,
                fileSha256: y,
                mediaKey: z,
                objectId: u,
                fbid: null,
                mediaEntry: e,
                dbCallbacks: {
                    getMediaPlaintext: r,
                    updateMediaEntryForMsg: g
                }
            }));
            if (x.success === !1) p.WARN(i(), x.error), d("WAGlobals").getConfig().mediaRejectPreviewResolvable() === !0 && void t(b, x.error), f.endFail("wa_protocol_media_download_fail", {
                string: {
                    wa_protocol_media_download_fail_reason: x.error
                }
            });
            else {
                p.LOG(h());
                f.addPoint("wa_protocol_media_download_end");
                f.endSuccess();
                return x.value
            }
        });
        return q.apply(this, arguments)
    }
    g.maybeDownloadDownloadablePreview = a
}), 98);
__d("WAMediaProgressiveJpegTransformStream", ["WABinary"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.scanLengths,
            c = [];
        a = 0;
        for (var e = b, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var h;
            if (f) {
                if (g >= e.length) break;
                h = e[g++]
            } else {
                g = e.next();
                if (g.done) break;
                h = g.value
            }
            h = h;
            a += h;
            c.push(a)
        }
        var i = new(d("WABinary").Binary)(),
            j = 0,
            k = 0;
        h = new TransformStream({
            transform: function(a, d) {
                a = a;
                k += a.byteLength;
                i.writeByteArray(a);
                for (; j < b.length && c[j] < k; j++) {
                    a = i.readByteArray(b[j]);
                    void d.enqueue(a)
                }
            },
            flush: function(a) {
                void a.enqueue(i.readByteArray())
            }
        });
        return h
    }
    g.makeProgressiveJpegHandlerTransformStream = a
}), 98);
__d("WADownloadProgressiveJpegPlaintextStreamerWithoutRetry", ["WACreateMediaDecrypterStream", "WAHttpDownloadMedia", "WAMediaCrypto", "WAMediaProgressiveJpegTransformStream", "WAProgressiveJpegGetPJpegDetails", "WAResultOrError", "WATagsLogger", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Content-Length header is not a number"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Content-Length header is missing"]);
        i = function() {
            return a
        };
        return a
    }
    var j = d("WATagsLogger").TAGS(["WADownloadProgressiveJpegPlaintextStreamer"]);

    function a(a) {
        return k.apply(this, arguments)
    }

    function k() {
        k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = a.serverMediaType,
                c = a.downloadUrl,
                e = a.eventFlow,
                f = a.progressiveJpegDetails;
            a = a.mediaKey;
            c = (yield d("WAHttpDownloadMedia").httpDownloadMedia(c, {
                mediaMetrics: e
            }));
            if (c.success !== !0) return c;
            e = c.value.body;
            if (e == null) return d("WAResultOrError").makeError("body-network-error");
            c = c.value.headers.get("Content-Length");
            if (c == null) {
                j.ERROR(i());
                return d("WAResultOrError").makeError("missing-content-length-header")
            }
            c = Number(c);
            if (Number.isNaN(c)) {
                j.ERROR(h());
                return d("WAResultOrError").makeError("invalid-content-length-header")
            }
            f = d("WAProgressiveJpegGetPJpegDetails").getExtendedProgressiveJpegDetails({
                progressiveJpegDetails: f,
                ciphertextLength: c
            });
            c = (yield d("WAMediaCrypto").computeMediaKeys(a, b));
            a = d("WACreateMediaDecrypterStream").createDefaultDecryptStream(c.cipherKey, c.iv, c.hmacKey, f.sidecar, f.alignedScanLengths);
            if (a.success !== !0) return a;
            b = a.value;
            c = d("WAMediaProgressiveJpegTransformStream").makeProgressiveJpegHandlerTransformStream(f);
            a = e.pipeThrough(b).pipeThrough(c);
            return d("WAResultOrError").makeResult(a)
        });
        return k.apply(this, arguments)
    }
    g.downloadProgressiveJpegPlaintextUsingStreamsWithoutRetry = a
}), 98);
__d("WADownloadProgressiveJpegPlaintextStreamer", ["WAAssertUnreachable", "WACreateMediaDownloadRetrier", "WADownloadProgressiveJpegPlaintextStreamerWithoutRetry", "WAMediaUrl", "WAResultOrError", "WATagsLogger", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Download with stream given up"]);
        h = function() {
            return a
        };
        return a
    }
    var i = d("WATagsLogger").TAGS(["WADownloadProgressiveJpegPlaintextStreamer"]);

    function a(a) {
        return j.apply(this, arguments)
    }

    function j() {
        j = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var e = a.serverMediaType,
                f = a.fileEncSha256,
                g = a.directPath,
                j = a.eventFlow,
                k = a.progressiveJpegDetails,
                l = a.mediaKey;
            a = (yield d("WACreateMediaDownloadRetrier").createMediaDownloadRetrier({
                directPath: g,
                eventFlow: j,
                fileEncSha256: f,
                mediaTypeDetails: {
                    type: "regular",
                    mediaType: e
                }
            }));
            if (!a.success) return a;
            a = a.value;
            var m = a.retrier;
            a = a.mediaRouteDetails;
            var n = a.bucket;
            a = (yield m.run(function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    a = a.domain;
                    a = d("WAMediaUrl").buildDownloadUrl(g, f, a, "manual", n);
                    a = (yield d("WADownloadProgressiveJpegPlaintextStreamerWithoutRetry").downloadProgressiveJpegPlaintextUsingStreamsWithoutRetry({
                        downloadUrl: a,
                        eventFlow: j,
                        mediaKey: l,
                        progressiveJpegDetails: k,
                        serverMediaType: e
                    }));
                    if (a.success === !0) return d("WAResultOrError").makeResult(a);
                    a = a.error;
                    switch (a) {
                        case "http-fetch-exception":
                        case "server-timeout":
                        case "unspecified-http-error":
                        case "invalid-content-length-header":
                        case "missing-content-length-header":
                            return d("WAResultOrError").makeError({
                                progressMade: !0
                            });
                        case "access-expired":
                            return d("WAResultOrError").makeResult(d("WAResultOrError").makeError("disconnected"));
                        case "body-network-error":
                            return d("WAResultOrError").makeResult(d("WAResultOrError").makeError("request-error"));
                        case "media-not-found":
                        case "request-error":
                        case "download-throttled":
                        case "signature-expired":
                            return d("WAResultOrError").makeResult(d("WAResultOrError").makeError(a));
                        case "missing-expected-hmacs":
                        case "hmac-chiphertext-array-mismatch":
                            return d("WAResultOrError").makeResult(d("WAResultOrError").makeError(a));
                        default:
                            a;
                            throw c("WAAssertUnreachable")(a)
                    }
                });
                return function(b) {
                    return a.apply(this, arguments)
                }
            }()));
            if (a == null) {
                i.WARN(h());
                return d("WAResultOrError").makeError("max-attempts-exceeded")
            }
            return a
        });
        return j.apply(this, arguments)
    }
    g.downloadProgressiveJpegPlaintextUsingStreams = a
}), 98);
__d("WAProgressiveJpegAddJPEGTrailingTag", ["WATypedArraysConcat"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Uint8Array([255, 217]);

    function a(a) {
        return d("WATypedArraysConcat").concatTypedArrays(Uint8Array, [new Uint8Array(a), h]).buffer
    }
    g.JPEG_TRAILING_TAG = h;
    g.addJPEGTrailingTag = a
}), 98);
__d("WAStreamAsyncIterator", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return g.apply(this, arguments)
    }

    function g() {
        g = babelHelpers.wrapAsyncGenerator(function*(a) {
            a = a.getReader();
            try {
                while (!0) {
                    var b = (yield babelHelpers.awaitAsyncGenerator(a.read())),
                        c = b.done;
                    b = b.value;
                    if (c) return;
                    yield b
                }
            } finally {
                a.releaseLock()
            }
        });
        return g.apply(this, arguments)
    }
    f.streamAsyncIterator = a
}), 66);
__d("WADownloadMedia", ["Promise", "WAByteArray", "WACryptoSha256", "WACryptoUtils", "WADownloadAndDecryptMedia", "WADownloadDownloadablePreview", "WADownloadProgressiveJpegPlaintextStreamer", "WADownloadProgressiveJpegPreview", "WAErrorMessage", "WAGetAgeBucketForMediaKeyTimestamp", "WAGlobals", "WAHashUtils", "WAMediaCrypto", "WAMediaQplHelper", "WAMediaUtils", "WAProgressiveJpegAddJPEGTrailingTag", "WAProgressiveJpegGetPJpegDetails", "WAPromiseManagement", "WAResultOrError", "WAStreamAsyncIterator", "WATagsLogger", "WATypedArraysConcat", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Exception occurred during Media Streaming: Reason: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media streaming for ProgressiveJpeg download successful. PlaintextHash: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media streaming for ProgressiveJpeg download failed due to plaintext hash mismatch. PlaintextHash: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Handling preview from scan ", " for plaintextHash ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Processing scan ", " for plaintextHash ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Targeting scanIndex ", " for preview. PlaintextHash: ", ""]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Using Media Streaming to download ProgressiveJpeg. PlaintextHash: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["downloadMedia: enc-hash-mismatch"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["media already exists in db, skipping download"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to download media due to runtime-error: ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media Entry size ", " does not match decrypted plaintext size ", ""]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["start download ", ". mediaKeyTimestampAgeBucket: ", ", size: ", ", serverMediaType: ", ""]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["mediaEntry is incomplete."]);
        u = function() {
            return a
        };
        return a
    }

    function v() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Skipping fallback for ", ". PlaintextHash: ", ""]);
        v = function() {
            return a
        };
        return a
    }

    function w() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Media Streaming failed to download progressive jpeg. Reason: ", ". PlaintextHash: ", ""]);
        w = function() {
            return a
        };
        return a
    }

    function x() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["media: mediaPreview - unsupported preview media type ", ""]);
        x = function() {
            return a
        };
        return a
    }

    function y() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to get ProgressiveJpeg details: ", ""]);
        y = function() {
            return a
        };
        return a
    }

    function z() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["mediaEntry is incomplete"]);
        z = function() {
            return a
        };
        return a
    }
    var A = d("WATagsLogger").TAGS(["MediaDownload"]);

    function a(a) {
        var b = a.downloadMediaMetric,
            c = a.hash,
            e = a.mediaEntry,
            f = a.protocolMsgId,
            g = a.getMediaPlaintext,
            h = a.handleMediaPreviewDownload,
            i = a.handleMediaPreviewBeforeDownload,
            j = a.handleMediaPreviewDownloadFailed;
        a = a.updateMediaEntryForMsg;
        var k = d("WAGlobals").getConfig().uiLayoutTriggeredMediaDownload() ? C : B,
            l = M({
                downloadMediaMetric: b,
                mediaEntry: e,
                hash: c
            });
        l = l.logDownloadResult;
        return l(k({
            downloadMediaMetric: b,
            hash: c,
            mediaEntry: e,
            protocolMsgId: f,
            getMediaPlaintext: g,
            handleMediaPreviewDownload: h,
            handleMediaPreviewBeforeDownload: i,
            handleMediaPreviewDownloadFailed: j,
            updateMediaEntryForMsg: a
        }))
    }
    var B = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                var c, e = a.downloadMediaMetric,
                    f = a.hash,
                    g = a.mediaEntry,
                    i = a.protocolMsgId,
                    j = a.getMediaPlaintext,
                    k = a.handleMediaPreviewDownload,
                    l = a.handleMediaPreviewBeforeDownload,
                    m = a.handleMediaPreviewDownloadFailed;
                a = a.updateMediaEntryForMsg;
                var n = g.directPath,
                    o = g.fileEncSha256,
                    p = g.fileSha256,
                    q = g.mediaKey,
                    r = g.serverMediaType;
                if (n == null || o == null || p == null || q == null || r == null) {
                    A.ERROR(z());
                    return d("WAResultOrError").makeError("media-entry-invalid")
                }(g == null ? void 0 : (c = g.downloadableThumbnail) == null ? void 0 : c.directPath) != null && e.addAnnotations({
                    bool: {
                        duplicateDirectPath: g.downloadableThumbnail.directPath === n,
                        hasDownloadableThumbnail: !0
                    }
                });
                c = d("WAProgressiveJpegGetPJpegDetails").maybeGetProgressiveJpegDetailsUsingMediaEntry(g);
                c.success === !1 && (A.ERROR(y(), c.error), e.addPoint(c.error));
                c = c.success === !0 ? c.value : null;
                e.addAnnotations({
                    bool: {
                        isProgressiveJpeg: c != null
                    }
                });
                var s = function(a) {
                    if (a == null) return (h || (h = b("Promise"))).resolve();
                    var c = d("WAMediaCrypto").convertServerMediaTypeToPreviewMediaType(r);
                    if (c == null) {
                        A.ERROR(x(), r);
                        return (h || (h = b("Promise"))).resolve()
                    }
                    return k(f, a, c, i).then(function() {})
                };
                if (c != null && d("WAMediaUtils").isTransformStreamSupported() && r === "image" && d("WAGlobals").getConfig().isMediaStreamingForProgressiveJpegEnabled()) {
                    n = (yield H({
                        directPath: n,
                        downloadFlow: e,
                        fileEncSha256: o,
                        handleMediaPreviewBlob: s,
                        hash: f,
                        mediaKey: q,
                        progressiveJpegDetails: c,
                        serverMediaType: r,
                        fileSha256: p,
                        handleMediaPreviewBeforeDownload: l,
                        handleMediaPreviewDownloadFailed: m
                    }));
                    if (n.success) return d("WAResultOrError").makeResult({
                        mimeType: d("WAMediaUtils").getMimeTypeFromServerMediaType(r),
                        plaintext: n.value
                    });
                    else {
                        o = n.error;
                        A.ERROR(w(), o, d("WAHashUtils").sanitisePlaintextHash(f));
                        switch (o) {
                            case "signature-expired":
                            case "request-error":
                                A.LOG(v(), o, d("WAHashUtils").sanitisePlaintextHash(f));
                                return d("WAResultOrError").makeError(o)
                        }
                        e == null ? void 0 : e.addPoint("fallback_to_full_download")
                    }
                }
                q = G({
                    hash: f,
                    mediaEntry: g,
                    progressiveJpegDetails: c,
                    protocolMsgId: i,
                    serverMediaType: r,
                    getMediaPlaintext: j,
                    handleMediaPreviewBeforeDownload: l,
                    handleMediaPreviewDownloadFailed: m,
                    updateMediaEntryForMsg: a,
                    downloadEntry: e.downloadEntry,
                    triggerUIView: e.triggerUIView
                });
                void q.then(s);
                return D({
                    downloadMediaMetric: e,
                    mediaEntry: g,
                    protocolMsgId: i,
                    getMediaPlaintext: j,
                    updateMediaEntryForMsg: a
                })
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }(),
        C = d("WAPromiseManagement").cacheWhilePending(function(a) {
            a = a.hash;
            return a
        }, B),
        D = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                var b = a.downloadMediaMetric,
                    c = a.mediaEntry,
                    e = a.protocolMsgId,
                    f = a.getMediaPlaintext;
                a = a.updateMediaEntryForMsg;
                var g = c.directPath,
                    h = c.fbid,
                    i = c.fileEncSha256,
                    j = c.fileSha256,
                    k = c.mediaKey,
                    l = c.objectId,
                    m = c.serverMediaType;
                if (g == null || i == null || j == null || k == null || m == null) {
                    A.ERROR(u());
                    return d("WAResultOrError").makeError("media-entry-invalid")
                }
                e = (yield E({
                    protocolMsgId: e,
                    downloadFlow: b,
                    mediaTypeDetails: {
                        mediaType: m,
                        type: "regular"
                    },
                    directPath: g,
                    fileEncSha256: i,
                    fileSha256: j,
                    mediaKey: k,
                    objectId: l,
                    fbid: h,
                    mediaEntry: c,
                    dbCallbacks: {
                        getMediaPlaintext: f,
                        updateMediaEntryForMsg: a
                    }
                }));
                return e.success ? d("WAResultOrError").makeResult({
                    mimeType: d("WAMediaUtils").getMimeTypeFromServerMediaType(m),
                    plaintext: e.value
                }) : e
            });
            return function(b) {
                return a.apply(this, arguments)
            }
        }();
    c = d("WAPromiseManagement").cacheWhilePending(function(a) {
        a = a.hash;
        return a
    }, function(a) {
        var b = a.hash;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["hash"]);
        b = M({
            hash: b,
            downloadMediaMetric: a.downloadMediaMetric,
            mediaEntry: a.mediaEntry
        });
        b = b.logDownloadResult;
        return b(D(a))
    });

    function E(a) {
        return F.apply(this, arguments)
    }

    function F() {
        F = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var c = a.protocolMsgId,
                e = a.downloadFlow,
                f = a.mediaTypeDetails,
                g = a.directPath,
                h = a.fileEncSha256,
                i = a.fileSha256,
                j = a.mediaKey,
                k = a.objectId,
                l = a.fbid,
                m = a.mediaEntry;
            a = a.dbCallbacks;
            var n = a.getMediaPlaintext,
                o = a.updateMediaEntryForMsg,
                r = d("WAHashUtils").toPlaintextHash(i);
            if (d("WAGlobals").getConfig().mediaDownloadDeduplication() && (f.mediaType === "gif" || f.mediaType === "sticker")) {
                a = (yield n(r));
                if (a != null) {
                    A.LOG(q());
                    e.addPoint("media_download_skipped");
                    i = (yield d("WAMediaUtils").blobToArrayBuffer(a));
                    return d("WAResultOrError").makeResult(i)
                }
            }
            n = (yield d("WADownloadAndDecryptMedia").downloadAndDecryptMedia({
                directPath: g,
                eventFlow: e,
                fbid: l,
                fileEncSha256: h,
                mediaKey: j,
                mediaTypeDetails: f,
                objectId: k,
                pathRedirected: function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                        var b = function() {
                            return d("WAMediaUtils").encodeMediaEntryWithUpdatedPath(m, a)
                        };
                        yield o(r, c, b, k, m.serverMediaType)
                    });

                    function e(b) {
                        return a.apply(this, arguments)
                    }
                    return e
                }(),
                plaintextHash: r
            }));
            if (n.success === !1) {
                a = n.error;
                switch (a) {
                    case "signature-expired":
                    case "media-not-found":
                        return d("WAResultOrError").makeError(a);
                    case "enc-hash-mismatch":
                        A.ERROR(p());
                        return d("WAResultOrError").makeError(a);
                    default:
                        a;
                        return d("WAResultOrError").makeError(a)
                }
            } else {
                i = n.value;
                return d("WAResultOrError").makeResult(i)
            }
        });
        return F.apply(this, arguments)
    }

    function G(a) {
        var b = a.hash,
            c = a.mediaEntry,
            e = a.progressiveJpegDetails,
            f = a.protocolMsgId,
            g = a.serverMediaType,
            h = a.getMediaPlaintext,
            i = a.handleMediaPreviewBeforeDownload,
            j = a.handleMediaPreviewDownloadFailed,
            k = a.updateMediaEntryForMsg,
            l = a.downloadEntry,
            m = a.triggerUIView;
        return e == null ? d("WADownloadDownloadablePreview").maybeDownloadDownloadablePreview(f, b, g, c, l, {
            getMediaPlaintext: h,
            handleMediaPreviewBeforeDownload: i,
            handleMediaPreviewDownloadFailed: j,
            updateMediaEntryForMsg: k
        }, m) : d("WADownloadProgressiveJpegPreview").maybeDownloadProgressiveJpegPreview({
            protocolMsgId: f,
            hash: b,
            serverMediaType: g,
            mediaEntry: c,
            progressiveJpegDetails: e,
            getMediaPlaintext: h,
            handleMediaPreviewBeforeDownload: i,
            handleMediaPreviewDownloadFailed: j,
            downloadEntry: l,
            triggerUIView: m
        }).then(function(a) {
            return a.success !== !0 ? d("WADownloadDownloadablePreview").maybeDownloadDownloadablePreview(f, b, g, c, l, {
                getMediaPlaintext: h,
                handleMediaPreviewBeforeDownload: i,
                handleMediaPreviewDownloadFailed: j,
                updateMediaEntryForMsg: k
            }, m) : a.value
        })
    }

    function H(a) {
        return I.apply(this, arguments)
    }

    function I() {
        I = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = a.directPath,
                c = a.downloadFlow,
                e = a.fileEncSha256,
                f = a.fileSha256,
                g = a.handleMediaPreviewBlob,
                h = a.hash,
                p = a.mediaKey,
                q = a.progressiveJpegDetails,
                r = a.serverMediaType,
                s = a.handleMediaPreviewBeforeDownload;
            a = a.handleMediaPreviewDownloadFailed;
            var t = A.TAGS(["MediaStreaming"]);
            t.LOG(o(), d("WAHashUtils").sanitisePlaintextHash(h));
            c.addPoint("media_streaming_start");
            c.addPoint("download_pjpeg_preview_start");
            var u = d("WADownloadProgressiveJpegPreview").getPreviewTargetScan(q.scanLengths) - 1;
            t.LOG(n(), u, d("WAHashUtils").sanitisePlaintextHash(h));
            c.addAnnotations({
                "int": {
                    scans: q.scanLengths.length
                }
            });
            b = (yield d("WADownloadProgressiveJpegPlaintextStreamer").downloadProgressiveJpegPlaintextUsingStreams({
                directPath: b,
                eventFlow: c,
                fileEncSha256: e,
                mediaKey: p,
                progressiveJpegDetails: q,
                serverMediaType: r
            }));
            if (b.success === !1) {
                c.addPoint("media_streaming_fail", {
                    string: {
                        wa_media_download_streaming_fail_reason: b.error
                    }
                });
                return b
            }
            void s(h);
            e = [];
            p = 0;
            try {
                q = !0;
                r = !1;
                var v;
                try {
                    for (var w = babelHelpers.asyncIterator(d("WAStreamAsyncIterator").streamAsyncIterator(b.value)), s, b; s = (yield w.next()), q = s.done, b = (yield s.value), !q; q = !0) {
                        s = b;
                        if (s == null) continue;
                        t.LOG(m(), p, d("WAHashUtils").sanitisePlaintextHash(h));
                        e.push(s);
                        if (p === u) {
                            c.addPoint("media_streaming_preview_processed");
                            t.LOG(l(), p, d("WAHashUtils").sanitisePlaintextHash(h));
                            b = d("WAByteArray").uint8ArrayToBuffer(d("WATypedArraysConcat").concatTypedArrays(Uint8Array, [].concat(e, [d("WAProgressiveJpegAddJPEGTrailingTag").JPEG_TRAILING_TAG])));
                            void g(b);
                            c.addPoint("download_pjpeg_preview_end")
                        }
                        p++
                    }
                } catch (a) {
                    r = !0, v = a
                } finally {
                    try {
                        !q && w["return"] != null && (yield w["return"]())
                    } finally {
                        if (r) throw v
                    }
                }
                p < u && c.addPoint("download_pjpeg_preview_fail");
                s = d("WAByteArray").uint8ArrayToBuffer(d("WATypedArraysConcat").concatTypedArrays(Uint8Array, [].concat(e)));
                b = (yield d("WACryptoSha256").sha256(s));
                if (!d("WACryptoUtils").arrayBuffersEqual(f, b)) {
                    t.WARN(k(), d("WAHashUtils").sanitisePlaintextHash(h));
                    c.addPoint("media_streaming_fail", {
                        string: {
                            wa_media_download_streaming_fail_reason: "hash-mismatch"
                        }
                    });
                    return d("WAResultOrError").makeError("hash-mismatch")
                }
                t.LOG(j(), d("WAHashUtils").sanitisePlaintextHash(h));
                c.addPoint("media_streaming_end");
                return d("WAResultOrError").makeResult(s)
            } catch (b) {
                t.ERROR(i(), b);
                d("WAGlobals").getConfig().mediaRejectPreviewResolvable() === !0 && void a(h, d("WAErrorMessage").maybeGetMessageFromError(b));
                c == null ? void 0 : c.addPoint("media_streaming_fail", {
                    string: {
                        wa_media_download_streaming_fail_reason: d("WAErrorMessage").maybeGetMessageFromError(b)
                    }
                });
                return d("WAResultOrError").makeError("stream-error")
            }
        });
        return I.apply(this, arguments)
    }
    var J = typeof((e = navigator.storage) == null ? void 0 : e.getDirectory) === "function",
        K = typeof self.caches === "object",
        L = 0;

    function M(a) {
        var c = a.downloadMediaMetric,
            e = a.mediaEntry;
        a = a.hash;
        var f = e.mediaKeyTimestamp,
            g = e.size;
        e = e.serverMediaType;
        f = d("WAGetAgeBucketForMediaKeyTimestamp").getAgeBucketForMediaKeyTimestamp(f);
        A.LOG(t(), d("WAHashUtils").sanitisePlaintextHash(a), f, g, e);
        c.addPoint("wa_protocol_media_download_start", {
            string: {
                mediaType: e,
                mediaKeyTimestampAgeBucket: f,
                sanitised_media_hash: d("WAHashUtils").sanitisePlaintextHash(a)
            },
            bool: {
                isOPFSSupported: J,
                isWebCacheSupported: K,
                isMediaStreamingForProgressiveJpegEnabled: d("WAGlobals").getConfig().isMediaStreamingForProgressiveJpegEnabled()
            }
        });
        return {
            logDownloadResult: function(a) {
                L++;
                c.addAnnotations({
                    "int": {
                        concurrentDownloadCount: L
                    }
                });
                return a.then(function(a) {
                    if (a.success) {
                        var b = a.value.plaintext.byteLength;
                        g !== b && (A.WARN(s(), g, b), c.addPoint("legacy_plaintext_size_mismatch"));
                        c.addPoint("wa_protocol_media_download_end", {
                            string: {
                                media_size: d("WAMediaQplHelper").convertIntegerSizeToStringBucket(b)
                            }
                        })
                    } else c.addPoint("wa_protocol_media_download_fail", {
                        string: {
                            wa_protocol_media_download_fail_reason: a.error
                        }
                    });
                    return a
                })["catch"](function(a) {
                    c.addPoint("wa_protocol_media_download_fail", {
                        string: {
                            wa_protocol_media_download_fail_reason: "runtime-error"
                        }
                    });
                    a = d("WAErrorMessage").maybeGetMessageFromError(a);
                    A.ERROR(r(), a);
                    return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeError("runtime-error"))
                })["finally"](function() {
                    L--
                })
            }
        }
    }
    g.mediaDownloadLogger = A;
    g.downloadMedia = a;
    g.downloadFullMediaOnly = D;
    g.cachedDownloadFullMediaOnly = c;
    g.downloadMediaImpl = E
}), 98);
__d("WADownloadProgressiveJpegPlaintext", ["WADownloadCiphertext", "WAMediaCrypto", "WAProgressiveJpegAddJPEGTrailingTag", "WAProgressiveJpegGetPJpegDetails", "WAResultOrError", "WATagsLogger", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["ProgressiveJpeg download and decrypt successful. Partial: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Download Plaintext Error ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Using progressiveJpeg decryptAndVerify"]);
        j = function() {
            return a
        };
        return a
    }
    var k = d("WATagsLogger").TAGS(["DownloadProgressiveJpeg"]);

    function a(a) {
        var c, e, f, g, h, i, j, k, n, o, p, q, r;
        return b("regeneratorRuntime").async(function(s) {
            while (1) switch (s.prev = s.next) {
                case 0:
                    c = a.mediaTypeDetails, e = a.fileEncSha256, f = a.directPath, g = a.mediaKey, h = a.eventFlow, i = a.pathRedirected, j = a.progressiveJpegDetails, k = a.targetScan, n = a.plaintextHash, o = a.size;
                    p = d("WAProgressiveJpegGetPJpegDetails").getExtendedProgressiveJpegDetails({
                        progressiveJpegDetails: j,
                        ciphertextLength: m(o)
                    });
                    q = d("WAProgressiveJpegGetPJpegDetails").getTotalByteSizeForScan(p.alignedScanLengths, k);
                    s.next = 5;
                    return b("regeneratorRuntime").awrap(d("WADownloadCiphertext").cachedDownloadCiphertext({
                        mediaTypeDetails: c,
                        fileEncSha256: e,
                        directPath: f,
                        pathRedirected: i,
                        fromBytes: 0,
                        toBytes: q - 1,
                        eventFlow: h,
                        plaintextHash: n
                    }));
                case 5:
                    r = s.sent;
                    if (!(r.success !== !0)) {
                        s.next = 8;
                        break
                    }
                    return s.abrupt("return", r);
                case 8:
                    return s.abrupt("return", l(g, c, k, p, r.value));
                case 9:
                case "end":
                    return s.stop()
            }
        }, null, this)
    }

    function l(a, c, e, f, g) {
        var l, m, n, o;
        return b("regeneratorRuntime").async(function(p) {
            while (1) switch (p.prev = p.next) {
                case 0:
                    k.LOG(j());
                    l = new Uint8Array(g);
                    c.type === "preview" ? m = d("WAMediaCrypto").computeMediaKeysForPreview(a) : m = d("WAMediaCrypto").computeMediaKeys(a, c.mediaType);
                    p.next = 5;
                    return b("regeneratorRuntime").awrap(m.then(function(a) {
                        var b = a.iv,
                            c = a.cipherKey;
                        a = a.hmacKey;
                        return d("WAMediaCrypto").decryptPartialChunks(c, b, l, a, e, f)
                    }).then(d("WAResultOrError").makeResult)["catch"](function(a) {
                        k.ERROR(i(), a);
                        if (a instanceof d("WAMediaCrypto").HmacValidationError) return d("WAResultOrError").makeError("enc-hash-mismatch");
                        else return d("WAResultOrError").makeError("decryption-error")
                    }));
                case 5:
                    n = p.sent;
                    if (n.success) {
                        p.next = 8;
                        break
                    }
                    return p.abrupt("return", n);
                case 8:
                    k.LOG(h(), e < f.scanLengths.length);
                    o = d("WAProgressiveJpegAddJPEGTrailingTag").addJPEGTrailingTag(n.value.plaintext);
                    return p.abrupt("return", d("WAResultOrError").makeResult(o));
                case 11:
                case "end":
                    return p.stop()
            }
        }, null, this)
    }

    function m(a) {
        if (a == null) return null;
        var b = d("WAMediaCrypto").CBC_BLOCK_SIZE - a % d("WAMediaCrypto").CBC_BLOCK_SIZE;
        return a + b + d("WAMediaCrypto").HMAC_LENGTH
    }
    g.downloadProgressiveJpegPlaintext = a
}), 98);
__d("WAProgressiveJpegGetTargetScanLengthForBytes", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        var c = 0,
            d = 0;
        for (var e = 0; e < a.length; e++) {
            d = e + 1;
            c += a[e];
            if (c >= b) break
        }
        return d
    }
    f.getTargetScanBasedOnByteSize = a
}), 66);
__d("WADownloadProgressiveJpegPreview", ["Promise", "WADownloadMedia", "WADownloadProgressiveJpegPlaintext", "WAGlobals", "WALoggerTag", "WAProgressiveJpegGetTargetScanLengthForBytes", "WAResultOrError", "WAStartMediaDownloadQplFlow", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Finished progressiveJpeg preview download"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Starting progressiveJpeg preview download"]);
        j = function() {
            return a
        };
        return a
    }
    var k = d("WADownloadMedia").mediaDownloadLogger.TAGS([c("WALoggerTag").MediaPreview]),
        l = d("WAGlobals").getConfig().jpegThumbnailTargetByteSizeKB() * 1024,
        m = 3;

    function a(a) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var b = a.protocolMsgId,
                c = a.hash,
                e = a.serverMediaType,
                f = a.mediaEntry,
                g = a.progressiveJpegDetails,
                h = a.handleMediaPreviewBeforeDownload,
                l = a.handleMediaPreviewDownloadFailed,
                m = a.downloadEntry;
            a = a.triggerUIView;
            var n = f.directPath,
                p = f.fileEncSha256,
                q = f.mediaKey,
                r = f.size;
            if (n == null || p == null || q == null) return d("WAResultOrError").makeError("pjpeg-failed");
            b = d("WAStartMediaDownloadQplFlow").startMediaDownloadQplFlow({
                protocolMsgId: b,
                downloadEntry: m + "-preview",
                msgType: null,
                triggerUIView: a
            });
            b.addAnnotations({
                bool: {
                    isMediaFallbackToAlternativeHmacSaltsEnabled: d("WAGlobals").getConfig().isMediaFallbackToAlternativeHmacSaltsEnabled(),
                    isProgressiveJpeg: !0
                },
                string: {
                    mediaType: "preview",
                    fullSizeMediaType: f.serverMediaType
                },
                "int": {
                    mediaEntrySize: f.size
                }
            });
            k.LOG(j());
            b.addPoint("wa_protocol_media_download_start");
            m = d("WAGlobals").getConfig().pjpegPreviewAvoidLastScan() === !0 ? g.scanLengths.length - 1 : g.scanLengths.length;
            a = Math.min(o(g.scanLengths, r), m);
            yield h(c);
            f = (yield d("WADownloadProgressiveJpegPlaintext").downloadProgressiveJpegPlaintext({
                directPath: n,
                eventFlow: b,
                fileEncSha256: p,
                mediaKey: q,
                mediaTypeDetails: {
                    mediaType: e,
                    type: "regular"
                },
                progressiveJpegDetails: g,
                plaintextHash: c,
                targetScan: a,
                size: r
            }));
            if (!f.success) {
                d("WAGlobals").getConfig().mediaRejectPreviewResolvable() === !0 && void l(c, f.error);
                b.endFail("wa_protocol_media_download_fail", {
                    string: {
                        wa_protocol_media_download_fail_reason: f.error
                    }
                });
                return d("WAResultOrError").makeError("pjpeg-failed")
            }
            m = f.value;
            k.LOG(i());
            b.addPoint("wa_protocol_media_download_end");
            b.endSuccess();
            return d("WAResultOrError").makeResult(m)
        });
        return n.apply(this, arguments)
    }

    function o(a, b) {
        var c = d("WAProgressiveJpegGetTargetScanLengthForBytes").getTargetScanBasedOnByteSize(a, l);
        (b == null || b === 0) && (c = Math.min(c, a.length - 1));
        c = Math.max(c, m);
        return c
    }

    function e(a) {
        var c = a.hash,
            e = a.serverMediaType,
            f = a.mediaEntry;
        a = a.progressiveJpegDetails;
        var g = f.directPath,
            i = f.fileEncSha256,
            j = f.mediaKey;
        f = f.size;
        if (g == null || i == null || j == null) return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeError("media-entry-invalid"));
        var k = d("WAGlobals").getConfig().pjpegPreviewAvoidLastScan() === !0 ? a.scanLengths.length - 1 : a.scanLengths.length;
        k = Math.min(o(a.scanLengths, f), k);
        return d("WADownloadProgressiveJpegPlaintext").downloadProgressiveJpegPlaintext({
            directPath: g,
            fileEncSha256: i,
            mediaKey: j,
            mediaTypeDetails: {
                mediaType: e,
                type: "regular"
            },
            progressiveJpegDetails: a,
            plaintextHash: c,
            targetScan: k,
            size: f
        })
    }
    g.maybeDownloadProgressiveJpegPreview = a;
    g.getPreviewTargetScan = o;
    g.maybeDownloadProgressiveJpegPreviewV2 = e
}), 98);
__d("WAMapUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return new Map(Array.from(a.entries()).map(function(a) {
            return [a[0], b(a[1], a[0])]
        }))
    }
    f.mapValues = a
}), 66);
__d("WAMsgTransport.pb", ["WACommon.pb", "WAProtoConst"], (function(a, b, c, d, e, f, g) {
    var h;
    a = {
        NOOP: 0,
        UPSERT: 1,
        DELETE: 2,
        UPSERT_AND_DELETE: 3
    };
    b = {};
    c = {};
    e = {};
    f = {};
    var i = {},
        j = {},
        k = {},
        l = {},
        m = {},
        n = {},
        o = {};
    b.internalSpec = {
        payload: [1, (h = d("WAProtoConst")).TYPES.MESSAGE, c],
        protocol: [2, h.TYPES.MESSAGE, e]
    };
    c.internalSpec = {
        applicationPayload: [1, h.TYPES.MESSAGE, d("WACommon.pb").SubProtocolSpec],
        futureProof: [3, h.TYPES.ENUM, d("WACommon.pb").FUTURE_PROOF_BEHAVIOR]
    };
    e.internalSpec = {
        integral: [1, h.TYPES.MESSAGE, m],
        ancillary: [2, h.TYPES.MESSAGE, f]
    };
    f.internalSpec = {
        skdm: [2, h.TYPES.MESSAGE, l],
        deviceListMetadata: [3, h.TYPES.MESSAGE, o],
        icdc: [4, h.TYPES.MESSAGE, j],
        backupDirective: [5, h.TYPES.MESSAGE, i]
    };
    i.internalSpec = {
        messageId: [1, h.TYPES.STRING],
        actionType: [2, h.TYPES.ENUM, a],
        supplementalKey: [3, h.TYPES.STRING]
    };
    j.internalSpec = {
        senderIdentity: [1, h.TYPES.MESSAGE, k],
        recipientIdentities: [2, h.FLAGS.REPEATED | h.TYPES.MESSAGE, k],
        recipientUserJids: [3, h.FLAGS.REPEATED | h.TYPES.STRING]
    };
    k.internalSpec = {
        seq: [1, h.TYPES.INT32],
        signingDevice: [2, h.TYPES.BYTES],
        unknownDevices: [3, h.FLAGS.REPEATED | h.TYPES.BYTES],
        unknownDeviceIds: [4, h.FLAGS.REPEATED | h.TYPES.INT32]
    };
    l.internalSpec = {
        groupId: [1, h.TYPES.STRING],
        axolotlSenderKeyDistributionMessage: [2, h.TYPES.BYTES]
    };
    m.internalSpec = {
        padding: [1, h.TYPES.BYTES],
        dsm: [2, h.TYPES.MESSAGE, n]
    };
    n.internalSpec = {
        destinationJid: [1, h.TYPES.STRING],
        phash: [2, h.TYPES.STRING]
    };
    o.internalSpec = {
        senderKeyHash: [1, h.TYPES.BYTES],
        senderTimestamp: [2, h.TYPES.UINT64],
        recipientKeyHash: [8, h.TYPES.BYTES],
        recipientTimestamp: [9, h.TYPES.UINT64]
    };
    g.MESSAGE_TRANSPORT_PROTOCOL_ANCILLARY_BACKUP_DIRECTIVE_ACTION_TYPE = a;
    g.MessageTransportSpec = b;
    g.MessageTransport$PayloadSpec = c;
    g.MessageTransport$ProtocolSpec = e;
    g.MessageTransport$Protocol$AncillarySpec = f;
    g.MessageTransport$Protocol$Ancillary$BackupDirectiveSpec = i;
    g.MessageTransport$Protocol$Ancillary$ICDCParticipantDevicesSpec = j;
    g.MessageTransport$Protocol$Ancillary$ICDCParticipantDevices$ICDCIdentityListDescriptionSpec = k;
    g.MessageTransport$Protocol$Ancillary$SenderKeyDistributionMessageSpec = l;
    g.MessageTransport$Protocol$IntegralSpec = m;
    g.MessageTransport$Protocol$Integral$DeviceSentMessageSpec = n;
    g.DeviceListMetadataSpec = o
}), 98);
__d("WAProtocolMediaType", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case "image":
            case "sticker":
            case "gif":
            case "video":
            case "ptt":
            case "audio":
            case "document":
            case "product":
                return a;
            case "xma-image":
                return "document";
            default:
                return null
        }
    }
    f.castToProtocolMediaType = a
}), 66);
__d("WAEncNode", ["WAAsMessageTransport", "WACryptoManagerUtils", "WAGlobals", "WALogger", "WAMapUtils", "WAMsgTransport.pb", "WANullthrows", "WAProtocolMediaType", "encodeProtobuf", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg failed to encrypt message: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg failed to encrypt message: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function a(a, b, e, f) {
        var g = new Set(),
            h = new Set(),
            m = new Set(),
            n = d("WAMapUtils").mapValues(a, function(a, b) {
                var c = a.params;
                a = a.icdc;
                var d;
                g.add(c.type);
                switch (c.type) {
                    case "message":
                        d = j({
                            messageBytes: c.messageBytes,
                            to: b,
                            icdc: a,
                            chat: c.chat,
                            applicationPayloadVersion: c.applicationPayloadVersion
                        });
                        h.add(c.messageType.type);
                        c.messageType.mediaType != null && m.add(c.messageType.mediaType);
                        break;
                    case "appdata":
                        d = k({
                            messageBytes: c.messageBytes
                        });
                        break;
                    default:
                        c.type, d = l({
                            skdm: c.skdm,
                            icdc: a
                        })
                }
                return {
                    plaintext: d
                }
            });
        return d("WACryptoManagerUtils").bulkEncryptMsgWithMetrics(n, b, e, Array.from(g), Array.from(h), Array.from(m)).then(function(b) {
            if (!b.success) {
                d("WALogger").ERROR(i(), b.error);
                return null
            }
            return d("WAMapUtils").mapValues(b.value, function(b, e) {
                var g, h = b.type,
                    i = b.ciphertext;
                b = b.baseKey;
                g = c("WANullthrows")((g = a.get(e)) == null ? void 0 : g.params);
                var j = g.type === "message" && g.messageType.type === "media" ? d("WAProtocolMediaType").castToProtocolMediaType(g.messageType.mediaType) : null;
                return {
                    encType: "device",
                    to: e,
                    v: ((e = g.messageBytes) == null ? void 0 : e.version) === "v2" ? "2" : "3",
                    type: h,
                    mediaType: j,
                    count: f,
                    ciphertext: i,
                    baseKey: b
                }
            })
        })
    }

    function b(a, b, c, e, f, g, i) {
        var m;
        switch (b.type) {
            case "message":
                m = j({
                    messageBytes: b.messageBytes,
                    to: a,
                    icdc: i,
                    chat: b.chat,
                    applicationPayloadVersion: b.applicationPayloadVersion
                });
                break;
            case "appdata":
                m = k({
                    messageBytes: b.messageBytes
                });
                break;
            default:
                b.type, m = l({
                    skdm: b.skdm,
                    icdc: i
                })
        }
        i = d("WACryptoManagerUtils").encryptMsgWithMetrics(a, m, c, f, g, b == null ? void 0 : b.chat);
        return i.then(function(c) {
            var f;
            if (!c.success) {
                d("WALogger").ERROR(h(), c.error);
                return null
            }
            var g = b.type === "message" && b.messageType.type === "media" ? d("WAProtocolMediaType").castToProtocolMediaType(b.messageType.mediaType) : null,
                i = c.value,
                j = i.type;
            i = i.ciphertext;
            return {
                encType: "device",
                to: a,
                v: ((f = b.messageBytes) == null ? void 0 : f.version) === "v2" ? "2" : "3",
                type: j,
                mediaType: g,
                count: e,
                ciphertext: i,
                baseKey: c.value.baseKey
            }
        })
    }

    function j(a) {
        var b = a.messageBytes,
            c = a.to,
            e = a.icdc,
            f = a.chat;
        a = a.applicationPayloadVersion;
        if (b.version === "v3") {
            var g = null;
            d("WAGlobals").isPeerDevice(c) && (g = f);
            f = d("WAAsMessageTransport").asMessageTransport(b.bytes, g, null, e, a);
            return d("encodeProtobuf").encodeProtobuf(d("WAMsgTransport.pb").MessageTransportSpec, f).readByteArray()
        } else if (d("WAGlobals").isPeerDevice(c)) return b.bytesForPeer;
        else return b.bytes
    }

    function k(a) {
        a = a.messageBytes;
        if (a.version === "v3") {
            a = d("WAAsMessageTransport").asMessageTransport(a.bytes);
            return d("encodeProtobuf").encodeProtobuf(d("WAMsgTransport.pb").MessageTransportSpec, a).readByteArray()
        } else throw c("err")("Plaintext v2 not supported yet")
    }

    function l(a) {
        var b = a.skdm;
        a = a.icdc;
        b = d("WAAsMessageTransport").asMessageTransport(null, null, b, a);
        return d("encodeProtobuf").encodeProtobuf(d("WAMsgTransport.pb").MessageTransportSpec, b).readByteArray()
    }
    g.getEncNodes = a;
    g.getEncNode = b
}), 98);
__d("WAPhash", ["Promise", "WABase64", "WABinary", "WACryptoDependencies", "WALogger", "WASortedLists"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Calculate pHash -- end"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Calculate pHash -- Start"]);
        j = function() {
            return a
        };
        return a
    }

    function a(a) {
        d("WALogger").LOG(j());
        a = d("WASortedLists").sortAndDedupe(a);
        var c = new(d("WABinary").Binary)();
        for (var e = 0; e < a.length; e++) c.writeString(a[e]);
        return (h || (h = b("Promise"))).resolve(d("WACryptoDependencies").getCrypto().subtle.digest("SHA-256", c.readByteArray()).then(function(a) {
            d("WALogger").LOG(i());
            a = new Uint8Array(a, 0, 6);
            return "2:" + d("WABase64").encodeB64(a)
        }))
    }
    g.calculatePHash = a
}), 98);
__d("WAEncUserMsg", ["Promise", "WAEncNode", "WAGlobals", "WAICDCUtils", "WAJids", "WAPhash", "WATagsLogger", "asyncToGeneratorRuntime", "err", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg -- encryptUserMsg -- user message -- DONE"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg -- encryptUserMsg -- user message -- OTHER_RECIPENT_DEVICE_EMPTY"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg -- encryptUserMsg -- user message -- ICDC"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- senderIdentity is null in ICDC"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- Sender ICDC has invalid index"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- Sender does not have ICDC"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- no other recipient"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- no recipient"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg -- encryptUserMsg -- user message -- START"]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- getParticipantNodes -- receiverEncypted -- FALSE"]);
        r = function() {
            return a
        };
        return a
    }

    function s() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- encrypt - getParticipantNodes -- EMPTY DEVICE JIDS"]);
        s = function() {
            return a
        };
        return a
    }

    function t() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- encrypt -- getParticipantNodes -- START"]);
        t = function() {
            return a
        };
        return a
    }

    function u() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WAEncUserMsg -- getParticipantNodes -- EMPTY NODE"]);
        u = function() {
            return a
        };
        return a
    }
    var v = d("WATagsLogger").TAGS(["WAEncUserMsg"]);

    function a(a, b, c, d, e) {
        return w.apply(this, arguments)
    }

    function w() {
        w = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e, f, g, r) {
            v.LOG(q());
            a.length === 0 && v.ERROR(p());
            var s = !1;
            a.length === 1 && (s = a[0].user === d("WAGlobals").getMyUserJid());
            var t = a.find(function(a) {
                return a.user === d("WAGlobals").getMyUserJid()
            });
            if (t == null) {
                var u = (yield g.cryptoManager.storage.loadIdentities(d("WAGlobals").getMyUserJid()));
                u = u.get(d("WAGlobals").getMyDeviceJid());
                if (u == null) throw c("err")("Cannot add correct ICDC, as device misses identity");
                t = {
                    user: d("WAGlobals").getMyUserJid(),
                    devicesInfo: [{
                        identity: u,
                        jid: d("WAGlobals").getMyDeviceJid()
                    }]
                }
            }
            u = a.filter(function(a) {
                return a.user !== d("WAGlobals").getMyUserJid()
            });
            u.length === 0 && e.type !== "appdata" && !s && v.ERROR(o());
            var w;
            if (e.type === "message") {
                var y = f.find(function(a) {
                    a = a.user;
                    return a === d("WAGlobals").getMyUserJid()
                });
                y == null ? v.ERROR(n()) : d("WAICDCUtils").isICDCIndexInvalid(y) ? v.ERROR(m()) : c("gkx")("3176") || (w = d("WAICDCUtils").computeICDCParticipantDevices(t, u, f));
                w != null && w.senderIdentity == null && (r == null ? void 0 : r.addPoint("icdc-incorrect", {
                    string: {
                        encType: e.type
                    },
                    bool: {
                        isSelfThread: s
                    }
                }), v.ERROR(l()))
            }
            v.LOG(k());
            y = a.flatMap(function(a) {
                return a.devicesInfo
            }).map(function(a) {
                return a.jid
            });
            z(a) && v.LOG(j());
            return (h || (h = b("Promise"))).all([x(y, e, g, w), d("WAPhash").calculatePHash(y.concat(d("WAGlobals").getMyDeviceJid()))]).then(function(a) {
                var b = a[0];
                a = a[1];
                v.LOG(i());
                return {
                    participants: b,
                    phash: a
                }
            })
        });
        return w.apply(this, arguments)
    }

    function e(a, b, c) {
        return x(a, b, c)
    }

    function x(a, b, c, d) {
        return y(a, b, c, d).then(function(a) {
            if (a.length === 0) {
                v.WARN(u());
                return
            }
            return a
        })
    }

    function f(a, b, c, e, f, g) {
        return d("WAEncNode").getEncNode(a, b, c, e, f, g)
    }

    function y(a, b, c, e) {
        var f = !1;
        v.LOG(t());
        (b.type !== "message" || d("WAJids").interpretAsGroupJid(b.chat) != null) && (f = !0);
        a = d("WAEncNode").getEncNodes(new Map(a.map(function(a) {
            return [a, {
                params: b,
                icdc: e
            }]
        })), c).then(function(a) {
            if (a == null) {
                v.WARN(s());
                return []
            }
            b.type === "message" && (f = f || Array.from(a.keys()).some(function(a) {
                return d("WAJids").extractUserJid(a) === b.chat
            }));
            return Array.from(a == null ? void 0 : a.values())
        });
        return a.then(function(a) {
            if (f) return a;
            else {
                v.ERROR(r());
                return []
            }
        }).then(function(a) {
            return a.filter(Boolean)
        })
    }

    function z(a) {
        return a.filter(function(a) {
            return a.user !== d("WAGlobals").getMyUserJid()
        }).flatMap(function(a) {
            return a.devicesInfo
        }).length === 0
    }
    g.encryptUserMsg = a;
    g.encryptGroupFanoutMsg = e;
    g.encryptDeviceJidMessage = f
}), 98);
__d("WAGetSenderKeyStatusApi", ["MAWDexieTable", "MAWTransactionMode", "WADbPersonalSenderKeyStatusTxns", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        personalSenderKeyStatuses: d("MAWTransactionMode").READWRITE
    }, "getSenderKeyStatus", function(a) {
        return function(b) {
            return a.personalSenderKeyStatuses.get(b).then(function(c) {
                c != null ? c = d("MAWDexieTable").dexieResolve(c) : c = d("WADbPersonalSenderKeyStatusTxns").putNewPersonalSenderKeyStatus(a, b);
                return c.then(function(a) {
                    var b = a.hasSenderKey,
                        c = a.rotateSenderKey,
                        d = a.senderKeyId;
                    a = a.senderKeyTs;
                    return {
                        hasSenderKey: b,
                        rotateSenderKey: c,
                        senderKeyId: d,
                        ts: a
                    }
                })
            })
        }
    });
    g.getSenderKeyStatus = a
}), 98);
__d("WAGetUserDevices", ["regeneratorRuntime"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, c) {
        var d;
        return b("regeneratorRuntime").async(function(e) {
            while (1) switch (e.prev = e.next) {
                case 0:
                    e.next = 2;
                    return b("regeneratorRuntime").awrap(c.storage.bulkLoadIdentities(a));
                case 2:
                    d = e.sent;
                    return e.abrupt("return", Array.from(d).flatMap(function(a) {
                        a = a[1];
                        return Array.from(a.keys())
                    }));
                case 4:
                case "end":
                    return e.stop()
            }
        }, null, this)
    }
    f.getUserDevices = a
}), 66);
__d("WAMarkSenderKeyAsRotatedApi", ["MAWTransactionMode", "WADbPersonalSenderKeyStatusTxns", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        personalSenderKeyStatuses: d("MAWTransactionMode").READWRITE
    }, "markSEnderKeyAsRotated", function(a) {
        return function(b, c, e) {
            return d("WADbPersonalSenderKeyStatusTxns").updateSenderKeyStatusAsRotated(a, b, c, e).then(function() {})
        }
    });
    g.markSenderKeyAsRotated = a
}), 98);
__d("WAEncGroupMsg", ["WAAsMessageTransport", "WABridge", "WACryptoManager", "WACryptoManagerUtils", "WAEncUserMsg", "WAGetSenderKeyStatusApi", "WAGetUserDevices", "WAGlobals", "WAHex", "WAMarkSenderKeyAsRotatedApi", "WAMsgTransport.pb", "WAOdsEnums", "WAPhash", "WAPromiseQueue", "WAProtocolMediaType", "WAResultOrError", "WASortedLists", "WATagsLogger", "WATimeUtils", "asyncToGeneratorRuntime", "encodeProtobuf"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["end key distribution"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["start key distribution"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Encrypt success"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Finish encrypt group content"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Finish group fanout msg"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Finish rotate participant info"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Rotating sender key for group ", " because ", ""]);
        n = function() {
            return a
        };
        return a
    }
    var o = d("WATagsLogger").TAGS(["WAEncGroupMsg"]),
        p = 30 * d("WATimeUtils").DAY_SECONDS,
        q = new(d("WAPromiseQueue").PromiseQueue)();

    function r(a, b, c) {
        return s.apply(this, arguments)
    }

    function s() {
        s = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            var e = a.senderKeyId;
            if (e == null || a.rotateSenderKey || !d("WATimeUtils").happenedWithin(a.ts, p)) return d("WAResultOrError").makeError("sender-key-invalid");
            c = (yield c.cryptoManager.storage.loadSenderKeySession(b, d("WAGlobals").getMyDeviceJid()));
            if (c.success === !1 || c.value.senderKeyStates.length === 0) return d("WAResultOrError").makeError("sender-key-missing");
            b = c.value.senderKeyStates.at(-1);
            if (b == null) return d("WAResultOrError").makeError("sender-key-missing");
            return b.senderKeyId !== a.senderKeyId ? d("WAResultOrError").makeError("sender-key-id-mismatch") : d("WAResultOrError").makeResult({
                senderKeyId: e
            })
        });
        return s.apply(this, arguments)
    }

    function t(a, b) {
        return u.apply(this, arguments)
    }

    function u() {
        u = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            b = (yield d("WACryptoManager").rotateGroupSenderKey(b.cryptoManager, a, d("WAGlobals").getMyDeviceJid()));
            yield d("WAMarkSenderKeyAsRotatedApi").markSenderKeyAsRotated(a, b.senderKeyId, d("WATimeUtils").unixTime());
            return {
                senderKeyId: b.senderKeyId
            }
        });
        return u.apply(this, arguments)
    }

    function v(a, c, e, f) {
        return q.enqueue(b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
            var b = (yield d("WAGetSenderKeyStatusApi").getSenderKeyStatus(a)),
                g = (yield r(b, a, e)),
                h = (yield d("WAGetUserDevices").getUserDevices(c, e.cryptoManager)),
                i = new Set(h);
            if (g.success === !1) {
                o.LOG(n(), a, g.error);
                d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                    entity: d("WAOdsEnums").Entity.GROUP_SKS_INVALID,
                    key: g.error
                });
                f == null ? void 0 : f.addPoint("sender_key_rotation_start");
                var j = (yield t(a, e));
                f == null ? void 0 : f.addPoint("sender_key_rotation_end");
                return {
                    senderKeyId: j.senderKeyId,
                    needsSenderKey: i,
                    groupParticipants: new Set(h)
                }
            } else {
                ((j = b.hasSenderKey) != null ? j : []).forEach(function(a) {
                    return i["delete"](a)
                });
                f == null ? void 0 : f.addPoint("no_sk_rotation", {
                    "int": {
                        noRotationNeedsSK: i.size
                    }
                });
                return {
                    senderKeyId: g.value.senderKeyId,
                    needsSenderKey: i,
                    groupParticipants: new Set(h)
                }
            }
        }))
    }

    function a(a, b, c, d, e, f) {
        return w.apply(this, arguments)
    }

    function w() {
        w = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e, f, g) {
            g == null ? void 0 : g.addPoint("enc_group_start");
            var n = (yield v(a, b.map(function(a) {
                    return a.user
                }), f, g)),
                p = n.senderKeyId,
                q = n.needsSenderKey;
            n = n.groupParticipants;
            o.LOG(m());
            g == null ? void 0 : g.addPoint("rotated_participant_info");
            var r = null,
                s, t;
            b = b.flatMap(function(a) {
                return a.devicesInfo
            }).map(function(a) {
                return a.jid
            });
            n["delete"](d("WAGlobals").getMyDeviceJid());
            var u = !d("WASortedLists").areEqual(d("WASortedLists").asSortedSet(n), d("WASortedLists").sortAndDedupe(b)),
                w = e.type === "text" && e.isRevoked,
                y = e.type === "media" ? d("WAProtocolMediaType").castToProtocolMediaType(e.mediaType) : null;
            if (u || w) {
                u = (yield d("WAEncUserMsg").encryptGroupFanoutMsg(b, {
                    type: "message",
                    messageBytes: c,
                    messageType: e,
                    chat: a
                }, f));
                u && !(e.type === "text" && e.isInvisible === !0) && (s = u, t = {
                    encType: "group",
                    to: a,
                    v: c.version === "v3" ? "3" : "2",
                    type: "skmsg",
                    mediaType: y,
                    ciphertext: null
                });
                o.LOG(l());
                g == null ? void 0 : g.addPoint("finish_group_fanout_msg")
            } else {
                if (c.version === "v3") {
                    w = d("WAAsMessageTransport").asMessageTransport(c.bytes);
                    u = d("encodeProtobuf").encodeProtobuf(d("WAMsgTransport.pb").MessageTransportSpec, w).readByteArray()
                } else u = c.bytes;
                w = (yield d("WACryptoManagerUtils").encryptGroupContentWithMetrics(a, u, f));
                o.LOG(k());
                g == null ? void 0 : g.addPoint("finish_encrypt_group_content");
                if (w.success) {
                    o.LOG(j());
                    u = w.value;
                    p !== u.senderKeyId && n.forEach(function(a) {
                        return q.add(a)
                    });
                    if (q.size > 0) {
                        w = {
                            groupId: a,
                            axolotlSenderKeyDistributionMessage: d("WAHex").bytesToBuffer(u.senderKeyDistributionProto)
                        };
                        o.LOG(i());
                        p = b.filter(function(a) {
                            return q.has(a)
                        });
                        n = (yield x(p, w, f));
                        o.LOG(h());
                        g == null ? void 0 : g.addPoint("finish_skdm_enc_node");
                        n.length > 0 && (s = n, r = {
                            group: a,
                            senderKeyId: u.senderKeyId,
                            knowsSenderKey: new Set(p)
                        })
                    }
                    t = {
                        encType: "group",
                        to: a,
                        v: c.version === "v2" ? "2" : "3",
                        type: u.ciphertext.type,
                        mediaType: y,
                        ciphertext: u.ciphertext.ciphertext
                    };
                    e.type === "text" && e.isInvisible === !0 && (t = {
                        encType: "group",
                        to: a,
                        v: c.version === "v2" ? "2" : "3",
                        type: "skmsg",
                        mediaType: null,
                        ciphertext: null
                    })
                }
            }
            w = (yield d("WAPhash").calculatePHash(b.concat(d("WAGlobals").getMyDeviceJid())));
            g == null ? void 0 : g.addPoint("phash_finish");
            return {
                phash: w,
                participants: s,
                encNode: t,
                senderKeyDistributionInfo: r
            }
        });
        return w.apply(this, arguments)
    }

    function x(a, b, c) {
        b = d("WAAsMessageTransport").asMessageTransport(null, null, b, null);
        var e = d("encodeProtobuf").encodeProtobuf(d("WAMsgTransport.pb").MessageTransportSpec, b).readByteArray();
        return d("WACryptoManagerUtils").bulkEncrypt(new Map(a.map(function(a) {
            return [a, {
                plaintext: e
            }]
        })), c).then(function(a) {
            var b = [];
            a.forEach(function(a, c) {
                b.push({
                    encType: "device",
                    to: c,
                    v: "3",
                    type: a.type,
                    ciphertext: a.ciphertext,
                    mediaType: null,
                    count: null,
                    baseKey: null
                })
            });
            return b
        })
    }
    g.encryptGroupMsg = a
}), 98);
__d("WAHttpRegularUploadMedia", ["WALogger", "WAMediaUtils", "WAResultOrError", "err", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpRegularUploadMedia: fail to parse request body ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Fetch Media HTTP status ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["HttpRegularUploadMedia: fail to initiate fetch ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function a(a, e) {
        var f, g, k;
        return b("regeneratorRuntime").async(function(l) {
            while (1) switch (l.prev = l.next) {
                case 0:
                    l.prev = 0;
                    l.next = 3;
                    return b("regeneratorRuntime").awrap(fetch(a, {
                        method: "POST",
                        mode: "cors",
                        cache: "no-store",
                        headers: {
                            "Content-Type": "text/plain"
                        },
                        body: new Blob([e])
                    }));
                case 3:
                    f = l.sent;
                    l.next = 10;
                    break;
                case 6:
                    l.prev = 6;
                    l.t0 = l["catch"](0);
                    d("WALogger").ERROR(j(), l.t0);
                    throw l.t0;
                case 10:
                    g = f, k = g.status;
                    d("WALogger").LOG(i(), k);
                    l.t1 = k;
                    l.next = l.t1 === 200 ? 15 : l.t1 === 408 ? 16 : l.t1 === 413 ? 17 : l.t1 === 415 ? 18 : l.t1 === 429 ? 19 : l.t1 === 507 ? 19 : 20;
                    break;
                case 15:
                    return l.abrupt("return", f.json().then(function(a) {
                        if (!Object.prototype.hasOwnProperty.call(a, "direct_path")) throw c("err")("direct_path not available in wa upload http response");
                        if (typeof a.direct_path !== "string") throw c("err")('directPath: "' + a.direct_path + '" is not a string');
                        if (a.object_id && typeof a.object_id !== "string") throw c("err")('objectId: "' + a.object_id + '" is not a string');
                        if (a.handle && typeof a.handle !== "string") throw c("err")('handle: "' + a.handle + '" is not a string');
                        a = {
                            directPath: d("WAMediaUtils").unsafeCastToDirectPath(a.direct_path),
                            objectId: a.object_id,
                            handle: a.handle
                        };
                        return d("WAResultOrError").makeResult(a)
                    })["catch"](function(a) {
                        d("WALogger").ERROR(h(), a);
                        return d("WAResultOrError").makeError("body-network-error")
                    }));
                case 16:
                    return l.abrupt("return", d("WAResultOrError").makeError("server-timeout"));
                case 17:
                    return l.abrupt("return", d("WAResultOrError").makeError("payload-too-large"));
                case 18:
                    return l.abrupt("return", d("WAResultOrError").makeError("invalid-media"));
                case 19:
                    return l.abrupt("return", d("WAResultOrError").makeError("upload-throttled"));
                case 20:
                    if (!(k >= 400 && k < 500)) {
                        l.next = 22;
                        break
                    }
                    return l.abrupt("return", d("WAResultOrError").makeError("request-error"));
                case 22:
                    return l.abrupt("return", d("WAResultOrError").makeError("unspecified-http-error"));
                case 23:
                case "end":
                    return l.stop()
            }
        }, null, this, [
            [0, 6]
        ])
    }
    g.httpRegularUploadMedia = a
}), 98);
__d("WAEncryptAndUploadPlaintext", ["WABase64", "WAGlobals", "WAHttpRegularUploadMedia", "WAHttpResumeCheck", "WALogger", "WAMediaCrypto", "WAMediaUrl", "WAMediaUtils", "WAProgressiveJpegGetPJpegDetails", "WAResultOrError", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: upload success ", " ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext given up"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext error: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext error: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: start upload media to ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: error during retrier ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: Found valid progressiveJpeg details. Adding to media entry."]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: Created invalid progressiveJpeg details during encrypt and upload: ", ""]);
        o = function() {
            return a
        };
        return a
    }

    function a(a) {
        return p.apply(this, arguments)
    }

    function p() {
        p = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var c = a.mediaTypeDetails,
                e = a.plaintextHash,
                f = a.plaintext,
                g = a.mediaKey,
                p = a.mediaKeyTimestamp,
                q = a.uploadToken,
                r = a.size,
                s = a.uploadRetrier,
                t = a.updateMediaEntry,
                u = a.mediaUploadQplFlow,
                v = a.filename,
                w = a.fromOffset,
                x = w === void 0 ? 0 : w;
            w = a.getDownloadableThumbnailForMedia;
            var y, z, A;
            if (c.type === "preview") {
                a = (yield d("WAMediaCrypto").computeMediaKeysForPreview(g));
                y = a.iv;
                z = a.cipherKey;
                a = a.hmacKey;
                A = "preview"
            } else {
                var B = (yield d("WAMediaCrypto").computeMediaKeys(g, c.mediaType));
                y = B.iv;
                z = B.cipherKey;
                a = B.hmacKey;
                A = c.mediaType
            }
            B = (yield d("WAMediaCrypto").encryptAndHmac(z, y, a, f, A));
            var C = B.ciphertext,
                D = B.ciphertextHash;
            c = B.sidecar;
            z = B.ivCiphertextHmac;
            y = null;
            if (A === "image") {
                u == null ? void 0 : u.addPoint("get_progressive_jpeg_details_start");
                B = (yield d("WAProgressiveJpegGetPJpegDetails").getProgressiveJpegDetails(new Uint8Array(yield d("WAMediaUtils").blobToArrayBuffer(f)), z, a));
                f = d("WAProgressiveJpegGetPJpegDetails").isValidProgressiveJpegDetails(B);
                f.success === !1 ? (d("WALogger").ERROR(o(), f.error), u == null ? void 0 : u.addPoint(f.error)) : f.value === !0 && d("WAGlobals").getConfig().isProgressiveJpegSendEnabled() && (d("WALogger").LOG(n()), y = B, u == null ? void 0 : u.addPoint("get_progressive_jpeg_details_end"))
            }
            z = {
                fileSha256: d("WABase64").decodeB64UrlSafe(e),
                fileEncSha256: D,
                mediaKey: g,
                mediaKeyTimestamp: p,
                serverMediaType: A,
                uploadToken: q,
                sidecar: c,
                filename: v,
                progressiveJpegDetails: y,
                size: r,
                lastDownloadAttemptTimestamp: void 0,
                directPath: void 0
            };
            var E;
            u == null ? void 0 : u.addPoint("update_media_entry_start");
            yield t(z);
            u == null ? void 0 : u.addPoint("update_media_entry_end");
            a = (yield s.run(function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
                    a = a.domain;
                    var e = x;
                    if (c > 0) try {
                        u == null ? void 0 : u.addPoint("resume_check_start");
                        var f = d("WAMediaUrl").buildUploadUrl(A, q, D, a, b, !0);
                        f = (yield d("WAHttpResumeCheck").httpResumeCheck(f));
                        if (f.success) {
                            u == null ? void 0 : u.addPoint("resume_check_end");
                            var g = f.value;
                            if (g.type === "media-found") {
                                u == null ? void 0 : u.addAnnotations({
                                    bool: {
                                        existingMediaFound: !0
                                    }
                                });
                                return d("WAResultOrError").makeResult(d("WAResultOrError").makeResult({
                                    directPath: g.directPath,
                                    objectId: null,
                                    handle: null
                                }))
                            }
                            g.type === "media-partial-found" && (e = g.resumeFromBytes)
                        }
                        u == null ? void 0 : u.addPoint("resume_check_fail", {
                            string: {
                                resume_check_error: f.error
                            }
                        })
                    } catch (a) {
                        u == null ? void 0 : u.addPoint("resume_check_fail", {
                            string: {
                                resume_check_error: a.message
                            }
                        }), d("WALogger").ERROR(m(), a)
                    }
                    e > 0 && e < C.byteLength ? (u == null ? void 0 : u.addAnnotations({
                        "int": {
                            fromOffset: e
                        },
                        bool: {
                            continuedFromOffset: !0
                        }
                    }), E = C.subarray(e)) : E = C;
                    g = d("WAMediaUrl").buildUploadUrl(A, q, D, a, b, !1, e);
                    d("WALogger").LOG(l(), g);
                    u == null ? void 0 : u.addPoint("http_upload_start");
                    return d("WAHttpRegularUploadMedia").httpRegularUploadMedia(g, E).then(function(a) {
                        if (a.success) {
                            u == null ? void 0 : u.addPoint("http_upload_end", {
                                "int": {
                                    byteLength: E.byteLength,
                                    attempt: c
                                }
                            });
                            return d("WAResultOrError").makeResult(a)
                        } else {
                            a = a.error;
                            u == null ? void 0 : u.addPoint("http_upload_fail", {
                                string: {
                                    http_upload_error: a
                                }
                            });
                            d("WALogger").LOG(k(), a);
                            switch (a) {
                                case "server-timeout":
                                case "unspecified-http-error":
                                    return d("WAResultOrError").makeError({
                                        progressMade: !0
                                    });
                                default:
                                    return d("WAResultOrError").makeResult(d("WAResultOrError").makeError(a))
                            }
                        }
                    })["catch"](function(a) {
                        u == null ? void 0 : u.addPoint("http_upload_fail", {
                            string: {
                                http_upload_error: a.message
                            }
                        });
                        d("WALogger").ERROR(j(), a);
                        return d("WAResultOrError").makeError({
                            progressMade: !1
                        })
                    })
                });
                return function(b, c, d) {
                    return a.apply(this, arguments)
                }
            }()));
            if (a == null) {
                d("WALogger").WARN(i());
                u == null ? void 0 : u.endFail("maxAttemptsExceeded");
                return d("WAResultOrError").makeError("max-attempts-exceeded")
            }
            if (a.success === !1) {
                u == null ? void 0 : u.endFail(a.error);
                return a
            }
            f = a.value;
            B = f.directPath;
            g = f.objectId;
            p = f.handle;
            try {
                u == null ? void 0 : u.addPoint("persist_downloadable_thumbnail_start");
                c = (yield w(e));
                z = babelHelpers["extends"]({}, z, {
                    directPath: B,
                    downloadableThumbnail: c,
                    handle: p,
                    objectId: g
                });
                yield t(z);
                u == null ? void 0 : u.addPoint("persist_downloadable_thumbnail_end")
            } catch (a) {
                u == null ? void 0 : u.addPoint("persist_downloadable_thumbnail_fail", {
                    string: {
                        persist_downloadable_thumbnail_error: a.message
                    }
                })
            }
            d("WALogger").LOG(h(), {
                directPath: B
            }, {
                objectId: g
            });
            u == null ? void 0 : u.endSuccess();
            return d("WAResultOrError").makeResult(z)
        });
        return p.apply(this, arguments)
    }
    g.encryptAndUploadPlaintext = a
}), 98);
__d("WAIsMediaKeyReusable", ["WATimeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 2 * d("WATimeUtils").DAY_SECONDS;

    function a(a) {
        var b = Math.floor(Math.random() * d("WATimeUtils").DAY_SECONDS);
        return a != null && d("WATimeUtils").happenedWithin(a, h + b)
    }
    g.MMS_MEDIA_KEY_TTL = h;
    g.isMediaKeyReusable = a
}), 98);
__d("WAFindReusableMediaEntry", ["WAIsMediaKeyReusable", "WAMediaUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        if (a == null) return null;
        b = b.get(a);
        if (b == null) return null;
        a = d("WAMediaUtils").decodeMediaEntryData(b);
        b = a.fileEncSha256;
        var c = a.mediaKey,
            e = a.mediaKeyTimestamp,
            f = a.uploadToken;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["fileEncSha256", "mediaKey", "mediaKeyTimestamp", "uploadToken"]);
        return c != null && f != null && b != null && e != null && d("WAIsMediaKeyReusable").isMediaKeyReusable(e) ? babelHelpers["extends"]({}, a, {
            fileEncSha256: b,
            mediaKey: c,
            mediaKeyTimestamp: e,
            uploadToken: f
        }) : null
    }
    g.findReusableMediaEntryForArmadillo = a
}), 98);
__d("WAGetMetaApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READONLY
    }, "getMeta", function(a) {
        return function() {
            return a.meta.bulkGet(["certificateChain", "deviceId", "identityKeyPair", "abProps", "edgeInfo", "clockSkew", "authKeyPair"]).then(function(a) {
                var b = a[0],
                    c = a[1],
                    d = a[2],
                    e = a[3],
                    f = a[4],
                    g = a[5];
                a = a[6];
                return {
                    abProps: e == null ? void 0 : (e = e.value) == null ? void 0 : e.abProps,
                    authKeyPair: a == null ? void 0 : (e = a.value) == null ? void 0 : e.authKeyPair,
                    certificateChain: b == null ? void 0 : (a = b.value) == null ? void 0 : a.certificateChain,
                    clockSkew: g == null ? void 0 : (e = g.value) == null ? void 0 : e.clockSkew,
                    deviceId: c == null ? void 0 : (b = c.value) == null ? void 0 : b.deviceId,
                    edgeInfo: f == null ? void 0 : (a = f.value) == null ? void 0 : a.edgeInfo,
                    identityKeyPair: d == null ? void 0 : (g = d.value) == null ? void 0 : g.identityKeyPair
                }
            })
        }
    });
    g.getMeta = a
}), 98);
__d("WAGetMetaApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        return d("WormDb").getDb().runInTransaction(["meta"], "readonly", function(a) {
            return a.stores.meta.bulkGet(["certificateChain", "deviceId", "identityKeyPair", "abProps", "edgeInfo", "clockSkew", "authKeyPair"]).then(function(a) {
                var b = a[0],
                    c = a[1],
                    d = a[2],
                    e = a[3],
                    f = a[4],
                    g = a[5];
                a = a[6];
                return {
                    abProps: e == null ? void 0 : (e = e.value) == null ? void 0 : e.abProps,
                    authKeyPair: a == null ? void 0 : (e = a.value) == null ? void 0 : e.authKeyPair,
                    certificateChain: b == null ? void 0 : (a = b.value) == null ? void 0 : a.certificateChain,
                    clockSkew: g == null ? void 0 : (e = g.value) == null ? void 0 : e.clockSkew,
                    deviceId: c == null ? void 0 : (b = c.value) == null ? void 0 : b.deviceId,
                    edgeInfo: f == null ? void 0 : (a = f.value) == null ? void 0 : a.edgeInfo,
                    identityKeyPair: d == null ? void 0 : (g = d.value) == null ? void 0 : g.identityKeyPair
                }
            })
        }, d("WormDb").signalOp("getMeta"))
    };
    g.getMeta = a
}), 98);
__d("WAGetCurrentUserDeviceInfoApi", ["WADexieToWormMigration", "WAGetMetaApi", "WAGetMetaApiV2", "WASignalKeys"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        return (d("WADexieToWormMigration").isWorm("WAGetCurrentUserDeviceInfoApi") ? d("WAGetMetaApiV2").getMeta() : d("WAGetMetaApi").getMeta()).then(function(a) {
            var b = a == null ? void 0 : a.deviceId;
            a = a == null ? void 0 : a.identityKeyPair;
            if (b == null || a == null) return null;
            a = d("WASignalKeys").serializePubKey(a);
            return {
                deviceId: b,
                identityKey: a
            }
        })
    };
    b = function() {
        return (d("WADexieToWormMigration").isWorm("WAGetCurrentUserDeviceInfoApi") ? d("WAGetMetaApiV2").getMeta() : d("WAGetMetaApi").getMeta()).then(function(a) {
            return (a == null ? void 0 : a.deviceId) == null ? null : {
                deviceId: a == null ? void 0 : a.deviceId
            }
        })
    };
    g.getCurrentUserDeviceInfo = a;
    g.getCurrentUserDeviceId = b
}), 98);
__d("WASmaxInDevicesFetchSelfResponseError", ["WAResultOrError", "WASmaxInDevicesIQErrorResponseMixin", "WASmaxInDevicesRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInDevicesIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInDevicesRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup").parseRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup: b.value
        }))
    }
    g.parseFetchSelfResponseError = a
}), 98);
__d("WASmaxInDevicesDeviceInfoMixin", ["WAResultOrError", "WASmaxInDevicesIdentityKeyMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "platform");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentString(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function i(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "manufacturer");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentString(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function j(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "model");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentString(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function k(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "seen");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentInt(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function l(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "creation");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentInt(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function m(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ip");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentString(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function n(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "location");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrString(a, "latitude");
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").attrString(a, "longitude");
        if (!c.success) return c;
        a = d("WASmaxParseUtils").contentString(a);
        return !a.success ? a : d("WAResultOrError").makeResult({
            latitude: b.value,
            longitude: c.value,
            elementValue: a.value
        })
    }

    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "device");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").optionalChildWithTag(a, "platform", h);
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").optionalChildWithTag(a, "manufacturer", i);
        if (!c.success) return c;
        var e = d("WASmaxParseUtils").optionalChildWithTag(a, "model", j);
        if (!e.success) return e;
        var f = d("WASmaxParseUtils").optionalChildWithTag(a, "seen", k);
        if (!f.success) return f;
        var g = d("WASmaxParseUtils").optionalChildWithTag(a, "creation", l);
        if (!g.success) return g;
        var o = d("WASmaxParseUtils").optionalChildWithTag(a, "ip", m);
        if (!o.success) return o;
        var p = d("WASmaxParseUtils").optionalChildWithTag(a, "location", n);
        if (!p.success) return p;
        var q = d("WASmaxParseUtils").attrIntRange(a, "id", 1, 999);
        if (!q.success) return q;
        a = d("WASmaxInDevicesIdentityKeyMixin").parseIdentityKeyMixin(a);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            id: q.value
        }, a.value, {
            platform: b.value,
            manufacturer: c.value,
            model: e.value,
            seen: f.value,
            creation: g.value,
            ip: o.value,
            location: p.value
        }))
    }
    g.parseDeviceInfoPlatform = h;
    g.parseDeviceInfoManufacturer = i;
    g.parseDeviceInfoModel = j;
    g.parseDeviceInfoSeen = k;
    g.parseDeviceInfoCreation = l;
    g.parseDeviceInfoIp = m;
    g.parseDeviceInfoLocation = n;
    g.parseDeviceInfoMixin = a
}), 98);
__d("WASmaxInDevicesFetchSelfResponseSuccess", ["WAResultOrError", "WASmaxInDevicesDeviceInfoMixin", "WASmaxInDevicesIQResultResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "device");
        if (!b.success) return b;
        b = d("WASmaxInDevicesDeviceInfoMixin").parseDeviceInfoMixin(a);
        return !b.success ? b : b
    }

    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "self");
        if (!c.success) return c;
        a = d("WASmaxInDevicesIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxParseUtils").mapChildrenWithTag(c.value, "device", 1, 25, h);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            selfDevice: b.value
        }))
    }
    g.parseFetchSelfResponseSuccessSelfDevice = h;
    g.parseFetchSelfResponseSuccess = a
}), 98);
__d("WASmaxOutDevicesFetchSelfRequest", ["WASmaxJsx", "WASmaxOutDevicesBaseIQGetRequestMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function a() {
        var a = d("WASmaxOutDevicesBaseIQGetRequestMixin").mergeBaseIQGetRequestMixin(d("WASmaxJsx").smax("iq", {
            to: d("WAWap").S_WHATSAPP_NET,
            xmlns: "fbid:devices"
        }, d("WASmaxJsx").smax("self", null)));
        return a
    }
    g.makeFetchSelfRequest = a
}), 98);
__d("WASmaxDevicesFetchSelfRPC", ["WAComms", "WASmaxInDevicesFetchSelfResponseError", "WASmaxInDevicesFetchSelfResponseSuccess", "WASmaxOutDevicesFetchSelfRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var c, e, f, g;
        return b("regeneratorRuntime").async(function(h) {
            while (1) switch (h.prev = h.next) {
                case 0:
                    c = d("WASmaxOutDevicesFetchSelfRequest").makeFetchSelfRequest();
                    h.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(c, a));
                case 3:
                    e = h.sent;
                    f = d("WASmaxInDevicesFetchSelfResponseSuccess").parseFetchSelfResponseSuccess(e, c);
                    if (!f.success) {
                        h.next = 7;
                        break
                    }
                    return h.abrupt("return", {
                        name: "FetchSelfResponseSuccess",
                        value: f.value
                    });
                case 7:
                    g = d("WASmaxInDevicesFetchSelfResponseError").parseFetchSelfResponseError(e, c);
                    if (!g.success) {
                        h.next = 10;
                        break
                    }
                    return h.abrupt("return", {
                        name: "FetchSelfResponseError",
                        value: g.value
                    });
                case 10:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("FetchSelf", {
                        Success: f,
                        Error: g
                    }));
                case 11:
                case "end":
                    return h.stop()
            }
        }, null, this)
    }
    g.sendFetchSelfRPC = a
}), 98);
__d("WAGetCurrentUserDeviceList", ["WAAssertUnreachable", "WAGlobals", "WAJids", "WALogger", "WAPersistedJobManager", "WASignalKeys", "WASmaxDevicesFetchSelfRPC", "WATimeUtils", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Two devices were detected as isCurrentDevice in getCurrentUserDeviceList"]);
        h = function() {
            return a
        };
        return a
    }

    function i(a, b) {
        if (a.isCurrentDevice && b.isCurrentDevice) {
            d("WALogger").ERROR(h());
            return 0
        }
        if (a.isCurrentDevice) return -1;
        if (b.isCurrentDevice) return 1;
        if (a.lastSeen != null && b.lastSeen == null) return -1;
        if (a.lastSeen == null && b.lastSeen != null) return 1;
        if (a.lastSeen != null && b.lastSeen != null) {
            a = a.lastSeen;
            b = b.lastSeen;
            return b.getTime() - a.getTime()
        }
        return 0
    }

    function a(a) {
        return j.apply(this, arguments)
    }

    function j() {
        j = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            a = (yield d("WASmaxDevicesFetchSelfRPC").sendFetchSelfRPC());
            switch (a.name) {
                case "FetchSelfResponseError":
                    var b = a.value.errorRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup;
                    switch (b.name) {
                        case "RetryableIQError":
                            var e = b.value.backoff;
                            if (e != null) throw new(d("WAPersistedJobManager").RetryOnBackoff)({
                                algo: {
                                    delay: e,
                                    type: "constant"
                                },
                                jitter: 0
                            });
                            else throw new(d("WAPersistedJobManager").RetryOnBackoff)({
                                algo: {
                                    first: d("WATimeUtils").HOUR_MILLISECONDS / 60,
                                    type: "exponential"
                                },
                                jitter: .1
                            });
                        default:
                            b.name;
                            e = b.value.code;
                            throw c("err")("Failed with an error code " + e)
                    }
                case "FetchSelfResponseSuccess":
                    var f = d("WAJids").extractDeviceId(d("WAGlobals").getMyDeviceJid());
                    return a.value.selfDevice.map(function(a) {
                        var b = a.creation,
                            c = a.elementValue,
                            e = a.id,
                            g = a.ip,
                            h = a.location,
                            i = a.manufacturer,
                            j = a.model,
                            k = a.platform;
                        a = a.seen;
                        return {
                            creationTime: b == null ? null : d("WATimeUtils").toDate(d("WATimeUtils").castToUnixTime(b.elementValue)),
                            id: d("WAJids").interpretAsDeviceId(e),
                            identityKey: d("WASignalKeys").serializeIdentity(c),
                            ipAddress: (b = g == null ? void 0 : g.elementValue) != null ? b : null,
                            isCurrentDevice: e === f,
                            lastSeen: a == null ? null : d("WATimeUtils").toDate(d("WATimeUtils").castToUnixTime(a.elementValue)),
                            latitude: h == null ? null : parseFloat(h.latitude),
                            location: (c = h == null ? void 0 : h.elementValue) != null ? c : null,
                            longitude: h == null ? null : parseFloat(h.longitude),
                            manufacturer: (g = i == null ? void 0 : i.elementValue) != null ? g : null,
                            model: (b = j == null ? void 0 : j.elementValue) != null ? b : null,
                            platform: (e = k == null ? void 0 : k.elementValue) != null ? e : null
                        }
                    }).sort(i);
                default:
                    return c("WAAssertUnreachable")(a.name)
            }
        });
        return j.apply(this, arguments)
    }
    g.getCurrentUserDeviceList = a
}), 98);
__d("WAGetDeviceIdentityMixin", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a != null ? {
            deviceIdentityElementValue: a
        } : null
    }
    f.getDeviceIdentityMixin = a
}), 66);
__d("WAGroupInviteUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a
    }
    f.toInviteCode = a
}), 66);
__d("WAGroupParserUtils", ["WAGroupInviteUtils", "WAJids", "WALogger", "WAResultOrError", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["received unknown participant error code: ", ""]);
        h = function() {
            return a
        };
        return a
    }
    var i = {
        superadmin: "superadmin",
        admin: "admin",
        participant: "participant",
        nonparticipant: "nonparticipant"
    };

    function j(a) {
        if (!a.hasAttr("error")) throw c("err")("Expected participant node to have error attr");
        var b = a.attrInt("error"),
            e = a.attrUserJid("jid");
        switch (b) {
            case 401:
                return {
                    errorCode: b,
                    text: "not-authorized",
                    user: e
                };
            case 403:
                a = a.child("add_request");
                return {
                    errorCode: b,
                    text: "request-code",
                    code: d("WAGroupInviteUtils").toInviteCode(a.attrString("code")),
                    expiration: a.attrTime("expiration"),
                    user: e
                };
            case 404:
                return {
                    errorCode: b,
                    text: "not-found",
                    user: e
                };
            case 406:
                return {
                    errorCode: b,
                    text: "enterprise-not-allowed",
                    user: e
                };
            case 408:
                return {
                    errorCode: b,
                    text: "temporarily-blocked",
                    user: e
                };
            case 409:
                return {
                    errorCode: b,
                    text: "conflict",
                    user: e
                };
            case 500:
                return {
                    errorCode: b,
                    text: "resource-constraint",
                    user: e
                };
            default:
                d("WALogger").ERROR(h(), b);
                return {
                    errorCode: -1,
                    text: "unknown",
                    user: e
                }
        }
    }

    function k(a, b) {
        a.assertTag("participant");
        var c = "participant";
        switch (b) {
            case "add":
            case "demote":
                c = "participant";
                break;
            case "promote":
                c = "admin";
                break;
            case "remove":
                c = "nonparticipant";
                break
        }
        b = a.attrUserJid("jid");
        if (a.hasAttr("error")) {
            var e = j(a);
            return d("WAResultOrError").makeError(e)
        } else {
            e = a.attrEnumOrDefault("type", i, c);
            c = a.maybeAttrString("addressable") !== "false";
            return d("WAResultOrError").makeResult({
                user: b,
                type: e,
                addressable: c
            })
        }
    }

    function a(a) {
        a.assertTag("group");
        var b, c = a.attrString("id");
        c.includes("@") ? b = a.attrGroupJid("id") : b = d("WAJids").toGroupJid(c);
        return {
            jid: b,
            creator: a.maybeAttrUserJid("creator") || void 0,
            creationTs: a.attrTime("creation"),
            subject: {
                content: a.maybeAttrString("subject") || void 0,
                user: a.maybeAttrUserJid("s_o") || void 0,
                ts: a.hasAttr("s_t") ? a.attrTime("s_t") : void 0
            },
            description: m(a) || void 0,
            participantVersion: a.maybeAttrString("p_v_id") || void 0,
            participants: a.mapChildrenWithTag("participant", function(a) {
                return k(a)
            }),
            memberAddMode: l(a) || void 0
        }
    }

    function l(a) {
        if (a.hasChild("member_add_mode")) {
            a = a.child("member_add_mode");
            if (a.hasContent()) {
                a = a.contentString();
                if (a === "admin_add" || a === "all_member_add") return a
            }
        }
        return null
    }

    function m(a) {
        if (a.hasChild("description")) {
            a = a.child("description");
            if (a.hasChild("body")) {
                var b = a.child("body");
                if (b.hasContent()) return {
                    id: a.attrString("id"),
                    ts: a.attrTime("t"),
                    content: b.contentString(),
                    user: b.maybeAttrUserJid("participant") || void 0
                }
            }
        }
        return null
    }
    g.PARTICIPANT_TYPES = i;
    g.parseProtocolGroupParticipantNode = k;
    g.parseGroupNode = a
}), 98);
__d("WALoadReceiptApi", ["MAWTransactionMode", "WADbTransactor", "WAMsg", "WAResultOrError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        receipts: d("MAWTransactionMode").READONLY
    }, "loadReceipt", function(a) {
        return function(b) {
            var c = d("WAMsg").craftWAMsgIdString(b);
            return a.receipts.get({
                waMsgId: c
            }).then(function(a) {
                var c;
                return a == null ? d("WAResultOrError").makeError("missing-receipt") : d("WAResultOrError").makeResult({
                    id: b,
                    permittedIdentitiesPerDevice: (c = a.permittedIdentitiesPerDevice) != null ? c : new Map(),
                    recipientDevices: a.recipientDevices
                })
            })
        }
    });
    g.loadReceipt = a
}), 98);
__d("WAMarkSenderKeyAsSentApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        personalSenderKeyStatuses: d("MAWTransactionMode").READWRITE
    }, "markSenderKeyAsSent", function(a) {
        return function(b, c, d) {
            return a.personalSenderKeyStatuses.get(b).then(function(b) {
                if (b == null) return;
                if (b.senderKeyId != c) return;
                d.forEach(function(a) {
                    b.hasSenderKey.add(a)
                });
                return a.personalSenderKeyStatuses.put(b).then(function() {})
            })
        }
    });
    g.markSenderKeyAsSent = a
}), 98);
__d("WASmaxInDevicesNotifyResponseError", ["WAResultOrError", "WASmaxInDevicesIQErrorResponseMixin", "WASmaxInDevicesRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInDevicesIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInDevicesRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup").parseRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup: b.value
        }))
    }
    g.parseNotifyResponseError = a
}), 98);
__d("WASmaxInDevicesNotifyResponseSuccess", ["WASmaxInDevicesIQResultResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxInDevicesIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        return !c.success ? c : c
    }
    g.parseNotifyResponseSuccess = a
}), 98);
__d("WASmaxOutDevicesBaseIQSetRequestMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("iq", {
            id: d("WAWap").generateId(),
            type: "set"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBaseIQSetRequestMixin = a
}), 98);
__d("WASmaxOutDevicesNotifyRequest", ["WASmaxChildren", "WASmaxJsx", "WASmaxOutDevicesBaseIQSetRequestMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.userJid;
        a = d("WASmaxJsx").smax("user", {
            jid: d("WAWap").USER_JID(a)
        });
        return a
    }

    function a(a) {
        a = a.userArgs;
        a = d("WASmaxOutDevicesBaseIQSetRequestMixin").mergeBaseIQSetRequestMixin(d("WASmaxJsx").smax("iq", {
            to: d("WAWap").S_WHATSAPP_NET,
            xmlns: "fbid:devices"
        }, d("WASmaxJsx").smax("users", null, d("WASmaxChildren").REPEATED_CHILD(h, a, 1, 25))));
        return a
    }
    g.makeNotifyRequestUsersUser = h;
    g.makeNotifyRequest = a
}), 98);
__d("WASmaxDevicesNotifyRPC", ["WAComms", "WASmaxInDevicesNotifyResponseError", "WASmaxInDevicesNotifyResponseSuccess", "WASmaxOutDevicesNotifyRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h;
        return b("regeneratorRuntime").async(function(i) {
            while (1) switch (i.prev = i.next) {
                case 0:
                    e = d("WASmaxOutDevicesNotifyRequest").makeNotifyRequest(a);
                    i.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = i.sent;
                    g = d("WASmaxInDevicesNotifyResponseSuccess").parseNotifyResponseSuccess(f, e);
                    if (!g.success) {
                        i.next = 7;
                        break
                    }
                    return i.abrupt("return", {
                        name: "NotifyResponseSuccess",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInDevicesNotifyResponseError").parseNotifyResponseError(f, e);
                    if (!h.success) {
                        i.next = 10;
                        break
                    }
                    return i.abrupt("return", {
                        name: "NotifyResponseError",
                        value: h.value
                    });
                case 10:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("Notify", {
                        Success: g,
                        Error: h
                    }));
                case 11:
                case "end":
                    return i.stop()
            }
        }, null, this)
    }
    g.sendNotifyRPC = a
}), 98);
__d("WANotifyDeviceChange", ["Promise", "WAGlobals", "WALogger", "WAPersistedJobManager", "WASmaxDevicesNotifyRPC", "WATimeUtils", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["The maximum number of users that can be notified is ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function a(a, c) {
        a = c.users;
        if (a.size === 0) return (h || (h = b("Promise"))).resolve();
        c = d("WAGlobals").getConfig().maxUsersForNotifyDeviceChange();
        var e = Array.from(a);
        a.size > c && (d("WALogger").ERROR(i(), c), e = e.slice(0, c));
        return j(e)
    }

    function j(a) {
        return k.apply(this, arguments)
    }

    function k() {
        k = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            a = (yield d("WASmaxDevicesNotifyRPC").sendNotifyRPC({
                userArgs: a.map(function(a) {
                    return {
                        userJid: a
                    }
                })
            }));
            if (a.name === "NotifyResponseSuccess") return;
            a.name;
            a = a.value.errorRetryableIQErrorOrNonRetryableIQErrorRetryableIQErrorMixinGroup;
            if (a.name === "RetryableIQError") {
                var b = a.value.backoff;
                if (b != null) throw new(d("WAPersistedJobManager").RetryOnBackoff)({
                    algo: {
                        type: "constant",
                        delay: b
                    },
                    jitter: 0
                });
                else throw new(d("WAPersistedJobManager").RetryOnBackoff)({
                    algo: {
                        type: "exponential",
                        first: d("WATimeUtils").HOUR_MILLISECONDS / 60
                    },
                    jitter: .1
                })
            }
            throw c("err")("Failed with an unexpected error code " + a.value.code)
        });
        return k.apply(this, arguments)
    }
    g.notifyDeviceChange = a
}), 98);
__d("WAParseFranking", ["WAFranking", "WAFrankingTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b;
        if (a == null) return null;
        b = (b = a.maybeChild("franking_tag")) == null ? void 0 : b.contentBytes();
        return {
            frankingKey: null,
            frankingTag: b != null ? d("WAFrankingTypes").castToFrankingTag(b) : null,
            reportingTag: (b = a.maybeChild("reporting_tag")) == null ? void 0 : b.contentBytes(),
            frankingVersion: d("WAFranking").getFrankingVersion(),
            reportingContent: null
        }
    }
    g.parseFrankingNode = a
}), 98);
__d("WAPreEstablishOutgoingSessionForGroup", ["Promise", "WACryptoManagerUtils", "WAGlobals", "WAPushSafeTypes", "WAResultOrError", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = new Set();

    function a(a, b) {
        return j.apply(this, arguments)
    }

    function j() {
        j = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c) {
            a = d("WAPushSafeTypes").unsafeNotNullable(c);
            c = a.groupJid;
            var e = a.userJids;
            if (!d("WAGlobals").getConfig().isPreEstablishSessionEnabled()) return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult());
            if (i.has(c)) return (h || (h = b("Promise"))).resolve(d("WAResultOrError").makeResult());
            yield d("WAGlobals").getWaOneQueue().enqueue(function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    var b = (yield a.cryptoManager.storage.bulkLoadIdentities(e));
                    b = Array.from(b).flatMap(function(a) {
                        a = a[1];
                        return Array.from(a.keys())
                    });
                    return d("WACryptoManagerUtils").bulkPreEstablishOutgoingSession(b, a)
                });
                return function(b) {
                    return a.apply(this, arguments)
                }
            }(), {
                flush: !0,
                afterInit: !0,
                operationType: "pre_establish_session"
            });
            i.add(c);
            return d("WAResultOrError").makeResult()
        });
        return j.apply(this, arguments)
    }
    g.preEstablishSession = a
}), 98);
__d("WAWaterFlow", ["$InternalEnum", "WAMapWithDefault", "WAPREMetrics", "WATagsLogger", "WATimeUtils", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose([" -> Done. Success: false\nTime taken: ", " sec;", "", "\n"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose([" -> Done. Success: true\nTime taken: ", " sec;", "", "\n"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose([" -> in progress.\nTime passed: ", " sec;", "", "\n"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Step should be a enum type"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " -> Done.;\nTime taken: ", ";\nTime from start: ", ";", "", "\n"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Step should be a enum type"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["No start point was found for step: ", "."]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["", " -> Start.", "", ""]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Step should be a enum type"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose([" -> Start.", ""]);
        q = function() {
            return a
        };
        return a
    }
    var r = d("WATagsLogger").TAGS(["WAWaterflow"]),
        s = b("$InternalEnum").Mirrored(["INIT", "ON_GOING", "COMPLETED"]),
        t = function() {
            function a(a, b, c) {
                this.$1 = s.INIT, this.$7 = [], this.$9 = new(d("WAMapWithDefault").MapWithDefault)(function() {
                    return []
                }), this.$5 = r.TAGS([a]), this.$8 = b, this.$3 = {}, this.$4 = new Set(), this.$10 = !c, this.$6 = d("WATimeUtils").performanceAbsoluteNow()
            }
            var b = a.prototype;
            b.$11 = function() {
                var a = this,
                    b = {
                        "int": {},
                        bool: {},
                        string: {},
                        string_array: {}
                    };
                this.$4.forEach(function(c) {
                    var d = a.$3[c];
                    Array.isArray(d) && (b.string_array[c] = d);
                    typeof d === "boolean" && (b.bool[c] = d);
                    typeof d === "number" && (b["int"][c] = d);
                    typeof d === "string" && (b.string[c] = d)
                });
                return b
            };
            b.$12 = function(a) {
                if (a == null) return;
                for (var b in a) {
                    var c = a[b];
                    c !== this.$3[b] && (this.$4.add(b), this.$3[b] = c)
                }
            };
            b.$13 = function(a, b) {
                this.$6 = d("WATimeUtils").performanceAbsoluteNow();
                this.$12(a);
                a = this.$11();
                this.$4.clear();
                this.$10 && this.$5.LOG(q(), u(this.$3));
                this.$1 = s.ON_GOING;
                if (this.$8 == null) return this;
                this.$2 = d("WAPREMetrics").startMetric(this.$8, a, b);
                return this
            };
            b.startMetric = function(a) {
                return this.$13(a)
            };
            b.reStartMetric = function(a, b) {
                return this.$13(b, a)
            };
            b.startPoint = function(a, b) {
                var e;
                if (typeof a !== "string") {
                    this.$5.ERROR(p());
                    throw c("err")("Step should be a enum type")
                }
                this.$12(b);
                b = this.$11();
                (e = this.$2) == null ? void 0 : e.addPoint(a + "_start", b);
                this.$4.clear();
                e = {
                    step: a,
                    from: d("WATimeUtils").performanceAbsoluteNow()
                };
                this.$7.push(e);
                this.$9.get(a).push(e);
                this.$10 && this.$5.LOG(o(), a, v(this.$7, this.$6), u(this.$3))
            };
            b.endPoint = function(a, b) {
                var e, f = d("WATimeUtils").performanceAbsoluteNow(),
                    g = this.$9.get(a).pop();
                g == null ? this.$5.WARN(n(), a) : g.to = f;
                if (typeof a !== "string") {
                    this.$5.ERROR(m());
                    throw c("err")("Step should be a enum type")
                }
                this.$12(b);
                b = this.$11();
                (e = this.$2) == null ? void 0 : e.addPoint(a + "_end", b);
                this.$4.clear();
                this.$10 && this.$5.LOG(l(), a, w(g != null ? f - g.from : 0), w(f - this.$6), v(this.$7, this.$6), u(this.$3))
            };
            b.isOnGoing = function() {
                return this.$1 === s.ON_GOING
            };
            b.isCompleted = function() {
                return this.$1 === s.COMPLETED
            };
            b.annotate = function(a) {
                this.$12(a)
            };
            b.reAnnotate = function(a) {
                this.$12(a(this.$3))
            };
            b.getAnnotations = function() {
                return this.$3
            };
            b.annotateImmediately = function(a) {
                var b;
                this.$12(a);
                a = this.$11();
                (b = this.$2) == null ? void 0 : b.addAnnotations(a);
                this.$4.clear()
            };
            b.addPoint = function(a, b) {
                var d;
                if (typeof a !== "string") {
                    this.$5.ERROR(k());
                    throw c("err")("Step should be a enum type")
                }
                this.$12(b);
                b = this.$11();
                (d = this.$2) == null ? void 0 : d.addPoint(a, b);
                this.$4.clear()
            };
            b.getStartTime = function() {
                return this.$6
            };
            b.log = function() {
                this.$10 && this.$5.LOG(j(), (d("WATimeUtils").performanceAbsoluteNow() - this.$6) / 1e3, v(this.$7, this.$6), u(this.$3))
            };
            b.endSuccess = function(a) {
                var b;
                this.$12(a);
                a = this.$11();
                (b = this.$2) == null ? void 0 : b.endSuccess(a);
                this.$4.clear();
                this.$10 && this.$5.LOG(i(), (d("WATimeUtils").performanceAbsoluteNow() - this.$6) / 1e3, v(this.$7, this.$6), u(this.$3));
                this.$1 = s.COMPLETED
            };
            b.endFail = function(a, b) {
                var c;
                this.$12(b);
                b = this.$11();
                (c = this.$2) == null ? void 0 : c.endFail(a, b);
                this.$4.clear();
                this.$10 && this.$5.LOG(h(), (d("WATimeUtils").performanceAbsoluteNow() - this.$6) / 1e3, v(this.$7, this.$6), u(this.$3));
                this.$1 = s.COMPLETED
            };
            return a
        }();

    function a(a) {
        if (a == null) return {};
        var b = {
            bool: {},
            "int": {},
            string: {},
            string_array: {}
        };
        for (var c in a) Array.isArray(a[c]) && (b.string_array[c] = a[c]), typeof a[c] === "number" && (b["int"][c] = a[c]), typeof a[c] === "boolean" && (b.bool[c] = a[c]), typeof a[c] === "string" && (b.string[c] = a[c]);
        return b
    }

    function u(a) {
        a = Object.entries(a).map(function(a) {
            var b = a[0];
            a = a[1];
            return b + ": " + String(a)
        });
        return a.length > 0 ? "\n" + a.join("\n") : ""
    }

    function v(a, b) {
        a = a.map(function(a) {
            var c = a.step,
                e = a.from;
            a = a.to;
            return typeof c === "string" ? c + " => Started after: " + w(e - b) + "; " + (a != null ? "Completed after: " + w(a - e) : "In progress: " + w(d("WATimeUtils").performanceAbsoluteNow() - e)) : ""
        }).filter(Boolean);
        return a.length > 0 ? "\n" + a.join("\n") : ""
    }

    function w(a) {
        return a / 1e3 + "s"
    }

    function e(a, b, c) {
        return new t(a, b, (a = c) != null ? a : !1)
    }
    g.WAWaterflow = t;
    g.convertToPREAnnotation = a;
    g.makeWaterflow = e
}), 98);
__d("WAQueryGroup", ["$InternalEnum", "WADeprecatedSendIq", "WADeprecatedWapParser", "WAGroupParserUtils", "WAPREList", "WAPREMetrics", "WAResultOrError", "WAWap", "WAWaterFlow", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new(c("WADeprecatedWapParser"))("queryAllGroupsResponse", function(a) {
        a.assertTag("iq");
        return {
            groups: a.child("groups").mapChildren(d("WAGroupParserUtils").parseGroupNode)
        }
    });

    function a() {
        var a, c, e;
        return b("regeneratorRuntime").async(function(f) {
            while (1) switch (f.prev = f.next) {
                case 0:
                    a = d("WAPREMetrics").startMetric(d("WAPREList").PRE_METRIC.QUERY_GROUPS);
                    c = d("WAWap").wap("iq", {
                        id: d("WAWap").generateId(),
                        to: d("WAWap").G_US,
                        type: "get",
                        xmlns: "w:g2"
                    }, d("WAWap").wap("participating", null, d("WAWap").wap("participants", null), d("WAWap").wap("description", null)));
                    f.next = 4;
                    return b("regeneratorRuntime").awrap(d("WADeprecatedSendIq").deprecatedSendIq(c, h));
                case 4:
                    e = f.sent;
                    if (e.success) {
                        f.next = 8;
                        break
                    }
                    a.endFail("query_groups_fail");
                    return f.abrupt("return", d("WAResultOrError").makeError(e));
                case 8:
                    a.endSuccess();
                    return f.abrupt("return", d("WAResultOrError").makeResult(e.result));
                case 10:
                case "end":
                    return f.stop()
            }
        }, null, this)
    }
    var i = new(c("WADeprecatedWapParser"))("queryAllGroupsResponse", function(a) {
            a.assertTag("iq");
            return {
                group: d("WAGroupParserUtils").parseGroupNode(a.child("group"))
            }
        }),
        j = b("$InternalEnum").Mirrored(["IQ_REQUEST"]);

    function e(a, c) {
        var e, f, g, h;
        return b("regeneratorRuntime").async(function(k) {
            while (1) switch (k.prev = k.next) {
                case 0:
                    f = (e = c) != null ? e : "unknown";
                    g = d("WAWaterFlow").makeWaterflow("query-group", d("WAPREList").PRE_METRIC.QUERY_GROUP).startMetric();
                    g.addPoint(j.IQ_REQUEST, {
                        key: f
                    });
                    k.next = 5;
                    return b("regeneratorRuntime").awrap(d("WADeprecatedSendIq").deprecatedSendIq(d("WAWap").wap("iq", {
                        id: d("WAWap").generateId(),
                        to: d("WAWap").GROUP_JID(a),
                        type: "get",
                        xmlns: "w:g2"
                    }, d("WAWap").wap("query", {
                        request: c != null ? d("WAWap").CUSTOM_STRING(c) : d("WAWap").DROP_ATTR
                    })), i));
                case 5:
                    h = k.sent;
                    if (h.success) {
                        k.next = 9;
                        break
                    }
                    g.endFail("Fail-" + f + "-" + h.errorCode);
                    return k.abrupt("return", d("WAResultOrError").makeError(h));
                case 9:
                    g.endSuccess();
                    return k.abrupt("return", d("WAResultOrError").makeResult(h.result.group));
                case 11:
                case "end":
                    return k.stop()
            }
        }, null, this)
    }
    g.queryAllGroups = a;
    g.parseQueryGroupResponse = i;
    g.queryGroup = e
}), 98);
__d("WAQueryGroups", ["Promise", "WACreateGroup", "WAGetDevices", "WAPushSafeTypes", "WAQueryGroup", "WATimeUtils", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, e) {
            e = d("WAPushSafeTypes").unsafeNotNullable(e);
            var f = {
                groups: []
            };
            if (e.type === "all") {
                var g = (yield d("WAQueryGroup").queryAllGroups());
                if (g.success === !1) {
                    var i;
                    throw c("err")("Failed to parse queryAllGroup response with error " + JSON.stringify((i = g.error) != null ? i : null))
                }
                f = g.value
            } else {
                e.type;
                i = (yield(h || (h = b("Promise"))).all(e.groups.map(function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                        a = (yield d("WAQueryGroup").queryGroup(a));
                        if (a.success === !1) {
                            var b;
                            throw c("err")("Failed to parse queryGroup response with error " + JSON.stringify((b = a.error) != null ? b : null))
                        }
                        return a.value
                    });
                    return function(b) {
                        return a.apply(this, arguments)
                    }
                }())));
                f = {
                    groups: i
                }
            }
            yield d("WACreateGroup").createGroups(f.groups.map(function(a) {
                return {
                    groupStatus: "queried",
                    groupToCreate: a,
                    serverTs: d("WATimeUtils").unixTime(),
                    extras: void 0,
                    folder: void 0,
                    key: void 0
                }
            }));
            var j = new Set();
            f.groups.forEach(function(a) {
                return a.participants.forEach(function(a) {
                    a.success ? j.add(a.value.user) : j.add(a.error.user)
                })
            });
            yield d("WAGetDevices").getDevices(a, {
                users: j,
                reason: "query-groups",
                ignoreDhash: !1
            })
        });
        return i.apply(this, arguments)
    }
    g.queryGroups = a
}), 98);
__d("WASmaxInDevicesIQErrorBadRequestOrItemNotFoundMixinGroup", ["WAResultOrError", "WASmaxInDevicesIQErrorBadRequestMixin", "WASmaxInDevicesIQErrorItemNotFoundMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInDevicesIQErrorBadRequestMixin").parseIQErrorBadRequestMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "IQErrorBadRequest",
            value: b.value
        });
        var c = d("WASmaxInDevicesIQErrorItemNotFoundMixin").parseIQErrorItemNotFoundMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "IQErrorItemNotFound",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["IQErrorBadRequest", "IQErrorItemNotFound"], [b, c])
    }
    g.parseIQErrorBadRequestOrItemNotFoundMixinGroup = a
}), 98);
__d("WASmaxInDevicesNonRetryableRemoveDeviceIQErrorMixin", ["WAResultOrError", "WASmaxInDevicesIQErrorBadRequestOrItemNotFoundMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "error");
        if (!b.success) return b;
        b = d("WASmaxInDevicesIQErrorBadRequestOrItemNotFoundMixinGroup").parseIQErrorBadRequestOrItemNotFoundMixinGroup(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            iQErrorBadRequestOrItemNotFoundMixinGroup: b.value
        })
    }
    g.parseNonRetryableRemoveDeviceIQErrorMixin = a
}), 98);
__d("WASmaxInDevicesRetryableOrNonRetryableRemoveDeviceIQErrorMixinGroup", ["WAResultOrError", "WASmaxInDevicesNonRetryableRemoveDeviceIQErrorMixin", "WASmaxInDevicesRetryableIQErrorMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxInDevicesRetryableIQErrorMixin").parseRetryableIQErrorMixin(a);
        if (b.success) return d("WAResultOrError").makeResult({
            name: "RetryableIQError",
            value: b.value
        });
        var c = d("WASmaxInDevicesNonRetryableRemoveDeviceIQErrorMixin").parseNonRetryableRemoveDeviceIQErrorMixin(a);
        return c.success ? d("WAResultOrError").makeResult({
            name: "NonRetryableRemoveDeviceIQError",
            value: c.value
        }) : d("WASmaxParseUtils").errorMixinDisjunction(a, ["RetryableIQError", "NonRetryableRemoveDeviceIQError"], [b, c])
    }
    g.parseRetryableOrNonRetryableRemoveDeviceIQErrorMixinGroup = a
}), 98);
__d("WASmaxInDevicesRemoveResponseError", ["WAResultOrError", "WASmaxInDevicesIQErrorResponseMixin", "WASmaxInDevicesRetryableOrNonRetryableRemoveDeviceIQErrorMixinGroup", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").flattenedChildWithTag(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInDevicesIQErrorResponseMixin").parseIQErrorResponseMixin(a, b);
        if (!a.success) return a;
        b = d("WASmaxInDevicesRetryableOrNonRetryableRemoveDeviceIQErrorMixinGroup").parseRetryableOrNonRetryableRemoveDeviceIQErrorMixinGroup(c.value);
        return !b.success ? b : d("WAResultOrError").makeResult(babelHelpers["extends"]({}, a.value, {
            errorRetryableOrNonRetryableRemoveDeviceIQErrorMixinGroup: b.value
        }))
    }
    g.parseRemoveResponseError = a
}), 98);
__d("WASmaxInDevicesRemoveResponseSuccess", ["WASmaxInDevicesIQResultResponseMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "iq");
        if (!c.success) return c;
        c = d("WASmaxInDevicesIQResultResponseMixin").parseIQResultResponseMixin(a, b);
        return !c.success ? c : c
    }
    g.parseRemoveResponseSuccess = a
}), 98);
__d("WASmaxOutDevicesKeyDataMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.anyElementValue;
        a = d("WASmaxJsx").smax("smax$any", null, a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeKeyDataMixin = a
}), 98);
__d("WASmaxOutDevicesIdentityKeyMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutDevicesKeyDataMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxOutDevicesKeyDataMixin").mergeKeyDataMixin(d("WASmaxJsx").smax("identity", null), a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIdentityKeyMixin = a
}), 98);
__d("WASmaxOutDevicesRemoveRequest", ["WASmaxJsx", "WASmaxOutDevicesBaseIQSetRequestMixin", "WASmaxOutDevicesIdentityKeyMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = a.removeId;
        a = a.identityKeyMixinArgs;
        b = d("WASmaxOutDevicesBaseIQSetRequestMixin").mergeBaseIQSetRequestMixin(d("WASmaxJsx").smax("iq", {
            to: d("WAWap").S_WHATSAPP_NET,
            xmlns: "fbid:devices"
        }, d("WASmaxOutDevicesIdentityKeyMixin").mergeIdentityKeyMixin(d("WASmaxJsx").smax("remove", {
            id: d("WAWap").INT(b)
        }), a)));
        return b
    }
    g.makeRemoveRequest = a
}), 98);
__d("WASmaxDevicesRemoveRPC", ["WAComms", "WASmaxInDevicesRemoveResponseError", "WASmaxInDevicesRemoveResponseSuccess", "WASmaxOutDevicesRemoveRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h;
        return b("regeneratorRuntime").async(function(i) {
            while (1) switch (i.prev = i.next) {
                case 0:
                    e = d("WASmaxOutDevicesRemoveRequest").makeRemoveRequest(a);
                    i.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = i.sent;
                    g = d("WASmaxInDevicesRemoveResponseSuccess").parseRemoveResponseSuccess(f, e);
                    if (!g.success) {
                        i.next = 7;
                        break
                    }
                    return i.abrupt("return", {
                        name: "RemoveResponseSuccess",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInDevicesRemoveResponseError").parseRemoveResponseError(f, e);
                    if (!h.success) {
                        i.next = 10;
                        break
                    }
                    return i.abrupt("return", {
                        name: "RemoveResponseError",
                        value: h.value
                    });
                case 10:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("Remove", {
                        Success: g,
                        Error: h
                    }));
                case 11:
                case "end":
                    return i.stop()
            }
        }, null, this)
    }
    g.sendRemoveRPC = a
}), 98);
__d("WARemoveDevice", ["WALogger", "WAPersistedJobManager", "WAPushSafeTypes", "WAResultOrError", "WASignalOther", "WASmaxDevicesRemoveRPC", "WATimeUtils", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["removeDevice result for ", ": ", " "]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["removeDevice called for device ", " and identity ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return j.apply(this, arguments)
    }

    function j() {
        j = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            a = d("WAPushSafeTypes").unsafeNotNullable(b);
            b = a.deviceId;
            a = a.identity;
            d("WALogger").DEV(i(), b, a);
            a = d("WASignalOther").sliceBytes(a, 1, 32);
            a = (yield d("WASmaxDevicesRemoveRPC").sendRemoveRPC({
                removeId: b,
                identityKeyMixinArgs: {
                    anyElementValue: a
                }
            }));
            d("WALogger").LOG(h(), b, a);
            if (a.name === "RemoveResponseSuccess") return d("WAResultOrError").makeResult();
            else {
                a.name;
                b = a.value.errorRetryableOrNonRetryableRemoveDeviceIQErrorMixinGroup;
                if (b.name !== "RetryableIQError") return d("WAResultOrError").makeError();
                b.name;
                a = b.value.backoff;
                if (a != null) throw new(d("WAPersistedJobManager").RetryOnBackoff)({
                    algo: {
                        type: "constant",
                        delay: a
                    },
                    jitter: 0
                });
                else throw new(d("WAPersistedJobManager").RetryOnBackoff)({
                    algo: {
                        type: "exponential",
                        first: d("WATimeUtils").HOUR_MILLISECONDS / 60
                    },
                    jitter: .1
                })
            }
        });
        return j.apply(this, arguments)
    }
    g.removeDevice = a
}), 98);
__d("WARemoveCurrentDevice", ["WAGetCurrentUserDeviceInfoApi", "WAGlobals", "WALogger", "WARemoveDevice", "WAResultOrError", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["There is no stored user info, it was already deleted or this job was called twice, possibly from another tab"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["removeCurrentDevice called for current device"]);
        i = function() {
            return a
        };
        return a
    }
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            d("WALogger").DEV(i());
            var b = (yield d("WAGetCurrentUserDeviceInfoApi").getCurrentUserDeviceInfo());
            if (b == null) {
                d("WALogger").WARN(h());
                return d("WAResultOrError").makeResult()
            }
            var c = b.deviceId;
            b = b.identityKey;
            a = (yield d("WARemoveDevice").removeDevice(a, {
                deviceId: c,
                identity: b
            }));
            if (a.success) {
                yield d("WAGlobals").getDependencies().clearSignalAndTempStores();
                return d("WAResultOrError").makeResult()
            }
            return d("WAResultOrError").makeResult()
        });
        return function(b) {
            return a.apply(this, arguments)
        }
    }();
    g.removeCurrentDevice = a
}), 98);
__d("WASaveReceiptApi", ["MAWTransactionMode", "WADbTransactor", "WAMsg"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        receipts: d("MAWTransactionMode").READWRITE
    }, "saveReceipt", function(a) {
        return function(b) {
            return a.receipts.put({
                msgId: b.id.externalId.toString(),
                permittedIdentitiesPerDevice: b.permittedIdentitiesPerDevice,
                recipientDevices: b.recipientDevices,
                waMsgId: d("WAMsg").craftWAMsgIdString(b.id)
            }).then(function() {})
        }
    });
    g.saveReceipt = a
}), 98);
__d("WASmaxInAppdataPublishAckMixin", ["WAResultOrError", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "class", "appdata");
        if (!c.success) return c;
        b = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", b.value);
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "t", 0, void 0);
        return !b.success ? b : d("WAResultOrError").makeResult({
            "class": c.value,
            t: b.value
        })
    }
    g.parseAckMixin = a
}), 98);
__d("WASmaxInAppdataPublishPeerResponseNegative", ["WAResultOrError", "WASmaxInAppdataPublishAckMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").attrString(a, "error");
        if (!c.success) return c;
        a = d("WASmaxInAppdataPublishAckMixin").parseAckMixin(a, b);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            error: c.value
        }, a.value))
    }
    g.parsePeerResponseNegative = a
}), 98);
__d("WASmaxInAppdataPublishDeviceListStaleMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrString(a, "phash");
        return !b.success ? b : d("WAResultOrError").makeResult({
            phash: b.value
        })
    }
    g.parseDeviceListStaleMixin = a
}), 98);
__d("WASmaxInAppdataPublishPeerResponseSuccess", ["WAResultOrError", "WASmaxInAppdataPublishAckMixin", "WASmaxInAppdataPublishDeviceListStaleMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!c.success) return c;
        c = d("WASmaxInAppdataPublishAckMixin").parseAckMixin(a, b);
        if (!c.success) return c;
        b = d("WASmaxInAppdataPublishDeviceListStaleMixin").parseDeviceListStaleMixin(a);
        return d("WAResultOrError").makeResult(babelHelpers["extends"]({}, c.value, {
            deviceListStaleMixin: b.success ? b.value : null
        }))
    }
    g.parsePeerResponseSuccess = a
}), 98);
__d("WASmaxOutAppdataPublishDeviceIdentityMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.deviceIdentityElementValue;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("device-identity", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeDeviceIdentityMixin = a
}), 98);
__d("WASmaxOutAppdataPublishInternalTestMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.testConfig;
        a = d("WASmaxJsx").smax("appdata", null, d("WASmaxJsx").smax("test", {
            config: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeInternalTestMixin = a
}), 98);
__d("WASmaxOutAppdataPublishRequestIDMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.requestIdElementValue;
        a = d("WASmaxJsx").smax("trace", null, d("WASmaxJsx").smax("request_id", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeRequestIDMixin = a
}), 98);
__d("WASmaxOutAppdataPublishTraceIDMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.edgeIdElementValue;
        a = d("WASmaxJsx").smax("edge_id", null, a);
        return a
    }

    function i(a) {
        var b = a.edgeIdArgs;
        a = a.traceIdElementValue;
        a = d("WASmaxJsx").smax("trace", null, d("WASmaxJsx").smax("trace_id", null, a), d("WASmaxChildren").OPTIONAL_CHILD(h, b));
        return a
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeTraceIDEdgeId = h;
    g.mergeTraceIDMixin = a
}), 98);
__d("WASmaxOutAppdataPublishRequestOrTraceIDMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutAppdataPublishRequestIDMixin", "WASmaxOutAppdataPublishTraceIDMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.requestID) return d("WASmaxOutAppdataPublishRequestIDMixin").mergeRequestIDMixin(a, b.requestID);
        if (b.traceID) return d("WASmaxOutAppdataPublishTraceIDMixin").mergeTraceIDMixin(a, b.traceID);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeRequestOrTraceIDMixinGroup = a
}), 98);
__d("WASmaxOutAppdataPublishTraceContextMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutAppdataPublishRequestOrTraceIDMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.requestOrTraceIDMixinGroupArgs;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxOutAppdataPublishRequestOrTraceIDMixinGroup").mergeRequestOrTraceIDMixinGroup(d("WASmaxJsx").smax("trace", null), a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeTraceContextMixin = a
}), 98);
__d("WASmaxOutAppdataPublishWithDeviceListCheckMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.appdataDeviceListCheck;
        a = d("WASmaxJsx").smax("appdata", {
            device_list_check: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeWithDeviceListCheckMixin = a
}), 98);
__d("WASmaxOutAppdataPublishBaseMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutAppdataPublishDeviceIdentityMixin", "WASmaxOutAppdataPublishInternalTestMixin", "WASmaxOutAppdataPublishTraceContextMixin", "WASmaxOutAppdataPublishWithDeviceListCheckMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.deviceIdentityMixinArgs,
            e = a.withDeviceListCheckMixinArgs,
            f = a.internalTestMixinArgs;
        a = a.traceContextMixinArgs;
        b = (b = d("WASmaxMixins")).optionalMerge(d("WASmaxOutAppdataPublishTraceContextMixin").mergeTraceContextMixin, b.optionalMerge(d("WASmaxOutAppdataPublishInternalTestMixin").mergeInternalTestMixin, b.optionalMerge(d("WASmaxOutAppdataPublishWithDeviceListCheckMixin").mergeWithDeviceListCheckMixin, b.optionalMerge(d("WASmaxOutAppdataPublishDeviceIdentityMixin").mergeDeviceIdentityMixin, d("WASmaxJsx").smax("appdata", null), c), e), f), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBaseMixin = a
}), 98);
__d("WASmaxOutAppdataPublishEncPayloadMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encElementValue;
        a = d("WASmaxJsx").smax("enc", null, a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncPayloadMixin = a
}), 98);
__d("WASmaxOutAppdataPublishEncTypeIndividualMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutAppdataPublishEncPayloadMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.encType;
        b = d("WASmaxOutAppdataPublishEncPayloadMixin").mergeEncPayloadMixin(d("WASmaxJsx").smax("enc", {
            type: d("WAWap").CUSTOM_STRING(b)
        }), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncTypeIndividualMixin = a
}), 98);
__d("WASmaxOutAppdataPublishEncVersionFutureproofMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encV;
        a = d("WASmaxJsx").smax("enc", {
            v: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncVersionFutureproofMixin = a
}), 98);
__d("WASmaxOutAppdataPublishPeerPeerFanoutMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutAppdataPublishEncTypeIndividualMixin", "WASmaxOutAppdataPublishEncVersionFutureproofMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.toJid,
            c = a.encVersionFutureproofMixinArgs;
        a = a.encTypeIndividualMixinArgs;
        b = d("WASmaxJsx").smax("to", {
            jid: d("WAWap").DEVICE_JID(b)
        }, d("WASmaxOutAppdataPublishEncTypeIndividualMixin").mergeEncTypeIndividualMixin(d("WASmaxOutAppdataPublishEncVersionFutureproofMixin").mergeEncVersionFutureproofMixin(d("WASmaxJsx").smax("enc", null), c), a));
        return b
    }

    function i(a) {
        var b = a.toArgs;
        a = a.appdataTo;
        a = d("WASmaxJsx").smax("appdata", {
            to: d("WAWap").USER_JID(a)
        }, d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").REPEATED_CHILD(h, b, 1, 24)));
        return a
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makePeerPeerFanoutParticipantsTo = h;
    g.mergePeerPeerFanoutMixin = a
}), 98);
__d("WASmaxOutAppdataPublishEncRetryMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encCount;
        a = d("WASmaxJsx").smax("enc", {
            count: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncRetryMixin = a
}), 98);
__d("WASmaxOutAppdataPublishRetryMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutAppdataPublishEncRetryMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.appdataT;
        a = a.encRetryMixinArgs;
        b = d("WASmaxJsx").smax("appdata", {
            t: d("WAWap").INT(b)
        }, d("WASmaxOutAppdataPublishEncRetryMixin").mergeEncRetryMixin(d("WASmaxJsx").smax("enc", null), a));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeRetryMixin = a
}), 98);
__d("WASmaxOutAppdataPublishPeerPeerSingleMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutAppdataPublishEncTypeIndividualMixin", "WASmaxOutAppdataPublishEncVersionFutureproofMixin", "WASmaxOutAppdataPublishRetryMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.appdataTo,
            c = a.retryMixinArgs,
            e = a.encVersionFutureproofMixinArgs;
        a = a.encTypeIndividualMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutAppdataPublishRetryMixin").mergeRetryMixin, d("WASmaxJsx").smax("appdata", {
            to: d("WAWap").DEVICE_JID(b)
        }, d("WASmaxOutAppdataPublishEncTypeIndividualMixin").mergeEncTypeIndividualMixin(d("WASmaxOutAppdataPublishEncVersionFutureproofMixin").mergeEncVersionFutureproofMixin(d("WASmaxJsx").smax("enc", null), e), a)), c);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePeerPeerSingleMixin = a
}), 98);
__d("WASmaxOutAppdataPublishPeerPeerFanoutOrPeerSingleMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutAppdataPublishPeerPeerFanoutMixin", "WASmaxOutAppdataPublishPeerPeerSingleMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.peerPeerFanout) return d("WASmaxOutAppdataPublishPeerPeerFanoutMixin").mergePeerPeerFanoutMixin(a, b.peerPeerFanout);
        if (b.peerPeerSingle) return d("WASmaxOutAppdataPublishPeerPeerSingleMixin").mergePeerPeerSingleMixin(a, b.peerPeerSingle);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergePeerPeerFanoutOrPeerSingleMixinGroup = a
}), 98);
__d("WASmaxOutAppdataPublishPeerRequest", ["WASmaxAttrs", "WASmaxJsx", "WASmaxOutAppdataPublishBaseMixin", "WASmaxOutAppdataPublishPeerPeerFanoutOrPeerSingleMixinGroup", "WAWap"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = a.appdataId,
            c = a.appdataPushPriority,
            e = a.peerPeerFanoutOrPeerSingleMixinGroupArgs;
        b = d("WASmaxOutAppdataPublishPeerPeerFanoutOrPeerSingleMixinGroup").mergePeerPeerFanoutOrPeerSingleMixinGroup(d("WASmaxOutAppdataPublishBaseMixin").mergeBaseMixin(d("WASmaxJsx").smax("appdata", {
            id: d("WAWap").STANZA_ID(b),
            category: "peer",
            push_priority: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, c)
        }), a), e);
        return b
    }
    g.makePeerRequest = a
}), 98);
__d("WASmaxAppdataPublishPeerRPC", ["WAComms", "WASmaxInAppdataPublishPeerResponseNegative", "WASmaxInAppdataPublishPeerResponseSuccess", "WASmaxOutAppdataPublishPeerRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h;
        return b("regeneratorRuntime").async(function(i) {
            while (1) switch (i.prev = i.next) {
                case 0:
                    e = d("WASmaxOutAppdataPublishPeerRequest").makePeerRequest(a);
                    i.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = i.sent;
                    g = d("WASmaxInAppdataPublishPeerResponseNegative").parsePeerResponseNegative(f, e);
                    if (!g.success) {
                        i.next = 7;
                        break
                    }
                    return i.abrupt("return", {
                        name: "PeerResponseNegative",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInAppdataPublishPeerResponseSuccess").parsePeerResponseSuccess(f, e);
                    if (!h.success) {
                        i.next = 10;
                        break
                    }
                    return i.abrupt("return", {
                        name: "PeerResponseSuccess",
                        value: h.value
                    });
                case 10:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("Peer", {
                        Negative: g,
                        Success: h
                    }));
                case 11:
                case "end":
                    return i.stop()
            }
        }, null, this)
    }
    g.sendPeerRPC = a
}), 98);
__d("WASendAppDataFanoutProtocol", ["WAAsMessageApplication", "WABridge", "WAConvertAppData", "WAEncUserMsg", "WAErrorMessage", "WAGetCurrentUserDeviceInfoApi", "WAGlobals", "WAMsgApplication.pb", "WAOdsEnums", "WAResultOrError", "WASmaxAppdataPublishPeerRPC", "WATagsLogger", "asyncToGeneratorRuntime", "encodeProtobuf"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to send appdata. Error: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Got phash mismatch on appdata, local[", "] server[", "]"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to fetch current device public identity key"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Attempting to send an appData stanza to more than the allowed ", " devices"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Attempting to send an appData stanza to ", " devices"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Sending appdata, externalId: ", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to send appdata to devices with error: ", ""]);
        n = function() {
            return a
        };
        return a
    }
    var o = d("WATagsLogger").TAGS(["sendAppDataFanout"]),
        p = 24;

    function a(a, b) {
        a = b.contents;
        var c = b.externalId,
            e = b.permittedIdentitiesPerDevice;
        b = b.checkPhash;
        b = b === void 0 ? "checkPhash" : b;
        return q(a, c, e, b)["catch"](function(a) {
            a = d("WAErrorMessage").maybeGetMessageFromError(a);
            o.ERROR(n(), a);
            return d("WAResultOrError").makeError("runtime-error")
        })
    }

    function q(a, b, c, d) {
        return r.apply(this, arguments)
    }

    function r() {
        r = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e) {
            e === void 0 && (e = "checkPhash");
            o.LOG(m(), b);
            a = d("WAConvertAppData").convertAppData(a);
            var f = {
                    bytes: d("WAAsMessageApplication").castToMessageApplicationBytes(d("encodeProtobuf").encodeProtobuf(d("WAMsgApplication.pb").MessageApplicationSpec, a).readByteArray()),
                    version: "v3"
                },
                g = [];
            a = Array.from(c.entries()).map(function(a) {
                var b = a[0];
                a = a[1];
                return {
                    identity: a.pubKey,
                    jid: b
                }
            });
            c = p;
            a.length > c && (o.WARN(l(), a.length), o.ERROR(k(), c), a = a.slice(0, c));
            var n = [{
                devicesInfo: a,
                user: d("WAGlobals").getMyUserJid()
            }];
            c = (yield d("WAGlobals").getWaOneQueue().enqueue(function(a) {
                a = a.cryptoManager;
                return d("WAEncUserMsg").encryptUserMsg(n, {
                    messageBytes: f,
                    type: "appdata"
                }, [], {
                    cryptoManager: a
                })
            }, {
                operationType: "encrypt",
                flush: !0
            }));
            a = c.phash;
            var q = !1;
            c.participants != null && c.participants.forEach(function(a) {
                a.type === "pkmsg" && (q = !0), g.push({
                    toJid: a.to,
                    encTypeIndividualMixinArgs: {
                        encType: a.type,
                        encElementValue: a.ciphertext
                    },
                    encVersionFutureproofMixinArgs: {
                        encV: parseInt(a.v, 10)
                    }
                })
            });
            c = {
                appdataTo: d("WAGlobals").getMyUserJid(),
                toArgs: g
            };
            c = {
                peerPeerFanout: c
            };
            var r = void 0;
            if (q) {
                var s = (yield d("WAGetCurrentUserDeviceInfoApi").getCurrentUserDeviceInfo());
                s = s == null ? void 0 : s.identityKey;
                if (s == null) {
                    o.ERROR(j());
                    return d("WAResultOrError").makeError("no-public-identity")
                }
                r = {
                    deviceIdentityElementValue: s
                }
            }
            s = {
                appdataDeviceListCheck: e === "checkPhash" ? "true" : "false"
            };
            e = {
                appdataId: b,
                peerPeerFanoutOrPeerSingleMixinGroupArgs: c,
                deviceIdentityMixinArgs: r,
                withDeviceListCheckMixinArgs: s
            };
            b = (yield d("WASmaxAppdataPublishPeerRPC").sendPeerRPC(e));
            switch (b.name) {
                case "PeerResponseSuccess":
                    r = (c = b.value.deviceListStaleMixin) == null ? void 0 : c.phash;
                    if (r != null && a != null && r !== a) {
                        o.LOG(i(), a, r);
                        d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                            entity: d("WAOdsEnums").Entity.PHASH_MISMATCH,
                            key: "appdata"
                        });
                        return d("WAResultOrError").makeResult({
                            phashMismatch: !0
                        })
                    } else return d("WAResultOrError").makeResult({
                        phashMismatch: !1
                    });
                default:
                    b.name;
                    o.ERROR(h(), b.value.error);
                    return d("WAResultOrError").makeError("ack-failure")
            }
        });
        return r.apply(this, arguments)
    }
    g.MAX_APPDATA_RECIPIENTS = p;
    g.sendAppDataToDevicesProtocol = a
}), 98);
__d("WASmaxInMessagePublishAckAdminEditMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "edit", "3");
        return !b.success ? b : d("WAResultOrError").makeResult({
            edit: b.value
        })
    }
    g.parseAckAdminEditMixin = a
}), 98);
__d("WASmaxInMessagePublishAckAdminRevokeMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "edit", "8");
        return !b.success ? b : d("WAResultOrError").makeResult({
            edit: b.value
        })
    }
    g.parseAckAdminRevokeMixin = a
}), 98);
__d("WASmaxInMessagePublishAckMessageEditMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "edit", "1");
        return !b.success ? b : d("WAResultOrError").makeResult({
            edit: b.value
        })
    }
    g.parseAckMessageEditMixin = a
}), 98);
__d("WASmaxInMessagePublishAckMessagePinMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "edit", "2");
        return !b.success ? b : d("WAResultOrError").makeResult({
            edit: b.value
        })
    }
    g.parseAckMessagePinMixin = a
}), 98);
__d("WASmaxInMessagePublishEnums", [], (function(a, b, c, d, e, f) {
    a = {
        CBP: "CBP",
        NBP: "NBP",
        PMP: "PMP"
    };
    b = {
        delivery: "delivery",
        no_optimization: "no_optimization"
    };
    c = {
        "false": "false",
        "true": "true"
    };
    d = {
        free_customer_service: "free_customer_service",
        free_entry_point: "free_entry_point",
        regular: "regular"
    };
    e = {
        lid: "lid",
        pn: "pn"
    };
    f.ENUM_CBP_NBP_PMP = a;
    f.ENUM_DELIVERY_NOOPTIMIZATION = b;
    f.ENUM_FALSE_TRUE = c;
    f.ENUM_FREECUSTOMERSERVICE_FREEENTRYPOINT_REGULAR = d;
    f.ENUM_LID_PN = e
}), 66);
__d("WASmaxInMessagePublishAckPaidConversationMixin", ["WAResultOrError", "WASmaxInMessagePublishEnums", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "delivery_context");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrStringEnum(a, "optimization_goal", d("WASmaxInMessagePublishEnums").ENUM_DELIVERY_NOOPTIMIZATION);
        return !b.success ? b : d("WAResultOrError").makeResult({
            optimizationGoal: b.value
        })
    }

    function i(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "source_url");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").contentString(a);
        return !b.success ? b : d("WAResultOrError").makeResult({
            elementValue: b.value
        })
    }

    function j(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "referral");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").optionalChildWithTag(a, "source_url", i);
        if (!b.success) return b;
        a = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrString, a, "source_type");
        return !a.success ? a : d("WAResultOrError").makeResult({
            sourceType: a.value,
            sourceUrl: b.value
        })
    }

    function k(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "origin");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").optionalChildWithTag(a, "referral", j);
        if (!b.success) return b;
        a = d("WASmaxParseUtils").attrString(a, "type");
        return !a.success ? a : d("WAResultOrError").makeResult({
            type: a.value,
            referral: b.value
        })
    }

    function l(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "pricing");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrString, a, "consumer_country_code");
        if (!b.success) return b;
        var c = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, a, "conversation_status", 0, void 0);
        if (!c.success) return c;
        a = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, a, "latest_c2b_timestamp", 0, void 0);
        return !a.success ? a : d("WAResultOrError").makeResult({
            consumerCountryCode: b.value,
            conversationStatus: c.value,
            latestC2bTimestamp: a.value
        })
    }

    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").flattenedChildWithTag(a, "biz");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").optionalChildWithTag(b.value, "delivery_context", h);
        if (!a.success) return a;
        var c = d("WASmaxParseUtils").optionalChildWithTag(b.value, "origin", k);
        if (!c.success) return c;
        var e = d("WASmaxParseUtils").optionalChildWithTag(b.value, "pricing", l);
        if (!e.success) return e;
        var f = d("WASmaxParseUtils").attrString(b.value, "paid_convo_id");
        if (!f.success) return f;
        var g = d("WASmaxParseUtils").attrStringEnum(b.value, "pricing_model", d("WASmaxInMessagePublishEnums").ENUM_CBP_NBP_PMP);
        if (!g.success) return g;
        var i = d("WASmaxParseUtils").attrStringEnum(b.value, "billable", d("WASmaxInMessagePublishEnums").ENUM_FALSE_TRUE);
        if (!i.success) return i;
        var j = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrIntRange, b.value, "expiration_timestamp", 0, void 0);
        if (!j.success) return j;
        var m = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrString, b.value, "pricing_category");
        if (!m.success) return m;
        b = d("WASmaxParseUtils").optional(d("WASmaxParseUtils").attrStringEnum, b.value, "pricing_type", d("WASmaxInMessagePublishEnums").ENUM_FREECUSTOMERSERVICE_FREEENTRYPOINT_REGULAR);
        return !b.success ? b : d("WAResultOrError").makeResult({
            bizPaidConvoId: f.value,
            bizPricingModel: g.value,
            bizBillable: i.value,
            bizExpirationTimestamp: j.value,
            bizPricingCategory: m.value,
            bizPricingType: b.value,
            bizDeliveryContext: a.value,
            bizOrigin: c.value,
            bizPricing: e.value
        })
    }
    g.parseAckPaidConversationBizDeliveryContext = h;
    g.parseAckPaidConversationBizOriginReferralSourceUrl = i;
    g.parseAckPaidConversationBizOriginReferral = j;
    g.parseAckPaidConversationBizOrigin = k;
    g.parseAckPaidConversationBizPricing = l;
    g.parseAckPaidConversationMixin = a
}), 98);
__d("WASmaxInMessagePublishAckRevokeMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "edit", "7");
        return !b.success ? b : d("WAResultOrError").makeResult({
            edit: b.value
        })
    }
    g.parseAckRevokeMixin = a
}), 98);
__d("WASmaxInMessagePublishServerFrankingTagMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = d("WASmaxParseUtils").flattenedChildWithTag(a, "franking");
        if (!a.success) return a;
        a = d("WASmaxParseUtils").flattenedChildWithTag(a.value, "reporting_tag");
        if (!a.success) return a;
        a = d("WASmaxParseUtils").contentBytesRange(a.value, 9, 128);
        return !a.success ? a : d("WAResultOrError").makeResult({
            frankingReportingTagElementValue: a.value
        })
    }
    g.parseServerFrankingTagMixin = a
}), 98);
__d("WASmaxInMessagePublishAckMixin", ["WAResultOrError", "WASmaxInMessagePublishAckAdminEditMixin", "WASmaxInMessagePublishAckAdminRevokeMixin", "WASmaxInMessagePublishAckMessageEditMixin", "WASmaxInMessagePublishAckMessagePinMixin", "WASmaxInMessagePublishAckPaidConversationMixin", "WASmaxInMessagePublishAckRevokeMixin", "WASmaxInMessagePublishServerFrankingTagMixin", "WASmaxParseReference", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!c.success) return c;
        c = d("WASmaxParseReference").attrStringFromReference(b, ["to"]);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "from", c.value);
        if (!c.success) return c;
        c = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "class", "message");
        if (!c.success) return c;
        b = d("WASmaxParseReference").attrStringFromReference(b, ["id"]);
        if (!b.success) return b;
        b = d("WASmaxParseUtils").literal(d("WASmaxParseUtils").attrString, a, "id", b.value);
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "t", 0, void 0);
        if (!b.success) return b;
        var e = d("WASmaxInMessagePublishAckMessageEditMixin").parseAckMessageEditMixin(a),
            f = d("WASmaxInMessagePublishAckAdminEditMixin").parseAckAdminEditMixin(a),
            g = d("WASmaxInMessagePublishAckMessagePinMixin").parseAckMessagePinMixin(a),
            h = d("WASmaxInMessagePublishAckAdminRevokeMixin").parseAckAdminRevokeMixin(a),
            i = d("WASmaxInMessagePublishAckRevokeMixin").parseAckRevokeMixin(a),
            j = d("WASmaxInMessagePublishAckPaidConversationMixin").parseAckPaidConversationMixin(a);
        a = d("WASmaxInMessagePublishServerFrankingTagMixin").parseServerFrankingTagMixin(a);
        return d("WAResultOrError").makeResult({
            "class": c.value,
            t: b.value,
            ackMessageEditMixin: e.success ? e.value : null,
            ackAdminEditMixin: f.success ? f.value : null,
            ackMessagePinMixin: g.success ? g.value : null,
            ackAdminRevokeMixin: h.success ? h.value : null,
            ackRevokeMixin: i.success ? i.value : null,
            ackPaidConversationMixin: j.success ? j.value : null,
            serverFrankingTagMixin: a.success ? a.value : null
        })
    }
    g.parseAckMixin = a
}), 98);
__d("WASmaxInMessagePublishApplicationNegativeAckMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "application_error", 0, void 0);
        return !b.success ? b : d("WAResultOrError").makeResult({
            applicationError: b.value
        })
    }
    g.parseApplicationNegativeAckMixin = a
}), 98);
__d("WASmaxInMessagePublishMessageNackRetryAttributesMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrIntRange(a, "backoff", 0, 86400);
        return !b.success ? b : d("WAResultOrError").makeResult({
            backoff: b.value
        })
    }
    g.parseMessageNackRetryAttributesMixin = a
}), 98);
__d("WASmaxInMessagePublishNegativeAckMixin", ["WAResultOrError", "WASmaxInMessagePublishAckMixin", "WASmaxInMessagePublishApplicationNegativeAckMixin", "WASmaxInMessagePublishMessageNackRetryAttributesMixin", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").attrString(a, "error");
        if (!c.success) return c;
        b = d("WASmaxInMessagePublishAckMixin").parseAckMixin(a, b);
        if (!b.success) return b;
        var e = d("WASmaxInMessagePublishApplicationNegativeAckMixin").parseApplicationNegativeAckMixin(a);
        a = d("WASmaxInMessagePublishMessageNackRetryAttributesMixin").parseMessageNackRetryAttributesMixin(a);
        return d("WAResultOrError").makeResult(babelHelpers["extends"]({
            error: c.value
        }, b.value, {
            applicationNegativeAckMixin: e.success ? e.value : null,
            messageNackRetryAttributesMixin: a.success ? a.value : null
        }))
    }
    g.parseNegativeAckMixin = a
}), 98);
__d("WASmaxInMessagePublishIndividualResponseNegative", ["WAResultOrError", "WASmaxInMessagePublishNegativeAckMixin", "WASmaxParseJid", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").optional(d("WASmaxParseJid").attrUserJid, a, "recipient");
        if (!c.success) return c;
        a = d("WASmaxInMessagePublishNegativeAckMixin").parseNegativeAckMixin(a, b);
        return !a.success ? a : d("WAResultOrError").makeResult(babelHelpers["extends"]({
            recipient: c.value
        }, a.value))
    }
    g.parseIndividualResponseNegative = a
}), 98);
__d("WASmaxInMessagePublishAckRcatMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").flattenedChildWithTag(a, "rcat");
        if (!b.success) return b;
        a = d("WASmaxParseUtils").contentBytes(b.value);
        return !a.success ? a : d("WAResultOrError").makeResult({
            rcatElementValue: a.value
        })
    }
    g.parseAckRcatMixin = a
}), 98);
__d("WASmaxInMessagePublishDeviceListStaleMixin", ["WAResultOrError", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!b.success) return b;
        b = d("WASmaxParseUtils").attrString(a, "phash");
        return !b.success ? b : d("WAResultOrError").makeResult({
            phash: b.value
        })
    }
    g.parseDeviceListStaleMixin = a
}), 98);
__d("WASmaxInMessagePublishIndividualResponseSuccess", ["WAResultOrError", "WASmaxInMessagePublishAckMixin", "WASmaxInMessagePublishAckRcatMixin", "WASmaxInMessagePublishDeviceListStaleMixin", "WASmaxParseJid", "WASmaxParseUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var c = d("WASmaxParseUtils").assertTag(a, "ack");
        if (!c.success) return c;
        c = d("WASmaxParseUtils").optional(d("WASmaxParseJid").attrUserJid, a, "recipient");
        if (!c.success) return c;
        var e = d("WASmaxParseUtils").optional(d("WASmaxParseJid").attrUserJid, a, "participant");
        if (!e.success) return e;
        b = d("WASmaxInMessagePublishAckMixin").parseAckMixin(a, b);
        if (!b.success) return b;
        var f = d("WASmaxInMessagePublishDeviceListStaleMixin").parseDeviceListStaleMixin(a);
        a = d("WASmaxInMessagePublishAckRcatMixin").parseAckRcatMixin(a);
        return d("WAResultOrError").makeResult(babelHelpers["extends"]({
            recipient: c.value,
            participant: e.value
        }, b.value, {
            deviceListStaleMixin: f.success ? f.value : null,
            ackRcatMixin: a.success ? a.value : null
        }))
    }
    g.parseIndividualResponseSuccess = a
}), 98);
__d("WASmaxOutMessagePublishAppdataMetaAttributeMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            appdata: "default"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeAppdataMetaAttributeMixin = a
}), 98);
__d("WASmaxOutMessagePublishAutomatedMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("automated", null));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeAutomatedMixin = a
}), 98);
__d("WASmaxOutMessagePublishAuthMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.authVerificationTimestamp;
        a = a.authEnableRiskCheck;
        b = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", null, d("WASmaxJsx").smax("auth", {
            verification_timestamp: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, b),
            enable_risk_check: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        })));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeAuthMixin = a
}), 98);
__d("WASmaxOutMessagePublishBizAcceptTsMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.bizAcceptTs;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", {
            accept_ts: d("WAWap").INT(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBizAcceptTsMixin = a
}), 98);
__d("WASmaxOutMessagePublishBizAutoResponseMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.bizAutoResponse;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", {
            auto_response: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBizAutoResponseMixin = a
}), 98);
__d("WASmaxOutMessagePublishBizCampaignMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.bizCampaignId;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", {
            campaign_id: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBizCampaignMixin = a
}), 98);
__d("WASmaxOutMessagePublishBizMetadataMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c, e = a.metadataAppOwner,
            f = a.metadataCsidBm,
            g = a.metadataPaymentBm,
            h = a.metadataCustomerCategory;
        a = a.metadataDidBepRun;
        e = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", null, d("WASmaxJsx").smax("metadata", {
            app_owner: (b = d("WASmaxAttrs")).OPTIONAL((c = d("WAWap")).CUSTOM_STRING, e),
            csid_bm: b.OPTIONAL(c.CUSTOM_STRING, f),
            payment_bm: b.OPTIONAL(c.CUSTOM_STRING, g),
            customer_category: b.OPTIONAL(c.CUSTOM_STRING, h),
            did_bep_run: b.OPTIONAL(c.CUSTOM_STRING, a)
        })));
        return e
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBizMetadataMixin = a
}), 98);
__d("WASmaxOutMessagePublishBizRolesMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.bizHostStorage,
            c = a.bizActualActors;
        a = a.bizPrivacyModeTs;
        b = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", {
            host_storage: d("WAWap").INT(b),
            actual_actors: d("WAWap").INT(c),
            privacy_mode_ts: d("WAWap").INT(a)
        }));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBizRolesMixin = a
}), 98);
__d("WASmaxOutMessagePublishButtonsMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", null, d("WASmaxJsx").smax("buttons", null)));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeButtonsMixin = a
}), 98);
__d("WASmaxOutMessagePublishExtensionsMetadataMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.capabilityArgs;
        a = d("WASmaxJsx").smax("capabilities", null, d("WASmaxChildren").REPEATED_CHILD(i, a, 1, 50));
        return a
    }

    function i(a) {
        a = a.capabilityName;
        a = d("WASmaxJsx").smax("capability", {
            name: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function j(a) {
        var b = a.capabilitiesArgs,
            c = a.extensionsMetadataWellVersion,
            e = a.extensionsMetadataDataApiVersion;
        a = a.extensionsMetadataFlowMessageVersion;
        c = d("WASmaxJsx").smax("native_flow", null, d("WASmaxJsx").smax("extensions_metadata", {
            well_version: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, c),
            data_api_version: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, e),
            flow_message_version: d("WAWap").INT(a)
        }, d("WASmaxChildren").OPTIONAL_CHILD(h, b)));
        return c
    }

    function a(a, b) {
        b = j(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeExtensionsMetadataExtensionsMetadataCapabilities = h;
    g.makeExtensionsMetadataExtensionsMetadataCapabilitiesCapability = i;
    g.mergeExtensionsMetadataMixin = a
}), 98);
__d("WASmaxOutMessagePublishMixedMetadataMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.paymentsMetadataVersion;
        a = d("WASmaxJsx").smax("native_flow", null, d("WASmaxJsx").smax("mixed_metadata", null, d("WASmaxJsx").smax("payments_metadata", {
            version: d("WAWap").INT(a)
        })));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMixedMetadataMixin = a
}), 98);
__d("WASmaxOutMessagePublishNativeFlowMessageTypeMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishExtensionsMetadataMixin", "WASmaxOutMessagePublishMixedMetadataMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.nativeFlowName,
            c = a.nativeFlowV,
            e = a.extensionsMetadataMixinArgs;
        a = a.mixedMetadataMixinArgs;
        b = d("WASmaxJsx").smax("interactive", {
            type: "native_flow"
        }, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishMixedMetadataMixin").mergeMixedMetadataMixin, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishExtensionsMetadataMixin").mergeExtensionsMetadataMixin, d("WASmaxJsx").smax("native_flow", {
            name: d("WAWap").CUSTOM_STRING(b),
            v: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, c)
        }), e), a));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeNativeFlowMessageTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishInteractiveMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishNativeFlowMessageTypeMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.hasInteractiveV1;
        a = a.nativeFlowMessageTypeMixinArgs;
        b = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", null, d("WASmaxOutMessagePublishNativeFlowMessageTypeMixin").mergeNativeFlowMessageTypeMixin(d("WASmaxJsx").smax("interactive", {
            v: d("WASmaxAttrs").OPTIONAL_LITERAL("1", b)
        }), a)));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeInteractiveMixin = a
}), 98);
__d("WASmaxOutMessagePublishNativeFlowMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.bizNativeFlowName;
        a = a.bizNativeFlowVersion;
        b = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", {
            native_flow_name: d("WAWap").CUSTOM_STRING(b),
            native_flow_version: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, a)
        }));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeNativeFlowMixin = a
}), 98);
__d("WASmaxOutMessagePublishButtonsOrNativeFlowOrInteractiveMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishButtonsMixin", "WASmaxOutMessagePublishInteractiveMixin", "WASmaxOutMessagePublishNativeFlowMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isButtons) return d("WASmaxOutMessagePublishButtonsMixin").mergeButtonsMixin(a);
        if (b.nativeFlow) return d("WASmaxOutMessagePublishNativeFlowMixin").mergeNativeFlowMixin(a, b.nativeFlow);
        if (b.interactive) return d("WASmaxOutMessagePublishInteractiveMixin").mergeInteractiveMixin(a, b.interactive);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeButtonsOrNativeFlowOrInteractiveMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishConversionRecipientStatusMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.conversionRecipientStatus;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("conversion", {
            recipient_status: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeConversionRecipientStatusMixin = a
}), 98);
__d("WASmaxOutMessagePublishClickToWhatsAppAttributionMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.ctwaAttributionElementValue;
        a = d("WASmaxJsx").smax("ctwa_attribution", null, a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeClickToWhatsAppAttributionMixin = a
}), 98);
__d("WASmaxOutMessagePublishCtwaAttributionMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishClickToWhatsAppAttributionMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishClickToWhatsAppAttributionMixin").mergeClickToWhatsAppAttributionMixin(d("WASmaxJsx").smax("ctwa_attribution", null), a);
        return a
    }

    function i(a) {
        a = a.ctwaAttributionArgs;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxChildren").OPTIONAL_CHILD(h, a));
        return a
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeCtwaAttributionCtwaAttribution = h;
    g.mergeCtwaAttributionMixin = a
}), 98);
__d("WASmaxOutMessagePublishClickToWhatsAppTypeMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.sourceUrlElementValue;
        a = d("WASmaxJsx").smax("source_url", null, a);
        return a
    }

    function i(a) {
        var b, c, e = a.sourceUrlArgs,
            f = a.ctwaConversionSource,
            g = a.ctwaConversionData,
            i = a.ctwaSourceType,
            j = a.ctwaEntryPointConversionSource,
            k = a.ctwaEntryPointConversionApp;
        a = a.ctwaSignals;
        f = d("WASmaxJsx").smax("ctwa", {
            conversion_source: (b = d("WASmaxAttrs")).OPTIONAL((c = d("WAWap")).CUSTOM_STRING, f),
            conversion_data: b.OPTIONAL(c.CUSTOM_STRING, g),
            source_type: b.OPTIONAL(c.CUSTOM_STRING, i),
            entry_point_conversion_source: b.OPTIONAL(c.CUSTOM_STRING, j),
            entry_point_conversion_app: b.OPTIONAL(c.CUSTOM_STRING, k),
            signals: b.OPTIONAL(c.CUSTOM_STRING, a)
        }, d("WASmaxChildren").OPTIONAL_CHILD(h, e));
        return f
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeClickToWhatsAppTypeSourceUrl = h;
    g.mergeClickToWhatsAppTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishCtwaConversionMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishClickToWhatsAppTypeMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishClickToWhatsAppTypeMixin").mergeClickToWhatsAppTypeMixin(d("WASmaxJsx").smax("ctwa", null), a);
        return a
    }

    function i(a) {
        a = a.ctwaArgs;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxChildren").OPTIONAL_CHILD(h, a));
        return a
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeCtwaConversionCtwa = h;
    g.mergeCtwaConversionMixin = a
}), 98);
__d("WASmaxOutMessagePublishDeliveryContextMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c, e = a.deliveryContextHsmMaxBid,
            f = a.deliveryContextOptimizationGoal,
            g = a.deliveryContextTemplateId,
            h = a.deliveryContextCampaignId,
            i = a.deliveryContextSourceType,
            j = a.deliveryContextTierType,
            k = a.deliveryContextDeliveryType,
            l = a.deliveryContextClientToken,
            m = a.deliveryContextPrice,
            n = a.deliveryContextWabaId,
            o = a.deliveryContextQualityFlag;
        a = a.deliveryContextIsZeroRatedTemplate;
        e = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", null, d("WASmaxJsx").smax("delivery_context", {
            hsm_max_bid: (b = d("WASmaxAttrs")).OPTIONAL((c = d("WAWap")).INT, e),
            optimization_goal: b.OPTIONAL(c.CUSTOM_STRING, f),
            template_id: b.OPTIONAL(c.CUSTOM_STRING, g),
            campaign_id: b.OPTIONAL(c.CUSTOM_STRING, h),
            source_type: b.OPTIONAL(c.CUSTOM_STRING, i),
            tier_type: b.OPTIONAL(c.CUSTOM_STRING, j),
            delivery_type: b.OPTIONAL(c.CUSTOM_STRING, k),
            client_token: b.OPTIONAL(c.CUSTOM_STRING, l),
            price: b.OPTIONAL(c.INT, m),
            waba_id: b.OPTIONAL(c.CUSTOM_STRING, n),
            quality_flag: b.OPTIONAL(c.CUSTOM_STRING, o),
            is_zero_rated_template: b.OPTIONAL(c.CUSTOM_STRING, a)
        })));
        return e
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeDeliveryContextMixin = a
}), 98);
__d("WASmaxOutMessagePublishCapabilitiesMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.hasFeatureV1;
        a = d("WASmaxJsx").smax("feature", {
            name: "full_catalog",
            v: d("WASmaxAttrs").OPTIONAL_LITERAL("1", a)
        });
        return a
    }

    function i(a) {
        a = a.featureArgs;
        a = d("WASmaxJsx").smax("hsm", null, d("WASmaxJsx").smax("capabilities", null, d("WASmaxChildren").OPTIONAL_CHILD(h, a)));
        return a
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeCapabilitiesCapabilitiesFeature = h;
    g.mergeCapabilitiesMixin = a
}), 98);
__d("WASmaxOutMessagePublishHSMReviewMetadataMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c, e = a.anyCategory,
            f = a.anyTag,
            g = a.anyId,
            h = a.anySubTag,
            i = a.anyLibraryTemplateId;
        a = a.anyIsTemplateFromLibraryEdited;
        e = d("WASmaxJsx").smax("smax$any", {
            category: (b = d("WASmaxAttrs")).OPTIONAL((c = d("WAWap")).CUSTOM_STRING, e),
            tag: b.OPTIONAL(c.CUSTOM_STRING, f),
            id: b.OPTIONAL(c.CUSTOM_STRING, g),
            sub_tag: b.OPTIONAL(c.CUSTOM_STRING, h),
            library_template_id: b.OPTIONAL(c.CUSTOM_STRING, i),
            is_template_from_library_edited: b.OPTIONAL(c.CUSTOM_STRING, a)
        });
        return e
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeHSMReviewMetadataMixin = a
}), 98);
__d("WASmaxOutMessagePublishHsmMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishCapabilitiesMixin", "WASmaxOutMessagePublishHSMReviewMetadataMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.messageTtl,
            e = a.hasHsmV1,
            f = a.hasHsmButtons1,
            g = a.hsmObjective,
            h = a.hSMReviewMetadataMixinArgs;
        a = a.capabilitiesMixinArgs;
        c = d("WASmaxJsx").smax("message", {
            ttl: (b = d("WASmaxAttrs")).OPTIONAL(d("WAWap").INT, c)
        }, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishCapabilitiesMixin").mergeCapabilitiesMixin, d("WASmaxOutMessagePublishHSMReviewMetadataMixin").mergeHSMReviewMetadataMixin(d("WASmaxJsx").smax("hsm", {
            v: b.OPTIONAL_LITERAL("1", e),
            buttons: b.OPTIONAL_LITERAL("1", f),
            objective: b.OPTIONAL(d("WAWap").CUSTOM_STRING, g)
        }), h), a));
        return c
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeHsmMixin = a
}), 98);
__d("WASmaxOutMessagePublishBizMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishAuthMixin", "WASmaxOutMessagePublishBizAcceptTsMixin", "WASmaxOutMessagePublishBizAutoResponseMixin", "WASmaxOutMessagePublishBizCampaignMixin", "WASmaxOutMessagePublishBizMetadataMixin", "WASmaxOutMessagePublishBizRolesMixin", "WASmaxOutMessagePublishButtonsOrNativeFlowOrInteractiveMixinGroup", "WASmaxOutMessagePublishConversionRecipientStatusMixin", "WASmaxOutMessagePublishCtwaAttributionMixin", "WASmaxOutMessagePublishCtwaConversionMixin", "WASmaxOutMessagePublishDeliveryContextMixin", "WASmaxOutMessagePublishHsmMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.hsmMixinArgs,
            e = a.bizRolesMixinArgs,
            f = a.bizAutoResponseMixinArgs,
            g = a.bizAcceptTsMixinArgs,
            h = a.bizCampaignMixinArgs,
            i = a.deliveryContextMixinArgs,
            j = a.authMixinArgs,
            k = a.conversionRecipientStatusMixinArgs,
            l = a.ctwaConversionMixinArgs,
            m = a.bizMetadataMixinArgs,
            n = a.ctwaAttributionMixinArgs;
        a = a.buttonsOrNativeFlowOrInteractiveMixinGroupArgs;
        b = (b = d("WASmaxMixins")).optionalMerge(d("WASmaxOutMessagePublishButtonsOrNativeFlowOrInteractiveMixinGroup").mergeButtonsOrNativeFlowOrInteractiveMixinGroup, b.optionalMerge(d("WASmaxOutMessagePublishCtwaAttributionMixin").mergeCtwaAttributionMixin, b.optionalMerge(d("WASmaxOutMessagePublishBizMetadataMixin").mergeBizMetadataMixin, b.optionalMerge(d("WASmaxOutMessagePublishCtwaConversionMixin").mergeCtwaConversionMixin, b.optionalMerge(d("WASmaxOutMessagePublishConversionRecipientStatusMixin").mergeConversionRecipientStatusMixin, b.optionalMerge(d("WASmaxOutMessagePublishAuthMixin").mergeAuthMixin, b.optionalMerge(d("WASmaxOutMessagePublishDeliveryContextMixin").mergeDeliveryContextMixin, b.optionalMerge(d("WASmaxOutMessagePublishBizCampaignMixin").mergeBizCampaignMixin, b.optionalMerge(d("WASmaxOutMessagePublishBizAcceptTsMixin").mergeBizAcceptTsMixin, b.optionalMerge(d("WASmaxOutMessagePublishBizAutoResponseMixin").mergeBizAutoResponseMixin, b.optionalMerge(d("WASmaxOutMessagePublishBizRolesMixin").mergeBizRolesMixin, b.optionalMerge(d("WASmaxOutMessagePublishHsmMixin").mergeHsmMixin, d("WASmaxJsx").smax("message", null), c), e), f), g), h), i), j), k), l), m), n), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBizMixin = a
}), 98);
__d("WASmaxOutMessagePublishClientFrankingTagMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.frankingTagElementValue;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("franking", null, d("WASmaxJsx").smax("franking_tag", null, a)));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeClientFrankingTagMixin = a
}), 98);
__d("WASmaxOutMessagePublishClientReportingTokenMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.reportingTokenV;
        a = a.reportingTokenElementValue;
        b = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("reporting", null, d("WASmaxJsx").smax("reporting_token", {
            v: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, b)
        }, a)));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeClientReportingTokenMixin = a
}), 98);
__d("WASmaxOutMessagePublishDeviceIdentityMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.deviceIdentityElementValue;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("device-identity", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeDeviceIdentityMixin = a
}), 98);
__d("WASmaxOutMessagePublishInternalTestMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.testConfig;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("test", {
            config: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeInternalTestMixin = a
}), 98);
__d("WASmaxOutMessagePublishLIDSessionDeprecationMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.metaDeprecatedLidSession;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            deprecated_lid_session: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeLIDSessionDeprecationMixin = a
}), 98);
__d("WASmaxOutMessagePublishMetaHideDecryptionPlaceholderMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("meta", {
            "decrypt-fail": "hide"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMetaHideDecryptionPlaceholderMixin = a
}), 98);
__d("WASmaxOutMessagePublishMulticastMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("multicast", null));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMulticastMixin = a
}), 98);
__d("WASmaxOutMessagePublishNoExtraFanoutMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            device_fanout: "false"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeNoExtraFanoutMixin = a
}), 98);
__d("WASmaxOutMessagePublishAnonPaddingMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.taPadElementValue;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("ta_pad", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeAnonPaddingMixin = a
}), 98);
__d("WASmaxOutMessagePublishWireSizePaddingMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.paddingElementValue;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("padding", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeWireSizePaddingMixin = a
}), 98);
__d("WASmaxOutMessagePublishPaddingMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishAnonPaddingMixin", "WASmaxOutMessagePublishWireSizePaddingMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.anonPaddingMixinArgs;
        a = a.wireSizePaddingMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishWireSizePaddingMixin").mergeWireSizePaddingMixin, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishAnonPaddingMixin").mergeAnonPaddingMixin, d("WASmaxJsx").smax("message", null), b), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePaddingMixin = a
}), 98);
__d("WASmaxOutMessagePublishPreFilledNumberMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("url_number", null));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePreFilledNumberMixin = a
}), 98);
__d("WASmaxOutMessagePublishPreFilledTextMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("url_text", null));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePreFilledTextMixin = a
}), 98);
__d("WASmaxOutMessagePublishSenderIntentMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            sender_intent: "hosted"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeSenderIntentMixin = a
}), 98);
__d("WASmaxOutMessagePublishRequestIDMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.requestIdElementValue;
        a = d("WASmaxJsx").smax("trace", null, d("WASmaxJsx").smax("request_id", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeRequestIDMixin = a
}), 98);
__d("WASmaxOutMessagePublishTraceIDMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.edgeIdElementValue;
        a = d("WASmaxJsx").smax("edge_id", null, a);
        return a
    }

    function i(a) {
        var b = a.edgeIdArgs;
        a = a.traceIdElementValue;
        a = d("WASmaxJsx").smax("trace", null, d("WASmaxJsx").smax("trace_id", null, a), d("WASmaxChildren").OPTIONAL_CHILD(h, b));
        return a
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeTraceIDEdgeId = h;
    g.mergeTraceIDMixin = a
}), 98);
__d("WASmaxOutMessagePublishRequestOrTraceIDMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishRequestIDMixin", "WASmaxOutMessagePublishTraceIDMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.requestID) return d("WASmaxOutMessagePublishRequestIDMixin").mergeRequestIDMixin(a, b.requestID);
        if (b.traceID) return d("WASmaxOutMessagePublishTraceIDMixin").mergeTraceIDMixin(a, b.traceID);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeRequestOrTraceIDMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishTraceContextMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishRequestOrTraceIDMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.requestOrTraceIDMixinGroupArgs;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxOutMessagePublishRequestOrTraceIDMixinGroup").mergeRequestOrTraceIDMixinGroup(d("WASmaxJsx").smax("trace", null), a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeTraceContextMixin = a
}), 98);
__d("WASmaxOutMessagePublishVerifiedNameNameMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messageVerifiedName;
        a = d("WASmaxJsx").smax("message", {
            verified_name: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeVerifiedNameNameMixin = a
}), 98);
__d("WASmaxOutMessagePublishWebDriverConfigMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.metaWebdriverConfig;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            webdriver_config: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeWebDriverConfigMixin = a
}), 98);
__d("WASmaxOutMessagePublishBaseMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishAutomatedMixin", "WASmaxOutMessagePublishBizMixin", "WASmaxOutMessagePublishClientFrankingTagMixin", "WASmaxOutMessagePublishClientReportingTokenMixin", "WASmaxOutMessagePublishDeviceIdentityMixin", "WASmaxOutMessagePublishInternalTestMixin", "WASmaxOutMessagePublishLIDSessionDeprecationMixin", "WASmaxOutMessagePublishMetaHideDecryptionPlaceholderMixin", "WASmaxOutMessagePublishMulticastMixin", "WASmaxOutMessagePublishNoExtraFanoutMixin", "WASmaxOutMessagePublishPaddingMixin", "WASmaxOutMessagePublishPreFilledNumberMixin", "WASmaxOutMessagePublishPreFilledTextMixin", "WASmaxOutMessagePublishSenderIntentMixin", "WASmaxOutMessagePublishTraceContextMixin", "WASmaxOutMessagePublishVerifiedNameNameMixin", "WASmaxOutMessagePublishWebDriverConfigMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.deviceIdentityMixinArgs,
            e = a.hasNoExtraFanout,
            f = a.hasMulticast,
            g = a.hasPreFilledText,
            h = a.hasPreFilledNumber,
            i = a.hasAutomated,
            j = a.bizMixinArgs,
            k = a.verifiedNameNameMixinArgs,
            l = a.clientFrankingTagMixinArgs,
            m = a.clientReportingTokenMixinArgs,
            n = a.internalTestMixinArgs,
            o = a.hasMetaHideDecryptionPlaceholder,
            p = a.traceContextMixinArgs,
            q = a.hasSenderIntent,
            r = a.lIDSessionDeprecationMixinArgs,
            s = a.paddingMixinArgs;
        a = a.webDriverConfigMixinArgs;
        b = (b = d("WASmaxMixins")).optionalMerge(d("WASmaxOutMessagePublishWebDriverConfigMixin").mergeWebDriverConfigMixin, b.optionalMerge(d("WASmaxOutMessagePublishPaddingMixin").mergePaddingMixin, b.optionalMerge(d("WASmaxOutMessagePublishLIDSessionDeprecationMixin").mergeLIDSessionDeprecationMixin, b.optionalMerge(d("WASmaxOutMessagePublishSenderIntentMixin").mergeSenderIntentMixin, b.optionalMerge(d("WASmaxOutMessagePublishTraceContextMixin").mergeTraceContextMixin, b.optionalMerge(d("WASmaxOutMessagePublishMetaHideDecryptionPlaceholderMixin").mergeMetaHideDecryptionPlaceholderMixin, b.optionalMerge(d("WASmaxOutMessagePublishInternalTestMixin").mergeInternalTestMixin, b.optionalMerge(d("WASmaxOutMessagePublishClientReportingTokenMixin").mergeClientReportingTokenMixin, b.optionalMerge(d("WASmaxOutMessagePublishClientFrankingTagMixin").mergeClientFrankingTagMixin, b.optionalMerge(d("WASmaxOutMessagePublishVerifiedNameNameMixin").mergeVerifiedNameNameMixin, b.optionalMerge(d("WASmaxOutMessagePublishBizMixin").mergeBizMixin, b.optionalMerge(d("WASmaxOutMessagePublishAutomatedMixin").mergeAutomatedMixin, b.optionalMerge(d("WASmaxOutMessagePublishPreFilledNumberMixin").mergePreFilledNumberMixin, b.optionalMerge(d("WASmaxOutMessagePublishPreFilledTextMixin").mergePreFilledTextMixin, b.optionalMerge(d("WASmaxOutMessagePublishMulticastMixin").mergeMulticastMixin, b.optionalMerge(d("WASmaxOutMessagePublishNoExtraFanoutMixin").mergeNoExtraFanoutMixin, b.optionalMerge(d("WASmaxOutMessagePublishDeviceIdentityMixin").mergeDeviceIdentityMixin, d("WASmaxJsx").smax("message", null), c), e), f), g), h), i), j), k), l), m), n), o), p), q), r), s), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBaseMixin = a
}), 98);
__d("WASmaxOutMessagePublishGroupInviteTargetMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.metaGroupInvite;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            group_invite: d("WAWap").GROUP_JID(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeGroupInviteTargetMixin = a
}), 98);
__d("WASmaxOutMessagePublishBotFeedbackMessageTypeMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("bot", {
            type: "feedback"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBotFeedbackMessageTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncRetryMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encCount;
        a = d("WASmaxJsx").smax("enc", {
            count: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncRetryMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncPayloadMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encElementValue;
        a = d("WASmaxJsx").smax("enc", null, a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncPayloadMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncTypeIndividualMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishEncPayloadMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.encType;
        b = d("WASmaxOutMessagePublishEncPayloadMixin").mergeEncPayloadMixin(d("WASmaxJsx").smax("enc", {
            type: d("WAWap").CUSTOM_STRING(b)
        }), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncTypeIndividualMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncVersion2Mixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("enc", {
            v: "2"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncVersion2Mixin = a
}), 98);
__d("WASmaxOutMessagePublishEncVersionFutureproofMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encV;
        a = d("WASmaxJsx").smax("enc", {
            v: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncVersionFutureproofMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncVersion2OrFutureproofMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishEncVersion2Mixin", "WASmaxOutMessagePublishEncVersionFutureproofMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isEncVersion2) return d("WASmaxOutMessagePublishEncVersion2Mixin").mergeEncVersion2Mixin(a);
        if (b.encVersionFutureproof) return d("WASmaxOutMessagePublishEncVersionFutureproofMixin").mergeEncVersionFutureproofMixin(a, b.encVersionFutureproof);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeEncVersion2OrFutureproofMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishMediaTypeMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encMediatype;
        a = d("WASmaxJsx").smax("enc", {
            mediatype: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMediaTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishBotRequestMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishEncRetryMixin", "WASmaxOutMessagePublishEncTypeIndividualMixin", "WASmaxOutMessagePublishEncVersion2OrFutureproofMixinGroup", "WASmaxOutMessagePublishMediaTypeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.toJid,
            c = a.encRetryMixinArgs,
            e = a.encTypeIndividualMixinArgs,
            f = a.mediaTypeMixinArgs;
        a = a.encVersion2OrFutureproofMixinGroupArgs;
        b = d("WASmaxJsx").smax("to", {
            jid: d("WAWap").JID(b)
        }, d("WASmaxOutMessagePublishEncVersion2OrFutureproofMixinGroup").mergeEncVersion2OrFutureproofMixinGroup(d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishMediaTypeMixin").mergeMediaTypeMixin, d("WASmaxOutMessagePublishEncTypeIndividualMixin").mergeEncTypeIndividualMixin(d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishEncRetryMixin").mergeEncRetryMixin, d("WASmaxJsx").smax("enc", null), c), e), f), a));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBotRequestMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeMediaMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "media"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeMediaMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeTextMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "text"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeTextMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeTextOrMediaMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishContentTypeMediaMixin", "WASmaxOutMessagePublishContentTypeTextMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isContentTypeText) return d("WASmaxOutMessagePublishContentTypeTextMixin").mergeContentTypeTextMixin(a);
        if (b.isContentTypeMedia) return d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(a);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeContentTypeTextOrMediaMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishBotLocalAutomatedTypeMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.botLocalAutomatedType;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("bot", {
            local_automated_type: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBotLocalAutomatedTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishBotMessageTypeMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.botType;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("bot", {
            type: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBotMessageTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishBusinessBotMessageFeedbackRequestedMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.botFeedbackRequested;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("bot", {
            feedback_requested: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBusinessBotMessageFeedbackRequestedMixin = a
}), 98);
__d("WASmaxOutMessagePublishBusinessBotMessageMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.botBizBot;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("bot", {
            biz_bot: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBusinessBotMessageMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeEventMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.metaEventType;
        a = d("WASmaxJsx").smax("message", {
            type: "event"
        }, d("WASmaxJsx").smax("meta", {
            event_type: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeEventMixin = a
}), 98);
__d("WASmaxOutMessagePublishProductListMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", null, d("WASmaxJsx").smax("list", {
            type: "product_list"
        })));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeProductListMixin = a
}), 98);
__d("WASmaxOutMessagePublishSingleSelectListMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.listV;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("biz", null, d("WASmaxJsx").smax("list", {
            type: "single_select",
            v: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        })));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeSingleSelectListMixin = a
}), 98);
__d("WASmaxOutMessagePublishSingleSelectOrProductListMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishProductListMixin", "WASmaxOutMessagePublishSingleSelectListMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.singleSelectList) return d("WASmaxOutMessagePublishSingleSelectListMixin").mergeSingleSelectListMixin(a, b.singleSelectList);
        if (b.isProductList) return d("WASmaxOutMessagePublishProductListMixin").mergeProductListMixin(a);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeSingleSelectOrProductListMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeListFanoutMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaMixin", "WASmaxOutMessagePublishSingleSelectOrProductListMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("to", null, d("WASmaxJsx").smax("enc", {
            mediatype: "list"
        }));
        return a
    }

    function i(a) {
        var b = a.toCount;
        a = a.singleSelectOrProductListMixinGroupArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishSingleSelectOrProductListMixinGroup").mergeSingleSelectOrProductListMixinGroup, d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").HOMOGENEOUS_CHILD_COUNT(h, b)))), a);
        return b
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeContentTypeListFanoutParticipantsTo = h;
    g.mergeContentTypeListFanoutMixin = a
}), 98);
__d("WASmaxOutMessagePublishLiveLocationModeMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.metaLivelocMode;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            liveloc_mode: d("WAWap").CUSTOM_STRING(a)
        }));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeLiveLocationModeMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeLiveLocationFanoutDeprecatedMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaMixin", "WASmaxOutMessagePublishLiveLocationModeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encDuration;
        a = d("WASmaxJsx").smax("to", null, d("WASmaxJsx").smax("enc", {
            mediatype: "livelocation",
            duration: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, a)
        }));
        return a
    }

    function i(a) {
        var b = a.toArgs;
        a = a.liveLocationModeMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishLiveLocationModeMixin").mergeLiveLocationModeMixin, d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").HOMOGENEOUS_CHILD(h, b)))), a);
        return b
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeContentTypeLiveLocationFanoutDeprecatedParticipantsTo = h;
    g.mergeContentTypeLiveLocationFanoutDeprecatedMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeLiveLocationFanoutMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaMixin", "WASmaxOutMessagePublishLiveLocationModeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encDuration;
        a = d("WASmaxJsx").smax("to", null, d("WASmaxJsx").smax("enc", {
            mediatype: "livelocation",
            duration: d("WAWap").INT(a)
        }));
        return a
    }

    function i(a) {
        var b = a.toArgs;
        a = a.liveLocationModeMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishLiveLocationModeMixin").mergeLiveLocationModeMixin, d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").HOMOGENEOUS_CHILD(h, b)))), a);
        return b
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeContentTypeLiveLocationFanoutParticipantsTo = h;
    g.mergeContentTypeLiveLocationFanoutMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeMedianotifyMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "medianotify"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeMedianotifyMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeMediaOrMedianotifyMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishContentTypeMediaMixin", "WASmaxOutMessagePublishContentTypeMedianotifyMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isContentTypeMedia) return d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(a);
        if (b.isContentTypeMedianotify) return d("WASmaxOutMessagePublishContentTypeMedianotifyMixin").mergeContentTypeMedianotifyMixin(a);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeContentTypeMediaOrMedianotifyMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishSenderContentBindingMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.senderContentBindingElementValue;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("sender_content_binding", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeSenderContentBindingMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeMediaFanoutDeprecatedMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaOrMedianotifyMixinGroup", "WASmaxOutMessagePublishSenderContentBindingMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.encMediatype,
            c = a.hasEncStickerTypeAvatar;
        a = a.encNativeFlowName;
        b = d("WASmaxJsx").smax("to", null, d("WASmaxJsx").smax("enc", {
            mediatype: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, b),
            sticker_type: d("WASmaxAttrs").OPTIONAL_LITERAL("avatar", c),
            native_flow_name: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        }));
        return b
    }

    function i(a) {
        var b = a.toArgs,
            c = a.senderContentBindingMixinArgs;
        a = a.contentTypeMediaOrMedianotifyMixinGroupArgs;
        b = d("WASmaxOutMessagePublishContentTypeMediaOrMedianotifyMixinGroup").mergeContentTypeMediaOrMedianotifyMixinGroup(d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishSenderContentBindingMixin").mergeSenderContentBindingMixin, d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").HOMOGENEOUS_CHILD(h, b))), c), a);
        return b
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeContentTypeMediaFanoutDeprecatedParticipantsTo = h;
    g.mergeContentTypeMediaFanoutDeprecatedMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeMediaFanoutMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaOrMedianotifyMixinGroup", "WASmaxOutMessagePublishSenderContentBindingMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.encMediatype,
            c = a.hasEncStickerTypeAvatar;
        a = a.encNativeFlowName;
        b = d("WASmaxJsx").smax("to", null, d("WASmaxJsx").smax("enc", {
            mediatype: d("WAWap").CUSTOM_STRING(b),
            sticker_type: d("WASmaxAttrs").OPTIONAL_LITERAL("avatar", c),
            native_flow_name: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        }));
        return b
    }

    function i(a) {
        var b = a.toArgs,
            c = a.senderContentBindingMixinArgs;
        a = a.contentTypeMediaOrMedianotifyMixinGroupArgs;
        b = d("WASmaxOutMessagePublishContentTypeMediaOrMedianotifyMixinGroup").mergeContentTypeMediaOrMedianotifyMixinGroup(d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishSenderContentBindingMixin").mergeSenderContentBindingMixin, d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").HOMOGENEOUS_CHILD(h, b))), c), a);
        return b
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeContentTypeMediaFanoutParticipantsTo = h;
    g.mergeContentTypeMediaFanoutMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypePollCreationMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "poll"
        }, d("WASmaxJsx").smax("meta", {
            polltype: "creation"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypePollCreationMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypePollResultSnapshotMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "poll"
        }, d("WASmaxJsx").smax("meta", {
            polltype: "result_snapshot"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypePollResultSnapshotMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypePollVoteMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "poll"
        }, d("WASmaxJsx").smax("meta", {
            polltype: "vote"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypePollVoteMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeReactionMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "reaction"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeReactionMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypePayMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            type: "pay"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypePayMixin = a
}), 98);
__d("WASmaxOutMessagePublishPayNodeTypeMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.payType;
        a = d("WASmaxJsx").smax("pay", {
            type: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePayNodeTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishBasePayNodeMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishPayNodeTypeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.payCountry,
            c = a.payVersion,
            e = a.payIsFirstSend;
        b = d("WASmaxOutMessagePublishPayNodeTypeMixin").mergePayNodeTypeMixin(d("WASmaxJsx").smax("pay", {
            country: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, b),
            version: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, c),
            is_first_send: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, e)
        }), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBasePayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishLegacyAmountMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.payCurrency;
        a = a.payAmount;
        b = d("WASmaxJsx").smax("pay", {
            currency: d("WAWap").CUSTOM_STRING(b),
            amount: d("WAWap").CUSTOM_STRING(a)
        });
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeLegacyAmountMixin = a
}), 98);
__d("WASmaxOutMessagePublishMoneyMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.moneyValue,
            c = a.moneyOffset;
        a = a.moneyCurrency;
        b = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("money", {
            value: d("WAWap").CUSTOM_STRING(b),
            offset: d("WAWap").CUSTOM_STRING(c),
            currency: d("WAWap").CUSTOM_STRING(a)
        }));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMoneyMixin = a
}), 98);
__d("WASmaxOutMessagePublishBaseIndividualPublishSendPayNodeMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBasePayNodeMixin", "WASmaxOutMessagePublishLegacyAmountMixin", "WASmaxOutMessagePublishMoneyMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishMoneyMixin").mergeMoneyMixin(d("WASmaxJsx").smax("amount", null), a);
        return a
    }

    function i(a) {
        var b = a.amountArgs,
            c = a.payCredentialId,
            e = a.payDeviceId,
            f = a.payRequestId,
            g = a.legacyAmountMixinArgs;
        c = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishLegacyAmountMixin").mergeLegacyAmountMixin, d("WASmaxOutMessagePublishBasePayNodeMixin").mergeBasePayNodeMixin(d("WASmaxJsx").smax("pay", {
            "credential-id": d("WAWap").CUSTOM_STRING(c),
            "device-id": d("WAWap").CUSTOM_STRING(e),
            "request-id": d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, f)
        }, d("WASmaxChildren").OPTIONAL_CHILD(h, b)), a), g);
        return c
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeBaseIndividualPublishSendPayNodeAmount = h;
    g.mergeBaseIndividualPublishSendPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishInstallmentMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishMoneyMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishMoneyMixin").mergeMoneyMixin(d("WASmaxJsx").smax("due_amount", null), a);
        return a
    }

    function i(a) {
        a = d("WASmaxOutMessagePublishMoneyMixin").mergeMoneyMixin(d("WASmaxJsx").smax("interest", null), a);
        return a
    }

    function j(a) {
        var b = a.dueAmountArgs,
            c = a.interestArgs,
            e = a.installmentMaxCount;
        a = a.installmentSelectedCount;
        e = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("installment", {
            max_count: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, e),
            selected_count: d("WAWap").INT(a)
        }, d("WASmaxChildren").OPTIONAL_CHILD(h, b), d("WASmaxChildren").OPTIONAL_CHILD(i, c)));
        return e
    }

    function a(a, b) {
        b = j(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeInstallmentInstallmentDueAmount = h;
    g.makeInstallmentInstallmentInterest = i;
    g.mergeInstallmentMixin = a
}), 98);
__d("WASmaxOutMessagePublishBeneficiaryMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.beneficiaryName,
            e = a.beneficiaryAddressLine1,
            f = a.beneficiaryAddressLine2,
            g = a.beneficiaryCity,
            h = a.beneficiaryState,
            i = a.beneficiaryPhoneNumber,
            j = a.beneficiaryCountry;
        a = a.beneficiaryPostalCode;
        e = d("WASmaxJsx").smax("beneficiary", {
            name: (b = d("WAWap")).CUSTOM_STRING(c),
            address_line1: b.CUSTOM_STRING(e),
            address_line2: (c = d("WASmaxAttrs")).OPTIONAL(b.CUSTOM_STRING, f),
            city: c.OPTIONAL(b.CUSTOM_STRING, g),
            state: c.OPTIONAL(b.CUSTOM_STRING, h),
            phone_number: c.OPTIONAL(b.CUSTOM_STRING, i),
            country: b.CUSTOM_STRING(j),
            postal_code: b.CUSTOM_STRING(a)
        });
        return e
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBeneficiaryMixin = a
}), 98);
__d("WASmaxOutMessagePublishBeneficiariesMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBeneficiaryMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishBeneficiaryMixin").mergeBeneficiaryMixin(d("WASmaxJsx").smax("beneficiary", null), a);
        return a
    }

    function i(a) {
        a = a.beneficiaryArgs;
        a = d("WASmaxJsx").smax("smax$any", null, d("WASmaxChildren").REPEATED_CHILD(h, a, 1, 5));
        return a
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeBeneficiariesBeneficiary = h;
    g.mergeBeneficiariesMixin = a
}), 98);
__d("WASmaxOutMessagePublishOrderInPaymentMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBeneficiariesMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishBeneficiariesMixin").mergeBeneficiariesMixin(d("WASmaxJsx").smax("beneficiaries", null), a);
        return a
    }

    function i(a) {
        var b, c = a.beneficiariesArgs,
            e = a.orderId,
            f = a.orderMessageId,
            g = a.orderPaymentConfigId;
        a = a.orderType;
        e = d("WASmaxJsx").smax("smax$any", null, d("WASmaxJsx").smax("order", {
            id: (b = d("WAWap")).CUSTOM_STRING(e),
            message_id: d("WASmaxAttrs").OPTIONAL(b.STANZA_ID, f),
            payment_config_id: d("WASmaxAttrs").OPTIONAL(b.CUSTOM_STRING, g),
            type: d("WASmaxAttrs").OPTIONAL(b.CUSTOM_STRING, a)
        }, d("WASmaxChildren").OPTIONAL_CHILD(h, c)));
        return e
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeOrderInPaymentOrderBeneficiaries = h;
    g.mergeOrderInPaymentMixin = a
}), 98);
__d("WASmaxOutMessagePublishPaymentInitiatorMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.anyPaymentInitiator;
        a = d("WASmaxJsx").smax("smax$any", {
            payment_initiator: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePaymentInitiatorMixin = a
}), 98);
__d("WASmaxOutMessagePublishBRPublishSendPayNodeP2MMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishInstallmentMixin", "WASmaxOutMessagePublishOrderInPaymentMixin", "WASmaxOutMessagePublishPaymentInitiatorMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.orderInPaymentMixinArgs,
            c = a.paymentInitiatorMixinArgs;
        a = a.installmentMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishInstallmentMixin").mergeInstallmentMixin, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishPaymentInitiatorMixin").mergePaymentInitiatorMixin, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishOrderInPaymentMixin").mergeOrderInPaymentMixin, d("WASmaxJsx").smax("pay", {
            "transaction-type": "p2m"
        }), b), c), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBRPublishSendPayNodeP2MMixin = a
}), 98);
__d("WASmaxOutMessagePublishBRPublishSendPayNodeP2PMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("pay", {
            "transaction-type": "p2p"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBRPublishSendPayNodeP2PMixin = a
}), 98);
__d("WASmaxOutMessagePublishBRPublishSendPayNodeP2POrMMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishBRPublishSendPayNodeP2MMixin", "WASmaxOutMessagePublishBRPublishSendPayNodeP2PMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isBRPublishSendPayNodeP2P) return d("WASmaxOutMessagePublishBRPublishSendPayNodeP2PMixin").mergeBRPublishSendPayNodeP2PMixin(a);
        if (b.bRPublishSendPayNodeP2M) return d("WASmaxOutMessagePublishBRPublishSendPayNodeP2MMixin").mergeBRPublishSendPayNodeP2MMixin(a, b.bRPublishSendPayNodeP2M);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeBRPublishSendPayNodeP2POrMMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishBRSendPayEloNodeMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.eloDeviceSignature,
            e = a.eloWalletSignature,
            f = a.eloChallengeId;
        a = a.eloCardholderVerificationMethod;
        c = d("WASmaxJsx").smax("pay", null, d("WASmaxJsx").smax("elo", {
            device_signature: (b = d("WAWap")).CUSTOM_STRING(c),
            wallet_signature: b.CUSTOM_STRING(e),
            challenge_id: b.CUSTOM_STRING(f),
            cardholder_verification_method: b.CUSTOM_STRING(a)
        }));
        return c
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBRSendPayEloNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishBRPublishSendPayNodeMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBRPublishSendPayNodeP2POrMMixinGroup", "WASmaxOutMessagePublishBRSendPayEloNodeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.payId,
            e = a.payPaymentRails,
            f = a.payTrustedDeviceInfo,
            g = a.payNonce,
            h = a.bRSendPayEloNodeMixinArgs;
        a = a.bRPublishSendPayNodeP2POrMMixinGroupArgs;
        c = d("WASmaxOutMessagePublishBRPublishSendPayNodeP2POrMMixinGroup").mergeBRPublishSendPayNodeP2POrMMixinGroup(d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishBRSendPayEloNodeMixin").mergeBRSendPayEloNodeMixin, d("WASmaxJsx").smax("pay", {
            id: (b = d("WAWap")).CUSTOM_STRING(c),
            "payment-rails": b.CUSTOM_STRING(e),
            "trusted-device-info": b.CUSTOM_STRING(f),
            nonce: b.CUSTOM_STRING(g)
        }), h), a);
        return c
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBRPublishSendPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishOrderMessageMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.orderOrderId,
            e = a.orderOrderMessageId,
            f = a.orderExpiryTs,
            g = a.orderOrderType;
        a = a.orderDiscountProgramName;
        e = d("WASmaxJsx").smax("order", {
            "order-id": (b = d("WAWap")).CUSTOM_STRING(c),
            "order-message-id": (c = d("WASmaxAttrs")).OPTIONAL(b.CUSTOM_STRING, e),
            "expiry-ts": c.OPTIONAL(b.INT, f),
            "order-type": c.OPTIONAL(b.CUSTOM_STRING, g),
            "discount-program-name": c.OPTIONAL(b.CUSTOM_STRING, a)
        });
        return e
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeOrderMessageMixin = a
}), 98);
__d("WASmaxOutMessagePublishUPIPublishSendPayNodeP2MMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishOrderMessageMixin", "WASmaxOutMessagePublishPaymentInitiatorMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.orderArgs;
        a = d("WASmaxJsx").smax("upi", null, d("WASmaxChildren").OPTIONAL_CHILD(i, a));
        return a
    }

    function i(a) {
        a = d("WASmaxOutMessagePublishOrderMessageMixin").mergeOrderMessageMixin(d("WASmaxJsx").smax("order", null), a);
        return a
    }

    function j(a) {
        var b = a.upiArgs;
        a = a.paymentInitiatorMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishPaymentInitiatorMixin").mergePaymentInitiatorMixin, d("WASmaxJsx").smax("pay", {
            "transaction-type": "p2m"
        }, d("WASmaxChildren").OPTIONAL_CHILD(h, b)), a);
        return b
    }

    function a(a, b) {
        b = j(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeUPIPublishSendPayNodeP2MUpi = h;
    g.makeUPIPublishSendPayNodeP2MUpiOrder = i;
    g.mergeUPIPublishSendPayNodeP2MMixin = a
}), 98);
__d("WASmaxOutMessagePublishUPIPublishSendPayNodeP2PMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.hasPayTransactionTypeP2P;
        a = d("WASmaxJsx").smax("pay", {
            "transaction-type": d("WASmaxAttrs").OPTIONAL_LITERAL("p2p", a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeUPIPublishSendPayNodeP2PMixin = a
}), 98);
__d("WASmaxOutMessagePublishUPIPublishSendPayNodeP2POrMMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishUPIPublishSendPayNodeP2MMixin", "WASmaxOutMessagePublishUPIPublishSendPayNodeP2PMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.uPIPublishSendPayNodeP2P) return d("WASmaxOutMessagePublishUPIPublishSendPayNodeP2PMixin").mergeUPIPublishSendPayNodeP2PMixin(a, b.uPIPublishSendPayNodeP2P);
        if (b.uPIPublishSendPayNodeP2M) return d("WASmaxOutMessagePublishUPIPublishSendPayNodeP2MMixin").mergeUPIPublishSendPayNodeP2MMixin(a, b.uPIPublishSendPayNodeP2M);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeUPIPublishSendPayNodeP2POrMMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishUPIPublishSendPayNodeMixin", ["WASmaxAttrs", "WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishUPIPublishSendPayNodeP2POrMMixinGroup", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.upiToken;
        a = d("WASmaxJsx").smax("upi", {
            token: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        });
        return a
    }

    function i(a) {
        var b, c, e = a.upiArgs,
            f = a.payId,
            g = a.payMpin,
            i = a.payReceiverVpa,
            j = a.payReceiverVpaId,
            k = a.paySenderVpa,
            l = a.paySenderVpaId,
            m = a.paySeqNo,
            n = a.payUpiBankInfo,
            o = a.payMode,
            p = a.payPurposeCode,
            q = a.payMcc,
            r = a.payRefId,
            s = a.payDeviceSsid,
            t = a.payNote;
        a = a.uPIPublishSendPayNodeP2POrMMixinGroupArgs;
        f = d("WASmaxOutMessagePublishUPIPublishSendPayNodeP2POrMMixinGroup").mergeUPIPublishSendPayNodeP2POrMMixinGroup(d("WASmaxJsx").smax("pay", {
            id: (b = d("WASmaxAttrs")).OPTIONAL((c = d("WAWap")).CUSTOM_STRING, f),
            mpin: b.OPTIONAL(c.CUSTOM_STRING, g),
            "receiver-vpa": c.CUSTOM_STRING(i),
            "receiver-vpa-id": b.OPTIONAL(c.CUSTOM_STRING, j),
            "sender-vpa": c.CUSTOM_STRING(k),
            "sender-vpa-id": b.OPTIONAL(c.CUSTOM_STRING, l),
            "seq-no": c.CUSTOM_STRING(m),
            "upi-bank-info": c.CUSTOM_STRING(n),
            mode: b.OPTIONAL(c.CUSTOM_STRING, o),
            "purpose-code": b.OPTIONAL(c.CUSTOM_STRING, p),
            mcc: b.OPTIONAL(c.CUSTOM_STRING, q),
            "ref-id": b.OPTIONAL(c.CUSTOM_STRING, r),
            device_ssid: b.OPTIONAL(c.CUSTOM_STRING, s),
            note: b.OPTIONAL(c.CUSTOM_STRING, t)
        }, d("WASmaxChildren").OPTIONAL_CHILD(h, e)), a);
        return f
    }

    function a(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeUPIPublishSendPayNodeUpi = h;
    g.mergeUPIPublishSendPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishBRPublishOrUPIPublishSendPayNodeMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishBRPublishSendPayNodeMixin", "WASmaxOutMessagePublishUPIPublishSendPayNodeMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.bRPublishSendPayNode) return d("WASmaxOutMessagePublishBRPublishSendPayNodeMixin").mergeBRPublishSendPayNodeMixin(a, b.bRPublishSendPayNode);
        if (b.uPIPublishSendPayNode) return d("WASmaxOutMessagePublishUPIPublishSendPayNodeMixin").mergeUPIPublishSendPayNodeMixin(a, b.uPIPublishSendPayNode);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeBRPublishOrUPIPublishSendPayNodeMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishIntegrationPublishPayNodeMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBRPublishOrUPIPublishSendPayNodeMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.bRPublishOrUPIPublishSendPayNodeMixinGroupArgs;
        a = d("WASmaxOutMessagePublishBRPublishOrUPIPublishSendPayNodeMixinGroup").mergeBRPublishOrUPIPublishSendPayNodeMixinGroup(d("WASmaxJsx").smax("pay", null), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIntegrationPublishPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualNonNoviPublishSendPayNodeMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBaseIndividualPublishSendPayNodeMixin", "WASmaxOutMessagePublishIntegrationPublishPayNodeMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishIntegrationPublishPayNodeMixin").mergeIntegrationPublishPayNodeMixin(d("WASmaxOutMessagePublishBaseIndividualPublishSendPayNodeMixin").mergeBaseIndividualPublishSendPayNodeMixin(d("WASmaxJsx").smax("pay", null), a), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualNonNoviPublishSendPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualPublishSendPayNodeMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishIndividualNonNoviPublishSendPayNodeMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishIndividualNonNoviPublishSendPayNodeMixin").mergeIndividualNonNoviPublishSendPayNodeMixin(d("WASmaxJsx").smax("pay", null), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualPublishSendPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualRequestPayNodeMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBasePayNodeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.paySender,
            c = a.payExpiryTs,
            e = a.payRequestId;
        b = d("WASmaxOutMessagePublishBasePayNodeMixin").mergeBasePayNodeMixin(d("WASmaxJsx").smax("pay", {
            sender: d("WASmaxAttrs").OPTIONAL(d("WAWap").USER_JID, b),
            "expiry-ts": d("WAWap").CUSTOM_STRING(c),
            "request-id": d("WAWap").CUSTOM_STRING(e)
        }), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualRequestPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishPayInviteNodeMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.payService;
        a = d("WASmaxJsx").smax("pay", {
            type: "invite",
            service: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePayInviteNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualPublishSendPayOrIndividualRequestPayOrPayInviteNodeMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishIndividualPublishSendPayNodeMixin", "WASmaxOutMessagePublishIndividualRequestPayNodeMixin", "WASmaxOutMessagePublishPayInviteNodeMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.individualPublishSendPayNode) return d("WASmaxOutMessagePublishIndividualPublishSendPayNodeMixin").mergeIndividualPublishSendPayNodeMixin(a, b.individualPublishSendPayNode);
        if (b.individualRequestPayNode) return d("WASmaxOutMessagePublishIndividualRequestPayNodeMixin").mergeIndividualRequestPayNodeMixin(a, b.individualRequestPayNode);
        if (b.payInviteNode) return d("WASmaxOutMessagePublishPayInviteNodeMixin").mergePayInviteNodeMixin(a, b.payInviteNode);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeIndividualPublishSendPayOrIndividualRequestPayOrPayInviteNodeMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishIndividualPublishPayNodeMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishIndividualPublishSendPayOrIndividualRequestPayOrPayInviteNodeMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.individualPublishSendPayOrIndividualRequestPayOrPayInviteNodeMixinGroupArgs;
        a = d("WASmaxOutMessagePublishIndividualPublishSendPayOrIndividualRequestPayOrPayInviteNodeMixinGroup").mergeIndividualPublishSendPayOrIndividualRequestPayOrPayInviteNodeMixinGroup(d("WASmaxJsx").smax("pay", null), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualPublishPayNodeMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualIndividualPublishPayNodeMessageMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishIndividualPublishPayNodeMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxJsx").smax("message", null, d("WASmaxOutMessagePublishIndividualPublishPayNodeMixin").mergeIndividualPublishPayNodeMixin(d("WASmaxJsx").smax("pay", null), a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualIndividualPublishPayNodeMessageMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualContentTypePayIndividualMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypePayMixin", "WASmaxOutMessagePublishIndividualIndividualPublishPayNodeMessageMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.individualIndividualPublishPayNodeMessageMixinArgs;
        a = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishIndividualIndividualPublishPayNodeMessageMixin").mergeIndividualIndividualPublishPayNodeMessageMixin, d("WASmaxOutMessagePublishContentTypePayMixin").mergeContentTypePayMixin(d("WASmaxJsx").smax("message", null)), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualContentTypePayIndividualMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentFanoutMixins", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishContentTypeEventMixin", "WASmaxOutMessagePublishContentTypeListFanoutMixin", "WASmaxOutMessagePublishContentTypeLiveLocationFanoutDeprecatedMixin", "WASmaxOutMessagePublishContentTypeLiveLocationFanoutMixin", "WASmaxOutMessagePublishContentTypeMediaFanoutDeprecatedMixin", "WASmaxOutMessagePublishContentTypeMediaFanoutMixin", "WASmaxOutMessagePublishContentTypeMedianotifyMixin", "WASmaxOutMessagePublishContentTypePollCreationMixin", "WASmaxOutMessagePublishContentTypePollResultSnapshotMixin", "WASmaxOutMessagePublishContentTypePollVoteMixin", "WASmaxOutMessagePublishContentTypeReactionMixin", "WASmaxOutMessagePublishContentTypeTextMixin", "WASmaxOutMessagePublishIndividualContentTypePayIndividualMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isContentTypeText) return d("WASmaxOutMessagePublishContentTypeTextMixin").mergeContentTypeTextMixin(a);
        if (b.contentTypeMediaFanout) return d("WASmaxOutMessagePublishContentTypeMediaFanoutMixin").mergeContentTypeMediaFanoutMixin(a, b.contentTypeMediaFanout);
        if (b.contentTypeMediaFanoutDeprecated) return d("WASmaxOutMessagePublishContentTypeMediaFanoutDeprecatedMixin").mergeContentTypeMediaFanoutDeprecatedMixin(a, b.contentTypeMediaFanoutDeprecated);
        if (b.contentTypeLiveLocationFanout) return d("WASmaxOutMessagePublishContentTypeLiveLocationFanoutMixin").mergeContentTypeLiveLocationFanoutMixin(a, b.contentTypeLiveLocationFanout);
        if (b.contentTypeLiveLocationFanoutDeprecated) return d("WASmaxOutMessagePublishContentTypeLiveLocationFanoutDeprecatedMixin").mergeContentTypeLiveLocationFanoutDeprecatedMixin(a, b.contentTypeLiveLocationFanoutDeprecated);
        if (b.individualContentTypePayIndividual) return d("WASmaxOutMessagePublishIndividualContentTypePayIndividualMixin").mergeIndividualContentTypePayIndividualMixin(a, b.individualContentTypePayIndividual);
        if (b.contentTypeListFanout) return d("WASmaxOutMessagePublishContentTypeListFanoutMixin").mergeContentTypeListFanoutMixin(a, b.contentTypeListFanout);
        if (b.isContentTypeReaction) return d("WASmaxOutMessagePublishContentTypeReactionMixin").mergeContentTypeReactionMixin(a);
        if (b.isContentTypePollCreation) return d("WASmaxOutMessagePublishContentTypePollCreationMixin").mergeContentTypePollCreationMixin(a);
        if (b.isContentTypePollVote) return d("WASmaxOutMessagePublishContentTypePollVoteMixin").mergeContentTypePollVoteMixin(a);
        if (b.isContentTypePollResultSnapshot) return d("WASmaxOutMessagePublishContentTypePollResultSnapshotMixin").mergeContentTypePollResultSnapshotMixin(a);
        if (b.isContentTypeMedianotify) return d("WASmaxOutMessagePublishContentTypeMedianotifyMixin").mergeContentTypeMedianotifyMixin(a);
        if (b.contentTypeEvent) return d("WASmaxOutMessagePublishContentTypeEventMixin").mergeContentTypeEventMixin(a, b.contentTypeEvent);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeContentFanoutMixins = a
}), 98);
__d("WASmaxOutMessagePublishLidChatOriginMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.metaOrigin;
        a = a.metaSharePn;
        b = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            origin: d("WAWap").CUSTOM_STRING(b),
            share_pn: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, a)
        }));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeLidChatOriginMixin = a
}), 98);
__d("WASmaxOutMessagePublishTDeprecatedMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messageT;
        a = d("WASmaxJsx").smax("message", {
            t: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeTDeprecatedMixin = a
}), 98);
__d("WASmaxOutMessagePublishToContentBindingMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.toJid;
        a = a.contentBindingElementValue;
        b = d("WASmaxJsx").smax("to", {
            jid: d("WAWap").DEVICE_JID(b)
        }, d("WASmaxJsx").smax("content_binding", null, a));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeToContentBindingMixin = a
}), 98);
__d("WASmaxOutMessagePublishAvatarStickerTypeMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("enc", {
            sticker_type: "avatar"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeAvatarStickerTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncMediaTypeDeprecatedMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishAvatarStickerTypeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.encMediatype,
            c = a.encNativeFlowName;
        a = a.hasAvatarStickerType;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishAvatarStickerTypeMixin").mergeAvatarStickerTypeMixin, d("WASmaxJsx").smax("enc", {
            mediatype: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, b),
            native_flow_name: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, c)
        }), a);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncMediaTypeDeprecatedMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncVersion3Mixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("enc", {
            v: "3"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncVersion3Mixin = a
}), 98);
__d("WASmaxOutMessagePublishEncVersion2Or3MixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishEncVersion2Mixin", "WASmaxOutMessagePublishEncVersion3Mixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isEncVersion2) return d("WASmaxOutMessagePublishEncVersion2Mixin").mergeEncVersion2Mixin(a);
        if (b.isEncVersion3) return d("WASmaxOutMessagePublishEncVersion3Mixin").mergeEncVersion3Mixin(a);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeEncVersion2Or3MixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishToDeviceMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishEncMediaTypeDeprecatedMixin", "WASmaxOutMessagePublishEncTypeIndividualMixin", "WASmaxOutMessagePublishEncVersion2Or3MixinGroup", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.toJid,
            c = a.encTypeIndividualMixinArgs,
            e = a.encMediaTypeDeprecatedMixinArgs;
        a = a.encVersion2Or3MixinGroupArgs;
        b = d("WASmaxJsx").smax("to", {
            jid: d("WAWap").JID(b)
        }, d("WASmaxOutMessagePublishEncVersion2Or3MixinGroup").mergeEncVersion2Or3MixinGroup(d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishEncMediaTypeDeprecatedMixin").mergeEncMediaTypeDeprecatedMixin, d("WASmaxOutMessagePublishEncTypeIndividualMixin").mergeEncTypeIndividualMixin(d("WASmaxJsx").smax("enc", null), c), e), a));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeToDeviceMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualIndividualFanoutMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBotLocalAutomatedTypeMixin", "WASmaxOutMessagePublishBotMessageTypeMixin", "WASmaxOutMessagePublishBusinessBotMessageFeedbackRequestedMixin", "WASmaxOutMessagePublishBusinessBotMessageMixin", "WASmaxOutMessagePublishContentFanoutMixins", "WASmaxOutMessagePublishLidChatOriginMixin", "WASmaxOutMessagePublishTDeprecatedMixin", "WASmaxOutMessagePublishToContentBindingMixin", "WASmaxOutMessagePublishToDeviceMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.toContentBindingMixinArgs;
        a = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishToContentBindingMixin").mergeToContentBindingMixin, d("WASmaxOutMessagePublishToDeviceMixin").mergeToDeviceMixin(d("WASmaxJsx").smax("to", null), a), b);
        return a
    }

    function a() {
        var a = d("WASmaxJsx").smax("enc", null);
        return a
    }

    function i(a) {
        var b, c = a.toArgs,
            e = a.messageTo,
            f = a.tDeprecatedMixinArgs,
            g = a.botMessageTypeMixinArgs,
            i = a.businessBotMessageMixinArgs,
            j = a.lidChatOriginMixinArgs,
            k = a.botLocalAutomatedTypeMixinArgs,
            l = a.businessBotMessageFeedbackRequestedMixinArgs;
        a = a.contentFanoutMixinsArgs;
        b = d("WASmaxOutMessagePublishContentFanoutMixins").mergeContentFanoutMixins((b = d("WASmaxMixins")).optionalMerge(d("WASmaxOutMessagePublishBusinessBotMessageFeedbackRequestedMixin").mergeBusinessBotMessageFeedbackRequestedMixin, b.optionalMerge(d("WASmaxOutMessagePublishBotLocalAutomatedTypeMixin").mergeBotLocalAutomatedTypeMixin, b.optionalMerge(d("WASmaxOutMessagePublishLidChatOriginMixin").mergeLidChatOriginMixin, b.optionalMerge(d("WASmaxOutMessagePublishBusinessBotMessageMixin").mergeBusinessBotMessageMixin, b.optionalMerge(d("WASmaxOutMessagePublishBotMessageTypeMixin").mergeBotMessageTypeMixin, b.optionalMerge(d("WASmaxOutMessagePublishTDeprecatedMixin").mergeTDeprecatedMixin, d("WASmaxJsx").smax("message", {
            to: d("WAWap").JID(e)
        }, d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").REPEATED_CHILD(h, c, 1, 1997))), f), g), i), j), k), l), a);
        return b
    }

    function b(a, b) {
        b = i(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeIndividualIndividualFanoutParticipantsTo = h;
    g.makeIndividualIndividualFanoutEnc = a;
    g.mergeIndividualIndividualFanoutMixin = b
}), 98);
__d("WASmaxOutMessagePublishEncListMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("enc", {
            mediatype: "list"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncListMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeListMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaMixin", "WASmaxOutMessagePublishEncListMixin", "WASmaxOutMessagePublishSingleSelectOrProductListMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.singleSelectOrProductListMixinGroupArgs;
        a = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishSingleSelectOrProductListMixinGroup").mergeSingleSelectOrProductListMixinGroup, d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(d("WASmaxJsx").smax("message", null, d("WASmaxOutMessagePublishEncListMixin").mergeEncListMixin(d("WASmaxJsx").smax("enc", null)))), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeListMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncLiveLocationDeprecatedMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encDuration;
        a = d("WASmaxJsx").smax("enc", {
            mediatype: "livelocation",
            duration: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncLiveLocationDeprecatedMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncLiveLocationMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.encDuration;
        a = d("WASmaxJsx").smax("enc", {
            mediatype: "livelocation",
            duration: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncLiveLocationMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncLiveLocationEncLiveLocationOrEncLiveLocationDeprecatedMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishEncLiveLocationDeprecatedMixin", "WASmaxOutMessagePublishEncLiveLocationMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.encLiveLocation) return d("WASmaxOutMessagePublishEncLiveLocationMixin").mergeEncLiveLocationMixin(a, b.encLiveLocation);
        if (b.encLiveLocationDeprecated) return d("WASmaxOutMessagePublishEncLiveLocationDeprecatedMixin").mergeEncLiveLocationDeprecatedMixin(a, b.encLiveLocationDeprecated);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeEncLiveLocationEncLiveLocationOrEncLiveLocationDeprecatedMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeLiveLocationSingleMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaMixin", "WASmaxOutMessagePublishEncLiveLocationEncLiveLocationOrEncLiveLocationDeprecatedMixinGroup", "WASmaxOutMessagePublishLiveLocationModeMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.liveLocationModeMixinArgs;
        a = a.encLiveLocationEncLiveLocationOrEncLiveLocationDeprecatedMixinGroupArgs;
        a = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishLiveLocationModeMixin").mergeLiveLocationModeMixin, d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(d("WASmaxJsx").smax("message", null, d("WASmaxOutMessagePublishEncLiveLocationEncLiveLocationOrEncLiveLocationDeprecatedMixinGroup").mergeEncLiveLocationEncLiveLocationOrEncLiveLocationDeprecatedMixinGroup(d("WASmaxJsx").smax("enc", null), a))), b);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeLiveLocationSingleMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncMediaTypeMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishAvatarStickerTypeMixin", "WASmaxOutMessagePublishMediaTypeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.encNativeFlowName,
            c = a.hasAvatarStickerType;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishAvatarStickerTypeMixin").mergeAvatarStickerTypeMixin, d("WASmaxOutMessagePublishMediaTypeMixin").mergeMediaTypeMixin(d("WASmaxJsx").smax("enc", {
            native_flow_name: d("WASmaxAttrs").OPTIONAL(d("WAWap").CUSTOM_STRING, b)
        }), a), c);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncMediaTypeMixin = a
}), 98);
__d("WASmaxOutMessagePublishEncMediaTypeEncMediaTypeOrEncMediaTypeDeprecatedMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishEncMediaTypeDeprecatedMixin", "WASmaxOutMessagePublishEncMediaTypeMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.encMediaType) return d("WASmaxOutMessagePublishEncMediaTypeMixin").mergeEncMediaTypeMixin(a, b.encMediaType);
        if (b.encMediaTypeDeprecated) return d("WASmaxOutMessagePublishEncMediaTypeDeprecatedMixin").mergeEncMediaTypeDeprecatedMixin(a, b.encMediaTypeDeprecated);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeEncMediaTypeEncMediaTypeOrEncMediaTypeDeprecatedMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeMediaSingleMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaOrMedianotifyMixinGroup", "WASmaxOutMessagePublishEncMediaTypeEncMediaTypeOrEncMediaTypeDeprecatedMixinGroup", "WASmaxOutMessagePublishSenderContentBindingMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.senderContentBindingMixinArgs,
            c = a.contentTypeMediaOrMedianotifyMixinGroupArgs;
        a = a.encMediaTypeEncMediaTypeOrEncMediaTypeDeprecatedMixinGroupArgs;
        a = d("WASmaxOutMessagePublishContentTypeMediaOrMedianotifyMixinGroup").mergeContentTypeMediaOrMedianotifyMixinGroup(d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishSenderContentBindingMixin").mergeSenderContentBindingMixin, d("WASmaxJsx").smax("message", null, d("WASmaxOutMessagePublishEncMediaTypeEncMediaTypeOrEncMediaTypeDeprecatedMixinGroup").mergeEncMediaTypeEncMediaTypeOrEncMediaTypeDeprecatedMixinGroup(d("WASmaxJsx").smax("enc", null), a)), b), c);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeContentTypeMediaSingleMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentMixins", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishContentTypeEventMixin", "WASmaxOutMessagePublishContentTypeListMixin", "WASmaxOutMessagePublishContentTypeLiveLocationSingleMixin", "WASmaxOutMessagePublishContentTypeMediaSingleMixin", "WASmaxOutMessagePublishContentTypePollCreationMixin", "WASmaxOutMessagePublishContentTypePollResultSnapshotMixin", "WASmaxOutMessagePublishContentTypePollVoteMixin", "WASmaxOutMessagePublishContentTypeReactionMixin", "WASmaxOutMessagePublishContentTypeTextMixin", "WASmaxOutMessagePublishIndividualContentTypePayIndividualMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isContentTypeText) return d("WASmaxOutMessagePublishContentTypeTextMixin").mergeContentTypeTextMixin(a);
        if (b.contentTypeMediaSingle) return d("WASmaxOutMessagePublishContentTypeMediaSingleMixin").mergeContentTypeMediaSingleMixin(a, b.contentTypeMediaSingle);
        if (b.contentTypeLiveLocationSingle) return d("WASmaxOutMessagePublishContentTypeLiveLocationSingleMixin").mergeContentTypeLiveLocationSingleMixin(a, b.contentTypeLiveLocationSingle);
        if (b.individualContentTypePayIndividual) return d("WASmaxOutMessagePublishIndividualContentTypePayIndividualMixin").mergeIndividualContentTypePayIndividualMixin(a, b.individualContentTypePayIndividual);
        if (b.contentTypeList) return d("WASmaxOutMessagePublishContentTypeListMixin").mergeContentTypeListMixin(a, b.contentTypeList);
        if (b.isContentTypeReaction) return d("WASmaxOutMessagePublishContentTypeReactionMixin").mergeContentTypeReactionMixin(a);
        if (b.isContentTypePollCreation) return d("WASmaxOutMessagePublishContentTypePollCreationMixin").mergeContentTypePollCreationMixin(a);
        if (b.isContentTypePollVote) return d("WASmaxOutMessagePublishContentTypePollVoteMixin").mergeContentTypePollVoteMixin(a);
        if (b.isContentTypePollResultSnapshot) return d("WASmaxOutMessagePublishContentTypePollResultSnapshotMixin").mergeContentTypePollResultSnapshotMixin(a);
        if (b.contentTypeEvent) return d("WASmaxOutMessagePublishContentTypeEventMixin").mergeContentTypeEventMixin(a, b.contentTypeEvent);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeContentMixins = a
}), 98);
__d("WASmaxOutMessagePublishIndividualIndividualRetryToPeerMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messageRecipient;
        a = d("WASmaxJsx").smax("message", {
            recipient: d("WAWap").JID(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualIndividualRetryToPeerMixin = a
}), 98);
__d("WASmaxOutMessagePublishRetryMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishEncRetryMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.messageT;
        a = a.encRetryMixinArgs;
        b = d("WASmaxJsx").smax("message", {
            t: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, b)
        }, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishEncRetryMixin").mergeEncRetryMixin, d("WASmaxJsx").smax("enc", null), a));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeRetryMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualIndividualRetryMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishIndividualIndividualRetryToPeerMixin", "WASmaxOutMessagePublishRetryMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.individualIndividualRetryToPeerMixinArgs;
        a = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishIndividualIndividualRetryToPeerMixin").mergeIndividualIndividualRetryToPeerMixin, d("WASmaxOutMessagePublishRetryMixin").mergeRetryMixin(d("WASmaxJsx").smax("message", null), a), b);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualIndividualRetryMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualIndividualSingleContentBindingMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.contentBindingElementValue;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("content_binding", null, a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualIndividualSingleContentBindingMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualIndividualSingleMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBotLocalAutomatedTypeMixin", "WASmaxOutMessagePublishBotMessageTypeMixin", "WASmaxOutMessagePublishBusinessBotMessageFeedbackRequestedMixin", "WASmaxOutMessagePublishBusinessBotMessageMixin", "WASmaxOutMessagePublishContentMixins", "WASmaxOutMessagePublishEncMediaTypeDeprecatedMixin", "WASmaxOutMessagePublishEncTypeIndividualMixin", "WASmaxOutMessagePublishEncVersion2Or3MixinGroup", "WASmaxOutMessagePublishIndividualIndividualRetryMixin", "WASmaxOutMessagePublishIndividualIndividualSingleContentBindingMixin", "WASmaxOutMessagePublishLidChatOriginMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.messageTo,
            e = a.individualIndividualRetryMixinArgs,
            f = a.individualIndividualSingleContentBindingMixinArgs,
            g = a.botMessageTypeMixinArgs,
            h = a.businessBotMessageMixinArgs,
            i = a.lidChatOriginMixinArgs,
            j = a.botLocalAutomatedTypeMixinArgs,
            k = a.businessBotMessageFeedbackRequestedMixinArgs,
            l = a.contentMixinsArgs,
            m = a.encTypeIndividualMixinArgs,
            n = a.encMediaTypeDeprecatedMixinArgs;
        a = a.encVersion2Or3MixinGroupArgs;
        c = d("WASmaxOutMessagePublishContentMixins").mergeContentMixins((b = d("WASmaxMixins")).optionalMerge(d("WASmaxOutMessagePublishBusinessBotMessageFeedbackRequestedMixin").mergeBusinessBotMessageFeedbackRequestedMixin, b.optionalMerge(d("WASmaxOutMessagePublishBotLocalAutomatedTypeMixin").mergeBotLocalAutomatedTypeMixin, b.optionalMerge(d("WASmaxOutMessagePublishLidChatOriginMixin").mergeLidChatOriginMixin, b.optionalMerge(d("WASmaxOutMessagePublishBusinessBotMessageMixin").mergeBusinessBotMessageMixin, b.optionalMerge(d("WASmaxOutMessagePublishBotMessageTypeMixin").mergeBotMessageTypeMixin, b.optionalMerge(d("WASmaxOutMessagePublishIndividualIndividualSingleContentBindingMixin").mergeIndividualIndividualSingleContentBindingMixin, b.optionalMerge(d("WASmaxOutMessagePublishIndividualIndividualRetryMixin").mergeIndividualIndividualRetryMixin, d("WASmaxJsx").smax("message", {
            to: d("WAWap").JID(c)
        }, d("WASmaxOutMessagePublishEncVersion2Or3MixinGroup").mergeEncVersion2Or3MixinGroup(b.optionalMerge(d("WASmaxOutMessagePublishEncMediaTypeDeprecatedMixin").mergeEncMediaTypeDeprecatedMixin, d("WASmaxOutMessagePublishEncTypeIndividualMixin").mergeEncTypeIndividualMixin(d("WASmaxJsx").smax("enc", null), m), n), a)), e), f), g), h), i), j), k), l);
        return c
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualIndividualSingleMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualIndividualSingleOrIndividualFanoutMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishIndividualIndividualFanoutMixin", "WASmaxOutMessagePublishIndividualIndividualSingleMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.individualIndividualSingle) return d("WASmaxOutMessagePublishIndividualIndividualSingleMixin").mergeIndividualIndividualSingleMixin(a, b.individualIndividualSingle);
        if (b.individualIndividualFanout) return d("WASmaxOutMessagePublishIndividualIndividualFanoutMixin").mergeIndividualIndividualFanoutMixin(a, b.individualIndividualFanout);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeIndividualIndividualSingleOrIndividualFanoutMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishIndividualBotRequestMessageMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBotFeedbackMessageTypeMixin", "WASmaxOutMessagePublishBotRequestMixin", "WASmaxOutMessagePublishContentTypeTextOrMediaMixinGroup", "WASmaxOutMessagePublishIndividualIndividualSingleOrIndividualFanoutMixinGroup", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.messageTo,
            c = a.contentTypeTextOrMediaMixinGroupArgs,
            e = a.individualIndividualSingleOrIndividualFanoutMixinGroupArgs,
            f = a.hasBotFeedbackMessageType;
        a = a.botRequestMixinArgs;
        b = d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishIndividualIndividualSingleOrIndividualFanoutMixinGroup").mergeIndividualIndividualSingleOrIndividualFanoutMixinGroup, d("WASmaxOutMessagePublishContentTypeTextOrMediaMixinGroup").mergeContentTypeTextOrMediaMixinGroup(d("WASmaxJsx").smax("message", {
            to: d("WAWap").USER_JID(b)
        }, d("WASmaxMixins").optionalMerge(d("WASmaxOutMessagePublishBotFeedbackMessageTypeMixin").mergeBotFeedbackMessageTypeMixin, d("WASmaxJsx").smax("bot", null, d("WASmaxOutMessagePublishBotRequestMixin").mergeBotRequestMixin(d("WASmaxJsx").smax("to", null), a)), f)), c), e);
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualBotRequestMessageMixin = a
}), 98);
__d("WASmaxOutMessagePublishBotResponseMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b, c = a.botEditTargetId,
            e = a.botSenderTimestampMs,
            f = a.botEdit;
        a = a.hasBotTypeVoice;
        c = d("WASmaxJsx").smax("bot", {
            edit_target_id: (b = d("WASmaxAttrs")).OPTIONAL(d("WAWap").STANZA_ID, c),
            sender_timestamp_ms: b.OPTIONAL(d("WAWap").INT, e),
            edit: b.OPTIONAL(d("WAWap").CUSTOM_STRING, f),
            type: b.OPTIONAL_LITERAL("voice", a)
        });
        return c
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeBotResponseMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualContentTypeBotResponseMediaFanoutMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishContentTypeMediaMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.toCount;
        a = d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").REPEATED_CHILD_COUNT(i, a, 2, 2));
        return a
    }

    function i() {
        var a = d("WASmaxJsx").smax("to", null, d("WASmaxJsx").smax("enc", {
            mediatype: "image"
        }));
        return a
    }

    function j(a) {
        a = a.participantsArgs;
        a = d("WASmaxOutMessagePublishContentTypeMediaMixin").mergeContentTypeMediaMixin(d("WASmaxJsx").smax("message", null, d("WASmaxChildren").OPTIONAL_CHILD(h, a)));
        return a
    }

    function a(a, b) {
        b = j(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeIndividualContentTypeBotResponseMediaFanoutParticipants = h;
    g.makeIndividualContentTypeBotResponseMediaFanoutParticipantsTo = i;
    g.mergeIndividualContentTypeBotResponseMediaFanoutMixin = a
}), 98);
__d("WASmaxOutMessagePublishContentTypeTextOrIndividualBotResponseMediaFanoutMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishContentTypeTextMixin", "WASmaxOutMessagePublishIndividualContentTypeBotResponseMediaFanoutMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isContentTypeText) return d("WASmaxOutMessagePublishContentTypeTextMixin").mergeContentTypeTextMixin(a);
        if (b.individualContentTypeBotResponseMediaFanout) return d("WASmaxOutMessagePublishIndividualContentTypeBotResponseMediaFanoutMixin").mergeIndividualContentTypeBotResponseMediaFanoutMixin(a, b.individualContentTypeBotResponseMediaFanout);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeContentTypeTextOrIndividualBotResponseMediaFanoutMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishEncTypeMessageSecretMessageMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishEncPayloadMixin"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = d("WASmaxOutMessagePublishEncPayloadMixin").mergeEncPayloadMixin(d("WASmaxJsx").smax("enc", {
            type: "msmsg"
        }), a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeEncTypeMessageSecretMessageMixin = a
}), 98);
__d("WASmaxOutMessagePublishMessageTargetMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.metaTargetId,
            c = a.metaTargetSenderJid;
        a = a.metaTargetChatJid;
        b = d("WASmaxJsx").smax("meta", {
            target_id: d("WAWap").STANZA_ID(b),
            target_sender_jid: d("WASmaxAttrs").OPTIONAL(d("WAWap").USER_JID, c),
            target_chat_jid: d("WASmaxAttrs").OPTIONAL(d("WAWap").JID, a)
        });
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMessageTargetMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualBotResponseFanoutMixin", ["WASmaxChildren", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishBotResponseMixin", "WASmaxOutMessagePublishContentTypeTextOrIndividualBotResponseMediaFanoutMixinGroup", "WASmaxOutMessagePublishEncTypeMessageSecretMessageMixin", "WASmaxOutMessagePublishEncVersion2OrFutureproofMixinGroup", "WASmaxOutMessagePublishMessageTargetMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.toArgs;
        a = d("WASmaxJsx").smax("participants", null, d("WASmaxChildren").REPEATED_CHILD(i, a, 2, 2));
        return a
    }

    function i(a) {
        a = a.toJid;
        a = d("WASmaxJsx").smax("to", {
            jid: d("WAWap").USER_JID(a)
        });
        return a
    }

    function j(a) {
        var b, c = a.participantsArgs,
            e = a.messageTo,
            f = a.contentTypeTextOrIndividualBotResponseMediaFanoutMixinGroupArgs,
            g = a.botResponseMixinArgs,
            i = a.messageTargetMixinArgs,
            j = a.encTypeMessageSecretMessageMixinArgs;
        a = a.encVersion2OrFutureproofMixinGroupArgs;
        e = d("WASmaxOutMessagePublishContentTypeTextOrIndividualBotResponseMediaFanoutMixinGroup").mergeContentTypeTextOrIndividualBotResponseMediaFanoutMixinGroup((b = d("WASmaxJsx")).smax("message", {
            to: d("WAWap").USER_JID(e)
        }, d("WASmaxOutMessagePublishBotResponseMixin").mergeBotResponseMixin(b.smax("bot", null), g), d("WASmaxOutMessagePublishMessageTargetMixin").mergeMessageTargetMixin(b.smax("meta", null), i), d("WASmaxOutMessagePublishEncVersion2OrFutureproofMixinGroup").mergeEncVersion2OrFutureproofMixinGroup(d("WASmaxOutMessagePublishEncTypeMessageSecretMessageMixin").mergeEncTypeMessageSecretMessageMixin(b.smax("enc", null), j), a), d("WASmaxChildren").OPTIONAL_CHILD(h, c)), f);
        return e
    }

    function a(a, b) {
        b = j(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.makeIndividualBotResponseFanoutParticipants = h;
    g.makeIndividualBotResponseFanoutParticipantsTo = i;
    g.mergeIndividualBotResponseFanoutMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualBotResponseFanoutOrIndividualBotRequestMessageOrIndividualIndividualSingleOrIndividualIndividualFanoutMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishIndividualBotRequestMessageMixin", "WASmaxOutMessagePublishIndividualBotResponseFanoutMixin", "WASmaxOutMessagePublishIndividualIndividualFanoutMixin", "WASmaxOutMessagePublishIndividualIndividualSingleMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.individualBotResponseFanout) return d("WASmaxOutMessagePublishIndividualBotResponseFanoutMixin").mergeIndividualBotResponseFanoutMixin(a, b.individualBotResponseFanout);
        if (b.individualBotRequestMessage) return d("WASmaxOutMessagePublishIndividualBotRequestMessageMixin").mergeIndividualBotRequestMessageMixin(a, b.individualBotRequestMessage);
        if (b.individualIndividualSingle) return d("WASmaxOutMessagePublishIndividualIndividualSingleMixin").mergeIndividualIndividualSingleMixin(a, b.individualIndividualSingle);
        if (b.individualIndividualFanout) return d("WASmaxOutMessagePublishIndividualIndividualFanoutMixin").mergeIndividualIndividualFanoutMixin(a, b.individualIndividualFanout);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeIndividualBotResponseFanoutOrIndividualBotRequestMessageOrIndividualIndividualSingleOrIndividualIndividualFanoutMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishIndividualRecipientDeprecaredMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messageRecipient;
        a = d("WASmaxJsx").smax("message", {
            recipient: d("WAWap").JID(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeIndividualRecipientDeprecaredMixin = a
}), 98);
__d("WASmaxOutMessagePublishMessageEditMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            edit: "1"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMessageEditMixin = a
}), 98);
__d("WASmaxOutMessagePublishMessagePinMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            edit: "2"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeMessagePinMixin = a
}), 98);
__d("WASmaxOutMessagePublishRevokeMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", {
            edit: "7"
        });
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeRevokeMixin = a
}), 98);
__d("WASmaxOutMessagePublishMessageEditOrMessagePinOrRevokeMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishMessageEditMixin", "WASmaxOutMessagePublishMessagePinMixin", "WASmaxOutMessagePublishRevokeMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.isMessageEdit) return d("WASmaxOutMessagePublishMessageEditMixin").mergeMessageEditMixin(a);
        if (b.isMessagePin) return d("WASmaxOutMessagePublishMessagePinMixin").mergeMessagePinMixin(a);
        if (b.isRevoke) return d("WASmaxOutMessagePublishRevokeMixin").mergeRevokeMixin(a);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeMessageEditOrMessagePinOrRevokeMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishPeerRecipientLIDMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messagePeerRecipientLid;
        a = d("WASmaxJsx").smax("message", {
            peer_recipient_lid: d("WAWap").JID(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePeerRecipientLIDMixin = a
}), 98);
__d("WASmaxOutMessagePublishPeerRecipientPNMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messagePeerRecipientPn;
        a = d("WASmaxJsx").smax("message", {
            peer_recipient_pn: d("WAWap").JID(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePeerRecipientPNMixin = a
}), 98);
__d("WASmaxOutMessagePublishRecipientPNMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messageRecipientPn;
        a = d("WASmaxJsx").smax("message", {
            recipient_pn: d("WAWap").USER_JID(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeRecipientPNMixin = a
}), 98);
__d("WASmaxOutMessagePublishRecipientUsernameMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.messageRecipientUsername;
        a = d("WASmaxJsx").smax("message", {
            recipient_username: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeRecipientUsernameMixin = a
}), 98);
__d("WASmaxOutMessagePublishRecipientPNOrPeerRecipientPNOrRecipientUsernameOrPeerRecipientLIDMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishPeerRecipientLIDMixin", "WASmaxOutMessagePublishPeerRecipientPNMixin", "WASmaxOutMessagePublishRecipientPNMixin", "WASmaxOutMessagePublishRecipientUsernameMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.recipientPN) return d("WASmaxOutMessagePublishRecipientPNMixin").mergeRecipientPNMixin(a, b.recipientPN);
        if (b.peerRecipientPN) return d("WASmaxOutMessagePublishPeerRecipientPNMixin").mergePeerRecipientPNMixin(a, b.peerRecipientPN);
        if (b.recipientUsername) return d("WASmaxOutMessagePublishRecipientUsernameMixin").mergeRecipientUsernameMixin(a, b.recipientUsername);
        if (b.peerRecipientLID) return d("WASmaxOutMessagePublishPeerRecipientLIDMixin").mergePeerRecipientLIDMixin(a, b.peerRecipientLID);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeRecipientPNOrPeerRecipientPNOrRecipientUsernameOrPeerRecipientLIDMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishStatusMentionMessageMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            is_status_mention: "true"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeStatusMentionMessageMixin = a
}), 98);
__d("WASmaxOutMessagePublishPrivacyTokenContentsMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.anyElementValue;
        a = d("WASmaxJsx").smax("smax$any", null, a);
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergePrivacyTokenContentsMixin = a
}), 98);
__d("WASmaxOutMessagePublishTCTokenMixin", ["WASmaxAttrs", "WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishPrivacyTokenContentsMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = a.tctokenT;
        a = a.privacyTokenContentsMixinArgs;
        b = d("WASmaxJsx").smax("smax$any", null, d("WASmaxOutMessagePublishPrivacyTokenContentsMixin").mergePrivacyTokenContentsMixin(d("WASmaxJsx").smax("tctoken", {
            t: d("WASmaxAttrs").OPTIONAL(d("WAWap").INT, b)
        }), a));
        return b
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeTCTokenMixin = a
}), 98);
__d("WASmaxOutMessagePublishThreadTypeTagEnumMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.metaThreadType;
        a = d("WASmaxJsx").smax("meta", {
            thread_type: d("WAWap").INT(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeThreadTypeTagEnumMixin = a
}), 98);
__d("WASmaxOutMessagePublishThreadTypeTagLegacyMixin", ["WASmaxJsx", "WASmaxMixins", "WAWap"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.metaThreadType;
        a = d("WASmaxJsx").smax("meta", {
            thread_type: d("WAWap").CUSTOM_STRING(a)
        });
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeThreadTypeTagLegacyMixin = a
}), 98);
__d("WASmaxOutMessagePublishThreadTypeTagEnumOrLegacyMixinGroup", ["WASmaxMixinGroupExhaustiveError", "WASmaxOutMessagePublishThreadTypeTagEnumMixin", "WASmaxOutMessagePublishThreadTypeTagLegacyMixin"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (b.threadTypeTagEnum) return d("WASmaxOutMessagePublishThreadTypeTagEnumMixin").mergeThreadTypeTagEnumMixin(a, b.threadTypeTagEnum);
        if (b.threadTypeTagLegacy) return d("WASmaxOutMessagePublishThreadTypeTagLegacyMixin").mergeThreadTypeTagLegacyMixin(a, b.threadTypeTagLegacy);
        throw new(d("WASmaxMixinGroupExhaustiveError").SmaxMixinGroupExhaustiveError)()
    }
    g.mergeThreadTypeTagEnumOrLegacyMixinGroup = a
}), 98);
__d("WASmaxOutMessagePublishThreadTypeTagMixin", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishThreadTypeTagEnumOrLegacyMixinGroup"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = a.threadTypeTagEnumOrLegacyMixinGroupArgs;
        a = d("WASmaxJsx").smax("message", null, d("WASmaxOutMessagePublishThreadTypeTagEnumOrLegacyMixinGroup").mergeThreadTypeTagEnumOrLegacyMixinGroup(d("WASmaxJsx").smax("meta", null), a));
        return a
    }

    function a(a, b) {
        b = h(b);
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeThreadTypeTagMixin = a
}), 98);
__d("WASmaxOutMessagePublishViewOnceMetaAttributeMixin", ["WASmaxJsx", "WASmaxMixins"], (function(a, b, c, d, e, f, g) {
    function h() {
        var a = d("WASmaxJsx").smax("message", null, d("WASmaxJsx").smax("meta", {
            view_once: "true"
        }));
        return a
    }

    function a(a) {
        var b = h();
        return d("WASmaxMixins").mergeStanzas(a, b)
    }
    g.mergeViewOnceMetaAttributeMixin = a
}), 98);
__d("WASmaxOutMessagePublishIndividualRequest", ["WASmaxJsx", "WASmaxMixins", "WASmaxOutMessagePublishAppdataMetaAttributeMixin", "WASmaxOutMessagePublishBaseMixin", "WASmaxOutMessagePublishGroupInviteTargetMixin", "WASmaxOutMessagePublishIndividualBotResponseFanoutOrIndividualBotRequestMessageOrIndividualIndividualSingleOrIndividualIndividualFanoutMixinGroup", "WASmaxOutMessagePublishIndividualRecipientDeprecaredMixin", "WASmaxOutMessagePublishMessageEditOrMessagePinOrRevokeMixinGroup", "WASmaxOutMessagePublishRecipientPNOrPeerRecipientPNOrRecipientUsernameOrPeerRecipientLIDMixinGroup", "WASmaxOutMessagePublishStatusMentionMessageMixin", "WASmaxOutMessagePublishTCTokenMixin", "WASmaxOutMessagePublishThreadTypeTagMixin", "WASmaxOutMessagePublishViewOnceMetaAttributeMixin", "WAWap"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b, c = a.messageId,
            e = a.groupInviteTargetMixinArgs,
            f = a.threadTypeTagMixinArgs,
            g = a.individualRecipientDeprecaredMixinArgs,
            h = a.hasAppdataMetaAttribute,
            i = a.hasStatusMentionMessage,
            j = a.tCTokenMixinArgs,
            k = a.hasViewOnceMetaAttribute,
            l = a.individualBotResponseFanoutOrIndividualBotRequestMessageOrIndividualIndividualSingleOrIndividualIndividualFanoutMixinGroupArgs,
            m = a.messageEditOrMessagePinOrRevokeMixinGroupArgs,
            n = a.recipientPNOrPeerRecipientPNOrRecipientUsernameOrPeerRecipientLIDMixinGroupArgs;
        b = (b = d("WASmaxMixins")).optionalMerge(d("WASmaxOutMessagePublishRecipientPNOrPeerRecipientPNOrRecipientUsernameOrPeerRecipientLIDMixinGroup").mergeRecipientPNOrPeerRecipientPNOrRecipientUsernameOrPeerRecipientLIDMixinGroup, b.optionalMerge(d("WASmaxOutMessagePublishMessageEditOrMessagePinOrRevokeMixinGroup").mergeMessageEditOrMessagePinOrRevokeMixinGroup, d("WASmaxOutMessagePublishIndividualBotResponseFanoutOrIndividualBotRequestMessageOrIndividualIndividualSingleOrIndividualIndividualFanoutMixinGroup").mergeIndividualBotResponseFanoutOrIndividualBotRequestMessageOrIndividualIndividualSingleOrIndividualIndividualFanoutMixinGroup(b.optionalMerge(d("WASmaxOutMessagePublishViewOnceMetaAttributeMixin").mergeViewOnceMetaAttributeMixin, b.optionalMerge(d("WASmaxOutMessagePublishTCTokenMixin").mergeTCTokenMixin, b.optionalMerge(d("WASmaxOutMessagePublishStatusMentionMessageMixin").mergeStatusMentionMessageMixin, b.optionalMerge(d("WASmaxOutMessagePublishAppdataMetaAttributeMixin").mergeAppdataMetaAttributeMixin, b.optionalMerge(d("WASmaxOutMessagePublishIndividualRecipientDeprecaredMixin").mergeIndividualRecipientDeprecaredMixin, b.optionalMerge(d("WASmaxOutMessagePublishThreadTypeTagMixin").mergeThreadTypeTagMixin, b.optionalMerge(d("WASmaxOutMessagePublishGroupInviteTargetMixin").mergeGroupInviteTargetMixin, d("WASmaxOutMessagePublishBaseMixin").mergeBaseMixin(d("WASmaxJsx").smax("message", {
            id: d("WAWap").STANZA_ID(c)
        }), a), e), f), g), h), i), j), k), l), m), n);
        return b
    }
    g.makeIndividualRequest = a
}), 98);
__d("WASmaxMessagePublishIndividualRPC", ["WAComms", "WASmaxInMessagePublishIndividualResponseNegative", "WASmaxInMessagePublishIndividualResponseSuccess", "WASmaxOutMessagePublishIndividualRequest", "WASmaxParsingFailure", "WASmaxRpcUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    function a(a, c) {
        var e, f, g, h;
        return b("regeneratorRuntime").async(function(i) {
            while (1) switch (i.prev = i.next) {
                case 0:
                    e = d("WASmaxOutMessagePublishIndividualRequest").makeIndividualRequest(a);
                    i.next = 3;
                    return b("regeneratorRuntime").awrap(d("WAComms").sendSmaxStanza(e, c));
                case 3:
                    f = i.sent;
                    g = d("WASmaxInMessagePublishIndividualResponseNegative").parseIndividualResponseNegative(f, e);
                    if (!g.success) {
                        i.next = 7;
                        break
                    }
                    return i.abrupt("return", {
                        name: "IndividualResponseNegative",
                        value: g.value
                    });
                case 7:
                    h = d("WASmaxInMessagePublishIndividualResponseSuccess").parseIndividualResponseSuccess(f, e);
                    if (!h.success) {
                        i.next = 10;
                        break
                    }
                    return i.abrupt("return", {
                        name: "IndividualResponseSuccess",
                        value: h.value
                    });
                case 10:
                    throw new(d("WASmaxParsingFailure").SmaxParsingFailure)(d("WASmaxRpcUtils").errorMessageRpcParsing("Individual", {
                        Negative: g,
                        Success: h
                    }));
                case 11:
                case "end":
                    return i.stop()
            }
        }, null, this)
    }
    g.sendIndividualRPC = a
}), 98);
__d("WASendMsgRPC", ["WADeprecatedSendIq", "WADeprecatedWapParser", "WAGetDeviceIdentityMixin", "WAJids", "WALogger", "WAParseFranking", "WASmaxMessagePublishIndividualRPC", "WATimeUtils", "WAWap", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["WASendMsgRPC: Wrong media type: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b, c, d, e) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e, f) {
            e === void 0 && (e = !1);
            var g = d("WAJids").interpretAsGroupJid(a.protocolMsgId.chat),
                h = a.messageType.type === "text" && a.messageType.invitedParticipantUserJid != null;
            if (b.type === "direct_user") {
                var i = {
                    individualIndividualSingle: {
                        messageTo: b.message.to,
                        individualIndividualRetryMixinArgs: m(a.count, b.recipient),
                        contentMixinsArgs: l(a, b.message),
                        encTypeIndividualMixinArgs: n(b.message),
                        encVersion2Or3MixinGroupArgs: o(b.message)
                    }
                };
                i = {
                    messageId: a.externalId,
                    deviceIdentityMixinArgs: d("WAGetDeviceIdentityMixin").getDeviceIdentityMixin(a.deviceIdentity),
                    hasNoExtraFanout: a.messageType.isInvisible === !0 ? !0 : null,
                    messageEditOrMessagePinOrRevokeMixinGroupArgs: p(a.messageType),
                    clientFrankingTagMixinArgs: (c == null ? void 0 : c.frankingTag) ? {
                        frankingTagElementValue: c.frankingTag
                    } : null,
                    hasMetaHideDecryptionPlaceholder: a.messageType.isInvisible === !0 ? !0 : null,
                    groupInviteTargetMixinArgs: h && g != null ? {
                        metaGroupInvite: g
                    } : null,
                    individualBotResponseFanoutOrIndividualBotRequestMessageOrIndividualIndividualSingleOrIndividualIndividualFanoutMixinGroupArgs: i,
                    internalTestMixinArgs: e ? {
                        testConfig: "armadillo_express"
                    } : null
                };
                f == null ? void 0 : f.addPoint("send_individual_rpc");
                i = (yield d("WASmaxMessagePublishIndividualRPC").sendIndividualRPC(i));
                if (i.name === "IndividualResponseSuccess") {
                    var q;
                    q = ((q = i.value.deviceListStaleMixin) == null ? void 0 : q.phash) != null ? {
                        type: "mismatch",
                        local: null,
                        server: i.value.deviceListStaleMixin.phash
                    } : {
                        type: "ok"
                    };
                    var r = i.value.serverFrankingTagMixin != null && c != null ? babelHelpers["extends"]({}, c, {
                        reportingTag: i.value.serverFrankingTagMixin.frankingReportingTagElementValue
                    }) : null;
                    return {
                        type: "success",
                        ts: d("WATimeUtils").castToUnixTime(i.value.t),
                        phash: q,
                        count: null,
                        reportingMeta: r
                    }
                } else {
                    i.name;
                    return {
                        type: "error",
                        errorCode: parseInt(i.value.error, 10),
                        backoff: parseInt((q = i.value.messageNackRetryAttributesMixin) == null ? void 0 : q.backoff, 10),
                        applicationError: (r = i.value.applicationNegativeAckMixin) == null ? void 0 : r.applicationError
                    }
                }
            }
            q = a.messageType.isInvisible === !0 ? "false" : d("WAWap").DROP_ATTR;
            i = b.participant != null ? d("WAWap").JID(b.participant) : d("WAWap").DROP_ATTR;
            r = b.phash != null && b.type === "group" ? d("WAWap").CUSTOM_STRING(b.phash) : d("WAWap").DROP_ATTR;
            var s = a.messageType.type === "text" && a.messageType.isRevoked ? d("WAWap").CUSTOM_STRING("7") : d("WAWap").DROP_ATTR;
            h = !h || g == null ? null : d("WAWap").wap("meta", {
                group_invite: d("WAWap").CUSTOM_STRING(g)
            });
            g = e ? d("WAWap").wap("test", {
                config: d("WAWap").CUSTOM_STRING("armadillo_express")
            }) : null;
            e = a.messageType.isInvisible === !0 ? d("WAWap").wap("meta", {
                "decrypt-fail": "hide"
            }) : null;
            var t = a.deviceIdentity != null ? d("WAWap").wap("device-identity", null, a.deviceIdentity) : null,
                u = (c == null ? void 0 : c.frankingTag) != null ? d("WAWap").wap("franking", null, d("WAWap").wap("franking_tag", null, c.frankingTag)) : null,
                v = null;
            b.participants != null && (v = d("WAWap").wap("participants", null, b.participants.map(function(a) {
                return j(a)
            })));
            var w = null;
            b.message != null && (w = j(b.message, !0));
            q = d("WAWap").wap("message", {
                device_fanout: q,
                edit: s,
                id: d("WAWap").CUSTOM_STRING(a.externalId),
                participant: i,
                phash: r,
                to: d("WAWap").JID(b.messageTo),
                type: d("WAWap").CUSTOM_STRING(a.messageType.type)
            }, h, u, v, w, e, t, g);
            f == null ? void 0 : f.addPoint("send_stanza_and_return_ack");
            s = (yield d("WADeprecatedSendIq").deprecatedSendStanzaAndReturnAck(q, {
                id: a.externalId,
                "class": "message",
                from: b.messageTo,
                participant: b.participant != null ? b.participant : null
            }));
            f == null ? void 0 : f.addPoint("send_msg_ack_parser");
            i = k.parse(s);
            if (i.success) {
                f == null ? void 0 : f.addPoint("send_msg_ack_parser_success");
                r = i.success;
                h = r.errorCode;
                u = r.applicationError;
                v = r.backoff;
                if (h == null) {
                    w = i.success;
                    e = w.ts;
                    t = w.phash;
                    g = w.count;
                    a = c != null ? babelHelpers["extends"]({}, c, {
                        reportingTag: (q = i.success.reportingMeta) == null ? void 0 : q.reportingTag
                    }) : null;
                    return {
                        type: "success",
                        ts: e,
                        phash: t == null || t === b.phash ? {
                            type: "ok"
                        } : {
                            type: "mismatch",
                            local: b.phash,
                            server: t
                        },
                        count: g,
                        reportingMeta: a
                    }
                } else {
                    f == null ? void 0 : f.addPoint("send_msg_ack_parser_failed");
                    return {
                        type: "error",
                        errorCode: h,
                        applicationError: u,
                        backoff: v
                    }
                }
            } else return {
                type: "parsing_error"
            }
        });
        return i.apply(this, arguments)
    }

    function j(a, b) {
        b === void 0 && (b = !1);
        var c = d("WAWap").wap("enc", {
            count: a.count != null ? d("WAWap").INT(a.count) : d("WAWap").DROP_ATTR,
            mediatype: a.mediaType != null ? d("WAWap").CUSTOM_STRING(a.mediaType) : d("WAWap").DROP_ATTR,
            type: d("WAWap").CUSTOM_STRING(a.type),
            v: d("WAWap").CUSTOM_STRING(a.v)
        }, a.ciphertext);
        if (b || a.encType === "group") return c;
        else return d("WAWap").wap("to", {
            jid: d("WAWap").DEVICE_JID(a.to)
        }, c)
    }
    var k = new(c("WADeprecatedWapParser"))("sendMsgAck", function(a) {
        a.assertTag("ack");
        return {
            count: a.maybeAttrInt("count"),
            errorCode: a.maybeAttrInt("error"),
            phash: a.maybeAttrString("phash"),
            applicationError: a.maybeAttrInt("application_error"),
            ts: a.attrTime("t"),
            reportingMeta: d("WAParseFranking").parseFrankingNode(a.maybeChild("franking")),
            backoff: a.maybeAttrInt("backoff")
        }
    });

    function l(a, b) {
        if (a.messageType.type === "reaction") return {
            isContentTypeReaction: !0
        };
        if (a.messageType.type === "text") return {
            isContentTypeText: !0
        };
        a.messageType.type;
        if (b.mediaType != null) {
            b = {
                contentTypeMediaOrMedianotifyMixinGroupArgs: {
                    isContentTypeMedia: !0
                },
                encMediaTypeEncMediaTypeOrEncMediaTypeDeprecatedMixinGroupArgs: {
                    encMediaType: {
                        encMediatype: b.mediaType
                    }
                }
            };
            return {
                contentTypeMediaSingle: b
            }
        }
        d("WALogger").ERROR(h(), a.messageType.mediaType);
        return {
            isContentTypeText: !0
        }
    }

    function m(a, b) {
        a = a != null ? {
            encCount: a
        } : null;
        b = b != null ? {
            messageRecipient: b
        } : null;
        return {
            encRetryMixinArgs: a,
            individualIndividualRetryToPeerMixinArgs: b
        }
    }

    function n(a) {
        return {
            encType: a.type,
            encElementValue: a.ciphertext
        }
    }

    function o(a) {
        return a.v === "2" ? {
            isEncVersion2: !0
        } : {
            isEncVersion3: !0
        }
    }

    function p(a) {
        return a.type === "text" && a.isRevoked ? {
            isRevoke: !0
        } : null
    }
    g.sendStanza = a;
    g.createEncWapNode = j
}), 98);
__d("WASendMsgInternal", ["Promise", "WABridge", "WADevicesState", "WAEncGroupMsg", "WAEncUserMsg", "WAGlobals", "WAJids", "WALogger", "WAMarkSenderKeyAsSentApi", "WAOdsEnums", "WAQueryGroups", "WAResultOrError", "WASendMsgRPC", "asyncToGeneratorRuntime", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Got phash mismatch, local[", "] server[", "]"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error during send message post-processing. Err: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["MAWSendMsg Failed to encrypt message for ", " message"]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendMessage ack success is true, error: ", ", chatType:", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendMessage ack success is false, chatType:", ""]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg -- encryptChatMessage -- finish encrypt group message"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg -- encryptChatMessage -- group message"]);
        o = function() {
            return a
        };
        return a
    }
    var p = 10002,
        q = 10009;

    function a(a, b, c) {
        return r.apply(this, arguments)
    }

    function r() {
        r = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c, e) {
            var f;
            e === void 0 && (e = !1);
            B(a, c);
            var g = e ? 3 : 2,
                i = function(b) {
                    return a.type === "chat" ? w(a, c, g, {
                        cryptoManager: b
                    }) : u(a, {
                        cryptoManager: b
                    }, g)
                },
                l = (yield d("WAGlobals").getWaOneQueue().enqueue(function(a) {
                    a = a.cryptoManager;
                    return i(a)
                }, {
                    operationType: "encrypt",
                    flush: !0
                })),
                m = l.success ? l.value.type : l.error;
            c == null ? void 0 : c.addPoint("finish_encrypt", {
                string: {
                    chatType: m
                }
            });
            if (l.success === !1) {
                d("WAGlobals").getConfig().sendMsgWithoutJob() === !1 && (c == null ? void 0 : c.endFail("fail_encrypt"));
                d("WALogger").ERROR(k(), m);
                return d("WAResultOrError").makeError({
                    type: "encryption-error"
                })
            }
            l = l.value;
            c == null ? void 0 : c.addPoint("sending_stanza_start", {
                string: {
                    encryptionType: l.type
                },
                "int": {
                    ciphertextByteLength: (f = (f = (f = l.message) == null ? void 0 : (f = f.ciphertext) == null ? void 0 : f.length) != null ? f : (f = l.participants) == null ? void 0 : (f = f[0].ciphertext) == null ? void 0 : f.length) != null ? f : 0
                }
            });
            f = (yield d("WASendMsgRPC").sendStanza(a, l, a.reportingMeta, e));
            c == null ? void 0 : c.addPoint("sending_stanza_end");
            if (f.type === "success") {
                c == null ? void 0 : c.addPoint("send_stanza_success");
                try {
                    e = (yield(h || (h = b("Promise"))).all([x(a, l, f, c), z(l)]));
                    e = e[0];
                    c == null ? void 0 : c.addPoint("mark_sender_key_sent");
                    return d("WAResultOrError").makeResult({
                        baseKey: (l = l.message) == null ? void 0 : l.baseKey,
                        reportingMeta: null,
                        serverTs: f.ts,
                        meta: {
                            pOrDhashMismatch: e
                        }
                    })
                } catch (a) {
                    c == null ? void 0 : c.addPoint("send_stanza_failed");
                    d("WALogger").ERROR(j(), a.message);
                    return d("WAResultOrError").makeError({
                        type: "unknown-error"
                    })
                }
            }
            f.type;
            C(f, m, c);
            f.applicationError === p && (yield d("WAGlobals").getDependencies().handleReachabilityErrorAdminMsg(a.chat));
            if (f.type === "error") {
                l = f.errorCode != null && f.errorCode >= 500;
                if (f.backoff != null || l) return d("WAResultOrError").makeError({
                    type: "retryable-error",
                    backoff: f.backoff
                });
                else return d("WAResultOrError").makeError({
                    type: "non-retryable-error",
                    applicationErrorCode: f.applicationError
                })
            }
            return d("WAResultOrError").makeError({
                type: "unknown-error"
            })
        });
        return r.apply(this, arguments)
    }

    function s(a) {
        d("WADevicesState").getDevicesState().reset([a]);
        return d("WADevicesState").getDevicesState().waitForUserDevices([a], "SendMsgUtil_recoverUser", !0)
    }

    function t(a, b) {
        return d("WAJids").switchOnChatJidType(b, {
            interopUser: s,
            msgrUser: s,
            lidUser: s,
            phoneUser: s,
            group: function(b) {
                return d("WAQueryGroups").queryGroups(a, {
                    type: "array",
                    groups: [b]
                })
            }
        })
    }

    function u(a, b, c) {
        return v.apply(this, arguments)
    }

    function v() {
        v = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            var e = a.chat,
                f = a.to,
                g = a.messageBytes,
                h = a.messageType,
                i = a.count,
                j = a.sessionInfo,
                k = a.identityKey,
                l = (yield d("WAEncUserMsg").encryptDeviceJidMessage(f, {
                    type: "message",
                    chat: e,
                    messageBytes: g,
                    messageType: h,
                    applicationPayloadVersion: c
                }, b, i, j, k));
            return d("WAJids").switchOnUserChatJidType(e, {
                user: function(b) {
                    return l != null ? d("WAResultOrError").makeResult({
                        type: "direct_user",
                        messageTo: a.to,
                        message: l,
                        recipient: d("WAGlobals").isPeerDevice(a.to) ? b : null
                    }) : d("WAResultOrError").makeError("direct_user")
                },
                group: function(b) {
                    return l != null ? d("WAResultOrError").makeResult({
                        type: "direct_group",
                        messageTo: b,
                        participant: a.to,
                        message: l
                    }) : d("WAResultOrError").makeError("direct_group")
                }
            })
        });
        return v.apply(this, arguments)
    }

    function w(a, c, e, f) {
        var g = a.recipients,
            h = a.messageBytes,
            i = a.messageType,
            j = a.chat,
            k = a.icdcInfo;
        return d("WAJids").switchOnUserChatJidType(j, {
            user: function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    var b = (yield d("WAEncUserMsg").encryptUserMsg(g, {
                            type: "message",
                            messageBytes: h,
                            messageType: i,
                            chat: a,
                            applicationPayloadVersion: e
                        }, k, f, c)),
                        j = b.participants;
                    return j != null && j.length > 0 ? d("WAResultOrError").makeResult({
                        type: "user",
                        messageTo: a,
                        participants: j,
                        phash: b.phash
                    }) : d("WAResultOrError").makeError("user")
                });

                function j(b) {
                    return a.apply(this, arguments)
                }
                return j
            }(),
            group: function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                    d("WALogger").LOG(o());
                    var b = (yield d("WAEncGroupMsg").encryptGroupMsg(a, g, h, i, f, c));
                    d("WALogger").LOG(n());
                    var e = b.participants,
                        j = b.encNode;
                    return e == null && j == null ? d("WAResultOrError").makeError("group") : d("WAResultOrError").makeResult({
                        type: "group",
                        messageTo: a,
                        participants: e,
                        message: j,
                        senderKeyDistributionInfo: b.senderKeyDistributionInfo,
                        phash: b.phash
                    })
                });

                function e(b) {
                    return a.apply(this, arguments)
                }
                return e
            }()
        })
    }

    function x(a, b, c, d) {
        return y.apply(this, arguments)
    }

    function y() {
        y = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c, e) {
            if (c.type !== "success") return !1;
            c = c.phash;
            if (c.type === "mismatch") {
                d("WALogger").LOG(i(), c.local, c.server);
                d("WABridge").getBridge().fireAndForget("event", "odsBumpEntityKey", {
                    entity: d("WAOdsEnums").Entity.PHASH_MISMATCH,
                    key: b.type
                });
                yield t(e, a.chat);
                e == null ? void 0 : e.addPoint("participant_recovery_finished");
                return !0
            }
            return !1
        });
        return y.apply(this, arguments)
    }

    function z(a) {
        return A.apply(this, arguments)
    }

    function A() {
        A = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            if (a.senderKeyDistributionInfo != null) {
                a = a.senderKeyDistributionInfo;
                var b = a.group,
                    c = a.senderKeyId;
                a = a.knowsSenderKey;
                yield d("WAMarkSenderKeyAsSentApi").markSenderKeyAsSent(b, c, a)
            }
        });
        return A.apply(this, arguments)
    }

    function B(a, b) {
        var c = 0;
        a.type === "chat" && (c = a.recipients.reduce(function(a, b) {
            return a + b.devicesInfo.length
        }, 0));
        var d = a.messageType.type === "text" && a.messageType.isRevoked;
        d = d ? "revoke" : a.messageType.type;
        b == null ? void 0 : b.addPoint("start_encrypt", {
            string: {
                sentMessageType: d
            },
            "int": {
                numDevices: c
            },
            bool: {
                isInvisibleMsg: a.messageType.type === "text" && a.messageType.isInvisible === !0
            }
        })
    }

    function C(a, b, e) {
        var f = c("gkx")("5178");
        if (a.type === "success") return;
        a.type === "parsing_error" && (d("WALogger").ERROR(m(), b), e == null ? void 0 : e.addPoint("ack_parse_fail"));
        var g = a.errorCode;
        a = a.applicationError;
        a === p && (e == null ? void 0 : e.addPoint("reachability_error_code"));
        d("WALogger").ERROR(l(), g, b);
        g != null && (e == null ? void 0 : e.addPoint("ack_success_error_" + g, {
            "int": {
                applicationError: a
            }
        }));
        if (f && (a === p || a === q)) {
            d("WAGlobals").getConfig().sendMsgWithoutJob() === !1 && (e == null ? void 0 : e.endSuccess());
            return
        }
        d("WAGlobals").getConfig().sendMsgWithoutJob() === !1 && (e == null ? void 0 : e.endFail("failed"))
    }
    g.sendMessage = a
}), 98);
__d("WASentBytesCacheApi", ["MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c = (a = d("WADbTransactor")).makeSignalTransactor({
        sentBytesCache: (b = d("MAWTransactionMode")).READWRITE
    }, "deleteSentBytes", function(a) {
        return function(b) {
            return a.sentBytesCache.bulkDelete(b)
        }
    });
    e = a.makeSignalTransactor({
        sentBytesCache: b.READONLY
    }, "loadExpired", function(a) {
        return function(b) {
            return a.sentBytesCache.where("ts").belowOrEqual(b).toArray().then(function(a) {
                return a.map(function(a) {
                    return a.waMsgId
                })
            })
        }
    });
    f = a.makeSignalTransactor({
        sentBytesCache: b.READONLY
    }, "loadSentBytes", function(a) {
        return function(b) {
            return a.sentBytesCache.bulkGet(b).then(function(a) {
                return a.filter(Boolean)
            })
        }
    });
    d = a.makeSignalTransactor({
        sentBytesCache: b.READWRITE
    }, "saveSentBytes", function(a) {
        return function(b) {
            return a.sentBytesCache.put(b).then(function() {})
        }
    });
    g.deleteSentBytes = c;
    g.loadExpired = e;
    g.loadSentBytes = f;
    g.saveSentBytes = d
}), 98);
__d("WASentBytesCache", ["WAGlobals", "WAJids", "WAMsg", "WASentBytesCacheApi", "WATagsLogger", "WATimeUtils", "WAWaitForUserUnblocked", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["It fails to bulkLoadIdentities: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to prune sent bytes: ", ""]);
        i = function() {
            return a
        };
        return a
    }
    var j = d("WATagsLogger").TAGS(["SentBytesCache"]),
        k = 30 * 24 * 60 * 60;
    c = function() {
        function a() {
            var a = this;
            void d("WAWaitForUserUnblocked").waitForUserUnblocked().then(function() {
                a.$1()["catch"](function(a) {
                    j.ERROR(i(), a)
                })
            })
        }
        var c = a.prototype;
        c.loadSentBytes = function(a) {
            return d("WASentBytesCacheApi").loadSentBytes(a)
        };
        c.getMsgsForRetry = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                var b = Array.from(new Set(a.map(function(a) {
                        a = a.deviceJid;
                        return d("WAJids").extractUserJid(a)
                    }))),
                    c = new Map();
                try {
                    c = (yield d("WAGlobals").getWaOneQueue().enqueue(function(a) {
                        a = a.cryptoManager;
                        return a.storage.bulkLoadIdentities(b)
                    }, {
                        operationType: "retries_load_identities",
                        flush: !1,
                        afterInit: !0
                    }))
                } catch (a) {
                    j.ERROR(h(), a.toString())
                }
                var e = (yield this.loadSentBytes(a.map(function(a) {
                    a = a.protocolMsgId;
                    return d("WAMsg").craftWAMsgIdString({
                        author: a.author,
                        chat: a.chat,
                        externalId: a.externalId
                    })
                })));
                return a.map(function(a) {
                    var b = a.deviceJid,
                        f = a.protocolMsgId,
                        g = d("WAMsg").craftWAMsgIdString({
                            author: f.author,
                            chat: f.chat,
                            externalId: f.externalId
                        });
                    f = (f = c.get(d("WAJids").extractUserJid(b))) == null ? void 0 : f.get(b);
                    if (f == null) return {
                        type: "unauthorized"
                    };
                    b = e.find(function(a) {
                        return a.waMsgId === g
                    });
                    if (b == null) return {
                        type: "missing"
                    };
                    else if (!d("WATimeUtils").happenedWithin(b.ts, k)) return {
                        type: "unauthorized"
                    };
                    return {
                        frankingKey: b.frankingKey,
                        frankingVersion: b.frankingVersion,
                        messageBytes: b.messageBytes,
                        messageType: b.messageType,
                        protocolMsgId: b.protocolMsgId,
                        retryCount: a.retryCount + 1,
                        type: "unacked"
                    }
                })
            });

            function c(b) {
                return a.apply(this, arguments)
            }
            return c
        }();
        c.saveSentBytes = function(a) {
            return d("WASentBytesCacheApi").saveSentBytes(a)
        };
        c.$1 = function() {
            return d("WASentBytesCacheApi").loadExpired(d("WATimeUtils").pastUnixTime(k)).then(function(a) {
                return d("WASentBytesCacheApi").deleteSentBytes(a)
            })
        };
        return a
    }();
    var l = new c();

    function a() {
        return l
    }
    g.SentBytesCache = c;
    g.sentBytesCache = a
}), 98);
__d("WASendMsgUtilV2", ["Promise", "WADevicesState", "WAGenReportingMeta", "WAGetDevices", "WAGlobals", "WAJids", "WALoadReceiptApi", "WALogger", "WAMsg", "WAResultOrError", "WASaveReceiptApi", "WASendMsgInternal", "WASentBytesCache", "WATimeUtils", "asyncToGeneratorRuntime", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error loading current device identity ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendWrittenMsg failed to save sent bytes to cache: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[WASendMsgUtilV2] Failed to calculate ICDC info, type: ", " error: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error during get devices for users with missing icdc info: ", ""]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Triggering getDevices for users with missing icdc info."]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Trying to send a message with no recipients, but it is a self thread"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Trying to send a message with no recipients"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Trying to send a message that does not have a receipt in db"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Failed to save receipt for message with error ", ""]);
        q = function() {
            return a
        };
        return a
    }

    function r() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Error during get devices before sending: ", ""]);
        r = function() {
            return a
        };
        return a
    }

    function s(a) {
        return (h || (h = b("Promise"))).resolve()
    }

    function t(a, b) {
        return d("WADevicesState").getDevicesState().waitForUserDevices(Array.from(new Set([a, d("WAGlobals").getMyUserJid()])), "GetDevicesBeforeSend: " + b)
    }

    function u(a, c) {
        a = c.chatJid;
        var e = c.reason;
        return d("WAJids").switchOnChatJidType(a, {
            group: function(a) {
                return s(a)
            },
            interopUser: function(a) {
                return t(a, e)
            },
            lidUser: function(a) {
                return t(a, e)
            },
            msgrUser: function(a) {
                return t(a, e)
            },
            phoneUser: function(a) {
                return t(a, e)
            }
        })["catch"](function(a) {
            d("WALogger").ERROR(r(), a);
            return (h || (h = b("Promise"))).resolve()
        })
    }

    function v(a, b) {
        return w.apply(this, arguments)
    }

    function w() {
        w = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            var c = a.messagePayload;
            a = a.loadThreadParticipants;
            var e = {
                    author: c.protocolMsgId.author,
                    chat: c.protocolMsgId.chat,
                    externalId: c.protocolMsgId.externalId
                },
                f = (yield d("WALoadReceiptApi").loadReceipt(e));
            if (f.success) return f;
            b == null ? void 0 : b.addPoint("get_devices_before_send_start");
            yield u(void 0, {
                chatJid: c.protocolMsgId.chat,
                reason: "prepareReceipt"
            });
            b == null ? void 0 : b.addPoint("get_devices_before_send_end");
            var g = (yield a(c.protocolMsgId.chat));
            b == null ? void 0 : b.addPoint("get_identities_start");
            f = (yield d("WAGlobals").getWaOneQueue().enqueue(function(a) {
                a = a.cryptoManager;
                return a.storage.bulkLoadIdentities(g)
            }, {
                flush: !1,
                afterInit: !0,
                operationType: "prepare_receipt_load_identities"
            }).then(function(a) {
                var b = new Map();
                for (a of a) {
                    a[0];
                    var c = a[1];
                    for (c of c) {
                        var e = c[0],
                            f = c[1];
                        if (e === d("WAGlobals").getMyDeviceJid()) continue;
                        b.set(e, {
                            pubKey: f
                        })
                    }
                }
                return b
            }));
            b == null ? void 0 : b.addPoint("get_identities_end");
            a = new Set();
            c = {
                permittedIdentitiesPerDevice: f,
                recipientDevices: a,
                id: e
            };
            b == null ? void 0 : b.addPoint("save_receipts_start");
            yield d("WASaveReceiptApi").saveReceipt(c)["catch"](function(a) {
                b == null ? void 0 : b.addPoint("save_receipts_fail");
                d("WALogger").ERROR(q(), a);
                return d("WAResultOrError").makeError("missing-receipt")
            });
            b == null ? void 0 : b.addPoint("save_receipts_end");
            return d("WAResultOrError").makeResult(c)
        });
        return w.apply(this, arguments)
    }

    function a(a, b, c) {
        return x.apply(this, arguments)
    }

    function x() {
        x = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, c, e) {
            a = c.messagePayload;
            var f = c.loadThreadParticipants,
                g = c.sendIdentity,
                i = g === void 0 ? !1 : g;
            g = c.isInstamadillo;
            c = g === void 0 ? !1 : g;
            e == null ? void 0 : e.addPoint("prepare_receipt_start");
            g = (yield v({
                messagePayload: a,
                loadThreadParticipants: f
            }, e));
            if (g.success === !1) {
                e == null ? void 0 : e.addPoint("prepare_receipt_fail");
                d("WALogger").ERROR(p());
                return d("WAResultOrError").makeError({
                    type: "missing-receipt"
                })
            }
            e == null ? void 0 : e.addPoint("prepare_receipt_end");
            f = g.value;
            var q = a.frankingKey,
                r = a.frankingVersion,
                s = a.messageBytes,
                t = a.messageType,
                u = a.protocolMsgId;
            g = y(f.permittedIdentitiesPerDevice);
            a = t.type === "text" && t.invitedParticipantUserJid != null ? g.filter(function(a) {
                return a.user === t.invitedParticipantUserJid || a.user === d("WAGlobals").getMyUserJid()
            }) : g;
            e == null ? void 0 : e.addPoint("recipients-calculated", {
                "int": {
                    recipientsCount: a.length
                },
                string: {
                    msgType: t.type
                }
            });
            f = t.type === "text" && t.invitedParticipantUserJid != null ? t.invitedParticipantUserJid : u.chat;
            g = u.chat === d("WAGlobals").getMyUserJid();
            if (a.length === 0 && !g) {
                d("WALogger").ERROR(o());
                return d("WAResultOrError").makeError({
                    type: "no-recipients"
                })
            } else if (a.length === 0 && g) {
                d("WALogger").LOG(n());
                d("WAGlobals").getConfig().sendMsgWithoutJob() === !1 && (e == null ? void 0 : e.endSuccess());
                return d("WAResultOrError").makeResult({
                    baseKey: null,
                    reportingMeta: null,
                    serverTs: d("WATimeUtils").unixTime()
                })
            }
            var w = new Set(a.map(function(a) {
                return a.user
            }));
            w.add(d("WAGlobals").getMyUserJid());
            e == null ? void 0 : e.addPoint("icdc_start");
            g = (yield d("WAGlobals").getWaOneQueue().enqueue(function() {
                var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                    b = b.cryptoManager;
                    var a = (yield b.storage.calculateICDC(Array.from(w)));
                    b = i ? yield z(b): null;
                    return {
                        icdcInfoResult: a,
                        deviceIdentity: b
                    }
                });
                return function(b) {
                    return a.apply(this, arguments)
                }
            }(), {
                operationType: "calc_icdc",
                flush: !0,
                afterInit: !0
            }));
            var x = g.icdcInfoResult;
            g = g.deviceIdentity;
            e == null ? void 0 : e.addPoint("icdc_end");
            var A = x.success ? x.value : {
                    icdcInfo: [],
                    usersWithMissingICDC: new Set()
                },
                B = A.icdcInfo;
            A = A.usersWithMissingICDC;
            A = x.success === !0 ? A : w;
            A.size > 0 && (d("WALogger").LOG(m()), d("WAGetDevices").getDevices(null, {
                ignoreDhash: !0,
                reason: "missing-icdc-info",
                users: A
            })["catch"](function(a) {
                d("WALogger").ERROR(l(), a)
            }));
            x.success === !1 && (e == null ? void 0 : e.addPoint("icdc-calc-error", {
                string: {
                    icdcError: x.error
                }
            }), d("WALogger").ERROR(k(), x.error, x.payload));
            A = (yield t.isRevoked === !0 ? (h || (h = b("Promise"))).resolve(null) : d("WAGenReportingMeta").genReportingMeta(s.bytes, q, r));
            return d("WASendMsgInternal").sendMessage({
                type: "chat",
                messageBytes: s,
                chat: f,
                deviceIdentity: g,
                messageType: t,
                protocolMsgId: u,
                externalId: u.externalId,
                icdcInfo: B,
                recipients: a,
                reportingMeta: A
            }, e, c).then(function(a) {
                if (a.success) return d("WASentBytesCache").sentBytesCache().saveSentBytes({
                    ts: a.value.serverTs,
                    frankingKey: q,
                    frankingVersion: r,
                    messageBytes: s,
                    messageType: t,
                    protocolMsgId: u,
                    waMsgId: d("WAMsg").craftWAMsgIdString({
                        author: u.author,
                        chat: u.chat,
                        externalId: u.externalId
                    })
                })["catch"](function(a) {
                    d("WALogger").ERROR(j(), a)
                }).then(function() {
                    return a
                });
                else return a
            })
        });
        return x.apply(this, arguments)
    }

    function y(a) {
        var b = new Map();
        a.forEach(function(a, c) {
            a = a.pubKey;
            var e = d("WAJids").extractUserJid(c);
            a = {
                identity: a,
                jid: c
            };
            c = b.get(e) || [];
            c.push(a);
            b.set(e, c)
        });
        return Array.from(b, function(a) {
            var b = a[0];
            a = a[1];
            return {
                devicesInfo: a,
                user: b
            }
        })
    }

    function z(a) {
        return A.apply(this, arguments)
    }

    function A() {
        A = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            try {
                a = (yield a.storage.loadIdentities(d("WAGlobals").getMyUserJid()));
                a = a.get(d("WAGlobals").getMyDeviceJid());
                if (a != null) return a;
                throw c("err")("missing-identity")
            } catch (a) {
                d("WALogger").ERROR(i(), a)
            }
        });
        return A.apply(this, arguments)
    }
    g.getDevicesBeforeSend = u;
    g.sendChatMessage = a
}), 98);
__d("WASetMetaApi", ["MAWDexieTable", "MAWTransactionMode", "WADbTransactor"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WADbTransactor").makeSignalTransactor({
        meta: d("MAWTransactionMode").READWRITE
    }, "setMeta", function(a) {
        return function(b) {
            return d("MAWDexieTable").dexieAll(Object.entries(b).map(function(b) {
                var c, d = b[0];
                b = b[1];
                return a.meta.put({
                    key: d,
                    value: (c = {}, c[d] = b, c)
                })
            })).then(function() {})
        }
    });
    g.setMeta = a
}), 98);
__d("WASetMetaApiV2", ["WormDb"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        return d("WormDb").getDb().runInTransaction(["meta"], "readwrite", function(b) {
            return b.stores.meta.bulkPut(Object.entries(a).map(function(a) {
                var b, c = a[0];
                a = a[1];
                return {
                    key: c,
                    value: (b = {}, b[c] = a, b)
                }
            }))
        }, d("WormDb").signalOp("setMeta"))
    };
    g.setMeta = a
}), 98);
__d("WASetClockSkewApi", ["WADexieToWormMigration", "WASetMetaApi", "WASetMetaApiV2"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        a = a.clockSkew;
        return d("WADexieToWormMigration").isWorm("WASetClockSkewApi") ? d("WASetMetaApiV2").setMeta({
            clockSkew: a
        }) : d("WASetMetaApi").setMeta({
            clockSkew: a
        })
    };
    g.setClockSkew = a
}), 98);
__d("WASendPing", ["WAComms", "WALogger", "WASetClockSkewApi", "WATimeUtils", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["sendPing: sending"]);
        h = function() {
            return a
        };
        return a
    }

    function a() {
        d("WALogger").LOG(h()), d("WAComms").sendPing()
    }

    function c(a, b) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            a = b.clockSkew;
            d("WATimeUtils").setClockSkew(a);
            yield d("WASetClockSkewApi").setClockSkew({
                clockSkew: a
            })
        });
        return i.apply(this, arguments)
    }
    g.sendPing = a;
    g.updateClockSkew = c
}), 98);
__d("WASyncAbProps", ["WAAbPropsSync", "WALogger", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["Syncing ABProps"]);
        h = function() {
            return a
        };
        return a
    }

    function a(a, b) {
        return i.apply(this, arguments)
    }

    function i() {
        i = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
            b = b.sendHash;
            d("WALogger").LOG(h());
            yield d("WAAbPropsSync").syncAbProps({
                sendHash: b,
                eventFlow: (b = a) != null ? b : void 0
            })
        });
        return i.apply(this, arguments)
    }
    g.syncAbProps = a
}), 98);
__d("WAUploadMedia", ["WABase64", "WABulkPutMediaKeysApi", "WACheckCiphertextInServer", "WACreateRetrier", "WAEncryptAndUploadPlaintext", "WAFindReusableMediaEntry", "WAGlobals", "WAHashUtils", "WALogger", "WAMediaUtils", "WAResultOrError", "WATimeUtils", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: no plaintext"]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["uploadMedia: media is not on the server, start uploading"]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: no plaintext"]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["uploadMedia: media is partially on the server, start uploading from byteOffset ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["uploadMedia: media is on the server"]);
        l = function() {
            return a
        };
        return a
    }

    function m() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["uploadMedia: resume/exist check exhausted available retries"]);
        m = function() {
            return a
        };
        return a
    }

    function n() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["uploadMedia: async upload"]);
        n = function() {
            return a
        };
        return a
    }

    function o() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["encryptAndUploadPlaintext: no plaintext"]);
        o = function() {
            return a
        };
        return a
    }

    function p() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["uploadMedia: no media entry found, need to upload media"]);
        p = function() {
            return a
        };
        return a
    }

    function q() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["uploadMedia: fail to gather media routes"]);
        q = function() {
            return a
        };
        return a
    }

    function a(a) {
        return r.apply(this, arguments)
    }

    function r() {
        r = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            a.chatJid;
            var b = a.filename,
                c = a.hash,
                e = a.mediaTypeDetails,
                f = a.protocolMsgId,
                g = a.size,
                r = a.uploadMediaMetric,
                t = a.getMediaKnownEntries,
                u = a.getMediaPlaintext,
                v = a.updateMediaEntryForMsg,
                w = a.updateMediaEntryForOptimisticUpload;
            a = a.getDownloadableThumbnailForMedia;
            var x;
            e.type === "regular" ? x = e.mediaType : (x = "preview", r == null ? void 0 : r.addAnnotations({
                string: {
                    fullSizeMediaType: e.messageType
                }
            }));
            r == null ? void 0 : r.addPoint("upload_retrier_start");
            var y = (yield d("WACreateRetrier").createUploadRetrier(x, r));
            if (!y.success) {
                d("WALogger").WARN(q());
                r == null ? void 0 : r.endFail("failToGatherMediaRoutes");
                return y
            }
            y = y.value;
            r == null ? void 0 : r.addPoint("update_media_entry_fn_start");
            v = s(f, c, v, w);
            r == null ? void 0 : r.addPoint("update_media_entry_fn_end");
            w = (yield t(c));
            t = d("WAFindReusableMediaEntry").findReusableMediaEntryForArmadillo(f, w);
            if (t == null) {
                d("WALogger").LOG(p());
                f = d("WAMediaUtils").createMediaKey();
                w = d("WAMediaUtils").createUploadToken();
                var z = d("WATimeUtils").unixTime();
                r == null ? void 0 : r.addPoint("get_media_plaintext_start");
                var A = (yield u(c));
                if (A == null) {
                    d("WALogger").ERROR(o());
                    r == null ? void 0 : r.endFail("missingPlaintext");
                    return d("WAResultOrError").makeError("no-plaintext")
                }
                r == null ? void 0 : r.addPoint("encrypt_and_upload_plaintext_start");
                return d("WAEncryptAndUploadPlaintext").encryptAndUploadPlaintext({
                    size: g,
                    filename: b,
                    mediaKey: f,
                    mediaKeyTimestamp: z,
                    mediaTypeDetails: e,
                    mediaUploadQplFlow: r,
                    plaintext: A,
                    plaintextHash: c,
                    updateMediaEntry: v,
                    uploadRetrier: y,
                    uploadToken: w,
                    getDownloadableThumbnailForMedia: a
                })
            }
            f = t.directPath;
            z = t.downloadableThumbnail;
            A = t.fileEncSha256;
            w = t.fileSha256;
            var B = t.mediaKey,
                C = t.mediaKeyTimestamp,
                D = t.objectId;
            t = t.uploadToken;
            z = {
                directPath: f,
                downloadableThumbnail: z,
                fileEncSha256: A,
                filename: b,
                fileSha256: w || d("WABase64").decodeB64UrlSafe(c),
                mediaKey: B,
                mediaKeyTimestamp: C,
                objectId: D,
                serverMediaType: x,
                size: g,
                uploadToken: t
            };
            if (f != null) {
                d("WALogger").LOG(n());
                yield v(z);
                r == null ? void 0 : r.endSuccess({
                    bool: {
                        reused_media_entry: !0
                    }
                });
                return d("WAResultOrError").makeResult(z)
            }
            r == null ? void 0 : r.addPoint("check_ciphertext_in_server_start");
            w = (yield d("WACheckCiphertextInServer").checkCiphertextInServer(x, A, t, y));
            if (!w.success) {
                d("WALogger").WARN(m());
                r == null ? void 0 : r.endFail("failToUpload");
                return w
            }
            D = w.value;
            if (D.type === "media-found") {
                d("WALogger").LOG(l());
                r == null ? void 0 : r.addAnnotations({
                    bool: {
                        existingMediaFound: !0
                    }
                });
                f = babelHelpers["extends"]({}, z, {
                    directPath: D.directPath,
                    objectId: D.objectId
                });
                yield v(f);
                r == null ? void 0 : r.endSuccess({
                    bool: {
                        reused_media_entry: !0
                    }
                });
                return d("WAResultOrError").makeResult(f)
            } else if (D.type === "media-partial-found") {
                d("WALogger").LOG(k(), D.resumeFromBytes);
                x = D.resumeFromBytes;
                r == null ? void 0 : r.addPoint("get_media_plaintext_start");
                A = (yield u(c));
                if (A == null) {
                    d("WALogger").ERROR(j());
                    r == null ? void 0 : r.endFail("missingPlaintext");
                    return d("WAResultOrError").makeError("no-plaintext")
                }
                r == null ? void 0 : r.addPoint("encrypt_and_upload_plaintext_start");
                return d("WAEncryptAndUploadPlaintext").encryptAndUploadPlaintext({
                    size: g,
                    filename: b,
                    fromOffset: x,
                    mediaKey: B,
                    mediaKeyTimestamp: C,
                    mediaTypeDetails: e,
                    mediaUploadQplFlow: r,
                    plaintext: A,
                    plaintextHash: c,
                    updateMediaEntry: v,
                    uploadRetrier: y,
                    uploadToken: t,
                    getDownloadableThumbnailForMedia: a
                })
            }
            d("WALogger").LOG(i());
            w = d("WATimeUtils").unixTime();
            r == null ? void 0 : r.addPoint("get_media_plaintext_start");
            z = (yield u(c));
            if (z == null) {
                d("WALogger").ERROR(h());
                r == null ? void 0 : r.endFail("missingPlaintext");
                return d("WAResultOrError").makeError("no-plaintext")
            }
            r == null ? void 0 : r.addPoint("encrypt_and_upload_plaintext_start");
            return d("WAEncryptAndUploadPlaintext").encryptAndUploadPlaintext({
                size: g,
                filename: b,
                mediaKey: B,
                mediaKeyTimestamp: w,
                mediaTypeDetails: e,
                mediaUploadQplFlow: r,
                plaintext: z,
                plaintextHash: c,
                updateMediaEntry: v,
                uploadRetrier: y,
                uploadToken: t,
                getDownloadableThumbnailForMedia: a
            })
        });
        return r.apply(this, arguments)
    }

    function s(a, c, e, f) {
        return function() {
            var g = b("asyncToGeneratorRuntime").asyncToGenerator(function*(b) {
                if (d("WAGlobals").getConfig().useProtocolMediaKey()) {
                    var g;
                    g = {
                        directPath: (g = b.directPath) != null ? g : void 0,
                        fbid: (g = b.fbid) != null ? g : void 0,
                        fileEncSha256: b.fileEncSha256,
                        fileSha256: d("WABase64").decodeB64UrlSafe(c),
                        mediaKey: b.mediaKey,
                        mediaKeyTimestamp: b.mediaKeyTimestamp,
                        objectId: (g = b.objectId) != null ? g : void 0,
                        plaintextHash: c,
                        ciphertextHash: d("WAHashUtils").toCiphertextHash(b.fileEncSha256),
                        serverMediaType: b.serverMediaType,
                        sidecar: (g = b.sidecar) != null ? g : void 0,
                        scanLengths: void 0,
                        uploadToken: b.uploadToken,
                        size: void 0
                    };
                    yield d("WABulkPutMediaKeysApi").bulkPutMediaKeys([g])
                }
                var h = d("WAMediaUtils").encodeMediaEntryForUpload(b);
                if (a == null) return f(c, function() {
                    return h
                }, b == null ? void 0 : b.objectId, b == null ? void 0 : b.serverMediaType);
                else return e(c, a, function() {
                    return h
                }, b == null ? void 0 : b.objectId, b == null ? void 0 : b.serverMediaType)
            });

            function h(a) {
                return g.apply(this, arguments)
            }
            return h
        }()
    }
    g.uploadMedia = a
}), 98);