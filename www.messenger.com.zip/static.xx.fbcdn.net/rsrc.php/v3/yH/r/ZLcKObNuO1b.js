; /*FB_PKG_DELIM*/

_btldr = {};
//# sourceURL=https://static.xx.fbcdn.net/rsrc.php/v3/yH/r/ZLcKObNuO1b.js