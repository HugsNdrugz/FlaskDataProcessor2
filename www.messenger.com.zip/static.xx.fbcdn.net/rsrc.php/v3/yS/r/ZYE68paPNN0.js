; /*FB_PKG_DELIM*/

__d("ACTSanitizerApiWasm", ["ACTSanitizerApiTypes", "WAArmadilloXMA.pb", "WATagsLogger", "WAWasmModuleCache", "asyncToGeneratorRuntime", "bx", "cr:11151", "encodeProtobuf", "err", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["isXMAValid runtime error: ", ". Final memory allocation: ", ". input page size: ", ". xma target type: ", ""]);
        h = function() {
            return a
        };
        return a
    }

    function i() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["module returned invalid validation result: ", ""]);
        i = function() {
            return a
        };
        return a
    }

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["isMessageTextValid runtime error: ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["instantiateWasm failed with error: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function l() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["instantiateWasm succeeded"]);
        l = function() {
            return a
        };
        return a
    }
    var m = d("WATagsLogger").TAGS(["ACTSanitizerWasm"]);

    function a(a) {
        return n.apply(this, arguments)
    }

    function n() {
        n = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            var e = c("gkx")("7318");
            a = e ? {
                instantiateWasm: function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b) {
                        try {
                            var e = c("bx").getURL(c("bx")("30948"));
                            e = (yield d("WAWasmModuleCache").loadWasmModule(e));
                            e = (yield WebAssembly.instantiate(e, a));
                            m.LOG(l());
                            b(e);
                            return {}
                        } catch (a) {
                            m.ERROR(k(), a.toString());
                            return !1
                        }
                    });

                    function e(b, c) {
                        return a.apply(this, arguments)
                    }
                    return e
                }()
            } : {
                locateFile: function() {
                    return c("bx").getURL(c("bx")("11565"))
                },
                wasmBinary: a
            };
            var f = (yield b("cr:11151")(a));
            return {
                getWasmMemorySize: function() {
                    var a;
                    return (a = f.wasmMemory) == null ? void 0 : a.buffer.byteLength
                },
                isMessageTextValid: function(a) {
                    try {
                        var b = new TextEncoder();
                        b = b.encode(a);
                        a = f._malloc(b.byteLength);
                        f.HEAPU8.set(b, a);
                        b = f._ACTSanitizer_isMessageTextValid(a, b.byteLength);
                        f._free(a);
                        a = d("ACTSanitizerApiTypes").ACTSanitizerValidationResult.cast(b);
                        if (a == null) throw c("err")("ACT Sanitizer WASM module returned invalid validation result");
                        return a
                    } catch (a) {
                        m.ERROR(j(), a.toString());
                        throw a
                    }
                },
                isXMAValid: function(a) {
                    var b, g;
                    try {
                        g = d("encodeProtobuf").encodeProtobuf(d("WAArmadilloXMA.pb").ExtendedContentMessageSpec, a).readByteArray();
                        b = f._malloc(g.byteLength);
                        f.HEAPU8.set(g, b);
                        var j = f._ACTSanitizer_isXMAValid(b, g.byteLength);
                        j = d("ACTSanitizerApiTypes").ACTSanitizerValidationResult.cast(j);
                        if (j == null) {
                            m.ERROR(i(), j);
                            throw c("err")("ACTSanitizerWasm module returned invalid validation result")
                        }
                        return j
                    } catch (b) {
                        m.ERROR(h(), b.toString(), (j = o((j = f.wasmMemory) == null ? void 0 : j.buffer.byteLength)) != null ? j : "unknown", (j = o((j = g) == null ? void 0 : j.byteLength)) != null ? j : "unknown", a.targetType);
                        throw b
                    } finally {
                        e && b != null && f._free(b)
                    }
                }
            }
        });
        return n.apply(this, arguments)
    }

    function o(a) {
        return a == null ? null : Math.ceil(a / 65536)
    }
    g.ACTSanitizerWasm = a
}), 98);