; /*FB_PKG_DELIM*/

__d("LSDeleteThenInsertMessage", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(12).fetch([
                [
                    [a[9]]
                ], "optimistic"
            ]).next().then(function(c, d) {
                var e = c.done;
                c = c.value;
                return e ? b.db.table(12).add({
                    threadKey: a[3],
                    timestampMs: a[5],
                    messageId: a[8],
                    offlineThreadingId: a[9],
                    authorityLevel: a[2],
                    primarySortKey: a[6],
                    senderId: a[10],
                    isAdminMessage: a[12],
                    sendStatus: a[15],
                    sendStatusV2: a[16],
                    text: a[0],
                    subscriptErrorMessage: a[1],
                    secondarySortKey: a[7],
                    stickerId: a[11],
                    messageRenderingType: a[13],
                    isUnsent: a[17],
                    unsentTimestampMs: a[18],
                    mentionOffsets: a[19],
                    mentionLengths: a[20],
                    mentionIds: a[21],
                    mentionTypes: a[22],
                    replySourceId: a[23],
                    replySourceType: a[24],
                    replySourceTypeV2: a[25],
                    replyStatus: a[26],
                    replySnippet: a[27],
                    replyMessageText: a[28],
                    replyToUserId: a[29],
                    replyMediaExpirationTimestampMs: a[30],
                    replyMediaUrl: a[31],
                    replyMediaPreviewWidth: a[33],
                    replyMediaPreviewHeight: a[34],
                    replyMediaUrlMimeType: a[35],
                    replyMediaUrlFallback: a[36],
                    replyCtaId: a[37],
                    replyCtaTitle: a[38],
                    replyAttachmentType: a[39],
                    replyAttachmentId: a[40],
                    replyAttachmentExtra: a[41],
                    isForwarded: a[42],
                    forwardScore: a[43],
                    hasQuickReplies: a[44],
                    adminMsgCtaId: a[45],
                    adminMsgCtaTitle: a[46],
                    adminMsgCtaType: a[47],
                    cannotUnsendReason: a[48],
                    textHasLinks: a[49],
                    viewFlags: a[50],
                    displayedContentTypes: a[51],
                    viewedPluginKey: a[52],
                    viewedPluginContext: a[53],
                    quickReplyType: a[54],
                    hotEmojiSize: a[55],
                    platformXmdEncoded: a[56],
                    replySourceTimestampMs: a[57],
                    ephemeralDurationInSec: a[58],
                    msUntilExpirationTs: a[59],
                    ephemeralExpirationTs: a[60],
                    takedownState: a[61],
                    isCollapsed: a[62],
                    subthreadKey: a[63],
                    botResponseId: a[64],
                    metadataDataclass: a[65],
                    editCount: a[66],
                    isPaidPartnership: a[67],
                    adminSignatureName: a[68],
                    adminSignatureProfileUrl: a[69],
                    adminSignatureCreatorType: a[70],
                    scheduledTimestamp: a[71]
                }) : (d = c.item, b.i64.le(d.authorityLevel, a[2]) ? b.db.table(12).put({
                    threadKey: a[3],
                    timestampMs: a[5],
                    messageId: a[8],
                    offlineThreadingId: a[9],
                    authorityLevel: a[2],
                    primarySortKey: d.primarySortKey,
                    senderId: a[10],
                    isAdminMessage: a[12],
                    sendStatus: a[15],
                    sendStatusV2: a[16],
                    text: a[0],
                    subscriptErrorMessage: a[1],
                    secondarySortKey: d.secondarySortKey,
                    stickerId: a[11],
                    messageRenderingType: a[13],
                    isUnsent: a[17],
                    unsentTimestampMs: a[18],
                    mentionOffsets: a[19],
                    mentionLengths: a[20],
                    mentionIds: a[21],
                    mentionTypes: a[22],
                    replySourceId: a[23],
                    replySourceType: a[24],
                    replySourceTypeV2: a[25],
                    replyStatus: a[26],
                    replySnippet: a[27],
                    replyMessageText: a[28],
                    replyToUserId: a[29],
                    replyMediaExpirationTimestampMs: a[30],
                    replyMediaUrl: a[31],
                    replyMediaPreviewWidth: a[33],
                    replyMediaPreviewHeight: a[34],
                    replyMediaUrlMimeType: a[35],
                    replyMediaUrlFallback: a[36],
                    replyCtaId: a[37],
                    replyCtaTitle: a[38],
                    replyAttachmentType: a[39],
                    replyAttachmentId: a[40],
                    replyAttachmentExtra: a[41],
                    isForwarded: a[42],
                    forwardScore: a[43],
                    hasQuickReplies: a[44],
                    adminMsgCtaId: a[45],
                    adminMsgCtaTitle: a[46],
                    adminMsgCtaType: a[47],
                    cannotUnsendReason: a[48],
                    textHasLinks: a[49],
                    viewFlags: a[50],
                    displayedContentTypes: a[51],
                    viewedPluginKey: a[52],
                    viewedPluginContext: a[53],
                    quickReplyType: a[54],
                    hotEmojiSize: a[55],
                    platformXmdEncoded: a[56],
                    replySourceTimestampMs: a[57],
                    ephemeralDurationInSec: a[58],
                    msUntilExpirationTs: a[59],
                    ephemeralExpirationTs: a[60],
                    takedownState: a[61],
                    isCollapsed: a[62],
                    subthreadKey: a[63],
                    botResponseId: a[64],
                    metadataDataclass: a[65],
                    editCount: a[66],
                    isPaidPartnership: a[67],
                    adminSignatureName: a[68],
                    adminSignatureProfileUrl: a[69],
                    adminSignatureCreatorType: a[70],
                    scheduledTimestamp: a[71]
                }) : b.resolve())
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxDeleteThenInsertMessageStoredProcedure";
    e.exports = a
}), null);
__d("LSInsertAttachmentCta", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(19).add({
                ctaId: a[0],
                attachmentFbid: a[1],
                attachmentIndex: a[2],
                threadKey: a[3],
                messageId: a[5],
                title: a[6],
                type_: a[7],
                platformToken: a[8],
                actionUrl: a[9],
                nativeUrl: a[10],
                urlWebviewType: a[11],
                actionContentBlob: a[12],
                enableExtensions: a[13],
                extensionHeightType: a[14],
                targetId: a[15]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxInsertAttachmentCtaStoredProcedure";
    e.exports = a
}), null);
__d("LSInsertBlobAttachment", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.sequence([function(c) {
                return b.forEach(b.filter(b.db.table(16).fetch([
                    [
                        [a[27], a[32], a[34]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[27]) && b.i64.eq(b.i64.cast([0, 0]), a[28]) && c.messageId === a[32] && c.attachmentFbid === a[34] && b.i64.lt(c.authorityLevel, a[48]) && (b.i64.eq(c.attachmentType, b.i64.cast([0, 2])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 3])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 4])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 5])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 6])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 10])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 14])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 15]))) && b.i64.eq(c.ephemeralMediaState, void 0) && c.isSharable === !1
                }), function(a) {
                    return a["delete"]()
                })
            }, function(c) {
                return b.db.table(16).add({
                    threadKey: a[27],
                    messageId: a[32],
                    attachmentFbid: a[34],
                    filename: a[0],
                    filesize: a[1],
                    hasMedia: a[2],
                    isSharable: !1,
                    playableUrl: a[3],
                    playableUrlFallback: a[4],
                    playableUrlExpirationTimestampMs: a[5],
                    playableUrlMimeType: a[6],
                    dashManifest: a[7],
                    previewUrl: a[8],
                    previewUrlFallback: a[9],
                    previewUrlExpirationTimestampMs: a[10],
                    previewUrlMimeType: a[11],
                    miniPreview: a[13],
                    previewWidth: a[14],
                    previewHeight: a[15],
                    attributionAppId: a[16],
                    attributionAppName: a[17],
                    attributionAppIcon: a[18],
                    attributionAppIconFallback: a[19],
                    attributionAppIconUrlExpirationTimestampMs: a[20],
                    localPlayableUrl: a[21],
                    playableDurationMs: a[22],
                    attachmentIndex: a[23],
                    accessibilitySummaryText: a[24],
                    isPreviewImage: a[25],
                    originalFileHash: a[26],
                    attachmentType: a[29],
                    timestampMs: a[31],
                    offlineAttachmentId: a[33],
                    hasXma: a[35],
                    xmaLayoutType: a[36],
                    xmasTemplateType: a[37],
                    titleText: a[38],
                    subtitleText: a[39],
                    descriptionText: a[40],
                    sourceText: a[41],
                    faviconUrlExpirationTimestampMs: a[42],
                    isBorderless: a[44],
                    previewUrlLarge: a[45],
                    samplingFrequencyHz: a[46],
                    waveformData: a[47],
                    authorityLevel: a[48]
                })
            }])
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxInsertBlobAttachmentStoredProcedure";
    e.exports = a
}), null);
__d("LSInsertXmaAttachment", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.sequence([function(c) {
                return b.forEach(b.filter(b.db.table(16).fetch([
                    [
                        [a[25], a[30], a[32]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[25]) && b.i64.eq(b.i64.cast([0, 0]), a[26]) && c.messageId === a[30] && c.attachmentFbid === a[32] && b.i64.lt(c.authorityLevel, a[128]) && (b.i64.eq(c.attachmentType, b.i64.cast([0, 7])) || b.i64.eq(c.attachmentType, b.i64.cast([0, 0]))) && c.hasMedia === !1 && c.hasXma === !0 && b.i64.eq(c.ephemeralMediaState, void 0)
                }), function(a) {
                    return a["delete"]()
                })
            }, function(c) {
                return b.db.table(16).add({
                    threadKey: a[25],
                    messageId: a[30],
                    attachmentFbid: a[32],
                    filename: a[1],
                    filesize: a[2],
                    hasMedia: !1,
                    isSharable: a[3],
                    playableUrl: a[4],
                    playableUrlFallback: a[5],
                    playableUrlExpirationTimestampMs: a[6],
                    playableUrlMimeType: a[7],
                    previewUrl: a[8],
                    previewUrlFallback: a[9],
                    previewUrlExpirationTimestampMs: a[10],
                    previewUrlMimeType: a[11],
                    previewWidth: a[13],
                    previewHeight: a[14],
                    attributionAppId: a[15],
                    attributionAppName: a[16],
                    attributionAppIcon: a[17],
                    attributionAppIconFallback: a[18],
                    attributionAppIconUrlExpirationTimestampMs: a[19],
                    attachmentIndex: a[20],
                    accessibilitySummaryText: a[21],
                    shouldRespectServerPreviewSize: a[22],
                    subtitleIconUrl: a[23],
                    shouldAutoplayVideo: a[24],
                    attachmentType: a[27],
                    timestampMs: a[29],
                    offlineAttachmentId: a[31],
                    hasXma: !0,
                    xmaLayoutType: a[33],
                    xmasTemplateType: a[34],
                    collapsibleId: a[35],
                    defaultCtaId: a[36],
                    defaultCtaTitle: a[37],
                    defaultCtaType: a[38],
                    attachmentCta1Id: a[40],
                    cta1Title: a[41],
                    cta1IconType: a[42],
                    cta1Type: a[43],
                    attachmentCta2Id: a[45],
                    cta2Title: a[46],
                    cta2IconType: a[47],
                    cta2Type: a[48],
                    attachmentCta3Id: a[50],
                    cta3Title: a[51],
                    cta3IconType: a[52],
                    cta3Type: a[53],
                    imageUrl: a[54],
                    imageUrlFallback: a[55],
                    imageUrlExpirationTimestampMs: a[56],
                    actionUrl: a[57],
                    titleText: a[58],
                    subtitleText: a[59],
                    subtitleDecorationType: a[60],
                    maxTitleNumOfLines: a[61],
                    maxSubtitleNumOfLines: a[62],
                    descriptionText: a[63],
                    sourceText: a[64],
                    faviconUrl: a[65],
                    faviconUrlFallback: a[66],
                    faviconUrlExpirationTimestampMs: a[67],
                    listItemsId: a[69],
                    listItemsDescriptionText: a[70],
                    listItemsDescriptionSubtitleText: a[71],
                    listItemsSecondaryDescriptionText: a[72],
                    listItemId1: a[73],
                    listItemTitleText1: a[74],
                    listItemContactUrlList1: a[75],
                    listItemProgressBarFilledPercentage1: a[76],
                    listItemContactUrlExpirationTimestampList1: a[77],
                    listItemContactUrlFallbackList1: a[78],
                    listItemAccessibilityText1: a[79],
                    listItemTotalCount1: a[80],
                    listItemId2: a[81],
                    listItemTitleText2: a[82],
                    listItemContactUrlList2: a[83],
                    listItemProgressBarFilledPercentage2: a[84],
                    listItemContactUrlExpirationTimestampList2: a[85],
                    listItemContactUrlFallbackList2: a[86],
                    listItemAccessibilityText2: a[87],
                    listItemTotalCount2: a[88],
                    listItemId3: a[89],
                    listItemTitleText3: a[90],
                    listItemContactUrlList3: a[91],
                    listItemProgressBarFilledPercentage3: a[92],
                    listItemContactUrlExpirationTimestampList3: a[93],
                    listItemContactUrlFallbackList3: a[94],
                    listItemAccessibilityText3: a[95],
                    listItemTotalCount3: a[96],
                    isBorderless: a[100],
                    headerImageUrlMimeType: a[101],
                    headerTitle: a[102],
                    headerSubtitleText: a[103],
                    headerImageUrl: a[104],
                    headerImageUrlFallback: a[105],
                    headerImageUrlExpirationTimestampMs: a[106],
                    previewImageDecorationType: a[107],
                    shouldHighlightHeaderTitleInTitle: a[108],
                    targetId: a[109],
                    attachmentLoggingType: a[112],
                    previewUrlLarge: a[114],
                    bodyText: a[115],
                    gatingType: a[116],
                    gatingTitle: a[117],
                    targetExpiryTimestampMs: a[118],
                    countdownTimestampMs: a[119],
                    shouldBlurSubattachments: a[120],
                    verifiedType: a[121],
                    captionBodyText: a[122],
                    isPublicXma: a[123],
                    replyCount: a[124],
                    xmaDataclass: a[125],
                    previewOverlayCountdownExpiry: a[126],
                    stickerType: a[127],
                    authorityLevel: a[128]
                })
            }])
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxInsertXmaAttachmentStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateAttachmentCtaAtIndexIgnoringAuthority", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.i64.eq(a[6], b.i64.cast([0, 0])) ? b.forEach(b.db.table(16).fetch([
                [
                    [a[0], a[1], a[2]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    defaultCtaId: a[3],
                    defaultCtaTitle: a[4],
                    defaultCtaType: a[5]
                })
            }) : b.i64.eq(a[6], b.i64.cast([0, 1])) ? b.forEach(b.db.table(16).fetch([
                [
                    [a[0], a[1], a[2]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    attachmentCta1Id: a[3],
                    cta1Title: a[4],
                    cta1Type: a[5],
                    cta1IconType: void 0
                })
            }) : b.i64.eq(a[6], b.i64.cast([0, 2])) ? b.forEach(b.db.table(16).fetch([
                [
                    [a[0], a[1], a[2]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    attachmentCta2Id: a[3],
                    cta2Title: a[4],
                    cta2Type: a[5],
                    cta2IconType: void 0
                })
            }) : b.i64.eq(a[6], b.i64.cast([0, 3])) ? b.forEach(b.db.table(16).fetch([
                [
                    [a[0], a[1], a[2]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    attachmentCta3Id: a[3],
                    cta3Title: a[4],
                    cta3Type: a[5],
                    cta3IconType: void 0
                })
            }) : b.resolve(function(a) {
                b.logger(a).warn(a)
            }("Unexpected CTA index"))
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateAttachmentCtaAtIndexIgnoringAuthorityStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateAttachmentItemCtaAtIndex", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.i64.eq(a[5], b.i64.cast([0, 0])) ? b.forEach(b.db.table(18).fetch([
                [
                    [a[0], a[1]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    defaultCtaId: a[2],
                    defaultCtaTitle: a[3],
                    defaultCtaType: a[4]
                })
            }) : b.i64.eq(a[5], b.i64.cast([0, 1])) ? b.forEach(b.db.table(18).fetch([
                [
                    [a[0], a[1]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    attachmentCta1Id: a[2],
                    cta1Title: a[3],
                    cta1Type: a[4],
                    cta1IconType: void 0
                })
            }) : b.i64.eq(a[5], b.i64.cast([0, 2])) ? b.forEach(b.db.table(18).fetch([
                [
                    [a[0], a[1]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    attachmentCta2Id: a[2],
                    cta2Title: a[3],
                    cta2Type: a[4],
                    cta2IconType: void 0
                })
            }) : b.i64.eq(a[5], b.i64.cast([0, 3])) ? b.forEach(b.db.table(18).fetch([
                [
                    [a[0], a[1]]
                ]
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    attachmentCta3Id: a[2],
                    cta3Title: a[3],
                    cta3Type: a[4],
                    cta3IconType: void 0
                })
            }) : b.resolve(function(a) {
                b.logger(a).warn(a)
            }("Unexpected CTA index"))
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateAttachmentItemCtaAtIndexStoredProcedure";
    e.exports = a
}), null);
//# sourceURL=https://static.xx.fbcdn.net/rsrc.php/v3/yX/r/N3dbhpg1fP0.js