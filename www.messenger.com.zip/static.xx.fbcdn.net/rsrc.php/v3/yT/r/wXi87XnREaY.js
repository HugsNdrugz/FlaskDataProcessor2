; /*FB_PKG_DELIM*/

/**
 *
 * This file is generated from fbsource. Please do not modify it directly.
 *
 * Generated from commit: 1ce9268612722d49dee249a726896128ec5f4516
 *
 * @nolint
 * @generated
 * @nopackage
 * @fullSyntaxTransform
 * @preserve-whitespace
 */
__d("actsanitizer_api_v2", ["Promise"], (function $module_actsanitizer_api_v2(global, require, requireDynamic, requireLazy, module, exports) {
    var _require_closure_Promise;

    var Module = function() {
        var _scriptDir = typeof document !== 'undefined' && document.currentScript ? document.currentScript.src : undefined;

        return (
            function(moduleArg) {
                if (moduleArg === void 0) {
                    moduleArg = {};
                }

                var Module = moduleArg;
                var readyPromiseResolve, readyPromiseReject;
                Module["ready"] = new(_require_closure_Promise || (_require_closure_Promise = require("Promise")))(function(resolve, reject) {
                    readyPromiseResolve = resolve;
                    readyPromiseReject = reject;
                });
                ["_malloc", "_free", "_memory", "_ACTSanitizer_isXMAValid", "_ACTSanitizer_isMessageTextValid", "___indirect_function_table", "_MEMMobileConfigCurrentProcessContextProviderIsMainApp", "_ls_waterfall_sampling", "_msys_sync_config", "_enable_connectivity_status_client_table", "_ls_mci_trace_session_based_config", "_msys_db_query", "_messenger_e2e_pre_qpl_config", "_enable_sqlite_error_callback_logging", "_msys_task_system_v2", "_msys_traffic_control", "_msys_validate_foreign_keys_from_sync_receiver", "_platform_trace_session_based_config", "_msys_internal_congestion", "_msys_database_configurations", "_msgr_db_query_optimizations", "_mci_telemetry_session_based_config", "_msgr_ios_media_picker", "_enable_cql_throw_logging", "_msys_read_only_connection", "_msys_task_congestion", "_msys_database_notification_configs", "_messaging_media_and_storage", "_msys_drop_logging_on_background", "_msgr_ios_messaging_media_quality", "_task_system_new_retry", "_messenger_db_health_recovery", "_sync_groups_priority_v2", "_msgr_db_in_memory_tables", "_msgr_health_e2e", "_msys_xstack_config", "_msys_arc", "_ls_connectivity_banner", "_msys_sync_xstack_config", "_msys_wal_hook", "_MEMPayloadVersionProviderGetPlaintextApplicationPayloadVersion", "_MEMPayloadVersionProviderGetMinimumSupportedApplicationPayloadVersion", "_MsysExceptionHandlerSetCriticalKeyValue", "_MsysExceptionHandlerSetKeyValue", "_MCIQPLCreateQPLInfoCopy", "_MCIQPLSetQPLInfo", "_MsysExecutionCurrentContext", "_MsysExecutionCurrentSessionedContext", "_MsysExecutionCurrentPriority", "_MsysExecutionSessionless", "_MsysExecutionSessioned", "_MsysExecutionEventTrigger", "_MsysExecutionContextSetStorage", "_MsysExecutionContextGetStorage", "_MsysExecutionContextCreateSystemStorageKey", "_MsysExecutionContextReleaseSystemStorageKey", "_MCIQPLMarkerAnnotateSingleString", "_MCIQPLMarkerIsOn", "_MCIQPLMarkerAnnotateSingleInt", "_MCIQPLGetTimestamp", "_MCIQPLMarkerPointWithFullAnnotation", "_msys_api_instrumentation", "_ls_echo", "_MsysPlatformTraceGetSamplingRate", "_platform_trace_session_based_config_v2", "_MCIExtensionExperimentCacheGetMobileConfigBoolean", "_MCIQPLMarkJoinRequestForE2E", "_MCIQPLMarkJoinResponseForE2E", "_MCIQPLMarkerStartWithLoggingOptions", "_MCIQPLMarkerEnd", "_MCIQPLMarkerPoint", "_MCIQPLMarkerPointWithAnnotation", "_MCIQPLMarkEvent", "_MCIQPLMarkerAnnotate", "_MCIQPLMarkerDrop", "_MCIComponentAttributionLoggerAPICreateArrayOfActiveFlowsIds", "_MCIQPLMarkerAnnotateIntArray", "_MCIAppExperimentsGetEnableTraceIDGenerationV2", "_MCIAppExperimentsEnableMccErrorLoggingOnArmadilloMediaS2sQPL", "_MsysSystraceStartSection", "_MsysSystraceEndSection", "_MsysCheckpoint", "_MsysSystraceStartCQLSection", "_MsysSystraceEndCQLSection", "_MCIQPLMarkerStart", "_MCIQPLMarkerEndWithTimestamp", "_MCIQPLMarkerAnnotateDouble", "_MsysAndroidIDProviderCopyAndroidID", "_MsysValidate", "_MsysFileManagerCopyContentsOfDirectoryAtURL", "_MsysFileManagerCopyFile", "_MsysFileManagerCreateDataWithContentsOfFile", "_MsysFileManagerCreateDirectory", "_MsysFileManagerCreateCacheDirectory", "_MsysFileManagerCreateStringWithContentsOfFile", "_MsysFileManagerCreateTemporaryDirectoryURL", "_MsysFileManagerDeleteItem", "_MsysFileManagerDeleteDatabaseFile", "_MsysFileManagerItemExists", "_MsysFileManagerLinkFile", "_MsysFileManagerMoveFile", "_MsysFileManagerWriteDataToFile", "_MsysFileManagerCopyHomeDirectoryURL", "_MsysFileManagerCopyFileSize", "_MsysFileManagerCopyContentAccessDate", "_MsysFileManagerClearURLResourcePropertyCacheFileSize", "_MsysFileManagerCopyAvailableDiskSpace", "_MCIExtensionExperimentCacheCreate", "_MCIExtensionExperimentCacheCreateWithExistingCache", "_MCIExtensionExperimentCacheLogExperimentExposure", "_MCIExtensionExperimentCacheGetGKValue", "_MCIExtensionExperimentCacheLogMobileConfigExposure__DEPRECATED", "_MCIExtensionExperimentCacheLogMobileConfigExposure", "_MCIExtensionExperimentCacheGetMobileConfigBoolean__DEPRECATED", "_MCIExtensionExperimentCacheGetMobileConfigInt64__DEPRECATED", "_MCIExtensionExperimentCacheGetMobileConfigInt64", "_MCIExtensionExperimentCacheGetMobileConfigInt32__DEPRECATED", "_MCIExtensionExperimentCacheGetMobileConfigInt32", "_MCIExtensionExperimentCacheGetMobileConfigDouble__DEPRECATED", "_MCIExtensionExperimentCacheGetMobileConfigDouble", "_MCIExtensionExperimentCacheGetMobileConfigString__DEPRECATED", "_MCIExtensionExperimentCacheGetMobileConfigString", "_MCIExtensionExperimentCacheSetMobileConfigCache", "_MCIExtensionExperimentCacheSetGKCache", "_MCIExtensionExperimentCacheGetMobileConfigCacheIsSet", "_MCIExtensionExperimentCacheCopyGKCache", "_MCIExtensionExperimentCacheGetInternalObject_DO_NOT_USE", "_MCIQPLStartQPLInfoPropagation", "_MCIQPLStopQPLInfoPropagation", "_MCIQPLGetInstanceKey", "_MCIQPLCreatePropagatedQPLInfoSnapshot", "_MCIQPLRestoreQPLInfoFromSnapshotId", "_MCIQPLMarkerAnnotateBool", "_MCIQPLGenerateFlowId", "_MsysStats", "_MCIAppExperimentsGetEnableReadOnlyForAllReadOnlyFunctions", "_MCIAppExperimentsGetEnableVMStackCachingInDasm", "_MCIAppExperimentsGetEnableAuthDataCheck", "_MCIAppExperimentsGetEnableBoxedAllocForDasm", "_MCIAppExperimentsAllowThreadViewReadOnlyConnectionUsage", "_MCIAppExperimentsEnablePlatformTTCTracking", "_MCIAppExperimentsAllowROConnectionForPinnedMessages", "_MCIAppExperimentsAllowThreadViewDataOnlyMediaMessagesReadOnly", "_MCIAppExperimentsAllowLoadThreadViewDataReadOnly", "_MCIAppExperimentsAllowROConnectionForMailboxThreadThemeLoad", "_MCIAppExperimentsAllowROConnectionForEchoInitialization", "_MCIAppExperimentsRunContactPkMigrationOnUpgrade", "_MCIAppExperimentsIsOnUpgradeOrInstall", "_MCIAppExperimentsUseNativeQPL", "_MCIAppExperimentsDbContextOffloadOrcaLoadThreadViewDataDelay", "_MCIAppExperimentsHandleUpdateDBOffload", "_MsysEventLogSubscriberLog", "_MsysEventLogSubscriberGetSchemaId", "_MsysTransportLogSubscriberGetTransportKeys", "_MsysTransportLogSubscriberLog", "_MCIComponentAttributionLoggerAPIComponentStart", "_MCIComponentAttributionLoggerAPIComponentPoint", "_MCIComponentAttributionLoggerAPIComponentAnnotateBool", "_MCIComponentAttributionLoggerAPIComponentAnnotateString", "_MCIComponentAttributionLoggerAPIComponentAnnotateDouble", "_MCIComponentAttributionLoggerAPIComponentAnnotateInt", "_MCIComponentAttributionLoggerAPIComponentEvent", "_MCIComponentAttributionLoggerAPIComponentEnd", "_ls_mobileconfig_secure_message_over_wa", "_mark_crypto_tasks_critical", "_xplat_messaging_rust", "_fflush", "_MsysLoggingDestinationProviderGetLoggingDestinations", "_MsysLoggingMaxLevelEnabledGet", "_MsysTripwireReportFailure", "_MEMMobileConfigPlatformGetBooleanUsingAuthDataContext", "_MEMMobileConfigPlatformGetInt32UsingAuthDataContext", "_MEMMobileConfigPlatformGetInt64UsingAuthDataContext", "_MEMMobileConfigPlatformGetDoubleUsingAuthDataContext", "_MEMMobileConfigPlatformCopyStringUsingAuthDataContext", "_MEMMobileConfigPlatformGetBooleanUsingDb", "_MEMMobileConfigPlatformGetInt32UsingDb", "_MEMMobileConfigPlatformGetInt64UsingDb", "_MEMMobileConfigPlatformGetDoubleUsingDb", "_MEMMobileConfigPlatformCopyStringUsingDb", "__embind_initialize_bindings", "onRuntimeInitialized"].forEach(function(prop) {
                    if (!Object.getOwnPropertyDescriptor(Module["ready"], prop)) {
                        Object.defineProperty(Module["ready"], prop, {
                            get: function get() {
                                return abort("You are getting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
                            },
                            set: function set() {
                                return abort("You are setting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
                            }
                        });
                    }
                });
                var moduleOverrides = Object.assign({}, Module);
                var arguments_ = [];
                var thisProgram = "./this.program";
                var quit_ = function quit_(status, toThrow) {
                    throw toThrow;
                };
                var ENVIRONMENT_IS_WEB = true;
                var ENVIRONMENT_IS_WORKER = false;
                var ENVIRONMENT_IS_NODE = false;
                var ENVIRONMENT_IS_SHELL = false;
                if (Module["ENVIRONMENT"]) {
                    throw new Error("Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -sENVIRONMENT=web or -sENVIRONMENT=node)");
                }
                var scriptDirectory = "";

                function locateFile(path) {
                    if (Module["locateFile"]) {
                        return Module["locateFile"](path, scriptDirectory);
                    }
                    return scriptDirectory + path;
                }
                var read_, readAsync, readBinary, setWindowTitle;
                if (ENVIRONMENT_IS_SHELL) {
                    if (typeof process == "object" && typeof require === "function" || typeof window == "object" || typeof importScripts == "function") throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
                    if (typeof read != "undefined") {
                        read_ = read;
                    }
                    readBinary = function readBinary(f) {
                        if (typeof readbuffer == "function") {
                            return new Uint8Array(readbuffer(f));
                        }
                        var data = read(f, "binary");
                        assert(typeof data == "object");
                        return data;
                    };
                    readAsync = function readAsync(f, onload, onerror) {
                        setTimeout(function() {
                            return onload(readBinary(f));
                        });
                    };
                    if (typeof clearTimeout == "undefined") {
                        globalThis.clearTimeout = function(id) {};
                    }
                    if (typeof setTimeout == "undefined") {
                        globalThis.setTimeout = function(f) {
                            return typeof f == "function" ? f() : abort();
                        };
                    }
                    if (typeof scriptArgs != "undefined") {
                        arguments_ = scriptArgs;
                    } else if (typeof arguments != "undefined") {
                        arguments_ = arguments;
                    }
                    if (typeof quit == "function") {
                        quit_ = function quit_(status, toThrow) {
                            setTimeout(function() {
                                if (!(toThrow instanceof ExitStatus)) {
                                    var toLog = toThrow;
                                    if (toThrow && typeof toThrow == "object" && toThrow.stack) {
                                        toLog = [toThrow, toThrow.stack];
                                    }
                                    err("exiting due to exception: " + toLog);
                                }
                                quit(status);
                            });
                            throw toThrow;
                        };
                    }
                    if (typeof print != "undefined") {
                        if (typeof console == "undefined") console = {};
                        console.log = print;
                        console.warn = console.error = typeof printErr != "undefined" ? printErr : print;
                    }
                } else if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
                    if (ENVIRONMENT_IS_WORKER) {
                        scriptDirectory = self.location.href;
                    } else if (typeof document != "undefined" && document.currentScript) {
                        scriptDirectory = document.currentScript.src;
                    }
                    if (_scriptDir) {
                        scriptDirectory = _scriptDir;
                    }
                    if (scriptDirectory.indexOf("blob:") !== 0) {
                        scriptDirectory = scriptDirectory.substr(0, scriptDirectory.replace(/[?#].*/, "").lastIndexOf("/") + 1);
                    } else {
                        scriptDirectory = "";
                    }
                    if (!(typeof window == "object" || typeof importScripts == "function")) throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)"); {
                        read_ = function read_(url) {
                            var xhr = new XMLHttpRequest();
                            xhr.open("GET", url, false);
                            xhr.send(null);
                            return xhr.responseText;
                        };
                        if (ENVIRONMENT_IS_WORKER) {
                            readBinary = function readBinary(url) {
                                var xhr = new XMLHttpRequest();
                                xhr.open("GET", url, false);
                                xhr.responseType = "arraybuffer";
                                xhr.send(null);
                                return new Uint8Array(xhr.response);
                            };
                        }
                        readAsync = function readAsync(url, onload, onerror) {
                            var xhr = new XMLHttpRequest();
                            xhr.open("GET", url, true);
                            xhr.responseType = "arraybuffer";
                            xhr.onload = function() {
                                if (xhr.status == 200 || xhr.status == 0 && xhr.response) {
                                    onload(xhr.response);
                                    return;
                                }
                                onerror();
                            };
                            xhr.onerror = onerror;
                            xhr.send(null);
                        };
                    }
                    setWindowTitle = function setWindowTitle(title) {
                        return document.title = title;
                    };
                } else {
                    throw new Error("environment detection error");
                }
                var out = console.log.bind(console);
                var err = console.error.bind(console);
                Object.assign(Module, moduleOverrides);
                moduleOverrides = null;
                checkIncomingModuleAPI();
                legacyModuleProp("arguments", "arguments_");
                legacyModuleProp("thisProgram", "thisProgram");
                legacyModuleProp("quit", "quit_");
                assert(typeof Module["memoryInitializerPrefixURL"] == "undefined", "Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");
                assert(typeof Module["pthreadMainPrefixURL"] == "undefined", "Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");
                assert(typeof Module["cdInitializerPrefixURL"] == "undefined", "Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");
                assert(typeof Module["filePackagePrefixURL"] == "undefined", "Module.filePackagePrefixURL option was removed, use Module.locateFile instead");
                assert(typeof Module["read"] == "undefined", "Module.read option was removed (modify read_ in JS)");
                assert(typeof Module["readAsync"] == "undefined", "Module.readAsync option was removed (modify readAsync in JS)");
                assert(typeof Module["readBinary"] == "undefined", "Module.readBinary option was removed (modify readBinary in JS)");
                assert(typeof Module["setWindowTitle"] == "undefined", "Module.setWindowTitle option was removed (modify setWindowTitle in JS)");
                assert(typeof Module["TOTAL_MEMORY"] == "undefined", "Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY");
                legacyModuleProp("asm", "wasmExports");
                legacyModuleProp("read", "read_");
                legacyModuleProp("readAsync", "readAsync");
                legacyModuleProp("readBinary", "readBinary");
                legacyModuleProp("setWindowTitle", "setWindowTitle");
                assert(!ENVIRONMENT_IS_WORKER, "worker environment detected but not enabled at build time.  Add 'worker' to `-sENVIRONMENT` to enable.");
                assert(!ENVIRONMENT_IS_NODE, "node environment detected but not enabled at build time.  Add 'node' to `-sENVIRONMENT` to enable.");
                assert(!ENVIRONMENT_IS_SHELL, "shell environment detected but not enabled at build time.  Add 'shell' to `-sENVIRONMENT` to enable.");
                var wasmBinary;
                if (Module["wasmBinary"]) wasmBinary = Module["wasmBinary"];
                legacyModuleProp("wasmBinary", "wasmBinary");
                var noExitRuntime = true;
                legacyModuleProp("noExitRuntime", "noExitRuntime");
                if (typeof WebAssembly != "object") {
                    abort("no native wasm support detected");
                }
                var wasmMemory;
                var wasmExports;
                var ABORT = false;
                var EXITSTATUS;

                function assert(condition, text) {
                    if (!condition) {
                        abort("Assertion failed" + (text ? ": " + text : ""));
                    }
                }
                var HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAP64, HEAPU64, HEAPF64;

                function updateMemoryViews() {
                    var b = wasmMemory.buffer;
                    Module["HEAP8"] = HEAP8 = new Int8Array(b);
                    Module["HEAP16"] = HEAP16 = new Int16Array(b);
                    Module["HEAP32"] = HEAP32 = new Int32Array(b);
                    Module["HEAPU8"] = HEAPU8 = new Uint8Array(b);
                    Module["HEAPU16"] = HEAPU16 = new Uint16Array(b);
                    Module["HEAPU32"] = HEAPU32 = new Uint32Array(b);
                    Module["HEAPF32"] = HEAPF32 = new Float32Array(b);
                    Module["HEAPF64"] = HEAPF64 = new Float64Array(b);
                    Module["HEAP64"] = HEAP64 = new BigInt64Array(b);
                    Module["HEAPU64"] = HEAPU64 = new BigUint64Array(b);
                }
                assert(!Module["STACK_SIZE"], "STACK_SIZE can no longer be set at runtime.  Use -sSTACK_SIZE at link time");
                assert(typeof Int32Array != "undefined" && typeof Float64Array !== "undefined" && Int32Array.prototype.subarray != undefined && Int32Array.prototype.set != undefined, "JS engine does not provide full typed array support");
                assert(!Module["wasmMemory"], "Use of `wasmMemory` detected.  Use -sIMPORTED_MEMORY to define wasmMemory externally");
                assert(!Module["INITIAL_MEMORY"], "Detected runtime INITIAL_MEMORY setting.  Use -sIMPORTED_MEMORY to define wasmMemory dynamically");
                var wasmTable;

                function writeStackCookie() {
                    var max = _emscripten_stack_get_end2();
                    assert((max & 3) == 0);
                    if (max == 0) {
                        max += 4;
                    }
                    HEAPU32[max >> 2] = 34821223;
                    HEAPU32[max + 4 >> 2] = 2310721022;
                    HEAPU32[0 >> 2] = 1668509029;
                }

                function checkStackCookie() {
                    if (ABORT) return;
                    var max = _emscripten_stack_get_end2();
                    if (max == 0) {
                        max += 4;
                    }
                    var cookie1 = HEAPU32[max >> 2];
                    var cookie2 = HEAPU32[max + 4 >> 2];
                    if (cookie1 != 34821223 || cookie2 != 2310721022) {
                        abort("Stack overflow! Stack cookie has been overwritten at " + ptrToString(max) + ", expected hex dwords 0x89BACDFE and 0x2135467, but received " + ptrToString(cookie2) + " " + ptrToString(cookie1));
                    }
                    if (HEAPU32[0 >> 2] != 1668509029) {
                        abort("Runtime error: The application has corrupted its heap memory area (address zero)!");
                    }
                }(function() {
                    var h16 = new Int16Array(1);
                    var h8 = new Int8Array(h16.buffer);
                    h16[0] = 25459;
                    if (h8[0] !== 115 || h8[1] !== 99) throw "Runtime error: expected the system to be little-endian! (Run with -sSUPPORT_BIG_ENDIAN to bypass)";
                })();
                var __ATPRERUN__ = [];
                var __ATINIT__ = [];
                var __ATPOSTRUN__ = [];
                var runtimeInitialized = false;
                var runtimeKeepaliveCounter = 0;

                function preRun() {
                    callRuntimeCallbacks(__ATPRERUN__);
                }

                function initRuntime() {
                    assert(!runtimeInitialized);
                    runtimeInitialized = true;
                    checkStackCookie();
                    callRuntimeCallbacks(__ATINIT__);
                }

                function postRun() {
                    checkStackCookie();
                    callRuntimeCallbacks(__ATPOSTRUN__);
                }

                function addOnInit(cb) {
                    __ATINIT__.unshift(cb);
                }
                assert(Math.imul, "This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
                assert(Math.fround, "This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
                assert(Math.clz32, "This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
                assert(Math.trunc, "This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
                var runDependencies = 0;
                var runDependencyWatcher = null;
                var dependenciesFulfilled = null;
                var runDependencyTracking = {};

                function addRunDependency(id) {
                    runDependencies++;
                    if (id) {
                        assert(!runDependencyTracking[id]);
                        runDependencyTracking[id] = 1;
                        if (runDependencyWatcher === null && typeof setInterval != "undefined") {
                            runDependencyWatcher = setInterval(function() {
                                if (ABORT) {
                                    clearInterval(runDependencyWatcher);
                                    runDependencyWatcher = null;
                                    return;
                                }
                                var shown = false;
                                for (var dep in runDependencyTracking) {
                                    if (!shown) {
                                        shown = true;
                                        err("still waiting on run dependencies:");
                                    }
                                    err("dependency: " + dep);
                                }
                                if (shown) {
                                    err("(end of list)");
                                }
                            }, 1e4);
                        }
                    } else {
                        err("warning: run dependency added without ID");
                    }
                }

                function removeRunDependency(id) {
                    runDependencies--;
                    if (id) {
                        assert(runDependencyTracking[id]);
                        delete runDependencyTracking[id];
                    } else {
                        err("warning: run dependency removed without ID");
                    }
                    if (runDependencies == 0) {
                        if (runDependencyWatcher !== null) {
                            clearInterval(runDependencyWatcher);
                            runDependencyWatcher = null;
                        }
                        if (dependenciesFulfilled) {
                            var callback = dependenciesFulfilled;
                            dependenciesFulfilled = null;
                            callback();
                        }
                    }
                }

                function abort(what) {
                    what = "Aborted(" + what + ")";
                    err(what);
                    ABORT = true;
                    EXITSTATUS = 1;
                    var e = new WebAssembly.RuntimeError(what);
                    readyPromiseReject(e);
                    throw e;
                }
                var FS = {
                    error: function error() {
                        abort("Filesystem support (FS) was not included. The problem is that you are using files from JS, but files were not used from C/C++, so filesystem support was not auto-included. You can force-include filesystem support with -sFORCE_FILESYSTEM");
                    },
                    init: function init() {
                        FS.error();
                    },
                    createDataFile: function createDataFile() {
                        FS.error();
                    },
                    createPreloadedFile: function createPreloadedFile() {
                        FS.error();
                    },
                    createLazyFile: function createLazyFile() {
                        FS.error();
                    },
                    open: function open() {
                        FS.error();
                    },
                    mkdev: function mkdev() {
                        FS.error();
                    },
                    registerDevice: function registerDevice() {
                        FS.error();
                    },
                    analyzePath: function analyzePath() {
                        FS.error();
                    },
                    ErrnoError: function ErrnoError() {
                        FS.error();
                    }
                };
                Module["FS_createDataFile"] = FS.createDataFile;
                Module["FS_createPreloadedFile"] = FS.createPreloadedFile;
                var dataURIPrefix = "data:application/octet-stream;base64,";

                function isDataURI(filename) {
                    return filename.startsWith(dataURIPrefix);
                }

                function isFileURI(filename) {
                    return filename.startsWith("file://");
                }

                function createExportWrapper(name) {
                    return function() {
                        assert(runtimeInitialized, "native function `" + name + "` called before runtime initialization");
                        var f = wasmExports[name];
                        assert(f, "exported native function `" + name + "` not found");
                        return f.apply(null, arguments);
                    };
                }
                var wasmBinaryFile;
                wasmBinaryFile = "actsanitizer_api_v2.wasm";
                if (!isDataURI(wasmBinaryFile)) {
                    wasmBinaryFile = locateFile(wasmBinaryFile);
                }

                function getBinarySync(file) {
                    if (file == wasmBinaryFile && wasmBinary) {
                        return new Uint8Array(wasmBinary);
                    }
                    if (readBinary) {
                        return readBinary(file);
                    }
                    throw "both async and sync fetching of the wasm failed";
                }

                function getBinaryPromise(binaryFile) {
                    if (!wasmBinary && (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER)) {
                        if (typeof fetch == "function") {
                            return fetch(binaryFile, {
                                credentials: "same-origin"
                            }).then(function(response) {
                                if (!response["ok"]) {
                                    throw "failed to load wasm binary file at '" + binaryFile + "'";
                                }
                                return response["arrayBuffer"]();
                            })["catch"](function() {
                                return getBinarySync(binaryFile);
                            });
                        }
                    }
                    return (_require_closure_Promise || (_require_closure_Promise = require("Promise"))).resolve().then(function() {
                        return getBinarySync(binaryFile);
                    });
                }

                function instantiateArrayBuffer(binaryFile, imports, receiver) {
                    return getBinaryPromise(binaryFile).then(function(binary) {
                        return WebAssembly.instantiate(binary, imports);
                    }).then(function(instance) {
                        return instance;
                    }).then(receiver, function(reason) {
                        err("failed to asynchronously prepare wasm: " + reason);
                        if (isFileURI(wasmBinaryFile)) {
                            err("warning: Loading from a file URI (" + wasmBinaryFile + ") is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing");
                        }
                        abort(reason);
                    });
                }

                function instantiateAsync(binary, binaryFile, imports, callback) {
                    if (!binary && typeof WebAssembly.instantiateStreaming == "function" && !isDataURI(binaryFile) && typeof fetch == "function") {
                        return fetch(binaryFile, {
                            credentials: "same-origin"
                        }).then(function(response) {
                            var result = WebAssembly.instantiateStreaming(response, imports);
                            return result.then(callback, function(reason) {
                                err("wasm streaming compile failed: " + reason);
                                err("falling back to ArrayBuffer instantiation");
                                return instantiateArrayBuffer(binaryFile, imports, callback);
                            });
                        });
                    }
                    return instantiateArrayBuffer(binaryFile, imports, callback);
                }

                function createWasm() {
                    var info = {
                        "env": wasmImports,
                        "wasi_snapshot_preview1": wasmImports
                    };

                    function receiveInstance(instance, module) {
                        var exports = instance.exports;
                        wasmExports = exports;
                        wasmMemory = wasmExports["memory"];
                        Module["wasmMemory"] = wasmMemory;
                        assert(wasmMemory, "memory not found in wasm exports");
                        updateMemoryViews();
                        wasmTable = wasmExports["__indirect_function_table"];
                        assert(wasmTable, "table not found in wasm exports");
                        addOnInit(wasmExports["__wasm_call_ctors"]);
                        removeRunDependency("wasm-instantiate");
                        return exports;
                    }
                    addRunDependency("wasm-instantiate");
                    var trueModule = Module;

                    function receiveInstantiationResult(result) {
                        assert(Module === trueModule, "the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");
                        trueModule = null;
                        receiveInstance(result["instance"]);
                    }
                    if (Module["instantiateWasm"]) {
                        try {
                            return Module["instantiateWasm"](info, receiveInstance);
                        } catch (e) {
                            err("Module.instantiateWasm callback failed with error: " + e);
                            readyPromiseReject(e);
                        }
                    }
                    instantiateAsync(wasmBinary, wasmBinaryFile, info, receiveInstantiationResult)["catch"](readyPromiseReject);
                    return {};
                }

                function legacyModuleProp(prop, newName, incomming) {
                    if (incomming === void 0) {
                        incomming = true;
                    }
                    if (!Object.getOwnPropertyDescriptor(Module, prop)) {
                        Object.defineProperty(Module, prop, {
                            configurable: true,
                            get: function get() {
                                var extra = incomming ? " (the initial value can be provided on Module, but after startup the value is only looked for on a local variable of that name)" : "";
                                abort("`Module." + prop + "` has been replaced by `" + newName + "`" + extra);
                            }
                        });
                    }
                }

                function ignoredModuleProp(prop) {
                    if (Object.getOwnPropertyDescriptor(Module, prop)) {
                        abort("`Module." + prop + "` was supplied but `" + prop + "` not included in INCOMING_MODULE_JS_API");
                    }
                }

                function isExportedByForceFilesystem(name) {
                    return name === "FS_createPath" || name === "FS_createDataFile" || name === "FS_createPreloadedFile" || name === "FS_unlink" || name === "addRunDependency" || name === "FS_createLazyFile" || name === "FS_createDevice" || name === "removeRunDependency";
                }

                function missingGlobal(sym, msg) {
                    if (typeof globalThis !== "undefined") {
                        Object.defineProperty(globalThis, sym, {
                            configurable: true,
                            get: function get() {
                                warnOnce("`" + sym + "` is not longer defined by emscripten. " + msg);
                                return undefined;
                            }
                        });
                    }
                }
                missingGlobal("buffer", "Please use HEAP8.buffer or wasmMemory.buffer");

                function missingLibrarySymbol(sym) {
                    if (typeof globalThis !== "undefined" && !Object.getOwnPropertyDescriptor(globalThis, sym)) {
                        Object.defineProperty(globalThis, sym, {
                            configurable: true,
                            get: function get() {
                                var msg = "`" + sym + "` is a library symbol and not included by default; add it to your library.js __deps or to DEFAULT_LIBRARY_FUNCS_TO_INCLUDE on the command line";
                                var librarySymbol = sym;
                                if (!librarySymbol.startsWith("_")) {
                                    librarySymbol = "$" + sym;
                                }
                                msg += " (e.g. -sDEFAULT_LIBRARY_FUNCS_TO_INCLUDE='" + librarySymbol + "')";
                                if (isExportedByForceFilesystem(sym)) {
                                    msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
                                }
                                warnOnce(msg);
                                return undefined;
                            }
                        });
                    }
                    unexportedRuntimeSymbol(sym);
                }

                function unexportedRuntimeSymbol(sym) {
                    if (!Object.getOwnPropertyDescriptor(Module, sym)) {
                        Object.defineProperty(Module, sym, {
                            configurable: true,
                            get: function get() {
                                var msg = "'" + sym + "' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the Emscripten FAQ)";
                                if (isExportedByForceFilesystem(sym)) {
                                    msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
                                }
                                abort(msg);
                            }
                        });
                    }
                }

                function ExitStatus(status) {
                    this.name = "ExitStatus";
                    this.message = "Program terminated with exit(" + status + ")";
                    this.status = status;
                }
                var callRuntimeCallbacks = function callRuntimeCallbacks(callbacks) {
                    while (callbacks.length > 0) {
                        callbacks.shift()(Module);
                    }
                };

                function getValue(ptr, type) {
                    if (type === void 0) {
                        type = "i8";
                    }
                    if (type.endsWith("*")) type = "*";
                    switch (type) {
                        case "i1":
                            return HEAP8[ptr >> 0];
                        case "i8":
                            return HEAP8[ptr >> 0];
                        case "i16":
                            return HEAP16[ptr >> 1];
                        case "i32":
                            return HEAP32[ptr >> 2];
                        case "i64":
                            return HEAP64[ptr >> 3];
                        case "float":
                            return HEAPF32[ptr >> 2];
                        case "double":
                            return HEAPF64[ptr >> 3];
                        case "*":
                            return HEAPU32[ptr >> 2];
                        default:
                            abort("invalid type for getValue: " + type);
                    }
                }
                var ptrToString = function ptrToString(ptr) {
                    assert(typeof ptr === "number");
                    ptr >>>= 0;
                    return "0x" + ptr.toString(16).padStart(8, "0");
                };

                function setValue(ptr, value, type) {
                    if (type === void 0) {
                        type = "i8";
                    }
                    if (type.endsWith("*")) type = "*";
                    switch (type) {
                        case "i1":
                            HEAP8[ptr >> 0] = value;
                            break;
                        case "i8":
                            HEAP8[ptr >> 0] = value;
                            break;
                        case "i16":
                            HEAP16[ptr >> 1] = value;
                            break;
                        case "i32":
                            HEAP32[ptr >> 2] = value;
                            break;
                        case "i64":
                            HEAP64[ptr >> 3] = BigInt(value);
                            break;
                        case "float":
                            HEAPF32[ptr >> 2] = value;
                            break;
                        case "double":
                            HEAPF64[ptr >> 3] = value;
                            break;
                        case "*":
                            HEAPU32[ptr >> 2] = value;
                            break;
                        default:
                            abort("invalid type for setValue: " + type);
                    }
                }
                var warnOnce = function warnOnce(text) {
                    if (!warnOnce.shown) warnOnce.shown = {};
                    if (!warnOnce.shown[text]) {
                        warnOnce.shown[text] = 1;
                        err(text);
                    }
                };
                var UTF8Decoder = typeof TextDecoder != "undefined" ? new TextDecoder("utf8") : undefined;
                var UTF8ArrayToString = function UTF8ArrayToString(heapOrArray, idx, maxBytesToRead) {
                    var endIdx = idx + maxBytesToRead;
                    var endPtr = idx;
                    while (heapOrArray[endPtr] && !(endPtr >= endIdx)) {
                        ++endPtr;
                    }
                    if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) {
                        return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr));
                    }
                    var str = "";
                    while (idx < endPtr) {
                        var u0 = heapOrArray[idx++];
                        if (!(u0 & 128)) {
                            str += String.fromCharCode(u0);
                            continue;
                        }
                        var u1 = heapOrArray[idx++] & 63;
                        if ((u0 & 224) == 192) {
                            str += String.fromCharCode((u0 & 31) << 6 | u1);
                            continue;
                        }
                        var u2 = heapOrArray[idx++] & 63;
                        if ((u0 & 240) == 224) {
                            u0 = (u0 & 15) << 12 | u1 << 6 | u2;
                        } else {
                            if ((u0 & 248) != 240) warnOnce("Invalid UTF-8 leading byte " + ptrToString(u0) + " encountered when deserializing a UTF-8 string in wasm memory to a JS string!");
                            u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | heapOrArray[idx++] & 63;
                        }
                        if (u0 < 65536) {
                            str += String.fromCharCode(u0);
                        } else {
                            var ch = u0 - 65536;
                            str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
                        }
                    }
                    return str;
                };
                var UTF8ToString = function UTF8ToString(ptr, maxBytesToRead) {
                    assert(typeof ptr == "number");
                    return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead) : "";
                };
                var ___assert_fail = function ___assert_fail(condition, filename, line, func) {
                    abort("Assertion failed: " + UTF8ToString(condition) + ", at: " + [filename ? UTF8ToString(filename) : "unknown filename", line, func ? UTF8ToString(func) : "unknown function"]);
                };

                function ExceptionInfo(excPtr) {
                    this.excPtr = excPtr;
                    this.ptr = excPtr - 24;
                    this.set_type = function(type) {
                        HEAPU32[this.ptr + 4 >> 2] = type;
                    };
                    this.get_type = function() {
                        return HEAPU32[this.ptr + 4 >> 2];
                    };
                    this.set_destructor = function(destructor) {
                        HEAPU32[this.ptr + 8 >> 2] = destructor;
                    };
                    this.get_destructor = function() {
                        return HEAPU32[this.ptr + 8 >> 2];
                    };
                    this.set_caught = function(caught) {
                        caught = caught ? 1 : 0;
                        HEAP8[this.ptr + 12 >> 0] = caught;
                    };
                    this.get_caught = function() {
                        return HEAP8[this.ptr + 12 >> 0] != 0;
                    };
                    this.set_rethrown = function(rethrown) {
                        rethrown = rethrown ? 1 : 0;
                        HEAP8[this.ptr + 13 >> 0] = rethrown;
                    };
                    this.get_rethrown = function() {
                        return HEAP8[this.ptr + 13 >> 0] != 0;
                    };
                    this.init = function(type, destructor) {
                        this.set_adjusted_ptr(0);
                        this.set_type(type);
                        this.set_destructor(destructor);
                    };
                    this.set_adjusted_ptr = function(adjustedPtr) {
                        HEAPU32[this.ptr + 16 >> 2] = adjustedPtr;
                    };
                    this.get_adjusted_ptr = function() {
                        return HEAPU32[this.ptr + 16 >> 2];
                    };
                    this.get_exception_ptr = function() {
                        var isPointer = ___cxa_is_pointer_type(this.get_type());
                        if (isPointer) {
                            return HEAPU32[this.excPtr >> 2];
                        }
                        var adjusted = this.get_adjusted_ptr();
                        if (adjusted !== 0) return adjusted;
                        return this.excPtr;
                    };
                }
                var exceptionLast = 0;
                var uncaughtExceptionCount = 0;

                function ___cxa_throw(ptr, type, destructor) {
                    var info = new ExceptionInfo(ptr);
                    info.init(type, destructor);
                    exceptionLast = ptr;
                    uncaughtExceptionCount++;
                    assert(false, "Exception thrown, but exception catching is not enabled. Compile with -sNO_DISABLE_EXCEPTION_CATCHING or -sEXCEPTION_CATCHING_ALLOWED=[..] to catch.");
                }

                function embindRepr(v) {
                    if (v === null) {
                        return "null";
                    }
                    var t = typeof v;
                    if (t === "object" || t === "array" || t === "function") {
                        return v.toString();
                    } else {
                        return "" + v;
                    }
                }

                function embind_init_charCodes() {
                    var codes = new Array(256);
                    for (var i = 0; i < 256; ++i) {
                        codes[i] = String.fromCharCode(i);
                    }
                    embind_charCodes = codes;
                }
                var embind_charCodes = undefined;

                function readLatin1String(ptr) {
                    var ret = "";
                    var c = ptr;
                    while (HEAPU8[c]) {
                        ret += embind_charCodes[HEAPU8[c++]];
                    }
                    return ret;
                }
                var awaitingDependencies = {};
                var registeredTypes = {};
                var typeDependencies = {};
                var BindingError = undefined;

                function throwBindingError(message) {
                    throw new BindingError(message);
                }
                var InternalError = undefined;

                function throwInternalError(message) {
                    throw new InternalError(message);
                }

                function sharedRegisterType(rawType, registeredInstance, options) {
                    if (options === void 0) {
                        options = {};
                    }
                    var name = registeredInstance.name;
                    if (!rawType) {
                        throwBindingError("type \"" + name + "\" must have a positive integer typeid pointer");
                    }
                    if (Object.prototype.hasOwnProperty.call(registeredTypes, rawType)) {
                        if (options.ignoreDuplicateRegistrations) {
                            return;
                        } else {
                            throwBindingError("Cannot register type '" + name + "' twice");
                        }
                    }
                    registeredTypes[rawType] = registeredInstance;
                    delete typeDependencies[rawType];
                    if (Object.prototype.hasOwnProperty.call(awaitingDependencies, rawType)) {
                        var callbacks = awaitingDependencies[rawType];
                        delete awaitingDependencies[rawType];
                        callbacks.forEach(function(cb) {
                            return cb();
                        });
                    }
                }

                function registerType(rawType, registeredInstance, options) {
                    if (options === void 0) {
                        options = {};
                    }
                    if (!("argPackAdvance" in registeredInstance)) {
                        throw new TypeError("registerType registeredInstance requires argPackAdvance");
                    }
                    return sharedRegisterType(rawType, registeredInstance, options);
                }

                function integerReadValueFromPointer(name, shift, signed) {
                    switch (shift) {
                        case 0:
                            return signed ? function readS8FromPointer(pointer) {
                                return HEAP8[pointer];
                            } : function readU8FromPointer(pointer) {
                                return HEAPU8[pointer];
                            };
                        case 1:
                            return signed ? function readS16FromPointer(pointer) {
                                return HEAP16[pointer >> 1];
                            } : function readU16FromPointer(pointer) {
                                return HEAPU16[pointer >> 1];
                            };
                        case 2:
                            return signed ? function readS32FromPointer(pointer) {
                                return HEAP32[pointer >> 2];
                            } : function readU32FromPointer(pointer) {
                                return HEAPU32[pointer >> 2];
                            };
                        case 3:
                            return signed ? function readS64FromPointer(pointer) {
                                return HEAP64[pointer >> 3];
                            } : function readU64FromPointer(pointer) {
                                return HEAPU64[pointer >> 3];
                            };
                        default:
                            throw new TypeError("Unknown integer type: " + name);
                    }
                }

                function __embind_register_bigint(primitiveType, name, size, minRange, maxRange) {
                    name = readLatin1String(name);
                    var shift = getShiftFromSize(size);
                    var isUnsignedType = name.indexOf("u") != -1;
                    if (isUnsignedType) {
                        maxRange = (1 n << 64 n) - 1 n;
                    }
                    registerType(primitiveType, {
                        name: name,
                        "fromWireType": function fromWireType(value) {
                            return value;
                        },
                        "toWireType": function toWireType(destructors, value) {
                            if (typeof value != "bigint" && typeof value != "number") {
                                throw new TypeError("Cannot convert \"" + embindRepr(value) + "\" to " + this.name);
                            }
                            if (value < minRange || value > maxRange) {
                                throw new TypeError("Passing a number \"" + embindRepr(value) + "\" from JS side to C/C++ side to an argument of type \"" + name + "\", which is outside the valid range [" + minRange + ", " + maxRange + "]!");
                            }
                            return value;
                        },
                        "argPackAdvance": 8,
                        "readValueFromPointer": integerReadValueFromPointer(name, shift, !isUnsignedType),
                        destructorFunction: null
                    });
                }

                function getShiftFromSize(size) {
                    switch (size) {
                        case 1:
                            return 0;
                        case 2:
                            return 1;
                        case 4:
                            return 2;
                        case 8:
                            return 3;
                        default:
                            throw new TypeError("Unknown type size: " + size);
                    }
                }

                function __embind_register_bool(rawType, name, size, trueValue, falseValue) {
                    var shift = getShiftFromSize(size);
                    name = readLatin1String(name);
                    registerType(rawType, {
                        name: name,
                        "fromWireType": function fromWireType(wt) {
                            return !!wt;
                        },
                        "toWireType": function toWireType(destructors, o) {
                            return o ? trueValue : falseValue;
                        },
                        "argPackAdvance": 8,
                        "readValueFromPointer": function readValueFromPointer(pointer) {
                            var heap;
                            if (size === 1) {
                                heap = HEAP8;
                            } else if (size === 2) {
                                heap = HEAP16;
                            } else if (size === 4) {
                                heap = HEAP32;
                            } else {
                                throw new TypeError("Unknown boolean type size: " + name);
                            }
                            return this["fromWireType"](heap[pointer >> shift]);
                        },
                        destructorFunction: null
                    });
                }

                function handleAllocatorInit() {
                    Object.assign(HandleAllocator.prototype, {
                        get: function get(id) {
                            assert(this.allocated[id] !== undefined, "invalid handle: " + id);
                            return this.allocated[id];
                        },
                        has: function has(id) {
                            return this.allocated[id] !== undefined;
                        },
                        allocate: function allocate(handle) {
                            var id = this.freelist.pop() || this.allocated.length;
                            this.allocated[id] = handle;
                            return id;
                        },
                        free: function free(id) {
                            assert(this.allocated[id] !== undefined);
                            this.allocated[id] = undefined;
                            this.freelist.push(id);
                        }
                    });
                }

                function HandleAllocator() {
                    this.allocated = [undefined];
                    this.freelist = [];
                }
                var emval_handles = new HandleAllocator();

                function __emval_decref(handle) {
                    if (handle >= emval_handles.reserved && 0 === --emval_handles.get(handle).refcount) {
                        emval_handles.free(handle);
                    }
                }

                function count_emval_handles() {
                    var count = 0;
                    for (var i = emval_handles.reserved; i < emval_handles.allocated.length; ++i) {
                        if (emval_handles.allocated[i] !== undefined) {
                            ++count;
                        }
                    }
                    return count;
                }

                function init_emval() {
                    emval_handles.allocated.push({
                        value: undefined
                    }, {
                        value: null
                    }, {
                        value: true
                    }, {
                        value: false
                    });
                    emval_handles.reserved = emval_handles.allocated.length;
                    Module["count_emval_handles"] = count_emval_handles;
                }
                var Emval = {
                    toValue: function toValue(handle) {
                        if (!handle) {
                            throwBindingError("Cannot use deleted val. handle = " + handle);
                        }
                        return emval_handles.get(handle).value;
                    },
                    toHandle: function toHandle(value) {
                        switch (value) {
                            case undefined:
                                return 1;
                            case null:
                                return 2;
                            case true:
                                return 3;
                            case false:
                                return 4;
                            default:
                                {
                                    return emval_handles.allocate({
                                        refcount: 1,
                                        value: value
                                    });
                                }
                        }
                    }
                };

                function simpleReadValueFromPointer(pointer) {
                    return this["fromWireType"](HEAP32[pointer >> 2]);
                }

                function __embind_register_emval(rawType, name) {
                    name = readLatin1String(name);
                    registerType(rawType, {
                        name: name,
                        "fromWireType": function fromWireType(handle) {
                            var rv = Emval.toValue(handle);
                            __emval_decref(handle);
                            return rv;
                        },
                        "toWireType": function toWireType(destructors, value) {
                            return Emval.toHandle(value);
                        },
                        "argPackAdvance": 8,
                        "readValueFromPointer": simpleReadValueFromPointer,
                        destructorFunction: null
                    });
                }

                function floatReadValueFromPointer(name, shift) {
                    switch (shift) {
                        case 2:
                            return function(pointer) {
                                return this["fromWireType"](HEAPF32[pointer >> 2]);
                            };
                        case 3:
                            return function(pointer) {
                                return this["fromWireType"](HEAPF64[pointer >> 3]);
                            };
                        default:
                            throw new TypeError("Unknown float type: " + name);
                    }
                }

                function __embind_register_float(rawType, name, size) {
                    var shift = getShiftFromSize(size);
                    name = readLatin1String(name);
                    registerType(rawType, {
                        name: name,
                        "fromWireType": function fromWireType(value) {
                            return value;
                        },
                        "toWireType": function toWireType(destructors, value) {
                            if (typeof value != "number" && typeof value != "boolean") {
                                throw new TypeError("Cannot convert " + embindRepr(value) + " to " + this.name);
                            }
                            return value;
                        },
                        "argPackAdvance": 8,
                        "readValueFromPointer": floatReadValueFromPointer(name, shift),
                        destructorFunction: null
                    });
                }

                function __embind_register_integer(primitiveType, name, size, minRange, maxRange) {
                    name = readLatin1String(name);
                    if (maxRange === -1) {
                        maxRange = 4294967295;
                    }
                    var shift = getShiftFromSize(size);
                    var fromWireType = function fromWireType(value) {
                        return value;
                    };
                    if (minRange === 0) {
                        var bitshift = 32 - 8 * size;
                        fromWireType = function fromWireType(value) {
                            return value << bitshift >>> bitshift;
                        };
                    }
                    var isUnsignedType = name.includes("unsigned");
                    var checkAssertions = function checkAssertions(value, toTypeName) {
                        if (typeof value != "number" && typeof value != "boolean") {
                            throw new TypeError("Cannot convert \"" + embindRepr(value) + "\" to " + toTypeName);
                        }
                        if (value < minRange || value > maxRange) {
                            throw new TypeError("Passing a number \"" + embindRepr(value) + "\" from JS side to C/C++ side to an argument of type \"" + name + "\", which is outside the valid range [" + minRange + ", " + maxRange + "]!");
                        }
                    };
                    var toWireType;
                    if (isUnsignedType) {
                        toWireType = function toWireType(destructors, value) {
                            checkAssertions(value, this.name);
                            return value >>> 0;
                        };
                    } else {
                        toWireType = function toWireType(destructors, value) {
                            checkAssertions(value, this.name);
                            return value;
                        };
                    }
                    registerType(primitiveType, {
                        name: name,
                        "fromWireType": fromWireType,
                        "toWireType": toWireType,
                        "argPackAdvance": 8,
                        "readValueFromPointer": integerReadValueFromPointer(name, shift, minRange !== 0),
                        destructorFunction: null
                    });
                }

                function __embind_register_memory_view(rawType, dataTypeIndex, name) {
                    var typeMapping = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array, BigInt64Array, BigUint64Array];
                    var TA = typeMapping[dataTypeIndex];

                    function decodeMemoryView(handle) {
                        handle = handle >> 2;
                        var heap = HEAPU32;
                        var size = heap[handle];
                        var data = heap[handle + 1];
                        return new TA(heap.buffer, data, size);
                    }
                    name = readLatin1String(name);
                    registerType(rawType, {
                        name: name,
                        "fromWireType": decodeMemoryView,
                        "argPackAdvance": 8,
                        "readValueFromPointer": decodeMemoryView
                    }, {
                        ignoreDuplicateRegistrations: true
                    });
                }
                var stringToUTF8Array = function stringToUTF8Array(str, heap, outIdx, maxBytesToWrite) {
                    assert(typeof str === "string");
                    if (!(maxBytesToWrite > 0)) return 0;
                    var startIdx = outIdx;
                    var endIdx = outIdx + maxBytesToWrite - 1;
                    for (var i = 0; i < str.length; ++i) {
                        var u = str.charCodeAt(i);
                        if (u >= 55296 && u <= 57343) {
                            var u1 = str.charCodeAt(++i);
                            u = 65536 + ((u & 1023) << 10) | u1 & 1023;
                        }
                        if (u <= 127) {
                            if (outIdx >= endIdx) break;
                            heap[outIdx++] = u;
                        } else if (u <= 2047) {
                            if (outIdx + 1 >= endIdx) break;
                            heap[outIdx++] = 192 | u >> 6;
                            heap[outIdx++] = 128 | u & 63;
                        } else if (u <= 65535) {
                            if (outIdx + 2 >= endIdx) break;
                            heap[outIdx++] = 224 | u >> 12;
                            heap[outIdx++] = 128 | u >> 6 & 63;
                            heap[outIdx++] = 128 | u & 63;
                        } else {
                            if (outIdx + 3 >= endIdx) break;
                            if (u > 1114111) warnOnce("Invalid Unicode code point " + ptrToString(u) + " encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).");
                            heap[outIdx++] = 240 | u >> 18;
                            heap[outIdx++] = 128 | u >> 12 & 63;
                            heap[outIdx++] = 128 | u >> 6 & 63;
                            heap[outIdx++] = 128 | u & 63;
                        }
                    }
                    heap[outIdx] = 0;
                    return outIdx - startIdx;
                };
                var stringToUTF8 = function stringToUTF8(str, outPtr, maxBytesToWrite) {
                    assert(typeof maxBytesToWrite == "number", "stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
                    return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
                };
                var lengthBytesUTF8 = function lengthBytesUTF8(str) {
                    var len = 0;
                    for (var i = 0; i < str.length; ++i) {
                        var c = str.charCodeAt(i);
                        if (c <= 127) {
                            len++;
                        } else if (c <= 2047) {
                            len += 2;
                        } else if (c >= 55296 && c <= 57343) {
                            len += 4;
                            ++i;
                        } else {
                            len += 3;
                        }
                    }
                    return len;
                };

                function __embind_register_std_string(rawType, name) {
                    name = readLatin1String(name);
                    var stdStringIsUTF8 = name === "std::string";
                    registerType(rawType, {
                        name: name,
                        "fromWireType": function fromWireType(value) {
                            var length = HEAPU32[value >> 2];
                            var payload = value + 4;
                            var str;
                            if (stdStringIsUTF8) {
                                var decodeStartPtr = payload;
                                for (var i = 0; i <= length; ++i) {
                                    var currentBytePtr = payload + i;
                                    if (i == length || HEAPU8[currentBytePtr] == 0) {
                                        var maxRead = currentBytePtr - decodeStartPtr;
                                        var stringSegment = UTF8ToString(decodeStartPtr, maxRead);
                                        if (str === undefined) {
                                            str = stringSegment;
                                        } else {
                                            str += String.fromCharCode(0);
                                            str += stringSegment;
                                        }
                                        decodeStartPtr = currentBytePtr + 1;
                                    }
                                }
                            } else {
                                var a = new Array(length);
                                for (var i = 0; i < length; ++i) {
                                    a[i] = String.fromCharCode(HEAPU8[payload + i]);
                                }
                                str = a.join("");
                            }
                            _free(value);
                            return str;
                        },
                        "toWireType": function toWireType(destructors, value) {
                            if (value instanceof ArrayBuffer) {
                                value = new Uint8Array(value);
                            }
                            var length;
                            var valueIsOfTypeString = typeof value == "string";
                            if (!(valueIsOfTypeString || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Int8Array)) {
                                throwBindingError("Cannot pass non-string to std::string");
                            }
                            if (stdStringIsUTF8 && valueIsOfTypeString) {
                                length = lengthBytesUTF8(value);
                            } else {
                                length = value.length;
                            }
                            var base = _malloc(4 + length + 1);
                            var ptr = base + 4;
                            HEAPU32[base >> 2] = length;
                            if (stdStringIsUTF8 && valueIsOfTypeString) {
                                stringToUTF8(value, ptr, length + 1);
                            } else {
                                if (valueIsOfTypeString) {
                                    for (var i = 0; i < length; ++i) {
                                        var charCode = value.charCodeAt(i);
                                        if (charCode > 255) {
                                            _free(ptr);
                                            throwBindingError("String has UTF-16 code units that do not fit in 8 bits");
                                        }
                                        HEAPU8[ptr + i] = charCode;
                                    }
                                } else {
                                    for (var i = 0; i < length; ++i) {
                                        HEAPU8[ptr + i] = value[i];
                                    }
                                }
                            }
                            if (destructors !== null) {
                                destructors.push(_free, base);
                            }
                            return base;
                        },
                        "argPackAdvance": 8,
                        "readValueFromPointer": simpleReadValueFromPointer,
                        destructorFunction: function destructorFunction(ptr) {
                            _free(ptr);
                        }
                    });
                }
                var UTF16Decoder = typeof TextDecoder != "undefined" ? new TextDecoder("utf-16le") : undefined;
                var UTF16ToString = function UTF16ToString(ptr, maxBytesToRead) {
                    assert(ptr % 2 == 0, "Pointer passed to UTF16ToString must be aligned to two bytes!");
                    var endPtr = ptr;
                    var idx = endPtr >> 1;
                    var maxIdx = idx + maxBytesToRead / 2;
                    while (!(idx >= maxIdx) && HEAPU16[idx]) {
                        ++idx;
                    }
                    endPtr = idx << 1;
                    if (endPtr - ptr > 32 && UTF16Decoder) return UTF16Decoder.decode(HEAPU8.subarray(ptr, endPtr));
                    var str = "";
                    for (var i = 0; !(i >= maxBytesToRead / 2); ++i) {
                        var codeUnit = HEAP16[ptr + i * 2 >> 1];
                        if (codeUnit == 0) break;
                        str += String.fromCharCode(codeUnit);
                    }
                    return str;
                };
                var stringToUTF16 = function stringToUTF16(str, outPtr, maxBytesToWrite) {
                    assert(outPtr % 2 == 0, "Pointer passed to stringToUTF16 must be aligned to two bytes!");
                    assert(typeof maxBytesToWrite == "number", "stringToUTF16(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
                    if (maxBytesToWrite === undefined) {
                        maxBytesToWrite = 2147483647;
                    }
                    if (maxBytesToWrite < 2) return 0;
                    maxBytesToWrite -= 2;
                    var startPtr = outPtr;
                    var numCharsToWrite = maxBytesToWrite < str.length * 2 ? maxBytesToWrite / 2 : str.length;
                    for (var i = 0; i < numCharsToWrite; ++i) {
                        var codeUnit = str.charCodeAt(i);
                        HEAP16[outPtr >> 1] = codeUnit;
                        outPtr += 2;
                    }
                    HEAP16[outPtr >> 1] = 0;
                    return outPtr - startPtr;
                };
                var lengthBytesUTF16 = function lengthBytesUTF16(str) {
                    return str.length * 2;
                };
                var UTF32ToString = function UTF32ToString(ptr, maxBytesToRead) {
                    assert(ptr % 4 == 0, "Pointer passed to UTF32ToString must be aligned to four bytes!");
                    var i = 0;
                    var str = "";
                    while (!(i >= maxBytesToRead / 4)) {
                        var utf32 = HEAP32[ptr + i * 4 >> 2];
                        if (utf32 == 0) break;
                        ++i;
                        if (utf32 >= 65536) {
                            var ch = utf32 - 65536;
                            str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
                        } else {
                            str += String.fromCharCode(utf32);
                        }
                    }
                    return str;
                };
                var stringToUTF32 = function stringToUTF32(str, outPtr, maxBytesToWrite) {
                    assert(outPtr % 4 == 0, "Pointer passed to stringToUTF32 must be aligned to four bytes!");
                    assert(typeof maxBytesToWrite == "number", "stringToUTF32(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
                    if (maxBytesToWrite === undefined) {
                        maxBytesToWrite = 2147483647;
                    }
                    if (maxBytesToWrite < 4) return 0;
                    var startPtr = outPtr;
                    var endPtr = startPtr + maxBytesToWrite - 4;
                    for (var i = 0; i < str.length; ++i) {
                        var codeUnit = str.charCodeAt(i);
                        if (codeUnit >= 55296 && codeUnit <= 57343) {
                            var trailSurrogate = str.charCodeAt(++i);
                            codeUnit = 65536 + ((codeUnit & 1023) << 10) | trailSurrogate & 1023;
                        }
                        HEAP32[outPtr >> 2] = codeUnit;
                        outPtr += 4;
                        if (outPtr + 4 > endPtr) break;
                    }
                    HEAP32[outPtr >> 2] = 0;
                    return outPtr - startPtr;
                };
                var lengthBytesUTF32 = function lengthBytesUTF32(str) {
                    var len = 0;
                    for (var i = 0; i < str.length; ++i) {
                        var codeUnit = str.charCodeAt(i);
                        if (codeUnit >= 55296 && codeUnit <= 57343) ++i;
                        len += 4;
                    }
                    return len;
                };
                var __embind_register_std_wstring = function __embind_register_std_wstring(rawType, charSize, name) {
                    name = readLatin1String(name);
                    var decodeString, encodeString, getHeap, lengthBytesUTF, shift;
                    if (charSize === 2) {
                        decodeString = UTF16ToString;
                        encodeString = stringToUTF16;
                        lengthBytesUTF = lengthBytesUTF16;
                        getHeap = function getHeap() {
                            return HEAPU16;
                        };
                        shift = 1;
                    } else if (charSize === 4) {
                        decodeString = UTF32ToString;
                        encodeString = stringToUTF32;
                        lengthBytesUTF = lengthBytesUTF32;
                        getHeap = function getHeap() {
                            return HEAPU32;
                        };
                        shift = 2;
                    }
                    registerType(rawType, {
                        name: name,
                        "fromWireType": function fromWireType(value) {
                            var length = HEAPU32[value >> 2];
                            var HEAP = getHeap();
                            var str;
                            var decodeStartPtr = value + 4;
                            for (var i = 0; i <= length; ++i) {
                                var currentBytePtr = value + 4 + i * charSize;
                                if (i == length || HEAP[currentBytePtr >> shift] == 0) {
                                    var maxReadBytes = currentBytePtr - decodeStartPtr;
                                    var stringSegment = decodeString(decodeStartPtr, maxReadBytes);
                                    if (str === undefined) {
                                        str = stringSegment;
                                    } else {
                                        str += String.fromCharCode(0);
                                        str += stringSegment;
                                    }
                                    decodeStartPtr = currentBytePtr + charSize;
                                }
                            }
                            _free(value);
                            return str;
                        },
                        "toWireType": function toWireType(destructors, value) {
                            if (!(typeof value == "string")) {
                                throwBindingError("Cannot pass non-string to C++ string type " + name);
                            }
                            var length = lengthBytesUTF(value);
                            var ptr = _malloc(4 + length + charSize);
                            HEAPU32[ptr >> 2] = length >> shift;
                            encodeString(value, ptr + 4, length + charSize);
                            if (destructors !== null) {
                                destructors.push(_free, ptr);
                            }
                            return ptr;
                        },
                        "argPackAdvance": 8,
                        "readValueFromPointer": simpleReadValueFromPointer,
                        destructorFunction: function destructorFunction(ptr) {
                            _free(ptr);
                        }
                    });
                };

                function __embind_register_void(rawType, name) {
                    name = readLatin1String(name);
                    registerType(rawType, {
                        isVoid: true,
                        name: name,
                        "argPackAdvance": 0,
                        "fromWireType": function fromWireType() {
                            return undefined;
                        },
                        "toWireType": function toWireType(destructors, o) {
                            return undefined;
                        }
                    });
                }
                var nowIsMonotonic = true;
                var __emscripten_get_now_is_monotonic = function __emscripten_get_now_is_monotonic() {
                    return nowIsMonotonic;
                };
                var SYSCALLS = {
                    varargs: undefined,
                    get: function get() {
                        assert(SYSCALLS.varargs != undefined);
                        SYSCALLS.varargs += 4;
                        var ret = HEAP32[SYSCALLS.varargs - 4 >> 2];
                        return ret;
                    },
                    getStr: function getStr(ptr) {
                        var ret = UTF8ToString(ptr);
                        return ret;
                    }
                };
                var MAX_INT53 = 9007199254740992;
                var MIN_INT53 = -9007199254740992;

                function bigintToI53Checked(num) {
                    return num < MIN_INT53 || num > MAX_INT53 ? NaN : Number(num);
                }

                function __mmap_js(len, prot, flags, fd, offset, allocated, addr) {
                    len = bigintToI53Checked(len);
                    offset = bigintToI53Checked(offset);
                    allocated = bigintToI53Checked(allocated);
                    addr = bigintToI53Checked(addr);
                    return -52;
                }

                function __munmap_js(addr, len, prot, flags, fd, offset) {
                    addr = bigintToI53Checked(addr);
                    len = bigintToI53Checked(len);
                    offset = bigintToI53Checked(offset);
                }
                var _abort = function _abort() {
                    abort("native code called abort()");
                };
                var _emscripten_console_error = function _emscripten_console_error(str) {
                    assert(typeof str == "number");
                    console.error(UTF8ToString(str));
                };

                function _emscripten_date_now() {
                    return Date.now();
                }
                var _emscripten_get_now;
                _emscripten_get_now = function _emscripten_get_now() {
                    return performance.now();
                };
                var getHeapMax = function getHeapMax() {
                    return 52428800;
                };
                var growMemory = function growMemory(size) {
                    var b = wasmMemory.buffer;
                    var pages = size - b.byteLength + 65535 >>> 16;
                    try {
                        wasmMemory.grow(pages);
                        updateMemoryViews();
                        return 1;
                    } catch (e) {
                        err("growMemory: Attempted to grow heap from " + b.byteLength + " bytes to " + size + " bytes, but got error: " + e);
                    }
                };
                var _emscripten_resize_heap = function _emscripten_resize_heap(requestedSize) {
                    var oldSize = HEAPU8.length;
                    requestedSize >>>= 0;
                    assert(requestedSize > oldSize);
                    var maxHeapSize = getHeapMax();
                    if (requestedSize > maxHeapSize) {
                        err("Cannot enlarge memory, asked to go up to " + requestedSize + " bytes, but the limit is " + maxHeapSize + " bytes!");
                        return false;
                    }
                    var alignUp = function alignUp(x, multiple) {
                        return x + (multiple - x % multiple) % multiple;
                    };
                    for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
                        var overGrownHeapSize = oldSize * (1 + .2 / cutDown);
                        overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296);
                        var newSize = Math.min(maxHeapSize, alignUp(Math.max(requestedSize, overGrownHeapSize), 65536));
                        var replacement = growMemory(newSize);
                        if (replacement) {
                            return true;
                        }
                    }
                    err("Failed to grow the heap from " + oldSize + " bytes to " + newSize + " bytes, not enough memory!");
                    return false;
                };
                var ENV = {};
                var getExecutableName = function getExecutableName() {
                    return thisProgram || "./this.program";
                };
                var getEnvStrings = function getEnvStrings() {
                    if (!getEnvStrings.strings) {
                        var lang = (typeof navigator == "object" && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8";
                        var env = {
                            "USER": "web_user",
                            "LOGNAME": "web_user",
                            "PATH": "/",
                            "PWD": "/",
                            "HOME": "/home/web_user",
                            "LANG": lang,
                            "_": getExecutableName()
                        };
                        for (var x in ENV) {
                            if (ENV[x] === undefined) delete env[x];
                            else env[x] = ENV[x];
                        }
                        var strings = [];
                        for (var x in env) {
                            strings.push(x + "=" + env[x]);
                        }
                        getEnvStrings.strings = strings;
                    }
                    return getEnvStrings.strings;
                };
                var stringToAscii = function stringToAscii(str, buffer) {
                    for (var i = 0; i < str.length; ++i) {
                        assert(str.charCodeAt(i) === (str.charCodeAt(i) & 255));
                        HEAP8[buffer++ >> 0] = str.charCodeAt(i);
                    }
                    HEAP8[buffer >> 0] = 0;
                };
                var _environ_get = function _environ_get(__environ, environ_buf) {
                    var bufSize = 0;
                    getEnvStrings().forEach(function(string, i) {
                        var ptr = environ_buf + bufSize;
                        HEAPU32[__environ + i * 4 >> 2] = ptr;
                        stringToAscii(string, ptr);
                        bufSize += string.length + 1;
                    });
                    return 0;
                };
                var _environ_sizes_get = function _environ_sizes_get(penviron_count, penviron_buf_size) {
                    var strings = getEnvStrings();
                    HEAPU32[penviron_count >> 2] = strings.length;
                    var bufSize = 0;
                    strings.forEach(function(string) {
                        bufSize += string.length + 1;
                    });
                    HEAPU32[penviron_buf_size >> 2] = bufSize;
                    return 0;
                };
                var _fd_close = function _fd_close(fd) {
                    abort("fd_close called without SYSCALLS_REQUIRE_FILESYSTEM");
                };

                function _fd_seek(fd, offset, whence, newOffset) {
                    offset = bigintToI53Checked(offset);
                    newOffset = bigintToI53Checked(newOffset);
                    return 70;
                }
                var printCharBuffers = [null, [],
                    []
                ];
                var printChar = function printChar(stream, curr) {
                    var buffer = printCharBuffers[stream];
                    assert(buffer);
                    if (curr === 0 || curr === 10) {
                        (stream === 1 ? out : err)(UTF8ArrayToString(buffer, 0));
                        buffer.length = 0;
                    } else {
                        buffer.push(curr);
                    }
                };
                var flush_NO_FILESYSTEM = function flush_NO_FILESYSTEM() {
                    _fflush(0);
                    if (printCharBuffers[1].length) printChar(1, 10);
                    if (printCharBuffers[2].length) printChar(2, 10);
                };
                var _fd_write = function _fd_write(fd, iov, iovcnt, pnum) {
                    var num = 0;
                    for (var i = 0; i < iovcnt; i++) {
                        var ptr = HEAPU32[iov >> 2];
                        var len = HEAPU32[iov + 4 >> 2];
                        iov += 8;
                        for (var j = 0; j < len; j++) {
                            printChar(fd, HEAPU8[ptr + j]);
                        }
                        num += len;
                    }
                    HEAPU32[pnum >> 2] = num;
                    return 0;
                };
                var initRandomFill = function initRandomFill() {
                    if (typeof crypto == "object" && typeof crypto["getRandomValues"] == "function") {
                        return function(view) {
                            return crypto.getRandomValues(view);
                        };
                    } else abort("no cryptographic support found for randomDevice. consider polyfilling it if you want to use something insecure like Math.random(), e.g. put this in a --pre-js: var crypto = { getRandomValues: (array) => { for (var i = 0; i < array.length; i++) array[i] = (Math.random()*256)|0 } };");
                };
                var _randomFill = function randomFill(view) {
                    return (_randomFill = initRandomFill())(view);
                };
                var _getentropy = function _getentropy(buffer, size) {
                    _randomFill(HEAPU8.subarray(buffer, buffer + size));
                    return 0;
                };

                function getCFunc(ident) {
                    var func = Module["_" + ident];
                    assert(func, "Cannot call unknown function " + ident + ", make sure it is exported");
                    return func;
                }
                var writeArrayToMemory = function writeArrayToMemory(array, buffer) {
                    assert(array.length >= 0, "writeArrayToMemory array must have a length (should be an array or typed array)");
                    HEAP8.set(array, buffer);
                };
                var stringToUTF8OnStack = function stringToUTF8OnStack(str) {
                    var size = lengthBytesUTF8(str) + 1;
                    var ret = stackAlloc(size);
                    stringToUTF8(str, ret, size);
                    return ret;
                };
                var ccall = function ccall(ident, returnType, argTypes, args, opts) {
                    var toC = {
                        "string": function string(str) {
                            var ret = 0;
                            if (str !== null && str !== undefined && str !== 0) {
                                ret = stringToUTF8OnStack(str);
                            }
                            return ret;
                        },
                        "array": function array(arr) {
                            var ret = stackAlloc(arr.length);
                            writeArrayToMemory(arr, ret);
                            return ret;
                        }
                    };

                    function convertReturnValue(ret) {
                        if (returnType === "string") {
                            return UTF8ToString(ret);
                        }
                        if (returnType === "boolean") return Boolean(ret);
                        return ret;
                    }
                    var func = getCFunc(ident);
                    var cArgs = [];
                    var stack = 0;
                    assert(returnType !== "array", 'Return type should not be "array".');
                    if (args) {
                        for (var i = 0; i < args.length; i++) {
                            var converter = toC[argTypes[i]];
                            if (converter) {
                                if (stack === 0) stack = stackSave();
                                cArgs[i] = converter(args[i]);
                            } else {
                                cArgs[i] = args[i];
                            }
                        }
                    }
                    var ret = func.apply(null, cArgs);

                    function onDone(ret) {
                        if (stack !== 0) stackRestore(stack);
                        return convertReturnValue(ret);
                    }
                    ret = onDone(ret);
                    return ret;
                };

                function uleb128Encode(n, target) {
                    assert(n < 16384);
                    if (n < 128) {
                        target.push(n);
                    } else {
                        target.push(n % 128 | 128, n >> 7);
                    }
                }

                function sigToWasmTypes(sig) {
                    var typeNames = {
                        "i": "i32",
                        "j": "i64",
                        "f": "f32",
                        "d": "f64",
                        "p": "i32"
                    };
                    var type = {
                        parameters: [],
                        results: sig[0] == "v" ? [] : [typeNames[sig[0]]]
                    };
                    for (var i = 1; i < sig.length; ++i) {
                        assert(sig[i] in typeNames, "invalid signature char: " + sig[i]);
                        type.parameters.push(typeNames[sig[i]]);
                    }
                    return type;
                }

                function generateFuncType(sig, target) {
                    var sigRet = sig.slice(0, 1);
                    var sigParam = sig.slice(1);
                    var typeCodes = {
                        "i": 127,
                        "p": 127,
                        "j": 126,
                        "f": 125,
                        "d": 124
                    };
                    target.push(96);
                    uleb128Encode(sigParam.length, target);
                    for (var i = 0; i < sigParam.length; ++i) {
                        assert(sigParam[i] in typeCodes, "invalid signature char: " + sigParam[i]);
                        target.push(typeCodes[sigParam[i]]);
                    }
                    if (sigRet == "v") {
                        target.push(0);
                    } else {
                        target.push(1, typeCodes[sigRet]);
                    }
                }

                function convertJsFunctionToWasm(func, sig) {
                    if (typeof WebAssembly.Function == "function") {
                        return new WebAssembly.Function(sigToWasmTypes(sig), func);
                    }
                    var typeSectionBody = [1];
                    generateFuncType(sig, typeSectionBody);
                    var bytes = [0, 97, 115, 109, 1, 0, 0, 0, 1];
                    uleb128Encode(typeSectionBody.length, bytes);
                    bytes.push.apply(bytes, typeSectionBody);
                    bytes.push(2, 7, 1, 1, 101, 1, 102, 0, 0, 7, 5, 1, 1, 102, 0, 0);
                    var module = new WebAssembly.Module(new Uint8Array(bytes));
                    var instance = new WebAssembly.Instance(module, {
                        "e": {
                            "f": func
                        }
                    });
                    var wrappedFunc = instance.exports["f"];
                    return wrappedFunc;
                }
                var getWasmTableEntry = function getWasmTableEntry(funcPtr) {
                    return wasmTable.get(funcPtr);
                };

                function updateTableMap(offset, count) {
                    if (functionsInTableMap) {
                        for (var i = offset; i < offset + count; i++) {
                            var item = getWasmTableEntry(i);
                            if (item) {
                                functionsInTableMap.set(item, i);
                            }
                        }
                    }
                }
                var functionsInTableMap = undefined;

                function getFunctionAddress(func) {
                    if (!functionsInTableMap) {
                        functionsInTableMap = new WeakMap();
                        updateTableMap(0, wasmTable.length);
                    }
                    return functionsInTableMap.get(func) || 0;
                }
                var freeTableIndexes = [];

                function getEmptyTableSlot() {
                    if (freeTableIndexes.length) {
                        return freeTableIndexes.pop();
                    }
                    try {
                        wasmTable.grow(1);
                    } catch (err) {
                        if (!(err instanceof RangeError)) {
                            throw err;
                        }
                        throw "Unable to grow wasm table. Set ALLOW_TABLE_GROWTH.";
                    }
                    return wasmTable.length - 1;
                }
                var setWasmTableEntry = function setWasmTableEntry(idx, func) {
                    return wasmTable.set(idx, func);
                };

                function addFunction(func, sig) {
                    assert(typeof func != "undefined");
                    var rtn = getFunctionAddress(func);
                    if (rtn) {
                        return rtn;
                    }
                    var ret = getEmptyTableSlot();
                    try {
                        setWasmTableEntry(ret, func);
                    } catch (err) {
                        if (!(err instanceof TypeError)) {
                            throw err;
                        }
                        assert(typeof sig != "undefined", "Missing signature argument to addFunction: " + func);
                        var wrapped = convertJsFunctionToWasm(func, sig);
                        setWasmTableEntry(ret, wrapped);
                    }
                    functionsInTableMap.set(func, ret);
                    return ret;
                }

                function removeFunction(index) {
                    functionsInTableMap["delete"](getWasmTableEntry(index));
                    freeTableIndexes.push(index);
                }
                embind_init_charCodes();
                BindingError = Module["BindingError"] = function(_Error) {
                    "use strict";
                    babelHelpers.inheritsLoose(BindingError, _Error);

                    function BindingError(message) {
                        var _this;
                        _this = _Error.call(this, message) || this;
                        _this.name = "BindingError";
                        return _this;
                    }
                    return BindingError;
                }(babelHelpers.wrapNativeSuper(Error));
                InternalError = Module["InternalError"] = function(_Error2) {
                    "use strict";
                    babelHelpers.inheritsLoose(InternalError, _Error2);

                    function InternalError(message) {
                        var _this2;
                        _this2 = _Error2.call(this, message) || this;
                        _this2.name = "InternalError";
                        return _this2;
                    }
                    return InternalError;
                }(babelHelpers.wrapNativeSuper(Error));
                handleAllocatorInit();
                init_emval();

                function checkIncomingModuleAPI() {
                    ignoredModuleProp("ENVIRONMENT");
                    ignoredModuleProp("GL_MAX_TEXTURE_IMAGE_UNITS");
                    ignoredModuleProp("SDL_canPlayWithWebAudio");
                    ignoredModuleProp("SDL_numSimultaneouslyQueuedBuffers");
                    ignoredModuleProp("INITIAL_MEMORY");
                    ignoredModuleProp("wasmMemory");
                    ignoredModuleProp("arguments");
                    ignoredModuleProp("buffer");
                    ignoredModuleProp("canvas");
                    ignoredModuleProp("doNotCaptureKeyboard");
                    ignoredModuleProp("dynamicLibraries");
                    ignoredModuleProp("elementPointerLock");
                    ignoredModuleProp("extraStackTrace");
                    ignoredModuleProp("forcedAspectRatio");
                    ignoredModuleProp("keyboardListeningElement");
                    ignoredModuleProp("freePreloadedMediaOnUse");
                    ignoredModuleProp("loadSplitModule");
                    ignoredModuleProp("logReadFiles");
                    ignoredModuleProp("mainScriptUrlOrBlob");
                    ignoredModuleProp("mem");
                    ignoredModuleProp("monitorRunDependencies");
                    ignoredModuleProp("noExitRuntime");
                    ignoredModuleProp("noInitialRun");
                    ignoredModuleProp("onAbort");
                    ignoredModuleProp("onCustomMessage");
                    ignoredModuleProp("onExit");
                    ignoredModuleProp("onFree");
                    ignoredModuleProp("onFullScreen");
                    ignoredModuleProp("onMalloc");
                    ignoredModuleProp("onRealloc");
                    ignoredModuleProp("onRuntimeInitialized");
                    ignoredModuleProp("postMainLoop");
                    ignoredModuleProp("postRun");
                    ignoredModuleProp("preInit");
                    ignoredModuleProp("preMainLoop");
                    ignoredModuleProp("preRun");
                    ignoredModuleProp("preinitializedWebGLContext");
                    ignoredModuleProp("memoryInitializerRequest");
                    ignoredModuleProp("preloadPlugins");
                    ignoredModuleProp("print");
                    ignoredModuleProp("printErr");
                    ignoredModuleProp("quit");
                    ignoredModuleProp("setStatus");
                    ignoredModuleProp("statusMessage");
                    ignoredModuleProp("stderr");
                    ignoredModuleProp("stdin");
                    ignoredModuleProp("stdout");
                    ignoredModuleProp("thisProgram");
                    ignoredModuleProp("wasm");
                    ignoredModuleProp("websocket");
                    ignoredModuleProp("fetchSettings");
                }
                var wasmImports = {
                    __assert_fail: ___assert_fail,
                    __cxa_throw: ___cxa_throw,
                    _embind_register_bigint: __embind_register_bigint,
                    _embind_register_bool: __embind_register_bool,
                    _embind_register_emval: __embind_register_emval,
                    _embind_register_float: __embind_register_float,
                    _embind_register_integer: __embind_register_integer,
                    _embind_register_memory_view: __embind_register_memory_view,
                    _embind_register_std_string: __embind_register_std_string,
                    _embind_register_std_wstring: __embind_register_std_wstring,
                    _embind_register_void: __embind_register_void,
                    _emscripten_get_now_is_monotonic: __emscripten_get_now_is_monotonic,
                    _mmap_js: __mmap_js,
                    _munmap_js: __munmap_js,
                    abort: _abort,
                    emscripten_console_error: _emscripten_console_error,
                    emscripten_date_now: _emscripten_date_now,
                    emscripten_get_now: _emscripten_get_now,
                    emscripten_resize_heap: _emscripten_resize_heap,
                    environ_get: _environ_get,
                    environ_sizes_get: _environ_sizes_get,
                    fd_close: _fd_close,
                    fd_seek: _fd_seek,
                    fd_write: _fd_write,
                    getentropy: _getentropy
                };
                var asm = createWasm();
                var ___wasm_call_ctors = createExportWrapper("__wasm_call_ctors");
                var _ACTSanitizer_isXMAValid = Module["_ACTSanitizer_isXMAValid"] = createExportWrapper("ACTSanitizer_isXMAValid");
                var _ACTSanitizer_isMessageTextValid = Module["_ACTSanitizer_isMessageTextValid"] = createExportWrapper("ACTSanitizer_isMessageTextValid");
                var _MEMMobileConfigCurrentProcessContextProviderIsMainApp = Module["_MEMMobileConfigCurrentProcessContextProviderIsMainApp"] = createExportWrapper("MEMMobileConfigCurrentProcessContextProviderIsMainApp");
                var _MEMPayloadVersionProviderGetPlaintextApplicationPayloadVersion = Module["_MEMPayloadVersionProviderGetPlaintextApplicationPayloadVersion"] = createExportWrapper("MEMPayloadVersionProviderGetPlaintextApplicationPayloadVersion");
                var _MEMPayloadVersionProviderGetMinimumSupportedApplicationPayloadVersion = Module["_MEMPayloadVersionProviderGetMinimumSupportedApplicationPayloadVersion"] = createExportWrapper("MEMPayloadVersionProviderGetMinimumSupportedApplicationPayloadVersion");
                var _free = Module["_free"] = createExportWrapper("free");
                var _malloc = Module["_malloc"] = createExportWrapper("malloc");
                var _MsysExceptionHandlerSetCriticalKeyValue = Module["_MsysExceptionHandlerSetCriticalKeyValue"] = createExportWrapper("MsysExceptionHandlerSetCriticalKeyValue");
                var _MsysExceptionHandlerSetKeyValue = Module["_MsysExceptionHandlerSetKeyValue"] = createExportWrapper("MsysExceptionHandlerSetKeyValue");
                var _MCIQPLCreateQPLInfoCopy = Module["_MCIQPLCreateQPLInfoCopy"] = createExportWrapper("MCIQPLCreateQPLInfoCopy");
                var _MCIQPLSetQPLInfo = Module["_MCIQPLSetQPLInfo"] = createExportWrapper("MCIQPLSetQPLInfo");
                var _MsysExecutionCurrentContext = Module["_MsysExecutionCurrentContext"] = createExportWrapper("MsysExecutionCurrentContext");
                var _MsysExecutionCurrentSessionedContext = Module["_MsysExecutionCurrentSessionedContext"] = createExportWrapper("MsysExecutionCurrentSessionedContext");
                var _MsysExecutionCurrentPriority = Module["_MsysExecutionCurrentPriority"] = createExportWrapper("MsysExecutionCurrentPriority");
                var _MsysExecutionSessionless = Module["_MsysExecutionSessionless"] = createExportWrapper("MsysExecutionSessionless");
                var _MsysExecutionSessioned = Module["_MsysExecutionSessioned"] = createExportWrapper("MsysExecutionSessioned");
                var _MsysExecutionEventTrigger = Module["_MsysExecutionEventTrigger"] = createExportWrapper("MsysExecutionEventTrigger");
                var _MsysExecutionContextSetStorage = Module["_MsysExecutionContextSetStorage"] = createExportWrapper("MsysExecutionContextSetStorage");
                var _MsysExecutionContextGetStorage = Module["_MsysExecutionContextGetStorage"] = createExportWrapper("MsysExecutionContextGetStorage");
                var _MsysExecutionContextCreateSystemStorageKey = Module["_MsysExecutionContextCreateSystemStorageKey"] = createExportWrapper("MsysExecutionContextCreateSystemStorageKey");
                var _MsysExecutionContextReleaseSystemStorageKey = Module["_MsysExecutionContextReleaseSystemStorageKey"] = createExportWrapper("MsysExecutionContextReleaseSystemStorageKey");
                var _MCIQPLMarkerAnnotateSingleString = Module["_MCIQPLMarkerAnnotateSingleString"] = createExportWrapper("MCIQPLMarkerAnnotateSingleString");
                var _MCIQPLMarkerIsOn = Module["_MCIQPLMarkerIsOn"] = createExportWrapper("MCIQPLMarkerIsOn");
                var _MCIQPLMarkerAnnotateSingleInt = Module["_MCIQPLMarkerAnnotateSingleInt"] = createExportWrapper("MCIQPLMarkerAnnotateSingleInt");
                var _MCIQPLGetTimestamp = Module["_MCIQPLGetTimestamp"] = createExportWrapper("MCIQPLGetTimestamp");
                var _MCIQPLMarkerPointWithFullAnnotation = Module["_MCIQPLMarkerPointWithFullAnnotation"] = createExportWrapper("MCIQPLMarkerPointWithFullAnnotation");
                var _MsysPlatformTraceGetSamplingRate = Module["_MsysPlatformTraceGetSamplingRate"] = createExportWrapper("MsysPlatformTraceGetSamplingRate");
                var _MCIExtensionExperimentCacheGetMobileConfigBoolean = Module["_MCIExtensionExperimentCacheGetMobileConfigBoolean"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigBoolean");
                var _MCIQPLMarkJoinRequestForE2E = Module["_MCIQPLMarkJoinRequestForE2E"] = createExportWrapper("MCIQPLMarkJoinRequestForE2E");
                var _MCIQPLMarkJoinResponseForE2E = Module["_MCIQPLMarkJoinResponseForE2E"] = createExportWrapper("MCIQPLMarkJoinResponseForE2E");
                var _MCIQPLMarkerStartWithLoggingOptions = Module["_MCIQPLMarkerStartWithLoggingOptions"] = createExportWrapper("MCIQPLMarkerStartWithLoggingOptions");
                var _MCIQPLMarkerEnd = Module["_MCIQPLMarkerEnd"] = createExportWrapper("MCIQPLMarkerEnd");
                var _MCIQPLMarkerPoint = Module["_MCIQPLMarkerPoint"] = createExportWrapper("MCIQPLMarkerPoint");
                var _MCIQPLMarkerPointWithAnnotation = Module["_MCIQPLMarkerPointWithAnnotation"] = createExportWrapper("MCIQPLMarkerPointWithAnnotation");
                var _MCIQPLMarkEvent = Module["_MCIQPLMarkEvent"] = createExportWrapper("MCIQPLMarkEvent");
                var _MCIQPLMarkerAnnotate = Module["_MCIQPLMarkerAnnotate"] = createExportWrapper("MCIQPLMarkerAnnotate");
                var _MCIQPLMarkerDrop = Module["_MCIQPLMarkerDrop"] = createExportWrapper("MCIQPLMarkerDrop");
                var _MCIComponentAttributionLoggerAPICreateArrayOfActiveFlowsIds = Module["_MCIComponentAttributionLoggerAPICreateArrayOfActiveFlowsIds"] = createExportWrapper("MCIComponentAttributionLoggerAPICreateArrayOfActiveFlowsIds");
                var _MCIQPLMarkerAnnotateIntArray = Module["_MCIQPLMarkerAnnotateIntArray"] = createExportWrapper("MCIQPLMarkerAnnotateIntArray");
                var _MCIAppExperimentsGetEnableTraceIDGenerationV2 = Module["_MCIAppExperimentsGetEnableTraceIDGenerationV2"] = createExportWrapper("MCIAppExperimentsGetEnableTraceIDGenerationV2");
                var _MCIAppExperimentsEnableMccErrorLoggingOnArmadilloMediaS2sQPL = Module["_MCIAppExperimentsEnableMccErrorLoggingOnArmadilloMediaS2sQPL"] = createExportWrapper("MCIAppExperimentsEnableMccErrorLoggingOnArmadilloMediaS2sQPL");
                var _MsysSystraceStartSection = Module["_MsysSystraceStartSection"] = createExportWrapper("MsysSystraceStartSection");
                var _MsysSystraceEndSection = Module["_MsysSystraceEndSection"] = createExportWrapper("MsysSystraceEndSection");
                var _MsysCheckpoint = Module["_MsysCheckpoint"] = createExportWrapper("MsysCheckpoint");
                var _MsysSystraceStartCQLSection = Module["_MsysSystraceStartCQLSection"] = createExportWrapper("MsysSystraceStartCQLSection");
                var _MsysSystraceEndCQLSection = Module["_MsysSystraceEndCQLSection"] = createExportWrapper("MsysSystraceEndCQLSection");
                var _MCIQPLMarkerStart = Module["_MCIQPLMarkerStart"] = createExportWrapper("MCIQPLMarkerStart");
                var _MCIQPLMarkerEndWithTimestamp = Module["_MCIQPLMarkerEndWithTimestamp"] = createExportWrapper("MCIQPLMarkerEndWithTimestamp");
                var _MCIQPLMarkerAnnotateDouble = Module["_MCIQPLMarkerAnnotateDouble"] = createExportWrapper("MCIQPLMarkerAnnotateDouble");
                var _MsysAndroidIDProviderCopyAndroidID = Module["_MsysAndroidIDProviderCopyAndroidID"] = createExportWrapper("MsysAndroidIDProviderCopyAndroidID");
                var _MsysValidate = Module["_MsysValidate"] = createExportWrapper("MsysValidate");
                var _MsysFileManagerCopyContentsOfDirectoryAtURL = Module["_MsysFileManagerCopyContentsOfDirectoryAtURL"] = createExportWrapper("MsysFileManagerCopyContentsOfDirectoryAtURL");
                var _MsysFileManagerCopyFile = Module["_MsysFileManagerCopyFile"] = createExportWrapper("MsysFileManagerCopyFile");
                var _MsysFileManagerCreateDataWithContentsOfFile = Module["_MsysFileManagerCreateDataWithContentsOfFile"] = createExportWrapper("MsysFileManagerCreateDataWithContentsOfFile");
                var _MsysFileManagerCreateDirectory = Module["_MsysFileManagerCreateDirectory"] = createExportWrapper("MsysFileManagerCreateDirectory");
                var _MsysFileManagerCreateCacheDirectory = Module["_MsysFileManagerCreateCacheDirectory"] = createExportWrapper("MsysFileManagerCreateCacheDirectory");
                var _MsysFileManagerCreateStringWithContentsOfFile = Module["_MsysFileManagerCreateStringWithContentsOfFile"] = createExportWrapper("MsysFileManagerCreateStringWithContentsOfFile");
                var _MsysFileManagerCreateTemporaryDirectoryURL = Module["_MsysFileManagerCreateTemporaryDirectoryURL"] = createExportWrapper("MsysFileManagerCreateTemporaryDirectoryURL");
                var _MsysFileManagerDeleteItem = Module["_MsysFileManagerDeleteItem"] = createExportWrapper("MsysFileManagerDeleteItem");
                var _MsysFileManagerDeleteDatabaseFile = Module["_MsysFileManagerDeleteDatabaseFile"] = createExportWrapper("MsysFileManagerDeleteDatabaseFile");
                var _MsysFileManagerItemExists = Module["_MsysFileManagerItemExists"] = createExportWrapper("MsysFileManagerItemExists");
                var _MsysFileManagerLinkFile = Module["_MsysFileManagerLinkFile"] = createExportWrapper("MsysFileManagerLinkFile");
                var _MsysFileManagerMoveFile = Module["_MsysFileManagerMoveFile"] = createExportWrapper("MsysFileManagerMoveFile");
                var _MsysFileManagerWriteDataToFile = Module["_MsysFileManagerWriteDataToFile"] = createExportWrapper("MsysFileManagerWriteDataToFile");
                var _MsysFileManagerCopyHomeDirectoryURL = Module["_MsysFileManagerCopyHomeDirectoryURL"] = createExportWrapper("MsysFileManagerCopyHomeDirectoryURL");
                var _MsysFileManagerCopyFileSize = Module["_MsysFileManagerCopyFileSize"] = createExportWrapper("MsysFileManagerCopyFileSize");
                var _MsysFileManagerCopyContentAccessDate = Module["_MsysFileManagerCopyContentAccessDate"] = createExportWrapper("MsysFileManagerCopyContentAccessDate");
                var _MsysFileManagerClearURLResourcePropertyCacheFileSize = Module["_MsysFileManagerClearURLResourcePropertyCacheFileSize"] = createExportWrapper("MsysFileManagerClearURLResourcePropertyCacheFileSize");
                var _MsysFileManagerCopyAvailableDiskSpace = Module["_MsysFileManagerCopyAvailableDiskSpace"] = createExportWrapper("MsysFileManagerCopyAvailableDiskSpace");
                var _MCIExtensionExperimentCacheCreate = Module["_MCIExtensionExperimentCacheCreate"] = createExportWrapper("MCIExtensionExperimentCacheCreate");
                var _MCIExtensionExperimentCacheCreateWithExistingCache = Module["_MCIExtensionExperimentCacheCreateWithExistingCache"] = createExportWrapper("MCIExtensionExperimentCacheCreateWithExistingCache");
                var _MCIExtensionExperimentCacheLogExperimentExposure = Module["_MCIExtensionExperimentCacheLogExperimentExposure"] = createExportWrapper("MCIExtensionExperimentCacheLogExperimentExposure");
                var _MCIExtensionExperimentCacheGetGKValue = Module["_MCIExtensionExperimentCacheGetGKValue"] = createExportWrapper("MCIExtensionExperimentCacheGetGKValue");
                var _MCIExtensionExperimentCacheLogMobileConfigExposure__DEPRECATED = Module["_MCIExtensionExperimentCacheLogMobileConfigExposure__DEPRECATED"] = createExportWrapper("MCIExtensionExperimentCacheLogMobileConfigExposure__DEPRECATED");
                var _MCIExtensionExperimentCacheLogMobileConfigExposure = Module["_MCIExtensionExperimentCacheLogMobileConfigExposure"] = createExportWrapper("MCIExtensionExperimentCacheLogMobileConfigExposure");
                var _MCIExtensionExperimentCacheGetMobileConfigBoolean__DEPRECATED = Module["_MCIExtensionExperimentCacheGetMobileConfigBoolean__DEPRECATED"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigBoolean__DEPRECATED");
                var _MCIExtensionExperimentCacheGetMobileConfigInt64__DEPRECATED = Module["_MCIExtensionExperimentCacheGetMobileConfigInt64__DEPRECATED"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigInt64__DEPRECATED");
                var _MCIExtensionExperimentCacheGetMobileConfigInt64 = Module["_MCIExtensionExperimentCacheGetMobileConfigInt64"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigInt64");
                var _MCIExtensionExperimentCacheGetMobileConfigInt32__DEPRECATED = Module["_MCIExtensionExperimentCacheGetMobileConfigInt32__DEPRECATED"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigInt32__DEPRECATED");
                var _MCIExtensionExperimentCacheGetMobileConfigInt32 = Module["_MCIExtensionExperimentCacheGetMobileConfigInt32"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigInt32");
                var _MCIExtensionExperimentCacheGetMobileConfigDouble__DEPRECATED = Module["_MCIExtensionExperimentCacheGetMobileConfigDouble__DEPRECATED"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigDouble__DEPRECATED");
                var _MCIExtensionExperimentCacheGetMobileConfigDouble = Module["_MCIExtensionExperimentCacheGetMobileConfigDouble"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigDouble");
                var _MCIExtensionExperimentCacheGetMobileConfigString__DEPRECATED = Module["_MCIExtensionExperimentCacheGetMobileConfigString__DEPRECATED"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigString__DEPRECATED");
                var _MCIExtensionExperimentCacheGetMobileConfigString = Module["_MCIExtensionExperimentCacheGetMobileConfigString"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigString");
                var _MCIExtensionExperimentCacheSetMobileConfigCache = Module["_MCIExtensionExperimentCacheSetMobileConfigCache"] = createExportWrapper("MCIExtensionExperimentCacheSetMobileConfigCache");
                var _MCIExtensionExperimentCacheSetGKCache = Module["_MCIExtensionExperimentCacheSetGKCache"] = createExportWrapper("MCIExtensionExperimentCacheSetGKCache");
                var _MCIExtensionExperimentCacheGetMobileConfigCacheIsSet = Module["_MCIExtensionExperimentCacheGetMobileConfigCacheIsSet"] = createExportWrapper("MCIExtensionExperimentCacheGetMobileConfigCacheIsSet");
                var _MCIExtensionExperimentCacheCopyGKCache = Module["_MCIExtensionExperimentCacheCopyGKCache"] = createExportWrapper("MCIExtensionExperimentCacheCopyGKCache");
                var _MCIExtensionExperimentCacheGetInternalObject_DO_NOT_USE = Module["_MCIExtensionExperimentCacheGetInternalObject_DO_NOT_USE"] = createExportWrapper("MCIExtensionExperimentCacheGetInternalObject_DO_NOT_USE");
                var _MCIQPLStartQPLInfoPropagation = Module["_MCIQPLStartQPLInfoPropagation"] = createExportWrapper("MCIQPLStartQPLInfoPropagation");
                var _MCIQPLStopQPLInfoPropagation = Module["_MCIQPLStopQPLInfoPropagation"] = createExportWrapper("MCIQPLStopQPLInfoPropagation");
                var _MCIQPLGetInstanceKey = Module["_MCIQPLGetInstanceKey"] = createExportWrapper("MCIQPLGetInstanceKey");
                var _MCIQPLCreatePropagatedQPLInfoSnapshot = Module["_MCIQPLCreatePropagatedQPLInfoSnapshot"] = createExportWrapper("MCIQPLCreatePropagatedQPLInfoSnapshot");
                var _MCIQPLRestoreQPLInfoFromSnapshotId = Module["_MCIQPLRestoreQPLInfoFromSnapshotId"] = createExportWrapper("MCIQPLRestoreQPLInfoFromSnapshotId");
                var _MCIQPLMarkerAnnotateBool = Module["_MCIQPLMarkerAnnotateBool"] = createExportWrapper("MCIQPLMarkerAnnotateBool");
                var _MCIQPLGenerateFlowId = Module["_MCIQPLGenerateFlowId"] = createExportWrapper("MCIQPLGenerateFlowId");
                var _MsysStats = Module["_MsysStats"] = createExportWrapper("MsysStats");
                var _MCIAppExperimentsGetEnableReadOnlyForAllReadOnlyFunctions = Module["_MCIAppExperimentsGetEnableReadOnlyForAllReadOnlyFunctions"] = createExportWrapper("MCIAppExperimentsGetEnableReadOnlyForAllReadOnlyFunctions");
                var _MCIAppExperimentsGetEnableVMStackCachingInDasm = Module["_MCIAppExperimentsGetEnableVMStackCachingInDasm"] = createExportWrapper("MCIAppExperimentsGetEnableVMStackCachingInDasm");
                var _MCIAppExperimentsGetEnableAuthDataCheck = Module["_MCIAppExperimentsGetEnableAuthDataCheck"] = createExportWrapper("MCIAppExperimentsGetEnableAuthDataCheck");
                var _MCIAppExperimentsGetEnableBoxedAllocForDasm = Module["_MCIAppExperimentsGetEnableBoxedAllocForDasm"] = createExportWrapper("MCIAppExperimentsGetEnableBoxedAllocForDasm");
                var _MCIAppExperimentsAllowThreadViewReadOnlyConnectionUsage = Module["_MCIAppExperimentsAllowThreadViewReadOnlyConnectionUsage"] = createExportWrapper("MCIAppExperimentsAllowThreadViewReadOnlyConnectionUsage");
                var _MCIAppExperimentsEnablePlatformTTCTracking = Module["_MCIAppExperimentsEnablePlatformTTCTracking"] = createExportWrapper("MCIAppExperimentsEnablePlatformTTCTracking");
                var _MCIAppExperimentsAllowROConnectionForPinnedMessages = Module["_MCIAppExperimentsAllowROConnectionForPinnedMessages"] = createExportWrapper("MCIAppExperimentsAllowROConnectionForPinnedMessages");
                var _MCIAppExperimentsAllowThreadViewDataOnlyMediaMessagesReadOnly = Module["_MCIAppExperimentsAllowThreadViewDataOnlyMediaMessagesReadOnly"] = createExportWrapper("MCIAppExperimentsAllowThreadViewDataOnlyMediaMessagesReadOnly");
                var _MCIAppExperimentsAllowLoadThreadViewDataReadOnly = Module["_MCIAppExperimentsAllowLoadThreadViewDataReadOnly"] = createExportWrapper("MCIAppExperimentsAllowLoadThreadViewDataReadOnly");
                var _MCIAppExperimentsAllowROConnectionForMailboxThreadThemeLoad = Module["_MCIAppExperimentsAllowROConnectionForMailboxThreadThemeLoad"] = createExportWrapper("MCIAppExperimentsAllowROConnectionForMailboxThreadThemeLoad");
                var _MCIAppExperimentsAllowROConnectionForEchoInitialization = Module["_MCIAppExperimentsAllowROConnectionForEchoInitialization"] = createExportWrapper("MCIAppExperimentsAllowROConnectionForEchoInitialization");
                var _MCIAppExperimentsRunContactPkMigrationOnUpgrade = Module["_MCIAppExperimentsRunContactPkMigrationOnUpgrade"] = createExportWrapper("MCIAppExperimentsRunContactPkMigrationOnUpgrade");
                var _MCIAppExperimentsIsOnUpgradeOrInstall = Module["_MCIAppExperimentsIsOnUpgradeOrInstall"] = createExportWrapper("MCIAppExperimentsIsOnUpgradeOrInstall");
                var _MCIAppExperimentsUseNativeQPL = Module["_MCIAppExperimentsUseNativeQPL"] = createExportWrapper("MCIAppExperimentsUseNativeQPL");
                var _MCIAppExperimentsDbContextOffloadOrcaLoadThreadViewDataDelay = Module["_MCIAppExperimentsDbContextOffloadOrcaLoadThreadViewDataDelay"] = createExportWrapper("MCIAppExperimentsDbContextOffloadOrcaLoadThreadViewDataDelay");
                var _MCIAppExperimentsHandleUpdateDBOffload = Module["_MCIAppExperimentsHandleUpdateDBOffload"] = createExportWrapper("MCIAppExperimentsHandleUpdateDBOffload");
                var _MsysEventLogSubscriberLog = Module["_MsysEventLogSubscriberLog"] = createExportWrapper("MsysEventLogSubscriberLog");
                var _MsysEventLogSubscriberGetSchemaId = Module["_MsysEventLogSubscriberGetSchemaId"] = createExportWrapper("MsysEventLogSubscriberGetSchemaId");
                var _MsysTransportLogSubscriberGetTransportKeys = Module["_MsysTransportLogSubscriberGetTransportKeys"] = createExportWrapper("MsysTransportLogSubscriberGetTransportKeys");
                var _MsysTransportLogSubscriberLog = Module["_MsysTransportLogSubscriberLog"] = createExportWrapper("MsysTransportLogSubscriberLog");
                var _MCIComponentAttributionLoggerAPIComponentStart = Module["_MCIComponentAttributionLoggerAPIComponentStart"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentStart");
                var _MCIComponentAttributionLoggerAPIComponentPoint = Module["_MCIComponentAttributionLoggerAPIComponentPoint"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentPoint");
                var _MCIComponentAttributionLoggerAPIComponentAnnotateBool = Module["_MCIComponentAttributionLoggerAPIComponentAnnotateBool"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentAnnotateBool");
                var _MCIComponentAttributionLoggerAPIComponentAnnotateString = Module["_MCIComponentAttributionLoggerAPIComponentAnnotateString"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentAnnotateString");
                var _MCIComponentAttributionLoggerAPIComponentAnnotateDouble = Module["_MCIComponentAttributionLoggerAPIComponentAnnotateDouble"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentAnnotateDouble");
                var _MCIComponentAttributionLoggerAPIComponentAnnotateInt = Module["_MCIComponentAttributionLoggerAPIComponentAnnotateInt"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentAnnotateInt");
                var _MCIComponentAttributionLoggerAPIComponentEvent = Module["_MCIComponentAttributionLoggerAPIComponentEvent"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentEvent");
                var _MCIComponentAttributionLoggerAPIComponentEnd = Module["_MCIComponentAttributionLoggerAPIComponentEnd"] = createExportWrapper("MCIComponentAttributionLoggerAPIComponentEnd");
                var _fflush = Module["_fflush"] = createExportWrapper("fflush");
                var _MsysLoggingDestinationProviderGetLoggingDestinations = Module["_MsysLoggingDestinationProviderGetLoggingDestinations"] = createExportWrapper("MsysLoggingDestinationProviderGetLoggingDestinations");
                var _MsysLoggingMaxLevelEnabledGet = Module["_MsysLoggingMaxLevelEnabledGet"] = createExportWrapper("MsysLoggingMaxLevelEnabledGet");
                var _MsysTripwireReportFailure = Module["_MsysTripwireReportFailure"] = createExportWrapper("MsysTripwireReportFailure");
                var _MEMMobileConfigPlatformGetBooleanUsingAuthDataContext = Module["_MEMMobileConfigPlatformGetBooleanUsingAuthDataContext"] = createExportWrapper("MEMMobileConfigPlatformGetBooleanUsingAuthDataContext");
                var _MEMMobileConfigPlatformGetInt32UsingAuthDataContext = Module["_MEMMobileConfigPlatformGetInt32UsingAuthDataContext"] = createExportWrapper("MEMMobileConfigPlatformGetInt32UsingAuthDataContext");
                var _MEMMobileConfigPlatformGetInt64UsingAuthDataContext = Module["_MEMMobileConfigPlatformGetInt64UsingAuthDataContext"] = createExportWrapper("MEMMobileConfigPlatformGetInt64UsingAuthDataContext");
                var _MEMMobileConfigPlatformGetDoubleUsingAuthDataContext = Module["_MEMMobileConfigPlatformGetDoubleUsingAuthDataContext"] = createExportWrapper("MEMMobileConfigPlatformGetDoubleUsingAuthDataContext");
                var _MEMMobileConfigPlatformCopyStringUsingAuthDataContext = Module["_MEMMobileConfigPlatformCopyStringUsingAuthDataContext"] = createExportWrapper("MEMMobileConfigPlatformCopyStringUsingAuthDataContext");
                var _MEMMobileConfigPlatformGetBooleanUsingDb = Module["_MEMMobileConfigPlatformGetBooleanUsingDb"] = createExportWrapper("MEMMobileConfigPlatformGetBooleanUsingDb");
                var _MEMMobileConfigPlatformGetInt32UsingDb = Module["_MEMMobileConfigPlatformGetInt32UsingDb"] = createExportWrapper("MEMMobileConfigPlatformGetInt32UsingDb");
                var _MEMMobileConfigPlatformGetInt64UsingDb = Module["_MEMMobileConfigPlatformGetInt64UsingDb"] = createExportWrapper("MEMMobileConfigPlatformGetInt64UsingDb");
                var _MEMMobileConfigPlatformGetDoubleUsingDb = Module["_MEMMobileConfigPlatformGetDoubleUsingDb"] = createExportWrapper("MEMMobileConfigPlatformGetDoubleUsingDb");
                var _MEMMobileConfigPlatformCopyStringUsingDb = Module["_MEMMobileConfigPlatformCopyStringUsingDb"] = createExportWrapper("MEMMobileConfigPlatformCopyStringUsingDb");
                var ___errno_location = createExportWrapper("__errno_location");
                var ___getTypeName = createExportWrapper("__getTypeName");
                var __embind_initialize_bindings = Module["__embind_initialize_bindings"] = createExportWrapper("_embind_initialize_bindings");
                var setTempRet0 = createExportWrapper("setTempRet0");
                var _emscripten_stack_init2 = function _emscripten_stack_init() {
                    return (_emscripten_stack_init2 = wasmExports["emscripten_stack_init"])();
                };
                var _emscripten_stack_get_free2 = function _emscripten_stack_get_free() {
                    return (_emscripten_stack_get_free2 = wasmExports["emscripten_stack_get_free"])();
                };
                var _emscripten_stack_get_base2 = function _emscripten_stack_get_base() {
                    return (_emscripten_stack_get_base2 = wasmExports["emscripten_stack_get_base"])();
                };
                var _emscripten_stack_get_end2 = function _emscripten_stack_get_end() {
                    return (_emscripten_stack_get_end2 = wasmExports["emscripten_stack_get_end"])();
                };
                var stackSave = createExportWrapper("stackSave");
                var stackRestore = createExportWrapper("stackRestore");
                var stackAlloc = createExportWrapper("stackAlloc");
                var _emscripten_stack_get_current2 = function _emscripten_stack_get_current() {
                    return (_emscripten_stack_get_current2 = wasmExports["emscripten_stack_get_current"])();
                };
                var ___cxa_increment_exception_refcount = createExportWrapper("__cxa_increment_exception_refcount");
                var ___cxa_can_catch = createExportWrapper("__cxa_can_catch");
                var ___cxa_is_pointer_type = createExportWrapper("__cxa_is_pointer_type");
                var _ls_waterfall_sampling = Module["_ls_waterfall_sampling"] = 185800;
                var _msys_sync_config = Module["_msys_sync_config"] = 185824;
                var _enable_connectivity_status_client_table = Module["_enable_connectivity_status_client_table"] = 186472;
                var _ls_mci_trace_session_based_config = Module["_ls_mci_trace_session_based_config"] = 186520;
                var _msys_db_query = Module["_msys_db_query"] = 188056;
                var _messenger_e2e_pre_qpl_config = Module["_messenger_e2e_pre_qpl_config"] = 200296;
                var _enable_sqlite_error_callback_logging = Module["_enable_sqlite_error_callback_logging"] = 188080;
                var _msys_task_system_v2 = Module["_msys_task_system_v2"] = 188152;
                var _msys_traffic_control = Module["_msys_traffic_control"] = 188224;
                var _msys_validate_foreign_keys_from_sync_receiver = Module["_msys_validate_foreign_keys_from_sync_receiver"] = 188416;
                var _platform_trace_session_based_config = Module["_platform_trace_session_based_config"] = 200440;
                var _msys_internal_congestion = Module["_msys_internal_congestion"] = 188440;
                var _msys_database_configurations = Module["_msys_database_configurations"] = 189088;
                var _msgr_db_query_optimizations = Module["_msgr_db_query_optimizations"] = 189112;
                var _mci_telemetry_session_based_config = Module["_mci_telemetry_session_based_config"] = 189424;
                var _msgr_ios_media_picker = Module["_msgr_ios_media_picker"] = 189448;
                var _enable_cql_throw_logging = Module["_enable_cql_throw_logging"] = 189928;
                var _msys_read_only_connection = Module["_msys_read_only_connection"] = 189952;
                var _msys_task_congestion = Module["_msys_task_congestion"] = 190816;
                var _msys_database_notification_configs = Module["_msys_database_notification_configs"] = 191080;
                var _messaging_media_and_storage = Module["_messaging_media_and_storage"] = 191104;
                var _msys_drop_logging_on_background = Module["_msys_drop_logging_on_background"] = 192808;
                var _msgr_ios_messaging_media_quality = Module["_msgr_ios_messaging_media_quality"] = 192832;
                var _task_system_new_retry = Module["_task_system_new_retry"] = 193e3;
                var _messenger_db_health_recovery = Module["_messenger_db_health_recovery"] = 193072;
                var _sync_groups_priority_v2 = Module["_sync_groups_priority_v2"] = 193360;
                var _msgr_db_in_memory_tables = Module["_msgr_db_in_memory_tables"] = 193456;
                var _msgr_health_e2e = Module["_msgr_health_e2e"] = 193528;
                var _msys_xstack_config = Module["_msys_xstack_config"] = 193552;
                var _msys_arc = Module["_msys_arc"] = 193576;
                var _ls_connectivity_banner = Module["_ls_connectivity_banner"] = 193600;
                var _msys_sync_xstack_config = Module["_msys_sync_xstack_config"] = 193624;
                var _msys_wal_hook = Module["_msys_wal_hook"] = 193792;
                var _msys_api_instrumentation = Module["_msys_api_instrumentation"] = 200104;
                var _ls_echo = Module["_ls_echo"] = 199648;
                var _platform_trace_session_based_config_v2 = Module["_platform_trace_session_based_config_v2"] = 200968;
                var _ls_mobileconfig_secure_message_over_wa = Module["_ls_mobileconfig_secure_message_over_wa"] = 193816;
                var _mark_crypto_tasks_critical = Module["_mark_crypto_tasks_critical"] = 200992;
                var _xplat_messaging_rust = Module["_xplat_messaging_rust"] = 201040;
                Module["wasmMemory"] = wasmMemory;
                Module["ccall"] = ccall;
                Module["addFunction"] = addFunction;
                Module["removeFunction"] = removeFunction;
                Module["setValue"] = setValue;
                Module["getValue"] = getValue;
                var missingLibrarySymbols = ["writeI53ToI64", "writeI53ToI64Clamped", "writeI53ToI64Signaling", "writeI53ToU64Clamped", "writeI53ToU64Signaling", "readI53FromI64", "readI53FromU64", "convertI32PairToI53", "convertI32PairToI53Checked", "convertU32PairToI53", "zeroMemory", "exitJS", "isLeapYear", "ydayFromDate", "arraySum", "addDays", "setErrNo", "inetPton4", "inetNtop4", "inetPton6", "inetNtop6", "readSockaddr", "writeSockaddr", "getHostByName", "getCallstack", "emscriptenLog", "convertPCtoSourceLocation", "readEmAsmArgs", "jstoi_q", "jstoi_s", "listenOnce", "autoResumeAudioContext", "getDynCaller", "dynCall", "handleException", "runtimeKeepalivePush", "runtimeKeepalivePop", "callUserCallback", "maybeExit", "safeSetTimeout", "asmjsMangle", "asyncLoad", "alignMemory", "mmapAlloc", "getNativeTypeSize", "STACK_SIZE", "STACK_ALIGN", "POINTER_SIZE", "ASSERTIONS", "cwrap", "reallyNegative", "unSign", "strLen", "reSign", "formatString", "intArrayFromString", "intArrayToString", "AsciiToString", "stringToNewUTF8", "registerKeyEventCallback", "maybeCStringToJsString", "findEventTarget", "findCanvasEventTarget", "getBoundingClientRect", "fillMouseEventData", "registerMouseEventCallback", "registerWheelEventCallback", "registerUiEventCallback", "registerFocusEventCallback", "fillDeviceOrientationEventData", "registerDeviceOrientationEventCallback", "fillDeviceMotionEventData", "registerDeviceMotionEventCallback", "screenOrientation", "fillOrientationChangeEventData", "registerOrientationChangeEventCallback", "fillFullscreenChangeEventData", "registerFullscreenChangeEventCallback", "JSEvents_requestFullscreen", "JSEvents_resizeCanvasForFullscreen", "registerRestoreOldStyle", "hideEverythingExceptGivenElement", "restoreHiddenElements", "setLetterbox", "softFullscreenResizeWebGLRenderTarget", "doRequestFullscreen", "fillPointerlockChangeEventData", "registerPointerlockChangeEventCallback", "registerPointerlockErrorEventCallback", "requestPointerLock", "fillVisibilityChangeEventData", "registerVisibilityChangeEventCallback", "registerTouchEventCallback", "fillGamepadEventData", "registerGamepadEventCallback", "registerBeforeUnloadEventCallback", "fillBatteryEventData", "battery", "registerBatteryEventCallback", "setCanvasElementSize", "getCanvasElementSize", "demangle", "demangleAll", "jsStackTrace", "stackTrace", "checkWasiClock", "wasiRightsToMuslOFlags", "wasiOFlagsToMuslOFlags", "createDyncallWrapper", "setImmediateWrapped", "clearImmediateWrapped", "polyfillSetImmediate", "getPromise", "makePromise", "idsToPromises", "makePromiseCallback", "findMatchingCatch", "setMainLoop", "getSocketFromFD", "getSocketAddress", "heapObjectForWebGLType", "heapAccessShiftForWebGLHeap", "webgl_enable_ANGLE_instanced_arrays", "webgl_enable_OES_vertex_array_object", "webgl_enable_WEBGL_draw_buffers", "webgl_enable_WEBGL_multi_draw", "emscriptenWebGLGet", "computeUnpackAlignedImageSize", "colorChannelsInGlTextureFormat", "emscriptenWebGLGetTexPixelData", "__glGenObject", "emscriptenWebGLGetUniform", "webglGetUniformLocation", "webglPrepareUniformLocationsBeforeFirstUse", "webglGetLeftBracePos", "emscriptenWebGLGetVertexAttrib", "__glGetActiveAttribOrUniform", "writeGLArray", "registerWebGlEventCallback", "runAndAbortIfError", "SDL_unicode", "SDL_ttfContext", "SDL_audio", "GLFW_Window", "ALLOC_NORMAL", "ALLOC_STACK", "allocate", "writeStringToMemory", "writeAsciiToMemory", "getTypeName", "heap32VectorToArray", "requireRegisteredType", "init_embind", "throwUnboundTypeError", "ensureOverloadTable", "exposePublicSymbol", "replacePublicSymbol", "extendError", "createNamedFunction", "getBasestPointer", "registerInheritedInstance", "unregisterInheritedInstance", "getInheritedInstance", "getInheritedInstanceCount", "getLiveInheritedInstances", "enumReadValueFromPointer", "runDestructors", "craftInvokerFunction", "embind__requireFunction", "genericPointerToWireType", "constNoSmartPtrRawPointerToWireType", "nonConstNoSmartPtrRawPointerToWireType", "init_RegisteredPointer", "RegisteredPointer", "RegisteredPointer_getPointee", "RegisteredPointer_destructor", "RegisteredPointer_deleteObject", "RegisteredPointer_fromWireType", "runDestructor", "releaseClassHandle", "detachFinalizer", "attachFinalizer", "makeClassHandle", "init_ClassHandle", "ClassHandle", "ClassHandle_isAliasOf", "throwInstanceAlreadyDeleted", "ClassHandle_clone", "ClassHandle_delete", "ClassHandle_isDeleted", "ClassHandle_deleteLater", "flushPendingDeletes", "setDelayFunction", "RegisteredClass", "shallowCopyInternalPointer", "downcastPointer", "upcastPointer", "validateThis", "char_0", "char_9", "makeLegalFunctionName", "getStringOrSymbol", "craftEmvalAllocator", "emval_get_global", "emval_lookupTypes", "emval_allocateDestructors", "emval_addMethodCaller"];
                missingLibrarySymbols.forEach(missingLibrarySymbol);
                var unexportedSymbols = ["run", "addOnPreRun", "addOnInit", "addOnPreMain", "addOnExit", "addOnPostRun", "addRunDependency", "removeRunDependency", "FS_createFolder", "FS_createPath", "FS_createDataFile", "FS_createLazyFile", "FS_createLink", "FS_createDevice", "FS_unlink", "out", "err", "callMain", "abort", "keepRuntimeAlive", "wasmTable", "wasmExports", "stackAlloc", "stackSave", "stackRestore", "getTempRet0", "setTempRet0", "writeStackCookie", "checkStackCookie", "MAX_INT53", "MIN_INT53", "bigintToI53Checked", "ptrToString", "getHeapMax", "growMemory", "ENV", "MONTH_DAYS_REGULAR", "MONTH_DAYS_LEAP", "MONTH_DAYS_REGULAR_CUMULATIVE", "MONTH_DAYS_LEAP_CUMULATIVE", "ERRNO_CODES", "ERRNO_MESSAGES", "DNS", "Protocols", "Sockets", "initRandomFill", "randomFill", "timers", "warnOnce", "UNWIND_CACHE", "readEmAsmArgsArray", "getExecutableName", "setWasmTableEntry", "getWasmTableEntry", "handleAllocatorInit", "HandleAllocator", "getCFunc", "uleb128Encode", "sigToWasmTypes", "generateFuncType", "convertJsFunctionToWasm", "freeTableIndexes", "functionsInTableMap", "getEmptyTableSlot", "updateTableMap", "getFunctionAddress", "PATH", "PATH_FS", "UTF8Decoder", "UTF8ArrayToString", "UTF8ToString", "stringToUTF8Array", "stringToUTF8", "lengthBytesUTF8", "stringToAscii", "UTF16Decoder", "UTF16ToString", "stringToUTF16", "lengthBytesUTF16", "UTF32ToString", "stringToUTF32", "lengthBytesUTF32", "stringToUTF8OnStack", "writeArrayToMemory", "JSEvents", "specialHTMLTargets", "currentFullscreenStrategy", "restoreOldWindowedStyle", "ExitStatus", "getEnvStrings", "flush_NO_FILESYSTEM", "promiseMap", "uncaughtExceptionCount", "exceptionLast", "exceptionCaught", "ExceptionInfo", "Browser", "wget", "SYSCALLS", "tempFixedLengthArray", "miniTempWebGLFloatBuffers", "miniTempWebGLIntBuffers", "GL", "emscripten_webgl_power_preferences", "AL", "GLUT", "EGL", "GLEW", "IDBStore", "SDL", "SDL_gfx", "GLFW", "allocateUTF8", "allocateUTF8OnStack", "InternalError", "BindingError", "throwInternalError", "throwBindingError", "registeredTypes", "awaitingDependencies", "typeDependencies", "tupleRegistrations", "structRegistrations", "sharedRegisterType", "whenDependentTypesAreResolved", "embind_charCodes", "embind_init_charCodes", "readLatin1String", "UnboundTypeError", "PureVirtualError", "embindRepr", "registeredInstances", "registeredPointers", "registerType", "getShiftFromSize", "integerReadValueFromPointer", "floatReadValueFromPointer", "simpleReadValueFromPointer", "finalizationRegistry", "detachFinalizer_deps", "deletionQueue", "delayFunction", "emval_handles", "emval_symbols", "init_emval", "count_emval_handles", "Emval", "emval_newers", "emval_methodCallers", "emval_registeredMethods"];
                unexportedSymbols.forEach(unexportedRuntimeSymbol);
                var calledRun;
                dependenciesFulfilled = function runCaller() {
                    if (!calledRun) run();
                    if (!calledRun) dependenciesFulfilled = runCaller;
                };

                function stackCheckInit() {
                    _emscripten_stack_init2();
                    writeStackCookie();
                }

                function run() {
                    if (runDependencies > 0) {
                        return;
                    }
                    stackCheckInit();
                    preRun();
                    if (runDependencies > 0) {
                        return;
                    }

                    function doRun() {
                        if (calledRun) return;
                        calledRun = true;
                        Module["calledRun"] = true;
                        if (ABORT) return;
                        initRuntime();
                        readyPromiseResolve(Module);
                        assert(!Module["_main"], 'compiled without a main, but one is present. if you added it from JS, use Module["onRuntimeInitialized"]');
                        postRun();
                    } {
                        doRun();
                    }
                    checkStackCookie();
                }
                run();


                return moduleArg.ready;
            });


    }();
    if (typeof exports === 'object' && typeof module === 'object')
        module.exports = Module;
    else
    if (typeof define === 'function' && define['amd'])
        define([], function() {
            return Module;
        });
}), null);