; /*FB_PKG_DELIM*/

__d("LSGetParentThreadKey", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(e) {
            return b.sequence([function(d) {
                return b.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, d) {
                    var e = a.done;
                    a = a.value;
                    return e ? c[0] = b.i64.cast([0, 0]) : (d = a.item, c[0] = d.parentThreadKey)
                })
            }, function(a) {
                return d[0] = c[0]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSMailboxGetParentThreadKeyStoredProcedure";
    e.exports = a
}), null);
__d("LSMarkThreadReadV2", ["LSGetViewerFBID"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var e = a.done;
                    a = a.value;
                    return e ? d[0] = c.i64.cast([0, 0]) : (b = a.item, d[0] = b.lastActivityTimestampMs)
                })
            }, function(e) {
                return c.i64.gt(d[0], a[1]) ? c.sequence([function(a) {
                    return c.storedProcedure(b("LSGetViewerFBID")).then(function(a) {
                        return a = a, d[2] = a[0], a
                    })
                }, function(b) {
                    return c.count(c.filter(c.db.table(12).fetch([
                        [
                            [a[0], {
                                gt: a[1]
                            }]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.threadKey, a[0]) && c.i64.eq(b.senderId, d[2]) && c.i64.gt(b.timestampMs, a[1])
                    })).then(function(a) {
                        return d[3] = a
                    })
                }, function(b) {
                    return c.count(c.db.table(12).fetch([
                        [
                            [a[0], {
                                gt: a[1]
                            }]
                        ]
                    ])).then(function(a) {
                        return d[4] = a
                    })
                }, function(b) {
                    return c.i64.eq(d[3], d[4]) && c.i64.gt(d[4], c.i64.cast([0, 0])) ? c.forEach(c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(a) {
                        var b = a.update;
                        a = a.item;
                        return b({
                            lastReadWatermarkTimestampMs: a.lastActivityTimestampMs
                        })
                    }) : c.forEach(c.filter(c.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(b) {
                        return c.i64.eq(b.threadKey, a[0]) && c.i64.gt(a[1], b.lastReadWatermarkTimestampMs)
                    }), function(b) {
                        var c = b.update;
                        b.item;
                        return c({
                            lastReadWatermarkTimestampMs: a[1]
                        })
                    })
                }]) : c.forEach(c.filter(c.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(b) {
                    return c.i64.eq(b.threadKey, a[0]) && c.i64.gt(a[1], b.lastReadWatermarkTimestampMs)
                }), function(b) {
                    var c = b.update;
                    b.item;
                    return c({
                        lastReadWatermarkTimestampMs: a[1]
                    })
                })
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxMarkThreadReadV2StoredProcedure";
    e.exports = a
}), null);
__d("LSReceiveMarkThreadReadNative", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(e) {
            return b.sequence([function(d) {
                return b.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]).next().then(function(a, b) {
                    var d = a.done;
                    a = a.value;
                    return d ? c[0] = void 0 : (b = a.item, c[0] = b.lastReadWatermarkTimestampMs)
                })
            }, function(d) {
                return b.i64.neq(c[0], void 0) && b.i64.neq(a[1], void 0) && b.i64.gt(a[1], c[0]) ? c[2] = a[1] : c[2] = void 0, b.i64.neq(c[2], void 0) ? b.sequence([function(d) {
                    return b.forEach(b.db.table(9).fetch([
                        [
                            [a[0]]
                        ]
                    ]), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            lastReadWatermarkTimestampMs: c[2]
                        })
                    })
                }, function(a) {
                    return c[3] = c[2]
                }]) : b.resolve(c[3] = void 0)
            }, function(a) {
                return d[0] = c[3]
            }])
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxReceiveMarkThreadReadNativeStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateFolderThreadSnippet", ["LSArrayGetObjectAt", "LSGetThreadParticipantDisplayName", "LSGetViewerFBID"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]).next().then(function(e, f) {
                var g = e.done;
                e = e.value;
                return g ? 0 : (f = e.item, c.sequence([function(e) {
                    return c.i64.eq(a[0], c.i64.cast([-1, 4294967284])) && !1 ? c.sequence([function(e) {
                        return c.i64.eq(a[0], c.i64.cast([-1, 4294967284])) && !1 ? c.sequence([function(e) {
                            return c.i64.neq(a[1], void 0) ? c.resolve(d[3] = a[1]) : c.sequence([function(b) {
                                return d[4] = c.createArray(), c.forEach(c.islc(c.db.table(9).fetchDesc([
                                    [
                                        [a[0]]
                                    ], "parentThreadKeyLastActivityTimestampMs"
                                ]), 0, c.i64.to_float(c.i64.cast([0, 20]))), function(a) {
                                    a = a.item;
                                    return d[7] = (d[4].push(a.threadKey), d[4])
                                })
                            }, function(a) {
                                return c.sequence([function(a) {
                                    return d[7] = c.createArray(), d[8] = c.i64.of_int32(d[4].length), c.i64.gt(d[8], c.i64.cast([0, 0])) ? c.loopAsync(d[8], function(a) {
                                        return d[10] = a, c.sequence([function(a) {
                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[4], d[10]).then(function(a) {
                                                return a = a, d[11] = a[0], d[12] = a[1], a
                                            })
                                        }, function(a) {
                                            return d[13] = (d[7].push(c.i64.to_string(d[11])), d[7])
                                        }])
                                    }) : c.resolve()
                                }, function(a) {
                                    return d[9] = d[7].join(","), d[5] = d[9]
                                }])
                            }, function(a) {
                                return c.count(c.filter(c.db.table(9).fetch(), function(a) {
                                    return d[4].some(function(b) {
                                        return c.i64.eq(a.threadKey, b)
                                    }) && c.i64.lt(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs) && !0 && !0
                                })).then(function(a) {
                                    return d[6] = a
                                })
                            }, function(a) {
                                return d[3] = d[6]
                            }])
                        }, function(a) {
                            return d[1] = d[3]
                        }]) : c.sequence([function(b) {
                            return c.i64.neq(a[1], void 0) ? c.resolve(d[3] = a[1]) : c.sequence([function(b) {
                                return c.count(c.filter(c.db.table(9).fetch([
                                    [
                                        [a[0]]
                                    ], "parentThreadKeyLastActivityTimestampMs"
                                ]), function(b) {
                                    return c.i64.eq(b.parentThreadKey, a[0]) && c.i64.lt(b.lastReadWatermarkTimestampMs, b.lastActivityTimestampMs) && (c.i64.eq(b.authorityLevel, c.i64.cast([0, 80])) || c.i64.eq(b.authorityLevel, c.i64.cast([0, 60])) && c.i64.eq(b.syncSource, c.i64.cast([0, 2])))
                                })).then(function(a) {
                                    return d[4] = a
                                })
                            }, function(a) {
                                return d[3] = d[4]
                            }])
                        }, function(a) {
                            return d[1] = d[3]
                        }])
                    }, function(e) {
                        return c.i64.eq(d[1], c.i64.cast([0, 0])) ? c.sequence([function(b) {
                            return d[3] = c.createArray(), c.forEach(c.islc(c.db.table(9).fetchDesc([
                                [
                                    [a[0]]
                                ], "parentThreadKeyLastActivityTimestampMs"
                            ]), 0, c.i64.to_float(c.i64.cast([0, 20]))), function(a) {
                                a = a.item;
                                return d[8] = (d[3].push(a.threadKey), d[3])
                            })
                        }, function(a) {
                            return c.sequence([function(a) {
                                return d[8] = c.createArray(), d[9] = c.i64.of_int32(d[3].length), c.i64.gt(d[9], c.i64.cast([0, 0])) ? c.loopAsync(d[9], function(a) {
                                    return d[11] = a, c.sequence([function(a) {
                                        return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[3], d[11]).then(function(a) {
                                            return a = a, d[12] = a[0], d[13] = a[1], a
                                        })
                                    }, function(a) {
                                        return d[14] = (d[8].push(c.i64.to_string(d[12])), d[8])
                                    }])
                                }) : c.resolve()
                            }, function(a) {
                                return d[10] = d[8].join(","), d[4] = d[10]
                            }])
                        }, function(a) {
                            return c.storedProcedure(b("LSGetViewerFBID")).then(function(a) {
                                return a = a, d[5] = a[0], a
                            })
                        }, function(a) {
                            return c.count(c.filter(c.db.table(9).fetch(), function(a) {
                                return d[3].some(function(b) {
                                    return c.i64.eq(a.threadKey, b)
                                }) && c.i64.eq(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs) && c.i64.neq(a.snippetSenderContactId, d[5]) && a.isAdminSnippet === !1
                            })).then(function(a) {
                                return d[6] = a
                            })
                        }, function(e) {
                            return c.i64.eq(c.i64.cast([0, 0]), d[6]) ? c.resolve((d[8] = a[2].get("all_read"), a[2], d[7] = d[8])) : c.sequence([function(b) {
                                return d[8] = c.createArray(), c.forEach(c.islc(c.db.table(9).fetchDesc([
                                    [
                                        [a[0]]
                                    ], "parentThreadKeyLastActivityTimestampMs"
                                ]), 0, c.i64.to_float(c.i64.cast([0, 20]))), function(a) {
                                    a = a.item;
                                    return d[19] = (d[8].push(a.threadKey), d[8])
                                })
                            }, function(a) {
                                return c.sequence([function(a) {
                                    return d[19] = c.createArray(), d[20] = c.i64.of_int32(d[8].length), c.i64.gt(d[20], c.i64.cast([0, 0])) ? c.loopAsync(d[20], function(a) {
                                        return d[22] = a, c.sequence([function(a) {
                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[8], d[22]).then(function(a) {
                                                return a = a, d[23] = a[0], d[24] = a[1], a
                                            })
                                        }, function(a) {
                                            return d[25] = (d[19].push(c.i64.to_string(d[23])), d[19])
                                        }])
                                    }) : c.resolve()
                                }, function(a) {
                                    return d[21] = d[19].join(","), d[9] = d[21]
                                }])
                            }, function(a) {
                                return c.storedProcedure(b("LSGetViewerFBID")).then(function(a) {
                                    return a = a, d[10] = a[0], a
                                })
                            }, function(a) {
                                return c.islc(c.filter(c.db.table(9).fetchDesc([
                                    [
                                        []
                                    ], "lastActivityTimestampMs"
                                ]), function(a) {
                                    return d[8].some(function(b) {
                                        return c.i64.eq(a.threadKey, b)
                                    }) && c.i64.eq(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs) && c.i64.neq(a.snippetSenderContactId, d[10]) && a.isAdminSnippet === !1
                                }), 0, c.i64.to_float(c.i64.cast([0, 1]))).next().then(function(b, e) {
                                    var a = b.done;
                                    b = b.value;
                                    return a ? (a = ["", c.i64.cast([-1, 4294967295])], d[11] = a[0], d[12] = a[1], a) : (e = b.item, a = [e.snippet, e.threadKey], d[11] = a[0], d[12] = a[1], a)
                                })
                            }, function(a) {
                                return c.storedProcedure(b("LSGetViewerFBID")).then(function(a) {
                                    return a = a, d[14] = a[0], a
                                })
                            }, function(a) {
                                return c.islc(c.db.table(14).fetch([
                                    [
                                        [d[12], {
                                            gt: d[14]
                                        }],
                                        [d[12], {
                                            lt: d[14]
                                        }]
                                    ]
                                ]), 0, c.i64.to_float(c.i64.cast([0, 1]))).next().then(function(b, e) {
                                    var a = b.done;
                                    b = b.value;
                                    return a ? d[15] = c.i64.cast([-1, 4294967295]) : (e = b.item, d[15] = e.contactId)
                                })
                            }, function(a) {
                                return c.storedProcedure(b("LSGetThreadParticipantDisplayName"), d[12], d[15]).then(function(a) {
                                    return a = a, d[17] = a[0], a
                                })
                            }, function(a) {
                                return c.i64.eq(d[6], c.i64.cast([0, 1])) ? c.sequence([function(a) {
                                    return d[19] = c.createArray(), d[21] = (d[19].push(d[17]), d[19]), c.localizeV2Async(c.i64.cast([0, 1907280305]), d[19]).then(function(a) {
                                        return d[20] = a
                                    })
                                }, function(a) {
                                    return d[18] = d[20]
                                }]) : c.sequence([function(a) {
                                    return d[19] = c.createArray(), d[21] = (d[19].push(d[17]), d[19]), c.localizeV2Async(c.i64.cast([0, 1112375422]), d[19]).then(function(a) {
                                        return d[20] = a
                                    })
                                }, function(a) {
                                    return d[18] = d[20]
                                }])
                            }, function(a) {
                                return d[7] = d[18]
                            }])
                        }, function(a) {
                            return d[2] = d[7]
                        }]) : c.sequence([function(e) {
                            return c.i64.eq(d[1], c.i64.cast([0, 1])) ? c.sequence([function(b) {
                                return d[4] = c.createArray(), c.forEach(c.islc(c.db.table(9).fetchDesc([
                                    [
                                        [a[0]]
                                    ], "parentThreadKeyLastActivityTimestampMs"
                                ]), 0, c.i64.to_float(c.i64.cast([0, 20]))), function(a) {
                                    a = a.item;
                                    return d[10] = (d[4].push(a.threadKey), d[4])
                                })
                            }, function(a) {
                                return c.sequence([function(a) {
                                    return d[10] = c.createArray(), d[11] = c.i64.of_int32(d[4].length), c.i64.gt(d[11], c.i64.cast([0, 0])) ? c.loopAsync(d[11], function(a) {
                                        return d[13] = a, c.sequence([function(a) {
                                            return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[4], d[13]).then(function(a) {
                                                return a = a, d[14] = a[0], d[15] = a[1], a
                                            })
                                        }, function(a) {
                                            return d[16] = (d[10].push(c.i64.to_string(d[14])), d[10])
                                        }])
                                    }) : c.resolve()
                                }, function(a) {
                                    return d[12] = d[10].join(","), d[5] = d[12]
                                }])
                            }, function(a) {
                                return c.islc(c.filter(c.db.table(9).fetchDesc([
                                    [
                                        []
                                    ], "lastActivityTimestampMs"
                                ]), function(a) {
                                    return d[4].some(function(b) {
                                        return c.i64.eq(a.threadKey, b)
                                    }) && c.i64.lt(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs) && !0 && a.isAdminSnippet === !1
                                }), 0, c.i64.to_float(c.i64.cast([0, 1]))).next().then(function(b, e) {
                                    var a = b.done;
                                    b = b.value;
                                    return a ? (a = ["", c.i64.cast([-1, 4294967295])], d[6] = a[0], d[7] = a[1], a) : (e = b.item, a = [e.snippet, e.threadKey], d[6] = a[0], d[7] = a[1], a)
                                })
                            }, function(b) {
                                return d[6] !== void 0 ? d[9] = d[6] : (d[10] = a[2].get("unread_singular"), a[2], d[9] = [c.i64.to_string(d[1]), d[10]].join("")), d[3] = d[9]
                            }]) : c.sequence([function(a) {
                                return d[4] = c.createArray(), d[6] = (d[4].push(c.i64.to_string(d[1])), d[4]), c.localizeV2Async(c.i64.cast([0, 3575257287]), d[4]).then(function(a) {
                                    return d[5] = a
                                })
                            }, function(a) {
                                return d[3] = d[5]
                            }])
                        }, function(a) {
                            return d[2] = d[3]
                        }])
                    }, function(a) {
                        return d[0] = d[2]
                    }]) : c.sequence([function(e) {
                        return c.i64.eq(f.threadType, c.i64.cast([0, 17])) ? c.sequence([function(e) {
                            return c.i64.eq(a[0], c.i64.cast([-1, 4294967284])) && !1 ? c.sequence([function(e) {
                                return c.i64.neq(a[1], void 0) ? c.resolve(d[4] = a[1]) : c.sequence([function(b) {
                                    return d[5] = c.createArray(), c.forEach(c.islc(c.db.table(9).fetchDesc([
                                        [
                                            [a[0]]
                                        ], "parentThreadKeyLastActivityTimestampMs"
                                    ]), 0, c.i64.to_float(c.i64.cast([0, 20]))), function(a) {
                                        a = a.item;
                                        return d[8] = (d[5].push(a.threadKey), d[5])
                                    })
                                }, function(a) {
                                    return c.sequence([function(a) {
                                        return d[8] = c.createArray(), d[9] = c.i64.of_int32(d[5].length), c.i64.gt(d[9], c.i64.cast([0, 0])) ? c.loopAsync(d[9], function(a) {
                                            return d[11] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[5], d[11]).then(function(a) {
                                                    return a = a, d[12] = a[0], d[13] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[14] = (d[8].push(c.i64.to_string(d[12])), d[8])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return d[10] = d[8].join(","), d[6] = d[10]
                                    }])
                                }, function(a) {
                                    return c.count(c.filter(c.db.table(9).fetch(), function(a) {
                                        return d[5].some(function(b) {
                                            return c.i64.eq(a.threadKey, b)
                                        }) && c.i64.lt(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs) && !0 && !0
                                    })).then(function(a) {
                                        return d[7] = a
                                    })
                                }, function(a) {
                                    return d[4] = d[7]
                                }])
                            }, function(a) {
                                return d[2] = d[4]
                            }]) : c.sequence([function(b) {
                                return c.i64.neq(a[1], void 0) ? c.resolve(d[4] = a[1]) : c.sequence([function(b) {
                                    return c.count(c.filter(c.db.table(9).fetch([
                                        [
                                            [a[0]]
                                        ], "parentThreadKeyLastActivityTimestampMs"
                                    ]), function(b) {
                                        return c.i64.eq(b.parentThreadKey, a[0]) && c.i64.lt(b.lastReadWatermarkTimestampMs, b.lastActivityTimestampMs) && (c.i64.eq(b.authorityLevel, c.i64.cast([0, 80])) || c.i64.eq(b.authorityLevel, c.i64.cast([0, 60])) && c.i64.eq(b.syncSource, c.i64.cast([0, 2])))
                                    })).then(function(a) {
                                        return d[5] = a
                                    })
                                }, function(a) {
                                    return d[4] = d[5]
                                }])
                            }, function(a) {
                                return d[2] = d[4]
                            }])
                        }, function(a) {
                            return c.i64.eq(d[2], c.i64.cast([0, 0])) ? c.sequence([function(a) {
                                return c.sequence([function(a) {
                                    return c.localizeV2Async(c.i64.cast([0, 2213485461]), void 0).then(function(a) {
                                        return d[5] = a
                                    })
                                }, function(a) {
                                    return d[4] = d[5]
                                }])
                            }, function(a) {
                                return d[3] = d[4]
                            }]) : c.sequence([function(a) {
                                return c.i64.eq(d[2], c.i64.cast([0, 1])) ? c.sequence([function(a) {
                                    return c.localizeV2Async(c.i64.cast([0, 3802288555]), void 0).then(function(a) {
                                        return d[5] = a
                                    })
                                }, function(a) {
                                    return d[4] = d[5]
                                }]) : c.sequence([function(a) {
                                    return d[5] = c.createArray(), d[7] = (d[5].push(c.i64.to_string(d[2])), d[5]), c.localizeV2Async(c.i64.cast([0, 1420387436]), d[5]).then(function(a) {
                                        return d[6] = a
                                    })
                                }, function(a) {
                                    return d[4] = d[6]
                                }])
                            }, function(a) {
                                return d[3] = d[4]
                            }])
                        }, function(a) {
                            return d[1] = d[3]
                        }]) : c.sequence([function(e) {
                            return c.i64.eq(a[0], c.i64.cast([-1, 4294967284])) && !1 ? c.sequence([function(e) {
                                return c.i64.neq(a[1], void 0) ? c.resolve(d[7] = a[1]) : c.sequence([function(b) {
                                    return d[8] = c.createArray(), c.forEach(c.islc(c.db.table(9).fetchDesc([
                                        [
                                            [a[0]]
                                        ], "parentThreadKeyLastActivityTimestampMs"
                                    ]), 0, c.i64.to_float(c.i64.cast([0, 20]))), function(a) {
                                        a = a.item;
                                        return d[11] = (d[8].push(a.threadKey), d[8])
                                    })
                                }, function(a) {
                                    return c.sequence([function(a) {
                                        return d[11] = c.createArray(), d[12] = c.i64.of_int32(d[8].length), c.i64.gt(d[12], c.i64.cast([0, 0])) ? c.loopAsync(d[12], function(a) {
                                            return d[14] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[8], d[14]).then(function(a) {
                                                    return a = a, d[15] = a[0], d[16] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[17] = (d[11].push(c.i64.to_string(d[15])), d[11])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return d[13] = d[11].join(","), d[9] = d[13]
                                    }])
                                }, function(a) {
                                    return c.count(c.filter(c.db.table(9).fetch(), function(a) {
                                        return d[8].some(function(b) {
                                            return c.i64.eq(a.threadKey, b)
                                        }) && c.i64.lt(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs) && !0 && !0
                                    })).then(function(a) {
                                        return d[10] = a
                                    })
                                }, function(a) {
                                    return d[7] = d[10]
                                }])
                            }, function(a) {
                                return d[2] = d[7]
                            }]) : c.sequence([function(b) {
                                return c.i64.neq(a[1], void 0) ? c.resolve(d[7] = a[1]) : c.sequence([function(b) {
                                    return c.count(c.filter(c.db.table(9).fetch([
                                        [
                                            [a[0]]
                                        ], "parentThreadKeyLastActivityTimestampMs"
                                    ]), function(b) {
                                        return c.i64.eq(b.parentThreadKey, a[0]) && c.i64.lt(b.lastReadWatermarkTimestampMs, b.lastActivityTimestampMs) && (c.i64.eq(b.authorityLevel, c.i64.cast([0, 80])) || c.i64.eq(b.authorityLevel, c.i64.cast([0, 60])) && c.i64.eq(b.syncSource, c.i64.cast([0, 2])))
                                    })).then(function(a) {
                                        return d[8] = a
                                    })
                                }, function(a) {
                                    return d[7] = d[8]
                                }])
                            }, function(a) {
                                return d[2] = d[7]
                            }])
                        }, function(b) {
                            return d[3] = a[2].get("all_read"), a[2], d[4] = a[2].get("unread_singular"), a[2], d[5] = a[2].get("unread_plural"), a[2], c.i64.eq(d[2], c.i64.cast([0, 0])) ? d[6] = d[3] : (c.i64.eq(d[2], c.i64.cast([0, 1])) ? d[7] = [c.i64.to_string(d[2]), d[4]].join("") : d[7] = [c.i64.to_string(d[2]), d[5]].join(""), d[6] = d[7]), d[1] = d[6]
                        }])
                    }, function(a) {
                        return d[0] = d[1]
                    }])
                }, function(a) {
                    return c.forEach(c.db.table(9).fetch([
                        [
                            [f.threadKey]
                        ]
                    ]), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            snippet: d[0],
                            snippetStringHash: void 0,
                            snippetStringArgument1: void 0,
                            snippetAttribution: void 0,
                            snippetAttributionStringHash: void 0
                        })
                    })
                }]))
            })
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateFolderThreadSnippetStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateParentFolderReadWatermark", ["LSArrayGetObjectAt", "LSGetParentThreadKey", "LSUpdateFolderThreadSnippet"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return c.storedProcedure(b("LSGetParentThreadKey"), a[0]).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(e) {
                return c.i64.neq(d[0], c.i64.cast([0, 0])) ? c.sequence([function(a) {
                    return c.i64.eq(d[0], c.i64.cast([-1, 4294967284])) && !1 ? c.sequence([function(a) {
                        return d[2] = c.createArray(), c.forEach(c.islc(c.db.table(9).fetchDesc([
                            [
                                [d[0]]
                            ], "parentThreadKeyLastActivityTimestampMs"
                        ]), 0, c.i64.to_float(c.i64.cast([0, 20]))), function(a) {
                            a = a.item;
                            return d[6] = (d[2].push(a.threadKey), d[2])
                        })
                    }, function(a) {
                        return c.sequence([function(a) {
                            return d[6] = c.createArray(), d[7] = c.i64.of_int32(d[2].length), c.i64.gt(d[7], c.i64.cast([0, 0])) ? c.loopAsync(d[7], function(a) {
                                return d[9] = a, c.sequence([function(a) {
                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[2], d[9]).then(function(a) {
                                        return a = a, d[10] = a[0], d[11] = a[1], a
                                    })
                                }, function(a) {
                                    return d[12] = (d[6].push(c.i64.to_string(d[10])), d[6])
                                }])
                            }) : c.resolve()
                        }, function(a) {
                            return d[8] = d[6].join(","), d[3] = d[8]
                        }])
                    }, function(a) {
                        return c.sortBy(c.filter(c.db.table(9).fetch(), function(a) {
                            return d[2].some(function(b) {
                                return c.i64.eq(a.threadKey, b)
                            }) && c.i64.lt(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs)
                        }), [
                            ["lastReadWatermarkTimestampMs", "ASC"]
                        ]).next().then(function(a, b) {
                            var c = a.done;
                            a = a.value;
                            return c ? d[4] = void 0 : (b = a.item, d[4] = b.lastReadWatermarkTimestampMs)
                        })
                    }, function(a) {
                        return d[1] = d[4]
                    }]) : c.sequence([function(a) {
                        return c.sortBy(c.filter(c.db.table(9).fetch([
                            [
                                [d[0]]
                            ], "parentThreadKeyLastActivityTimestampMs"
                        ]), function(a) {
                            return c.i64.eq(a.parentThreadKey, d[0]) && c.i64.lt(a.lastReadWatermarkTimestampMs, a.lastActivityTimestampMs)
                        }), [
                            ["lastReadWatermarkTimestampMs", "ASC"]
                        ]).next().then(function(a, b) {
                            var c = a.done;
                            a = a.value;
                            return c ? d[2] = void 0 : (b = a.item, d[2] = b.lastReadWatermarkTimestampMs)
                        })
                    }, function(a) {
                        return d[1] = d[2]
                    }])
                }, function(a) {
                    return c.i64.neq(d[1], void 0) ? c.forEach(c.db.table(9).fetch([
                        [
                            [d[0]]
                        ]
                    ]), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            lastReadWatermarkTimestampMs: d[1]
                        })
                    }) : c.sequence([function(a) {
                        return c.db.table(9).fetch([
                            [
                                [d[0]]
                            ]
                        ]).next().then(function(a, b) {
                            var c = a.done;
                            a = a.value;
                            return c ? d[2] = void 0 : (b = a.item, d[2] = b.lastActivityTimestampMs)
                        })
                    }, function(a) {
                        return c.i64.neq(d[2], void 0) ? c.forEach(c.db.table(9).fetch([
                            [
                                [d[0]]
                            ]
                        ]), function(a) {
                            var b = a.update;
                            a.item;
                            return b({
                                lastReadWatermarkTimestampMs: d[2]
                            })
                        }) : c.resolve()
                    }])
                }, function(e) {
                    return c.storedProcedure(b("LSUpdateFolderThreadSnippet"), d[0], void 0, a[1])
                }]) : c.resolve()
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSMailboxUpdateParentFolderReadWatermarkStoredProcedure";
    e.exports = a
}), null);
//# sourceURL=https://static.xx.fbcdn.net/rsrc.php/v3/yV/r/DXvgPqiOdb9.js