; /*FB_PKG_DELIM*/

__d("LSCreateOpenToE2EEThreadLink", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(193).put({
                openThreadId: a[0],
                armadilloThreadId: a[1],
                showOpenMessageHistory: a[2],
                timestampMs: a[3]
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxCreateOpenToE2EEThreadLinkStoredProcedure";
    e.exports = a
}), null);
__d("LSHandleMessageWithProtobufsRestore", ["LSArrayGetObjectAt", "LSDecryptMessageProtobufs", "LSIsEncryptionVersionSecure", "LSLoadThreadPkFromThreadId", "LSLogMebClientEvent.nop", "LSLogWebQpl.nop", "LSRestoreProtobufs.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return d[0] = c.i64.of_float(Date.now()),
                    function(a) {
                        c.logger(a).info(a)
                    }("[EncryptedBackups][handleMessageWithProtobufsRestore] Beginning execution."), d[1] = c.i64.of_float(Date.now()), c.storedProcedure(b("LSDecryptMessageProtobufs"), a[0], a[2]).then(function(a) {
                        return a = a, d[2] = a[0], d[3] = a[1], a
                    })
            }, function(e) {
                return d[4] = a[5].get("request_id"), a[5], d[5] = a[5].get("restore_task_source"), a[5], d[6] = c.i64.of_int32(a[0].length), d[4] !== void 0 ? c.nativeOperation(b("LSLogWebQpl.nop"), d[4], c.i64.cast([0, 521476165]), "call_from_client", d[6], void 0, void 0) : c.resolve()
            }, function(b) {
                return c.i64.neq(a[7], void 0) ? c.sequence([function(b) {
                    return c.filter(c.db.table(168).fetch(), function(a) {
                        return c.i64.eq(a.authorityLevel, c.i64.cast([0, 80]))
                    }).next().then(function(b, e) {
                        var f = b.done;
                        b = b.value;
                        return f ? d[14] = !1 : (e = b.item, d[17] = e.deviceId, c.i64.neq(d[17], void 0) ? d[16] = c.i64.neq(d[17], a[7]) : d[16] = !1, d[14] = d[16])
                    })
                }, function(a) {
                    return d[7] = d[14]
                }]) : c.resolve(d[7] = !1)
            }, function(e) {
                return d[7] ? (d[14] = new c.Map(), d[14].set("error_code", c.i64.cast([0, 110])), d[14].set("stored_procedure", "LSEncryptedBackupsHandleMessageWithProtobufsRestoreStoredProcedure"), d[14].set("error_message", ""), c.resolve()) : c.sequence([function(e) {
                    return d[2] !== void 0 ? c.sequence([function(e) {
                        return c.storedProcedure(b("LSLoadThreadPkFromThreadId"), a[2]).then(function(a) {
                            return a = a, d[15] = a[0], d[16] = a[1], a
                        })
                    }, function(e) {
                        return c.i64.neq(d[15], void 0) ? c.sequence([function(e) {
                            return void 0 !== void 0 ? c.resolve(d[18] = void 0) : c.sequence([function(e) {
                                return d[19] = a[1].get("has_more_before"), a[1], d[20] = a[1].get("has_more_after"), a[1], d[19] ? (d[28] = a[1].get("next_message_timestamp_ms_before"), a[1], d[21] = d[28]) : d[21] = void 0, d[20] ? (d[28] = a[1].get("next_message_timestamp_ms_after"), a[1], d[22] = d[28]) : d[22] = void 0, d[23] = a[1].get("has_more_before"), a[1], d[24] = a[1].get("has_more_after"), a[1], d[25] = a[5].get("request_id"), a[5], d[26] = a[5].get("reference_timestamp"), a[5], d[27] = c.createArray(), c.nativeOperation(b("LSRestoreProtobufs.nop"), a[2], d[2], d[23], d[21], d[24], d[22], a[4], d[25], d[26], a[6], d[27], d[5])
                            }, function(a) {
                                return d[18] = void 0
                            }])
                        }, function(a) {
                            return d[17] = d[18]
                        }]) : c.resolve(d[17] = d[16])
                    }, function(a) {
                        return d[14] = d[17]
                    }]) : c.resolve((d[3] !== void 0 ? (d[15] = d[3].get("error_code"), d[3], c.i64.eq(d[15], c.i64.cast([0, 1])) ? 0 : 0) : 0, d[14] = d[3]))
                }, function(e) {
                    return d[14] !== void 0 ? c.sequence([function(a) {
                        return c.resolve()
                    }, function(e) {
                        return a[6] !== void 0 ? c.sequence([function(e) {
                            return d[15] = a[5].get("request_id"), a[5], c.islc(c.filter(c.db.table(168).fetch(), function(a) {
                                return c.i64.eq(a.authorityLevel, c.i64.cast([0, 80])) || !1
                            }), 0, c.i64.to_float(c.i64.cast([0, 1]))).next().then(function(a, e) {
                                var f = a.done;
                                a = a.value;
                                return f ? d[16] = void 0 : (e = a.item, c.sequence([function(a) {
                                    return d[26] = e.deviceId, d[25] = e.backupTenancy, d[24] = e.encryptionVersion, d[19] = void 0, c.i64.neq(d[19], void 0) ? c.resolve(d[20] = d[19]) : c.sequence([function(a) {
                                        return d[27] = c.createArray(), c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 0])).then(function(a) {
                                            return a = a, d[28] = a[0], a
                                        })
                                    }, function(a) {
                                        return d[28] ? d[37] = (d[27].push(c.i64.cast([0, 0])), d[27]) : 0, c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 2])).then(function(a) {
                                            return a = a, d[29] = a[0], a
                                        })
                                    }, function(a) {
                                        return d[29] ? d[37] = (d[27].push(c.i64.cast([0, 2])), d[27]) : 0, c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 3])).then(function(a) {
                                            return a = a, d[30] = a[0], a
                                        })
                                    }, function(a) {
                                        return d[30] ? d[37] = (d[27].push(c.i64.cast([0, 3])), d[27]) : 0, c.storedProcedure(b("LSIsEncryptionVersionSecure"), c.i64.cast([0, 4])).then(function(a) {
                                            return a = a, d[31] = a[0], a
                                        })
                                    }, function(a) {
                                        return d[31] ? d[37] = (d[27].push(c.i64.cast([0, 4])), d[27]) : 0, d[32] = c.createArray(), d[33] = c.i64.of_int32(d[27].length), c.i64.gt(d[33], c.i64.cast([0, 0])) ? c.loopAsync(d[33], function(a) {
                                            return d[37] = a, c.sequence([function(a) {
                                                return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[27], d[37]).then(function(a) {
                                                    return a = a, d[38] = a[0], d[39] = a[1], a
                                                })
                                            }, function(a) {
                                                return d[40] = (d[32].push(d[38]), d[32])
                                            }])
                                        }) : c.resolve()
                                    }, function(a) {
                                        return c.sequence([function(a) {
                                            return d[37] = c.createArray(), d[38] = c.i64.of_int32(d[32].length), c.i64.gt(d[38], c.i64.cast([0, 0])) ? c.loopAsync(d[38], function(a) {
                                                return d[40] = a, c.sequence([function(a) {
                                                    return c.nativeTypeOperation("Array", b("LSArrayGetObjectAt"), d[32], d[40]).then(function(a) {
                                                        return a = a, d[41] = a[0], d[42] = a[1], a
                                                    })
                                                }, function(a) {
                                                    return d[43] = (d[37].push(c.i64.to_string(d[41])), d[37])
                                                }])
                                            }) : c.resolve()
                                        }, function(a) {
                                            return d[39] = d[37].join(","), d[34] = d[39]
                                        }])
                                    }, function(a) {
                                        return d[32].some(function(a) {
                                            return c.i64.eq(d[24], a)
                                        }) ? d[35] = d[24] : d[35] = void 0, c.i64.neq(d[35], void 0) ? d[36] = d[35] : d[36] = void 0, d[20] = d[36]
                                    }])
                                }, function(a) {
                                    return c.i64.neq(d[20], void 0) ? d[21] = d[20] : d[21] = c.i64.cast([0, 0]), c.i64.neq(d[25], void 0) ? d[22] = d[25] : d[22] = c.i64.cast([0, 1]), c.i64.neq(d[26], void 0) ? d[23] = d[26] : d[23] = void 0, d[16] = d[23]
                                }]))
                            })
                        }, function(b) {
                            return d[18] = a[5].get("restore_task_source")
                        }, a[5]]) : c.resolve()
                    }]) : c.resolve(0)
                }])
            }, function(a) {
                return d[8] = c.i64.of_float(Date.now()), d[9] = c.i64.random(), d[11] = "Finishing execution. Execution time: ", d[12] = c.i64.to_string(c.i64.sub(d[8], d[0])), d[13] = " ms", d[10] = "",
                    function(a) {
                        c.logger(a).info(a)
                    }(["[EncryptedBackups][handleMessageWithProtobufsRestore] ", d[10], d[11], d[10], d[12], d[10], d[13]].join("")), c.i64.eq(c.i64.mod_(d[9], c.i64.cast([0, 1e3])), c.i64.cast([0, 0])) ? (d[14] = ",", d[15] = c.createArray(), void 0 !== void 0 ? d[16] = (d[15].push(void 0), d[15]) : 0, c.nativeOperation(b("LSLogMebClientEvent.nop"), "handleMessageWithProtobufsRestore", [d[11], d[14], d[12], d[14], d[13]].join(""), d[15], c.i64.cast([0, 4]))) : c.resolve()
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSEncryptedBackupsHandleMessageWithProtobufsRestoreStoredProcedure";
    e.exports = a
}), null);
__d("LSShimHybridThreadDeleteUtil", ["Promise", "ReQL"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, b) {
        return d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.mi_act_mapping_table).getKeyRange(b)).then(function(a) {
            return a
        })
    }

    function c(a, c) {
        if (c != null) return (h || (h = b("Promise"))).all([a.threads["delete"](c.serverThreadKey), a.mi_act_mapping_table["delete"](c.serverThreadKey, c.clientThreadPk, c.jid)]).then(function() {});
        else return (h || (h = b("Promise"))).resolve()
    }
    g.getMiActMappingRow = a;
    g.deleteE2EEMetadataTable = c
}), 98);
__d("LSShimHybridThreadDeleteByThreadKey.nop", ["LSShimHybridThreadDeleteUtil", "asyncToGeneratorRuntime", "gkx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e) {
            if (c("qex")._("1016") !== !0 && !c("gkx")("4991")) {
                b = (yield d("LSShimHybridThreadDeleteUtil").getMiActMappingRow(a, e));
                return d("LSShimHybridThreadDeleteUtil").deleteE2EEMetadataTable(a, b)
            }
        });

        function e(b, c, d) {
            return a.apply(this, arguments)
        }
        return e
    }();
    g["default"] = a
}), 98);
__d("LSHybridThreadDelete", ["LSShimHybridThreadDeleteByThreadKey.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.nativeOperation(b("LSShimHybridThreadDeleteByThreadKey.nop"), a[0])
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxHybridThreadDeleteStoredProcedure";
    e.exports = a
}), null);
__d("LSMoveThreadToE2EECutoverFolder", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(9).fetch([
                [
                    [a[0]]
                ]
            ]).next().then(function(c, d) {
                d = c.done;
                c = c.value;
                return d ? 0 : (c.item, b.forEach(b.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(a) {
                    var c = a.update;
                    a.item;
                    return c({
                        folderName: "e2ee_cutover",
                        parentThreadKey: b.i64.cast([-1, 4294967279])
                    })
                }))
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxMoveThreadToE2EECutoverFolderStoredProcedure";
    e.exports = a
}), null);
__d("LSReplaceOptimisticThread", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.db.table(9).fetch([
                [
                    [a[1]]
                ]
            ]).next().then(function(c, d) {
                d = c.done;
                c = c.value;
                return d ? b.forEach(b.filter(b.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(c) {
                    return b.i64.eq(c.threadKey, a[0]) && b.i64.le(c.authorityLevel, b.i64.cast([0, 20]))
                }), function(c) {
                    var d = c.update;
                    c.item;
                    return d({
                        threadKey: a[1],
                        authorityLevel: b.i64.cast([0, 40])
                    })
                }) : (c.item, b.forEach(b.db.table(9).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(a) {
                    return a["delete"]()
                }))
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSMailboxReplaceOptimisticThreadStoredProcedure";
    e.exports = a
}), null);
__d("LSSetOrUnsetPinnedMessage", ["LSShimThreadPinMessage.nop", "LSShimThreadUnpinMessage.nop"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [];
        return c.sequence([function(d) {
            return c.i64.eq(a[2], c.i64.cast([0, 1])) || c.i64.eq(a[2], c.i64.cast([0, 2])) ? c.nativeOperation(b("LSShimThreadPinMessage.nop"), a[0], a[1], a[3]) : c.nativeOperation(b("LSShimThreadUnpinMessage.nop"), a[0], a[3])
        }, function(a) {
            return c.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxSetOrUnsetPinnedMessageStoredProcedure";
    e.exports = a
}), null);
__d("LSShimCopyAllParticipantNicknamesForThread", ["gkx"], (function(a, b, c, d, e, f, g) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            d = [];
        return c("gkx")("26379") === !1 ? 0 : 0, b.resolve(d)
    }
    a.__sproc_name__ = "LSMailboxShimCopyAllParticipantNicknamesForThreadStoredProcedure";
    b = a;
    g["default"] = b
}), 98);
__d("LSShimGetServerThreadKeyFromJIDV2.nop", ["ReQL", "RetUtil", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, c) {
            b = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.mi_act_mapping_table.index("jid")).getKeyRange(c)));
            return d("RetUtil").getNullableRetResult(b == null ? void 0 : b.serverThreadKey)
        });

        function c(b, c, d) {
            return a.apply(this, arguments)
        }
        return c
    }();
    g["default"] = a
}), 98);
__d("MAWMiActBulkCreateThreadInActWithMiData", ["ExecutionEnvironment", "I64", "MAWBridgeFireAndForget", "MAWBridgeSendAndReceive", "MAWJids", "MAWMIC", "MAWMICSchema", "MAWMiActCreateThreadInActWithMiData", "MAWTrackPendingOccamadilloThreads", "MAWWaitForBackendSetup", "Promise", "WABridgedAPI", "WAJids", "WALoggerDeferred", "asyncToGeneratorRuntime", "getErrorSafe", "gkx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j;

    function k() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[Occamadillo] Querying WA server for group: ", ""]);
        k = function() {
            return a
        };
        return a
    }

    function a(a) {
        return l.apply(this, arguments)
    }

    function l() {
        l = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
            try {
                var e = a.map(function(a) {
                    var b = a.fbid,
                        c = a.isGroupThread,
                        e = a.jid,
                        f = a.lastActivityTimestampMs;
                    a = a.lastReadWatermarkTimestampMs;
                    e = (j || (j = d("I64"))).to_string(e);
                    e = c ? d("WAJids").toGroupJid(e) : d("MAWJids").toUserJid(e);
                    return {
                        authoritativeThreadKey: j.to_string(b),
                        chatJid: e,
                        lastActivityTimestampMs: j.to_float(f),
                        lastReadWatermarkTimestampMs: j.to_float(a),
                        numOfMsgsToLoad: d("MAWMiActCreateThreadInActWithMiData").getNumberOfMessagesToLoad({
                            fbid: b,
                            isGroupThread: c
                        })
                    }
                });
                if ((i || (i = c("ExecutionEnvironment"))).isInWorker) {
                    a = e.map(function(a) {
                        return {
                            status: "fulfilled",
                            value: {
                                chatJid: a.chatJid,
                                isCreated: !1,
                                shouldQueryForGroup: !1
                            }
                        }
                    });
                    return (h || (h = b("Promise"))).resolve(a)
                }
                a = (yield d("MAWWaitForBackendSetup").waitForBackendSetup("bulk-occamadillo-mapping-await").then(function() {
                    d("MAWMIC").markEvent(d("MAWMICSchema").POINTS.backend_setup_ready);
                    return d("MAWBridgeSendAndReceive").sendAndReceive("backend", "bulkCreateThread", {
                        threads: e
                    })
                }));
                d("MAWMIC").markEvent("occamadillo_mapping_bridge_event_received");
                yield(h || (h = b("Promise"))).all(a.map(function() {
                    var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a) {
                        if (a.status === "rejected") throw a.reason;
                        var b = a.value.chatJid,
                            e = d("WAJids").interpretAsGroupJid(b) != null;
                        if (e) {
                            e = d("WAJids").toGroupJid(b);
                            if (a.value.isCreated || c("gkx")("23923") && a.value.shouldQueryForGroup) {
                                c("promiseDone")(d("WALoggerDeferred").DEV(k(), e));
                                try {
                                    yield c("WABridgedAPI").queryGroups({
                                        groups: [e],
                                        type: "array"
                                    })
                                } catch (b) {
                                    a = b instanceof Error && b.message.includes('"errorCode":403');
                                    if (!a) throw b
                                }
                                d("MAWBridgeFireAndForget").fireAndForget("backend", "checkIfGroupParticipant", {
                                    threadJid: b
                                })
                            } else d("MAWBridgeFireAndForget").fireAndForget("backend", "updateLSThreadFromGroupInfo", {
                                groupJid: e
                            })
                        }
                        c("promiseDone")(d("MAWTrackPendingOccamadilloThreads").removePendingThread(b))
                    });
                    return function(b) {
                        return a.apply(this, arguments)
                    }
                }()));
                return a
            } catch (a) {
                d("MAWMIC").fail("thread_mapping_error", c("getErrorSafe")(a));
                throw a
            }
        });
        return l.apply(this, arguments)
    }
    g.miActBulkCreateThreadInActWithMiData = a
}), 98);
__d("WABatcher", ["Promise", "WAResolvable", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a, d) {
        var e = a.delayMs,
            f = a.maxSize,
            g = null;

        function i(a) {
            g && g.args === a && (g = null);
            return d(a)
        }
        var j = function() {
            if (g == null) return (h || (h = b("Promise"))).resolve();
            var a = g;
            g = null;
            clearTimeout(a.timer);
            a.run();
            return a.batchPromise
        };
        a = function(a) {
            if (g) g.args.push(a);
            else {
                var d, k = [a];
                a = new(h || (h = b("Promise")))(function(a) {
                    d = function() {
                        return void a(k)
                    }
                }).then(i);
                var l = d;
                g = {
                    args: k,
                    batchPromise: a,
                    run: l,
                    timer: setTimeout(l, e)
                }
            }
            if (g == null) throw c("err")("activeBatch should not be null here");
            a = g;
            l = a.args;
            a = a.batchPromise;
            var m = l.length - 1;
            f != null && l.length >= f && void j();
            return a.then(function(a) {
                return a[m]
            })
        };
        return {
            accept: a,
            runActiveBatch: j
        }
    }

    function a(a, b) {
        var c = i(a, b);
        return function(a) {
            return c.accept(a)
        }
    }

    function e(a) {
        var e = [],
            f = new(d("WAResolvable").Resolvable)(),
            g = function(c) {
                if (e.length === 0) return (h || (h = b("Promise"))).resolve(new Map());
                var g = e,
                    i = f;
                e = [];
                f = new(d("WAResolvable").Resolvable)();
                return (h || (h = b("Promise"))).resolve(a(g, c)).then(function(a) {
                    i.resolve(a);
                    return a
                })
            },
            i = function(a) {
                e.push(a);
                return f.promise.then(function(b) {
                    b = b.get(a);
                    if (b == null) throw c("err")("This should not happen because we just added it to the batch");
                    return b
                })
            };
        return {
            accept: i,
            runActiveBatch: g
        }
    }
    g.createSimpleBatcher = i;
    g.batch = a;
    g.createBatcher = e
}), 98);
__d("LSShimVerifyThreadExists.nop", ["I64", "LSPlatformArmadilloUtils", "MAWMiActBulkCreateThreadInActWithMiData", "MAWMiActCreateThreadInActWithMiData", "MAWTrackPendingOccamadilloThreads", "MWCookieUtil", "Promise", "QE2Logger", "ReQL", "WABatcher", "WAJids", "WALoggerDeferred", "asyncToGeneratorRuntime", "cr:10180", "gkx", "promiseDone", "qex", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;

    function j() {
        var a = babelHelpers.taggedTemplateLiteralLoose(["[Occamadillo] MI thread insertion: fbid ", ", jid: ", ", last activity ts: ", ", last read ts: ", ", read = ", ""]);
        j = function() {
            return a
        };
        return a
    }

    function k(a, b, c) {
        return a.mi_act_mapping_table.put({
            clientThreadPk: (i || (i = d("I64"))).neg(b),
            jid: c,
            serverThreadKey: b
        })
    }
    a = 200;
    f = (e = c("qex")._("2160")) != null ? e : 15;

    function l() {
        d("QE2Logger").logExposureForActingAccount("messenger_web_occamadillo_thread_mapping")
    }
    var m = d("WABatcher").createSimpleBatcher({
        delayMs: a,
        maxSize: f
    }, function(a) {
        d("MAWTrackPendingOccamadilloThreads").markBulkBatchRun(a.length);
        c("promiseDone")(d("MAWMiActBulkCreateThreadInActWithMiData").miActBulkCreateThreadInActWithMiData(a));
        return []
    });
    d("LSPlatformArmadilloUtils").executeOnThreadMappingEnd(b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
        yield m.runActiveBatch()
    }));
    var n = 3e3;
    e = function() {
        var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*(a, b, e, f, g, h, l, m, n) {
            d("MAWTrackPendingOccamadilloThreads").markFirstThreadPassedToNativeOp();
            var q = d("MWCookieUtil").isAutoChatTabFromCookie(e);
            q && d("MAWTrackPendingOccamadilloThreads").markACTOPassedToNativeOp();
            b = (yield d("ReQL").firstAsync(d("ReQL").fromTableAscending(a.mi_act_mapping_table).getKeyRange(e)));
            b == null && (yield k(a, e, f));
            c("promiseDone")(d("WALoggerDeferred").LOG(j(), (i || (i = d("I64"))).to_string(e), i.to_string(f), i.to_string(m), i.to_string(n), i.le(m, n)));
            g = l ? d("WAJids").toGroupJid((i || (i = d("I64"))).to_string(f)) : d("WAJids").toMsgrUserJid((i || (i = d("I64"))).to_string(f));
            d("MAWTrackPendingOccamadilloThreads").addPendingThread(g);
            var r = {
                description: "LSShimVerifyThreadExists.nop",
                fbid: e,
                isGroupThread: l,
                jid: f,
                lastActivityTimestampMs: m,
                lastReadWatermarkTimestampMs: n
            };
            c("promiseDone")(o({
                isACTO: q,
                miActMappingData: r
            }), function() {}, function() {
                p({
                    isACTO: q,
                    miActMappingData: r
                })
            })
        });

        function e(b, c, d, e, f, g, h, i, j) {
            return a.apply(this, arguments)
        }
        return e
    }();

    function o(a) {
        var e = a.isACTO,
            f = a.miActMappingData;
        return new(h || (h = b("Promise")))(function(a, g) {
            if (!c("gkx")("5805")) return g("Gating disallows mapping in UI");
            if (b("cr:10180") == null) return g("Module dependency not present");
            if (!b("cr:10180").isThreadEligibleForMappingInUI(f)) return g("Thread ineligible for mapping in UI");
            d("MAWTrackPendingOccamadilloThreads").markFirstThreadCheckedInUiThread();
            e && d("MAWTrackPendingOccamadilloThreads").markACTOCheckedInUiThread();
            var i = b("cr:10180").MAWMiActVerifyThreadExistsInActWithMiDataInMainThread(f);
            return (h || (h = b("Promise"))).race([new h(function() {
                c("setTimeout")(function() {
                    return g("Timed out")
                }, n)
            }), i.then(function(b) {
                b ? a() : g("Mapping in UI did not finish")
            })["catch"](function() {
                return g(!1)
            })])
        })
    }

    function p(a) {
        var b = a.isACTO;
        a = a.miActMappingData;
        d("MAWTrackPendingOccamadilloThreads").markFirstThreadCheckedInWorker();
        b ? (d("MAWTrackPendingOccamadilloThreads").markACTOCheckedInWorker(), c("promiseDone")(d("MAWMiActCreateThreadInActWithMiData").miActCreateThreadInActWithMiData(a))) : (l(), c("promiseDone")(m.accept(a)))
    }
    g["default"] = e
}), 98);
__d("LSTransportHybridParticipantUpdateReceipts", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.resolve(c)
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxTransportHybridParticipantUpdateReceiptsStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateOccamadilloMostRecentMessagePerThread", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [],
            d = [];
        return b.sequence([function(d) {
            return b.db.table(292).fetch([
                [
                    [a[0]]
                ]
            ]).next().then(function(d, e) {
                var f = d.done;
                d = d.value;
                return f ? (c[1] = b.i64.of_float(Date.now()), b.db.table(292).add({
                    threadKey: a[0],
                    timestampMs: a[1],
                    fetchTimestampMs: c[1]
                })) : (e = d.item, c[2] = e.fetchTimestampMs, c[1] = b.i64.of_float(Date.now()), b.i64.neq(c[2], void 0) ? b.i64.ge(c[1], b.i64.add(c[2], b.i64.cast([0, 2592e6]))) ? b.db.table(292).put({
                    threadKey: a[0],
                    timestampMs: a[1],
                    fetchTimestampMs: c[1]
                }) : b.resolve() : b.forEach(b.db.table(292).fetch([
                    [
                        [a[0]]
                    ]
                ]), function(a) {
                    var b = a.update;
                    a.item;
                    return b({
                        fetchTimestampMs: c[1]
                    })
                }))
            })
        }, function(a) {
            return b.resolve(d)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxUpdateOccamadilloMostRecentMessagePerThreadStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateOptimisticContextThreadKeys", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.sequence([function(c) {
                return b.forEach(b.filter(b.db.table(32).fetch(), function(c) {
                    return b.i64.eq(c.threadKey, a[0])
                }), function(b) {
                    var c = b.update;
                    b.item;
                    return c({
                        threadKey: a[1]
                    })
                })
            }, function(c) {
                return b.forEach(b.filter(b.db.table(31).fetch(), function(c) {
                    return b.i64.eq(c.threadKey, a[0])
                }), function(b) {
                    var c = b.update;
                    b.item;
                    return c({
                        threadKey: a[1]
                    })
                })
            }])
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSCoreUpdateOptimisticContextThreadKeysStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateTaskQueueName", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.db.table(2).fetch([
                [
                    [a[0]]
                ], "queueNameTaskId"
            ]), function(b) {
                var c = b.update;
                b.item;
                return c({
                    queueName: a[1]
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSCoreUpdateTaskQueueNameStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateTaskValue", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            b = a[a.length - 1],
            c = [];
        return b.sequence([function(c) {
            return b.forEach(b.db.table(2).fetch([
                [
                    [a[0]]
                ], "queueNameTaskId"
            ]), function(b) {
                var c = b.update;
                b = b.item;
                return c({
                    taskValue: b.taskValue.split(a[1]).join(a[2])
                })
            })
        }, function(a) {
            return b.resolve(c)
        }])
    }
    a.__sproc_name__ = "LSCoreUpdateTaskValueStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateThreadAuthorityAndMapping", ["LSDeleteThread", "LSReplaceOptimisticThread", "LSShimGetServerThreadKeyFromJIDV2.nop", "LSUpdateOptimisticContextThreadKeys", "LSUpdateTaskQueueName", "LSUpdateTaskValue"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return c.nativeOperation(b("LSShimGetServerThreadKeyFromJIDV2.nop"), a[0]).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(b) {
                return c.db.table(9).fetch([
                    [
                        [a[1]]
                    ]
                ]).next().then(function(a, b) {
                    b = a.done;
                    a = a.value;
                    return b ? d[1] = !1 : (a.item, d[1] = !0)
                })
            }, function(b) {
                return c.filter(c.db.table(9).fetch(), function(b) {
                    return c.i64.eq(b.threadKey, a[2])
                }).next().then(function(a, b) {
                    b = a.done;
                    a = a.value;
                    return b ? d[3] = !1 : (a.item, d[3] = !0)
                })
            }, function(e) {
                return d[5] = c.i64.neq(d[0], void 0), d[7] = c.i64.eq(d[0], a[2]) && d[5], !d[7] && !(c.i64.eq(d[0], a[1]) && d[5]) && d[5] ? function(a) {
                    c.logger(a).mustfix(a)
                }("The mi_act_mapping row did not correspond to either the authoritative or optimistic thread key.") : 0, c.i64.neq(a[2], void 0) ? d[6] = a[2] : d[6] = c.i64.cast([0, 0]), d[5] ? d[7] ? c.sequence([function(e) {
                    return d[1] ? c.storedProcedure(b("LSDeleteThread"), a[1], !1) : c.resolve()
                }, function(a) {
                    return c.i64.neq(d[6], void 0) ? c.forEach(c.db.table(9).fetch([
                        [
                            [d[6]]
                        ]
                    ]), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            clientThreadKey: d[6]
                        })
                    }) : c.resolve()
                }, function(e) {
                    return c.storedProcedure(b("LSReplaceOptimisticThread"), d[6], a[1])
                }, function(e) {
                    return c.storedProcedure(b("LSUpdateOptimisticContextThreadKeys"), d[6], a[1])
                }]) : d[3] ? c.storedProcedure(b("LSDeleteThread"), d[6], !1) : c.resolve() : d[3] ? d[1] ? c.storedProcedure(b("LSDeleteThread"), d[6], !1) : c.sequence([function(a) {
                    return c.i64.neq(d[6], void 0) ? c.forEach(c.db.table(9).fetch([
                        [
                            [d[6]]
                        ]
                    ]), function(a) {
                        var b = a.update;
                        a.item;
                        return b({
                            clientThreadKey: d[6]
                        })
                    }) : c.resolve()
                }, function(e) {
                    return c.storedProcedure(b("LSReplaceOptimisticThread"), d[6], a[1])
                }, function(e) {
                    return c.storedProcedure(b("LSUpdateOptimisticContextThreadKeys"), d[6], a[1])
                }]) : c.resolve()
            }, function(e) {
                return d[3] ? c.sequence([function(e) {
                    return d[9] = c.i64.to_string(d[6]), d[8] = c.i64.to_string(a[1]), c.storedProcedure(b("LSUpdateTaskQueueName"), d[9], d[8])
                }, function(a) {
                    return c.storedProcedure(b("LSUpdateTaskValue"), d[8], d[9], d[8])
                }]) : c.resolve()
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxUpdateThreadAuthorityAndMappingStoredProcedure";
    e.exports = a
}), null);
__d("LSUpdateThreadAuthorityAndMappingWithOTIDFromJID", ["LSShimGetServerThreadKeyFromJIDV2.nop", "LSUpdateThreadAuthorityAndMapping"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(e) {
            return c.sequence([function(e) {
                return c.nativeOperation(b("LSShimGetServerThreadKeyFromJIDV2.nop"), a[0]).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(e) {
                return c.i64.neq(d[0], a[1]) ? d[1] = d[0] : d[1] = void 0, c.storedProcedure(b("LSUpdateThreadAuthorityAndMapping"), a[0], a[1], d[1])
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxUpdateThreadAuthorityAndMappingWithOTIDFromJIDStoredProcedure";
    e.exports = a
}), null);
__d("LSVerifyHybridThreadExists", ["LSShimVerifyThreadExists.nop", "LSVerifyE2EEMetadataThreadExistsV2"], (function(a, b, c, d, e, f) {
    function a() {
        var a = arguments,
            c = a[a.length - 1],
            d = [],
            e = [];
        return c.sequence([function(f) {
            return c.sequence([function(e) {
                return c.storedProcedure(b("LSVerifyE2EEMetadataThreadExistsV2"), a[2], a[0], c.i64.cast([0, 60])).then(function(a) {
                    return a = a, d[0] = a[0], a
                })
            }, function(b) {
                return d[1] = c.i64.of_float(Date.now()), c.i64.neq(a[11], void 0) ? c.sequence([function(b) {
                    return c.filter(c.db.table(168).fetch(), function(a) {
                        return c.i64.eq(a.authorityLevel, c.i64.cast([0, 80]))
                    }).next().then(function(b, e) {
                        var f = b.done;
                        b = b.value;
                        return f ? d[4] = !1 : (e = b.item, d[7] = e.deviceId, c.i64.neq(d[7], void 0) ? d[6] = c.i64.neq(d[7], a[11]) : d[6] = !1, d[4] = d[6])
                    })
                }, function(a) {
                    return d[2] = d[4]
                }]) : c.resolve(d[2] = !1)
            }, function(e) {
                return d[2] ? d[3] = !0 : d[3] = a[8], c.nativeOperation(b("LSShimVerifyThreadExists.nop"), a[0], a[1], a[3], a[4], a[5], a[6], a[7])
            }, function(a) {
                return e[0] = c.i64.cast([0, 0])
            }])
        }, function(a) {
            return c.resolve(e)
        }])
    }
    a.__sproc_name__ = "LSE2EEMessagingMetadataMailboxVerifyHybridThreadExistsStoredProcedure";
    e.exports = a
}), null);
//# sourceURL=https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/gbB5ekFXlDZ.js