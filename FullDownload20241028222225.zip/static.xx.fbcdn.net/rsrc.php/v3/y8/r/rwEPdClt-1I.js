;/*FB_PKG_DELIM*/

__d("LSDeleteThenInsertAvatarFeatureConfig",[],(function(a,b,c,d,e,f){function a(){var a=arguments,b=a[a.length-1],c=[];return b.resolve(c)}a.__sproc_name__="LSContactDeleteThenInsertAvatarFeatureConfigStoredProcedure";e.exports=a}),null);