;/*FB_PKG_DELIM*/

__d("MAWIsLinkPreviewWaitForXmaEnabled",["qex"],(function(a,b,c,d,e,f,g){"use strict";function a(){return c("qex")._("2042")===!0}function b(){return c("qex")._("2072")===!0}g.isLinkPreviewWaitForXmaEnabled=a;g.isLinkPreviewWaitForXmaEnabledShortTimeout=b}),98);
__d("MAWUpdateClientRestoreStatusOperationType",[],(function(a,b,c,d,e,f){"use strict";a=0;b=1;f.upsertClientRestoreStatus=a;f.markCompleteClientRestoreStatus=b}),66);